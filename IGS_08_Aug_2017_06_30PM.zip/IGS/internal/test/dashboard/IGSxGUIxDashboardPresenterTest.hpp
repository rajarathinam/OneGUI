/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenterTest.hpp
| Author       : Raja A
| Description  : Header file for Dashboard Presenter test
|
| ! \file        IGSxGUIxDashboardPresenterTest.hpp
| ! \brief       Header file for Dashboard Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDPRESENTERTEST_HPP
#define IGSXGUIXDASHBOARDPRESENTERTEST_HPP



#include "IGSxGUIxDashboardPresenter.hpp"



/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class DashboardPresenterTest : public ::testing::Test
{
 public:
  DashboardPresenterTest(){}
  virtual ~DashboardPresenterTest(){}

 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif // IGSXGUIXDASHBOARDPRESENTERTEST_HPP
