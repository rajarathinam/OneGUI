/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPITest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI test
|
| ! \file        IGSxGUIxKPITest.cpp
| ! \brief       Implementation of KPI test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKPITest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPITestParam,
                        ::testing::Values("EUV_Pulse_Energy_Internal"));

TEST_P(KPITestParam, Constructor)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);

    EXPECT_STRCASEEQ(kpi.getName().c_str(), m_kpiDefinition1.name().c_str());
    EXPECT_STRCASEEQ(kpi.getDescription().c_str(), m_kpiDefinition1.description().c_str());
}

TEST_P(KPITestParam,  ValueContentSize)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);
}

TEST_P(KPITestParam,  TypeTest)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    kpi.setType("KPI");
    EXPECT_STRCASEEQ("KPI", kpi.getType().c_str());

    kpi.setType("System");
    EXPECT_STRCASEEQ("System", kpi.getType().c_str());

    kpi.setType("Consumable");
    EXPECT_STRCASEEQ("Consumable", kpi.getType().c_str());

    kpi.setType("");
    EXPECT_STRCASEEQ("", kpi.getType().c_str());

    kpi.setType(" ");
    EXPECT_STRCASEEQ(" ", kpi.getType().c_str());

    kpi.setType("12345");
    EXPECT_STRCASEEQ("12345", kpi.getType().c_str());

}



TEST_P(KPITestParam,  GetActiveValueSet)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);

    for(size_t index = 0; index < valsetlist.size(); ++index)
    {
        EXPECT_TRUE(valsetlist[index]->isActive() == false);
    }

    IGSxGUI::KPIValueSet *invalidActiveValueset = kpi.getActiveValueSet();
    EXPECT_TRUE(invalidActiveValueset ==  NULL);


    valsetlist[1]->setActive(true);
    EXPECT_TRUE(valsetlist[1]->isActive() == true);
    EXPECT_EQ(1, valsetlist[1]->getIndexPosition());

    IGSxGUI::KPIValueSet *validActiveValueset = kpi.getActiveValueSet();
    EXPECT_TRUE(validActiveValueset !=  NULL);
    EXPECT_TRUE(validActiveValueset->isActive() == true);
    EXPECT_EQ(1, validActiveValueset->getIndexPosition());
}


TEST_P(KPITestParam,  GetValueSet)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    IGSxGUI::KPIValueSet* valueSet= kpi.getValueSet("");
    EXPECT_TRUE(valueSet ==  NULL);

    IGSxGUI::KPIValueSet* valueSet1= kpi.getValueSet(" ");
    EXPECT_TRUE(valueSet1 ==  NULL);

    IGSxGUI::KPIValueSet* valueSet2= kpi.getValueSet("ValueSetName1_1");
    EXPECT_TRUE(valueSet2 !=  NULL);

    IGSxGUI::KPIValueSet* valueSet3= kpi.getValueSet("INVALID");
    EXPECT_TRUE(valueSet3 ==  NULL);

}

TEST_P(KPITestParam, RegisterForValueChangedTest)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);

    time_t testtime = time(0);
    KPIValueSet testvalueset;
    testvalueset.push_back(10.0);
    testvalueset.push_back(30.0);
    testvalueset.push_back(20.0);
    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);
    kpi.updateValue(testkpidata1, true);

    EXPECT_STRCASEEQ("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("customkpiType", this->getKPIType().c_str());

}

TEST_P(KPITestParam, UpdateValueTestValidValueSet)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);
    valsetlist[0]->setIndexPosition(1);
    valsetlist[0]->setFactor(2.0);

    time_t testtime = time(0);
    KPIValueSet testvalueset;
    testvalueset.push_back(10.0);
    testvalueset.push_back(30.0);
    testvalueset.push_back(20.0);
    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);
    kpi.updateValue(testkpidata1, true);

    EXPECT_STRCASEEQ("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("customkpiType", this->getKPIType().c_str());

    IGSxGUI::KPIValueSet *activeKPIValueSet = kpi.getActiveValueSet();
    IGSxGUI::KPITimeValue newtimeValue1 =   activeKPIValueSet->getLastValue();
    EXPECT_EQ(testtime, newtimeValue1.kpiTime);
    EXPECT_DOUBLE_EQ(60.0, newtimeValue1.kpiValue);
    EXPECT_TRUE(newtimeValue1.isUpdated == true) ;
}

TEST_P(KPITestParam, UpdateValueTestInvalidValueSet)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(false); // No Active Valueset

    time_t testtime = time(0);
    KPIValueSet testvalueset;
    testvalueset.push_back(10.0);
    testvalueset.push_back(30.0);
    testvalueset.push_back(20.0);
    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);
    kpi.updateValue(testkpidata1, true);

    EXPECT_STRCASENE("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASENE("customkpiType", this->getKPIType().c_str());

}

TEST_P(KPITestParam, UpdateValueTestInvalidDataSize)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);

    time_t testtime = time(0);
    KPIValueSet testvalueset; // Empty Valueset

    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);
    kpi.updateValue(testkpidata1, true);

    EXPECT_STRCASENE("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASENE("customkpiType", this->getKPIType().c_str());

}

TEST_P(KPITestParam, UpdateValueTestNoValueChnagedRegistration)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);

    time_t testtime = time(0);
    KPIValueSet testvalueset;
    testvalueset.push_back(10.0);
    testvalueset.push_back(30.0);
    testvalueset.push_back(20.0);
    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);
    kpi.updateValue(testkpidata1, true);

    EXPECT_STRCASENE("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASENE("customkpiType", this->getKPIType().c_str());

}


TEST_P(KPITestParam, UpdateValuesTestValid)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);
    valsetlist[0]->setIndexPosition(1);
    valsetlist[0]->setFactor(2.0);

    time_t testtime1 = time(0);
    time_t testtime2 = time(0) + 10;

    KPIValueSet testvalueset1;
    testvalueset1.push_back(11.0);
    testvalueset1.push_back(12.0);
    testvalueset1.push_back(13.0);

    KPIValueSet testvalueset2;
    testvalueset2.push_back(21.0);
    testvalueset2.push_back(22.0);
    testvalueset2.push_back(23.0);

    IGSxKPI::KPIData testkpidata1("kpidata1", testtime1, testvalueset1);
    IGSxKPI::KPIData testkpidata2("kpidata2", testtime2, testvalueset2);

    IGSxKPI::KPIDataList kpidatalist;
    kpidatalist.push_back(testkpidata1);
    kpidatalist.push_back(testkpidata2);



    kpi.updateValues(kpidatalist, true);

    EXPECT_STRCASEEQ("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("customkpiType", this->getKPIType().c_str());

    IGSxGUI::KPIValueSet *activeKPIValueSet = kpi.getActiveValueSet();
    IGSxGUI::KPITimeValue newtimeValue1 =   activeKPIValueSet->getLastValue();
    EXPECT_EQ(testtime2, newtimeValue1.kpiTime);
    EXPECT_DOUBLE_EQ(44.0, newtimeValue1.kpiValue);
    EXPECT_TRUE(newtimeValue1.isUpdated == true) ;
}

TEST_P(KPITestParam, UpdateValuesTestEmptyDataList)
{
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition("customkpidefinitionName", "customkpidefinitionDescription", kpivaluedeinitionlist);
    IGSxGUI::KPI kpi(kpidefinition);
    kpi.setType("customkpiType");

    this->setKPIName("DummyName");
    this->setKPIType("DummyType");
    EXPECT_STRCASEEQ("DummyName", this->getKPIName().c_str());
    EXPECT_STRCASEEQ("DummyType", this->getKPIType().c_str());


    kpi.registerForValueChanged(boost::bind(&KPITestParam::onKPIDataUpdated, this, _1, _2));

    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    valsetlist[0]->setActive(true);

    time_t testtime1 = time(0);
    time_t testtime2 = time(0) + 10;
    KPIValueSet testvalueset1;
    testvalueset1.push_back(10.0);
    testvalueset1.push_back(30.0);
    testvalueset1.push_back(20.0);

    KPIValueSet testvalueset2;
    testvalueset2.push_back(10.0);
    testvalueset2.push_back(30.0);
    testvalueset2.push_back(20.0);

    IGSxKPI::KPIData testkpidata1("kpidata1", testtime1, testvalueset1);
    IGSxKPI::KPIData testkpidata2("kpidata2", testtime2, testvalueset2);

    IGSxKPI::KPIDataList kpidatalist;

    kpi.updateValues(kpidatalist, true);

    EXPECT_STRCASENE("customkpidefinitionName", this->getKPIName().c_str());
    EXPECT_STRCASENE("customkpiType", this->getKPIType().c_str());

}

