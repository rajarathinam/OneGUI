/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemDateTimeTest.cpp
| Author       : Raja A
| Description  : Implementation of SystemDateTime test
|
| ! \file        IGSxGUIxSystemDateTimeTest.cpp
| ! \brief       Implementation of SystemDateTime test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxGUIxSystemDateTimeTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(SystemDateTimeTest, TimeTest)
{
  std::string actualtime = IGSxGUI::SystemDateTime::getSystemCurrentDateTime(IGSxGUI::SystemDateTime::STR_TIME);

  time_t     now = time(0);
  struct tm  tstruct;
  char       buf[IGSxGUI::CONVERSION_BUFFER_SIZE];
  tstruct = *localtime_r(&now, &tstruct);
  strftime(buf, sizeof(buf), "%H:%M", &tstruct);
  std::string expectedtime = buf;
  EXPECT_EQ(expectedtime, actualtime);
}

TEST_F(SystemDateTimeTest, DateTest)
{
    std::string actualtime = IGSxGUI::SystemDateTime::getSystemCurrentDateTime(IGSxGUI::SystemDateTime::STR_DATE);

    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[IGSxGUI::CONVERSION_BUFFER_SIZE];
    tstruct = *localtime_r(&now, &tstruct);
    strftime(buf, sizeof(buf), "%Y-%m-%d", &tstruct);
    std::string expectedtime = buf;

    EXPECT_EQ(expectedtime, actualtime);
}
TEST_F(SystemDateTimeTest, DateTimeTest)
{
    std::string actualtime = IGSxGUI::SystemDateTime::getSystemCurrentDateTime(IGSxGUI::SystemDateTime::STR_DATE_TIME);

    std::string expectedtime = "";
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[IGSxGUI::CONVERSION_BUFFER_SIZE];
    tstruct = *localtime_r(&now, &tstruct);
    strftime(buf, sizeof(buf), "%Y-%m-%d  %H:%M", &tstruct);
    expectedtime = buf;

    EXPECT_EQ(expectedtime, actualtime);
}

TEST_F(SystemDateTimeTest, TimeDiffTest)
{
  time_t time1 = time(0);
  time_t time2 = time(0) + 60;
  int actualtimedifference = IGSxGUI::SystemDateTime::getTimeDifferenceInMinutes(time2, time1);
  EXPECT_EQ(1, actualtimedifference);

  time2 = time(0) + 120;
  actualtimedifference = IGSxGUI::SystemDateTime::getTimeDifferenceInMinutes(time2, time1);
  EXPECT_EQ(2, actualtimedifference);

  time2 = time(0);
  actualtimedifference = IGSxGUI::SystemDateTime::getTimeDifferenceInMinutes(time2, time1);
  EXPECT_EQ(0, actualtimedifference);

  time2 = time(0) - 120;
  actualtimedifference = IGSxGUI::SystemDateTime::getTimeDifferenceInMinutes(time2, time1);
  EXPECT_EQ(-2, actualtimedifference);

  time2 = time(0) + 40;
  actualtimedifference = IGSxGUI::SystemDateTime::getTimeDifferenceInMinutes(time2, time1);
  EXPECT_EQ(0, actualtimedifference);
}
