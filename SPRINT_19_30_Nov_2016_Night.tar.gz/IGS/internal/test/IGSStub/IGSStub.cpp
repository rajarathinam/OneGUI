/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS_Stub.cpp
| Author       : Thijs Jacobs
| Description  : Stub impementation of IGSxITS library
|
| ! \file        IGSxITS_Stub.cpp
| ! \brief       Stub impementation of IGSxITS library
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSStub.hpp"
#include <assert.h>
#include <time.h>
#include <stdlib.h>
#include <boost/bind.hpp>
#include <string>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

const int MS_IN_SEC = 1000;
const int NO_ERROR = 0x0000;
const int ERROR_CODE = 0x1234;
const char* IGSxITS::InitTerminate_Stub::ERR_INIT_SYS = "Error while Initializing system";
const char* IGSxITS::InitTerminate_Stub::ERR_GET_DRIVER = "Error while getting driver";

typedef struct
{
    std::string name;
    std::string desc;
    int initDur;
    int termDur;
} gMetaType;

typedef struct
{
    std::string sysfun;
    gMetaType driver;
} gDriverType;

gMetaType gSystem = {"EUV Source", "EUV Source", 40, 20};

gMetaType gSysfun[] = {
    {"SF-04", "Environmental Control", 30, 15},
    {"SF-15", "Laser", 40, 20},
    {"SF-16", "Droplet Generation & Positioning", 20, 10},
    {"SF-17", "Plasma and Energy Control", 20, 10},
    {"SF-18", "Spectrally Pure EUV Collection", 30, 15},
    {"SF-19", "Tin Mitigation", 40, 20},
    {"SF-20", "Source Machine Control", 40, 20}
};

gDriverType gDriver[] = {
    {"SF-04", {"Collector Cooling Driver", "[NOT IMPLEMENTED]Collector Cooling Driver", 10, 5}},
    {"SF-04", {"Vessel Heat Exchanger Driver", "[NOT IMPLEMENTED]Vessel Heat Exchanger Driver", 10, 5}},
    {"SF-04", {"SFC Environmental Control", "SFC Environmental Control", 20, 10}},
    {"SF-04", {"Gas and Vacuum Driver", "Gas and Vacuum Driver", 20, 10}},
    {"SF-04", {"HP-RGA Driver", "HP-RGA Driver", 30, 15}},
    {"SF-15", {"Laser Generation Driver", "Laser Generation Driver", 10, 5}},
    {"SF-15", {"SFC Laser Management", "SFC Laser Management", 10, 5}},
    {"SF-15", {"Amplification Chain Driver", "Amplification Chain Driver", 20, 10}},
    {"SF-15", {"M150 Vacuum Driver", "M150 Vacuum Driver", 20, 10}},
    {"SF-15", {"FFA Driver", "FFA Driver", 30, 15}},
    {"SF-15", {"BFSR Driver", "BFSR Driver", 30, 15}},
    {"SF-16", {"DG Control Driver", "DG Control Driver", 20, 10}},
    {"SF-17", {"Plasma Driver", "Plasma Driver", 10, 5}},
    {"SF-17", {"Target Formation Monitoring Driver", "Target Formation Monitoring Driver", 10, 5}},
    {"SF-17", {"Energy Control Driver", "Energy Control Driver", 20, 10}},
    {"SF-18", {"Power Limiter Driver", "Power Limiter Driver", 30, 15}},
    {"SF-19", {"Collector Cleaning Driver", "Collector Cleaning Driver", 10, 5}},
    {"SF-19", {"Metrology Cleaning Driver", "Metrology Cleaning Driver", 10, 5}},
    {"SF-19", {"SFC Tin Debris Management", "SFC Tin Debris Management", 20, 10}},
    {"SF-19", {"Heated Tin Vanes Bucket Driver", "Heated Tin Vanes Bucket Driver", 20, 10}},
    {"SF-19", {"Vanes Driver", "Vanes Driver", 30, 15}},
    {"SF-20", {"System State Controller", "System State Controller", 30, 15}},
};

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxITS::InitTerminate* IGSxITS::InitTerminate::instance = IGSxITS::InitTerminate_Stub::getInstance();

IGSxITS::InitTerminate_Stub::InitTerminate_Stub() :
    m_initializeSystemCompletedCb(NULL),
    m_initializeDriverCompletedCb(NULL),
    m_terminateSystemCompletedCb(NULL),
    m_terminateDriverCompletedCb(NULL),
    m_driverStatusChangedCb(NULL),
    m_driver(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_elapsedTime(0),
    m_throwException(false)
{
    srand(time(NULL));  // init random seed
    m_timer->setInterval(MS_IN_SEC);
    m_timer->setSingleShot(false);

    for (size_t i = 0; i < sizeof(gDriver) / sizeof(*gDriver); i++)
    {
        gMetaType* driver = &gDriver[i].driver;
        m_drivers.push_back(Driver(driver->name, driver->desc, driver->initDur, driver->termDur));
    }
}

IGSxITS::InitTerminate_Stub::~InitTerminate_Stub()
{
    m_timer->stop();
}

IGSxITS::InitTerminate* IGSxITS::InitTerminate_Stub::getInstance()
{
    static InitTerminate_Stub _instance;
    return &_instance;
}

IGSxITS::MetaDescriptions IGSxITS::InitTerminate_Stub::getSysfuns()
{
    MetaDescriptions sysfuns;
    for (size_t i = 0; i < sizeof(gSysfun) / sizeof(*gSysfun); i++)
    {
        gMetaType* sysfun = &gSysfun[i];
        sysfuns.push_back(MetaDescription(sysfun->name, sysfun->desc));
    }
    return sysfuns;
}

IGSxITS::MetaDescriptions IGSxITS::InitTerminate_Stub::getDrivers(const std::string& sysfunName)
{
    MetaDescriptions drivers;
    if (sizeof(gDriver) > 0 && sizeof(*gDriver) > 0 && sizeof(gDriver)/sizeof(*gDriver) > 0)
    {
        for (size_t i = 0; i < sizeof(gDriver) / sizeof(*gDriver); i++)
        {
            if (sysfunName == gDriver[i].sysfun)
            {
                gMetaType* driver = &gDriver[i].driver;
                drivers.push_back(MetaDescription(driver->name, driver->desc));
            }
        }
    }
    if (m_throwException)
    {
        throw IGS::Exception(ERR_GET_DRIVER);
    }

    return drivers;
}

// init/terminate requests
void IGSxITS::InitTerminate_Stub::initializeSystem(const InitializeCompletedCallback& cb)
{
    m_initializeSystemCompletedCb = cb;

    bool hasError = false;
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        Driver& driver = m_drivers[i];
        if (DriverState::DS_INITIALIZED != driver.driverState())
        {
            if (NO_ERROR != driver.error())
            {
                hasError = true;
            }
            driver.setDriverState(DriverState::DS_INITIALIZING);
            driver.setError(NO_ERROR);
            notifyDriverStateChanged(&driver);
        }
    }

    if (!hasError)
    {
        // inject an error to a random driver
        m_drivers[rand() % m_drivers.size()].setError(ERROR_CODE);
    }

    m_timer->setInterval(MS_IN_SEC);
    m_timer->timeout = boost::bind(&InitTerminate_Stub::on_initializeSystem, this);
    m_elapsedTime = 0;
    m_timer->start();
    if (m_throwException)
    {
        throw IGS::Exception(ERR_INIT_SYS);  // For Testing purpose
    }
}

void IGSxITS::InitTerminate_Stub::initializeDrivers(const DriverNames& /*driverNames*/, const InitializeCompletedCallback& /*cb*/)
{
    /*m_initializeDriverCompletedCb = cb;

    for (unsigned i = 0; i < driverNames.size(); i++)
    {
        m_driver = &driver(driverNames[i]);
        m_driver->setDriverState(DriverState::DS_INITIALIZING);

        m_timer->timeout = boost::bind(&InitTerminate_Stub::on_initializeDriver, this);
        m_elapsedTime = 0;
        m_timer->start();
    }*/
}

void IGSxITS::InitTerminate_Stub::terminateSystem(const TerminateCompletedCallback& cb)
{
    m_terminateSystemCompletedCb = cb;

    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        m_drivers[i].setDriverState(DriverState::DS_TERMINATING);
        notifyDriverStateChanged(&m_drivers[i]);
    }

    m_timer->timeout = boost::bind(&InitTerminate_Stub::on_terminateSystem, this);
    m_elapsedTime = 0;
    m_timer->start();
}

void IGSxITS::InitTerminate_Stub::terminateDrivers(const DriverNames& /*driverNames*/, const TerminateCompletedCallback& /*cb*/)
{
    /*m_terminateDriverCompletedCb = cb;

    for (unsigned i = 0; i < driverNames.size(); i++)
    {
        m_driver = &driver(driverNames[i]);
        m_driver->setDriverState(DriverState::DS_TERMINATING);

        m_timer->timeout = boost::bind(&InitTerminate_Stub::on_terminateDriver, this);
        m_elapsedTime = 0;
    }
    m_timer->start();*/
}

IGSxITS::DriverStatus IGSxITS::InitTerminate_Stub::getDriverStatus(const std::string& driverName)
{
  return driver(driverName).driverStatus();
}

// subscribe to state changes
void IGSxITS::InitTerminate_Stub::subscribeToDriverStatusChanged(const DriverStatusChangedCallback& cb)
{
    m_driverStatusChangedCb = cb;
}

void IGSxITS::InitTerminate_Stub::unsubscribeToDriverStatusChanged()
{
    if (m_driverStatusChangedCb)
    {
        m_driverStatusChangedCb = NULL;
    }
}

// notify state changes
IGSxITS::Driver& IGSxITS::InitTerminate_Stub::driver(const std::string& driverName)
{
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        if (driverName == m_drivers[i].name())
        {
            return m_drivers[i];
        }
    }
    assert(false);
}

void IGSxITS::InitTerminate_Stub::notifyDriverStateChanged(Driver *driver)
{
    if (m_driverStatusChangedCb)
    {
        DriverStatus driverStatus(driver->driverState());
        m_driverStatusChangedCb(driver->name(), driverStatus);
    }
}

void IGSxITS::InitTerminate_Stub::on_initializeSystem()
{
    bool initialized = true;
    m_elapsedTime += m_timer->interval();

    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        Driver& driver = m_drivers[i];
        if (DriverState::DS_INITIALIZING == driver.driverState())
        {
            if (m_elapsedTime >= driver.initializeDuration() * MS_IN_SEC)
            {
                if (NO_ERROR == driver.error())
                {
                    driver.setDriverState(DriverState::DS_INITIALIZED);
                } else {
                    driver.setDriverState(DriverState::DS_RECOVERY_REQUIRED);
                }
                notifyDriverStateChanged(&driver);
            } else {
                initialized = false;
            }
        }
    }

    if (initialized)
    {
        m_timer->stop();
        if (m_initializeSystemCompletedCb)
        {
            m_initializeSystemCompletedCb(IGS::OK);
        }
    }
}

void IGSxITS::InitTerminate_Stub::on_terminateSystem()
{
    bool terminated = true;
    m_elapsedTime += m_timer->interval();

    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        Driver& driver = m_drivers[i];
        if (DriverState::DS_TERMINATING == driver.driverState())
        {
            if (m_elapsedTime >= driver.terminateDuration() * MS_IN_SEC)
            {
                driver.setDriverState(DriverState::DS_TERMINATED);
                notifyDriverStateChanged(&driver);
            } else {
                terminated = false;
            }
        }
    }

    if (terminated)
    {
        m_timer->stop();
        if (m_terminateSystemCompletedCb)
        {
            m_terminateSystemCompletedCb(IGS::OK);
        }
    }
}

void IGSxITS::InitTerminate_Stub::on_initializeDriver()
{
    m_elapsedTime += m_timer->interval();

    if (m_driver && (DriverState::DS_INITIALIZING == m_driver->driverState()) && (m_elapsedTime >= m_driver->initializeDuration() * MS_IN_SEC))
    {
        m_timer->stop();

        m_driver->setDriverState(DriverState::DS_INITIALIZED);
        notifyDriverStateChanged(m_driver);
        m_driver = NULL;

        if (m_initializeDriverCompletedCb)
        {
            m_initializeDriverCompletedCb(IGS::OK);
        }
    }
}

void IGSxITS::InitTerminate_Stub::on_terminateDriver()
{
    m_elapsedTime += m_timer->interval();

    if (m_driver && (DriverState::DS_TERMINATING == m_driver->driverState()) && (m_elapsedTime >= m_driver->terminateDuration() * MS_IN_SEC))
    {
        m_timer->stop();

        m_driver->setDriverState(DriverState::DS_TERMINATED);
        notifyDriverStateChanged(m_driver);
        m_driver = NULL;

        if (m_terminateDriverCompletedCb)
        {
            m_terminateDriverCompletedCb(IGS::OK);
        }
    }
}

int IGSxITS::InitTerminate_Stub::getInitializeDuration(const std::string& driverName)
{
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        if (driverName == m_drivers[i].name())
        {
            Driver drv = m_drivers[i];
            return drv.initializeDuration();
        }
    }
    return 0;
}

int IGSxITS::InitTerminate_Stub::getTerminateDuration(const std::string& driverName)
{
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        if (driverName == m_drivers[i].name())
        {
            Driver drv = m_drivers[i];
            return drv.terminateDuration();
        }
    }
    return 0;
}

void IGSxITS::InitTerminate_Stub::setDriverStatus(std::string driverName, DriverState::DriverStateEnum state)
{
    for (unsigned i = 0; i < m_drivers.size(); i++)
    {
        if (driverName == m_drivers[i].name())
        {
            Driver drv = m_drivers[i];
            drv.setDriverState(state);

            notifyDriverStateChanged(&drv);
        }
    }
}

void IGSxITS::InitTerminate_Stub::setThrowExceptions(bool enable)
{
    m_throwException = enable;
}
