/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGS_Timer.hpp
| Author       : Thijs Jacobs
| Description  : Header file for Timer
|
| ! \file        IGS_Timer.hpp
| ! \brief       Header file for Timer
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGS_TIMER_HPP
#define IGS_TIMER_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <pthread.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
namespace IGS {

class Timer
{
 public:
    typedef boost::function<void ()> Callback;

    Timer();
    virtual ~Timer();

    void start();
    void stop();

    int interval() {return m_interval;}
    int elapsedTime() {return m_elapsedTime;}
    bool isSingleShot() {return m_singleShot;}
    void setInterval(int interval) {m_interval = interval;}
    void setSingleShot(bool singleShot) {m_singleShot = singleShot;}
    void setCallback(const Callback& cb) {m_callback = cb;}

 protected:
    void run();

 private:
    static void *runFunc(void *This);

 private:
    int m_interval;  // timer interval in ms
    int m_elapsedTime;  // elapsed time in ms since start
    bool m_singleShot;
    bool m_quit;
    Callback m_callback;
    pthread_t m_thread;
};

}  // namespace IGS

#endif  // IGS_TIMER_HPP

