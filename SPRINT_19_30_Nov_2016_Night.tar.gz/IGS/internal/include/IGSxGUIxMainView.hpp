/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Main application view
|
| ! \file        IGSxGUIxMainView.hpp
| ! \brief       Header file for Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMAINVIEW_HPP
#define IGSXGUIXMAINVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <vector>
#include <string>
#include "IGSxGUIxMainPresenter.hpp"
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MainView;
}  // namespace SUI

namespace IGSxGUI {
class MainView: public IGSxGUI::IMainView
{
 public:
    MainView();
    virtual ~MainView();
    virtual void show();
    virtual void showError(const std::string& eMsg, const std::string& timeStamp);
    virtual void hideError();
    typedef boost::function<void(SystemState::SystemStateEnum)> systemStateChanged;

 private:
    MainView(const MainView &);
    MainView& operator=(const MainView &);

    enum BUTTON
    {
        BTN_SYSTEM,
        BTN_DASHBOARD,
        BTN_ANALYSIS,
        BTN_ERRORALARM
    }NavigationButton;

    void onSystemButtonPressed();
    void onSystemHoverOn();
    void onSystemHoverOff();
    void onDashboardButtonPressed();
    void onDashboardHoverOn();
    void onDashboardHoverOff();
    void onAnalysisButtonPressed();
    void onAnalysisHoverOn();
    void onAnalysisHoverOff();
    void onCPDButtonPressed();
    void onErrorAlarmButtonPressed();
    void onErrorAlarmHoverOn();
    void onErrorAlarmHoverOff();
    void onErrorCloseBtnPressed();
    void onSubMenuButton1Pressed();
    void onSubMenuButton2Pressed();
    void onSubMenuButton3Pressed();
    void onSubMenuButton4Pressed();
    void onSubMenuButton5Pressed();

    void onSystemStateChanged(SystemState::SystemStateEnum state);
    void onTimeout();
    void setNavigationButtonStyles(BUTTON button, std::string strImage, std::string strStyle);
    const std::string currentDateTime(const std::string& dateTime);

    static const std::string MAINVIEW_LOAD_FILE;

    static const std::string NAVIGATION_BUTTON_SYSTEM;
    static const std::string NAVIGATION_BUTTON_DASHBOARD;
    static const std::string NAVIGATION_BUTTON_ANALYSIS;
    static const std::string NAVIGATION_BUTTON_ERRORALARM;

    static const std::string IMAGE_WHITE_SYSTEM;
    static const std::string IMAGE_WHITE_DASHBOARD;
    static const std::string IMAGE_WHITE_ANALYSIS;
    static const std::string IMAGE_WHITE_WARNING;
    static const std::string IMAGE_WHITE_CLOCK;
    static const std::string IMAGE_WHITE_INFO;
    static const std::string IMAGE_WHITE_CHECKCIRCLE;

    static const std::string IMAGE_BLUE_SYSTEM;
    static const std::string IMAGE_BLUE_DASHBOARD;
    static const std::string IMAGE_BLUE_ANALYSIS;

    static const std::string IMAGE_GREEN_CHECKCIRCLE;
    static const std::string IMAGE_RED_WARNING_16PX;

    static const std::string STRING_TIME;
    static const std::string STRING_DATE;

    static const std::string STRING_INITIALIZED;
    static const std::string STRING_TERMINATED;
    static const std::string STRING_PARTIALLY_INITIALIZED;
    static const std::string STRING_RECOVERY_REQUIRED;

    static const std::string STYLE_HOVER_ON;
    static const std::string STYLE_HOVER_OFF;
    static const std::string STYLE_ERROR_ALARM_HOVER_ON;
    static const std::string STYLE_ERROR_ALARM_HOVER_OFF;

    static const int TIMER_INTERVAL;
    static const int TIMER_RESTART_INTERVAL;

    SUI::MainView *sui;
    IGSxGUI::MainPresenter *m_presenter;
    ISystem *m_iSystem;
    IDashboard *m_iDashboard;
    IAnalysis *m_iAnalysis;
    ISystem *m_iCPD;
    boost::shared_ptr<SUI::Timer> m_timer;
    systemStateChanged m_systemChanged;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMAINVIEW_HPP
