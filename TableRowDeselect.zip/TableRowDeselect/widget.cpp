#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    model = new QStandardItemModel;
    widget = new QWidget;
    model->setColumnCount(1);
    model->setRowCount(5);
    ui->tableView->setModel(model);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableView->horizontalHeader()->hide();
    ui->tableView->verticalHeader()->hide();
    ui->tableView->resizeColumnsToContents();
    ui->tableView->setStyleSheet("border:2px solid red;border-top: 0px;border-left: 0px;border-right: 0px;");
    button = new QPushButton;
    buttonclicked = false;



}

Widget::~Widget()
{
    delete ui;
}
QLabel* Widget::getADTNameLabel(QPushButton *button)
{
    QLayout *layout = button->layout();
    QVBoxLayout *vboxlayout =  dynamic_cast<QVBoxLayout*>(layout->itemAt(0));
    QLabel *label = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(0)->widget());
    return label;
}

void Widget::on_pushButton_clicked()
{
    ui->tableView->clearSelection();
    ui->tableView->horizontalHeader()->adjustSize();
    for(int i =0; i < model->rowCount(); ++i)
    {
        QModelIndex index = model->index(i, 0);
        button = addADTUserControl();
        getADTNameLabel(button)->setText(QString::number(i));
        buttons.push_back(button);
        ui->tableView->setIndexWidget(index, button);
        ui->tableView->resizeRowsToContents();
    }
    foreach (QPushButton* button, buttons) {
        connect(button, SIGNAL(clicked(bool)),
                this, SLOT(onRowClicked()));
    }


}

void Widget::onRowClicked()
{
    if(!buttonclicked)
    {
        ui->pushButton->setVisible(true);
        buttonclicked = true;
    }
    else
    {
        ui->pushButton->setVisible(false);
        buttonclicked = false;
    }

    foreach (QPushButton* button, buttons) {
        button->setStyleSheet("QPushButton:!hover{background-color:white}");
        button->setStyleSheet(button->styleSheet() + "QPushButton:hover:!pressed{background-color:#DAF2FE;}");
        QLayout *layout = button->layout();
        QVBoxLayout *vboxlayout =  dynamic_cast<QVBoxLayout*>(layout->itemAt(0));
        QLabel *label0 = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(0)->widget());
        label0->setStyleSheet("color:black");
        QLabel *label1 = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(1)->widget());
        label1->setStyleSheet("color:black");
    }

    button = dynamic_cast<QPushButton*>(QObject::sender());
    qDebug() << getADTNameLabel(button)->text() ;
    button->setStyleSheet("QPushButton{background-color:#1B3E93;}");

    QLayout *layout = button->layout();
    QVBoxLayout *vboxlayout =  dynamic_cast<QVBoxLayout*>(layout->itemAt(0));
    QLabel *label0 = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(0)->widget());
    label0->setStyleSheet("color:white");
    QLabel *label1 = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(1)->widget());
    label1->setStyleSheet("color:white");


}

QPushButton* Widget::addADTUserControl()
{
   QPushButton *button = new QPushButton;
   QVBoxLayout *vlayout = new QVBoxLayout();
   QHBoxLayout *hlayout = new QHBoxLayout();

   QLabel *adtname = new QLabel("ADTNAme");
   QLabel *adtdescription = new QLabel("ADTDescription");
   QSpacerItem *spacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
   QLabel *arrow = new QLabel("Arrow");

   vlayout->addWidget(adtname);
   vlayout->addWidget(adtdescription);
   hlayout->addLayout(vlayout);
   hlayout->addItem(spacer);
   hlayout->addWidget(arrow);
   button->setLayout(hlayout);
   button->setFixedSize(545, 60);
   button->setStyleSheet("QPushButton:!hover{background-color:white}");
   button->setStyleSheet(button->styleSheet() + "QPushButton:hover:!pressed{background-color:#DAF2FE;}");
   return button;

}

