/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashView.cpp
| Author       : Raja A
| Description  : Implementation of Splash screen view
|
| ! \file        IGSxGUIxSplashView.cpp
| ! \brief       Implementation of Splash screen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxMoc_SplashView.hpp"
#include "IGSxGUIxUtil.hpp"
#include <SUIDialog.h>
#include <SUIProgressBar.h>
#include <SUIGraphicsView.h>
#include <SUILabel.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SplashView::SPLASHVIEW_LOAD_FILE = "IGSxGUIxSplashView.xml";


IGSxGUI::SplashView::SplashView():
    sui(new SUI::SplashView)
{
    if (sui != NULL)
    {
        sui->setupSUI(SPLASHVIEW_LOAD_FILE.c_str());
    }

    m_presenter = new IGSxGUI::SplashPresenter(this);

    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::setAwesome(sui->lblCopyrightImage, IGSxGUI::AwesomeIcon::AI_fa_copyright, SUI::ColorEnum::Gray);
    sui->lblCopyright->setVisible(false);
    sui->lblCopyrightImage->setVisible(false);
    sui->lblCopyrightText->setVisible(false);
}
IGSxGUI::SplashView::~SplashView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SplashView::show()
{
    sui->dialog->show();

    sui->lblMachineId->setText(m_presenter->getMachineId());
    sui->lblVersion->setText(m_presenter->getReleaseId());
}

void IGSxGUI::SplashView::hide()
{
    sui->dialog->hide();
}

