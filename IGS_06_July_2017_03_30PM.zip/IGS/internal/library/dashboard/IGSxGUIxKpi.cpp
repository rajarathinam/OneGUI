/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpi.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI
|
| ! \file        IGSxGUIxKpi.cpp
| ! \brief       Implementation of KPI
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::KPI::STRING_EMPTY = "";

IGSxGUI::KPI::KPI(IGSxKPI::KPIDefinition kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description()),
    m_type("")
{
    for (size_t i = 0; i < kpiDefinition.values()->size(); ++i)
    {
        KPIValueSet* kpiValueSet = new KPIValueSet(kpiDefinition.values()->at(i));
        kpiValueSet->setIndexPosition(i);

        if (kpiValueSet != NULL)
        {
            m_KPIValueSets.push_back(kpiValueSet);
        }
    }
}

IGSxGUI::KPI::~KPI()
{
    for (vector<KPIValueSet*>::iterator it = m_KPIValueSets.begin() ; it != m_KPIValueSets.end(); ++it)
    {
        if (*it != NULL)
        {
           delete (*it);
        }
    }
    m_KPIValueSets.clear();
}

std::string IGSxGUI::KPI::getType() const
{
    return m_type;
}

void IGSxGUI::KPI::setType(const std::string &type)
{
    m_type = type;
}

string IGSxGUI::KPI::getName() const
{
    return m_name;
}

string IGSxGUI::KPI::getDescription() const
{
    return m_desc;
}

void IGSxGUI::KPI::updateValue(const IGSxKPI::KPIData &kpiData, bool valsetUpdate) const
{
    KPIValueSet* valset = getActiveValueSet();

    if (valset != NULL)
    {
        size_t index = valset->getIndexPosition();
        IGSxKPI::KPIData data = kpiData;
        if (data.values()->size() > index)
        {
            valset->addValue(data.time(), data.values()->at(index), valsetUpdate);

            if (!m_valueChanged.empty())
            {
                m_valueChanged(getName(), getType());
            }
        }
    }
}

void IGSxGUI::KPI::updateValues(const IGSxKPI::KPIDataList &kpiDataList, bool valsetUpdate) const
{
    for (size_t i = 0; i < kpiDataList.size(); i++)
    {
        updateValue(kpiDataList[i], valsetUpdate);
    }
}

boost::signals2::connection IGSxGUI::KPI::registerForValueChanged(const IGSxGUI::KPI::ValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}

IGSxGUI::KPIValueSet *IGSxGUI::KPI::getValueSet(const std::string &name) const
{
    for (size_t i = 0; i < m_KPIValueSets.size(); i++)
    {
        if (m_KPIValueSets[i]->getName() == name)
        {
            return m_KPIValueSets[i];
        }
    }
    return NULL;
}

std::vector<IGSxGUI::KPIValueSet*> IGSxGUI::KPI::getValueSets() const
{
    return m_KPIValueSets;
}

IGSxGUI::KPIValueSet *IGSxGUI::KPI::getActiveValueSet() const
{
    for (size_t i = 0; i < m_KPIValueSets.size(); i++)
    {
        if (m_KPIValueSets[i]->isActive())
        {
            return m_KPIValueSets[i];
        }
    }
    return NULL;
}
