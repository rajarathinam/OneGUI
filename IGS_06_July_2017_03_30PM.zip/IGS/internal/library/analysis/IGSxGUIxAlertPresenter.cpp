/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertPresenter.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert plugin Presenter
|
| ! \file        IGSxGUIxAlertPresenter.cpp
| ! \brief       Implementation of Alert plugin Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxAlertPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::AlertPresenter::AlertPresenter(IGSxGUI::IAlertView* view, AlertManager* pAlertManager):
    m_view(view),
    m_pAlertManager(pAlertManager)
{
}

IGSxGUI::AlertPresenter::~AlertPresenter()
{
    m_connection.disconnect();
}

void IGSxGUI::AlertPresenter::subscribeForEvents()
{
    m_connection = m_pAlertManager->registerToAlertUpdated(boost::bind(&IGSxGUI::AlertPresenter::OnAlertUpdated, this, _1, _2));
}

void IGSxGUI::AlertPresenter::unsubscribeForEvents()
{
    m_connection.disconnect();
}

std::vector<IGSxGUI::Alert *> IGSxGUI::AlertPresenter::getActiveAlerts() const
{
    return m_pAlertManager->getActiveAlerts();
}

IGSxGUI::Alert *IGSxGUI::AlertPresenter::getAlert(int nAlertLogID) const
{
    return m_pAlertManager->getAlert(nAlertLogID);
}

void IGSxGUI::AlertPresenter::OnAlertUpdated(int nAlertCount, AlertInfo alertInfo) const
{
    m_view->updateAlerts(nAlertCount, alertInfo);
}
