/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Main application view
|
| ! \file        IGSxGUIxMainView.hpp
| ! \brief       Header file for Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMAINVIEW_HPP
#define IGSXGUIXMAINVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxGUIxMainPresenter.hpp"
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxSystemState.hpp"
#include "IGSxGUIxISystem.hpp"
#include "IGSxGUIxIDashboard.hpp"
#include "IGSxGUIxIAnalysis.hpp"
#include "IGSxGUIxISplashView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MainView;
class Timer;
}  // namespace SUI

namespace IGSxGUI {
class MainView: public IGSxGUI::IMainView
{
 public:
    MainView();
    virtual ~MainView();
    virtual void show();
    typedef boost::function<void(SystemState::SystemStateEnum)> systemStateChanged;
    typedef boost::function<void(int, AlertInfo)> alertUpdated;
    virtual void onInitializeEnd();

 private:
    MainView(const MainView &);
    MainView& operator=(const MainView &);

    enum BUTTON
    {
        BTN_SYSTEM,
        BTN_DASHBOARD,
        BTN_ANALYSIS
    }NavigationButton;

    enum SYSTEM_SUBMENU_BUTTON
    {
        BTN_SYSTEM_INITIALIZATION,
        BTN_SYSTEM_STATEMANAGER,
        BTN_HARDWARE_RESET,
        BTN_MAINTENANCE,
        BTN_SYSTEM_SERVICE
    }SystemSubmenuButton;

    enum ANALYSIS_SUBMENU_BUTTON
    {
        BTN_DATAVIEW,
        BTN_ALERTS,
        BTN_ADVANCED_DIAGNOSTICS,
        BTN_EVENTLOG
    }AnalysisSubmenuButton;

    enum SCREENS
    {
        SCREEN_SYSTEM_INIT,
        SCREEN_STATE_MANAGER,
        SCREEN_HARDWARE_RESET,
        SCREEN_MAINTENANCE,
        SCREEN_SYSTEM_SERVICE,
        SCREEN_DASHBOARD,
        SCREEN_DATAVIEW,
        SCREEN_SAFETY_DIAGNOSIS,
        SCREEN_ADVANCED_DIAGNOSIS,
        SCREEN_EVENTLOG,
        SCREEN_ALERTS
    }Screens;

    SCREENS m_SystemActivePage, m_DashboardActivePage, m_AnalysisActivePage;

    void onSystemButtonPressed();
    void onSystemHoverOn();
    void onSystemHoverOff();
    void onDashboardButtonPressed();
    void onDashboardHoverOn();
    void onDashboardHoverOff();
    void onAnalysisButtonPressed();
    void onAnalysisHoverOn();
    void onAnalysisHoverOff();
    void onAlertHoverOn();
    void onAlertHoverOff();
    void onSubMenuSystemInitializationPressed();
    void onSubMenuSystemStateManagerPressed();
    void onSubMenuHardwareResetPressed();
    void onSubMenuMaintenancePressed();
    void onSubMenuServicePressed();
    void onSubMenuDataViewPressed();
    void onSubMenuAlertsPressed();
    void onSubMenuAdvancedDiagnosticsPressed();
    void onSubMenuEventLogPressed();
    void showSystemSubMenu(bool bShow) const;
    void showAnalysisSubMenu(bool bShow) const;
    void onAlertsButtonPressed();

    void onSystemStateChanged(const SystemState::SystemStateEnum& state);
    void onAlertUpdated(int alertCOunt, AlertInfo alertInfo);
    void onTimeout();
    void onAlertPopupClosed();
    void onPopupTimeout();
    void onAlertBlinkTimeout();
    void showPopup(const AlertInfo& alertInfo);
    void setAlertButtonNormalStyle();
    void setAlertButtonBlinkingStyle();
    void setMainNavigationButtonStyles(const BUTTON& button, const std::string& strImage, const std::string& strStyle) const;
    void setSystemSubMenuButtonStyle(const SYSTEM_SUBMENU_BUTTON& button) const;
    void setAnalysisSubMenuButtonStyle(const ANALYSIS_SUBMENU_BUTTON& button) const;
    void callInitialize();

    static const std::string MAINVIEW_LOAD_FILE;

    static const std::string NAVIGATION_BUTTON_SYSTEM;
    static const std::string NAVIGATION_BUTTON_DASHBOARD;
    static const std::string NAVIGATION_BUTTON_ANALYSIS;
    static const std::string NAVIGATION_BUTTON_ERRORALARM;

    static const std::string IMAGE_WHITE_SYSTEM;
    static const std::string IMAGE_WHITE_DASHBOARD;
    static const std::string IMAGE_WHITE_ANALYSIS;
    static const std::string IMAGE_WHITE_WARNING;
    static const std::string IMAGE_WHITE_CLOCK;
    static const std::string IMAGE_WHITE_INFO;
    static const std::string IMAGE_WHITE_CHECKCIRCLE;

    static const std::string IMAGE_BLUE_SYSTEM;
    static const std::string IMAGE_BLUE_DASHBOARD;
    static const std::string IMAGE_BLUE_ANALYSIS;

    static const std::string IMAGE_GREEN_CHECKCIRCLE;
    static const std::string IMAGE_RED_WARNING_16PX;
    static const std::string IMAGE_BLUE_ALARM;
    static const std::string IMAGE_BLUEDARK_ALARM;
    static const std::string IMAGE_RED_ALARM;

    static const std::string STRING_ALARM;
    static const std::string STRING_ERROR;
    static const std::string STRING_WARNING;

    static const std::string STRING_DATE_TIME;
    static const std::string STRING_ALERTS;

    static const std::string STRING_INITIALIZED;
    static const std::string STRING_TERMINATED;
    static const std::string STRING_PARTIALLY_INITIALIZED;
    static const std::string STRING_RECOVERY_REQUIRED;

    static const std::string STYLE_HOVER_ON;
    static const std::string STYLE_HOVER_OFF;
    static const std::string STYLE_ERROR_ALARM_HOVER_ON;
    static const std::string STYLE_ERROR_ALARM_HOVER_OFF;

    static const std::string STYLE_POPUP_RED;
    static const std::string STYLE_POPUP_YELLOW;
    static const std::string STYLE_BLACK;
    static const std::string STYLE_WHITE;
    static const std::string STYLE_TOPBAR_LABEL_WHITE;
    static const std::string STYLE_TOPBAR_BUTTON;
    static const std::string STYLE_TOPBAR_BUTTON_HOVER;

    static const std::string STRING_MAINVIEW_SHOWN_LOG;
    static const std::string STRING_SYSTEM_SUBMENU1_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU2_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU3_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU4_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU5_BUTTON;

    static const std::string STRING_ANALYSIS_SUBMENU1_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU2_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU3_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU4_BUTTON;

    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;

    static const std::string STYLE_MENU_BUTTON_CLICKED;
    static const std::string STYLE_MENU_BUTTON_NORMAL;

    static const int TIMER_INTERVAL;
    static const int POPUP_TIMER_INTERVAL;
    static const int POPUP_BLINKING_TIMER_INTERVAL;
    static const int ALERT_BLINKING_INTERVAL;
    static const int TIMER_RESTART_INTERVAL;
    static const int CONVERSION_BUFFER_SIZE;

    SUI::MainView *sui;
    IGSxGUI::MainPresenter *m_presenter;
    ISystem *m_iSystem;
    IDashboard *m_iDashboard;
    IAnalysis *m_iAnalysis;
    IGSxGUI::ISplashView *m_splashView;
    boost::shared_ptr<SUI::Timer> m_timer;
    boost::shared_ptr<SUI::Timer> m_popuptimer;
    boost::shared_ptr<SUI::Timer> m_alertBlinkingtimer;
    systemStateChanged m_systemChanged;
    alertUpdated m_alertUpdated;
    bool m_bInitializeEventLog;
    bool m_bIsAlertHoverOn;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMAINVIEW_HPP
