/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <string>
#include <vector>
#include <utility>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_TITLE = "lblTitle";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_NOBUTTON = "btnNo";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_YESBUTTON = "btnYes";
const std::string IGSxGUI::MachineconstantsView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_MESSAGE = "lblMessage";
const std::string IGSxGUI::MachineconstantsView::COLOR_LINEEDIT_CANCEL = "#8c8c8c";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::MachineconstantsView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const std::string IGSxGUI::MachineconstantsView::DIALOG_TITLE = "Cancel pending changes?";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETER_FOUND = "parameter found";
const std::string IGSxGUI::MachineconstantsView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_BLUEBG = "BlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETERS_FOUND = "parameters found";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_ORANGEBG = "OrangeBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PENDINGPARAMLABEL_STYLE = "pendingParameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_HOVERBLUEBG = "HoverBlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::DIALOG_MESSAGE = "All changed values will be discarded";
const std::string IGSxGUI::MachineconstantsView::CANCELPOPUP_LOAD_FILE = "IGSxGUIxMachineConstantPopup.xml";
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR_CLICKED = "#FFFFFF";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_CLICKED = "PendingParameterCancelClicked";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERED = "PendingParameterCancelHovered";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERLEFT = "PendingParameterCancelHoverLeft";

const int IGSxGUI::MachineconstantsView::DIALOG_X = 0;
const int IGSxGUI::MachineconstantsView::DIALOG_Y = 60;
const int IGSxGUI::MachineconstantsView::ROW_HEIGHT = 40;
const int IGSxGUI::MachineconstantsView::BUTTON_SIZE = 18;
const int IGSxGUI::MachineconstantsView::DIALOG_WIDTH = 1920;
const int IGSxGUI::MachineconstantsView::DIALOG_HEIGHT = 130;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS = 18;
const int IGSxGUI::MachineconstantsView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::MachineconstantsView::PENDINGPARAM_CLOSEBUTTON_SIZE = 16;
const std::string IGSxGUI::MachineconstantsView::STYLE_AWESOME_ICONCOLOR = "#4d4d4d";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::MachineconstantsView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::MachineconstantsView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_COLORORANGE = "#FF7F45";

namespace IGSxGUI
{

class BreadCrum
{
public:
    static const int CRUM_DISTANCE = 5;
    static const int CRUM_MARGIN = 17;
    static const int PIXELS_PER_CHARACTER = 11;
    static const int SLASH_WIDTH = 8;

public:
    BreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum, SUI::Button* btnPrevious) :
        m_lblSlash(lblSlash), m_btnBreadCrum(btnBreadCrum) , m_btnPrevious(btnPrevious)
    {
    }

    SUI::Button* getMainButton()
    {
        return m_btnBreadCrum;
    }

    void Reposition(std::string strCrum)
    {
        // hide the slash if the bread crum that follows is empty
        m_lblSlash->setVisible(!strCrum.empty());

        SUI::Rect rectSlash = m_lblSlash->getGeometry();
        rectSlash.setX(m_btnPrevious->getGeometry().getX() + m_btnPrevious->getGeometry().getWidth() + CRUM_DISTANCE);
        rectSlash.setWidth(SLASH_WIDTH);
        m_lblSlash->setGeometry(rectSlash);

        m_btnBreadCrum->setText(strCrum);
        SUI::Rect rectButton = m_btnBreadCrum->getGeometry();
        rectButton.setX(rectSlash.getX() + rectSlash.getWidth() + CRUM_DISTANCE);
        rectButton.setWidth((strCrum.length() * PIXELS_PER_CHARACTER) + CRUM_MARGIN);

        m_btnBreadCrum->setGeometry(rectButton);
    }

private:
    SUI::Label*  m_lblSlash;
    SUI::Button* m_btnBreadCrum;
    SUI::Button* m_btnPrevious;
};

class BreadCrumResizer
{
public:
    BreadCrumResizer(SUI::Button* btnStart) : m_btnStart(btnStart)
    {

    }

    void AddBreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum)
    {
        m_breadCrums.push_back(new BreadCrum(lblSlash, btnBreadCrum,
            m_breadCrums.size() == 0 ? m_btnStart : m_breadCrums[m_breadCrums.size()-1]->getMainButton()));
    }

    void RepositionAll(const std::vector<std::string>& breadCrumTitles)
    {
         m_btnStart->setText(breadCrumTitles[0]);
         SUI::Rect rectButton = m_btnStart->getGeometry();
         rectButton.setWidth((breadCrumTitles[0].length() * BreadCrum::PIXELS_PER_CHARACTER) + BreadCrum::CRUM_MARGIN);
         m_btnStart->setGeometry(rectButton);

         for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
             m_breadCrums[i]->Reposition(i < static_cast<int>(breadCrumTitles.size() - 1) ? breadCrumTitles[i + 1] : "");
         }
    }

    ~BreadCrumResizer()
    {
        for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
            delete m_breadCrums[i];
        }
    }

private:
    SUI::Button*            m_btnStart;
    std::vector<BreadCrum*> m_breadCrums;
};

} // namespace IGSxGUI

IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager):
    sui(new SUI::MachineconstantsView),
    m_selectedParameterRowNum(-1),
    m_selectedPendingParameterRowNum(-1),
    m_searchText(""),
    m_breadCrumResizer(NULL)
{
    m_pMachineconstantsManager = pMachineconstantsManager;
    m_dialog = SUI::UILoader::loadUI(CANCELPOPUP_LOAD_FILE.c_str());
}

IGSxGUI::MachineconstantsView::~MachineconstantsView()
{
    if (m_breadCrumResizer != NULL)
    {
        delete m_breadCrumResizer;
    }
}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(MACHINECONSTANTSVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    init();
    IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::init()
{
    breadCrumpButtonList.clear();
    breadCrumpButtonList.push_back(sui->btnBC1);
    breadCrumpButtonList.push_back(sui->btnBC2);
    breadCrumpButtonList.push_back(sui->btnBC3);
    breadCrumpButtonList.push_back(sui->btnBC4);
    breadCrumpButtonList.push_back(sui->btnBC5);
    breadCrumpButtonList.push_back(sui->btnBC6);

    m_breadCrumResizer = new IGSxGUI::BreadCrumResizer(sui->btnBC1);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash1, sui->btnBC2);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash2, sui->btnBC3);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash3, sui->btnBC4);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash4, sui->btnBC5);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash5, sui->btnBC6);

    sui->lblParameterNameTooltip->setVisible(false);
    sui->lblParameterValueTooltip->setVisible(false);
    sui->lblAllCategories->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->lblBackImage, IGSxGUI::AwesomeIcon::AI_fa_angle_left, SUI::ColorEnum::White, 30);
    sui->lblBackImage->setVisible(false);
    sui->lblBack->setText("BACK");
    sui->lblBack->setVisible(false);
    sui->txaPendingParamSaveChangeReason->clearText();
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);

    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);

    IGSxGUI::Util::setAwesome(sui->lblSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->btnPendingParamSaveNameLnEditCancel, IGSxGUI::AwesomeIcon::AI_fa_close, COLOR_LINEEDIT_CANCEL, 15);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE); 

    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);

    sui->tawMCPendingParam->showGrid(false);
    sui->tawMCPendingParam->setRowVisible(0, false);
    sui->tawMCPendingParam->setListViewMode(false);

    setHandlers();

    showSaveCancelButtons(false);
    showFinalSaveScreenItems(false);
    showSearchEntriesParameter(false);
    showNoPendingParameterScreen(true);

    initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
    sui->tawParameterTree->showGrid(false);
    onParameterTreeItemPressed(0);
}

void IGSxGUI::MachineconstantsView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::MachineconstantsView::setHandlers()
{
    sui->btnCancel->clicked = boost::bind(&MachineconstantsView::onCancelButtonPressed, this);
    sui->btnHistory->hoverLeft = boost::bind(&MachineconstantsView::onHistoryHoverLeft, this);
    sui->btnSearchClear->clicked = boost::bind(&MachineconstantsView::onSearchClearPressed, this);
    sui->uctSaveButton->clicked = boost::bind(&MachineconstantsView::onUCTSaveButtonClicked, this);
    sui->uctSaveButton->pressed = boost::bind(&MachineconstantsView::onUCTSaveButtonPressed, this);
    sui->btnHistory->hoverEntered = boost::bind(&MachineconstantsView::onHistoryHoverEntered, this);
    sui->btnHistory->clicked = boost::bind(&MachineconstantsView::onHistoryPressed,this);

    sui->uctCloseHistory->clicked = boost::bind(&MachineconstantsView::onUCTCloseHistoryClicked, this);
    sui->uctCloseHistory->hoverEntered = boost::bind(&MachineconstantsView::onUCTCloseHistoryHoverOn, this);
    sui->uctCloseHistory->hoverLeft = boost::bind(&MachineconstantsView::onUCTCloseHistoryHoverOff, this);
    sui->uctCloseHistory->pressed = boost::bind(&MachineconstantsView::onUCTCloseHistoryPressed, this);
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->btnSearchClear->hoverLeft = boost::bind(&MachineconstantsView::onSearchClearHoverLeft, this);
    sui->uctSaveButton->hoverLeft = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOff, this);
    sui->uctSaveButton->hoverEntered = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOn, this);
    sui->btnParameterName->hoverLeft = boost::bind(&MachineconstantsView::onParameterNameHoverLeft, this);
    sui->btnSearchParameter->hoverLeft = boost::bind(&MachineconstantsView::onSearchButtonHoverLeft, this);
    sui->btnParameterValue->hoverLeft = boost::bind(&MachineconstantsView::onParameterValueHoverLeft, this);
    sui->btnSearchClear->hoverEntered = boost::bind(&MachineconstantsView::onSearchClearHoverEntered, this);
    sui->btnParameterName->hoverEntered = boost::bind(&MachineconstantsView::onParameterNameHoverEntered, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->btnPendingParamCancelSave->clicked = boost::bind(&MachineconstantsView::onPendingParamCancelSave, this);
    sui->btnSearchParameter->hoverEntered = boost::bind(&MachineconstantsView::onSearchButtonHoverEntered, this);
    sui->btnParameterValue->hoverEntered = boost::bind(&MachineconstantsView::onParameterValueHoverEntered, this);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->uctPendingParamFinalSave->clicked = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveClicked, this);
    sui->btnPendingParameterName->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterNameHoverLeft, this);
    sui->lnePendingParamSaveName->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveTxtChanged, this, _1);
    sui->btnPendingParameterValue->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterValueHoverLeft, this);
    sui->uctPendingParamFinalSave->hoverLeft = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverLeft, this);
    sui->btnPendingParameterName->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterNameHoverEntered, this);
    sui->btnPendingParameterValue->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterValueHoverEntered, this);
    sui->uctPendingParamFinalSave->hoverEntered = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverEntered, this);
    sui->btnPendingParamSaveNameLnEditCancel->clicked = boost::bind(&MachineconstantsView::PendingParamSaveNameLnEditCancel, this);
    sui->txaPendingParamSaveChangeReason->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveChangeReasonTxtChanged, this, _1);
    sui->tawParameterTree->rowClicked = boost::bind(&MachineconstantsView::onParameterTreeItemPressed, this, _1);
    sui->lblBack->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    m_parameterview.registerForValueChanged(boost::bind(&MachineconstantsView::onParameterValueChanged, this, _1, _2));
    sui->btnBC1->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump1HoverEntered, this);
    sui->btnBC2->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump2HoverEntered, this);
    sui->btnBC3->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump3HoverEntered, this);
    sui->btnBC4->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump4HoverEntered, this);
    sui->btnBC5->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump5HoverEntered, this);
    sui->btnBC6->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump6HoverEntered, this);
    sui->btnBC1->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump1HoverLeft, this);
    sui->btnBC2->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump2HoverLeft, this);
    sui->btnBC3->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump3HoverLeft, this);
    sui->btnBC4->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump4HoverLeft, this);
    sui->btnBC5->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump5HoverLeft, this);
    sui->btnBC6->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump6HoverLeft, this);
    sui->btnBC1->clicked = boost::bind(&MachineconstantsView::onBreadCrump1Clicked, this);
    sui->btnBC2->clicked = boost::bind(&MachineconstantsView::onBreadCrump2Clicked, this);
    sui->btnBC3->clicked = boost::bind(&MachineconstantsView::onBreadCrump3Clicked, this);
    sui->btnBC4->clicked = boost::bind(&MachineconstantsView::onBreadCrump4Clicked, this);
    sui->btnBC5->clicked = boost::bind(&MachineconstantsView::onBreadCrump5Clicked, this);
    sui->btnBC6->clicked = boost::bind(&MachineconstantsView::onBreadCrump6Clicked, this);
}

void IGSxGUI::MachineconstantsView::onCancelYesPressed()
{
    int rowcount = sui->tawMCPendingParam->rowCount();

    removePendingParamTableRows(1, rowcount-1);

    showSaveCancelButtons(false);
    showNoPendingParameterScreen(true);

    moveSaveCancelButtons(UP, (rowcount-1)*ROW_HEIGHT);

    m_dialog->close();
}

void IGSxGUI::MachineconstantsView::updateParameterTable()
{
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);

    sui->scbParametersTable->setValue(0);
    sui->lneSearchParameterText->clearText();
    std::vector<ParameterData*> collection = m_pMachineconstantsManager->getParameterData();
    std::vector<ParameterData*>::iterator it = collection.begin();
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row, ++it) {
        IGSxGUI::Util::setRowHeight(sui->tawParameters, row, ROW_HEIGHT);

        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        widget->setEnabled(true);
        IGSxGUI::Util::setTextToParameterUserControl(widget, 0, (*it)->getName());
        IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>((*it)->getCurrentValue()));
        if ((*it)->isReadOnly()) {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        } else {
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
        }
        setUCTHandlers(widget, row, (*it)->isReadOnly());
    }
}

void IGSxGUI::MachineconstantsView::onCancelButtonPressed()
{
    createPopup(DIALOG_TITLE, DIALOG_MESSAGE);
    m_dialog->show();
}

void IGSxGUI::MachineconstantsView::showSaveCancelButtons(bool bShow)
{
    sui->btnCancel->setVisible(bShow);
    sui->uctSaveButton->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showPendingParamWidgets(bool bShow)
{
    sui->tawMCPendingParam->setVisible(bShow);
    sui->btnPendingParameterName->setVisible(bShow);
    sui->btnPendingParameterValue->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenItems(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamSaveNameLnEdit->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(bShow);
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showSearchEntriesParameter(bool bShow)
{
    sui->btnSearchClear->setVisible(bShow);
    sui->lblEntriesFound->setVisible(bShow);
    sui->btnSearchParameter->setVisible(!bShow);
}

void IGSxGUI::MachineconstantsView::showNoPendingParameterScreen(bool bShow)
{
    sui->btnNoPendingParameters->setVisible(bShow);

    sui->tawMCPendingParam->setVisible(!bShow);
    sui->btnPendingParameterName->setVisible(!bShow);
    sui->btnPendingParameterValue->setVisible(!bShow);
}

void IGSxGUI::MachineconstantsView::createPopup(const std::string& title, const std::string& message)
{
    m_dialog->setWindowTitle(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_TITLE)->setText(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_MESSAGE)->setText(message);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_YESBUTTON)->clicked = boost::bind(&MachineconstantsView::onCancelYesPressed, this);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_NOBUTTON)->clicked = boost::bind(&SUI::Dialog::close, m_dialog);
    m_dialog->setModal(true);

    IGSxGUI::Util::setParent(m_dialog, sui->btnSearchClear);
    IGSxGUI::Util::disableScrollbars(m_dialog);
    IGSxGUI::Util::setWindowFrame(m_dialog, false);

    IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
}

void IGSxGUI::MachineconstantsView::setUCTHandlers(SUI::Widget *widget, int row, bool readonly)
{
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    if (!readonly) {
        usercontrol->clicked = boost::bind(&MachineconstantsView::onParameterRowPressed, this, row);
        usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onParameterUCTHoverEntered, this, row);
        usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onParameterUCTHoverLeft, this, row);
    } else {
        usercontrol->clicked = NULL;
        usercontrol->hoverEntered = NULL;
        usercontrol->hoverLeft = NULL;
    }
}

void IGSxGUI::MachineconstantsView::populateData(std::vector<ParameterData*>::iterator it, int row)
{
    IGSxGUI::Util::setRowHeight(sui->tawParameters, row, ROW_HEIGHT);

    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, (*it)->getDisplayName());
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>((*it)->getCurrentValue()));
    if ((*it)->isReadOnly()) {
        setUCTHandlers(widget, row, true);
        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
    } else {
        setUCTHandlers(widget, row, false);
    }
}

void IGSxGUI::MachineconstantsView::initializeTableRows(int rows, std::vector<ParameterData*> collection)
{
    if (rows <= 0) {
        sui->tawParameters->setVisible(false);
    } else {
        sui->tawParameters->showGrid(false);
        int noofrows = rows;
        if (rows > MAX_VISIBLE_ROWS) {
            noofrows = MAX_VISIBLE_ROWS;
            sui->scbParametersTable->setVisible(true);
            sui->scbParametersTable->setMinValue(0);
            sui->scbParametersTable->setMaxValue(static_cast<int>(collection.size()));
        } else {
            sui->scbParametersTable->setVisible(false);
        }
        sui->tawParameters->removeRows(1, (sui->tawParameters->rowCount() - 1));
        for (int i = 0; i < (noofrows - 1); ++i) {
            sui->tawParameters->appendRow();
        }
    }
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = MAX_VISIBLE_ROWS;
    }
    setData(0, rows, collection);
}

void IGSxGUI::MachineconstantsView::setData(int value, int rows, std::vector<ParameterData*> collection)
{
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    std::vector<ParameterData*>::iterator it = collection.end();
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
    }
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonClicked()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);

    for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
        SUI::Widget *widget = dynamic_cast<SUI::Widget*>(sui->tawParameters->getWidgetItem(row, 0));

        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);

        usercontrol->clicked = NULL;
        usercontrol->hoverLeft = NULL;
        usercontrol->hoverEntered = NULL;
    }

    sui->scbParametersTable->valueChanged = NULL;
    sui->lneSearchParameterText->textChanged = NULL;
    sui->lneSearchParameterText->editingFinished = NULL;

    if (sui->lnePendingParamSaveName->getText().empty()) {
        sui->lblPendingParamSaveNameLnEdit->setVisible(true);
    }

    if (sui->txaPendingParamSaveChangeReason->getText().empty()) {
        sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(true);
    }

    sui->lblPendingParamSaveName->setFocus();

    showSaveCancelButtons(false);
    showPendingParamWidgets(false);
    showFinalSaveScreenPendingParams(true);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenPendingParams(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonPressed()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOn()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOff()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::setTableRows(int value, std::vector<ParameterData*> collection)
{
    int rows = static_cast<int>(collection.size());
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = std::min(MAX_VISIBLE_ROWS, (rows-value));
    }
    setData(value, rows, collection);
}

void IGSxGUI::MachineconstantsView::onParameterNameHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, true);
    sui->lblParameterNameTooltip->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onParameterNameHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, false);
    sui->lblParameterNameTooltip->setVisible(false);
}

void IGSxGUI::MachineconstantsView::onParameterValueHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, true);
    sui->lblParameterValueTooltip->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onParameterValueHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, false);
    sui->lblParameterValueTooltip->setVisible(false);
}

void IGSxGUI::MachineconstantsView::onParameterValueChanged(const std::string& name, const std::string& value)
{
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    if (parameterData != NULL) {
        if (m_pMachineconstantsManager->getParameterCount() > MAX_VISIBLE_ROWS) {
            setTableRows(sui->scbParametersTable->getValue(), m_pMachineconstantsManager->getParameterData());
        } else {
            setTableRows(0, m_pMachineconstantsManager->getParameterData());
        }
        m_parameterview.close();
        UpdatePendingParamTable(name, value);
    }
    showSaveCancelButtons(true);
    showNoPendingParameterScreen(false);
}

void IGSxGUI::MachineconstantsView::onParameterRowPressed(int row)
{
    m_selectedParameterRowNum = row;

    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
    IGSxGUI::Util::processEvents();

    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    boost::trim(name);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    boost::trim(value);

    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);

    if (parameterData != NULL) {
        m_parameterview.setParameterName(parameterData->getName());
        m_parameterview.setParameterValue(boost::lexical_cast<std::string>(parameterData->getCurrentValue()));
        m_parameterview.setParameterDefaultValue(boost::lexical_cast<std::string>(parameterData->getDefaultValue()));
        m_parameterview.setParent(sui->lneSearchParameterText);  // any widget can be passed
        m_parameterview.show();
    }

    m_selectedParameterRowNum = -1;

    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    if (parameterData->isUpdated()) {
        IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
    }
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverEntered(int row)
{
    int value = 0;

    if (m_pMachineconstantsManager->getParameterCount()> MAX_VISIBLE_ROWS) {
        value = sui->scbParametersTable->getValue();
    }

    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(value, m_pMachineconstantsManager->getParameterData());
    }  else {
        setTableRows(value, m_matchedparameters);
    }

    IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawParameters->getWidgetItem(row, 0));
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverLeft(int row)
{
    int value = 0;

    if (m_pMachineconstantsManager->getParameterCount() > MAX_VISIBLE_ROWS) {
        value = sui->scbParametersTable->getValue();
    }

    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(value, m_pMachineconstantsManager->getParameterData());
    }  else {
        setTableRows(value, m_matchedparameters);
    }

    // When popup window shows up after clicking the table row, focus goes out of the clicked row and onParameterUCTHoverLeft event gets generated
    // which makes this method called and clicked row becomes un-highlighted. Do not apply HoverOffStyle to the selected row, so that the
    // selected row will be remain selected even after popup window shows up.
    if (m_selectedParameterRowNum != row) {
        IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawParameters->getWidgetItem(row, 0));
    }
}

void IGSxGUI::MachineconstantsView::onHistoryHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, true);
}

void IGSxGUI::MachineconstantsView::onHistoryHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, false);
}

void IGSxGUI::MachineconstantsView::onHistoryPressed()
{
   sui->gbxHistory->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onUCTCloseHistoryClicked()
{
    sui->lblCloseHistory->setStyleSheetClass(STYLE_ASML_ORANGELABEL);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_ASML_COLORORANGE, AWESOME_CLOSE_SIZE);
    sui->lblCloseHistory->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    sui->lblCloseHistory->setBGColor(SUI::ColorEnum::White);
    sui->lblCloseImage2->setBGColor(SUI::ColorEnum::White);
    sui->gbxHistory->setVisible(false);
}

void IGSxGUI::MachineconstantsView::onUCTCloseHistoryHoverOn()
{
    sui->lblCloseHistory->setStyleSheetClass(STYLE_HOVERON);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::MachineconstantsView::onUCTCloseHistoryHoverOff()
{
    sui->lblCloseHistory->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
}
void IGSxGUI::MachineconstantsView::onUCTCloseHistoryPressed()
{
  std::string color = "#FF7F45";
  IGSxGUI::Util::setAwesome(sui->lblCloseImage2, IGSxGUI::AwesomeIcon::AI_fa_times, color, AWESOME_CLOSE_SIZE);
  std::string styleClass = "OrangeLabel";
  sui->lblCloseHistory->setStyleSheetClass(styleClass);
}

void IGSxGUI::MachineconstantsView::onPendingParameterNameHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnPendingParameterName, true);
    sui->lblPendingParameterNameTooltip->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onPendingParameterNameHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnPendingParameterName, false);
    sui->lblPendingParameterNameTooltip->setVisible(false);
}

void IGSxGUI::MachineconstantsView::onPendingParameterValueHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnPendingParameterValue, true);
    sui->lblPendingParameterValueTooltip->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onPendingParameterValueHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnPendingParameterValue, false);
    sui->lblPendingParameterValueTooltip->setVisible(false);
}

void IGSxGUI::MachineconstantsView::onSearchButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_BLUE_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowClosePressed(int rowNumber)
{
    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    tabwidget->setStyleSheetClass(PENDINGPARAMCANCEL_CLICKED);

    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    boost::trim(name);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    boost::trim(value);

    IGSxGUI::Util::processEvents();

    if (sui->tawMCPendingParam->rowCount() == 1)
    {
        sui->tawMCPendingParam->setRowVisible(0, false);

        showSaveCancelButtons(false);
        showNoPendingParameterScreen(true);
        IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
    } else {
        sui->tawMCPendingParam->removeRow(rowNumber);
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            pendingParamApplyRowBehavior(row);
        }
        moveSaveCancelButtons(UP, ROW_HEIGHT);
    }
}

void IGSxGUI::MachineconstantsView::updateParameterTableValue(const std::string &pendingParametername, const std::string &newValue)
{
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(pendingParametername);
    if (parameterData != NULL) {
        parameterData->changeValue(boost::lexical_cast<int>(newValue));
        int rowCount = sui->tawParameters->rowCount();
        for (int row = 0; row < rowCount; row++ ) {
            SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            boost::trim(paramname);
            if (pendingParametername == paramname) {
                IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>(parameterData->getCurrentValue()));
                IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                break;
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::onSearchButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onSearchClearHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_BLUE_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onSearchClearHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onSearchTextEdited(const std::string &text)
{
    m_searchText = text;
    refreshParameterList();
}

void IGSxGUI::MachineconstantsView::refreshParameterList()
{
    if (m_searchText.empty()) {
        showSearchEntriesParameter(false);

        initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
        sui->scbParametersTable->setValue(0);
        sui->tawParameters->setVisible(true);
    } else {
        showSearchEntriesParameter(true);

        IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
        int entriesfound = m_pMachineconstantsManager->searchForParameters(m_searchText, &m_matchedparameters);
        initializeTableRows(entriesfound, m_matchedparameters);
        sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND);
        if (entriesfound <= 0) {
            sui->tawParameters->setVisible(false);
        } else {
            sui->tawParameters->setVisible(true);
            sui->scbParametersTable->setValue(0);
        }
    }
}

void IGSxGUI::MachineconstantsView::onValueChanged()
{
     // set the appropriate style for parameter table rows when scrollbar of parameter table scrolled
     for (int row = 0; row < sui->tawParameters->rowCount(); row++ ) {
         SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
         IGSxGUI::Util::setParameterUCTNormalStyle(widget);
         std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
         boost::trim(name);
         ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
         if (parameterData->isUpdated()) {
             IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
         }
     }

    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(sui->scbParametersTable->getValue(), m_pMachineconstantsManager->getParameterData());
    } else {
        setTableRows(sui->scbParametersTable->getValue(), m_matchedparameters);
    }
}

void IGSxGUI::MachineconstantsView::onSearchTextEditFinished()
{
    sui->btnSearchClear->setVisible(true);
}

void IGSxGUI::MachineconstantsView::onSearchClearPressed()
{
    showSearchEntriesParameter(false);
    sui->lneSearchParameterText->clearText();
}

void IGSxGUI::MachineconstantsView::UpdatePendingParamTable(const std::string &name, const std::string &value)
{
    int rowNumber;
    if ((sui->tawMCPendingParam->rowCount() == 1) && (!sui->tawMCPendingParam->isRowVisible(0))) {
        rowNumber = 0;
        sui->tawMCPendingParam->setRowVisible(rowNumber, true);

        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget,0);

        // After pending parameters have been saved or cancelled or removed, adding a row only requires to update with new name and value
        // since we are not actually deleting the last row while performing saving or cancel or removing last row in pending parameters.
        if(!paramname.empty()) {
            IGSxGUI::Util::setTextToParameterUserControl(widget, 0, name);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>(value));
            return;
        }
     } else {
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            boost::trim(paramname);
            if (paramname == name) {
                IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>(value));
                return;
            }
        }
        sui->tawMCPendingParam->appendRow();
        rowNumber = sui->tawMCPendingParam->rowCount() - 1;
        moveSaveCancelButtons(DOWN, ROW_HEIGHT);
    }
    configurePendingParamTableRow(rowNumber, name, value);
}

void IGSxGUI::MachineconstantsView::configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value)
{
    IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT);
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, name);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>(value));

    pendingParamApplyRowBehavior(rowNumber);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveClicked()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);

    int rowCount = sui->tawMCPendingParam->rowCount();
  for (int row = 0; row < rowCount; row++ )
  {
      SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
      std::string pendingParametername = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
      boost::trim(pendingParametername);
      std::string pendingParametervalue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
      boost::trim(pendingParametervalue);
      updateParameterTableValue(pendingParametername, pendingParametervalue);
  }


    sui->lnePendingParamSaveName->clearText();
    sui->txaPendingParamSaveChangeReason->clearText();
    showSaveCancelButtons(false);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(true);

    removePendingParamTableRows(1, rowCount-1);
    moveSaveCancelButtons(UP, (rowCount-1) * ROW_HEIGHT);

    updateParameterTable();
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverEntered()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverLeft()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveChangeReasonTxtChanged(const std::string &text)
{
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(text.empty());
}

void IGSxGUI::MachineconstantsView::PendingParamSaveTxtChanged(const std::string &text)
{
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(!text.empty());
    sui->lblPendingParamSaveNameLnEdit->setVisible(text.empty());
}

void IGSxGUI::MachineconstantsView::removePendingParamTableRows(int pos, int count)
{
    sui->tawMCPendingParam->removeRows(pos, count);
    sui->tawMCPendingParam->setRowVisible(0, false);
}

void IGSxGUI::MachineconstantsView::moveSaveCancelButtons(const moveDirection &dir, int pixels)
{
    int xCancel = sui->btnCancel->getGeometry().getX();
    int yCancel = sui->btnCancel->getGeometry().getY();
    int widthCancel = sui->btnCancel->getGeometry().getWidth();
    int heightCancel = sui->btnCancel->getGeometry().getHeight();

    int xSave = sui->uctSaveButton->getGeometry().getX();
    int ySave = sui->uctSaveButton->getGeometry().getY();
    int widthSave = sui->uctSaveButton->getGeometry().getWidth();
    int heightSave = sui->uctSaveButton->getGeometry().getHeight();

    switch (dir)
    {
        case UP:
        {
            yCancel -= pixels;
            ySave -= pixels;
            break;
        }
        case DOWN:
        {
            yCancel += pixels;
            ySave += pixels;
            break;
        }
        default:
            break;
    }
    sui->btnCancel->setGeometry(xCancel, yCancel, widthCancel, heightCancel);
    sui->uctSaveButton->setGeometry(xSave, ySave, widthSave, heightSave);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveNameLnEditCancel()
{
    sui->lnePendingParamSaveName->clearText();
    sui->lnePendingParamSaveName->setFocus();
}

void IGSxGUI::MachineconstantsView::onPendingParamCancelSave()
{
    showSaveCancelButtons(true);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(false);

    updateParameterTable();
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverEntered(int row)
{
    IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawMCPendingParam->getWidgetItem(row,0));
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverLeft(int row)
{
    // When popup window shows up after clicking the pending parameter table row, focus goes out of the clicked row
    // and onPendingParameterHoverLeft event gets generated which makes this method called and clicked row becomes
    // un-highlighted. Do not apply HoverOffStyle to the selected row, so that the selected row will be remain selected
    // even after popup window shows up.
    if (m_selectedPendingParameterRowNum != row) {
        IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawMCPendingParam->getWidgetItem(row,0));
    }
}

void IGSxGUI::MachineconstantsView::onPendingParameterClicked(int row)
{
    m_selectedPendingParameterRowNum = row;

    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
    IGSxGUI::Util::processEvents();
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    boost::trim(name);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    boost::trim(value);

    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    if (parameterData != NULL) {
        m_parameterview.setParameterName(name);
        m_parameterview.setParameterValue(boost::lexical_cast<std::string>(value));
        m_parameterview.setParameterDefaultValue(boost::lexical_cast<std::string>(parameterData->getDefaultValue()));
        m_parameterview.setParent(sui->btnHistory);  // any widget can be passed
        m_parameterview.show();
    }

    m_selectedPendingParameterRowNum = -1;
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
}

void IGSxGUI::MachineconstantsView::pendingParamApplyRowBehavior(int row)
{
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&MachineconstantsView::onPendingParameterClicked, this, row);
    usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterHoverEntered, this, row);
    usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterHoverLeft, this, row);

    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(row, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
    SUI::Button* button = dynamic_cast<SUI::Button*>(tabwidget);
    button->clicked = boost::bind(&MachineconstantsView::onPendingParameterRowClosePressed, this, row);
    button->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHovered, this, row);
    button->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHoverLeft, this, row);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHovered(int row) {
    sui->tawMCPendingParam->getWidgetItem(row,1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERED);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHoverLeft(int row) {
    sui->tawMCPendingParam->getWidgetItem(row,1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERLEFT);
}

void IGSxGUI::MachineconstantsView::onBackPressed()
{
    m_pMachineconstantsManager->navigateBack();
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
}


void IGSxGUI::MachineconstantsView::onParameterTreeItemPressed(int rowNumber)
{
    std::string text = sui->tawParameterTree->getItemText(rowNumber, 0);
    m_pMachineconstantsManager->navigateToChild(text);
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1Clicked()
{
    onBreadCrumpClicked(0);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2Clicked()
{
    onBreadCrumpClicked(1);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3Clicked()
{
    onBreadCrumpClicked(2);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4Clicked()
{
    onBreadCrumpClicked(3);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5Clicked()
{
    onBreadCrumpClicked(4);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6Clicked()
{
    onBreadCrumpClicked(5);
}

void IGSxGUI::MachineconstantsView::onBreadCrumpClicked(int index)
{
    if (m_pMachineconstantsManager->getCurrentNodeName() != breadCrumpButtonList[index]->getText()) {
        if ( index == 0) {
            m_pMachineconstantsManager->navigateToBreadCrum("Parameters");
        } else {
            m_pMachineconstantsManager->navigateToBreadCrum(breadCrumpButtonList[index]->getText());
        }
        refreshTreeViewAndBreadCrums();
        refreshParameterList();
    }
}

void IGSxGUI::MachineconstantsView::refreshTreeViewAndBreadCrums()
{
    const std::vector<std::string>& breadCrumList =  m_pMachineconstantsManager->getBreadCrumTitles();
    if (breadCrumList.size() == 1) {
        sui->lblAllCategories->setVisible(true);
        sui->lblBackImage->setVisible(false);
        sui->lblBack->setVisible(false);
    } else {
        sui->lblAllCategories->setVisible(false);
        sui->lblBackImage->setVisible(true);
        sui->lblBack->setVisible(true);
    }
    this->m_breadCrumResizer->RepositionAll(breadCrumList);

    std::vector<std::string> childNodeTitles;
    m_pMachineconstantsManager->getChildNodeTitles(&childNodeTitles);
    int childNodeCount = childNodeTitles.size();
    if (childNodeCount == 0) {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        sui->tawParameterTree->setItemText(0, 0, "No Subcategories");
    } else {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        for (int row = 0 ; row < childNodeCount - 1; ++row) {
            sui->tawParameterTree->appendRow();
        }
        for (int row = 0 ; row < sui->tawParameterTree->rowCount(); ++row) {
            sui->tawParameterTree->setItemText(row, 0, formatSubsystemName(childNodeTitles[row]));
        }
    }
    IGSxGUI::Util::clearSelection(sui->tawParameterTree);
}


std::string IGSxGUI::MachineconstantsView::formatSubsystemName(const std::string& subsystemname)
{
    std::string strMultiLine = subsystemname;
     std::vector<int> vec;
    if (subsystemname.length() > 27)
    {
        int i = 0;
        while ( (i < subsystemname.length()) && !::isupper(subsystemname[i]))
          {

          }

    }
    return strMultiLine;
}
