/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_ParameterpopupView.hpp
| Author       : Raja
| Description  : Header file for Moc Parameterpopup view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.hpp
| ! \brief       Header file for Moc Parameterpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
#define IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
//----------------------------------------------------------------------------|
//                          Forward Declarations                              |
//----------------------------------------------------------------------------|
namespace IGSxGUI {
        class ParameterpopupView;
} //namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class LineEdit;
class Button;
class Label;

class ParameterpopupView
{
private:
        ParameterpopupView();

    void setupSUI(const char *xmlFileName);
    void setupSUIContainer(const char *xmlFileName, SUI::Container *container);
    void loadObjects(SUI::ObjectList *objectList);

    SUI::Dialog *dialog;
    SUI::Button *btnPopCancel;
    SUI::Button *btnClose;
    SUI::Button *btnPopReset;
    SUI::Button *btnPopUpdate;
    SUI::Label *lblDefaultValue;
    SUI::Label *lblDefaultValueNumber;
    SUI::Label *lblParameterName;
    SUI::Label *lblValue;
    SUI::LineEdit *lneValue;


    friend class ::IGSxGUI::ParameterpopupView;
};
} //namespace SUI
#endif // IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
