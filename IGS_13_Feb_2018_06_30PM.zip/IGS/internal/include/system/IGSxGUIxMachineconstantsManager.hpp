/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.hpp
| Author       : Raja
| Description  : Header file for Machineconstants Manager
|
| ! \file        IGSxGUIxMachineconstantsManager.hpp
| ! \brief       Header file for Machinecontants Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSMANAGER_HPP
#define IGSXGUIXMACHINECONSTANTSMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/



namespace IGSxGUI {


class ParameterData
{
private:
    std::string m_name;
    int m_defaultValue;
    int m_currentValue;
    int m_previousValue;
    bool m_readOnly;
    bool m_updated;
    std::vector<int> m_componentIndexes;

public:
    static int treeLevel;

public:
    ParameterData(const std::string& name, int m_currentValue, int defaultValue, bool readOnly);
    const std::string& getName() const;
    std::string getDisplayName() const;
    std::string getComponent(int index) const;
    int getComponentCount() const;
    bool isReadOnly() const;

    int getCurrentValue() const;
    int getDefaultValue() const;
    bool isUpdated() const;
    void changeValue(int newValue);
    void revertValue();
    ParameterData* getPtr();
};

struct find_parameter {
    explicit find_parameter(const std::string& text):m_text(text)
    {
    }

    bool operator()(const ParameterData& data)
    {
        return ( data.getName() == m_text);
    }

    std::string m_text;
};

class Node {

public:
    Node(std::string name, int level, Node* parentNode);
    ~Node();

    const std::string getName() const;
    Node* getParentNode();
    Node* findChildNode(const std::string& name);
    Node* addChildNode(const std::string& name);
    void addParameter(IGSxGUI::ParameterData* parameter);
    std::vector<IGSxGUI::ParameterData*>& getParameters();
    void getChildNodeTitles(std::vector<std::string>* targetList );

private:
    std::string m_name;
    int m_level;
    Node* m_parentNode;
    std::vector<Node*> m_childNodes;
    std::vector<IGSxGUI::ParameterData*> m_parameters;
};

class MachineconstantsManager
{
 public:
    MachineconstantsManager();
    virtual ~MachineconstantsManager();

    void initialize();
    int getParameterCount();
    ParameterData* findParameter(const std::string& name);
    std::vector<ParameterData*> getParameterData();
    int searchForParameters(const std::string &textToSearch, std::vector<ParameterData*>*  matchedparameters);
    void saveUpdatedParameters(const std::string& userId, const std::string& reason);
    void cancelUpdatedParameters();

    void getChildNodeTitles(std::vector<std::string>* targetList);
    void navigateToChild(const std::string& childNodeTitle);
    void navigateBack();
    void navigateToBreadCrum(const std::string& breadCrumTitle);
    const std::vector<std::string>& getBreadCrumTitles();
    std::string getCurrentNodeName();


 private:
    MachineconstantsManager(MachineconstantsManager const &);
    MachineconstantsManager& operator=(MachineconstantsManager const &);

    void createTableData();
    void registerNodes(ParameterData* parameter);

    // data
    std::vector<ParameterData> m_tabledata;

    // bread crum path
    Node* m_rootNode;
    Node* m_currentNode;
    std::vector<std::string> m_breadCrumPath;

    // constants
    static const int TOTAL_PARAMETERS_COUNT;
    static const int PARAMETER_DEFAULT_VALUE;
    static const int PARAMETER_CURRENT_VALUE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSMANAGER_HPP
