/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCTRL_impl.cpp
| Author       : Arjan Tekeenburg
| Description  : Stub impementation of IGSxCTRL interface
|
| ! \file        IGSxCTRL_impl.cpp
| ! \brief       Stub impementation of IGSxCTRL interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxCTRL_impl.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxCTRL::Control *IGSxCTRL::CTRL_Stub::getInstance()
{
    static CTRL_Stub _instance;
    return &_instance;
}

IGSxCTRL::Control* IGSxCTRL::Control::instance = IGSxCTRL::CTRL_Stub::getInstance();

IGSxCTRL::CTRL_Stub::CTRL_Stub():
    m_who(Who::NONE)
{

}

bool IGSxCTRL::CTRL_Stub::requestControl()
{
    if (m_who == Who::NONE || m_who == Who::GUI)
    {
        setWhoIsInControl(Who::GUI);
        return true;
    }
    return false;
}

void IGSxCTRL::CTRL_Stub::releaseControl()
{
    m_who = Who::NONE;
}

bool IGSxCTRL::CTRL_Stub::canIGetControl()
{
    if (m_who == Who::NONE || m_who == Who::GUI)
    {
        return true;
    }
    return false;
}

IGSxCTRL::Who::WhoEnum  IGSxCTRL::CTRL_Stub::whoIsInControl()
{
    return m_who;
}

void IGSxCTRL::CTRL_Stub::subscribeToControlChanged(const ControlChangedCallback &cb)
{
    m_controlChangedCB = cb;
}

void IGSxCTRL::CTRL_Stub::unsubscribeToControlChanged()
{
    m_controlChangedCB = NULL;
}

void IGSxCTRL::CTRL_Stub::setWhoIsInControl(Who::WhoEnum who)
{
    m_who = who;

    if (m_controlChangedCB != NULL)
    {
        m_controlChangedCB(m_who);
    }
}
