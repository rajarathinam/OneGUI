/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashPresenter.cpp
| Author       : Venugopal S
| Description  : Implementation of Splash Presenter
|
| ! \file        IGSxGUIxSplashPresenter.cpp
| ! \brief       Implementation of S Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxCNF.hpp"
#include "IGSxGUIxSplashPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::SplashPresenter::SplashPresenter(IGSxGUI::ISplashView* view) : m_view(view)
{
}
IGSxGUI::SplashPresenter::~SplashPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::string IGSxGUI::SplashPresenter::getMachineId() const
{
    return IGSxCNF::Configuration::getInstance()->getMachineId();
}

std::string IGSxGUI::SplashPresenter::getReleaseId() const
{
    return IGSxCNF::Configuration::getInstance()->getReleaseId();
}


