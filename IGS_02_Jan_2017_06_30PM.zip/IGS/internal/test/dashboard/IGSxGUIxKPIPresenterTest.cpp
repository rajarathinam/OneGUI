/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIPresenterTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI Presenter test
|
| ! \file        IGSxGUIxKPIPresenterTest.cpp
| ! \brief       Implementation of KPI Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxKPIPresenterTest.hpp"
#include "IGSxGUIxKPIManager.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxKpiValueSet.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPIPresenterTestParam,
                        ::testing::Values("Test"));

TEST_P(KPIPresenterTestParam, Test1)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();
    IGSxGUI::DashboardPresenter* ptr = new IGSxGUI::DashboardPresenter(NULL, kpiMgr);

    vector<IGSxGUI::KPI*> kpi = ptr->getKPIs();
    EXPECT_EQ(kpi.size(), 8);

    delete ptr;
    delete kpiMgr;
}

TEST_P(KPIPresenterTestParam, Test2)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();
    IGSxGUI::DashboardPresenter* ptr = new IGSxGUI::DashboardPresenter(NULL, kpiMgr);

    vector<IGSxGUI::KPIValueSet*> valsets = ptr->getKPIValueSets("DG_Droplet_Jump_Y");
    EXPECT_EQ(valsets.size(), 0);

    delete ptr;
    delete kpiMgr;
}
