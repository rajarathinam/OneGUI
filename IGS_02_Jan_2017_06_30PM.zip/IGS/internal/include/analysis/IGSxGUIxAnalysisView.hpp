/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisView.hpp
| Author       : Venugopal S
| Description  : Header file for Analysisview
|
| ! \file        IGSxGUIxAdvancedDiagnosticsView.hpp
| ! \brief       Header file for Analysis view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXANALYSISVIEW_HPP
#define IGSXGUIXANALYSISVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxIAnalysisView.hpp"
#include "IGSxGUIxAnalysisPresenter.hpp"
#include "IGSxGUIxADTManager.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AnalysisView;
}

namespace IGSxGUI{
class AnalysisView : public IAnalysisView
{
 public:
    AnalysisView();
    virtual ~AnalysisView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    AnalysisView(const AnalysisView&);
    AnalysisView& operator=(const AnalysisView&);


    SUI::AnalysisView *sui;
    AnalysisPresenter *m_presenter;

    static const std::string LOAD_FILE_ADVANCED_DIAGNOSTICS;
    static const std::string STR_ADT_LIST;
    static const std::string STR_CPD_LIST;
    static const std::string STR_INCORRECT_SELECTION;
    static const std::string STR_STARTED;
    static const std::string STR_STOPPED;
    bool m_bAnalysisViewActive;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXANALYSISVIEW_HPP
