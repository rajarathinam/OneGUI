/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application view
|
| ! \file        IGSxGUIxMainView.cpp
| ! \brief       Implementation of Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMainView.hpp"
#include <boost/bind.hpp>
#include <string>
#include "IGSxGUIxMoc_MainView.hpp"
#include "system/IGSxGUIxSystem.hpp"
#include <SUIDialog.h>
#include <SUIButton.h>
#include <SUIGroupBox.h>
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIBusyIndicator.h>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MainView::MAINVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxMainView.xml");
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_SYSTEM = "System";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_DASHBOARD = "Dashboard";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ANALYSIS = "Analysis";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ERRORALARM = "ALARM";

const std::string IGSxGUI::MainView::IMAGE_WHITE_SYSTEM = IGS::Resource::path("IGSxMain_WHITE_System.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_DASHBOARD = IGS::Resource::path("IGSxMain_WHITE_Dashboard.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_ANALYSIS = IGS::Resource::path("IGSxMain_WHITE_Analysis.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_WARNING = IGS::Resource::path("IGSxMain_WHITE_Warning.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_CLOCK = IGS::Resource::path("IGSxMain_WHITE_Clock.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_INFO = IGS::Resource::path("IGSxMain_WHITE_Info.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_CHECKCIRCLE = IGS::Resource::path("IGSxMain_WHITE_CheckCircle.png");

const std::string IGSxGUI::MainView::IMAGE_BLUE_SYSTEM = IGS::Resource::path("IGSxMain_BLUE_System.png");
const std::string IGSxGUI::MainView::IMAGE_BLUE_DASHBOARD = IGS::Resource::path("IGSxMain_BLUE_Dashboard.png");
const std::string IGSxGUI::MainView::IMAGE_BLUE_ANALYSIS = IGS::Resource::path("IGSxMain_BLUE_Analysis.png");

const std::string IGSxGUI::MainView::IMAGE_GREEN_CHECKCIRCLE = IGS::Resource::path("IGSxMain_GREEN_CheckCircle.png");
const std::string IGSxGUI::MainView::IMAGE_RED_WARNING_16PX = IGS::Resource::path("IGSxMain_RED_Warning_16px.png");

const std::string IGSxGUI::MainView::STRING_INITIALIZED = "INITIALIZED";
const std::string IGSxGUI::MainView::STRING_TERMINATED = "TERMINATED";
const std::string IGSxGUI::MainView::STRING_PARTIALLY_INITIALIZED = "PARTIALLY..";
const std::string IGSxGUI::MainView::STRING_RECOVERY_REQUIRED = "RECOVERY...";

const std::string IGSxGUI::MainView::STRING_TIME = "Time";
const std::string IGSxGUI::MainView::STRING_DATE = "Date";

const std::string IGSxGUI::MainView::STYLE_HOVER_ON = "hoverOn";
const std::string IGSxGUI::MainView::STYLE_HOVER_OFF = "hoverOff";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_ON = "hoverOnAlarmButton";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_OFF = "hoverOffAlarmButton";


const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU1_BUTTON = "System initialization";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU2_BUTTON = "System state manager";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU3_BUTTON = "Hardware reset";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU4_BUTTON = "Maintenance";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU5_BUTTON = "Service";


const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU1_BUTTON  = "Data View";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU2_BUTTON  = "Safety Diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU3_BUTTON  = "Advanced diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU4_BUTTON  = "Event Log";

const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_CLICKED  = "subSystemClciked";
const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_NORMAL  = "subSystemText";



const int IGSxGUI::MainView::TIMER_INTERVAL = 1000;
const int IGSxGUI::MainView::TIMER_RESTART_INTERVAL = 60000;

IGSxGUI::MainView::MainView() :
    NavigationButton(BTN_SYSTEM),
    sui(new SUI::MainView),
    m_iSystem(NULL),
    m_iDashboard(NULL),
    m_iAnalysis(NULL),
    m_iADT(NULL),
    m_iCPD(NULL),
    m_iEventViewer(NULL),
    m_timer(SUI::Timer::createTimer())
{
    sui->setupSUI(MAINVIEW_LOAD_FILE.c_str());

    sui->uctSystem->clicked = boost::bind(&MainView::onSystemButtonPressed, this);
    sui->uctDashboard->clicked = boost::bind(&MainView::onDashboardButtonPressed, this);
    sui->uctAnalysis->clicked = boost::bind(&MainView::onAnalysisButtonPressed, this);
    sui->uctErrorAlarm->clicked = boost::bind(&MainView::onErrorAlarmButtonPressed, this);
    sui->btn_ErrorInfo_Close->clicked = boost::bind(&MainView::onErrorCloseBtnPressed, this);

    sui->uctSystem->hoverEntered = boost::bind(&MainView::onSystemHoverOn, this);
    sui->uctSystem->hoverLeft = boost::bind(&MainView::onSystemHoverOff, this);
    sui->uctDashboard->hoverEntered = boost::bind(&MainView::onDashboardHoverOn, this);
    sui->uctDashboard->hoverLeft = boost::bind(&MainView::onDashboardHoverOff, this);
    sui->uctAnalysis->hoverEntered = boost::bind(&MainView::onAnalysisHoverOn, this);
    sui->uctAnalysis->hoverLeft = boost::bind(&MainView::onAnalysisHoverOff, this);
    sui->uctErrorAlarm->hoverEntered = boost::bind(&MainView::onErrorAlarmHoverOn, this);
    sui->uctErrorAlarm->hoverLeft = boost::bind(&MainView::onErrorAlarmHoverOff, this);

    sui->btnSysInit->clicked = boost::bind(&MainView::onSysInitPressed, this);
    sui->btnSysStateMgr->clicked = boost::bind(&MainView::onSysStateMgrPressed, this);
    sui->btnSysHWReset->clicked = boost::bind(&MainView::onSysHWResetPressed, this);
    sui->btnSysMaintenance->clicked = boost::bind(&MainView::onSysMaintenancePressed, this);
    sui->btnSysService->clicked = boost::bind(&MainView::onSysServicePressed, this);

    sui->btnAnalysisDataView->clicked = boost::bind(&MainView::onAnalysisDataViewPressed, this);
    sui->btnAnalysisSafetyDiagnostics->clicked = boost::bind(&MainView::onAnalysisSafetyDiagnosticsPressed, this);
    sui->btnAnalysisADT->clicked = boost::bind(&MainView::onAnalysisADTPressed, this);
    sui->btnAnalysisEventLog->clicked = boost::bind(&MainView::onAnalysisEventLogPressed, this);


    m_systemChanged = boost::bind(&IGSxGUI::MainView::onSystemStateChanged, this, _1);
    m_timer->timeout = boost::bind(&MainView::onTimeout, this);

    m_presenter = new IGSxGUI::MainPresenter(this);

    // Workaround to show the alarms button
    m_presenter->OnErrorStateChange("No alarms present");
}
IGSxGUI::MainView::~MainView()
{
    m_timer->stop();
    delete m_presenter;
    delete sui;

    if (m_systemChanged != NULL)
    {
        m_iSystem->unsubscribeForSystemState(m_systemChanged);
        m_systemChanged = NULL;
    }
    // Do not delete the plugins, they are maintained by the Factory
}

const std::string IGSxGUI::MainView::currentDateTime(const std::string& dateTime) {
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%l:%M%p", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}

void IGSxGUI::MainView::show()
{
    sui->dialog->show();
    m_timer->start(TIMER_INTERVAL);
    sui->uctSystem->setVisible(true);
    sui->uctDashboard->setVisible(true);
    sui->uctAnalysis->setVisible(true);

    sui->lblSystem->setText(NAVIGATION_BUTTON_SYSTEM);
    sui->lblDashboard->setText(NAVIGATION_BUTTON_DASHBOARD);
    sui->lblAnalysis->setText(NAVIGATION_BUTTON_ANALYSIS);
    sui->lblErrorAlarm->setText(NAVIGATION_BUTTON_ERRORALARM);

    sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_SYSTEM);
    sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_DASHBOARD);
    sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_ANALYSIS);
    sui->imvErrorAlarm->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_WARNING);

    sui->imv_TitleInfo_DateTime->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_CLOCK);
    sui->imv_ErrInfo_TimerImg->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_CLOCK);
    sui->imv_TitleInfo_Info->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_INFO);
    sui->lbl_tit_info_Time->setText(currentDateTime(STRING_TIME));
    sui->lbl_tit_info_Date->setText(currentDateTime(STRING_DATE));
    sui->gbxTitleInfo_DateTime->setToolTip("Date & time");

    onSystemButtonPressed();
}

void IGSxGUI::MainView::showError(const std::string& eMsg, const std::string& timeStamp)
{
    if (sui->uctErrorAlarm != NULL)
    {
        if (!sui->uctErrorAlarm->isVisible()){
            sui->uctErrorAlarm->setVisible(true);
        }
        sui->lbl_ErrInfo_Date->setText(timeStamp);
        sui->lbl_ErrorInfo_Msg->setText(eMsg);
    }
}

void IGSxGUI::MainView::hideError()
{
    if (sui->uctErrorAlarm != NULL)
    {
        sui->uctErrorAlarm->setVisible(false);
    }
}

void IGSxGUI::MainView::onTimeout()
{
    if (sui->lbl_tit_info_Time->getText() == currentDateTime(STRING_TIME))
    {
        return;
    }
    sui->lbl_tit_info_Time->setText(currentDateTime(STRING_TIME));
    sui->lbl_tit_info_Date->setText(currentDateTime(STRING_DATE));
    m_timer->stop();
    m_timer->start(TIMER_RESTART_INTERVAL);  // Increased the timer after first update as we dont need to update the seconds in timer.
}

void IGSxGUI::MainView::onSystemButtonPressed()
{
    bool bIsFirstTimeDisplay = false;
    sui->btnAnalysisDataView->setVisible(false);
    sui->btnAnalysisSafetyDiagnostics->setVisible(false);
    sui->btnAnalysisADT->setVisible(false);
    sui->btnAnalysisEventLog->setVisible(false);

    sui->btnSysInit->setVisible(true);
    sui->btnSysStateMgr->setVisible(true);
    sui->btnSysHWReset->setVisible(true);
    sui->btnSysMaintenance->setVisible(true);
    sui->btnSysService->setVisible(true);

    sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
    sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
    sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
    sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    if (m_iSystem == NULL)
    {
        m_iSystem = PluginFactory::getInstance().getSystemPlugin();

        if (m_systemChanged != NULL)
        {
            m_iSystem->subscribeForSystemState(m_systemChanged);
            // ToDo this is a quick fix for the delivery to ASML
            onSystemStateChanged(m_iSystem->retrieveSystemState());
        }

        bIsFirstTimeDisplay = true;
    }
    m_iSystem->setActive(true);
    sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    m_iSystem->show(sui->cntChildScreens, bIsFirstTimeDisplay);

    NavigationButton = BTN_SYSTEM;
    onDashboardHoverOff();
    onAnalysisHoverOff();
    onSystemHoverOn();
}

void IGSxGUI::MainView::onDashboardButtonPressed()
{
    bool bIsFirstTimeDisplay = false;
    sui->btnSysInit->setVisible(false);
    sui->btnSysStateMgr->setVisible(false);
    sui->btnSysHWReset->setVisible(false);
    sui->btnSysMaintenance->setVisible(false);
    sui->btnSysService->setVisible(false);

    sui->btnAnalysisDataView->setVisible(false);
    sui->btnAnalysisSafetyDiagnostics->setVisible(false);
    sui->btnAnalysisADT->setVisible(false);
    sui->btnAnalysisEventLog->setVisible(false);


    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    if (m_iDashboard == NULL)
    {
        m_iDashboard = PluginFactory::getInstance().getDashboardPlugin();
        bIsFirstTimeDisplay = true;
    }
    m_iDashboard->setActive(true);
    m_iDashboard->show(sui->cntChildScreens, bIsFirstTimeDisplay);

    NavigationButton = BTN_DASHBOARD;
    onSystemHoverOff();
    onAnalysisHoverOff();
    onDashboardHoverOn();
}


void IGSxGUI::MainView::onAnalysisButtonPressed()
{
    sui->btnSysInit->setVisible(false);
    sui->btnSysStateMgr->setVisible(false);
    sui->btnSysHWReset->setVisible(false);
    sui->btnSysMaintenance->setVisible(false);
    sui->btnSysService->setVisible(false);

    sui->btnAnalysisDataView->setVisible(true);
    sui->btnAnalysisSafetyDiagnostics->setVisible(true);
    sui->btnAnalysisADT->setVisible(true);
    sui->btnAnalysisEventLog->setVisible(true);



    sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
    sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
    sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);



    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    // Initial ADT UI display
    sui->btnAnalysisADT->setFocus();
    onAnalysisADTPressed();

    NavigationButton = BTN_ANALYSIS;

    onSystemHoverOff();
    onDashboardHoverOff();
    onAnalysisHoverOn();
}
void IGSxGUI::MainView::onCPDButtonPressed()
{
    bool bIsFirstTimeDisplay = false;

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }
    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }
    m_iCPD = PluginFactory::getInstance().getSystemPlugin();
    bIsFirstTimeDisplay = true;

    m_iCPD->setActive(true);
    m_iCPD->showCPD(sui->cntChildScreens, bIsFirstTimeDisplay);
}
void IGSxGUI::MainView::onADTMenuItemPressed()
{
    bool bIsFirstTimeDisplay = false;

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }
    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }
    m_iADT = PluginFactory::getInstance().getAnalysisPlugin();
    bIsFirstTimeDisplay = true;

    sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    m_iADT->showADT(sui->cntChildScreens, bIsFirstTimeDisplay);
}

void IGSxGUI::MainView::onErrorAlarmButtonPressed()
{
    if (!sui->gbx_ErrorInfo->isVisible() && sui->uctErrorAlarm->isEnabled())
    {
        sui->gbx_ErrorInfo->setVisible(true);
    }
}

void IGSxGUI::MainView::onErrorCloseBtnPressed()
{
    sui->gbx_ErrorInfo->setVisible(false);
}

void IGSxGUI::MainView::onSystemStateChanged(SystemState::SystemStateEnum state)
{
    switch (state)
    {
        case SystemState::SS_INITIALIZED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(true);
            sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_GREEN_CHECKCIRCLE);
            sui->lblTopBarStatus->setText(STRING_INITIALIZED);
            break;
        }
        case SystemState::SS_TERMINATED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(false);
            sui->lblTopBarStatus->setText(STRING_TERMINATED);
            break;
        }
        case SystemState::SS_INITIALIZING:
        case SystemState::SS_TERMINATING:
        {
            sui->uctTopBarStatus->setVisible(false);
            sui->bicTopBarStatus->setVisible(true);
            break;
        }
        case SystemState::SS_PARTIALLY_INITIALIZED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(false);
            sui->lblTopBarStatus->setText(STRING_PARTIALLY_INITIALIZED);
            break;
        }
        case SystemState::SS_RECOVERY_REQUIRED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(true);
            sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_RED_WARNING_16PX);
            sui->lblTopBarStatus->setText(STRING_RECOVERY_REQUIRED);
            break;
        }
    }
}

void IGSxGUI::MainView::onSystemHoverOn()
{
    setNavigationButtonStyles(BTN_SYSTEM, IMAGE_BLUE_SYSTEM, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onDashboardHoverOn()
{
    setNavigationButtonStyles(BTN_DASHBOARD, IMAGE_BLUE_DASHBOARD, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onAnalysisHoverOn()
{
    setNavigationButtonStyles(BTN_ANALYSIS, IMAGE_BLUE_ANALYSIS, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onErrorAlarmHoverOn()
{
    if (sui->uctErrorAlarm->isEnabled())
    {
        setNavigationButtonStyles(BTN_ERRORALARM, IMAGE_RED_WARNING_16PX, STYLE_ERROR_ALARM_HOVER_ON);
    }
}

void IGSxGUI::MainView::onSystemHoverOff()
{
    if (NavigationButton != BTN_SYSTEM)
    {
        setNavigationButtonStyles(BTN_SYSTEM, IMAGE_WHITE_SYSTEM, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onDashboardHoverOff()
{
    if (NavigationButton != BTN_DASHBOARD)
    {
        setNavigationButtonStyles(BTN_DASHBOARD, IMAGE_WHITE_DASHBOARD, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onAnalysisHoverOff()
{
    if (NavigationButton != BTN_ANALYSIS)
    {
        setNavigationButtonStyles(BTN_ANALYSIS, IMAGE_WHITE_ANALYSIS, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onErrorAlarmHoverOff()
{
    if (sui->uctErrorAlarm->isEnabled())
    {
        setNavigationButtonStyles(BTN_ERRORALARM, IMAGE_WHITE_WARNING, STYLE_ERROR_ALARM_HOVER_OFF);
    }
}

void IGSxGUI::MainView::setNavigationButtonStyles(BUTTON button, std::string strImage, std::string strStyle)
{
    switch (button)
    {
        case BTN_SYSTEM:
        {
            sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblSystem->setStyleSheetClass(strStyle);
            sui->gbxSystem->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_DASHBOARD:
        {
            sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblDashboard->setStyleSheetClass(strStyle);
            sui->gbxDashboard->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ANALYSIS:
        {
            sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblAnalysis->setStyleSheetClass(strStyle);
            sui->gbxAnalysis->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ERRORALARM:
        {
            sui->imvErrorAlarm->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblErrorAlarm->setStyleSheetClass(strStyle);
            sui->gbxErrorAlarm->setStyleSheetClass(strStyle);
            break;
        }
    }
}

void IGSxGUI::MainView::onSysInitPressed()
{
      bool bIsFirstTimeDisplay = false;
      m_iSystem->show(sui->cntChildScreens, bIsFirstTimeDisplay);
      NavigationButton = BTN_SYSTEM;
      onDashboardHoverOff();
      onAnalysisHoverOff();
      onSystemHoverOn();
}
void IGSxGUI::MainView::onSysStateMgrPressed()
{
    sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
}
void IGSxGUI::MainView::onSysHWResetPressed()
{
    sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
}
void IGSxGUI::MainView::onSysMaintenancePressed()
{
    sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    onCPDButtonPressed();
}
void IGSxGUI::MainView::onSysServicePressed()
{
    sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
}
void IGSxGUI::MainView::onAnalysisDataViewPressed()
{
    sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
}
void IGSxGUI::MainView::onAnalysisSafetyDiagnosticsPressed()
{
    sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
}
void IGSxGUI::MainView::onAnalysisADTPressed()
{
    sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
    sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    onADTMenuItemPressed();
}
void IGSxGUI::MainView::onAnalysisEventLogPressed()
{
    sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
    sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);

    bool bIsFirstTimeDisplay = false;
    if (m_iEventViewer == NULL)
    {
        m_iEventViewer = PluginFactory::getInstance().getAnalysisPlugin();
        bIsFirstTimeDisplay = true;
    }
    m_iEventViewer->setActive(true);
    m_iEventViewer->showEventViewer(sui->cntChildScreens, bIsFirstTimeDisplay);
}
