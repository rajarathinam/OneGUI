/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/assign.hpp>
#include <sstream>
#include <iomanip>
#include <vector>
#include <utility>
#include <string>
#include <map>
#include <stack>
#include <list>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxGUIxUtil.hpp"
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIUserControl.h>
#include <SUIGroupBox.h>
#include <SUIScrollBar.h>
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = "IGSxGUIxDashboardView.xml";

const std::string IGSxGUI::DashboardView::STRING_EMPTY = "";
const std::string IGSxGUI::DashboardView::STRING_SINGLE_SPACE = " ";
const std::string IGSxGUI::DashboardView::STRING_TIME = "Time";
const std::string IGSxGUI::DashboardView::STRING_ZERO = "0";
const std::string IGSxGUI::DashboardView::STRING_SEPERATOR = " | ";
const int IGSxGUI::DashboardView::NO_OF_PLOTITEM_VALUES = 20;
const int IGSxGUI::DashboardView::NO_OF_MAJOR_TICKS = 4;
const int IGSxGUI::DashboardView::NO_OF_MINOR_TICKS = 0;
const int IGSxGUI::DashboardView::TIMER_INTERVAL = 60000;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_START_VALUE = 40.0;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_END_VALUE = 80.0;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_SEPARATOR = 60.0;
const int IGSxGUI::DashboardView::SECONDS_PER_MINUTE = 60;
const int IGSxGUI::DashboardView::SECONDS_PER_HOUR = 3600;
const int IGSxGUI::DashboardView::SECONDS_FOR_FIVE_MINUTES = 300;
const int IGSxGUI::DashboardView::COLOR_RED = 83;
const int IGSxGUI::DashboardView::COLOR_GREEN = 194;
const int IGSxGUI::DashboardView::COLOR_BLUE = 252;
const int IGSxGUI::DashboardView::CONVERSION_BUFFER_SIZE = 80;
const int IGSxGUI::DashboardView::SCROLLBAR_MAX_VALUE = 350;
const int IGSxGUI::DashboardView::SCROLLBAR_MIN_VALUE = 10;

const int IGSxGUI::DashboardView::FIRST_MINUTE = 1;
const int IGSxGUI::DashboardView::SECOND_MINUTE = 2;
const int IGSxGUI::DashboardView::THIRD_MINUTE = 3;
const int IGSxGUI::DashboardView::FOURTH_MINUTE = 4;
const int IGSxGUI::DashboardView::FIFTH_MINUTE = 5;
const int IGSxGUI::DashboardView::SIXTH_MINUTE = 6;
const int IGSxGUI::DashboardView::TOTAL_SCROLLBAR_MINUTES = 360;

const int IGSxGUI::DashboardView::NORMALKPINAME_FONTSIZE = 12;
const int IGSxGUI::DashboardView::TEN_MINUTES = 10;

const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME1 = "Histogram1";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME2 = "Histogram2";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME3 = "Histogram3";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME4 = "Histogram4";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME5 = "Histogram5";
const std::string IGSxGUI::DashboardView::STRING_DATETIME_FORMAT2 = "%d/%m/%Y";

const std::string IGSxGUI::DashboardView::STRING_MINUTE_AGO = "minute ago...";
const std::string IGSxGUI::DashboardView::STRING_MINUTES_AGO = "minutes ago...";
const std::string IGSxGUI::DashboardView::STRING_NO_VALUES = "-";
const std::string IGSxGUI::DashboardView::STRING_DASHBOARD_SHOWN = "DashboardView is shown";

const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_HOVER_ON = "uctnormalkpihoveron";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_HOVER_OFF = "uctnormalkpihoveroff";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT = "tableLabelGreyText";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_PLAIN_TEXT = "tableLabelBlackText";

const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_HOVER_ON = "uctconsumablehoveron";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_HOVER_OFF = "uctconsumablehoveroff";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT = "tableLabelGreyText";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT = "tableLabelBlackText";

std::vector<std::string> IGSxGUI::DashboardView::STRING_HISTOGRAM_NAMES = boost::assign::list_of(STRING_HISTOGRAM_NAME1)(STRING_HISTOGRAM_NAME2)(STRING_HISTOGRAM_NAME3)(STRING_HISTOGRAM_NAME4)(STRING_HISTOGRAM_NAME5);

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView),
    m_timer(SUI::Timer::createTimer()), m_xaxis_update_enabled(true)
{
    m_presenter = new DashboardPresenter(this, pKpiManager);
    m_slider_move_past_values = false;
    m_slider_value_backup = SCROLLBAR_MAX_VALUE;

    m_listSystemKPIs = m_presenter->getSystemKPIs();
}
IGSxGUI::DashboardView::~DashboardView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
    std::map<std::string, SUI::PlotHistogramItem*>::iterator end_it = m_mapKPIHistogram.end();
    for (std::map<std::string, SUI::PlotHistogramItem*>::iterator it = m_mapKPIHistogram.begin(); it != end_it; ++it)
    {
        if (it->second != NULL)
        {
            it->second->detach();
            delete it->second;
        }
    }
    m_mapKPIHistogram.clear();
}

void IGSxGUI::DashboardView::buildHistogramGraphs()
{
    m_listSystemKPIs.clear();
    m_mapKPIHistogram.clear();
    m_mapKPIPlots.clear();
    m_mapKPIGraphValueLabel.clear();

    m_listSystemKPIs = m_presenter->getSystemKPIs();

    const int start = 1, end = 5;

    for (size_t i = 0; i < m_listSystemKPIs.size(); i++)
    {
        KPI* kpi = m_listSystemKPIs[i];
        if (kpi != NULL)
        {
            KPIValueSet* valueSet = kpi->getActiveValueSet();

            if (valueSet != NULL)
            {
                int position = valueSet->getPosition();

                if ( (position >= start) && (position <= end))
                {
                    int index = position - 1;
                    m_listSystemKPIGroupBoxes[index]->setVisible(true);
                    buildHistogramGraph(STRING_HISTOGRAM_NAMES[index], m_listSystemKPIGraphs[index], kpi, m_listSystemKPIGraphNames[index], m_listSystemKPIGraphValueSetNames[index], m_listSystemKPIGraphUnits[index], m_listSystemKPIGraphValues[index], m_listCircularBuffers[index]);
                }
            }
        }
    }
}
void IGSxGUI::DashboardView::updatePlotXAxisTime(std::list<double>& time_list, const boost::posix_time::ptime& time)
{
    time_list.clear();
    boost::posix_time::ptime timeLocal = time;
    double x = (SECONDS_PER_HOUR * (timeLocal.time_of_day().hours() - 1)) + (SECONDS_PER_MINUTE * timeLocal.time_of_day().minutes());
    time_list.push_back(x - (2 * SECONDS_FOR_FIVE_MINUTES));
    time_list.push_back(x - (1 * SECONDS_FOR_FIVE_MINUTES));
    time_list.push_back(x);
    time_list.push_back(x + (1 * SECONDS_FOR_FIVE_MINUTES));
    time_list.push_back(x + (2 * SECONDS_FOR_FIVE_MINUTES));


    m_xaxisstartvalue = x - (2 * SECONDS_FOR_FIVE_MINUTES);
}

void IGSxGUI::DashboardView::buildHistogramGraph(const std::string& name, SUI::PlotWidget* plot, IGSxGUI::KPI* kpi, SUI::Label *lblName, SUI::Label *lblValueName, SUI::Label *lblDisplayName, SUI::Label *lblValue, const boost::circular_buffer<double>& buffer)
{
    SUI::PlotHistogramItem* histogram = new SUI::PlotHistogramItem(name);
    if (histogram != NULL)
    {
        plot->setYGrid(SUI::GridStyleEnum::Normal);
        plot->setAxisMaxMinor(SUI::PlotAxisEnum::yLeft, NO_OF_MINOR_TICKS);

        std::list<double> time_list;
        boost::posix_time::ptime currenttime = boost::posix_time::second_clock::local_time();
        updatePlotXAxisTime(time_list, currenttime);
        plot->setCustomXAxisScale(time_list);

        SUI::PlotItemCustomColor penColor(COLOR_RED, COLOR_GREEN, COLOR_BLUE);
        histogram->setCustomBrushColor(penColor);
        histogram->setCustomPenColor(penColor);
        histogram->attach(plot);
    }

    if (kpi != NULL)
    {
        std::string systemKPIDesc = kpi->getDescription();
        lblName->setText(IGSxGUI::Util::elideText(systemKPIDesc, NORMALKPINAME_FONTSIZE, lblName->getGeometry().getWidth()));
        lblName->setToolTip(systemKPIDesc);

        KPIValueSet* valueSet = kpi->getActiveValueSet();

        if (valueSet != NULL)
        {
            lblValueName->setText(valueSet->getName());
            lblDisplayName->setText(valueSet->getDisplayUnit());
            m_mapKPIHistogram.insert(std::make_pair(systemKPIDesc, histogram));
            m_mapKPIGraphValueLabel.insert(std::make_pair(systemKPIDesc, lblValue));
            m_mapKPIPlots.insert(std::make_pair(systemKPIDesc, plot));
            m_mapKPICircBuffPlotItemValues.insert((std::make_pair(systemKPIDesc, buffer)));

            KPITimeValue kpiTimeValue = valueSet->getLastValue();

            if (kpiTimeValue.isUpdated)
            {
                std::ostringstream ss;
                ss << std::fixed << std::setprecision(1);

                double x = kpiTimeValue.kpiValue;
                ss << x;

                m_mapKPIGraphValueLabel[systemKPIDesc]->setText(boost::lexical_cast<std::string>(ss.str()));
            } else {
                m_mapKPIGraphValueLabel[systemKPIDesc]->setText(STRING_NO_VALUES);
            }
            showHistogramsForValue(kpi->getName(), kpiTimeValue.kpiTime);
        }
    }
}

void IGSxGUI::DashboardView::buildKPITable()
{
    std::vector<KPI*> kpis = m_presenter->getKPIs();
    const int start = 1, mid = 10, end = 20;

    for (size_t i = 0; i < kpis.size(); i++)
    {
        KPI* kpi = kpis[i];

        if (kpi != NULL)
        {
            KPIValueSet* valueSet = kpi->getActiveValueSet();

            if (valueSet != NULL)
            {
                int position = valueSet->getPosition();

                if ((position >= start) && (position <= mid))
                {
                    int index = position - start;

                    m_listNormalKPIGroupBoxes_T1[index]->setVisible(true);
                    m_listNormalKPINames_T1[index]->setText(IGSxGUI::Util::elideText(kpi->getDescription(), NORMALKPINAME_FONTSIZE, m_listNormalKPINames_T1[index]->getGeometry().getWidth()));
                    m_listNormalKPIUnits_T1[index]->setText(valueSet->getDisplayUnit());

                    KPITimeValue kpiTimeValue = valueSet->getLastValue();

                    if (kpiTimeValue.isUpdated)
                    {
                        std::ostringstream ss;
                        ss << std::fixed << std::setprecision(1);

                        double x = kpiTimeValue.kpiValue;
                        ss << x;

                        m_listNormalKPIValues_T1[index]->setText(boost::lexical_cast<std::string>(ss.str()));

                        std::string strMinuteDesc = STRING_MINUTE_AGO;
                        int diffInMinutes = SystemDateTime::getTimeDifferenceInMinutes(time(0), kpiTimeValue.kpiTime);
                        if (diffInMinutes > 1)
                        {
                            strMinuteDesc = STRING_MINUTES_AGO;
                        }
                        m_listTimeKPIUpdated_T1[index]->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, kpiTimeValue.kpiTime) + STRING_SEPERATOR);
                        m_listTimeKPILastUpdated_T1[index]->setText(boost::lexical_cast<std::string>(diffInMinutes) + STRING_SINGLE_SPACE + strMinuteDesc);
                    } else {
                        m_listNormalKPIValues_T1[index]->setText(STRING_NO_VALUES);
                        m_listTimeKPIUpdated_T1[index]->setText(STRING_NO_VALUES);
                    }
                } else if ((position >= (mid+1)) && (position <= end)) {
                    int index = position - (mid+1);

                    m_listNormalKPIGroupBoxes_T2[index]->setVisible(true);
                    m_listNormalKPINames_T2[index]->setText(kpi->getDescription());
                    m_listNormalKPIUnits_T2[index]->setText(valueSet->getDisplayUnit());

                    KPITimeValue kpiTimeValue = valueSet->getLastValue();

                    if (kpiTimeValue.isUpdated)
                    {
                        std::ostringstream ss;
                        ss << std::fixed << std::setprecision(1);

                        double x = kpiTimeValue.kpiValue;
                        ss << x;

                        m_listNormalKPIValues_T2[index]->setText(boost::lexical_cast<std::string>(ss.str()));

                        std::string strMinuteDesc = STRING_MINUTE_AGO;
                        int diffInMinutes = SystemDateTime::getTimeDifferenceInMinutes(time(0), kpiTimeValue.kpiTime);
                        if ( diffInMinutes > 1)
                        {
                            strMinuteDesc = STRING_MINUTES_AGO;
                        }
                        m_listTimeKPIUpdated_T2[index]->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, kpiTimeValue.kpiTime) + STRING_SEPERATOR);
                        m_listTimeKPILastUpdated_T2[index]->setText(boost::lexical_cast<std::string>(diffInMinutes) + STRING_SINGLE_SPACE + strMinuteDesc);
                    } else {
                        m_listTimeKPIUpdated_T2[index]->setText(STRING_NO_VALUES);
                        m_listNormalKPIValues_T2[index]->setText(STRING_NO_VALUES);
                    }
                }
            }
        }
    }
}
void IGSxGUI::DashboardView::buildConsumableTable()
{
    std::vector<KPI*> consumables = m_presenter->getConsumables();

    const int start = 1, end = 10;
    if (consumables.empty())
    {
        sui->lblHeadingConsumable1->setVisible(false);
        sui->lblHeadingConsumable2->setVisible(false);
        sui->lblHeadingConsumable3->setVisible(false);
    }

    for (size_t i = 0; i < consumables.size(); i++)
    {
        KPI* kpi = consumables[i];

        if (kpi != NULL)
        {
            KPIValueSet* valueSet = kpi->getActiveValueSet();

            if (valueSet != NULL)
            {
                int position = valueSet->getPosition();

                if ( (position >= start) && (position <= end))
                {
                    int index = position - 1;
                    m_listConsumableGroupBoxes[index]->setVisible(true);
                    m_listConsumableNames[index]->setText(kpi->getDescription());

                    KPITimeValue kpiTimeValue = valueSet->getLastValue();

                    if (kpiTimeValue.isUpdated)
                    {
                        double kpiValue = kpiTimeValue.kpiValue;

                        double max = boost::lexical_cast<double>(valueSet->getMax());
                        double min = boost::lexical_cast<double>(valueSet->getMin());
                        double t_kpiValuePercentage = ((kpiValue - min) * static_cast<double>(100)) / (max - min);

                        std::ostringstream ss;
                        ss << std::fixed << std::setprecision(1);

                        double x = kpiTimeValue.kpiValue;
                        ss << x;

                        m_listConsumableValues[index]->setText(boost::lexical_cast<std::string>(ss.str()));
                        m_listConsumableProgressbars[index]->setValue(static_cast<int>(t_kpiValuePercentage));
                        m_listConsumableTimes[index]->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_TIME));
                    } else {
                        m_listConsumableValues[index]->setText(STRING_NO_VALUES);
                        m_listConsumableProgressbars[index]->setValue(0);
                        m_listConsumableTimes[index]->setText(STRING_NO_VALUES);
                    }
                    m_listConsumableUnits[index]->setText(valueSet->getDisplayUnit());
                }
            }
        }
    }
}
void IGSxGUI::DashboardView::restoreDashboard()
{
    addSliderTimes();
    onSliderValueChanged();
    buildKPITable();
}

void IGSxGUI::DashboardView::onTimeout()
{
    buildKPITable();
    addSliderTimes();
    if (m_slider_value_backup != SCROLLBAR_MAX_VALUE)
    {
        m_slider_value_backup = m_slider_value_backup- 1;
        if (m_slider_value_backup <= 0)
        {
            m_slider_value_backup = 0;
        }
        m_xaxis_update_enabled = false;
        sui->scbTimeSlider->setValue(m_slider_value_backup);
        m_xaxis_update_enabled = true;
    }
}

void IGSxGUI::DashboardView::showHistograms()
{
    for (size_t outer_index = 0; outer_index < m_listSystemKPIs.size(); ++outer_index)
    {
        KPI* systemKpi = m_listSystemKPIs[outer_index];

        if (systemKpi != NULL)
        {
            std::string sysKPIName = systemKpi->getDescription();

            m_circularBufferToDraw[sysKPIName].set_capacity(NO_OF_PLOTITEM_VALUES);
            m_circularBufferToDraw[sysKPIName].clear();

            for (int inner_index = 0; inner_index < NO_OF_PLOTITEM_VALUES; ++inner_index)
            {
              m_circularBufferToDraw[sysKPIName].push_back(0.0);
            }

            boost::circular_buffer<KPITimeValue> cbKpiTimeValue = systemKpi->getActiveValueSet()->getValue();

            boost::circular_buffer<KPITimeValue>::const_iterator endIt = cbKpiTimeValue.end();
            boost::circular_buffer<KPITimeValue>::const_iterator it;

            for (it = cbKpiTimeValue.begin(); it != endIt; ++it)
            {
                m_circularBufferToDraw[sysKPIName].push_back(it->kpiValue);
            }

            m_mapKPIHistogram[sysKPIName]->clearSamples();
            boost::circular_buffer<double>::const_iterator end_it = m_circularBufferToDraw[sysKPIName].end();
            boost::circular_buffer<double>::const_iterator circ_it;
            plotsamples[sysKPIName].clear();
            if (m_slider_value_backup == SCROLLBAR_MAX_VALUE)
                {
                    std::list<double> time_list;
                    boost::posix_time::ptime currenttime = boost::posix_time::second_clock::local_time();
                    updatePlotXAxisTime(time_list, currenttime - boost::posix_time::minutes(TEN_MINUTES));
                    m_mapKPIPlots[sysKPIName]->setCustomXAxisScale(time_list);
                }

            m_mapKPIMinValue[sysKPIName] = m_xaxisstartvalue + HISTOGRAM_BAR_START_VALUE;
            m_mapKPIMaxValue[sysKPIName] = m_xaxisstartvalue + HISTOGRAM_BAR_END_VALUE;

            for (circ_it = m_circularBufferToDraw[sysKPIName].begin(); circ_it != end_it; ++circ_it)
            {
                plotsamples[sysKPIName].push_back(SUI::PlotIntervalSample(*circ_it, m_mapKPIMinValue[sysKPIName], m_mapKPIMaxValue[sysKPIName]));
                m_mapKPIMinValue[sysKPIName]  = m_mapKPIMinValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
                m_mapKPIMaxValue[sysKPIName]  = m_mapKPIMaxValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
            }
            m_mapKPIHistogram[sysKPIName]->setSamples(plotsamples[sysKPIName]);
            m_mapKPIPlots[sysKPIName]->replot();
        }
    }
}

void IGSxGUI::DashboardView::showHistogramsForValue(const std::string& strSystemKPIName, const time_t& value)
{
    KPI* systemKPI = m_presenter->getSystemKPI(strSystemKPIName);
    if ( systemKPI != NULL)
    {
        std::string sysKPIDesc;
        sysKPIDesc = m_presenter->getSystemKPI(strSystemKPIName)->getDescription();

        m_circularBufferToDraw[sysKPIDesc].set_capacity(NO_OF_PLOTITEM_VALUES);
        m_circularBufferToDraw[sysKPIDesc].clear();

        for (int inner_index = 0; inner_index < NO_OF_PLOTITEM_VALUES; ++inner_index)
        {
            m_circularBufferToDraw[sysKPIDesc].push_back(0.0);
        }
        boost::circular_buffer<KPITimeValue> cbKpiTimeValue = systemKPI->getActiveValueSet()->getValue();
        boost::circular_buffer<KPITimeValue>::const_reverse_iterator endIt = cbKpiTimeValue.rend();
        boost::circular_buffer<KPITimeValue>::const_reverse_iterator it;
        std::stack<double> reverse_values;
        bool bFound = false;
        for (it = cbKpiTimeValue.rbegin(); it != endIt; ++it)
        {
            KPITimeValue timevalue = *it;

            if (timevalue.kpiTime <= value)
            {
                bFound = true;
            }

            if (bFound)
            {
                reverse_values.push(timevalue.kpiValue);
            }
        }
        while (!reverse_values.empty())
        {
            m_circularBufferToDraw[sysKPIDesc].push_back(reverse_values.top());
            reverse_values.pop();
        }
        m_mapKPIHistogram[sysKPIDesc]->clearSamples();
        boost::circular_buffer<double>::const_iterator end_it = m_circularBufferToDraw[sysKPIDesc].end();
        boost::circular_buffer<double>::const_iterator circ_it;
        plotsamples[sysKPIDesc].clear();
        if (m_slider_value_backup == SCROLLBAR_MAX_VALUE)
        {
            boost::posix_time::ptime currenttime = boost::posix_time::second_clock::local_time();
            std::list<double> time_list;
            updatePlotXAxisTime(time_list, currenttime - boost::posix_time::minutes(TEN_MINUTES));
            m_mapKPIPlots[sysKPIDesc]->setCustomXAxisScale(time_list);
        }

        m_mapKPIMinValue[sysKPIDesc] = m_xaxisstartvalue + HISTOGRAM_BAR_START_VALUE;
        m_mapKPIMaxValue[sysKPIDesc] = m_xaxisstartvalue + HISTOGRAM_BAR_END_VALUE;

        for (circ_it = m_circularBufferToDraw[sysKPIDesc].begin(); circ_it != end_it; ++circ_it)
        {
           plotsamples[sysKPIDesc].push_back(SUI::PlotIntervalSample(*circ_it, m_mapKPIMinValue[sysKPIDesc], m_mapKPIMaxValue[sysKPIDesc]));

           m_mapKPIMinValue[sysKPIDesc]  = m_mapKPIMinValue[sysKPIDesc] + HISTOGRAM_BAR_SEPARATOR;
           m_mapKPIMaxValue[sysKPIDesc]  = m_mapKPIMaxValue[sysKPIDesc] + HISTOGRAM_BAR_SEPARATOR;
        }
        m_mapKPIHistogram[sysKPIDesc]->setSamples(plotsamples[sysKPIDesc]);
        m_mapKPIPlots[sysKPIDesc]->replot();
    }
}

void IGSxGUI::DashboardView::addSliderTimes() const
{
    time_t currTime = time(NULL);
    sui->timeDisplay7->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime));
    sui->timeDisplay6->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(FIRST_MINUTE * SECONDS_PER_HOUR)));
    sui->timeDisplay5->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(SECOND_MINUTE * SECONDS_PER_HOUR)));
    sui->timeDisplay4->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(THIRD_MINUTE * SECONDS_PER_HOUR)));
    sui->timeDisplay3->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(FOURTH_MINUTE * SECONDS_PER_HOUR)));
    sui->timeDisplay2->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(FIFTH_MINUTE * SECONDS_PER_HOUR)));
    sui->timeDisplay1->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, currTime - static_cast<time_t>(SIXTH_MINUTE * SECONDS_PER_HOUR)));
}
void IGSxGUI::DashboardView::onSliderValueChanged()
{
    m_slider_value_backup = sui->scbTimeSlider->getValue();

    if (m_slider_value_backup == SCROLLBAR_MAX_VALUE)
    {
        showHistograms();
    } else {
        int current_value = m_slider_value_backup;
        std::list<double> time_list;
        if (m_xaxis_update_enabled)
        {
            boost::posix_time::ptime currenttime = boost::posix_time::second_clock::local_time();
            currenttime = currenttime - boost::posix_time::minutes(TOTAL_SCROLLBAR_MINUTES) + boost::posix_time::minutes(current_value);
            updatePlotXAxisTime(time_list, currenttime);
        }
       time_t timetosearch = time(NULL) - static_cast<time_t>((TOTAL_SCROLLBAR_MINUTES - TEN_MINUTES) * SECONDS_PER_MINUTE) + static_cast<time_t>(current_value * SECONDS_PER_MINUTE);
       for ( size_t i = 0; i < m_listSystemKPIs.size(); i++)
       {
            if (m_xaxis_update_enabled)
            {
                std::string sysKPIDesc = m_listSystemKPIs[i]->getDescription();
                m_mapKPIPlots[sysKPIDesc]->setCustomXAxisScale(time_list);
                m_mapKPIPlots[sysKPIDesc]->replot();
            }
            showHistogramsForValue(m_listSystemKPIs[i]->getName(), timetosearch);
       }
    }
}

void IGSxGUI::DashboardView::updateSystemKPI(const std::string &p_systemKPIName)
{
    IGSxGUI::KPI *kpi = m_presenter->getSystemKPI(p_systemKPIName);
    IGSxGUI::KPIValueSet *valueSet = kpi->getActiveValueSet();

    if (valueSet != NULL)
    {
        KPITimeValue kpiTimeValue;
        kpiTimeValue = valueSet->getLastValue();

        std::ostringstream ss;
        ss << std::fixed << std::setprecision(1);

        double x = kpiTimeValue.kpiValue;
        ss << x;

        if (sui->scbTimeSlider->getValue() == SCROLLBAR_MAX_VALUE)
        {
            showHistogramsForValue(p_systemKPIName, kpiTimeValue.kpiTime);
            m_mapKPIGraphValueLabel[kpi->getDescription()]->setText(boost::lexical_cast<std::string>(ss.str()));
        }
    }
}

void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
    if (!bIsFirstTimeDisplay)
    {
        restoreDashboard();
    }

    IGS_INFO(STRING_DASHBOARD_SHOWN);
}
void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
        std::map<std::string, SUI::PlotHistogramItem*>::iterator end_it = m_mapKPIHistogram.end();
        for (std::map<std::string, SUI::PlotHistogramItem*>::iterator it = m_mapKPIHistogram.begin(); it != end_it; ++it)
        {
            if (it->second != NULL)
            {
                it->second->detach();
                delete it->second;
            }
        }
        m_mapKPIHistogram.clear();
        m_timer->stop();
    }
}

void IGSxGUI::DashboardView::updateKPI(const std::string &kpiName)
{
    IGSxGUI::KPI* kpi = m_presenter->getKPI(kpiName);
    if (kpi != NULL)
    {
        KPIValueSet* valset = kpi->getActiveValueSet();

        if (valset != NULL)
        {
            const int start = 1, mid = 10, end = 20;
            std::string description = kpi->getDescription();

            KPITimeValue kpiTimeValue;
            kpiTimeValue = valset->getLastValue();

            int position = valset->getPosition();

            if ( (position >= start) && (position <= mid))
            {
                int index = position - start;

                if (m_listNormalKPINames_T1[index]->getText() == description)
                {
                    std::ostringstream ss;
                    ss << std::fixed << std::setprecision(1);

                    double x = kpiTimeValue.kpiValue;
                    ss << x;

                    m_listNormalKPIValues_T1[index]->setText(ss.str());
                    m_listNormalKPIUnits_T1[index]->setText(valset->getDisplayUnit());

                    std::string strMinuteDesc = STRING_MINUTE_AGO;
                    int diffInMinutes = SystemDateTime::getTimeDifferenceInMinutes(time(0), kpiTimeValue.kpiTime);
                    if (diffInMinutes > 1)
                    {
                        strMinuteDesc = STRING_MINUTES_AGO;
                    }
                    m_listTimeKPIUpdated_T1[index]->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, kpiTimeValue.kpiTime) + STRING_SEPERATOR);
                    m_listTimeKPILastUpdated_T1[index]->setText(boost::lexical_cast<std::string>(diffInMinutes) + STRING_SINGLE_SPACE + strMinuteDesc);
                }

            } else if ((position >= (mid+1)) && (position <= end)) {
                int index = position - (mid+1);

                if (m_listNormalKPINames_T2[index]->getText() == description)
                {
                    std::ostringstream ss;
                    ss << std::fixed << std::setprecision(1);

                    double x = kpiTimeValue.kpiValue;
                    ss << x;

                    m_listNormalKPIValues_T2[index]->setText(ss.str());
                    m_listNormalKPIUnits_T2[index]->setText(valset->getDisplayUnit());

                    std::string strMinuteDesc = STRING_MINUTE_AGO;
                    int diffInMinutes = SystemDateTime::getTimeDifferenceInMinutes(time(0), kpiTimeValue.kpiTime);
                    if (diffInMinutes > 1)
                    {
                        strMinuteDesc = STRING_MINUTES_AGO;
                    }
                    m_listTimeKPIUpdated_T2[index]->setText((SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, kpiTimeValue.kpiTime) + STRING_SEPERATOR));
                    m_listTimeKPILastUpdated_T2[index]->setText(boost::lexical_cast<std::string>(diffInMinutes) + STRING_SINGLE_SPACE + strMinuteDesc);
                }
            }
        }
    }
}

void IGSxGUI::DashboardView::updateConsumable(const std::string &p_consumableName)
{
    IGSxGUI::KPI* kpi = m_presenter->getConsumable(p_consumableName);
    if (kpi != NULL)
    {
        KPIValueSet* valSet = kpi->getActiveValueSet();
        if (valSet != NULL)
        {
            KPITimeValue kpiTimeValue;
            kpiTimeValue = valSet->getLastValue();

            int position = valSet->getPosition();
            const int start = 1, end = 10;

            if ( (position >= start) && (position <= end))
            {
                int index = position - start;

                std::ostringstream ss;
                ss << std::fixed << std::setprecision(1);

                double x = kpiTimeValue.kpiValue;
                ss << x;

                // Calculate Percentage Value
                double t_kpiValuePercentage = ((kpiTimeValue.kpiValue - valSet->getMin()) * static_cast<double>(100)) / (valSet->getMax() - valSet->getMin());

                m_listConsumableTimes[index]->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_TIME, kpiTimeValue.kpiTime));
                m_listConsumableValues[index]->setText(ss.str());
                m_listConsumableUnits[index]->setText(valSet->getDisplayUnit());
                m_listConsumableProgressbars[index]->setValue(boost::numeric_cast<int>(t_kpiValuePercentage));
            }
        }
    }
}

void IGSxGUI::DashboardView::loadContainers()
{
    m_listNormalKPIUCTs_T1.clear();
    m_listNormalKPINames_T1.clear();
    m_listTimeKPIUpdated_T1.clear();
    m_listTimeKPILastUpdated_T1.clear();
    m_listNormalKPIValues_T1.clear();
    m_listNormalKPIUnits_T1.clear();
    m_listNormalKPIGroupBoxes_T1.clear();

    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI1_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI2_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI3_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI4_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI5_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI6_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI7_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI8_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI9_T1);
    m_listNormalKPIUCTs_T1.push_back(sui->uctNormalKPI10_T1);

    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI1_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI2_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI3_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI4_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI5_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI6_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI7_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI8_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI9_T1);
    m_listNormalKPIGroupBoxes_T1.push_back(sui->gbxNormalKPI10_T1);

    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI1Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI2Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI3Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI4Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI5Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI6Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI7Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI8Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI9Name_T1);
    m_listNormalKPINames_T1.push_back(sui->lblNormalKPI10Name_T1);

    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI1Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI2Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI3Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI4Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI5Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI6Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI7Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI8Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI9Updated_T1);
    m_listTimeKPIUpdated_T1.push_back(sui->lblTimeKPI10Updated_T1);

    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI1LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI2LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI3LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI4LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI5LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI6LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI7LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI8LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI9LastUpdated_T1);
    m_listTimeKPILastUpdated_T1.push_back(sui->lblTimeKPI10LastUpdated_T1);

    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI1Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI2Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI3Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI4Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI5Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI6Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI7Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI8Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI9Value_T1);
    m_listNormalKPIValues_T1.push_back(sui->lblNormalKPI10Value_T1);

    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI1Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI2Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI3Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI4Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI5Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI6Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI7Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI8Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI9Unit_T1);
    m_listNormalKPIUnits_T1.push_back(sui->lblNormalKPI10Unit_T1);

    m_listNormalKPIUCTs_T2.clear();
    m_listNormalKPINames_T2.clear();
    m_listTimeKPIUpdated_T2.clear();
    m_listTimeKPILastUpdated_T2.clear();
    m_listNormalKPIValues_T2.clear();
    m_listNormalKPIUnits_T2.clear();
    m_listNormalKPIGroupBoxes_T2.clear();

    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI1_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI2_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI3_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI4_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI5_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI6_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI7_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI8_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI9_T2);
    m_listNormalKPIUCTs_T2.push_back(sui->uctNormalKPI10_T2);

    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI1_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI2_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI3_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI4_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI5_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI6_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI7_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI8_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI9_T2);
    m_listNormalKPIGroupBoxes_T2.push_back(sui->gbxNormalKPI10_T2);

    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI1Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI2Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI3Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI4Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI5Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI6Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI7Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI8Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI9Name_T2);
    m_listNormalKPINames_T2.push_back(sui->lblNormalKPI10Name_T2);

    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI1Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI2Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI3Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI4Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI5Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI6Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI7Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI8Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI9Updated_T2);
    m_listTimeKPIUpdated_T2.push_back(sui->lblTimeKPI10Updated_T2);

    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI1LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI2LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI3LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI4LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI5LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI6LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI7LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI8LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI9LastUpdated_T2);
    m_listTimeKPILastUpdated_T2.push_back(sui->lblTimeKPI10LastUpdated_T2);

    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI1Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI2Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI3Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI4Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI5Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI6Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI7Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI8Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI9Value_T2);
    m_listNormalKPIValues_T2.push_back(sui->lblNormalKPI10Value_T2);

    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI1Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI2Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI3Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI4Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI5Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI6Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI7Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI8Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI9Unit_T2);
    m_listNormalKPIUnits_T2.push_back(sui->lblNormalKPI10Unit_T2);

    m_listConsumableUCTs.clear();
    m_listConsumableGroupBoxes.clear();
    m_listConsumableNames.clear();
    m_listConsumableCategories.clear();
    m_listConsumableTimes.clear();
    m_listConsumableValues.clear();
    m_listConsumableUnits.clear();
    m_listConsumableProgressbars.clear();

    m_listConsumableUCTs.push_back(sui->uctConsumable1);
    m_listConsumableUCTs.push_back(sui->uctConsumable2);
    m_listConsumableUCTs.push_back(sui->uctConsumable3);
    m_listConsumableUCTs.push_back(sui->uctConsumable4);
    m_listConsumableUCTs.push_back(sui->uctConsumable5);
    m_listConsumableUCTs.push_back(sui->uctConsumable6);
    m_listConsumableUCTs.push_back(sui->uctConsumable7);
    m_listConsumableUCTs.push_back(sui->uctConsumable8);
    m_listConsumableUCTs.push_back(sui->uctConsumable9);
    m_listConsumableUCTs.push_back(sui->uctConsumable10);

    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable1);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable2);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable3);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable4);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable5);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable6);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable7);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable8);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable9);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable10);

    m_listConsumableNames.push_back(sui->lblConsumable1Name);
    m_listConsumableNames.push_back(sui->lblConsumable2Name);
    m_listConsumableNames.push_back(sui->lblConsumable3Name);
    m_listConsumableNames.push_back(sui->lblConsumable4Name);
    m_listConsumableNames.push_back(sui->lblConsumable5Name);
    m_listConsumableNames.push_back(sui->lblConsumable6Name);
    m_listConsumableNames.push_back(sui->lblConsumable7Name);
    m_listConsumableNames.push_back(sui->lblConsumable8Name);
    m_listConsumableNames.push_back(sui->lblConsumable9Name);
    m_listConsumableNames.push_back(sui->lblConsumable10Name);

    m_listConsumableTimes.push_back(sui->lblConsumable1Time);
    m_listConsumableTimes.push_back(sui->lblConsumable2Time);
    m_listConsumableTimes.push_back(sui->lblConsumable3Time);
    m_listConsumableTimes.push_back(sui->lblConsumable4Time);
    m_listConsumableTimes.push_back(sui->lblConsumable5Time);
    m_listConsumableTimes.push_back(sui->lblConsumable6Time);
    m_listConsumableTimes.push_back(sui->lblConsumable7Time);
    m_listConsumableTimes.push_back(sui->lblConsumable8Time);
    m_listConsumableTimes.push_back(sui->lblConsumable9Time);
    m_listConsumableTimes.push_back(sui->lblConsumable10Time);

    m_listConsumableValues.push_back(sui->lblConsumable1Value);
    m_listConsumableValues.push_back(sui->lblConsumable2Value);
    m_listConsumableValues.push_back(sui->lblConsumable3Value);
    m_listConsumableValues.push_back(sui->lblConsumable4Value);
    m_listConsumableValues.push_back(sui->lblConsumable5Value);
    m_listConsumableValues.push_back(sui->lblConsumable6Value);
    m_listConsumableValues.push_back(sui->lblConsumable7Value);
    m_listConsumableValues.push_back(sui->lblConsumable8Value);
    m_listConsumableValues.push_back(sui->lblConsumable9Value);
    m_listConsumableValues.push_back(sui->lblConsumable10Value);

    m_listConsumableUnits.push_back(sui->lblConsumable1Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable2Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable3Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable4Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable5Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable6Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable7Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable8Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable9Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable10Unit);

    m_listConsumableProgressbars.push_back(sui->pgbConsumable1);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable2);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable3);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable4);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable5);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable6);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable7);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable8);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable9);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable10);

    m_listSystemKPIUCTs.clear();
    m_listSystemKPIGroupBoxes.clear();
    m_listSystemKPIGraphs.clear();
    m_listSystemKPIGraphNames.clear();
    m_listSystemKPIGraphValueSetNames.clear();
    m_listSystemKPIGraphUnits.clear();
    m_listSystemKPIGraphValues.clear();
    m_listCircularBuffers.clear();

    m_listSystemKPIUCTs.push_back(sui->uctSystemKPIGraph1);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPIGraph2);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPIGraph3);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPIGraph4);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPIGraph5);

    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPIGraph1);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPIGraph2);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPIGraph3);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPIGraph4);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPIGraph5);

    m_listSystemKPIGraphs.push_back(sui->plwSystemKPIGraph1);
    m_listSystemKPIGraphs.push_back(sui->plwSystemKPIGraph2);
    m_listSystemKPIGraphs.push_back(sui->plwSystemKPIGraph3);
    m_listSystemKPIGraphs.push_back(sui->plwSystemKPIGraph4);
    m_listSystemKPIGraphs.push_back(sui->plwSystemKPIGraph5);

    m_listSystemKPIGraphNames.push_back(sui->lblSystemKPIGraph1KPIName);
    m_listSystemKPIGraphNames.push_back(sui->lblSystemKPIGraph2KPIName);
    m_listSystemKPIGraphNames.push_back(sui->lblSystemKPIGraph3KPIName);
    m_listSystemKPIGraphNames.push_back(sui->lblSystemKPIGraph4KPIName);
    m_listSystemKPIGraphNames.push_back(sui->lblSystemKPIGraph5KPIName);

    m_listSystemKPIGraphValueSetNames.push_back(sui->lblSystemKPIGraph1ValueSetname);
    m_listSystemKPIGraphValueSetNames.push_back(sui->lblSystemKPIGraph2ValueSetname);
    m_listSystemKPIGraphValueSetNames.push_back(sui->lblSystemKPIGraph3ValueSetname);
    m_listSystemKPIGraphValueSetNames.push_back(sui->lblSystemKPIGraph4ValueSetname);
    m_listSystemKPIGraphValueSetNames.push_back(sui->lblSystemKPIGraph5ValueSetname);

    m_listSystemKPIGraphUnits.push_back(sui->lblSystemKPIGraph1KPIUnit);
    m_listSystemKPIGraphUnits.push_back(sui->lblSystemKPIGraph2KPIUnit);
    m_listSystemKPIGraphUnits.push_back(sui->lblSystemKPIGraph3KPIUnit);
    m_listSystemKPIGraphUnits.push_back(sui->lblSystemKPIGraph4KPIUnit);
    m_listSystemKPIGraphUnits.push_back(sui->lblSystemKPIGraph5KPIUnit);

    m_listSystemKPIGraphValues.push_back(sui->lblSystemKPIGraph1KPIValue);
    m_listSystemKPIGraphValues.push_back(sui->lblSystemKPIGraph2KPIValue);
    m_listSystemKPIGraphValues.push_back(sui->lblSystemKPIGraph3KPIValue);
    m_listSystemKPIGraphValues.push_back(sui->lblSystemKPIGraph4KPIValue);
    m_listSystemKPIGraphValues.push_back(sui->lblSystemKPIGraph5KPIValue);

    m_listCircularBuffers.push_back(m_circularBuffer1);
    m_listCircularBuffers.push_back(m_circularBuffer1);
    m_listCircularBuffers.push_back(m_circularBuffer1);
    m_listCircularBuffers.push_back(m_circularBuffer1);
    m_listCircularBuffers.push_back(m_circularBuffer1);
}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctNormalKPI1_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI1_T1HoverOn, this);
    sui->uctNormalKPI1_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI1_T1HoverOff, this);

    sui->uctNormalKPI2_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI2_T1HoverOn, this);
    sui->uctNormalKPI2_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI2_T1HoverOff, this);

    sui->uctNormalKPI3_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI3_T1HoverOn, this);
    sui->uctNormalKPI3_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI3_T1HoverOff, this);

    sui->uctNormalKPI4_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI4_T1HoverOn, this);
    sui->uctNormalKPI4_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI4_T1HoverOff, this);

    sui->uctNormalKPI5_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI5_T1HoverOn, this);
    sui->uctNormalKPI5_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI5_T1HoverOff, this);

    sui->uctNormalKPI6_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI6_T1HoverOn, this);
    sui->uctNormalKPI6_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI6_T1HoverOff, this);

    sui->uctNormalKPI7_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI7_T1HoverOn, this);
    sui->uctNormalKPI7_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI7_T1HoverOff, this);

    sui->uctNormalKPI8_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI8_T1HoverOn, this);
    sui->uctNormalKPI8_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI8_T1HoverOff, this);

    sui->uctNormalKPI9_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI9_T1HoverOn, this);
    sui->uctNormalKPI9_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI9_T1HoverOff, this);

    sui->uctNormalKPI10_T1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI10_T1HoverOn, this);
    sui->uctNormalKPI10_T1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI10_T1HoverOff, this);

    sui->uctNormalKPI1_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI1_T2HoverOn, this);
    sui->uctNormalKPI1_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI1_T2HoverOff, this);

    sui->uctNormalKPI2_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI2_T2HoverOn, this);
    sui->uctNormalKPI2_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI2_T2HoverOff, this);

    sui->uctNormalKPI3_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI3_T2HoverOn, this);
    sui->uctNormalKPI3_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI3_T2HoverOff, this);

    sui->uctNormalKPI4_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI4_T2HoverOn, this);
    sui->uctNormalKPI4_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI4_T2HoverOff, this);

    sui->uctNormalKPI5_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI5_T2HoverOn, this);
    sui->uctNormalKPI5_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI5_T2HoverOff, this);

    sui->uctNormalKPI6_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI6_T2HoverOn, this);
    sui->uctNormalKPI6_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI6_T2HoverOff, this);

    sui->uctNormalKPI7_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI7_T2HoverOn, this);
    sui->uctNormalKPI7_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI7_T2HoverOff, this);

    sui->uctNormalKPI8_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI8_T2HoverOn, this);
    sui->uctNormalKPI8_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI8_T2HoverOff, this);

    sui->uctNormalKPI9_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI9_T2HoverOn, this);
    sui->uctNormalKPI9_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI9_T2HoverOff, this);

    sui->uctNormalKPI10_T2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI10_T2HoverOn, this);
    sui->uctNormalKPI10_T2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI10_T2HoverOff, this);

    sui->uctConsumable1->hoverEntered = boost::bind(&DashboardView::onConsumable1HoverOn, this);
    sui->uctConsumable1->hoverLeft = boost::bind(&DashboardView::onConsumable1HoverOff, this);

    sui->uctConsumable2->hoverEntered = boost::bind(&DashboardView::onConsumable2HoverOn, this);
    sui->uctConsumable2->hoverLeft = boost::bind(&DashboardView::onConsumable2HoverOff, this);

    sui->uctConsumable3->hoverEntered = boost::bind(&DashboardView::onConsumable3HoverOn, this);
    sui->uctConsumable3->hoverLeft = boost::bind(&DashboardView::onConsumable3HoverOff, this);

    sui->uctConsumable4->hoverEntered = boost::bind(&DashboardView::onConsumable4HoverOn, this);
    sui->uctConsumable4->hoverLeft = boost::bind(&DashboardView::onConsumable4HoverOff, this);

    sui->uctConsumable5->hoverEntered = boost::bind(&DashboardView::onConsumable5HoverOn, this);
    sui->uctConsumable5->hoverLeft = boost::bind(&DashboardView::onConsumable5HoverOff, this);

    sui->uctConsumable6->hoverEntered = boost::bind(&DashboardView::onConsumable6HoverOn, this);
    sui->uctConsumable6->hoverLeft = boost::bind(&DashboardView::onConsumable6HoverOff, this);

    sui->uctConsumable7->hoverEntered = boost::bind(&DashboardView::onConsumable7HoverOn, this);
    sui->uctConsumable7->hoverLeft = boost::bind(&DashboardView::onConsumable7HoverOff, this);

    sui->uctConsumable8->hoverEntered = boost::bind(&DashboardView::onConsumable8HoverOn, this);
    sui->uctConsumable8->hoverLeft = boost::bind(&DashboardView::onConsumable8HoverOff, this);

    sui->uctConsumable9->hoverEntered = boost::bind(&DashboardView::onConsumable9HoverOn, this);
    sui->uctConsumable9->hoverLeft = boost::bind(&DashboardView::onConsumable9HoverOff, this);

    m_timer->timeout = boost::bind(&DashboardView::onTimeout, this);
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOnStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_name->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_category->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_time->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_value->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_unit->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_OFF);
    p_name->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_PLAIN_TEXT);
    p_category->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
    p_time->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
    p_value->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_PLAIN_TEXT);
    p_unit->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI1_T1, sui->lblNormalKPI1Name_T1, sui->lblTimeKPI1Updated_T1, sui->lblTimeKPI1LastUpdated_T1, sui->lblNormalKPI1Value_T1, sui->lblNormalKPI1Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI1_T1, sui->lblNormalKPI1Name_T1, sui->lblTimeKPI1Updated_T1, sui->lblTimeKPI1LastUpdated_T1, sui->lblNormalKPI1Value_T1, sui->lblNormalKPI1Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI2_T1, sui->lblNormalKPI2Name_T1, sui->lblTimeKPI2Updated_T1, sui->lblTimeKPI2LastUpdated_T1, sui->lblNormalKPI2Value_T1, sui->lblNormalKPI2Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI2_T1, sui->lblNormalKPI2Name_T1, sui->lblTimeKPI2Updated_T1, sui->lblTimeKPI2LastUpdated_T1, sui->lblNormalKPI2Value_T1, sui->lblNormalKPI2Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI3_T1, sui->lblNormalKPI3Name_T1, sui->lblTimeKPI3Updated_T1, sui->lblTimeKPI3LastUpdated_T1, sui->lblNormalKPI3Value_T1, sui->lblNormalKPI3Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI3_T1, sui->lblNormalKPI3Name_T1, sui->lblTimeKPI3Updated_T1, sui->lblTimeKPI3LastUpdated_T1, sui->lblNormalKPI3Value_T1, sui->lblNormalKPI3Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI4_T1, sui->lblNormalKPI4Name_T1, sui->lblTimeKPI4Updated_T1, sui->lblTimeKPI4LastUpdated_T1, sui->lblNormalKPI4Value_T1, sui->lblNormalKPI4Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI4_T1, sui->lblNormalKPI4Name_T1, sui->lblTimeKPI4Updated_T1, sui->lblTimeKPI4LastUpdated_T1, sui->lblNormalKPI4Value_T1, sui->lblNormalKPI4Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI5_T1, sui->lblNormalKPI5Name_T1, sui->lblTimeKPI5Updated_T1, sui->lblTimeKPI5LastUpdated_T1, sui->lblNormalKPI5Value_T1, sui->lblNormalKPI5Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI5_T1, sui->lblNormalKPI5Name_T1, sui->lblTimeKPI5Updated_T1, sui->lblTimeKPI5LastUpdated_T1, sui->lblNormalKPI5Value_T1, sui->lblNormalKPI5Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI6_T1, sui->lblNormalKPI6Name_T1, sui->lblTimeKPI6Updated_T1, sui->lblTimeKPI6LastUpdated_T1, sui->lblNormalKPI6Value_T1, sui->lblNormalKPI6Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI6_T1, sui->lblNormalKPI6Name_T1, sui->lblTimeKPI6Updated_T1, sui->lblTimeKPI6LastUpdated_T1, sui->lblNormalKPI6Value_T1, sui->lblNormalKPI6Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI7_T1, sui->lblNormalKPI7Name_T1, sui->lblTimeKPI7Updated_T1, sui->lblTimeKPI7LastUpdated_T1, sui->lblNormalKPI7Value_T1, sui->lblNormalKPI7Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI7_T1, sui->lblNormalKPI7Name_T1, sui->lblTimeKPI7Updated_T1, sui->lblTimeKPI7LastUpdated_T1, sui->lblNormalKPI7Value_T1, sui->lblNormalKPI7Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI8_T1, sui->lblNormalKPI8Name_T1, sui->lblTimeKPI8Updated_T1, sui->lblTimeKPI8LastUpdated_T1, sui->lblNormalKPI8Value_T1, sui->lblNormalKPI8Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI8_T1, sui->lblNormalKPI8Name_T1, sui->lblTimeKPI8Updated_T1, sui->lblTimeKPI8LastUpdated_T1, sui->lblNormalKPI8Value_T1, sui->lblNormalKPI8Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI9_T1, sui->lblNormalKPI9Name_T1, sui->lblTimeKPI9Updated_T1, sui->lblTimeKPI9LastUpdated_T1, sui->lblNormalKPI9Value_T1, sui->lblNormalKPI9Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI9_T1, sui->lblNormalKPI9Name_T1, sui->lblTimeKPI9Updated_T1, sui->lblTimeKPI9LastUpdated_T1, sui->lblNormalKPI9Value_T1, sui->lblNormalKPI9Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10_T1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI10_T1, sui->lblNormalKPI10Name_T1, sui->lblTimeKPI10Updated_T1, sui->lblTimeKPI10LastUpdated_T1, sui->lblNormalKPI10Value_T1, sui->lblNormalKPI10Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10_T1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI10_T1, sui->lblNormalKPI10Name_T1, sui->lblTimeKPI10Updated_T1, sui->lblTimeKPI10LastUpdated_T1, sui->lblNormalKPI10Value_T1, sui->lblNormalKPI10Unit_T1);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI1_T2, sui->lblNormalKPI1Name_T2, sui->lblTimeKPI1Updated_T2, sui->lblTimeKPI1LastUpdated_T2, sui->lblNormalKPI1Value_T2, sui->lblNormalKPI1Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI1_T2, sui->lblNormalKPI1Name_T2, sui->lblTimeKPI1Updated_T2, sui->lblTimeKPI1LastUpdated_T2, sui->lblNormalKPI1Value_T2, sui->lblNormalKPI1Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI2_T2, sui->lblNormalKPI2Name_T2, sui->lblTimeKPI2Updated_T2, sui->lblTimeKPI2LastUpdated_T2, sui->lblNormalKPI2Value_T2, sui->lblNormalKPI2Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI2_T2, sui->lblNormalKPI2Name_T2, sui->lblTimeKPI2Updated_T2, sui->lblTimeKPI2LastUpdated_T2, sui->lblNormalKPI2Value_T2, sui->lblNormalKPI2Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI3_T2, sui->lblNormalKPI3Name_T2, sui->lblTimeKPI3Updated_T2, sui->lblTimeKPI3LastUpdated_T2, sui->lblNormalKPI3Value_T2, sui->lblNormalKPI3Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI3_T2, sui->lblNormalKPI3Name_T2, sui->lblTimeKPI3Updated_T2, sui->lblTimeKPI3LastUpdated_T2, sui->lblNormalKPI3Value_T2, sui->lblNormalKPI3Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI4_T2, sui->lblNormalKPI4Name_T2, sui->lblTimeKPI4Updated_T2, sui->lblTimeKPI4LastUpdated_T2, sui->lblNormalKPI4Value_T2, sui->lblNormalKPI4Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI4_T2, sui->lblNormalKPI4Name_T2, sui->lblTimeKPI4Updated_T2, sui->lblTimeKPI4LastUpdated_T2, sui->lblNormalKPI4Value_T2, sui->lblNormalKPI4Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI5_T2, sui->lblNormalKPI5Name_T2, sui->lblTimeKPI5Updated_T2, sui->lblTimeKPI5LastUpdated_T2, sui->lblNormalKPI5Value_T2, sui->lblNormalKPI5Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI5_T2, sui->lblNormalKPI5Name_T2, sui->lblTimeKPI5Updated_T2, sui->lblTimeKPI5LastUpdated_T2, sui->lblNormalKPI5Value_T2, sui->lblNormalKPI5Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI6_T2, sui->lblNormalKPI6Name_T2, sui->lblTimeKPI6Updated_T2, sui->lblTimeKPI6LastUpdated_T2, sui->lblNormalKPI6Value_T2, sui->lblNormalKPI6Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI6_T2, sui->lblNormalKPI6Name_T2, sui->lblTimeKPI6Updated_T2, sui->lblTimeKPI6LastUpdated_T2, sui->lblNormalKPI6Value_T2, sui->lblNormalKPI6Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI7_T2, sui->lblNormalKPI7Name_T2, sui->lblTimeKPI7Updated_T2, sui->lblTimeKPI7LastUpdated_T2, sui->lblNormalKPI7Value_T2, sui->lblNormalKPI7Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI7_T2, sui->lblNormalKPI7Name_T2, sui->lblTimeKPI7Updated_T2, sui->lblTimeKPI7LastUpdated_T2, sui->lblNormalKPI7Value_T2, sui->lblNormalKPI7Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI8_T2, sui->lblNormalKPI8Name_T2, sui->lblTimeKPI8Updated_T2, sui->lblTimeKPI8LastUpdated_T2, sui->lblNormalKPI8Value_T2, sui->lblNormalKPI8Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI8_T2, sui->lblNormalKPI8Name_T2, sui->lblTimeKPI8Updated_T2, sui->lblTimeKPI8LastUpdated_T2, sui->lblNormalKPI8Value_T2, sui->lblNormalKPI8Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI9_T2, sui->lblNormalKPI9Name_T2, sui->lblTimeKPI9Updated_T2, sui->lblTimeKPI9LastUpdated_T2, sui->lblNormalKPI9Value_T2, sui->lblNormalKPI9Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI9_T2, sui->lblNormalKPI9Name_T2, sui->lblTimeKPI9Updated_T2, sui->lblTimeKPI9LastUpdated_T2, sui->lblNormalKPI9Value_T2, sui->lblNormalKPI9Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10_T2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI10_T2, sui->lblNormalKPI10Name_T2, sui->lblTimeKPI10Updated_T2, sui->lblTimeKPI10LastUpdated_T2, sui->lblNormalKPI10Value_T2, sui->lblNormalKPI10Unit_T2);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10_T2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI10_T2, sui->lblNormalKPI10Name_T2, sui->lblTimeKPI10Updated_T2, sui->lblTimeKPI10LastUpdated_T2, sui->lblNormalKPI10Value_T2, sui->lblNormalKPI10Unit_T2);
}
void IGSxGUI::DashboardView::setConsumableHoverOnStyle(SUI::GroupBox* p_GroupBox,  SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_name->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_time->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_value->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_unit->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
}

void IGSxGUI::DashboardView::setConsumableHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_OFF);
    p_name->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT);
    p_time->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT);
    p_value->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT);
    p_unit->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT);
}
void IGSxGUI::DashboardView::onConsumable1HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable1HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::onConsumable10HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable10, sui->lblConsumable10Name, sui->lblConsumable10Time, sui->lblConsumable10Value, sui->lblConsumable10Unit);
}
void IGSxGUI::DashboardView::onConsumable10HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable10, sui->lblConsumable10Name, sui->lblConsumable10Time, sui->lblConsumable10Value, sui->lblConsumable10Unit);
}
void IGSxGUI::DashboardView::init()
{
    sui->scbTimeSlider->setMaxValue(SCROLLBAR_MAX_VALUE);
    sui->scbTimeSlider->setMinValue(SCROLLBAR_MIN_VALUE);
    sui->scbTimeSlider->setValue(m_slider_value_backup);
    sui->scbTimeSlider->valueChanged =  boost::bind(&DashboardView::onSliderValueChanged, this);
    addSliderTimes();
    buildHistogramGraphs();
    buildKPITable();
    buildConsumableTable();
    m_timer->start(TIMER_INTERVAL);
}
