/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxLOG.hpp"
#include <SUIButton.h>
#include <SUILineEdit.h>
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUITableWidget.h>
#include <IGSxGUIxUtil.hpp>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";

IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager */*pMachineconstantsManager*/):
    sui(new SUI::MachineconstantsView)
{
}


IGSxGUI::MachineconstantsView::~MachineconstantsView()
{
}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(MACHINECONSTANTSVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    init();
    IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::updateStatus(const std::string &, const IGS::Result &/*result*/)
{
}

void IGSxGUI::MachineconstantsView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::MachineconstantsView::init()
{
    sui->lneSearchParameterText->textEdited = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->btnSearchParameter->hoverEntered = boost::bind(&MachineconstantsView::onSearchButtonHoverEntered, this);
    sui->btnSearchParameter->hoverLeft = boost::bind(&MachineconstantsView::onSearchButtonHoverLeft, this);
    sui->btnSearchClear->hoverEntered = boost::bind(&MachineconstantsView::onSearchClearHoverEntered, this);
    sui->btnSearchClear->hoverLeft = boost::bind(&MachineconstantsView::onSearchClearHoverLeft, this);
    sui->lneSearchParameterText->setText("");
    sui->lneSearchParameterText->setPlaceHolderText("Search parameter");
    sui->btnSearchParameter->setVisible(true);
    sui->btnSearchClear->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, "#AAAAAA", 18);
    sui->tawParameters->showGrid(false);
    for (int i = 0; i < 29; ++i)
    {
        sui->tawParameters->appendRow();
    }
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row)
    {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        IGSxGUI::Util::setParameterUCTNormalStyle(widget);
        IGSxGUI::Util::setTextToUserControl(widget, 0, "LRT/Configuration/ProfibusAdvancedDiagnosticsEnabled (n/a)");
        IGSxGUI::Util::setTextToUserControl(widget, 1, "100");
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        if (row % 2 != 0)
        {
            usercontrol->clicked = boost::bind(&MachineconstantsView::onParameterRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onParameterUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onParameterUCTHoverLeft, this, row);
        }
        else
        {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        }
    }
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row)
    {
        IGSxGUI::Util::setRowHeight(sui->tawParameters, row, 40);
    }
    sui->tawParameters->rowClicked = boost::bind(&MachineconstantsView::onRowPressed, this, _1);
    sui->btnParameterName->hoverEntered = boost::bind(&MachineconstantsView::onParameterNameHoverEntered, this);
    sui->btnParameterName->hoverLeft = boost::bind(&MachineconstantsView::onParameterNameHoverLeft, this);
    sui->btnParameterValue->hoverEntered = boost::bind(&MachineconstantsView::onParameterValueHoverEntered, this);
    sui->btnParameterValue->hoverLeft = boost::bind(&MachineconstantsView::onParameterValueHoverLeft, this);
}
void IGSxGUI::MachineconstantsView::onRowPressed(int row)
{
    IGSxGUI::Util::selectRow(sui->tawParameters, row);
}
void IGSxGUI::MachineconstantsView::onParameterNameHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, true);
}
void IGSxGUI::MachineconstantsView::onParameterNameHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, false);
}
void IGSxGUI::MachineconstantsView::onParameterValueHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, true);
}
void IGSxGUI::MachineconstantsView::onParameterValueHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, false);
}
void IGSxGUI::MachineconstantsView::onParameterRowPressed(int row)
{
    IGSxGUI::ParameterpopupView *parameterview = new IGSxGUI::ParameterpopupView;
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getADTNameFromUserControl(widget);
    boost::trim(name);
    parameterview->setParameterName(name);
    parameterview->show();
    for (int i = 0; i < sui->tawParameters->rowCount(); ++i )
    {
        if ( i % 2 != 0)
        {
            IGSxGUI::Util::setParameterUCTNormalStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
        else
        {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
    }
    IGSxGUI::Util::setParameterUCTClickedStyle(sui->tawParameters->getWidgetItem(row, 0));
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverEntered(int row)
{
    for (int i = 0; i < sui->tawParameters->rowCount(); ++i )
    {
        if ( i % 2 != 0)
        {
            IGSxGUI::Util::setParameterUCTNormalStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
        else
        {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
    }
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setADTUCTHoverOnStyle(widget);
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverLeft(int row)
{
    for (int i = 0; i < sui->tawParameters->rowCount(); ++i )
    {
        if ( i % 2 != 0)
        {
            IGSxGUI::Util::setParameterUCTNormalStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
        else
        {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(sui->tawParameters->getWidgetItem(i, 0));
        }
    }
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setADTUCTHoverOffStyle(widget);
}

void IGSxGUI::MachineconstantsView::onSearchButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, "#B3E2FF", 18);
}


void IGSxGUI::MachineconstantsView::onSearchButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, "#AAAAAA", 18);
}

void IGSxGUI::MachineconstantsView::onSearchClearHoverEntered()
{
    if(!sui->btnSearchClear->isVisible())
        std::cout << "Visible" << std::endl;
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, "#B3E2FF", 18);
}


void IGSxGUI::MachineconstantsView::onSearchClearHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
}


void IGSxGUI::MachineconstantsView::onSearchTextEdited(const std::string &text)
{
    sui->btnSearchParameter->setVisible(false);
    sui->btnSearchClear->setVisible(true);
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
    int entriesfound = searchForParameters(text);
    sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " parameters found");

}
void IGSxGUI::MachineconstantsView::onSearchTextEditFinished()
{
    sui->btnSearchClear->setVisible(false);
    sui->btnSearchParameter->setVisible(true);
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, "#AAAAAA", 18);

}
int IGSxGUI::MachineconstantsView::searchForParameters(const std::string &textToSearch)
{
  int result = 16000;
  return result;
}
