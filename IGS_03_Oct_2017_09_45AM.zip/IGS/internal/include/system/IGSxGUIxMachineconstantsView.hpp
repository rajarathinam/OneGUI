
/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIMachineconstantsView.hpp
| Author       : Raja
| Description  : Interface file for Machineconstants View
|
| ! \file        IGSxGUIxICPDView.hpp
| ! \brief       Interface file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{

class MachineconstantsView : public IMachineconstantsView
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const std::string&, const IGS::Result& /*result*/);
    virtual void setActive(bool);
    void onRowPressed(int row);
    void onParameterNameHoverEntered();
    void onParameterNameHoverLeft();
    void onParameterValueHoverEntered();
    void onParameterValueHoverLeft();

    void onParameterRowPressed(int row);
    void onParameterUCTHoverEntered(int row);
    void onParameterUCTHoverLeft(int row);
    void onSearchButtonHoverEntered();
    void onSearchButtonHoverLeft();
    void onSearchTextEdited(const std::string &text);
    void onSearchTextEditFinished();
    void onSearchClearHoverLeft();
    void onSearchClearHoverEntered();
private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);
    void init();

    SUI::MachineconstantsView *sui;
    IGSxGUI::ParameterpopupView parameterview;

    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;

    int searchForParameters(const std::string &textToSearch);
};
}  // namespace IGSxGUI
#endif // IGSXGUIXMACHINECONSTANTSVIEW_HPP
