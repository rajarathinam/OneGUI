#ifndef IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
#define IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
//----------------------------------------------------------------------------|
//                          Forward Declarations                              |
//----------------------------------------------------------------------------|
namespace IGSxGUI {
        class ParameterpopupView;
} //namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class LineEdit;
class Button;
class Label;

class ParameterpopupView
{
private:
        ParameterpopupView();

    void setupSUI(const char *xmlFileName);
    void setupSUIContainer(const char *xmlFileName, SUI::Container *container);
    void loadObjects(SUI::ObjectList *objectList);

    SUI::Dialog *dialog;
    SUI::Button *btnCancel;
    SUI::Button *btnClose;
    SUI::Button *btnReset;
    SUI::Button *btnUpdate;
    SUI::Label *lblDefaultValue;
    SUI::Label *lblDefaultValueNumber;
    SUI::Label *lblParameterName;
    SUI::Label *lblValue;
    SUI::LineEdit *lneValue;

        friend class ::IGSxGUI::ParameterpopupView;
};
} //namespace SUI
#endif // IGSXGUIXMOC_PARAMETERPOPUPVIEW_HPP
