/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCNF_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxCNF stub
|
| ! \file        IGSxCNF_impl.hpp
| ! \brief       Header file for IGSxCNF stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCNF_IMPL_HPP
#define IGSXCNF_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxCNF.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxCNF {

class CNF_Stub :public Configuration
{
 public:
    static Configuration* getInstance();

    virtual std::string getMachineId();
    virtual std::string getReleaseId();

 protected:
    CNF_Stub(){}
    virtual ~CNF_Stub() {}
};
}  // namespace IGSxCNF
#endif  // IGSXCNF_IMPL_HPP
