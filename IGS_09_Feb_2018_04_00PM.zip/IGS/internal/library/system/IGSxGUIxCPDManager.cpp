/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.cpp
| Author       : Venugopal S
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxCPDManager.cpp
| ! \brief       CPD Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>
#include "IGSxGUIxCPDManager.hpp"
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDManager::STRING_CANNOT_START = "Can\'t open CPD";
const int IGSxGUI::CPDManager::MAX_NR_REPORTS = 5;

IGSxGUI::CPDManager::CPDManager() :
     m_runningCPD(NULL)
{
}

IGSxGUI::CPDManager::~CPDManager()
{
    try
    {
        IGSxCPD::CPD::getInstance()->unregisterCpdFinishedCallback();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (std::vector<CPD*>::iterator it = m_CPDs.begin() ; it != m_CPDs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_CPDs.clear();
}

void IGSxGUI::CPDManager::initialize()
{
    IGSxCPD::MetaDescriptions metaDescriptions;
    try
    {
        IGSxCPD::CPD::getInstance()->getCpds(metaDescriptions);
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        // Trim the spaces
        IGSxCPD::MetaDescription  metaDescription = metaDescriptions[i];
        std::string name = boost::trim_copy(metaDescription.name());
        std::string testtype = boost::trim_copy(metaDescription.testType());
        std::string subsystem = boost::trim_copy(metaDescription.subSystem());
        std::string description = boost::trim_copy(metaDescription.description());
        std::string descriptionFile = boost::trim_copy(metaDescription.htmlFile());
        IGSxCPD::MetaDescription newMetaDescription(name, testtype, subsystem, description, descriptionFile);

        CPD* cpd = new CPD(newMetaDescription);
        if (cpd != NULL)
        {
            add(cpd);
        }
    }

    try
    {
        IGSxCPD::CPD::getInstance()->registerCpdFinishedCallback(boost::bind(&CPDManager::onStopped, this, _1));
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }
}

bool IGSxGUI::CPDManager::add(CPD* cpd)
{
    if (cpd != NULL)
    {
        for (size_t i = 0; i < m_CPDs.size(); i++)
        {
            if (m_CPDs[i]->getName() == cpd->getName())
            {
                // CPD with the name already exists, So need not add
                return false;
            }
        }
        m_CPDs.push_back(cpd);
        return true;
    }
    return false;
}

bool IGSxGUI::CPDManager::remove(CPD* cpd)
{
    if (cpd != NULL)
    {
        for (size_t i = 0; i < m_CPDs.size(); i++)
        {
            if (m_CPDs[i]->getName() == cpd->getName())
            {
                m_CPDs.erase(std::remove(m_CPDs.begin(), m_CPDs.end(), cpd), m_CPDs.end());

                delete cpd;
                cpd = NULL;

                return true;
            }
        }
    }
    return false;
}

bool IGSxGUI::CPDManager::openCPD(const std::string &cpdName)
{
    bool bReturn = false;
    m_runningCPD = getCPD(cpdName);

    if (m_runningCPD != NULL)
    {
        bReturn = m_runningCPD->start();

        if (!bReturn)
        {
            if (!m_messageDisplay.empty())
            {
                m_messageDisplay(STRING_CANNOT_START);
            }
        }
    }
    return bReturn;
}

IGSxGUI::CPD *IGSxGUI::CPDManager::getCPD(const std::string &name) const
{
    CPD* cpd = NULL;

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (m_CPDs[i]->getName() == name)
        {
            cpd = m_CPDs[i];
            break;
        }
    }
    return cpd;
}

std::vector<IGSxGUI::CPD*> IGSxGUI::CPDManager::retrieveAll() const
{
    return m_CPDs;
}

void IGSxGUI::CPDManager::retrieveCPDTestResults(const std::string& cpdname, IGSxCPD::TestResultList& testResults) const
{
    IGSxCPD::CPD::getInstance()->getLatestTestResults(cpdname, MAX_NR_REPORTS, testResults);
}

void IGSxGUI::CPDManager::onStopped(const IGS::Result &result) const
{
    if (result != 0) {
       if (!m_messageDisplay.empty())
       {
           m_messageDisplay(STRING_CANNOT_START);
       }
    }
    m_runningCPD->onStopped(result);
}

boost::signals2::connection IGSxGUI::CPDManager::registerToMessageDisplayCallback(const messageDisplayCallback &cb)
{
    return m_messageDisplay.connect(cb);
}

IGSxGUI::CPD *IGSxGUI::CPDManager::retrieveRunningCPD() const
{
    std::string currentTest;
    try
    {
        currentTest = IGSxCPD::CPD::getInstance()->getCurrentCpd();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (currentTest == m_CPDs[i]->getName())
        {
            return m_CPDs[i];
        }
    }
    return NULL;
}















