/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.cpp
| Author       : Raja
| Description  : Machine constants manager Implementation
|
| ! \file        IGSxGUIxMachineconstantsManager.cpp
| ! \brief       Machine constants Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <string>
#include <vector>
#include "IGSxPAR.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

namespace {
// helper classes
class Visitor : public IGSxPAR::IParameterTypeVisitor
{
 private:
    std::vector<IGSxGUI::ParameterData>* m_parameterData;

 public:
    explicit Visitor(std::vector<IGSxGUI::ParameterData>* parameterData)
    {
        m_parameterData = parameterData;
    }

    virtual void visit(const IGSxPAR::IntType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.name(), type.value(), type.config().def(), !type.writeAccess()));
    }

    virtual void visit(const IGSxPAR::UIntType& /*type*/ ) {}
    virtual void visit(const IGSxPAR::FloatType& /*type*/ ) {}
    virtual void visit(const IGSxPAR::BoolType& /*type*/ ) {}
    virtual void visit(const IGSxPAR::FloatArrayType& /*type*/ ) {}
};
}  // namespace



IGSxGUI::Node::Node(std::string name, int level, Node* parentNode) :
    m_name(name), m_level(level), m_parentNode(parentNode)
{
}

IGSxGUI::Node::~Node() {

    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i)
    {
        delete m_childNodes[i];
    }
    m_childNodes.clear();
}


const std::string IGSxGUI::Node::getName() const
{
    return m_name;
}

IGSxGUI::Node* IGSxGUI::Node::getParentNode()
{
    return m_parentNode;
}

IGSxGUI::Node* IGSxGUI::Node::findChildNode(const std::string& name)
{
    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i)
    {
        if (m_childNodes[i]->getName() == name)
        {
            return m_childNodes[i];
        }
    }
    return NULL;
}

IGSxGUI::Node* IGSxGUI::Node::addChildNode(const std::string& name)
{
    m_childNodes.push_back(new Node(name, m_level + 1, this));
    return m_childNodes[m_childNodes.size()-1];
}

void IGSxGUI::Node::addParameter(IGSxGUI::ParameterData* parameter)
{
    m_parameters.push_back(parameter);
}

std::vector<IGSxGUI::ParameterData*>& IGSxGUI::Node::getParameters()
{
    return m_parameters;
}

void IGSxGUI::Node::getChildNodeTitles(std::vector<std::string>* targetList )
{
    targetList->clear();
    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i){
        targetList->push_back(m_childNodes[i]->getName());
    }
}


int IGSxGUI::ParameterData::treeLevel = 0;

IGSxGUI::ParameterData::ParameterData(const std::string& name, int currentValue, int defaultValue, bool readOnly) :
  m_name(name), m_defaultValue(defaultValue), m_currentValue(currentValue), m_previousValue(currentValue), m_readOnly(readOnly), m_updated(false)
{
    for (size_t i = 0; i < m_name.size(); ++i) {
        if (m_name[i] == '/')
        {
            m_componentIndexes.push_back(i);
        }
    }
}

IGSxGUI::ParameterData* IGSxGUI::ParameterData::getPtr()
{
    return this;
}


const std::string& IGSxGUI::ParameterData::getName() const
{
    return m_name;
}


std::string IGSxGUI::ParameterData::getDisplayName() const
{
    if (treeLevel <= 0 || static_cast<int>(m_componentIndexes.size()) == 0)
        return m_name;

    if (treeLevel >= static_cast<int>(m_componentIndexes.size()))
        return m_name.substr(m_componentIndexes[m_componentIndexes.size() - 1] + 1);

    return m_name.substr(m_componentIndexes[treeLevel - 1] + 1);
}


std::string IGSxGUI::ParameterData::getComponent(int index) const
{
    if (index < 0 || index >= static_cast<int>(m_componentIndexes.size()))
    {
        return "";
    }
    else if (index == 0)
    {
        return m_name.substr(0, m_componentIndexes[0]);
    }
    else
    {
        return m_name.substr(m_componentIndexes[index - 1] + 1, m_componentIndexes[index] - m_componentIndexes[index - 1] - 1);
    }
}


int IGSxGUI::ParameterData::getComponentCount() const
{
    return m_componentIndexes.size();
}


void IGSxGUI::ParameterData::changeValue(int newValue)
{
    m_currentValue = newValue;
    m_updated = true;
}


void IGSxGUI::ParameterData::revertValue()
{
    m_currentValue = m_previousValue;
    m_updated = false;
}


bool IGSxGUI::ParameterData::isReadOnly() const
{
    return m_readOnly;
}


bool IGSxGUI::ParameterData::isUpdated() const
{
    return m_updated;
}


int IGSxGUI::ParameterData::getCurrentValue() const
{
    return m_currentValue;
}


int IGSxGUI::ParameterData::getDefaultValue() const
{
    return m_defaultValue;
}

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::MachineconstantsManager::MachineconstantsManager()
{
}

IGSxGUI::MachineconstantsManager::~MachineconstantsManager()
{
    if (m_rootNode != NULL) {
        delete m_rootNode;
    }
}

void IGSxGUI::MachineconstantsManager::initialize()
{
    createTableData();
}

void IGSxGUI::MachineconstantsManager::createTableData()
{
    m_tabledata.clear();

    std::string filter;
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::ParameterTypePtrVector parameters;
    inst->Read(filter, parameters);
    Visitor visitor(&m_tabledata);

    for (int i = 0;  i < static_cast<int>(parameters.size()); ++i)
    {
        IGSxPAR::ParameterTypePtr parameter = parameters[i];
        parameter->accept(visitor);
    }

    m_rootNode = new IGSxGUI::Node("Parameters", 0, NULL);
    m_currentNode = m_rootNode;
    m_breadCrumPath.clear();
    m_breadCrumPath.push_back(m_rootNode->getName());

    for (int i = 0; i <  static_cast<int>(m_tabledata.size()); ++i)
    {
        registerNodes(m_tabledata[i].getPtr());
    }
}

void IGSxGUI::MachineconstantsManager::registerNodes(ParameterData* parameter)
{
    Node* parentNode = m_rootNode;
    parentNode->addParameter(parameter);

    for (int i = 0; i < parameter->getComponentCount(); ++i)
    {
        std::string title = parameter->getComponent(i);
        Node* childNode = parentNode->findChildNode(title);
        if (childNode == NULL)
        {
            childNode = parentNode->addChildNode(title);
        }
        childNode->addParameter(parameter);
        parentNode = childNode;
    }
}

int IGSxGUI::MachineconstantsManager::getParameterCount()
{
     return static_cast<int>(m_currentNode->getParameters().size());
}

std::vector<IGSxGUI::ParameterData*> IGSxGUI::MachineconstantsManager::getParameterData()
{
     return m_currentNode->getParameters();
}

IGSxGUI::ParameterData* IGSxGUI::MachineconstantsManager::findParameter(const std::string& name)
{
    if (name.empty())
        return NULL;

    std::vector<IGSxGUI::ParameterData>::iterator it = std::find_if(m_tabledata.begin(), m_tabledata.end(), find_parameter(name));
    return (it != m_tabledata.end()) ? it->getPtr() : NULL;
}

void IGSxGUI::MachineconstantsManager::saveUpdatedParameters(const std::string& userId, const std::string& reason)
{
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::TransactionInfo transactionInfo(userId, reason);
    IGSxPAR::IValuePtrVector values;

    for (size_t i = 0; i < m_tabledata.size(); ++i)
    {
        if (m_tabledata.at(i).isUpdated())
        {
            values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::IntValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue())));
        }
    }

    inst->Write(transactionInfo, values);
}

void IGSxGUI::MachineconstantsManager::cancelUpdatedParameters()
{
    for (size_t i = 0; i < m_tabledata.size(); ++i)
    {
        if (m_tabledata.at(i).isUpdated())
        {
            m_tabledata.at(i).revertValue();
        }
    }
}

int IGSxGUI::MachineconstantsManager::searchForParameters(const std::string& textToSearch, std::vector<ParameterData*>*  matchedparameters)
{
    matchedparameters->clear();
    if (textToSearch.empty()) {
        return 0;
    }

    int count = 0;
    for (int i = 0; i < static_cast<int>(m_tabledata.size()); ++i) {
        if (boost::contains(m_tabledata[i].getDisplayName(), textToSearch)) {
            ++count;
            matchedparameters->push_back(&(m_tabledata[i]));
        }
    }
    return count;
}

void IGSxGUI::MachineconstantsManager::getChildNodeTitles(std::vector<std::string>* childNodeTitles) {

    m_currentNode->getChildNodeTitles(childNodeTitles);
}

void IGSxGUI::MachineconstantsManager::navigateToChild(const std::string& childNodeTitle){

    Node* childNode = m_currentNode->findChildNode(childNodeTitle);
    if (childNode != NULL)
    {
        m_currentNode = childNode;
        m_breadCrumPath.push_back(m_currentNode->getName());
        IGSxGUI::ParameterData::treeLevel++;
    }
}

void IGSxGUI::MachineconstantsManager::navigateBack(){

    if (m_currentNode->getParentNode() != NULL)
    {
        m_currentNode = m_currentNode->getParentNode();
        m_breadCrumPath.erase(m_breadCrumPath.begin() + m_breadCrumPath.size() - 1);
        IGSxGUI::ParameterData::treeLevel--;
    }
}

void IGSxGUI::MachineconstantsManager::navigateToBreadCrum(const std::string& breadCrumTitle){

    Node*  parentNode = m_currentNode->getParentNode();
    while (parentNode != NULL)
    {
        if (parentNode->getName() == breadCrumTitle) {
            m_currentNode = parentNode;
            while (m_breadCrumPath[m_breadCrumPath.size() - 1] != breadCrumTitle && m_breadCrumPath.size() > 1)
            {
                m_breadCrumPath.erase(m_breadCrumPath.begin() + m_breadCrumPath.size() - 1);
                IGSxGUI::ParameterData::treeLevel--;
            }
            return;
        }
    }
}

const std::vector<std::string>& IGSxGUI::MachineconstantsManager::getBreadCrumTitles(){
    return m_breadCrumPath;
}

std::string IGSxGUI::MachineconstantsManager::getCurrentNodeName()
{
  return (m_currentNode->getName());
}
