

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.cpp
| ! \brief       Implementation of Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxWidgets/SUITextArea.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::MachineconstantsView::MachineconstantsView() :
    dialog(NULL),
    btnParameterName(NULL),
    lblParameterNameTooltip(NULL),
    btnParameterValue(NULL),
    lblParameterValueTooltip(NULL),
    lblPendingParameters(NULL),
    btnNoPendingParameters(NULL),
    btnHistory(NULL),
    btnPendingParameterName(NULL),
    lblPendingParameterNameTooltip(NULL),
    btnPendingParameterValue(NULL),
    lblPendingParameterValueTooltip(NULL),
    btnPendingParametersLine(NULL),
    tawParameters(NULL),
    lneSearchParameterText(NULL),
    btnSearchParameter(NULL),
    btnSearchClear(NULL),
    lblEntriesFound(NULL),
    uctSaveButton(NULL),
    lblSaveImage(NULL),
    lblSaveText(NULL),
    scbParametersTable(NULL),
    imvLogo(NULL),
    lblPendingParamSaveName(NULL),
    lnePendingParamSaveName(NULL),
    lblPendingParamSaveChangeReason(NULL),
    txaPendingParamSaveChangeReason(NULL),
    btnPendingParamCancelSave(NULL),
    uctPendingParamFinalSave(NULL),
    lblPendingParamFinalSaveImage(NULL),
    lblPendingParamFinalSaveText(NULL),
    gbxPendingParamFinalSaveButton(NULL),
    lblPendingParamSaveChangeReasonTxtArea(NULL),
    lblPendingParamSaveNameLnEdit(NULL),
    btnPendingParamSaveNameLnEditCancel(NULL),
    lblMachineConstantHeader(NULL),
    lblAllCategories(NULL),
    lblBackImage(NULL),
    lblBack(NULL),
    btnBC1(NULL),
    btnBC2(NULL),
    btnBC3(NULL),
    btnBC4(NULL),
    btnBC5(NULL),
    btnBC6(NULL)
{
}

void SUI::MachineconstantsView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::MachineconstantsView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::MachineconstantsView::loadObjects(ObjectList* objectList)
{
    btnParameterName =  objectList->getObject<Button>("btnParameterName");
    lblParameterNameTooltip = objectList->getObject<Label>("lblParameterNameTooltip");
    btnParameterValue = objectList->getObject<Button>("btnParameterValue");
    lblParameterValueTooltip = objectList->getObject<Label>("lblParameterValueTooltip");
    tawParameters = objectList->getObject<TableWidget>("tawParameters");
    lneSearchParameterText = objectList->getObject<LineEdit>("lneSearchParameterText");
    btnSearchParameter = objectList->getObject<Button>("btnSearchParameter");
    btnSearchClear = objectList->getObject<Button>("btnSearchClear");
    lblEntriesFound = objectList->getObject<Label>("lblEntriesFound");
    scbParametersTable = objectList->getObject<ScrollBar>("scbParametersTable");
    imvLogo = objectList->getObject<GraphicsView>("imvLogo");
    btnCancel = objectList->getObject<Button>("btnCancel");
    uctSaveButton = objectList->getObject<UserControl>("uctSaveButton");
    lblSaveImage = objectList->getObject<Label>("uctSaveButton:lblSaveImage");
    lblSaveText = objectList->getObject<Label>("uctSaveButton:lblSaveText");
    gbxSaveButton = objectList->getObject<GroupBox>("uctSaveButton:gbxSaveButtonUCT");
    lblPendingParameters = objectList->getObject<Label>("lblPendingParameters");
    btnNoPendingParameters = objectList->getObject<Button>("btnNoPendingParameters");
    btnHistory = objectList->getObject<Button>("btnHistory");
    btnPendingParameterName =  objectList->getObject<Button>("btnPendingParameterName");
    lblPendingParameterNameTooltip = objectList->getObject<Label>("lblPendingParameterNameTooltip");
    btnPendingParameterValue = objectList->getObject<Button>("btnPendingParameterValue");
    lblPendingParameterValueTooltip = objectList->getObject<Label>("lblPendingParameterValueTooltip");
    btnPendingParametersLine = objectList->getObject<Button>("btnPendingParametersLine");
    tawMCPendingParam = objectList->getObject<TableWidget>("tawMCPendingParam");
    lblPendingParamSaveName = objectList->getObject<Label>("lblPendingParamSaveName");
    lnePendingParamSaveName = objectList->getObject<LineEdit>("lnePendingParamSaveName");
    lblPendingParamSaveChangeReason = objectList->getObject<Label>("lblPendingParamSaveChangeReason");
    txaPendingParamSaveChangeReason = objectList->getObject<TextArea>("txaPendingParamSaveChangeReason");
    btnPendingParamCancelSave = objectList->getObject<Button>("btnPendingParamCancelSave");
    uctPendingParamFinalSave = objectList->getObject<UserControl>("uctPendingParamFinalSave");
    lblPendingParamFinalSaveImage = objectList->getObject<Label>("uctPendingParamFinalSave:lblSaveImage");
    lblPendingParamFinalSaveText = objectList->getObject<Label>("uctPendingParamFinalSave:lblSaveText");
    gbxPendingParamFinalSaveButton = objectList->getObject<GroupBox>("uctPendingParamFinalSave:gbxSaveButtonUCT");
    lblPendingParamSaveChangeReasonTxtArea = objectList->getObject<Label>("lblPendingParamSaveChangeReasonTxtArea");
    lblPendingParamSaveNameLnEdit = objectList->getObject<Label>("lblPendingParamSaveNameLnEdit");
    btnPendingParamSaveNameLnEditCancel = objectList->getObject<Button>("btnPendingParamSaveNameLnEditCancel");
    tawParameterTree = objectList->getObject<TableWidget>("tawParameterTree");
    lblMachineConstantHeader = objectList->getObject<Label>("lblMachineConstantHeader");
    lblAllCategories = objectList->getObject<Label>("lblAllCategories");
    lblBackImage = objectList->getObject<Label>("lblBackImage");
    lblBack = objectList->getObject<Label>("lblBack");

    btnBC1 = objectList->getObject<Button>("btnBC1");
    btnBC2 = objectList->getObject<Button>("btnBC2");
    btnBC3 = objectList->getObject<Button>("btnBC3");
    btnBC4 = objectList->getObject<Button>("btnBC4");
    btnBC5 = objectList->getObject<Button>("btnBC5");
    btnBC6 = objectList->getObject<Button>("btnBC6");
}
#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
