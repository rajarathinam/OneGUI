/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include <numeric>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIWebView.h>
#include <FWQxCore/SUIResourcePath.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxUtils/SUITimer.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = "IGSxGUIxADT.xml";
const std::string IGSxGUI::ADTView::STRING_EMPTY = "";
const std::string IGSxGUI::ADTView::STRING_SINGLESPACE = " ";
const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "ALL ADTs";
const std::string IGSxGUI::ADTView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::ADTView::STRING_ADTVIEW_SHOWN = "ADTView is shown.";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::ADTView::STRING_ADTSUBSYSTEM_STYLE = "adtsubsystem";
const std::string IGSxGUI::ADTView::STRING_SLASH = " / ";
const std::string IGSxGUI::ADTView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::ADTView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::ADTView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const std::string IGSxGUI::ADTView::CUSTOM_STYLESHEET = "customCss.css";
const std::string IGSxGUI::ADTView::STRING_ADT_ALREADY_RUNNING = "ADT is already running";
const std::string IGSxGUI::ADTView::STRING_ADT_SHOWING = "Opening ADT...";
const std::string IGSxGUI::ADTView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const char IGSxGUI::ADTView::NEWLINE_CHAR = '\n';
const char* IGSxGUI::ADTView::STRING_ADT_MESSAGE = "Start ADT button pressed, Adt Name: ";
const int IGSxGUI::ADTView::ADTSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::ADTView::AWESOME_ANGLE_SIZE = 22;
const int IGSxGUI::ADTView::ADTTABLE_ROW_SIZE = 62;
const int IGSxGUI::ADTView::NORMAL_SUBSYSTEM_ROW_SIZE = 40;
const int IGSxGUI::ADTView::EXTENDED_SUBSYSTEM_ROW_SIZE = 70;
const std::string::size_type IGSxGUI::ADTView::MAX_SUBSYSTEM_CHARS_PER_CELL = 21;

namespace IGSxGUI
{
bool stringcomparator(const std::string &lhs, const std::string &rhs )
{
    std::string left = boost::to_upper_copy(lhs);
    std::string right = boost::to_upper_copy(rhs);
    return (left.compare(right) <= 0);
}

bool ADTComparator(const ADT *adtLeft, const ADT *adtRight)
{
    std::string str1 = adtLeft->getName();
    std::string str2 = adtRight->getName();
    return (stringcomparator(str1, str2));
}
}  // namespace  IGSxGUI
IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_bRunningADT(false),
    m_isDescFolded(true),
    m_isCloseButtonPressed(false),
    m_isInternalCallToSubsystemPressed(false),
    m_selectedAdt(""),
    m_selectedSubSystem(""),
    m_selectedAdtRowNum(-1),
    m_selectedSubsystemRowNum(-1),
    m_startingAdtTimer(SUI::Timer::createTimer())
{
    m_presenter = new ADTPresenter(this, pADTManager);
    m_startingAdtTimer->setSingleShot(true);
    m_startingAdtTimer->timeout = boost::bind(&ADTView::onShowADTStartingTimeout, this);
}

IGSxGUI::ADTView::~ADTView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    if (bIsFirstTimeDisplay)
    {
        init();
    } else {
        reload();
    }
    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
    IGS_INFO(STRING_ADTVIEW_SHOWN);
}

void IGSxGUI::ADTView::init()
{
    initCommon();
    m_selectedSubSystem = STRING_ALL_ADTS;
    sui->lblAllADTs->setText(STRING_ALL_ADTS);
    m_listADT = m_presenter->getADTs();
    IGSxGUI::Util::selectRow(sui->tawADTSubsystem, 0);
    loadADTTable(m_listADT);
}

void IGSxGUI::ADTView::initCommon()
{
    sui->tawADTSubsystem->showGrid(false);
    sui->tawADT->showGrid(false);

    IGSxGUI::Util::addCustomStylesheet(sui->wvwADTHTMLDescription, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));

    loadSubSystemTable();
}

void IGSxGUI::ADTView::onSubsystemPressed()
{
    if (m_isCloseButtonPressed) {
        return;
    }
    if (!m_isInternalCallToSubsystemPressed) {
        m_selectedAdt = "";
        m_selectedAdtRowNum = -1;
    }
    std::vector<int> items = sui->tawADTSubsystem->getSelectedRows();
    if (items.size() > 0) {
        m_selectedSubsystemRowNum = items[0];
        if (m_selectedSubsystemRowNum == 0) {
            m_selectedSubSystem = STRING_ALL_ADTS;
            sui->lblAllADTs->setText(STRING_ALL_ADTS);
            m_listADT = m_presenter->getADTs();
            loadADTTable(m_listADT);
        } else {
            m_selectedSubSystem = m_listStringSubsystem[m_selectedSubsystemRowNum - 1];
            sui->lblAllADTs->setText(STRING_ALL_ADTS + STRING_SLASH + m_selectedSubSystem);
            std::vector<ADT*> listSelectedSubsystemADTs = getSelectedSubSystemADTs();
            loadADTTable(listSelectedSubsystemADTs);
            showRightPane(false, "");
        }
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    size_t subsystemSize = m_listSubsystems.size();
    for (size_t i = 0 ; i < subsystemSize; ++i) {
        container subsys = m_listSubsystems[i];
        if (subsys.name == m_selectedSubSystem) {
            listSubsystemADTs.push_back(subsys.adt);
        }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::loadADTTable(std::vector<ADT *> listADT)
{
    if (listADT.size() > 0)
    {
        std::sort(listADT.begin(), listADT.end(), IGSxGUI::ADTComparator);
        sui->tawADT->setVisible(true);
        sui->tawADT->removeRows(1, sui->tawADT->rowCount()-1);
        for (size_t i = 0 ; i < (listADT.size() - 1); ++i) {
            sui->tawADT->appendRow();
        }
        for (int row = 0; row < sui->tawADT->rowCount(); ++row)
        {
            SUI::Widget *widget = sui->tawADT->getWidgetItem(row, 0);
            IGSxGUI::Util::setADTUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&ADTView::onTableADTRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&ADTView::onADTUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&ADTView::onADTUCTHoverLeft, this, row);

            IGSxGUI::Util::setTextToADTUserControl(widget, 0, listADT[row]->getName());
            IGSxGUI::Util::setTextToADTUserControl(widget, 1, listADT[row]->getDescription());
            IGSxGUI::Util::setTextToADTUserControl(widget, 2, STRING_EMPTY);
            IGSxGUI::Util::setRowHeight(sui->tawADT, row, ADTTABLE_ROW_SIZE);
        }
        IGSxGUI::Util::clearSelection(sui->tawADT);
    } else {
        sui->tawADT->setVisible(false);
    }
}

void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(const IGS::Result &result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;
    }
}

std::string IGSxGUI::ADTView::formatSubsystemName(const std::string& subsystemname)
{
    std::string strMultiLine = subsystemname;
    if (subsystemname.length() > MAX_SUBSYSTEM_CHARS_PER_CELL)
    {
        static const int MagicNumber = 6;
        for (int i = static_cast<int>(MAX_SUBSYSTEM_CHARS_PER_CELL) - 1; i > MagicNumber; --i)
        {
            char ch = subsystemname.at(i);
            if (ch == ' ')
            {
                strMultiLine = subsystemname.substr(0, i) + NEWLINE_CHAR +
                        formatSubsystemName(subsystemname.substr(i + 1));
                break;
            }
            if (::isupper(ch))
            {
                strMultiLine = subsystemname.substr(0, i) + NEWLINE_CHAR +
                        formatSubsystemName(subsystemname.substr(i));
                break;
            }
        }
        if (strMultiLine == subsystemname)
        {
            // no spaces or capitals found in the last 15 characters: split at char 21
            strMultiLine = subsystemname.substr(0, MAX_SUBSYSTEM_CHARS_PER_CELL) + NEWLINE_CHAR +
                    formatSubsystemName(subsystemname.substr(MAX_SUBSYSTEM_CHARS_PER_CELL));
        }
    }
    return strMultiLine;
}

void IGSxGUI::ADTView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    sui->tawADTSubsystem->setItemText(static_cast<int>(i), 1, formatSubsystemName(subsyscount.nameSubsystem));

    IGSxGUI::Util::setColor(sui->tawADTSubsystem->getWidgetItem(i, 1), SUI::ColorEnum::White, sui->tawADTSubsystem);
    sui->tawADTSubsystem->setItemText(static_cast<int>(i), 2, subsys);
}

void IGSxGUI::ADTView::loadSubSystemTable()
{
    std::vector<ADT*> listSubsystemADTs = m_presenter->getADTs();
    container subsystem;

    m_listSubsystemCount.clear();
    m_listSubsystems.clear();

    size_t subsystemADTSize = listSubsystemADTs.size();
    for (size_t i = 0 ; i < subsystemADTSize; ++i) {
        subsystem.name = listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = listSubsystemADTs[i];
        m_listStringSubsystem.push_back(listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(m_listStringSubsystem.begin(), m_listStringSubsystem.end());
    m_listStringSubsystem.erase(unique(m_listStringSubsystem.begin(), m_listStringSubsystem.end()), m_listStringSubsystem.end());

    for (size_t i = 0 ; i < m_listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (m_listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = m_listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;
    // All ADTs
    sui->tawADTSubsystem->setItemText(0, 1, STRING_ALL_ADTS);
    int totalADTs = static_cast<int>(listSubsystemADTs.size());
    std::string  totalADTText = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(totalADTs) + STRING_CLOSE_BRACKET;
    sui->tawADTSubsystem->setItemText(0, 2, totalADTText);
    for (size_t i = 0; i < m_listSubsystemCount.size(); i++) {
        sui->tawADTSubsystem->appendRow();
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        int translatedIndex = static_cast<int>(i) + 1;
        if (subsyscount.nameSubsystem.length() <= MAX_SUBSYSTEM_CHARS_PER_CELL) {
            IGSxGUI::Util::setRowHeight(sui->tawADTSubsystem, translatedIndex, NORMAL_SUBSYSTEM_ROW_SIZE);
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawADTSubsystem, translatedIndex, EXTENDED_SUBSYSTEM_ROW_SIZE);
        }
        setValuesToRowWidgets(subsys, translatedIndex, subsyscount);
    }
}

void IGSxGUI::ADTView::setHandlers()
{
    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
    sui->btnOpenADT->clicked = boost::bind(&ADTView::onOpenADTClicked, this);
    sui->btnDescription->clicked = boost::bind(&ADTView::onBtnDescriptionClicked, this);
    sui->btnDescription->hoverEntered = boost::bind(&ADTView::onBtnDescriptionHoverEntered, this);
    sui->btnDescription->hoverLeft = boost::bind(&ADTView::onBtnDescriptionHoverLeft, this);
}

void IGSxGUI::ADTView::onTableADTRowPressed(int rowindex)
{
    if (m_selectedAdtRowNum == rowindex)
    {
        m_selectedAdt = "";
        m_selectedAdtRowNum = -1;
        IGSxGUI::Util::setADTUCTNormalStyle(sui->tawADT->getWidgetItem(rowindex, 0));
        showRightPane(false, m_selectedAdt);
    } else {
        m_selectedAdtRowNum = rowindex;
        SUI::Widget *widget = sui->tawADT->getWidgetItem(rowindex, 0);
        m_selectedAdt = IGSxGUI::Util::getADTCPDNameFromUserControl(widget);
        boost::trim(m_selectedAdt);

        for (int i = 0; i < sui->tawADT->rowCount(); ++i )
        {
            IGSxGUI::Util::setADTUCTNormalStyle(sui->tawADT->getWidgetItem(i, 0));
        }
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawADT->getWidgetItem(rowindex, 0));
        showRightPane(true, m_selectedAdt);
    }
}

void IGSxGUI::ADTView::onADTUCTHoverEntered(int index)
{
    if (m_selectedAdtRowNum != index)
    {
        SUI::Widget *widget = sui->tawADT->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::ADTView::onADTUCTHoverLeft(int index)
{
  if (m_selectedAdtRowNum != index)
  {
        SUI::Widget *widget = sui->tawADT->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOffStyle(widget);
  }
}

void IGSxGUI::ADTView::onBtnDescriptionHoverEntered()
{
    if (m_isDescFolded)
    {
        IGSxGUI::Util::setUnderline(sui->btnDescription, true);
    }
}

void IGSxGUI::ADTView::onBtnDescriptionHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnDescription, false);
}

void IGSxGUI::ADTView::showRightPane(bool isVisible, const std::string &adtName)
{
    sui->lblLine->setVisible(isVisible);
    sui->lblDescriptionAngle->setVisible(isVisible);
    sui->lblSelectedADT->setVisible(isVisible);
    sui->btnOpenADT->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->wvwADTHTMLDescription->setVisible(isVisible);

    if (isVisible)
    {
        sui->lblSelectedADT->setText(adtName);
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);

        if (m_isDescFolded)
        {
            showDescriptionHTML(false);
        } else {
            IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showDescriptionHTML(true);
        }
    }
}

void IGSxGUI::ADTView::onBtnDescriptionClicked()
{
    if (m_isDescFolded)
    {
        m_isDescFolded = false;
        showDescriptionHTML(true);
        IGSxGUI::Util::setUnderline(sui->btnDescription, false);
    } else {
        m_isDescFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showDescriptionHTML(false);
    }
}

void IGSxGUI::ADTView::onOpenADTClicked()
{
    IGS_INFO(std::string(STRING_ADT_MESSAGE + m_selectedAdt));

    if (m_presenter->isADTRunning(m_selectedAdt))
    {
        sui->lblStartingAdt->setText(STRING_ADT_ALREADY_RUNNING);
    } else {
        sui->lblStartingAdt->setText(STRING_ADT_SHOWING);
    }
    sui->lblStartingAdt->setVisible(true);
    IGSxGUI::Util::processEvents();

    const int timout = 2000;
    m_startingAdtTimer->start(timout);

    m_presenter->startADT(m_selectedAdt);
}

void IGSxGUI::ADTView::onShowADTStartingTimeout()
{
    sui->lblStartingAdt->setVisible(false);
}

void IGSxGUI::ADTView::showDescriptionHTML(bool isVisible)
{
    sui->wvwADTHTMLDescription->setVisible(isVisible);
    if (isVisible)
    {
        IGSxGUI::ADT* adt = m_presenter->getADT(sui->lblSelectedADT->getText());

        if (adt != NULL)
        {
            IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);

            std::string strADTHTMLFilePath = adt->getHtmlFile();
            sui->wvwADTHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strADTHTMLFilePath));
        }

    } else {
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
    }
}

void IGSxGUI::ADTView::reload()
{
    initCommon();
    if (m_selectedSubSystem != STRING_ALL_ADTS)
    {
        m_isInternalCallToSubsystemPressed = true;
        IGSxGUI::Util::selectRow(sui->tawADTSubsystem, m_selectedSubsystemRowNum);
        sui->lblAllADTs->setText(STRING_ALL_ADTS + STRING_SLASH + m_selectedSubSystem);

        std::vector<ADT*> listSelectedSubsystemADTs = getSelectedSubSystemADTs();
        loadADTTable(listSelectedSubsystemADTs);

        m_isInternalCallToSubsystemPressed = false;
    } else {
        m_listADT = m_presenter->getADTs();
        loadADTTable(m_listADT);
        IGSxGUI::Util::selectRow(sui->tawADTSubsystem, 0);
    }

    if (m_selectedAdt != "")
    {
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawADT->getWidgetItem(m_selectedAdtRowNum, 0));
        showRightPane(true, m_selectedAdt);
    } else {
        showRightPane(false, m_selectedAdt);
    }
}
