/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_AlertView.cpp
| Author       : Raja A
| Description  : Implementation of Moc Alert view
|
| ! \file        IGSxGUIxMoc_AlertView.cpp
| ! \brief       Implementation of Moc Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMoc_AlertView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIGraphicsView.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::AlertView::AlertView():
    dialog(NULL),
    tawAlert(NULL),
    lblAlertHeader(NULL),
    btnNoAlerts(NULL),
    lblHeaderBottom(NULL),
    uctSeverity(NULL),
    lblSeverity(NULL),
    lblSeverityImage(NULL),
    uctTimeReported(NULL),
    lblTimeReported(NULL),
    lblTimeReportedImage(NULL),
    uctCode(NULL),
    lblCode(NULL),
    lblCodeImage(NULL),
    btnMessage(NULL),
    lblalarms(NULL),
    lblerrors(NULL),
    lblwarnings(NULL),
    lblalarmsimage(NULL),
    lblerrorsimage(NULL),
    lblwarningsimage(NULL),
    imvLogo(NULL)
{
}

void SUI::AlertView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::AlertView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::AlertView::loadObjects(ObjectList* objectList)
{
    tawAlert = objectList->getObject<TableWidget>("tawAlert");
    lblAlertHeader = objectList->getObject<Label>("lblAlertHeader");
    btnNoAlerts = objectList->getObject<Button>("btnNoAlerts");
    lblalarms = objectList->getObject<Label>("lblalarms");
    lblerrors = objectList->getObject<Label>("lblerrors");
    lblwarnings = objectList->getObject<Label>("lblwarnings");
    lblalarmsimage = objectList->getObject<Label>("lblalarmsimage");
    lblerrorsimage = objectList->getObject<Label>("lblerrorsimage");
    lblwarningsimage = objectList->getObject<Label>("lblwarningsimage");
    lblHeaderBottom = objectList->getObject<Label>("lblHeaderBottom");
    uctSeverity = objectList->getObject<UserControl>("uctSeverity");
    lblSeverity = objectList->getObject<Label>("uctSeverity:lblHeaderButtonText");
    lblSeverityImage = objectList->getObject<Label>("uctSeverity:lblHeaderButtonImage");
    uctTimeReported = objectList->getObject<UserControl>("uctTimeReported");
    lblTimeReported = objectList->getObject<Label>("uctTimeReported:lblHeaderButtonText");
    lblTimeReportedImage = objectList->getObject<Label>("uctTimeReported:lblHeaderButtonImage");
    uctCode = objectList->getObject<UserControl>("uctCode");
    lblCode = objectList->getObject<Label>("uctCode:lblHeaderButtonText");
    lblCodeImage = objectList->getObject<Label>("uctCode:lblHeaderButtonImage");
    btnMessage = objectList->getObject<Button>("btnMessage");
    imvLogo = objectList->getObject<GraphicsView>("imvLogo");
}


