/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIAnalysis.hpp
| Author       : Venugopal S
| Description  : Interface file for Analysis plugin
|
| ! \file        IGSxGUIxIAnalysis.hpp
| ! \brief       Interface file for Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIANALYSIS_HPP
#define IGSXGUIXIANALYSIS_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIContainer.h>
#include "IGSxGUIxAlertEvent.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IAnalysis
{
 public:
    IAnalysis() {}
    virtual ~IAnalysis() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void showAlert(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void initialize() = 0;
    virtual void setActive(bool bActive) = 0;
    virtual void showEventViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void subscribeForAlertChange(const alertUpdatedCallback& cb)= 0;
    virtual void unsubscribeForAlertChange()= 0;
    virtual int getAlertCount() = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIANALYSIS_HPP
