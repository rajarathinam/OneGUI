/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Machineconstants View
|
| ! \file        IGSxGUIxMachineconstantsView.hpp
| ! \brief       Header file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIButton.h>
#include <string>
#include <vector>
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{
  class Node;

class MachineconstantsView : public IMachineconstantsView
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool);  

private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);

    enum moveDirection
    {
       UP = 0,
       DOWN
    }Direction;

    void onHistoryHoverLeft();
    void onHistoryHoverEntered();

    void onUCTSaveButtonClicked();
    void onUCTSaveButtonPressed();
    void onUCTSaveButtonHoverOn();
    void onUCTSaveButtonHoverOff();

    void onSearchClearHoverLeft();
    void onSearchButtonHoverLeft();
    void onSearchTextEditFinished();
    void onSearchClearHoverEntered();
    void onSearchButtonHoverEntered();
    void onSearchTextEdited(const std::string &text);

    void onParameterNameHoverLeft();
    void onParameterValueHoverLeft();
    void onParameterNameHoverEntered();
    void onParameterValueHoverEntered();

    void onPendingParamCancelSave();
    void uctPendingParamFinalSaveClicked();
    void PendingParamSaveNameLnEditCancel();
    void uctPendingParamFinalSaveHoverLeft();
    void uctPendingParamFinalSaveHoverEntered();

    void onPendingParameterNameHoverLeft();
    void onPendingParameterValueHoverLeft();
    void onPendingParameterNameHoverEntered();
    void onPendingParameterValueHoverEntered();
    void onPendingParameterRowClosePressed(int rowNumber);

    void onParameterRowPressed(int row);
    void onParameterUCTHoverLeft(int row);
    void onParameterUCTHoverEntered(int row);

    void init();
    void setHandlers();
    void onValueChanged();
    void onCancelYesPressed();
    void updateParameterTable();
    void onSearchClearPressed();
    void onCancelButtonPressed();
    void onParameterTreeItemPressed(int rowNUmber);
    void onBackPressed();

    int searchForParameters(const std::string &textToSearch);

    void showSaveCancelButtons(bool bShow);
    void showPendingParamWidgets(bool bShow);
    void showFinalSaveScreenItems(bool bShow);
    void showSearchEntriesParameter(bool bShow);
    void configurePendingParamTableRow(size_t i);
    void showNoPendingParameterScreen(bool bShow);
    void showFinalSaveScreenPendingParams(bool bShow);
    void removePendingParamTableRows(int pos, int count);
    void PendingParamSaveTxtChanged(const std::string &text);
    void moveSaveCancelButtons(const moveDirection& dir, int pixels);
    void setUCTHandlers(SUI::Widget *widget, int row, bool readonly);
    void populateData(std::vector<ParameterData*>::iterator it, int row);
    void PendingParamSaveChangeReasonTxtChanged(const std::string &text);
    void setTableRows(int value, std::vector<ParameterData*> collection);
    void createPopup(const std::string& title, const std::string& message);
    void setData(int value, int rows, std::vector<ParameterData*> collection);
    void initializeTableRows(int rows, std::vector<ParameterData*> collection);
    void onParameterValueChanged(const std::string& name, const std::string& value);
    void UpdatePendingParamTable(const std::string& name, const std::string& value);
    void configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value);
    void updateParameterTableValue(const std::string& pendingParametername, const std::string &newValue);
    void refreshTreeViewAndBreadCrums();
    void refreshParameterList();
    void setBreadCrumpButtonVisibility(bool visiblity);
    void onBreadCrump1HoverEntered();
    void onBreadCrump2HoverEntered();
    void onBreadCrump3HoverEntered();
    void onBreadCrump4HoverEntered();
    void onBreadCrump5HoverEntered();
    void onBreadCrump6HoverEntered();

    void onBreadCrump1HoverLeft();
    void onBreadCrump2HoverLeft();
    void onBreadCrump3HoverLeft();
    void onBreadCrump4HoverLeft();
    void onBreadCrump5HoverLeft();
    void onBreadCrump6HoverLeft();

    void onBreadCrump1Clicked();
    void onBreadCrump2Clicked();
    void onBreadCrump3Clicked();
    void onBreadCrump4Clicked();
    void onBreadCrump5Clicked();
    void onBreadCrump6Clicked();

    SUI::MachineconstantsView* sui;
    SUI::Dialog* m_dialog;
    int m_selectedParameterRowNum;
    IGSxGUI::ParameterpopupView m_parameterview;
    std::vector<ParameterData*> m_matchedparameters;
    MachineconstantsManager* m_pMachineconstantsManager;
    std::string m_searchText;
    std::vector<SUI::Button*> breadCrumpButtonList;

    static const int DIALOG_X;
    static const int DIALOG_Y;
    static const int ROW_HEIGHT;
    static const int BUTTON_SIZE;
    static const int DIALOG_WIDTH;
    static const int DIALOG_HEIGHT;
    static const int MAX_VISIBLE_ROWS;
    static const int AWESOME_CLOSE_SIZE;
    static const int PENDINGPARAM_CLOSEBUTTON_SIZE;

    static const std::string IMAGE_LOGO;
    static const std::string DIALOG_TITLE;
    static const std::string DIALOG_MESSAGE;
    static const std::string DIALOG_ID_TITLE;
    static const std::string DIALOG_ID_MESSAGE;
    static const std::string DIALOG_ID_NOBUTTON;
    static const std::string DIALOG_ID_YESBUTTON;
    static const std::string STRING_GREY_REGULAR;
    static const std::string STRING_BLUE_REGULAR;
    static const std::string STYLE_BUTTON_BLUEBG;
    static const std::string STYLE_BUTTON_BORDER;
    static const std::string COLOR_LINEEDIT_CANCEL;
    static const std::string STYLE_BUTTON_ORANGEBG;
    static const std::string CANCELPOPUP_LOAD_FILE;
    static const std::string STRING_PARAMETER_FOUND;
    static const std::string STRING_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETERS_FOUND;
    static const std::string STYLE_BUTTON_HOVERBLUEBG;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STRING_PENDINGPARAMLABEL_STYLE;
    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSVIEW_HPP
