/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard View
|
| ! \file        IGSxGUIxDashboardView.hpp
| ! \brief       Header file for Dashboard View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDVIEW_HPP
#define IGSXGUIXDASHBOARDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxDashboardPresenter.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxKPIManager.hpp"
#include <SUIPlotWidget.h>
#include <SUIPlotHistogramItem.h>
#include <SUIProgressBar.h>
#include <SUIGroupBox.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class DashboardView;
}

namespace IGSxGUI {
class DashboardView : public IDashboardView
{
 public:
    explicit DashboardView(KPIManager* pKpiManager);
    virtual ~DashboardView();

    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool bActive);
    virtual void updateKPI(string kpiName, string valueSetName, vector<double> values);

    void constructGraphs();
    void constructKPItable1();
    void constructKPItable2();
    void constructConsumableTable();
    void init();
    void setHandlers();
    void onConsumableHoverOn();
    void onConsumableHoverOff();

    void onMy();
private:
    DashboardView(const DashboardView&);
    DashboardView& operator=(const DashboardView&);

    SUI::DashboardView *sui;
    DashboardPresenter *m_presenter;
    std::vector<KPI*> m_listKPIs;
    std::map<std::string, SUI::PlotHistogramItem *> mapPlotHistogram;

    std::vector<SUI::UserControl*> m_listConsumableUCT;
    std::vector<SUI::Label*> m_listConsumableNameLabels;
    std::vector<SUI::Label*> m_listConsumableTimeLabels;
    std::vector<SUI::Label*> m_listConsumableValueLabels;
    std::vector<SUI::Label*> m_listConsumablePercentageLabels;
    std::vector<SUI::P*> m_listDisplayButtons;

    static const std::string LOAD_FILE_DASHBOARD;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXDASHBOARDVIEW_HPP
