/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUITableWidget.h>
#include <SUIPlotWidget.h>
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIPlotAxisEnum.h>
#include <SUIUserControl.h>



/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView)
{
    m_presenter = new DashboardPresenter(this,pKpiManager);
}

IGSxGUI::DashboardView::~DashboardView()
{
    delete m_presenter;
    delete sui;
}
void IGSxGUI::DashboardView::constructGraphs()
{
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("MyHistogram");
    histogram->attach(sui->plwgraph);
    mapPlotHistogram.insert(std::pair<std::string, SUI::PlotHistogramItem*>("MyHistogram", histogram));
    histogram->setBrushColor(SUI::ColorEnum::Blue);

     //Add samples
     SUI::PlotIntervalSample sample1(10,2,3);
     SUI::PlotIntervalSample sample2(20,4,5);
     SUI::PlotIntervalSample sample3(5,6,7);
     SUI::PlotIntervalSample sample4(11,8,9);
     SUI::PlotIntervalSample sample5(18,10,11);
     SUI::PlotIntervalSample sample6(100,12,13);
     histogram->setSample(sample1);
     histogram->setSample(sample2);
     histogram->setSample(sample3);
     histogram->setSample(sample4);
     histogram->setSample(sample5);
     histogram->setSample(sample6);

    sui->plwgraph->replot();


}
void IGSxGUI::DashboardView::constructKPItable1()
{
  sui->tawModules->showGrid(false);
  sui->tawModules->setListViewMode(true);

}
void IGSxGUI::DashboardView::constructKPItable2()
{

}
void IGSxGUI::DashboardView::constructConsumableTable()
{

}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctConsumable->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);
}
void IGSxGUI::DashboardView::onConsumableHoverOn()
{

     sui->gbxConsumable->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumableName->setStyleSheetClass("uctconsumablehoveron");
     sui->lblTime->setStyleSheetClass("uctconsumablehoveron");
     sui->lblValue->setStyleSheetClass("uctconsumablehoveron");
     sui->lblPercentage->setStyleSheetClass("uctconsumablehoveron");

}

void IGSxGUI::DashboardView::onConsumableHoverOff()
{
    sui->gbxConsumable->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumableName->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblTime->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblValue->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblPercentage->setStyleSheetClass("uctconsumablehoveroff");


}

void IGSxGUI::DashboardView::onMy()
{
    int x = 10;
}

void IGSxGUI::DashboardView::init()
{


    //Construct Graphs
    constructGraphs();
    constructKPItable1();
    constructKPItable2();
    constructConsumableTable();
/*
    m_listKPIs = m_presenter->getKPIs();

    for (size_t i = 0; i < m_listKPIs.size(); i++)
    {
        KPI* kpi = m_listKPIs[i];

        for (size_t j = 0; j < kpi->getValueSets().size(); j++)
        {
            KPIValueSet* valueSet = kpi->getValueSets()[j];
            std::list<std::string> listRowData;

            listRowData.push_back(kpi->getName());
            listRowData.push_back(valueSet->getName());

            listRowData.push_back(boost::lexical_cast<string>(valueSet->getValue().back()));
            listRowData.push_back("");

            sui->tawKPI->insertRows(i+1,1);
            sui->tawKPI->addData(i+1,listRowData);
        }
    }
    */
}


void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    init();
    setHandlers();

}

void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else
    {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::DashboardView::updateKPI(string kpiName, string valueSetName, vector<double> values)
{

    /*
     * for (int i = 1; i < sui->tawKPI->rowCount(); i++)
    {
        if (sui->tawKPI->getItemText(i,0) == kpiName && sui->tawKPI->getItemText(i,1) == valueSetName)
        {
            sui->tawKPI->setItemText(i,2,boost::lexical_cast<string>(values[0]));
            break;
        }
    }
    */
}
