/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenter.hpp
| Author       : Raja A
| Description  : Header file for ADT presenter
|
| ! \file        IGSxGUIxADTPresenter.hpp
| ! \brief       Header file for ADT presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTPRESENTER_HPP
#define IGSXGUIXADTPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2.hpp>
#include <vector>
#include <string>
#include "IGSxGUIxIADTView.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class ADTPresenter
{
 public:
    explicit ADTPresenter(IADTView* view, ADTManager* pADTManager);
    virtual ~ADTPresenter();

    std::vector<ADT*> getADTs();
    bool startADT(std::string adtName);


 private:
    ADTPresenter(const ADTPresenter& adtPresenter);
    ADTPresenter& operator=(const ADTPresenter& adtPresenter);



    ADTManager* m_pADTManager;
    IADTView *m_view;
    std::vector<boost::signals2::connection> m_connection;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADTPRESENTER_HPP
