/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemFunctionTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Function test
|
| ! \file        IGSxGUIxSystemFunctionTest.cpp
| ! \brief       Implementation of System Function test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemFunctionTest.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        SystemSystemFunctionTestParam,
                        ::testing::Values("SF-04"));

TEST_P(SystemSystemFunctionTestParam, Test1)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(obj);
    std::string desc = sys->getDescription();
    EXPECT_STRCASEEQ(desc.c_str(), "SF Environmental Mgt");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test2)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(obj);
    std::string name = sys->getName();
    EXPECT_STRCASEEQ(name.c_str(), "SF-04");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test3)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(obj);
    std::string desc = sys->getDescription();
    EXPECT_STRCASEEQ(desc.c_str(), "SF Environmental Mgt");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test4)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(obj);
    std::string name = sys->getName();
    EXPECT_STRCASEEQ(name.c_str(), "SF-04");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test5)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta("SF-15", "Laser Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(sysMeta);
    sys->addDriver(drvMeta, DriverState::DS_INITIALIZED);
    const std::string sysFunName = "SF-15";
    IGSxGUI::Driver* drv = sys->getDriver(sysFunName);
    std::string name = drv->getName();
    EXPECT_STRCASEEQ(name.c_str(), "SF-15");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test7)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta("SF-15", "Laser Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(sysMeta);
    sys->addDriver(drvMeta, DriverState::DS_INITIALIZED);
    const std::string sysFunName = "SF-15";
    IGSxGUI::Driver* drv = sys->getDriver(sysFunName);

    DriverState::DriverStateEnum drvstate = drv->getState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_INITIALIZED");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test8)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta("SF-15", "Laser Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(sysMeta);
    sys->addDriver(drvMeta, DriverState::DS_TERMINATED);
    const std::string sysFunName = "SF-15";
    IGSxGUI::Driver* drv = sys->getDriver(sysFunName);

    DriverState::DriverStateEnum drvstate = drv->getState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_TERMINATED");

    delete sys;
}

TEST_P(SystemSystemFunctionTestParam, Test9)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta("SF-15", "Laser Mgt");
    IGSxGUI::SystemFunction* sys = new IGSxGUI::SystemFunction(sysMeta);
    sys->addDriver(drvMeta, DriverState::DS_TERMINATED);
    const std::string sysFunName = "SF-15";
    sys->updateDriverState(sysFunName, DriverState::DS_INITIALIZED);
    IGSxGUI::Driver* drv = sys->getDriver(sysFunName);

    DriverState::DriverStateEnum drvstate = drv->getState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_INITIALIZED");

    delete sys;
}
