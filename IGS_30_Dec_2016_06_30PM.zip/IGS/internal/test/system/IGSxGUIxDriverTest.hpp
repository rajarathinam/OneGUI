/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver test
|
| ! \file        IGSxGUIxDriverTest.hpp
| ! \brief       Header file for Driver test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVERTEST_HPP
#define IGSXGUIXDRIVERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxDriver.hpp"

using std::vector;
using std::list;
using IGSxITS::MetaDescriptions;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
template<typename T>
    ::testing::AssertionResult VectorsMatch(vector<T> Expected, vector<T> Actual)
{
        for (int i=0; i < Expected.size(); i++)
        {
            if (Expected.at(i)->getName().compare(Actual.at(i)->getName()) != 0)
            {
                return ::testing::AssertionFailure();
            }
        }
        return ::testing::AssertionSuccess();
}

template<typename T>
    ::testing::AssertionResult ListMatch(list<T> Expected, list<T> Actual)
{
        while ((!Expected.empty()) && (!Actual.empty()))
        {
            if (Expected.front().compare(Actual.front()) != 0)
            {
                return ::testing::AssertionFailure();
            }
            Expected.pop_front();
            Actual.pop_front();
        }
        return ::testing::AssertionSuccess();
}

class SystemDriverTest : public ::testing::Test
{
 public:
    SystemDriverTest(){}
    virtual ~SystemDriverTest(){}
 private:
    MetaDescriptions ExpectedDrivers;
    MetaDescriptions ExpectedSysfunctions;
 protected:
  virtual void SetUp()
  {
        ExpectedDrivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
        ExpectedDrivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
        ExpectedDrivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
        ExpectedDrivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
        ExpectedDrivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));

        ExpectedSysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
        ExpectedSysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
        ExpectedSysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
        ExpectedSysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
        ExpectedSysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
        ExpectedSysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class SystemDriverTestParam : public ::testing::TestWithParam<std::string>
{
 public:
    SystemDriverTestParam(){}
    virtual ~SystemDriverTestParam(){}
 private:
    std::vector<IGSxGUI::Driver*> ExpectedDrivers;
    MetaDescriptions ExpectedSysfunctions;
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXDRIVERMANAGERTEST_HPP
