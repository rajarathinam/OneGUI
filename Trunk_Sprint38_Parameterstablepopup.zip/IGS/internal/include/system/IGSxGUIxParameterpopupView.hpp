

/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.hpp
| Author       : Raja
| Description  : Interface file for Parameterpopup View
|
| ! \file        IGSxGUIxParameterpopupView.hpp
| ! \brief       Interface file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXPARAMETERPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class ParameterpopupView;
}  // namespace SUI

namespace IGSxGUI{

class ParameterpopupView : public IParameterpopupView
{
 public:
    explicit ParameterpopupView();
    virtual ~ParameterpopupView();
    virtual void show();

  void onCloseButtonPressed();
  void setParameterName(const std::string &name);
  void setParameterValue(const std::string &value);
  void setParameterDefaultValue(const std::string &defaultvalue);
private:
    ParameterpopupView(const ParameterpopupView &);
    ParameterpopupView& operator=(const ParameterpopupView &);
    void init();

    SUI::ParameterpopupView *sui;
    static const std::string PARAMETERPOPUPVIEW_LOAD_FILE;
    static const std::string STRING_PARAMETERPOPUPVIEW_SHOWN;


};
}  // namespace IGSxGUI

#endif // IGSXGUIXPARAMETERPOPUPVIEW_HPP
