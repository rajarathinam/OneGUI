/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystem.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin
|
| ! \file        IGSxGUIxSystem.cpp
| ! \brief       Implementation of System plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxSystemView.hpp"
#include "IGSxGUIxCPDView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::System::System():m_systemView(NULL), m_cpdView(NULL), m_driverManager(new DriverManager()),
    m_cpdManager(new CPDManager())
{
}

IGSxGUI::System::~System()
{
    if (m_driverManager != NULL)
    {
        delete m_driverManager;
        m_driverManager = NULL;
    }
    if (m_cpdManager != NULL)
    {
        delete m_cpdManager;
        m_cpdManager = NULL;
    }
    if (m_systemView != NULL)
    {
        delete m_systemView;
        m_systemView = NULL;
    }
    if (m_cpdView != NULL)
    {
        delete m_cpdView;
        m_cpdView = NULL;
    }
}

void IGSxGUI::System::initialize()
{
    if (m_driverManager != NULL)
    {
        m_driverManager->initialize();
    }
    if (m_cpdManager != NULL)
    {
        m_cpdManager->initialize();
    }
}

void IGSxGUI::System::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_cpdView != NULL)
    {
        m_cpdView->setActive(false);
    }
    if (m_systemView == NULL)
    {
        m_systemView = new IGSxGUI::SystemView(m_driverManager);
    }
    setActive(true);
    m_systemView->show(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::System:: showCPD(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_systemView != NULL)
    {
        m_systemView->setActive(false);
    }
    if (m_cpdView == NULL)
    {
        m_cpdView = new IGSxGUI::CPDView(m_cpdManager);
    }

    m_cpdView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::System:: setActive(bool bActive)
{
    if (m_systemView != NULL)
    {
        m_systemView->setActive(bActive);
    }

    if (m_cpdView != NULL)
    {
        m_cpdView->setActive(bActive);
    }
}

void IGSxGUI::System::subscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->registerToSystemStateChanged(cb);
}

void IGSxGUI::System::unsubscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->unregisterToSystemStateChanged(cb);
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::System::retrieveSystemState()
{
    return m_driverManager->getSystemState();
}

void IGSxGUI::System::notifyAlertPopup(bool bAlertPopupRaised)
{
    if (m_systemView != NULL)
    {
        m_systemView->notifyAlertPopup(bAlertPopupRaised);
    }
}

void IGSxGUI::System::controlChanged(const IGSxCTRL::Who::WhoEnum &who)
{
    if (m_systemView != NULL)
    {
        m_systemView->controlChanged(who);
    }
}
