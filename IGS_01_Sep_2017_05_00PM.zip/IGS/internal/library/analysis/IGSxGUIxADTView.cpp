/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = "IGSxGUIxADT.xml";
const std::string IGSxGUI::ADTView::STRING_EMPTY = "";
const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "All ADTs";
const std::string IGSxGUI::ADTView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::ADTView::STRING_ADTVIEW_SHOWN = "ADTView is shown.";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::ADTView::STRING_ADTSUBSYSTEM_STYLE = "adtsubsystem";
const std::string IGSxGUI::ADTView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::ADTView::STRING_SPACE = "  ";
const std::string IGSxGUI::ADTView::STRING_SLASH = " / ";
const std::string IGSxGUI::ADTView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::ADTView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::ADTView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const char* IGSxGUI::ADTView::STRING_ADT_MESSAGE = "Start ADT button pressed, Adt Name: ";
const int IGSxGUI::ADTView::CHARS_TO_REMOVE = 11;
const int IGSxGUI::ADTView::ITEMS_TO_REMOVE = 20;
const int IGSxGUI::ADTView::ADTSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::ADTView::AWESOME_ANGLE_SIZE = 22;

IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_bRunningADT(false),
    m_toggleDescDisplay(true),
    m_selectedSubSystem(""),
    m_PreviousSelectedADT("")
{
    m_presenter = new ADTPresenter(this, pADTManager);
}

IGSxGUI::ADTView::~ADTView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    init();
    IGS_INFO(STRING_ADTVIEW_SHOWN);
}

void IGSxGUI::ADTView::init()
{
    sui->tawADTSubsystem->showGrid(false);

    m_listADT = m_presenter->getADTs();
    m_listSubsystemADTs = m_presenter->getADTs();

    loadSubSystems();
    loadADTTable();
    IGSxGUI::Util::insertUserControl(sui->tawADT, sui->uctADT, 0,0);

}

void IGSxGUI::ADTView::onSubSystemClosePressed()
{
    EnableCountLabels();
    DisableCloseButtons();
    IGSxGUI::Util::clearSelection(sui->tawADTSubsystem);
    loadADTTable();
}

void IGSxGUI::ADTView::EnableCountLabels()
{
    for (int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 1))->setVisible(true);
    }
}
void IGSxGUI::ADTView::DisableCloseButtons()
{
    for (int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 2))->setVisible(false);
    }
}

void IGSxGUI::ADTView::onSubsystemPressed()
{
    std::vector<int> items = sui->tawADTSubsystem->getSelectedRows();
    if (items.size() > 0)
    {
        EnableCountLabels();
        DisableCloseButtons();
        int  strSelectedRow = items[0];
        dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(strSelectedRow, 1))->setVisible(false);
        dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(strSelectedRow, 2))->setVisible(true);

        std::string selectedText = sui->tawADTSubsystem->getItemText(boost::lexical_cast<int>(strSelectedRow), 0);

        boost::trim(selectedText);
        m_selectedSubSystem = selectedText;
        sui->lblAllADTs->setText(STRING_ALL_ADTS + STRING_SLASH + m_selectedSubSystem);

        std::vector<ADT*> listSelectedSubsystemADTs = getSelectedSubSystemADTs();
        sui->tawADT->removeRows(1, sui->tawADT->rowCount()-1);


        for (size_t i = 0 ; i < listSelectedSubsystemADTs.size() - 1; i++)
        {
            std::list<std::string> data;
            data.push_back(listSelectedSubsystemADTs[i]->getName());
            sui->tawADT->appendRow();
          }
        for(int row = 0; row < sui->tawADT->rowCount(); ++row)
          {
            IGSxGUI::Util::setRowHeight(sui->tawADT,row, 60);
            IGSxGUI::Util::setColumnWidth(sui->tawADT,0, 545);
            SUI::Widget *arrowLabel = dynamic_cast<SUI::Widget*>(sui->tawADT->getWidgetItem(1, 0));
            std::cout <<arrowLabel->getId() <<std::endl;
            IGSxGUI::Util::setAwesome(sui->lblArrow, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, 16);
          }
        IGSxGUI::Util::clearSelection(sui->tawADT);
        setDescriptionPaneVisible(false);
      }

}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
        container subsys = m_listSubsystems[i];
        if (subsys.name == m_selectedSubSystem)
        {
            listSubsystemADTs.push_back(subsys.adt);
        }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::setDescriptionPaneVisible(bool visibility)
{
    sui->lblLine->setVisible(visibility);
    sui->lblAngle->setVisible(visibility);
    sui->lblSelectedADT->setVisible(visibility);
    sui->btnOpenADT->setVisible(visibility);
    sui->btnDescription->setVisible(visibility);
    sui->wvwADTHTMLDescription->setVisible(visibility);
}

void IGSxGUI::ADTView::loadADTTable()
{
    sui->tawADT->insertRows(sui->tawADT->rowCount(), m_listADT.size() - 1);

    for (size_t i = 0 ; i < m_listADT.size(); i++)
    {
        std::list<std::string> data;
        data.push_back(m_listADT[i]->getName());
        sui->tawADT->addData(i, data);
    }

    sui->lblAllADTs->setText(STRING_ALL_ADTS);
    setDescriptionPaneVisible(false);
}

void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(const IGS::Result &result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;
    }
}

void IGSxGUI::ADTView::insertCountLabelAndCloseButton(size_t i)
{
    IGSxGUI::Util::addLabel(sui->tawADTSubsystem, i, 1);
    SUI::Label* label = dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 1));
    label->setStyleSheetClass(STRING_ADTSUBSYSTEM_STYLE);
    IGSxGUI::Util::addButton(sui->tawADTSubsystem, i, 2);
    SUI::Button* button = dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(i, 2));
    button->setVisible(false);
    button->clicked = boost::bind(&ADTView::onSubSystemClosePressed, this);
    IGSxGUI::Util::setAwesome(button, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, ADTSUBSYSTEM_CLOSEBUTTON_SIZE);
}

void IGSxGUI::ADTView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    sui->tawADTSubsystem->setItemText(static_cast<int>(i), 0, subsyscount.nameSubsystem);
    dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 1))->setText(subsys);
}

void IGSxGUI::ADTView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemADTs.size(); i++)
    {
        subsystem.name = m_listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = m_listSubsystemADTs[i];
        listStringSubsystem.push_back(m_listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        insertCountLabelAndCloseButton(i);
        sui->tawADTSubsystem->appendRow();
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        setValuesToRowWidgets(subsys, i, subsyscount);
    }
    sui->tawADTSubsystem->removeRow(sui->tawADTSubsystem->rowCount() - 1);
    IGSxGUI::Util::setScalable(sui->tawADTSubsystem);
}

void IGSxGUI::ADTView::setHandlers()
{
    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
    sui->tawADT->rowClicked = boost::bind(&ADTView::onTableADTRowPressed, this);
    sui->btnOpenADT->clicked = boost::bind(&ADTView::onOpenADTClicked, this);
    sui->btnDescription->clicked = boost::bind(&ADTView::onDescriptionClicked, this);
}

void IGSxGUI::ADTView::onTableADTRowPressed()
{
    EnableCountLabels();
    DisableCloseButtons();
    int strSelectedRow;

    std::vector<int> items = sui->tawADT->getSelectedRows();

    if (items.size() > 0)
    {
        strSelectedRow = items.front();
    }
    std::string currentSelectedADT = sui->tawADT->getItemText(strSelectedRow, 0);

    if (m_PreviousSelectedADT == currentSelectedADT)
    {
        showADTDetailsPage(false, currentSelectedADT);
    } else {
        showADTDetailsPage(true, currentSelectedADT);
        hideHTMLReport();
    }
    m_PreviousSelectedADT = currentSelectedADT;
}

void IGSxGUI::ADTView::showADTDetailsPage(bool isVisible, const std::string &adtName)
{
    sui->lblLine->setVisible(isVisible);
    sui->lblAngle->setVisible(isVisible);
    sui->lblSelectedADT->setVisible(isVisible);
    sui->btnOpenADT->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->wvwADTHTMLDescription->setVisible(isVisible);

    if (isVisible)
    {
        m_toggleDescDisplay = true;
        sui->lblSelectedADT->setText(adtName);
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
    }
}

void IGSxGUI::ADTView::onDescriptionClicked()
{
    if (m_toggleDescDisplay)
    {
        IGSxGUI::ADT* adt = m_presenter->getADT(m_PreviousSelectedADT);

        if (adt != NULL)
        {
            std::string strADTHTMLFilePath = adt->getHtmlFile();
            IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->wvwADTHTMLDescription->setVisible(true);
            sui->wvwADTHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strADTHTMLFilePath));
            sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
        }
    } else {
        hideHTMLReport();
    }
    m_toggleDescDisplay = !m_toggleDescDisplay;
}

void IGSxGUI::ADTView::onOpenADTClicked()
{
    IGS_INFO(std::string(STRING_ADT_MESSAGE + m_PreviousSelectedADT));
    m_presenter->startADT(m_PreviousSelectedADT);
}

void IGSxGUI::ADTView::hideHTMLReport()
{
    sui->wvwADTHTMLDescription->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
    sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
}

