/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Utility class
|
| ! \file        IGSxGUIxUtil.hpp
| ! \brief       Header file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXUTIL_HPP
#define IGSXGUIXUTIL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <QtCore/QChar>
#include <string>
#include <algorithm>
#include <SUIColorEnum.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Label;
class BaseWidget;
class Widget;
class Dialog;
class TableWidget;
class UserControl;
}
/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

const int NO_SIZE = -1;
class AwesomeIcon
{
 public:
    typedef enum
    {  // http://fontawesome.io/icons/
        AI_fa_times,                    // 0xf00d
        AI_fa_exclamation_triangle,     // 0xf071
        AI_fa_exclamation,              // 0xf12a
        AI_fa_times_circle,             // 0xf057
        AI_fa_bell,                     // 0xf0f3
        AI_fa_sort_desc,                // 0xf0dd
        AI_fa_sort_asc,                 // 0xf0de
        AI_fa_sort_default,             // 0xf0dc
        AI_fa_copyright,                // 0xf1f9
        AI_fa_cog,                      // 0xf013
        AI_fa_sliders,                  // 0xf1de
        AI_fa_dashboard,                // 0xf0e4
        AI_fa_sitemap,                  // 0xf0e8
        AI_fa_checkcircle,              // 0xf058
        AI_fa_clock,                    // 0xf017
        AI_fa_crosshairs,               // 0xf05b
        AI_fa_areachart,                // 0xf1fe
        AI_fa_stethoscope,              // 0xf0f1
        AI_fa_check,                    // 0xf00c
        AI_fa_close,                    // oxf00d
        AI_fa_angle_right,              // 0xf105
        AI_fa_angle_down                // 0xf107
    } AwesomeIconEnum;
};

class SortOrder
{
 public:
    typedef enum
    {
        Ascending,
        Descending
    } SortOrderEnum;
};

class Util
{
 public:
    static void setGeometry(SUI::Widget *widget, int x, int y, int width, int height);
    static void setWindowFrame(SUI::Dialog *dialog, bool enable);
    static void disableScrollbars(SUI::Dialog *dialog);
    static void setFadeOut(SUI::Dialog *dialog, int duration);
    static void processEvents();
    static void setImageToLabel(SUI::Label *label, SUI::Dialog *dialog, const std::string &resourcepath);
    static void setTranslucentBackground(SUI::Dialog *dialog);

    /**
     * @brief setParent sets the parent of the widget to the parent from the
     * @param widget The widget to set the parent on
     * @param parent This is the widget where the parent will be taken from
     */
    static void setParent(SUI::Widget *widget, SUI::Widget* parent);
    static const std::string elideText(const std::string& instr, int fontsize, int width);

    static void sort(int col, SUI::TableWidget* widget, SortOrder::SortOrderEnum order);
    static void setScalable(SUI::TableWidget *widget);

    static void setAwesome(SUI::Widget* widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string& color, const int size);
    static void setAwesome(SUI::Widget* widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, SUI::ColorEnum::Color color, const int size);
    static void setColor(SUI::Widget* widget, SUI::ColorEnum::Color color, SUI::TableWidget *tableWidget);
    static void addLabel(SUI::TableWidget *tableWidget, int row, int column);
    static void addButton(SUI::TableWidget *tableWidget, int row, int column);
    static void clearSelection(SUI::TableWidget *tableWidget);
    static void insertUserControl(SUI::TableWidget *tableWidget, SUI::UserControl * usercontrol, int row, int column);
    static void setRowHeight(SUI::TableWidget *tableWidget, int row, int height);
    static void setColumnWidth(SUI::TableWidget *tableWidget, int column, int width);
 private:
    Util();
    static void setAwesomeStyle(SUI::BaseWidget *baseWidget, const std::string &customcolor, const int size);
    static void setIcon(SUI::BaseWidget *baseWidget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string& color, const int size);
    static QChar getAwesomeChar();
 private:
    static QChar m_awesomeChar;
};

}  // namespace IGSxGUI

#endif  // IGSXGUIXUTIL_HPP
