/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManager.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver Manager
|
| ! \file        IGSxGUIxDriverManager.cpp
| ! \brief       Implementation of Driver Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDriverManager.hpp"
#include <string>
#include <vector>
#include <algorithm>
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DriverManager::ERROR_ADDING_SYSFUN = "Error While Adding System Function";
const char* IGSxGUI::DriverManager::STRING_NEW_SYSTEM_STATE = "New system state: ";

IGSxGUI::DriverManager::DriverManager():
    m_systemState(SystemState::SS_RECOVERY_REQUIRED)
{
}

IGSxGUI::DriverManager::~DriverManager()
{
    try
    {
        InitTerminate::getInstance()->unsubscribeToDriverStatusChanged();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (std::vector<SystemFunction*>::iterator it = m_systemFunctions.begin() ; it != m_systemFunctions.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_systemFunctions.clear();
}

void IGSxGUI::DriverManager::addSystemFunctions(const MetaDescriptions& metaDescriptions)
{
    if (metaDescriptions.size() >0)
    {
        for (size_t i = 0; i < metaDescriptions.size(); i++)
        {
            IGSxGUI::SystemFunction* systemFunction = new SystemFunction(metaDescriptions[i]);
            if (systemFunction != NULL)
            {
                systemFunction->registerToDetermineMainState(boost::bind(&IGSxGUI::DriverManager::determineSystemState, this));
                m_systemFunctions.push_back(systemFunction);
            } else {
                throw IGS::Exception(ERROR_ADDING_SYSFUN);
            }
        }
    } else {
        throw IGS::Exception(ERROR_ADDING_SYSFUN);
    }
    sort(m_systemFunctions.begin(), m_systemFunctions.end(), compareSystemFunction());
}

IGSxGUI::SystemFunction* IGSxGUI::DriverManager::getSystemFunction(const std::string &name) const
{
    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        if (m_systemFunctions[i]->getName() == name)
        {
            return m_systemFunctions[i];
        }
    }
    return NULL;
}

std::vector<IGSxGUI::SystemFunction*> IGSxGUI::DriverManager::getSystemFunctions() const
{
    return m_systemFunctions;
}

IGSxGUI::Driver* IGSxGUI::DriverManager::getDriver(const std::string& name) const
{
    Driver* driver = NULL;
    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        if (m_systemFunctions[i]->isManagingDriver(name))
        {
            driver = m_systemFunctions[i]->getDriver(name);
        }
    }
    return driver;
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::DriverManager::getSystemState() const
{
    return m_systemState;
}

void IGSxGUI::DriverManager::determineSystemState()
{
    SystemState::SystemStateEnum worstState = SystemState::SS_INITIALIZED;
    SystemState::SystemStateEnum newState = SystemState::SS_RECOVERY_REQUIRED;
    bool allInitialized = true;
    bool allTerminated = true;
    bool oneInitializing = false;
    bool oneTerminating = false;
    bool oneInitialized = false;
    bool oneTerminated = false;

    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        std::vector<Driver*> drivers = m_systemFunctions[i]->getDrivers();
        for (size_t j = 0; j < drivers.size(); j++)
        {
            if (drivers[j]->isImplemented())
            {
                DriverState::DriverStateEnum driverState = drivers[j]->getState();

                if (driverState != DriverState::DS_INITIALIZED) allInitialized = false;
                if (driverState != DriverState::DS_TERMINATED) allTerminated = false;
                if (driverState == DriverState::DS_INITIALIZING) oneInitializing = true;
                if (driverState == DriverState::DS_TERMINATING) oneTerminating = true;
                if (driverState == DriverState::DS_INITIALIZED) oneInitialized = true;
                if (driverState == DriverState::DS_TERMINATED) oneTerminated = true;
                if (driverState == DriverState::DS_RECOVERY_REQUIRED) worstState = SystemState::SS_RECOVERY_REQUIRED;
            }
        }
    }
    if (oneInitializing)
    {
        newState = SystemState::SS_INITIALIZING;
    } else if (oneTerminating) {
        newState = SystemState::SS_TERMINATING;
    } else if (worstState == SystemState::SS_RECOVERY_REQUIRED){
        newState = worstState;
    }else if (allInitialized) {
        newState = SystemState::SS_INITIALIZED;
    } else if (allTerminated) {
        newState = SystemState::SS_TERMINATED;
    } else if ((!allInitialized) && (!allTerminated) && oneInitialized && oneTerminated) {
        newState = SystemState::SS_PARTIALLY_INITIALIZED;
    } else if ((worstState != SystemState::SS_INITIALIZED) && oneTerminated) {
        newState = SystemState::SS_TERMINATED;
    } else if ((worstState != SystemState::SS_INITIALIZED) && oneInitialized){
        newState = worstState;
    }

    setSystemState(newState);
}
void IGSxGUI::DriverManager::registerToSystemStateChanged(const SystemStateChangedCallback& cb)
{
    m_systemStateChanged.connect(cb);
}

void IGSxGUI::DriverManager::unregisterToSystemStateChanged(const SystemStateChangedCallback& cb)
{
    m_systemStateChanged.disconnect(&cb);
}

void IGSxGUI::DriverManager::setSystemState(const SystemState::SystemStateEnum &state)
{
    if (m_systemState != state)
    {
        std::string message = STRING_NEW_SYSTEM_STATE + SystemState::toString(state);
        IGS_INFO(message);
    }
    m_systemState = state;
    m_systemStateChanged(state);
}

void IGSxGUI::DriverManager::initialize()
{
    try
    {
        addSystemFunctions(InitTerminate::getInstance()->getSysfuns());
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
        setSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }

    for (size_t i = 0; i < m_systemFunctions.size(); ++i)
    {
        MetaDescriptions drivers;
        try
        {
            drivers = InitTerminate::getInstance()->getDrivers(m_systemFunctions[i]->getName());
        } catch (IGS::Exception& ex)
        {
            IGS_ERROR(ex.what());
            setSystemState(SystemState::SS_RECOVERY_REQUIRED);
        }

        for (size_t j = 0; j < drivers.size(); j++ )
        {
            DriverStatus locDriverStatus(DriverState::DS_RECOVERY_REQUIRED);
            try
            {
                locDriverStatus = InitTerminate::getInstance()->getDriverStatus(drivers[j].name());
            } catch (IGS::Exception& ex)
            {
                IGS_ERROR(ex.what());
                setSystemState(SystemState::SS_RECOVERY_REQUIRED);
            }
            m_systemFunctions[i]->addDriver(drivers[j], locDriverStatus.driverState());
        }
    }

    try
    {
        InitTerminate::getInstance()->subscribeToDriverStatusChanged(boost::bind(&IGSxGUI::DriverManager::onDriverStatusChanged, this, _1, _2));
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
        setSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }

    determineSystemState();
}

void IGSxGUI::DriverManager::onDriverStatusChanged(const std::string& driverName, const DriverStatus& status) const
{
    Driver* driver = getDriver(driverName);

    if (driver != NULL)
    {
        driver->updateDriverState(status.driverState());
    }
}
