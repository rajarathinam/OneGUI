/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADT_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxADT interface
|
| ! \file        IGSxADT_impl.cpp
| ! \brief       Stub impementation of IGSxADT interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxADT_impl.hpp"
#include <iostream>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    std::string name;
    std::string subsystem;
    std::string description;
    std::string descriptionFile;
} gMetaType;

gMetaType gADT[] = {
    {"Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"},
    {"Collector Cooling", "Environmental control", "Collector Cooling ADT", "CCD_CCS.html"},
    {"Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "DGD_CCS.html"},
    {"Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "LEF_FFA.html"},
    {"GVA", "Gas and vacuum", "GVA ADT", "LSC_AlignmentADT.html"},
    {"HP-RGA", "Environmental control", "HP-RGA ADT", "LasersADT.html"},
    {"Heated Tin Vanes Bucket", "Tin Mitigation", "The ADT of the Heated Tin Vanes Bucket (HTVB)", "VDT_DCR.html"},
    {"Plasma Control", "Plasma Generation and Energy Control", "Plasma Control ADT", "PDH_PCL.html"},
    {"Real Time Streaming", "Generic Diagnostics", "The ADT for Real Time data Streaming", "VDA_TvbPlus.html"},
    {"Timing and Energy Control", "Plasma Generation and Energy Control", "Timing and Energy Control (TEC) ADT", "VDA_Fatc.html"},
    {"Vanes Manual Thermal Cycling", "Tin Mitigation", "ADT for the manual thermal cycling of the vanes", "LSC_SystemInfoADT.html"},
    {"Vessel Cooling", "Environmental control", "Vessel Cooling ADT", "LasersADT_HPSM.html"}
};
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxADT::ADT *IGSxADT::ADT_Stub::getInstance()
{
    static ADT_Stub _instance;
    return &_instance;
}

IGSxADT::ADT* IGSxADT::ADT::instance = IGSxADT::ADT_Stub::getInstance();

IGSxADT::ADT_Stub::ADT_Stub()
{
}

void IGSxADT::ADT_Stub::getAdts(MetaDescriptions& adts)
{
    for (size_t i = 0; i < sizeof(gADT) / sizeof(*gADT); i++)
    {
        gMetaType* adt = &gADT[i];
        adts.push_back(MetaDescription(adt->name, adt->subsystem, adt->description, adt->descriptionFile));
    }
}

void IGSxADT::ADT_Stub::startAdt(const std::string &adtName)
{
    std::cerr << "Adt : " << adtName << " started" << std::endl;
}


