/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxApplication.cpp
| Author       : Raja A
| Description  : Implementation for Application class
|
| ! \file        IGSxGUIxApplication.cpp
| ! \brief       Implementation for Application class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#include <string>
#include <SUIApplication.h>
#include <SUIResourcePath.h>
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxIStubView.hpp"
#include "IGSxStubView.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxApplication.hpp"
#include <boost/asio.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/thread.hpp>




const std::string IGSxGUIxApplication::STRING_SIMULATION = "simulation";

IGSxGUIxApplication::IGSxGUIxApplication(int argc, char *argv[], const std::string &resourcePath):m_argc(argc), m_argv(argv), m_resourcePath(resourcePath)
{
}

int IGSxGUIxApplication::exec()
{
    int result = 1;
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(m_argc, m_argv);
    SUI::ResourcePath::getInstance()->setResourcePath(m_resourcePath);

    if (m_argc == 1)
    {
        /*IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
        if (splashView != NULL)
        {
            splashView->show();
            delete splashView;
            splashView = NULL;
        }
        */

        //IGSxGUI::PluginFactory::getInstance().initialize();

       IGSxGUI::IMainView *mainView; mainView = new IGSxGUI::MainView();
        if (mainView != NULL)
        {
            mainView->show();
            result = app->exec();
            delete mainView;
            mainView = NULL;
        }
    } else {
        std::string strPluginName(m_argv[1]);
        if (strPluginName == IGSxGUIxApplication::STRING_SIMULATION)
        {
            /*IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
            if (splashView != NULL)
            {
                splashView->show();
                delete splashView;
                splashView = NULL;
            }
            IGSxGUI::PluginFactory::getInstance().initialize();*/

            // Start stub implementations
            dynamic_cast<IGSxKPI::KPI_Stub*>(IGSxKPI::KPI::getInstance())->enableKPIGeneration(true);
            IGSxGUI::IStubView *stubView;
            stubView = new IGSxGUI::StubView();
            if (stubView != NULL)
            {
                stubView->show();
            }

            IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
            if (mainView != NULL)
            {
                mainView->show();
                result = app->exec();
                delete mainView;
                mainView = NULL;

                if (stubView != NULL)
                {
                    delete stubView;
                    stubView = NULL;
                }
            }
        }
    }
    // execute the application (main eventloop)
    return result;
}

