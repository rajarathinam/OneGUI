//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IAnimatable.
// !\description Header file for class SUI::IAnimatable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIANIMATABLE_H
#define SUIIANIMATABLE_H

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the animation property of a widget
 */
class IAnimatable
{
public:
    virtual ~IAnimatable() {}

    /*!
     * \brief startAnimation
     * starts the animation
     */
    virtual void startAnimation() = 0;

    /*!
     * \brief stopAnimation
     * stops the animation
     */
    virtual void stopAnimation() = 0;
};
}

#endif // IANIMATABLE_H
