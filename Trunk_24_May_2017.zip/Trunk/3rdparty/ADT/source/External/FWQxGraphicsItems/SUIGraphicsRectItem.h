//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GraphicsRectItem.
// !\description Header file for class SUI::GraphicsRectItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGRAPHICSRECTITEM_H
#define SUIGRAPHICSRECTITEM_H

#include "FWQxGraphicsItems/SUIGraphicsItem.h"
#include "FWQxCore/SUIColorEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief The GraphicsRect class
 */
class SUI_SHARED_EXPORT GraphicsRectItem : public GraphicsItem
{
public:
    virtual ~GraphicsRectItem();

    /*!
     * \brief getPenColor
     * Returns the color of this pen's brush
     * \return
     */
    SUI::ColorEnum::Color getPenColor() const;

    /*!
     * \brief setPenColor
     * Sets the color of this pen's brush to the given color
     * \param color
     */
    void setPenColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setPenWidth
     * Sets the pen width to the given width in pixels with integer precision
     * \param width
     */
    void setPenWidth(int width);

    /*!
     * \brief getPenWidth
     * Returns the pen width with integer precision
     * \return
     */
    int getPenWidth() const;

    /*!
     * \brief getBrushColor
     * Returns the color of this pen's brush
     * \return
     */
    SUI::ColorEnum::Color getBrushColor() const;

    /*!
     * \brief setBrushColor
     * Sets the color of this pen's brush to the given color
     * \param color
     */
    void setBrushColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief setSize
     * Sets the item's rectangle to be the given width and hight
     * \param width
     * \param height
     */
    void setSize(double width, double height);

    /*!
     * \brief getWidth
     * Returns the width of the rectangle
     * \return
     */
    double getWidth() const;

    /*!
     * \brief getHeight
     * Returns the height of the rectangle
     * \return
     */
    double getHeight() const;
    
    /*!
     * \brief penColorChanged
     * Callback that is triggered when the pen's color changed
     */
    boost::function<void()> penColorChanged;

    /*!
     * \brief brushColorChanged
     * Callback that is triggered when the brush's color changed
     */
    boost::function<void()> brushColorChanged;

private:
    friend class ObjectFactory;
    explicit GraphicsRectItem(SUI::GraphicsItem *parent = NULL);
    GraphicsRectItem(const GraphicsRectItem &copy);
    GraphicsRectItem &operator=(const GraphicsRectItem &copy);

    SUI::ColorEnum::Color penColor;
};
}

#endif // SUIGRAPHICSRECTITEM_H
