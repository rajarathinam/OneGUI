//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ButtonBar.
// !\description Header file for class SUI::ButtonBar.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBUTTONBAR_H
#define SUIBUTTONBAR_H

#include "FWQxWidgets/SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ButtonBar class
 */
class SUI_SHARED_EXPORT ButtonBar : public Widget
{
public:
    virtual ~ButtonBar();
    
protected:
    ButtonBar();
};
}
#endif // SUIBUTTONBAR_H
