//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ImageWidget.
// !\description Header file for class SUI::ImageWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIMAGEWIDGET_H
#define SUIIMAGEWIDGET_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIImage.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ImageWidget class
 */
class SUI_SHARED_EXPORT ImageWidget : public Widget, public IImage
{
public:
    virtual ~ImageWidget();
    
protected:
    ImageWidget();

};
}

#endif // SUIIMAGEWIDGET_H
