
//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DateTimeEditImpl.
// !\description Header file for class SUI::DateTimeEditImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIDATETIMEEDITIMPL_H
#define SUIDATETIMEEDITIMPL_H

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIDateTimeEdit.h"

class QDateTimeEdit;
class CustomDateTimeEditPopup;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The DateTimeEdit class
 */
class DateTimeEditImpl : public BaseWidget, public DateTimeEdit
{
    Q_OBJECT
public:
    explicit DateTimeEditImpl(QWidget *parent = NULL);
    virtual ~DateTimeEditImpl();

    virtual void initialize(const ObjectContext &context);
    virtual QWidget *getWidget() const;

    virtual void setTime(const boost::shared_ptr<SUI::Time> &time);

    virtual boost::shared_ptr<Time> getTime() const;
    virtual void setTimeSpec(DateTimeEnum::TimeSpec spec);

    virtual DateTimeEnum::TimeSpec getTimeSpec() const;
    virtual void setDate(const boost::shared_ptr<SUI::Date> &dt);

    virtual void getDate(int * getYear, int * getMonth, int * getDay);
    virtual bool isValid() const;

public slots:
    void onNewDateTimeSelected(const QDate &date, const QTime &time);
    void onDateTimeChanged(const QDateTime &dateTime);

private:
    QDateTimeEdit *mDateTime;
    CustomDateTimeEditPopup *mDateTimePopup;
    
    void positionPopup();

    DateTimeEditImpl(const DateTimeEditImpl &rhs);
    DateTimeEditImpl &operator=(const DateTimeEditImpl &rhs);
};
}

#endif // SUIDATETIMEEDITIMPL_H
