//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckGroupBoxImpl.
// !\description Header file for class SUI::CheckGroupBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUICHECKGROUPBOXIMPL_H
#define SUICHECKGROUPBOXIMPL_H

#include <QGroupBox>

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUICheckGroupBox.h"


namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The CheckGroupBox class
 */
class CheckGroupBoxImpl : public BaseWidget, public CheckGroupBox
{
    Q_OBJECT
public:
    explicit CheckGroupBoxImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QGroupBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setChecked(bool checked);
    virtual bool isChecked() const;

    virtual SUI::ColorEnum::Color getBGColor() const;
    virtual void setBGColor(const SUI::ColorEnum::Color color);

private slots:
    void handleCheckedChanged(bool newState);

private:
    CheckGroupBoxImpl(const CheckGroupBoxImpl &rhs);
    CheckGroupBoxImpl &operator=(const CheckGroupBoxImpl &rhs);

};
}

#endif // SUICHECKGROUPBOXIMPL_H
