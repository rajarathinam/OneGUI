/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlert.hpp
| Author       : Venugopal S
| Description  : Header file for Alert
|
| ! \file        IGSxGUIxAlert.hpp
| ! \brief       Header file for Alert
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERT_HPP
#define IGSXGUIXALERT_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxERR.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class Alert
{
 public:
    explicit Alert(const IGSxERR::ActivatedAlert& alert);
    virtual ~Alert();

    int getLogId() const;
    std::string getLogCode() const;
    time_t getTime() const;
    IGSxERR::AlertSeverity::AlertSeverityEnum getSeverity() const;
    std::string getUserText() const;
    std::string getDeveloperText() const;
    bool isNew() const;
    void setNew(bool isNew);

 private:
    Alert(Alert const &);
    Alert& operator=(Alert const &);

    IGSxERR::ActivatedAlert m_alert;
    bool m_isNew;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXALERT_HPP
