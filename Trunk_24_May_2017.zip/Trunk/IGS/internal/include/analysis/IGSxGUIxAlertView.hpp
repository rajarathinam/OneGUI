/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.hpp
| Author       : Venugopal S
| Description  : Header file for Alert view
|
| ! \file        IGSxGUIxAlertView.hpp
| ! \brief       Header file for Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTVIEW_HPP
#define IGSXGUIXALERTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxIAlertView.hpp"
#include "IGSxGUIxAlertPresenter.hpp"
#include "IGSxGUIxUtil.hpp"
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AlertView;
class Label;
}
namespace IGSxGUI{

class AlertView : public IAlertView
{
 public:
    explicit AlertView(AlertManager* pAlertManager);
    virtual ~AlertView();

    void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    void updateAlerts(int nAlertCount, AlertInfo alertInfo);
    void setActive(bool);

 private:
    AlertView(const AlertView &);
    AlertView& operator=(const AlertView &);

    void addAlert(Alert* alert);
    void removeAlert(int nAlertId);

    void onSeverityBtnClicked();
    void onCodeBtnClicked();
    void onMessageBtnClicked();
    void onTimeReporatedBtnClicked();

    void sortColumn(int column);

    SUI::AlertView *sui;
    AlertPresenter *m_presenter;
    IGSxGUI::SortOrder::SortOrderEnum m_order;
    int m_column;

    static const std::string ALERTVIEW_LOAD_FILE;
    static const std::string STRING_HEADER;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;

    static const std::string STYLE_ALARM;
    static const std::string STYLE_ERROR;
    static const std::string STYLE_WARNING;

    static const std::string STRING_ALARM;
    static const std::string STRING_ERROR;
    static const std::string STRING_WARNING;

    static const std::string STRING_NEW;
    static const std::string STRING_NEWLABEL;

    static const int COLUMN_IMAGE;
    static const int COLUMN_SEVERITY;
    static const int COLUMN_LOGCODE;
    static const int COLUMN_MESSAGE;
    static const int COLUMN_TIME;
    static const int COLUMN_NEW;
    static const int COLUMN_SEVERITY_TEXT;
    static const int COLUMN_LOGID;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXALERTVIEW_HPP
