/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisPresenterTest.hpp
| Author       : Raja A
| Description  : Header file for Analysis Presenter test
|
| ! \file        IGSxGUIxAnalysisPresenterTest.hpp
| ! \brief       Header file for Analysis Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXANALYSISPRESENTERTEST_H
#define IGSXGUIXANALYSISPRESENTERTEST_H
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <string>
#include "IGSxGUIxAnalysisPresenter.hpp"

using std::vector;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class AnalysisPresenterTest : public ::testing::Test
{
 public:
  AnalysisPresenterTest(){}
  virtual ~AnalysisPresenterTest(){}
 protected:
  IGSxGUI::ADTManager* m_adtManager;
  virtual void SetUp()
  {
      m_adtManager = new IGSxGUI::ADTManager();

      IGSxADT::MetaDescriptions adtDescriptions;
      adtDescriptions.push_back(IGSxADT::MetaDescription("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Collector Cooling", "Environmental control", "Collector Cooling ADT", " CCD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "DGD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "LEF_FFA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("GVA", "Gas and vacuum", "GVA ADT", "GVA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("HP-RGA", "Environmental control", "HP-RGA ADT", "RCA_RCM.html"));

      for (size_t i = 0; i < adtDescriptions.size(); i++)
      {
          IGSxGUI::ADT* adt = new IGSxGUI::ADT(adtDescriptions[i]);
          m_adtManager->add(adt);
      }
  }
  virtual void TearDown()
  {
      std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
      for (size_t i = 0; i < adtList.size(); i++)
      {
          m_adtManager->remove(adtList[i]);
      }

      delete m_adtManager;
      m_adtManager = NULL;
  }
};

class AnalysisViewStub : public IGSxGUI::IAnalysisView
{
 private:
  bool m_status;
 public:
    AnalysisViewStub() : m_status(false){}
    ~AnalysisViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {
        m_status = true;
    }
    void setActive(bool /*bActive*/) {
        m_status = true;
    }
    void setStatus(bool bstatus)
    {
        m_status = bstatus;
    }
    bool getStatus()
    {
        return m_status;
    }
};

#endif  // IGSXGUIXANALYSISPRESENTERTEST_H
