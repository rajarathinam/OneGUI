/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR_impl.hpp
| Author       : Surya Tiwari
| Description  : Header file for IGSxERR implementation
|
| ! \file        IGSxERR_impl.hpp
| ! \brief       Header file for IGSxERR implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXERR_IMPL_HPP
#define IGSXERR_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxERR.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
// forward declaration
namespace SUI {
class Timer;
}

namespace IGSxERR {

class EventLogger_Stub :public EventLogger
{
 public:
    static EventLogger* getInstance();

    virtual std::string getEventLog();
    virtual std::string getPreviousEventLog();

 protected:
    EventLogger_Stub();
    virtual ~EventLogger_Stub() {}

    std::string m_currentfilename;
    std::string m_previousfilename;
};

class Alert_Stub :public Alert
{
 public:
    static Alert* getInstance();

    virtual void getActiveAlerts(ActiveAlertList& alerts);

    virtual void subscribeToAlertRaised(const AlertRaisedCallback& cb);
    virtual void unsubscribeToAlertRaised();
    virtual void subscribeToAlertDeactivated(const AlertDeactivatedCallback& cb);
    virtual void unsubscribeToAlertDeactivated();

 protected:
    Alert_Stub();
    virtual ~Alert_Stub();

 private:
    void onAlertCreateTimeout();
    void onAlertKillTimeout();
    int getRandomNumber(int low, int high) const;
    AlertSeverity::AlertSeverityEnum getAlertSeverity() const;

    static const int ALERT_TIMER_INTERVAL;
    static const int ALERT_TIMER_MIN_INTERVAL;
    static const int ALERT_TIMER_MAX_INTERVAL;
    static const std::string USER_CODE;
    static const std::string DEVELOPER_CODE;
    static const std::string LOGCODE_PREFIX;

    boost::shared_ptr<SUI::Timer> m_timerAlertCreate;
    boost::shared_ptr<SUI::Timer> m_timerAlertKill;

    std::vector<ActivatedAlert> m_ActiveAlertList;

    int m_uniqueAlertId;
    AlertRaisedCallback m_AlertRaisedCb;
    AlertDeactivatedCallback m_AlertDeactivatedCb;
};
}  // namespace IGSxERR
#endif  // IGSXERR_IMPL_HPP
