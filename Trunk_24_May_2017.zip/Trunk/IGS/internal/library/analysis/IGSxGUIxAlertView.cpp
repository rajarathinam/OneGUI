/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert view
|
| ! \file        IGSxGUIxAlertView.cpp
| ! \brief       Implementation of Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAlertView.hpp"
#include <boost/lexical_cast.hpp>
#include <boost/foreach.hpp>
#include <algorithm>
#include <string>
#include <vector>
#include <SUITableWidget.h>
#include <SUITableWidgetItem.h>
#include <SUITimer.h>
#include <SUIButton.h>
#include <SUILabel.h>
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxMoc_AlertView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AlertView::ALERTVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxAlert.xml");
const std::string IGSxGUI::AlertView::STRING_HEADER = "Active alerts";
const std::string IGSxGUI::AlertView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::AlertView::STRING_CLOSE_BRACKET = ")";

const std::string IGSxGUI::AlertView::STYLE_ALARM = "alarmbuttonimagered";
const std::string IGSxGUI::AlertView::STYLE_ERROR = "errorimage";
const std::string IGSxGUI::AlertView::STYLE_WARNING = "warningimage";

const std::string IGSxGUI::AlertView::STRING_ALARM = "Alarm";
const std::string IGSxGUI::AlertView::STRING_ERROR = "Error";
const std::string IGSxGUI::AlertView::STRING_WARNING = "Warning";

const std::string IGSxGUI::AlertView::STRING_NEW = "NEW";
const std::string IGSxGUI::AlertView::STRING_NEWLABEL = "newLabel";

const int IGSxGUI::AlertView::COLUMN_IMAGE = 0;
const int IGSxGUI::AlertView::COLUMN_SEVERITY = 1;
const int IGSxGUI::AlertView::COLUMN_LOGCODE = 2;
const int IGSxGUI::AlertView::COLUMN_MESSAGE = 3;
const int IGSxGUI::AlertView::COLUMN_TIME = 4;
const int IGSxGUI::AlertView::COLUMN_NEW = 5;
const int IGSxGUI::AlertView::COLUMN_LOGID = 6;

IGSxGUI::AlertView::AlertView(IGSxGUI::AlertManager *pAlertManager) :
    sui(new SUI::AlertView),
    m_order(SortOrder::Descending),
    m_column(COLUMN_SEVERITY)
{
    m_presenter = new AlertPresenter(this, pAlertManager);
}

IGSxGUI::AlertView::~AlertView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::AlertView::show(SUI::Container *MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ALERTVIEW_LOAD_FILE.c_str(), MainScreenContainer);

        sui->btnSeverity->clicked = boost::bind(&AlertView::onSeverityBtnClicked, this);
        sui->btnCode->clicked = boost::bind(&AlertView::onCodeBtnClicked, this);
        sui->btnMessage->clicked = boost::bind(&AlertView::onMessageBtnClicked, this);
        sui->btnTimeReported->clicked = boost::bind(&AlertView::onTimeReporatedBtnClicked, this);
        onSeverityBtnClicked();

        sui->tawAlert->insertRows(sui->tawAlert->rowCount(), 1);
        sui->tawAlert->removeRow(0);
        sui->tawAlert->setRowVisible(0, false);
        sui->tawAlert->showGrid(false);
        IGSxGUI::Util::setScalable(sui->tawAlert);

        std::vector<Alert*> alerts = m_presenter->getActiveAlerts();
        BOOST_FOREACH(Alert* alert, alerts)
        {
            addAlert(alert);
        }
    }
}

void IGSxGUI::AlertView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::AlertView::updateAlerts(int nAlertCount, AlertInfo alertInfo)
{
    sui->lblHeader->setText(STRING_HEADER + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET);

    if (alertInfo.bIsAlertAdded)
    {
        Alert* alert = m_presenter->getAlert(alertInfo.alertId);
        addAlert(alert);
        // Try to resume the sorting
        sortColumn(m_column);
        sortColumn(m_column);
        // ToDo fix this, this will probably not perform
    } else {
        removeAlert(alertInfo.alertId);
    }
}

void IGSxGUI::AlertView::addAlert(Alert *alert)
{
    int rowNumber = 0;
    if (sui->tawAlert->rowCount() == 1 && !sui->tawAlert->isRowVisible(0))
    {
        sui->tawAlert->setRowVisible(0, true);
    } else {
        sui->tawAlert->insertRows(sui->tawAlert->rowCount(), 1);
        rowNumber = ((m_order == SortOrder::Descending) ? sui->tawAlert->rowCount() - 1 : 0);
    }

    switch (alert->getSeverity())
    {
        case IGSxERR::AlertSeverity::ALARM:
        {
            IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_exclamation);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_ALARM);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ALARM);
            break;
        }
        case IGSxERR::AlertSeverity::ERROR:
        {
            IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_times_circle);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_ERROR);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ERROR);
            break;
        }
        case IGSxERR::AlertSeverity::WARNING:
        {
            IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_WARNING);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_WARNING);
            break;
        }
        case IGSxERR::AlertSeverity::EVENT:
        default:
        {
            // Ignore events and not known severtities
            break;
        }
    }

    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGCODE))->setText(alert->getLogCode());
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_MESSAGE))->setText(alert->getUserText());
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_TIME))->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, alert->getTime()));

    if (alert->isNew())
    {
        alert->setNew(false); // It has been shown, so put it to false
        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setText(STRING_NEW);
        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setStyleSheetClass(STRING_NEWLABEL);
    }
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->setText(boost::lexical_cast<std::string>(alert->getLogId()));
}

void IGSxGUI::AlertView::removeAlert(int nAlertId)
{
    if (sui->tawAlert->rowCount() == 1)
    {
        sui->tawAlert->setRowVisible(0, false);
    } else {
        for (int rowNumber = 0; rowNumber < sui->tawAlert->rowCount(); rowNumber++)
        {
            if (dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->getText() == boost::lexical_cast<std::string>(nAlertId))
            {
                sui->tawAlert->removeRow(rowNumber);
            }
        }
    }
}

void IGSxGUI::AlertView::onSeverityBtnClicked()
{
    sortColumn(COLUMN_SEVERITY);
}

void IGSxGUI::AlertView::onCodeBtnClicked()
{
    sortColumn(COLUMN_LOGCODE);
}

void IGSxGUI::AlertView::onMessageBtnClicked()
{
    sortColumn(COLUMN_MESSAGE);
}

void IGSxGUI::AlertView::onTimeReporatedBtnClicked()
{
    sortColumn(COLUMN_TIME);
}

void IGSxGUI::AlertView::sortColumn(int columnId)
{
    if (m_column == columnId)
    {
        m_order = (m_order == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    } else
    {
        m_order = SortOrder::Descending;
    }
    m_column = columnId;

    IGSxGUI::Util::sort(m_column, sui->tawAlert, m_order);
}
