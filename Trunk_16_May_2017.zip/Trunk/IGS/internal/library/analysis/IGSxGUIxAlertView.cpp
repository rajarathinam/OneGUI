/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert view
|
| ! \file        IGSxGUIxAlertView.cpp
| ! \brief       Implementation of Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAlertView.hpp"
#include <boost/lexical_cast.hpp>
#include <boost/foreach.hpp>
#include <string>
#include <vector>
#include <SUITableWidget.h>
#include <SUITableWidgetItem.h>
#include <SUITimer.h>
#include <SUIButton.h>
#include <SUILabel.h>
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxMoc_AlertView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AlertView::ALERTVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxAlert.xml");
const std::string IGSxGUI::AlertView::STRING_HEADER = "Active alerts";
const std::string IGSxGUI::AlertView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::AlertView::STRING_CLOSE_BRACKET = ")";

const std::string IGSxGUI::AlertView::STYLE_ALARM = "alarmbuttonimagered";
const std::string IGSxGUI::AlertView::STYLE_ERROR = "errorimage";
const std::string IGSxGUI::AlertView::STYLE_WARNING = "warningimage";

const std::string IGSxGUI::AlertView::STRING_ALARM = "Alarm";
const std::string IGSxGUI::AlertView::STRING_ERROR = "Error";
const std::string IGSxGUI::AlertView::STRING_WARNING = "Warning";

const std::string IGSxGUI::AlertView::STRING_NEW = "NEW";
const std::string IGSxGUI::AlertView::STRING_NEWLABEL = "newLabel";

const int IGSxGUI::AlertView::COLUMN_IMAGE = 0;
const int IGSxGUI::AlertView::COLUMN_SEVERITY = 1;
const int IGSxGUI::AlertView::COLUMN_LOGCODE = 2;
const int IGSxGUI::AlertView::COLUMN_MESSAGE = 3;
const int IGSxGUI::AlertView::COLUMN_TIME = 4;
const int IGSxGUI::AlertView::COLUMN_NEW = 5;
const int IGSxGUI::AlertView::COLUMN_SEVERITY_TEXT = 6;
const int IGSxGUI::AlertView::COLUMN_LOGID = 7;

IGSxGUI::AlertView::AlertView(IGSxGUI::AlertManager *pAlertManager) :
    sui(new SUI::AlertView),
    severityOrder(false),
    codeOrder(false),
    messageOrder(false),
    timeReportedOrder(false)
{
    m_presenter = new AlertPresenter(this, pAlertManager);
}

IGSxGUI::AlertView::~AlertView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::AlertView::show(SUI::Container *MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ALERTVIEW_LOAD_FILE.c_str(), MainScreenContainer);

        sui->btnSeverity->clicked = boost::bind(&AlertView::onSeverityBtnClicked, this);
        sui->btnCode->clicked = boost::bind(&AlertView::onCodeBtnClicked, this);
        sui->btnMessage->clicked = boost::bind(&AlertView::onMessageBtnClicked, this);
        sui->btnTimeReported->clicked = boost::bind(&AlertView::onTimeReporatedBtnClicked, this);

        sui->tawAlert->setRowVisible(0, false);
        sui->tawAlert->showGrid(false);
        IGSxGUI::Util::setScalable(sui->tawAlert);


        std::vector<Alert*> alerts = m_presenter->getActiveAlerts();
        BOOST_FOREACH(Alert* alert, alerts)
        {
            addAlert(alert);
        }
    }
}

void IGSxGUI::AlertView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::AlertView::updateAlerts(int nAlertCount, AlertInfo alertInfo)
{
    sui->lblHeader->setText(STRING_HEADER + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET);

    if (alertInfo.bIsAlertAdded)
    {
        Alert* alert = m_presenter->getAlert(alertInfo.alertId);
        addAlert(alert);
    } else {
        removeAlert(alertInfo.alertId);
    }
}

void IGSxGUI::AlertView::addAlert(Alert *alert)
{
    sui->tawAlert->appendRow();
    int rowNumber = sui->tawAlert->rowCount() - 1;

    switch(alert->getSeverity())
    {
        case IGSxERR::AlertSeverity::ALARM:
        {
            dynamic_cast<SUI::Button*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_ALARM);
            dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ALARM);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY_TEXT))->setText("1");
            break;
        }
        case IGSxERR::AlertSeverity::ERROR:
        {
            dynamic_cast<SUI::Button*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_ERROR);
            dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ERROR);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY_TEXT))->setText("2");
            break;
        }
        case IGSxERR::AlertSeverity::WARNING:
        {
            dynamic_cast<SUI::Button*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE))->setStyleSheetClass(STYLE_WARNING);
            dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_WARNING);
            dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY_TEXT))->setText("3");
            break;
        }
        case IGSxERR::AlertSeverity::EVENT:
        default:
        {
            // Ignore events and not known severtities
            break;
        }
    }

    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGCODE))->setText(alert->getLogCode());
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_MESSAGE))->setText(alert->getUserText());
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_TIME))->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, alert->getTime()));
    if (alert->isNew())
    {
        dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setText(STRING_NEW);
        dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setStyleSheetClass(STRING_NEWLABEL);
    }
    dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->setText(boost::lexical_cast<std::string>(alert->getLogId()));
    alert->setNew(false); // It has been shown, so put it to false
}

void IGSxGUI::AlertView::removeAlert(int nAlertId)
{
    for (int rowNumber = 0; rowNumber < sui->tawAlert->rowCount(); rowNumber++)
    {
        if (dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->getText() == boost::lexical_cast<std::string>(nAlertId))
        {
            sui->tawAlert->removeRow(rowNumber);
        }
    }
}

void IGSxGUI::AlertView::onSeverityBtnClicked()
{
  IGSxGUI::Util::sort(COLUMN_SEVERITY_TEXT, sui->tawAlert, severityOrder);
  severityOrder = !severityOrder;
}

void IGSxGUI::AlertView::onCodeBtnClicked()
{
  IGSxGUI::Util::sort(COLUMN_LOGCODE, sui->tawAlert, codeOrder);
  codeOrder = !codeOrder;
}

void IGSxGUI::AlertView::onMessageBtnClicked()
{
  IGSxGUI::Util::sort(COLUMN_MESSAGE, sui->tawAlert, messageOrder);
  messageOrder = !messageOrder;
}

void IGSxGUI::AlertView::onTimeReporatedBtnClicked()
{
  IGSxGUI::Util::sort(COLUMN_TIME, sui->tawAlert, timeReportedOrder);
  timeReportedOrder = !timeReportedOrder;
}
