/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemDateTime.cpp
| Author       : Raja A
| Description  : System Date Time Implementation
|
| ! \file        IGSxGUIxSystemDateTime.cpp
| ! \brief       System Date Time Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxSystemDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SystemDateTime::getSystemCurrentDateTime(const SystemDateTime::eSystemDateTime& format)
{
    return formatDateTime(format, time(0));
}

const std::string IGSxGUI::SystemDateTime::formatDateTime(const SystemDateTime::eSystemDateTime& format, time_t time)
{
    struct tm  tstruct;
    char       buf[CONVERSION_BUFFER_SIZE];
    tstruct = *localtime_r(&time, &tstruct);
    std::string currenttime = "";

    switch(format)
    {
        case SystemDateTime::STR_TIME:
        {
            strftime(buf, sizeof(buf), STRING_TIME_FORMAT.c_str(), &tstruct);
            currenttime = buf;
            break;
        }
        case SystemDateTime::STR_DATE:
        {
            strftime(buf, sizeof(buf), STRING_DATE_FORMAT.c_str(), &tstruct);
            currenttime = buf;
            break;
        }
        case SystemDateTime::STR_DATE_TIME:
        {
            strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT.c_str(), &tstruct);
            currenttime = buf;
            break;
        }
        case SystemDateTime::STR_DATE_TIME_SEC:
        default:
        {
            strftime(buf, sizeof(buf), STRING_DATETIMESEC_FORMAT.c_str(), &tstruct);
            currenttime = buf;
            break;
        }
    }

    return currenttime;
}
