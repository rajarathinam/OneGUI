/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenterTest.hpp
| Author       : Raja
| Description  : Header file for CPD Presenter test
|
| ! \file        IGSxGUIxCPDPresenterTest.hpp
| ! \brief       Header file for CPD Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDPRESENTERTEST_HPP
#define IGSXGUIXCPDPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <string>
#include "IGSxGUIxCPDPresenter.hpp"

using std::vector;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class CPDPresenterTest : public ::testing::Test
{
 public:
  CPDPresenterTest(){}
  virtual ~CPDPresenterTest(){}

 protected:
    IGSxGUI::CPDManager* m_cpdManager;
  virtual void SetUp()
  {
        m_cpdManager = new IGSxGUI::CPDManager();

        IGSxCPD::MetaDescriptions cpdDescriptions;
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDFFMDFC", "Calibration", "FinalFocusMetrology", "CPD FFM Default Filter Calibration", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html"));
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPD_CODMCL", "Performance", "Cleaning", "Collector and Metrology Cleaning CPD", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPD_CODMCL/CPD_CODMCL_description.html"));
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDDGSABC", "Calibration", "DropletGeneratorSteering", "DGS Actuator Basis Calibration", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSABC/CPDDGSABC_description.html"));
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("LDN_HPSNLC", "Diagnostics", "HighPowerSeed", "LDN_HPSNLC test", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/LDN_HPSNLC/LDN_HPSNLC_description.html"));
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDDGSESI", "Diagnostics", "DropletGeneratorSteering", "DGSS Encoder Loop System Identification", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSESI/CPDDGSESI_description.html"));
        cpdDescriptions.push_back(IGSxCPD::MetaDescription("FDD_DUMREG", "Calibration", "FinalFocusAssembly", "FDD_DUMREG test", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/FDD_DUMREG/FDD_DUMREG_description.html"));

        for (size_t i = 0; i < cpdDescriptions.size(); i++)
        {
            IGSxGUI::CPD* cpd = new IGSxGUI::CPD(cpdDescriptions[i]);
            m_cpdManager->add(cpd);
        }
  }
  virtual void TearDown()
  {
        std::vector<IGSxGUI::CPD*> cpdList = m_cpdManager->retrieveAll();
        for (size_t i = 0; i < cpdList.size(); i++)
        {
            m_cpdManager->remove(cpdList[i]);
        }

        delete m_cpdManager;
        m_cpdManager = NULL;
  }
};

class CPDViewStub : public IGSxGUI::ICPDView
{
 private:
  bool m_status;
 public:
    CPDViewStub() :m_status(false){}
    ~CPDViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {
        m_status = true;
    }
    void setActive(bool /*bActive*/) {
        m_status = true;
    }
    void updateStatus(const std::string& /*strCPD*/, const IGS::Result& /*result*/) {
        m_status = true;
    }
    void setStatus(bool bstatus)
    {
        m_status = bstatus;
    }
    bool getStatus()
    {
        return m_status;
    }
};

#endif  // IGSXGUIXCPDPRESENTERTEST_HPP
