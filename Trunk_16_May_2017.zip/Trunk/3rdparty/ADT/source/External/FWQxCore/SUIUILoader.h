//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::UILoader.
// !\description Header file for class SUI::UILoader.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIUILOADER_H
#define SUIUILOADER_H

#include <string>

namespace SUI {
class Dialog;
class Widget;

/*!
 * \ingroup FWQxCore
 *
 * \brief The UILoader class
 */
class UILoader
{
public:
    /*!
     * \brief loadUI
     * Loads a UI definition from an XML file and stores it in a Dialog object
     * \param xmlFile
     * \param id
     * \param parent
     * \return
     */
    static Dialog *loadUI(const std::string &xmlFile, const std::string &id = "0", Widget *parent = NULL);
};
}
#endif // SUIUILOADER_H
