//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief        Header file for Doxygen
// !\description  Header file for Doxygen
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef DOXYGEN_H
#define DOXYGEN_H

/*!
This file contains all the groups for the doxygen generation
*/

/*!
  The main groups are the projects

  \defgroup FWQxCore The Core API
  \defgroup FWQxWidgets The Widget API
  \defgroup FWQxGraphicsItems The GraphicsItem API
  \defgroup FWQxUtils The Util API
*/

#endif // DOXYGEN_H
