//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::XmlException.
// !\description Header file for class SUI::XmlException.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIXMLEXCEPTION_H
#define SUIXMLEXCEPTION_H

#include "FWQxCore/SUIException.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The XmlException class
 */
class SUI_SHARED_EXPORT XmlException : public Exception
{
public:
    /*!
     * \brief XmlException
     * Creates/constructs an XML exception object with the given message
     * \param msg
     */
    explicit XmlException(const std::string &msg);

private:
    XmlException();
};
}

#endif // SUIXMLEXCEPTION_H
