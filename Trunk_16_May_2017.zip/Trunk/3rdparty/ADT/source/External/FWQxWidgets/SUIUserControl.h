//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::UserControl.
// !\description Header file for class SUI::UserControl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIUSERCONTROL_H
#define SUIUSERCONTROL_H

#include "FWQxCore/SUISharedExport.h"
#include "FWQxCore/SUIIClickable.h"
#include "FWQxCore/SUIIHoverable.h"

#include "FWQxWidgets/SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The UserControl class
 */
class SUI_SHARED_EXPORT UserControl : public Widget, public IClickable, public IHoverable
{
public:
    virtual ~UserControl();
    
protected:
    UserControl();

};
}

#endif // SUIUSERCONTROL_H
