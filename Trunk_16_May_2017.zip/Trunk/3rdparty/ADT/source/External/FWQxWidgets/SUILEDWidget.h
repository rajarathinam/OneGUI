//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LEDWidget.
// !\description Header file for class SUI::LEDWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILEDWIDGET_H
#define SUILEDWIDGET_H

#include "FWQxCore/SUIDeprecated.h"

#include "FWQxCore/SUIIColorable.h"
#include "FWQxWidgets/SUIWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The LEDWidget class
 */
class SUI_DEPRECATED LEDWidget : public Widget, public IColorable
{
public:
    virtual ~LEDWidget();
    
protected:
    LEDWidget();

};
}

#endif // SUILEDWIDGET_H
