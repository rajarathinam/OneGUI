#
#
#-------------------------------------------------------------------------------
#   coverage.sh
#   
#   A script to run code coverage
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"
echo $(pwd)
LD_LIBRARY_PATH=$(pwd)/../../targets/library:$(pwd)/../../3rdparty/ADT/library:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
curDir=`pwd`
cd $(pwd)/../../targets/bin/

./UnitTest

cd ..

lcov -d . -c -o coverage.info
lcov --remove coverage.info "/usr*" -o coverage.info
lcov --remove coverage.info "*3rdparty*" -o coverage.info

genhtml -o ../html/ coverage.info

cd $curDir