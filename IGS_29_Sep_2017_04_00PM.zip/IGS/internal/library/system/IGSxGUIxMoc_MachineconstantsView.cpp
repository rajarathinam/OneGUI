

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.cpp
| ! \brief       Implementation of Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include <SUIUILoader.h>
#include <SUIObjectList.h>
#include <SUIDialog.h>
#include <SUIContainer.h>
#include <SUIButton.h>
#include <SUITableWidget.h>
#include <SUILineEdit.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::MachineconstantsView::MachineconstantsView() :
    dialog(NULL),
    btnParameterName(NULL),
    btnParameterValue(NULL),
    tawParameters(NULL),
    lneSearchParameterText(NULL),
    btnSearchParameter(NULL),
    btnSearchClear(NULL)
{
}

void SUI::MachineconstantsView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::MachineconstantsView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::MachineconstantsView::loadObjects(ObjectList* objectList)
{
  btnParameterName =  objectList->getObject<Button>("btnParameterName");
  btnParameterValue = objectList->getObject<Button>("btnParameterValue");
  tawParameters = objectList->getObject<TableWidget>("tawParameters");
  lneSearchParameterText = objectList->getObject<LineEdit>("lneSearchParameterText");
  btnSearchParameter = objectList->getObject<Button>("btnSearchParameter");
  btnSearchClear = objectList->getObject<Button>("btnSearchClear");

}

#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
