/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application view
|
| ! \file        IGSxGUIxMainView.cpp
| ! \brief       Implementation of Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMainView.hpp"
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread.hpp>
#include <string>
#include "IGSxGUIxMoc_MainView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxGUIxSplashView.hpp"
#include <SUIDialog.h>
#include <SUIButton.h>
#include <SUIGroupBox.h>
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIBusyIndicator.h>
#include <SUITimer.h>
#include "IGSxERR.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxLOG.hpp"
#include "SUIExternalEvent.h"
#include "SUIExternalEventHandler.h"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MainView::MAINVIEW_LOAD_FILE = "IGSxGUIxMainView.xml";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_SYSTEM = "System";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_DASHBOARD = "Dashboard";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ANALYSIS = "Analysis";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ERRORALARM = "ALARM";

const std::string IGSxGUI::MainView::IMAGE_WHITE_SYSTEM = "IGSxGUIxMain_WHITE_System.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_DASHBOARD = "IGSxGUIxMain_WHITE_Dashboard.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_ANALYSIS = "IGSxGUIxMain_WHITE_Analysis.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_WARNING = "IGSxGUIxMain_WHITE_Warning.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_CLOCK = "IGSxGUIxMain_WHITE_Clock.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_INFO = "IGSxGUIxMain_WHITE_Info.png";
const std::string IGSxGUI::MainView::IMAGE_WHITE_CHECKCIRCLE = "IGSxGUIxMain_WHITE_CheckCircle.png";

const std::string IGSxGUI::MainView::IMAGE_BLUE_SYSTEM = "IGSxGUIxMain_BLUE_System.png";
const std::string IGSxGUI::MainView::IMAGE_BLUE_DASHBOARD = "IGSxGUIxMain_BLUE_Dashboard.png";
const std::string IGSxGUI::MainView::IMAGE_BLUE_ANALYSIS = "IGSxGUIxMain_BLUE_Analysis.png";

const std::string IGSxGUI::MainView::IMAGE_GREEN_CHECKCIRCLE = "IGSxGUIxMain_GREEN_CheckCircle.png";
const std::string IGSxGUI::MainView::IMAGE_RED_WARNING_16PX = "IGSxGUIxMain_RED_Warning_16px.png";

const std::string IGSxGUI::MainView::STRING_MAINVIEW_SHOWN_LOG = "MainView is shown.";
const std::string IGSxGUI::MainView::STRING_INITIALIZED = "INITIALIZED";
const std::string IGSxGUI::MainView::STRING_TERMINATED = "TERMINATED";
const std::string IGSxGUI::MainView::STRING_PARTIALLY_INITIALIZED = "PARTIALLY..";
const std::string IGSxGUI::MainView::STRING_RECOVERY_REQUIRED = "RECOVERY...";

const std::string IGSxGUI::MainView::STRING_ALARM = "Alarm";
const std::string IGSxGUI::MainView::STRING_ERROR = "Error";
const std::string IGSxGUI::MainView::STRING_WARNING = "Warning";

const std::string IGSxGUI::MainView::STRING_DATE_TIME = "Date & time";
const std::string IGSxGUI::MainView::STRING_ALERTS = "ALERTS";

const std::string IGSxGUI::MainView::STYLE_HOVER_ON = "hoverOn";
const std::string IGSxGUI::MainView::STYLE_HOVER_OFF = "hoverOff";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_ON = "hoverOnAlarmButton";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_OFF = "hoverOffAlarmButton";

const std::string IGSxGUI::MainView::STYLE_POPUP_RED = "popupred";
const std::string IGSxGUI::MainView::STYLE_POPUP_YELLOW = "popupyellow";
const std::string IGSxGUI::MainView::STYLE_BLACK = "black";
const std::string IGSxGUI::MainView::STYLE_WHITE = "white";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_BUTTON = "TopbarButton";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_BUTTON_HOVER = "TopbarButtonHover";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_LABEL_WHITE = "TopbarButtonWhiteLabel";
const std::string IGSxGUI::MainView::STYLE_STATUSBAR_LABEL = "TopbarStatusLabel";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_STATUS_HOVER = "TopbarStatusHover";

const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU1_BUTTON = "System initialization";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU2_BUTTON = "System state manager";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU3_BUTTON = "Hardware reset";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU4_BUTTON = "Maintenance";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU5_BUTTON = "Service";

const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU1_BUTTON  = "Data View";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU2_BUTTON  = "Alerts";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU3_BUTTON  = "Advanced diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU4_BUTTON  = "Event Log";

const std::string IGSxGUI::MainView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::MainView::STRING_CLOSE_BRACKET = ")";

const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_CLICKED  = "subSystemClciked";
const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_NORMAL  = "subSystemText";

const std::string IGSxGUI::MainView::COLOR_LIGHT_BLUE  = "#0AA8FB";
const std::string IGSxGUI::MainView::STRING_CPD_ACTIVE = "CPD Active";
const std::string IGSxGUI::MainView::STRING_SCANNER_INCONTROL = "Scanner in control";

const int IGSxGUI::MainView::TIMER_INTERVAL = 1000;
const int IGSxGUI::MainView::ALERT_BLINKING_INTERVAL = 500;
const int IGSxGUI::MainView::POPUP_BLINKING_TIMER_INTERVAL = 500;
const int IGSxGUI::MainView::POPUP_TIMER_INTERVAL = 30000;
const int IGSxGUI::MainView::TIMER_RESTART_INTERVAL = 60000;
const int IGSxGUI::MainView::CONVERSION_BUFFER_SIZE = 80;

IGSxGUI::MainView::MainView() :
    NavigationButton(BTN_SYSTEM),
    sui(new SUI::MainView),
    m_iSystem(NULL),
    m_iDashboard(NULL),
    m_iAnalysis(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_popuptimer(SUI::Timer::createTimer()),
    m_alertBlinkingtimer(SUI::Timer::createTimer()),
    m_bInitializeEventLog(true),
    m_bIsAlertHoverOn(false)
{
    if (sui != NULL)
    {
        sui->setupSUI(MAINVIEW_LOAD_FILE.c_str());
    }

    sui->uctSystem->clicked = boost::bind(&MainView::onSystemButtonPressed, this);
    sui->uctDashboard->clicked = boost::bind(&MainView::onDashboardButtonPressed, this);
    sui->uctAnalysis->clicked = boost::bind(&MainView::onAnalysisButtonPressed, this);
    sui->uctTopBarAlarm->clicked = boost::bind(&MainView::onAlertsButtonPressed, this);

    sui->uctSystem->hoverEntered = boost::bind(&MainView::onSystemHoverOn, this);
    sui->uctSystem->hoverLeft = boost::bind(&MainView::onSystemHoverOff, this);
    sui->uctDashboard->hoverEntered = boost::bind(&MainView::onDashboardHoverOn, this);
    sui->uctDashboard->hoverLeft = boost::bind(&MainView::onDashboardHoverOff, this);
    sui->uctAnalysis->hoverEntered = boost::bind(&MainView::onAnalysisHoverOn, this);
    sui->uctAnalysis->hoverLeft = boost::bind(&MainView::onAnalysisHoverOff, this);

    sui->uctTopBarStatus->hoverEntered = boost::bind(&MainView::onTopBarStatusHoverOn, this);
    sui->uctTopBarStatus->hoverLeft = boost::bind(&MainView::onTopBarStatusHoverOff, this);

    sui->uctTopBarAlarm->hoverEntered = boost::bind(&MainView::onAlertHoverOn, this);
    sui->uctTopBarAlarm->hoverLeft = boost::bind(&MainView::onAlertHoverOff, this);

    sui->btnSysInit->clicked = boost::bind(&MainView::onSubMenuSystemInitializationPressed, this);
    sui->btnSysStateMgr->clicked = boost::bind(&MainView::onSubMenuSystemStateManagerPressed, this);
    sui->btnSysHWReset->clicked = boost::bind(&MainView::onSubMenuHardwareResetPressed, this);
    sui->btnSysMaintenance->clicked = boost::bind(&MainView::onSubMenuMaintenancePressed, this);
    sui->btnSysService->clicked = boost::bind(&MainView::onSubMenuServicePressed, this);

    sui->btnAnalysisDataView->clicked = boost::bind(&MainView::onSubMenuDataViewPressed, this);
    sui->btnAnalysisSafetyDiagnostics->clicked = boost::bind(&MainView::onSubMenuAlertsPressed, this);
    sui->btnAnalysisADT->clicked = boost::bind(&MainView::onSubMenuAdvancedDiagnosticsPressed, this);
    sui->btnAnalysisEventLog->clicked = boost::bind(&MainView::onSubMenuEventLogPressed, this);
    sui->btnClose->clicked = boost::bind(&MainView::onAlertPopupClosed, this);

    m_systemChanged = boost::bind(&IGSxGUI::MainView::onSystemStateChanged, this, _1);
    m_alertUpdated = boost::bind(&IGSxGUI::MainView::onAlertUpdated, this, _1, _2);
    m_timer->timeout = boost::bind(&MainView::onTimeout, this);
    m_popuptimer->timeout = boost::bind(&MainView::onPopupTimeout, this);
    m_alertBlinkingtimer->timeout = boost::bind(&MainView::onAlertBlinkTimeout, this);

    m_popuptimer->setSingleShot(true);

    m_presenter = new IGSxGUI::MainPresenter(this);
}
IGSxGUI::MainView::~MainView()
{
    m_timer->stop();
    m_popuptimer->stop();
    m_alertBlinkingtimer->stop();

    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }

    if (m_systemChanged != NULL)
    {
        m_iSystem->unsubscribeForSystemState(m_systemChanged);
        m_systemChanged = NULL;
    }
    if (m_alertUpdated != NULL)
    {
        m_iAnalysis->unsubscribeForAlertChange();
        m_alertUpdated = NULL;
    }
    // Do not delete the plugins, they are maintained by the Factory
}

void IGSxGUI::MainView::show()
{
    sui->dialog->show();
    m_timer->start(TIMER_INTERVAL);

    sui->uctSystem->setVisible(true);
    sui->uctDashboard->setVisible(true);
    sui->uctAnalysis->setVisible(true);

    sui->lblSystem->setText(NAVIGATION_BUTTON_SYSTEM);
    sui->lblDashboard->setText(NAVIGATION_BUTTON_DASHBOARD);
    sui->lblAnalysis->setText(NAVIGATION_BUTTON_ANALYSIS);

    IGSxGUI::Util::setAwesome(sui->lblAlertImageTopBar, IGSxGUI::AwesomeIcon::AI_fa_bell, SUI::ColorEnum::White);
    sui->lblAlertImageTopBar->setStyleSheetClass(STYLE_TOPBAR_LABEL_WHITE);
    sui->lblAlertTextTopBar->setText(STRING_ALERTS);
    sui->lblAlertTextTopBar->setStyleSheetClass(STYLE_TOPBAR_LABEL_WHITE);
    setAlertButtonNormalStyle();
    setTopBarStatusNormalStyle();

    sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_SYSTEM);
    sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_DASHBOARD);
    sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_ANALYSIS);

    sui->imv_TitleInfo_DateTime->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_CLOCK);

    sui->lbl_tit_MachineId->setText("MACHINE:  " + m_presenter->getMachineId());
    sui->lbl_tit_SWVersion->setText("VERSION:  " + m_presenter->getReleaseId());

    sui->lbl_tit_info_DateTime->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME_SEC));
    sui->gbxTitleInfo_DateTime->setToolTip(STRING_DATE_TIME);

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    m_iAnalysis->subscribeForAlertChange(m_alertUpdated);
    int nAlertCount = m_iAnalysis->getAlertCount();
    if (nAlertCount == 0)
    {
        sui->lblAlertTextTopBar->setText(STRING_ALERTS);
    } else {
        std::string strAlarmCount = STRING_ALERTS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET;
        sui->lblAlertTextTopBar->setText(strAlarmCount);
    }

    m_AnalysisActivePage = SCREEN_EVENTLOG;
    m_SystemActivePage = SCREEN_SYSTEM_INIT;
    m_DashboardActivePage = SCREEN_DASHBOARD;
    onSystemButtonPressed();

    IGS_INFO(STRING_MAINVIEW_SHOWN_LOG);

    sui->gbxAlert->hide();
    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
    }
}


void IGSxGUI::MainView::onTimeout()
{
    if (sui->lbl_tit_info_DateTime->getText() == SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME_SEC))
    {
        return;
    }
    sui->lbl_tit_info_DateTime->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME_SEC));
    m_timer->stop();
    m_timer->start(TIMER_RESTART_INTERVAL);  // Increased the timer after first update as we dont need to update the seconds in timer.
}

void IGSxGUI::MainView::onAlertPopupClosed()
{
    sui->gbxAlert->hide();
    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
    }
}

void IGSxGUI::MainView::onSystemButtonPressed()
{
    showAnalysisSubMenu(false);
    showSystemSubMenu(true);

    sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
    sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
    sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
    sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);

    NavigationButton = BTN_SYSTEM;

    onDashboardHoverOff();
    onAnalysisHoverOff();
    onSystemHoverOn();

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    switch (IGSxGUI::MainView::m_SystemActivePage)
    {
        case IGSxGUI::MainView::SCREEN_SYSTEM_INIT:
            onSubMenuSystemInitializationPressed();
            break;
        case IGSxGUI::MainView::SCREEN_MAINTENANCE:
            onSubMenuMaintenancePressed();
            break;
        default:
            break;
    }
    sui->cntChildScreens->setVisible(true);
}

void IGSxGUI::MainView::onDashboardButtonPressed()
{
    bool bIsFirstTimeDisplay = false;

    m_DashboardActivePage = SCREEN_DASHBOARD;

    showAnalysisSubMenu(false);
    showSystemSubMenu(false);

    NavigationButton = BTN_DASHBOARD;
    onSystemHoverOff();
    onAnalysisHoverOff();
    onDashboardHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    if (m_iDashboard == NULL)
    {
        m_iDashboard = PluginFactory::getInstance().getDashboardPlugin();
        bIsFirstTimeDisplay = true;
    }
    m_iDashboard->setActive(true);

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    m_iDashboard->show(sui->cntChildScreens, bIsFirstTimeDisplay);
    sui->cntChildScreens->setVisible(true);
}


void IGSxGUI::MainView::onAnalysisButtonPressed()
{
    showSystemSubMenu(false);
    showAnalysisSubMenu(true);

    sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
    sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
    sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);

    NavigationButton = BTN_ANALYSIS;

    onSystemHoverOff();
    onDashboardHoverOff();
    onAnalysisHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    m_iAnalysis->setActive(true);

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    switch (IGSxGUI::MainView::m_AnalysisActivePage)
    {
        case IGSxGUI::MainView::SCREEN_EVENTLOG:
            onSubMenuEventLogPressed();
            break;
        case IGSxGUI::MainView::SCREEN_ALERTS:
            onSubMenuAlertsPressed();
            break;
        case IGSxGUI::MainView::SCREEN_ADVANCED_DIAGNOSIS:
            onSubMenuAdvancedDiagnosticsPressed();
            break;
        default:
            break;
    }
    sui->cntChildScreens->setVisible(true);
}

void IGSxGUI::MainView::onAlertsButtonPressed()
{
    setAlertButtonNormalStyle();

    showSystemSubMenu(false);
    showAnalysisSubMenu(true);

    sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
    sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
    sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);

    NavigationButton = BTN_ANALYSIS;

    onSystemHoverOff();
    onDashboardHoverOff();
    onAnalysisHoverOn();

    setAnalysisSubMenuButtonStyle(BTN_ALERTS);

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    m_iAnalysis->setActive(true);

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    onSubMenuAlertsPressed();
    sui->cntChildScreens->setVisible(true);
}

void IGSxGUI::MainView::onSystemStateChanged(const SystemState::SystemStateEnum &state)
{
    if (m_who == IGSxCTRL::Who::GUI || m_who == IGSxCTRL::Who::NONE)
    {
        sui->lblTopBarStatusImage->setVisible(false);
        switch (state)
        {
            case SystemState::SS_INITIALIZED:
            {
                sui->uctTopBarStatus->setVisible(true);
                sui->bicTopBarStatus->setVisible(false);

                sui->imvTopBarStatus->setVisible(true);
                sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_GREEN_CHECKCIRCLE);
                sui->lblTopBarStatus->setText(STRING_INITIALIZED);
                break;
            }
            case SystemState::SS_TERMINATED:
            {
                sui->uctTopBarStatus->setVisible(true);
                sui->bicTopBarStatus->setVisible(false);

                sui->imvTopBarStatus->setVisible(false);
                sui->lblTopBarStatus->setText(STRING_TERMINATED);
                break;
            }
            case SystemState::SS_INITIALIZING:
            case SystemState::SS_TERMINATING:
            {
                sui->uctTopBarStatus->setVisible(false);
                sui->bicTopBarStatus->setVisible(true);
                break;
            }
            case SystemState::SS_PARTIALLY_INITIALIZED:
            {
                sui->uctTopBarStatus->setVisible(true);
                sui->bicTopBarStatus->setVisible(false);

                sui->imvTopBarStatus->setVisible(false);
                sui->lblTopBarStatus->setText(STRING_PARTIALLY_INITIALIZED);
                break;
            }
            case SystemState::SS_RECOVERY_REQUIRED:
            {
                sui->uctTopBarStatus->setVisible(true);
                sui->bicTopBarStatus->setVisible(false);

                sui->imvTopBarStatus->setVisible(true);
                sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_RED_WARNING_16PX);
                sui->lblTopBarStatus->setText(STRING_RECOVERY_REQUIRED);
                break;
            }
            default:
                // ToDo, log this case.
                break;
        }
    } else {
        sui->uctTopBarStatus->setVisible(true);
        sui->bicTopBarStatus->setVisible(false);
        sui->imvTopBarStatus->setVisible(false);  // This might be needed to display icon
        if (m_who == IGSxCTRL::Who::TESTMANAGER)
        {
            sui->lblTopBarStatusImage->setVisible(true);
            IGSxGUI::Util::setAwesome(sui->lblTopBarStatusImage, IGSxGUI::AwesomeIcon::AI_fa_cog, SUI::ColorEnum::Blue, true, COLOR_LIGHT_BLUE);
            sui->lblTopBarStatus->setText(STRING_CPD_ACTIVE);
        }
        if (m_who == IGSxCTRL::Who::SCANNER)
        {
            sui->lblTopBarStatusImage->setVisible(false);
            sui->lblTopBarStatus->setText(STRING_SCANNER_INCONTROL);
        }
    }
}

void IGSxGUI::MainView::onAlertUpdated(int nAlertCount, AlertInfo alertInfo)
{
    sui->lblAlertTextTopBar->setText("");  // This code reduces flickering a little
    if (nAlertCount == 0)
    {
        sui->lblAlertTextTopBar->setText(STRING_ALERTS);
        m_alertBlinkingtimer->stop();
        setAlertButtonNormalStyle();
    } else {
        std::string strAlarmCount = STRING_ALERTS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET;
        sui->lblAlertTextTopBar->setText(strAlarmCount);
    }

    if (alertInfo.bIsAlertAdded)
    {
        if (sui->gbxAlert->isVisible() && m_popuptimer->isActive())
        {
            sui->gbxAlert->hide();
            m_popuptimer->stop();

            if (m_iSystem != NULL)
            {
                m_iSystem->notifyAlertPopup(false);
            }
        }
        showPopup(alertInfo);
        m_popuptimer->start(POPUP_TIMER_INTERVAL);

        if (m_AnalysisActivePage != SCREEN_ALERTS)
        {
            m_alertBlinkingtimer->start(ALERT_BLINKING_INTERVAL);
        }
    }
}

void IGSxGUI::MainView::onPopupTimeout()
{
    sui->gbxAlert->hide();
    m_popuptimer->stop();

    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
    }
}

void IGSxGUI::MainView::onAlertBlinkTimeout()
{
    if (!m_bIsAlertHoverOn)
    {
        if (sui->gbxAlertTopBar->getStyleSheetClass() == STYLE_POPUP_RED)
        {
            setAlertButtonNormalStyle();
        } else {
            setAlertButtonBlinkingStyle();
        }
    }
}

void IGSxGUI::MainView::showPopup(const IGSxGUI::AlertInfo &alertInfo)
{
    switch (alertInfo.alertSeverity)
    {
        case IGSxERR::AlertSeverity::ALARM:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_exclamation, SUI::ColorEnum::White);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::White);
            sui->lblAlertSeverity->setText(STRING_ALARM);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_RED);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertCode->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_WHITE);
            break;
        }
        case IGSxERR::AlertSeverity::ERROR:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::White);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::White);
            sui->lblAlertSeverity->setText(STRING_ERROR);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_RED);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertCode->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_WHITE);
            break;
        }
        case IGSxERR::AlertSeverity::WARNING:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::Black);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::Black);
            sui->lblAlertSeverity->setText(STRING_WARNING);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_YELLOW);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertCode->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_BLACK);
            break;
        }
        case IGSxERR::AlertSeverity::EVENT:
        default:
        {
            break;
        }
    }
    sui->lblAlertCode->setText(alertInfo.alertCode);
    sui->lblAlertMessage->setText(alertInfo.alertMessage);
    sui->lblAlertDateTime->setText(alertInfo.alertDateTime);

    sui->gbxAlert->show();

    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(true);
    }
}

void IGSxGUI::MainView::setTopBarStatusNormalStyle()
{
    sui->lblTopBarStatus->setStyleSheetClass(STYLE_STATUSBAR_LABEL);
    sui->gbxTopBarStatus->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}
void IGSxGUI::MainView::setAlertButtonNormalStyle()
{
    sui->gbxAlertTopBar->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}

void IGSxGUI::MainView::setAlertButtonBlinkingStyle()
{
    sui->gbxAlertTopBar->setStyleSheetClass(STYLE_POPUP_RED);
}

void IGSxGUI::MainView::onSystemHoverOn()
{
    setMainNavigationButtonStyles(BTN_SYSTEM, IMAGE_BLUE_SYSTEM, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onDashboardHoverOn()
{
    setMainNavigationButtonStyles(BTN_DASHBOARD, IMAGE_BLUE_DASHBOARD, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onAnalysisHoverOn()
{
    setMainNavigationButtonStyles(BTN_ANALYSIS, IMAGE_BLUE_ANALYSIS, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onSystemHoverOff()
{
    if (NavigationButton != BTN_SYSTEM)
    {
        setMainNavigationButtonStyles(BTN_SYSTEM, IMAGE_WHITE_SYSTEM, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onDashboardHoverOff()
{
    if (NavigationButton != BTN_DASHBOARD)
    {
        setMainNavigationButtonStyles(BTN_DASHBOARD, IMAGE_WHITE_DASHBOARD, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onAnalysisHoverOff()
{
    if (NavigationButton != BTN_ANALYSIS)
    {
        setMainNavigationButtonStyles(BTN_ANALYSIS, IMAGE_WHITE_ANALYSIS, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onTopBarStatusHoverOn()
{
    sui->lblTopBarStatus->setStyleSheetClass(STYLE_TOPBAR_LABEL_WHITE);
    sui->gbxTopBarStatus->setStyleSheetClass(STYLE_TOPBAR_STATUS_HOVER);
    IGSxGUI::Util::setAwesome(sui->lblTopBarStatusImage, IGSxGUI::AwesomeIcon::AI_fa_cog, SUI::ColorEnum::White);
}

void IGSxGUI::MainView::onTopBarStatusHoverOff()
{
    setTopBarStatusNormalStyle();
    IGSxGUI::Util::setAwesome(sui->lblTopBarStatusImage, IGSxGUI::AwesomeIcon::AI_fa_cog, SUI::ColorEnum::Blue, true, COLOR_LIGHT_BLUE);
}

void IGSxGUI::MainView::onAlertHoverOn()
{
    m_bIsAlertHoverOn = true;
    sui->gbxAlertTopBar->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
}

void IGSxGUI::MainView::onAlertHoverOff()
{
    m_bIsAlertHoverOn = false;
    setAlertButtonNormalStyle();
}

void IGSxGUI::MainView::setMainNavigationButtonStyles(const BUTTON &button, const std::string &strImage, const std::string &strStyle) const
{
    switch (button)
    {
        case BTN_SYSTEM:
        {
            sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblSystem->setStyleSheetClass(strStyle);
            sui->gbxSystem->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_DASHBOARD:
        {
            sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblDashboard->setStyleSheetClass(strStyle);
            sui->gbxDashboard->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ANALYSIS:
        {
            sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblAnalysis->setStyleSheetClass(strStyle);
            sui->gbxAnalysis->setStyleSheetClass(strStyle);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setSystemSubMenuButtonStyle(const SYSTEM_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_SYSTEM_INITIALIZATION:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEM_STATEMANAGER:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_HARDWARE_RESET:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_MAINTENANCE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEM_SERVICE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setAnalysisSubMenuButtonStyle(const IGSxGUI::MainView::ANALYSIS_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_DATAVIEW:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_ALERTS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_ADVANCED_DIAGNOSTICS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_EVENTLOG:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        default:
           // ToDo, log this case.
           break;
    }
}

void IGSxGUI::MainView::onSubMenuSystemInitializationPressed()
{
    bool bIsFirstTimeDisplay = false;
    m_SystemActivePage = SCREEN_SYSTEM_INIT;

    setSystemSubMenuButtonStyle(BTN_SYSTEM_INITIALIZATION);

    if (m_iSystem == NULL)
    {
        m_iSystem = PluginFactory::getInstance().getSystemPlugin();

        if (m_systemChanged != NULL)
        {
            m_iSystem->subscribeForSystemState(m_systemChanged);
            onSystemStateChanged(m_iSystem->retrieveSystemState());
        }

        bIsFirstTimeDisplay = true;
    }

    m_iSystem->setActive(true);
    m_iSystem->show(sui->cntChildScreens, bIsFirstTimeDisplay);
}
void IGSxGUI::MainView::onSubMenuSystemStateManagerPressed()
{
    m_SystemActivePage = SCREEN_STATE_MANAGER;
    setSystemSubMenuButtonStyle(BTN_SYSTEM_STATEMANAGER);
}
void IGSxGUI::MainView::onSubMenuHardwareResetPressed()
{
    m_SystemActivePage = SCREEN_HARDWARE_RESET;
    setSystemSubMenuButtonStyle(BTN_HARDWARE_RESET);
}
void IGSxGUI::MainView::onSubMenuMaintenancePressed()
{
    m_SystemActivePage = SCREEN_MAINTENANCE;
    setSystemSubMenuButtonStyle(BTN_MAINTENANCE);
    m_iSystem->showCPD(sui->cntChildScreens, false);
}
void IGSxGUI::MainView::onSubMenuServicePressed()
{
    m_SystemActivePage = SCREEN_SYSTEM_SERVICE;
    setSystemSubMenuButtonStyle(BTN_SYSTEM_SERVICE);
}
void IGSxGUI::MainView::onSubMenuDataViewPressed()
{
    m_SystemActivePage = SCREEN_DATAVIEW;
    setAnalysisSubMenuButtonStyle(BTN_DATAVIEW);
}
void IGSxGUI::MainView::onSubMenuAlertsPressed()
{
    m_alertBlinkingtimer->stop();
    setAlertButtonNormalStyle();

    m_AnalysisActivePage = SCREEN_ALERTS;

    setAnalysisSubMenuButtonStyle(BTN_ALERTS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showAlert(sui->cntChildScreens, false);
    }
}
void IGSxGUI::MainView::onSubMenuAdvancedDiagnosticsPressed()
{
    m_AnalysisActivePage = SCREEN_ADVANCED_DIAGNOSIS;
    setAnalysisSubMenuButtonStyle(BTN_ADVANCED_DIAGNOSTICS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showADT(sui->cntChildScreens, false);
    }
}

void IGSxGUI::MainView::onSubMenuEventLogPressed()
{
    m_AnalysisActivePage = SCREEN_EVENTLOG;
    setAnalysisSubMenuButtonStyle(BTN_EVENTLOG);
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showEventViewer(sui->cntChildScreens, m_bInitializeEventLog);
    }
    m_bInitializeEventLog = false;
}

void IGSxGUI::MainView::showSystemSubMenu(bool bShow) const
{
    sui->btnSysInit->setVisible(bShow);
    sui->btnSysStateMgr->setVisible(false);  // Screen not implemented yet
    sui->btnSysHWReset->setVisible(false);   // Screen not implemented yet
    sui->btnSysMaintenance->setVisible(bShow);  // Screen not implemented yet
    sui->btnSysService->setVisible(false);  // Screen not implemented yet
}

void IGSxGUI::MainView::showAnalysisSubMenu(bool bShow) const
{
    sui->btnAnalysisDataView->setVisible(false);  // Screen not implemented yet
    sui->btnAnalysisSafetyDiagnostics->setVisible(bShow);  // Screen not implemented yet
    sui->btnAnalysisADT->setVisible(bShow);
    sui->btnAnalysisEventLog->setVisible(bShow);
}

void IGSxGUI::MainView::controlChanged(const IGSxCTRL::Who::WhoEnum who)
{
    m_who = who;
    onSystemStateChanged(m_iSystem->retrieveSystemState());
}
