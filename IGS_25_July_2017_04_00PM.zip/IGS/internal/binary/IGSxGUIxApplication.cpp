/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxApplication.cpp
| Author       : Raja A
| Description  : Implementation for Application class
|
| ! \file        IGSxGUIxApplication.cpp
| ! \brief       Implementation for Application class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#include <boost/thread.hpp>
#include <string>
#include <SUIResourcePath.h>
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxApplication.hpp"
#include "SUIExternalEvent.h"
#include "SUIExternalEventHandler.h"

const int IGSxGUIxApplication::TIMER_INTERVAL = 1000;
const int IGSxGUIxApplication::SPLASHSCREEN_TIMEOUT = 3;

IGSxGUIxApplication::IGSxGUIxApplication(int argc, char *argv[], const std::string &resourcePath):
    m_splashView(NULL),
    m_mainView(NULL),
    m_resourcePath(resourcePath),
    m_splashtimer(SUI::Timer::createTimer()),
    m_argc(argc),
    m_argv(argv),
    m_count(0),
    m_controlManager(new IGSxGUI::ControlManager())
{
    m_splashtimer->timeout = boost::bind(&IGSxGUIxApplication::onSplashTimeout, this);
    m_app = SUI::Application::createApplication(m_argc, m_argv);
    SUI::ResourcePath::getInstance()->setResourcePath(m_resourcePath);
}

IGSxGUIxApplication::~IGSxGUIxApplication()
{
    if (m_controlManager != NULL)
    {
        delete m_controlManager;
        m_controlManager = NULL;
    }
    if (m_splashView != NULL)
    {
        delete m_splashView;
        m_splashView = NULL;
    }

    if (m_mainView != NULL)
    {
        delete m_mainView;
        m_mainView = NULL;
    }
}

int IGSxGUIxApplication::exec()
{
    int result = 1;

    m_splashView = new IGSxGUI::SplashView();
    m_splashView->show();
    m_splashtimer->start(TIMER_INTERVAL);

    boost::thread(&IGSxGUIxApplication::initializePlugins, this);

    result = m_app->exec();
    return result;
}

void IGSxGUIxApplication::initializePlugins()
{
    IGSxGUI::PluginFactory::getInstance().initialize();
    m_controlManager->initialize();
    m_controlManager->registerToControlChanged(boost::bind(&IGSxGUIxApplication::onControlChanged, this, _1));

    if (m_count < SPLASHSCREEN_TIMEOUT)
    {
        boost::this_thread::sleep_for(boost::chrono::seconds(SPLASHSCREEN_TIMEOUT - m_count));
    }
    boost::function<void()> signal = boost::bind(&IGSxGUIxApplication::onInitializePluginsCompleted, this);
    SUI::ExternalEvent<void> *event = new SUI::ExternalEvent<void>(signal);
    SUI::ExternalEventHandler::raiseEvent(event);
}

void IGSxGUIxApplication::onInitializePluginsCompleted()
{
    m_mainView = new IGSxGUI::MainView();
    m_mainView->show();

    m_splashView->hide();
}

void IGSxGUIxApplication::onSplashTimeout()
{
    ++m_count;
}

void IGSxGUIxApplication::onControlChanged(const IGSxCTRL::Who::WhoEnum &who)
{
    m_mainView->controlChanged(who);
    IGSxGUI::PluginFactory::getInstance().getSystemPlugin()->controlChanged(who);
}
