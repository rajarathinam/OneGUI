/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashView.hpp
| Author       : Raja A
| Description  : Header file for Splashscreen view
|
| ! \file        IGSxGUIxSplashView.hpp
| ! \brief       Header file for Splashscreen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXGUIXSPLASHVIEW_HPP
#define IGSXGUIXSPLASHVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashPresenter.hpp"
#include "IGSxGUIxSplashView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SplashView;
class Timer;
}  // namespace SUI

namespace IGSxGUI {
class SplashView: public IGSxGUI::ISplashView
{
 public:
    SplashView();
    virtual ~SplashView();
    virtual void show();
    virtual void hide();
 private:
    void onTimeout();

    static const int FADEOUT_TIME;
    static const std::string SPLASHVIEW_LOAD_FILE;
    static const std::string STRING_SPLASHVIEW_SHOWN_LOG;
    SUI::SplashView *sui;
    IGSxGUI::SplashPresenter *m_presenter;
    boost::shared_ptr<SUI::Timer> m_timer;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSPLASHVIEW_HPP
