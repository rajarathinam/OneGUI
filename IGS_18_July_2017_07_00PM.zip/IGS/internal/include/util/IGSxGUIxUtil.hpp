/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Utility class
|
| ! \file        IGSxGUIxUtil.hpp
| ! \brief       Header file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXUTIL_HPP
#define IGSXGUIXUTIL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <boost/shared_ptr.hpp>
#include <string>
#include <algorithm>
#include <SUIColorEnum.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Widget;
class Dialog;
class TableWidget;
}

/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class AwesomeIcon
{
 public:
    typedef enum
    {  // http://fontawesome.io/icons/
        AI_fa_times,                    // 0xf00d
        AI_fa_exclamation_triangle,     // 0xf071
        AI_fa_exclamation,              // 0xf12a
        AI_fa_times_circle,             // 0xf057
        AI_fa_bell,                     // 0xf0f3
        AI_fa_sort_desc,                // 0xf0dd
        AI_fa_sort_asc,                 // 0xf0de
        AI_fa_sort_default,             // 0xf0dc
        AI_fa_copyright                 // 0xf1f9
    } AwesomeIconEnum;
};

class SortOrder
{
 public:
    typedef enum
    {
        Ascending,
        Descending
    } SortOrderEnum;
};

class Util
{
 public:
    static void setGeometry(SUI::Widget *widget, int x, int y, int width, int height);
    static void setWindowFrame(SUI::Dialog *dialog, bool enable);
    static void disableScrollbars(SUI::Dialog *dialog);
    static void setFadeOut(SUI::Dialog *dialog, int duration);
    static void processEvents();
    static void setTranslucentBackground(SUI::Dialog *dialog);

    /**
     * @brief setParent sets the parent of the widget to the parent from the
     * @param widget The widget to set the parent on
     * @param parent This is the widget where the parent will be taken from
     */
    static void setParent(SUI::Widget *widget, SUI::Widget* parent);
    static const std::string elideText(const std::string& instr, int fontsize, int width);

    static void sort(int col, SUI::TableWidget* widget, SortOrder::SortOrderEnum order);
    static void setScalable(SUI::TableWidget *widget);
    static void setAwesome(SUI::Widget* widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, SUI::ColorEnum::Color color);
    static void setColor(SUI::Widget* widget, SUI::ColorEnum::Color color, SUI::TableWidget *tableWidget);
    static void addLabel(SUI::TableWidget *tableWidget, int row, int column);
 private:
    Util();
};

}  // namespace IGSxGUI

#endif  // IGSXGUIXUTIL_HPP
