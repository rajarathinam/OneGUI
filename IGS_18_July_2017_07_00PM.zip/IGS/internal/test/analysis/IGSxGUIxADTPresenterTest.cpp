/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of ADT Presenter test
|
| ! \file        IGSxGUIxADTPresenterTest.cpp
| ! \brief       Implementation of ADT Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxADTPresenterTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTPresenterTest, Test1)
{
    ADTViewStub* stubView  = new ADTViewStub();
    ASSERT_TRUE(stubView != NULL);

    ASSERT_TRUE(m_adtManager != NULL);
    IGSxGUI::ADTPresenter* adtpresenter = new IGSxGUI::ADTPresenter(stubView, m_adtManager);
    ASSERT_TRUE(adtpresenter != NULL);

    std::vector<IGSxGUI::ADT*> listADTs = adtpresenter->getADTs();
    EXPECT_EQ(6, listADTs.size());

    IGSxGUI::ADT* adt = new IGSxGUI::ADT(IGSxADT::MetaDescription("NewADTName", "NewADTSubSystem", "NewADTDesc", "NewADTFile"));
    ASSERT_TRUE(adt != NULL);

    m_adtManager->add(adt);

    listADTs = adtpresenter->getADTs();
    EXPECT_EQ(7, listADTs.size());

    IGSxGUI::ADT* unknownADT = adtpresenter->getADT("UNKNOWN");
    ASSERT_TRUE(unknownADT  == NULL);

    IGSxGUI::ADT* adt1 = adtpresenter->getADT("Collector Cooling");
    ASSERT_TRUE(adt1  != NULL);
    EXPECT_EQ(adt1->getName(), "Collector Cooling");

    ASSERT_TRUE(adtpresenter != NULL);
    delete adtpresenter;
    adtpresenter = NULL;

    ASSERT_TRUE(stubView != NULL);
    delete stubView;
    stubView = NULL;
}

TEST_F(ADTPresenterTest, Test2)
{
    ASSERT_TRUE(m_adtManager != NULL);

    ADTViewStub* stubView  = new ADTViewStub();
    ASSERT_TRUE(stubView != NULL);

    IGSxGUI::ADTPresenter* ADTpresenter = new IGSxGUI::ADTPresenter(stubView, m_adtManager);

    std::vector<IGSxGUI::ADT*> adts = ADTpresenter->getADTs();
    EXPECT_EQ(adts.size(), 6);

    EXPECT_FALSE(ADTpresenter->startADT(""));
    EXPECT_FALSE(ADTpresenter->startADT("OneGUI"));

    ASSERT_TRUE(ADTpresenter->startADT("GVA"));

    if (ADTpresenter != NULL)
    {
        delete ADTpresenter;
        ADTpresenter = NULL;
    }
    if (stubView != NULL)
    {
        delete stubView;
        stubView = NULL;
    }
}
