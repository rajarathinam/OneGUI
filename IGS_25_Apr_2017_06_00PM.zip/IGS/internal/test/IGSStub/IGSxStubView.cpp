/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxStubView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Stub view
|
| ! \file        IGSxStubView.cpp
| ! \brief       Implementation of Stub view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxStubView.hpp"
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <string>
#include <list>
#include "IGSxStubMocView.hpp"
#include "IGSxITS.hpp"
#include <SUILabel.h>
#include <SUIButton.h>
#include <SUIDialog.h>
#include <SUIDropDown.h>
#include <SUICheckBox.h>
#include <SUITextArea.h>
#include <SUITableWidget.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

std::string IGSxGUI::StubView::STUBVIEW_LOAD_FILE = IGS::Resource::path("IGSxStubView.xml");

IGSxGUI::StubView::StubView() :
    sui(new SUI::StubView)
{
    if( sui != NULL)
    {
        sui->setupSUI(STUBVIEW_LOAD_FILE.c_str());
    }

    sui->btnInit->clicked = boost::bind(&StubView::onInitializeButtonPressed, this);
    sui->btnTerminate->clicked = boost::bind(&StubView::onTerminateButtonPressed, this);
    sui->ddb9->valueChanged = boost::bind(&StubView::onSystemFunctionSelected, this);
    sui->btn9->clicked = boost::bind(&StubView::onSetButtonPressed, this);
    sui->btnSet->clicked = boost::bind(&StubView::onKPIValueSetButtonPressed, this);

    sui->btnSetAllInitialized->clicked = boost::bind(&StubView::onSetAllInitializedPressed, this);
    sui->btnSetAllInitializing->clicked = boost::bind(&StubView::onSetAllInitializingPressed, this);
    sui->btnSetAllTerminated->clicked = boost::bind(&StubView::onSetAllTerminatedPressed, this);
    sui->btnSetAllTerminating->clicked = boost::bind(&StubView::onSetAllTerminatingPressed, this);
    sui->btnSetAllRecRequired->clicked = boost::bind(&StubView::onSetAllRecRequiredPressed, this);

    sui->cbxException->checkStateChanged = boost::bind(&StubView::onCheckBoxStateChanged, this, _1);
    sui->ddbKPI->valueChanged = boost::bind(&StubView::onddbKPIValueChanged, this);
    sui->cbxGenerateKpiData->checkStateChanged = boost::bind(&StubView::onCheckBoxcbxGenerateKpiDataChanged, this, _1);

    m_presenter = new StubPresenter(this);

    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    sui->ddb9->clearItems();
    sui->ddb9->addItems(systemFunctionList);

    std::list<std::string> stateList;
    for (int enumInt = IGSxITS::DriverState::DS_TERMINATING; enumInt <= IGSxITS::DriverState::DS_RECOVERY_REQUIRED; enumInt++)
    {
        IGSxITS::DriverState::DriverStateEnum enumState = static_cast<IGSxITS::DriverState::DriverStateEnum>(enumInt);
        stateList.push_back(IGSxITS::DriverState::toString(enumState));
    }
    sui->ddbState->clearItems();
    sui->ddbState->addItems(stateList);

    sui->txaValue->clearText();
    sui->txaValue->setFocus();
    std::list<std::string> kpiList = m_presenter->getKPIs();
    sui->ddbKPI->clearItems();
    sui->ddbKPI->addItems(kpiList);

    std::list<std::string> selectedItems = sui->ddbKPI->getSelectedItems();
    std::list<std::string> valueSetList = m_presenter->getValueSet(selectedItems.front());
    sui->ddbKPIValueSet->clearItems();
    sui->ddbKPIValueSet->addItems(valueSetList);

    int i = 0;
    for (std::list<string>::iterator it=kpiList.begin(); it != kpiList.end(); ++it)
    {
        ++i;
        std::list<std::string> listRowData;
        listRowData.push_back(*it);
        listRowData.push_back(boost::lexical_cast<std::string>(i));

        sui->tawKPI->insertRows(i,1);
        sui->tawKPI->addData(i,listRowData);
    }

    if (m_presenter != NULL)
    {
        m_presenter->fetchKPIInfo();
    }
}

IGSxGUI::StubView::~StubView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
}

void IGSxGUI::StubView::show()
{
    sui->dialog->show();
}

void IGSxGUI::StubView::showStatus(const std::string &strStatus)
{
    sui->lblStatus->clearText();
    sui->lblStatus->setText(strStatus);
}

void IGSxGUI::StubView::onInitializeButtonPressed()
{
    m_presenter->Initialize();
}

void IGSxGUI::StubView::onddbKPIValueChanged()
{
    std::list<std::string> selectedItems = sui->ddbKPI->getSelectedItems();
    std::list<std::string> valueSetList = m_presenter->getValueSet(selectedItems.front());
    sui->ddbKPIValueSet->clearItems();
    sui->ddbKPIValueSet->addItems(valueSetList);
}

void IGSxGUI::StubView::onTerminateButtonPressed()
{
    m_presenter->Terminate();
}

void IGSxGUI::StubView::onSetButtonPressed()
{
    std::list<std::string> selectedItems = sui->ddb8->getSelectedItems();
    std::list<std::string> selectedState = sui->ddbState->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        m_presenter->setDriverStatus(selectedItems.front(), selectedState.front());
    }
}

void IGSxGUI::StubView::onKPIValueSetButtonPressed()
{
    std::list<std::string> selectedKPIs = sui->ddbKPI->getSelectedItems();
    std::list<std::string> selectedValueSet = sui->ddbKPIValueSet->getSelectedItems();
    string strValue = sui->txaValue->getText();

    if ((selectedKPIs.size() == 1) && (selectedValueSet.size()) && (strValue != ""))
    {
        vector<double> values;
        values.push_back(boost::lexical_cast<double>(strValue));

        m_presenter->setKPIValue(selectedKPIs.front(),selectedValueSet.front(),values);
    }    
}

void IGSxGUI::StubView::onSystemFunctionSelected()
{
    std::list<std::string> selectedItems = sui->ddb9->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::list<std::string> drivers = m_presenter->getDrivers(selectedItems.front());
        sui->ddb8->clearItems();
        sui->ddb8->addItems(drivers);
    }
}

void IGSxGUI::StubView::onSetAllInitializedPressed()
{
    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    for (std::list<std::string>::iterator itSysFun=systemFunctionList.begin(); itSysFun != systemFunctionList.end(); ++itSysFun)
    {
        std::string sysFunName = *itSysFun;
        std::list<std::string> drivers = m_presenter->getDrivers(sysFunName);

        for (std::list<std::string>::iterator itDriver=drivers.begin(); itDriver != drivers.end(); ++itDriver)
        {
            std::string driverName = *itDriver;
            string state = IGSxITS::DriverState::toString(IGSxITS::DriverState::DS_INITIALIZED);
            m_presenter->setDriverStatus(driverName, state);
        }
    }
}
void IGSxGUI::StubView::onSetAllInitializingPressed()
{
    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    for (std::list<std::string>::iterator itSysFun=systemFunctionList.begin(); itSysFun != systemFunctionList.end(); ++itSysFun)
    {
        std::string sysFunName = *itSysFun;
        std::list<std::string> drivers = m_presenter->getDrivers(sysFunName);

        for (std::list<std::string>::iterator itDriver=drivers.begin(); itDriver != drivers.end(); ++itDriver)
        {
            std::string driverName = *itDriver;
            string state = IGSxITS::DriverState::toString(IGSxITS::DriverState::DS_INITIALIZING);
            m_presenter->setDriverStatus(driverName, state);
        }
    }
}
void IGSxGUI::StubView::onSetAllTerminatedPressed()
{
    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    for (std::list<std::string>::iterator itSysFun=systemFunctionList.begin(); itSysFun != systemFunctionList.end(); ++itSysFun)
    {
        std::string sysFunName = *itSysFun;
        std::list<std::string> drivers = m_presenter->getDrivers(sysFunName);

        for (std::list<std::string>::iterator itDriver=drivers.begin(); itDriver != drivers.end(); ++itDriver)
        {
            std::string driverName = *itDriver;
            string state = IGSxITS::DriverState::toString(IGSxITS::DriverState::DS_TERMINATED);
            m_presenter->setDriverStatus(driverName, state);
        }
    }
}
void IGSxGUI::StubView::onSetAllTerminatingPressed()
{
    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    for (std::list<std::string>::iterator itSysFun=systemFunctionList.begin(); itSysFun != systemFunctionList.end(); ++itSysFun)
    {
        std::string sysFunName = *itSysFun;
        std::list<std::string> drivers = m_presenter->getDrivers(sysFunName);

        for (std::list<std::string>::iterator itDriver=drivers.begin(); itDriver != drivers.end(); ++itDriver)
        {
            std::string driverName = *itDriver;
            string state = IGSxITS::DriverState::toString(IGSxITS::DriverState::DS_TERMINATING);
            m_presenter->setDriverStatus(driverName, state);
        }
    }
}
void IGSxGUI::StubView::onSetAllRecRequiredPressed()
{
    std::list<std::string> systemFunctionList = m_presenter->getSystemFunctions();
    for (std::list<std::string>::iterator itSysFun=systemFunctionList.begin(); itSysFun != systemFunctionList.end(); ++itSysFun)
    {
        std::string sysFunName = *itSysFun;
        std::list<std::string> drivers = m_presenter->getDrivers(sysFunName);

        for (std::list<std::string>::iterator itDriver=drivers.begin(); itDriver != drivers.end(); ++itDriver)
        {
            std::string driverName = *itDriver;
            string state = IGSxITS::DriverState::toString(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
            m_presenter->setDriverStatus(driverName, state);
        }
    }
}

void IGSxGUI::StubView::onCheckBoxStateChanged(bool checked)
{
    m_presenter->enableThrowExceptions(checked);
}

void IGSxGUI::StubView::onCheckBoxcbxGenerateKpiDataChanged(bool checked)
{
    m_presenter->enableKPIGeneration(checked);
}

void IGSxGUI::StubView::updateKPI(const std::string& kpiName, const std::string& /*upTime*/, const vector<double> &values)
{
    for (int i = 1; i < sui->tawKPI->rowCount(); i++)
    {
        if (sui->tawKPI->getItemText(i,0) == kpiName)
        {
            string value("---");
            if (values.size() > 0)
            {
                value = boost::lexical_cast<string>(values[0]);
            }

            sui->tawKPI->setItemText(i,1,value);
            break;
        }
    }
}
