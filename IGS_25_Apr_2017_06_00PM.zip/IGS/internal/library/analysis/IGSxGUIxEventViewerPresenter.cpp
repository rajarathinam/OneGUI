/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerPresenter.cpp
| Author       : Venugopal S
| Description  : Implementation of Event Viewer Presenter
|
| ! \file        IGSxGUIxEventViewerPresenter.cpp
| ! \brief       Implementation of Event Viewer Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxEventViewerPresenter.hpp"
#include "IGSxERR.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::EventViewerPresenter::EventViewerPresenter(IGSxGUI::IEventViewerView* view):
    m_view(view)
{
}

IGSxGUI::EventViewerPresenter::~EventViewerPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::string IGSxGUI::EventViewerPresenter::getEventLog()
{
    return IGSxERR::EventLogger::getInstance()->getEventLog();
}

std::string IGSxGUI::EventViewerPresenter::getPreviousEventLog()
{
    return IGSxERR::EventLogger::getInstance()->getPreviousEventLog();
}
