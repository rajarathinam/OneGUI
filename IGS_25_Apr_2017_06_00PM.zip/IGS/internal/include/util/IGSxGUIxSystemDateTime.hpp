/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxSystemDateTime.hpp
| Author       : Raja A
| Description  : Header file for System Date and Time
|
| ! \file        IGSxGUIxSystemDateTime.hpp
| ! \brief       Header file for System Date and Time
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMDATETIME_HPP
#define IGSXGUIXSYSTEMDATETIME_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

const std::string STRING_TIME_FORMAT = "%H:%M";
const std::string STRING_DATE_FORMAT = "%Y-%m-%d";
const std::string STRING_DATETIME_FORMAT = "%Y-%m-%d  %H:%M";
const int CONVERSION_BUFFER_SIZE = 80;
class SystemDateTime
{
 public:
    typedef enum
    {
        STR_DATE,
        STR_TIME,
        STR_DATE_TIME
    }eSystemDateTime;

    static const std::string getSystemCurrentDateTime(const SystemDateTime::eSystemDateTime& strname);
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMDATETIME_HPP
