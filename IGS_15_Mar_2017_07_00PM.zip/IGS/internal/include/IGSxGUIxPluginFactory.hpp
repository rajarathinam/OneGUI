/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPluginFactory.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Plugin factory
|
| ! \file        IGSxGUIxPluginFactory.hpp
| ! \brief       Header file for Plugin factory
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXPLUGINFACTORY_HPP
#define IGSXGUIXPLUGINFACTORY_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxISystem.hpp"
#include "IGSxGUIxIAnalysis.hpp"
#include "IGSxGUIxIDashboard.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class PluginFactory
{
 public:
    static PluginFactory& getInstance()
    {
        static PluginFactory instance;
        return instance;
    }
    ISystem* getSystemPlugin();
    IAnalysis* getAnalysisPlugin();
    IDashboard* getDashboardPlugin();

 private:
    PluginFactory();
    PluginFactory(PluginFactory const&);
    ~PluginFactory();
    void operator=(PluginFactory const&);

    ISystem* m_systemPlugin;
    IAnalysis* m_analysisPlugin;
    IDashboard* m_dashboardPlugin;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXPLUGINFACTORY_HPP
