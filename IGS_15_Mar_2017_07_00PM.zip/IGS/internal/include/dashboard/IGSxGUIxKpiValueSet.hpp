/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.hpp
| ! \brief       Header file for KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXKPIVALUESET_HPP
#define IGSXGUIXKPIVALUESET_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/circular_buffer.hpp>
#include <string>
#include <vector>
#include "IGSxKPI.hpp"

using std::string;
using std::vector;
using IGSxKPI::KPIValueSetDefinition;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
struct structKPITimeValue
{
    time_t kpiTime;
    double kpiValue;

    structKPITimeValue(): kpiTime(0), kpiValue(0.0)
    {
    }
};
typedef structKPITimeValue KPITimeValue;

class KPIValueSet
{
 public:
    explicit KPIValueSet(const KPIValueSetDefinition &kpiDefinition);
    virtual ~KPIValueSet();

    string getName() const;
    string getDescription() const;
    string getUnit() const;

    string getDisplayUnit() const;
    double getFactor() const;
    double getMin() const;
    double getMax() const;
    bool isActive();
    void setActive(bool isActive);

    void setDisplayUnit(const std::string& unit);
    void setFactor(double factor);
    void setMin(double min);
    void setMax(double max);

    void addValue(const time_t& time, const double &value);
    boost::circular_buffer<KPITimeValue> getValue() const;
    KPITimeValue getLastValue() const;

 private:
    KPIValueSet(KPIValueSet const &);
    KPIValueSet& operator=(KPIValueSet const &);

    string m_name;  // KPI Value name
    string m_desc;  // KPI Value description
    string m_unit;  // KPI Value unit

    std::string m_displayUnit;  // Display name
    double m_factor;       // Factor
    double m_min;          // Min
    double m_max;          // Max
    bool m_isActive;       // Is implemented

    boost::circular_buffer<KPITimeValue> m_cbKPITimeValue;
    static const int TOTAL_LIMITING_MINUTES;
    static const int DEGREE_CELSIUS_PER_KELVIN;
    static const string KELVIN;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXKPIVALUESET_HPP
