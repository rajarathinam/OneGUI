/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManagerTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver Manager test
|
| ! \file        IGSxGUIxDriverManagerTest.cpp
| ! \brief       Implementation of Driver Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDriverManagerTest.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        SystemDriverManagerTestParam,
                        ::testing::Values("SF Environmental Mgt"));

TEST_P(SystemDriverManagerTestParam, Test1)
{
    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();

    if (drvMgr != NULL)
    {
        drvMgr->addSystemFunctions(Sysfunctions);
    }
    IGSxGUI::SystemFunction* sys = drvMgr->getSystemFunction("SF-04");

    if (sys != NULL)
    {
        std::string name = sys->getName();
        EXPECT_STRCASEEQ(name.c_str(), "SF-04");
    }
    if (drvMgr != NULL)
    {
        delete drvMgr;
        drvMgr = NULL;
    }
}

TEST_P(SystemDriverManagerTestParam, Test2)
{
    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();

    if (drvMgr != NULL)
    {
        drvMgr->addSystemFunctions(Sysfunctions);
    }
    IGSxGUI::SystemFunction* sys = drvMgr->getSystemFunction("SF-04");

    if (sys != NULL)
    {
        std::string desc = sys->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "SF Environmental Mgt");
    }

    if (drvMgr != NULL)
    {
        delete drvMgr;
        drvMgr = NULL;
    }
}
