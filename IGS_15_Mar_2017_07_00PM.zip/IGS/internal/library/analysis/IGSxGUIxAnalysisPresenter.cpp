/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Analysis Presenter
|
| ! \file        IGSxGUIxAnalysisPresenter.cpp
| ! \brief       Implementation of Analysis Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxAnalysisPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::AnalysisPresenter::AnalysisPresenter(IAnalysisView* view):
    m_view(view)
{
}

IGSxGUI::AnalysisPresenter::~AnalysisPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::ADT *> IGSxGUI::AnalysisPresenter::getADTs() const
{
    std::vector<IGSxGUI::ADT *> adts;

    if (m_pADTManager != NULL)
    {
        adts = m_pADTManager->retrieveAll();
    }
    return adts;
}


bool IGSxGUI::AnalysisPresenter::startADT(const std::string &adtName) const
{
    IGSxGUI::ADT* adt = m_pADTManager->getADT(adtName);

    if (adt != NULL)
    {
        return adt->start();
    }
    return false;
}




