/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerView.cpp
| Author       : Surya Tiwari
| Description  : Implementation of Event Viewer view
|
| ! \file        IGSxGUIxEventViewerView.cpp
| ! \brief       Implementation of Event Viewer view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <fstream>
#include "IGSxGUIxEventViewerView.hpp"
#include "IGSxGUIxMoc_EventViewerView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxERR.hpp"
#include "IGSxCOMMON.hpp"
#include <SUIButton.h>
#include <SUILabel.h>
#include <SUITextArea.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
namespace IGSxGUI
{
    std::string lastupdateddate;
}

const std::string IGSxGUI::EventViewerView::LOAD_FILE_EVENT_VIEWER = IGS::Resource::path("IGSxGUIxEventViewer.xml");
const std::string IGSxGUI::EventViewerView::STRING_LAST_UPDATED = "Last Updated: ";
const std::string IGSxGUI::EventViewerView::STRING_NO_FILE = "No File";
const int IGSxGUI::EventViewerView::READ_NUM_LINES = 1000;

IGSxGUI::EventViewerView::EventViewerView() :
    sui(new SUI::EventViewerView)
{
    m_cirbufEventLogs.set_capacity(0);
}
IGSxGUI::EventViewerView::~EventViewerView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::EventViewerView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(LOAD_FILE_EVENT_VIEWER.c_str(), MainScreenContainer);
        sui->textAreaEventViewerLog->setAutoScroll(true);
    }

    sui->buttonUpdateLog->clicked = boost::bind(&EventViewerView::onUpdateLogButtonPressed, this);

    if (bIsFirstTimeDisplay)
    {
        onUpdateLogButtonPressed();
    } else {
        std::string fulltext;
        sui->lblLastUpdatedDate->setText(m_lastupdateddate);

        boost::circular_buffer<std::string>::iterator it;
        boost::circular_buffer<std::string>::iterator end_it = m_cirbufEventLogs.end();
        for (it = m_cirbufEventLogs.begin(); it != end_it; ++it)
        {
            fulltext += (*it);
        }
        sui->textAreaEventViewerLog->clearText();
        sui->textAreaEventViewerLog->setText(fulltext);
    }
}

void IGSxGUI::EventViewerView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::EventViewerView::onUpdateLogButtonPressed()
{
    m_cirbufEventLogs.clear();
    UpdateLastUpdatedDateTime();

    std::string gline;
    std::string fulltext;
    std::fstream curreventlog;
    bool fileReadactive = false;

    sui->textAreaEventViewerLog->clearText();
    m_cirbufEventLogs.set_capacity(READ_NUM_LINES);

    std::string prevfilename = IGSxERR::EventLogger::getInstance()->getPreviousEventLog();
    std::fstream preveventlog;
    preveventlog.open(prevfilename.c_str(), std::fstream::in);
    if (preveventlog.is_open())
    {
        while (std::getline(preveventlog, gline))
        {
            m_cirbufEventLogs.push_back(gline + "<br />");
        }
        fileReadactive = true;
        preveventlog.close();
    }


    std::string currentfilename = IGSxERR::EventLogger::getInstance()->getEventLog();
    curreventlog.open(currentfilename.c_str(), std::fstream::in);
    if (curreventlog.is_open())
    {
        while ( std::getline(curreventlog, gline))
        {
            m_cirbufEventLogs.push_back(gline + "<br />");
        }
        fileReadactive = true;
        curreventlog.close();
    }


    if (fileReadactive)
    {
        boost::circular_buffer<std::string>::iterator it;
        boost::circular_buffer<std::string>::iterator end_it = m_cirbufEventLogs.end();
        for (it = m_cirbufEventLogs.begin(); it != end_it; ++it)
        {
            fulltext += (*it);
        }
        sui->textAreaEventViewerLog->setText(fulltext);
    } else {
        sui->textAreaEventViewerLog->setText(STRING_NO_FILE);
    }
}

void IGSxGUI::EventViewerView::UpdateLastUpdatedDateTime()
{
    SystemDateTime currDate;
    m_lastupdateddate = STRING_LAST_UPDATED + currDate.SystemCurrentDateTime(SystemDateTime::STR_DATE) + " " + currDate.SystemCurrentDateTime(SystemDateTime::STR_TIME);
    sui->lblLastUpdatedDate->setText(m_lastupdateddate);
}
