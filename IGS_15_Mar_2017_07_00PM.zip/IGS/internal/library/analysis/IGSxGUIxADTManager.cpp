/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManager.cpp
| Author       : Venugopal S
| Description  : ADT manager Implementation
|
| ! \file        IGSxGUIxADTManager.cpp
| ! \brief       ADT Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTManager.hpp"
#include <boost/bind.hpp>
#include <string>
#include <vector>
#include <algorithm>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::ADTManager::ADTManager()
{
}
IGSxGUI::ADTManager::~ADTManager()
{
    std::vector<ADT*>::iterator end_it = m_ADTs.end();
    for (std::vector<ADT*>::iterator it = m_ADTs.begin() ; it != end_it; ++it)
    {
        delete (*it);
    }
    m_ADTs.clear();
}
void IGSxGUI::ADTManager::initialize()
{
    IGSxADT::MetaDescriptions metaDescriptions;

    try
    {
        IGSxADT::ADT::getInstance()->getAdts(metaDescriptions);
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }
    size_t t_metaDescriptions_size = metaDescriptions.size();
    for (size_t i = 0; i < t_metaDescriptions_size; i++)
    {
        ADT* adt = new ADT(metaDescriptions[i]);

        if (adt != NULL)
        {
            add(adt);
        }
    }
}
void IGSxGUI::ADTManager::add(ADT* adt)
{
    if (adt != NULL)
    {
        m_ADTs.push_back(adt);
    }
}
void IGSxGUI::ADTManager::remove(ADT* adt)
{
    m_ADTs.erase(std::remove(m_ADTs.begin(), m_ADTs.end(), adt), m_ADTs.end());

    if (adt != NULL)
    {
        delete adt;
        adt = NULL;
    }
}
IGSxGUI::ADT *IGSxGUI::ADTManager::getADT(const std::string &name) const
{
    ADT* adt = NULL;
    size_t t_ADTs_size = m_ADTs.size();
    for (size_t i = 0; i < t_ADTs_size; i++)
    {
        if (m_ADTs[i]->getName() == name)
        {
            adt = m_ADTs[i];
            break;
        }
    }
    return adt;
}
std::vector<IGSxGUI::ADT*> IGSxGUI::ADTManager::retrieveAll()
{
    return m_ADTs;
}















