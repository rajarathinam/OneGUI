/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemFunction.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Function
|
| ! \file        IGSxGUIxSystemFunction.cpp
| ! \brief       Implementation of System Function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemFunction.hpp"
#include <boost/bind.hpp>
#include <string>
#include <vector>
#include <algorithm>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::SystemFunction::SystemFunction(const IGSxITS::MetaDescription &metaDescription):
    m_driverCount(0),
    m_metaDescription(metaDescription),
    m_SysFunState(SystemState::SS_TERMINATED)
{
    m_drivers.clear();
}

IGSxGUI::SystemFunction::~SystemFunction()
{
    for (std::vector<Driver*>::iterator it = m_drivers.begin() ; it != m_drivers.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_drivers.clear();
}

std::string IGSxGUI::SystemFunction::getName() const
{
    return m_metaDescription.name();
}

std::string IGSxGUI::SystemFunction::getDescription() const
{
    return m_metaDescription.description();
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::SystemFunction::getState() const
{
    return m_SysFunState;
}

void IGSxGUI::SystemFunction::addDriver(const MetaDescription& metaDescription, const DriverState::DriverStateEnum &driverState)
{
    Driver* driver = new Driver(metaDescription, driverState);

    if (driver != NULL)
    {
        if (driver->isImplemented())
        {
            m_driverCount++;
        }
        driver->registerToDriverStateChanged(boost::bind(&IGSxGUI::SystemFunction::onDriverStateChanged, this, _1, _2));
        m_drivers.push_back(driver);

        sort(m_drivers.begin(), m_drivers.end(), compareDriver());

        determineState();
    }
}

IGSxGUI::Driver* IGSxGUI::SystemFunction::getDriver(const std::string &name) const
{
    for (size_t i = 0; i < m_drivers.size(); i++)
    {
        if (m_drivers[i]->getName() == name)
        {
            return m_drivers[i];
        }
    }
    return NULL;
}

bool IGSxGUI::SystemFunction::isManagingDriver(const std::string &name) const
{
    for (size_t i = 0; i < m_drivers.size(); i++)
    {
        if (m_drivers[i]->getName() == name)
        {
            return true;
        }
    }
    return false;
}

std::vector<IGSxGUI::Driver *> IGSxGUI::SystemFunction::getDrivers() const
{
    return m_drivers;
}

int IGSxGUI::SystemFunction::getDriverCount() const
{
    return m_driverCount;
}

void IGSxGUI::SystemFunction::updateDriverState(const std::string &driverName, const DriverState::DriverStateEnum &driverState)
{
    Driver* driver = this->getDriver(driverName);

    if (driver != NULL)
    {
        driver->updateDriverState(driverState);
    }
}

void IGSxGUI::SystemFunction::onDriverStateChanged(const DriverState::DriverStateEnum & /*state*/, const std::string & /*strDriver*/)
{
    determineState();
}

void IGSxGUI::SystemFunction::determineState()
{
    int nInitializedDriverCount = 0;
    int nTerminatedDriverCount = 0;
    SystemState::SystemStateEnum worstState = SystemState::SS_TERMINATED;
    SystemState::SystemStateEnum newState = SystemState::SS_TERMINATED;

    if (m_drivers.size() == 1)
    {
        if (m_drivers[0]->isImplemented())
        {
            DriverState::DriverStateEnum driverState = m_drivers[0]->getState();
            if (driverState == DriverState::DS_INITIALIZED)
            {
                ++nInitializedDriverCount;
            }
            if (driverState == DriverState::DS_TERMINATED)
            {
                ++nTerminatedDriverCount;
            }
            if (driverState == DriverState::DS_INITIALIZED) newState = SystemState::SS_INITIALIZED;
            if (driverState == DriverState::DS_TERMINATED) newState = SystemState::SS_TERMINATED;
            if (driverState == DriverState::DS_INITIALIZING) newState = SystemState::SS_INITIALIZING;
            if (driverState == DriverState::DS_TERMINATING) newState = SystemState::SS_TERMINATING;
            if (driverState == DriverState::DS_RECOVERY_REQUIRED) newState = SystemState::SS_RECOVERY_REQUIRED;
        }
        if (!m_stateSysFunChanged.empty())
        {
            m_stateSysFunChanged(newState, this->getName(), nInitializedDriverCount, nTerminatedDriverCount);
            m_stateMainDetermine();
        }
    } else {
        bool allInitialized = true;
        bool allTerminated = true;
        bool oneInitializing = false;
        bool oneTerminating = false;
        bool oneInitialized = false;
        bool oneTerminated = false;

        for (size_t i = 0; i < m_drivers.size(); i++)
        {
            if (m_drivers[i]->isImplemented())
            {
                DriverState::DriverStateEnum driverState = m_drivers[i]->getState();

                if (driverState != DriverState::DS_INITIALIZED) allInitialized = false;
                if (driverState != DriverState::DS_TERMINATED) allTerminated = false;
                if (driverState == DriverState::DS_INITIALIZING) oneInitializing = true;
                if (driverState == DriverState::DS_TERMINATING) oneTerminating = true;
                if (driverState == DriverState::DS_RECOVERY_REQUIRED) worstState = SystemState::SS_RECOVERY_REQUIRED;
                if (driverState == DriverState::DS_INITIALIZED)
                {
                    oneInitialized = true;
                    ++nInitializedDriverCount;
                }
                if (driverState == DriverState::DS_TERMINATED)
                {
                    oneTerminated = true;
                    ++nTerminatedDriverCount;
                }
            }
        }
        if (oneInitializing)
        {
            newState = SystemState::SS_INITIALIZING;
        } else if (oneTerminating) {
            newState = SystemState::SS_TERMINATING;
        } else if (worstState == SystemState::SS_RECOVERY_REQUIRED){
            newState = worstState;
        } else if (allTerminated) {
            newState = SystemState::SS_TERMINATED;
        } else if (allInitialized) {
            newState = SystemState::SS_INITIALIZED;
        } else if ((!allInitialized) && (!allTerminated) && oneInitialized && oneTerminated) {
            newState = SystemState::SS_PARTIALLY_INITIALIZED;
        } else if ((worstState != SystemState::SS_INITIALIZED) && oneTerminated) {
            newState = SystemState::SS_TERMINATED;
        } else if ((worstState != SystemState::SS_INITIALIZED) && oneInitialized) {
            newState = worstState;
        }
        if (!m_stateSysFunChanged.empty())
        {
            m_stateSysFunChanged(newState, this->getName(), nInitializedDriverCount, nTerminatedDriverCount);
            m_stateMainDetermine();
        }
    }
    m_SysFunState = newState;
}

void IGSxGUI::SystemFunction::registerToSysFunStateChanged(const stateSysFunChanged& cb)
{
    m_stateSysFunChanged = cb;
}
void IGSxGUI::SystemFunction::registerToDetermineMainState(const stateMainDetermine& cb)
{
    m_stateMainDetermine = cb;
}
