/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardTest.cpp
| Author       : Raja A
| Description  : Implementation of Dashboard  test
|
| ! \file        IGSxGUIxDashboardTest.cpp
| ! \brief       Implementation of Dashboard  test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxDashboardTest.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(DashboardTest, InitializeTest)
{
  IGSxGUI::Dashboard *ptr_Dashboard = new IGSxGUI::Dashboard;
  IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
  EXPECT_EQ(0, kpiMgr->getKPIs().size());
  ptr_Dashboard->initialize();
  EXPECT_EQ(9, kpiMgr->getKPIs().size()) << kpiMgr->getKPIs().size() <<std::endl;

}
