/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIManagerTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI Manager test
|
| ! \file        IGSxGUIxKPIManagerTest.cpp
| ! \brief       Implementation of KPI Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxKPIManagerTest.hpp"
#define private public
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPIManagerTestParam,
                        ::testing::Values("Test"));

TEST_F(KPIManagerTestParam, GetKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    size_t noofKPIs = kpiMgr->getKPIs().size();
    EXPECT_EQ(9, noofKPIs);
}

TEST_F(KPIManagerTestParam, GetSystemKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    size_t noofKPIs = kpiMgr->getSystemKPIs().size();
    EXPECT_EQ(2, noofKPIs);
}

TEST_F(KPIManagerTestParam, GetConsumablesTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    size_t noofKPIs = kpiMgr->getConsumables().size();
    EXPECT_EQ(1, noofKPIs);
}


TEST_F(KPIManagerTestParam, GetKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getKPI("AMP_PA0in_MpPpPower_On");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    EXPECT_STRCASEEQ("AMP_PA0in_MpPpPower_On", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

}

TEST_F(KPIManagerTestParam, GetSystemKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getSystemKPI("Closed_Loop_EUV_Power_at_IF");
    ASSERT_TRUE(kpiFromKPIManager != NULL);

    EXPECT_STRCASEEQ("Closed_Loop_EUV_Power_at_IF", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

}

TEST_F(KPIManagerTestParam, GetConsumableTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize();

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getConsumable("EUV_Pulse_Energy_Internal");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    EXPECT_STRCASEEQ("EUV_Pulse_Energy_Internal", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);


    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

}


/*

TEST_F(KPIManagerTestParam, AddKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();

    vector<IGSxGUI::KPI*> kpisFromKPIManager = kpiMgr->getKPIs();
    EXPECT_EQ(0, kpisFromKPIManager.size());

    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition1("customkpidefinitionName1", "customkpidefinitionDescription", kpivaluedeinitionlist);
    KPIDefinition kpidefinition2("customkpidefinitionName2", "customkpidefinitionDescription", kpivaluedeinitionlist);


    kpisFromKPIManager.clear();

    kpiMgr->addKPI(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getKPIs();
    EXPECT_EQ(1, kpisFromKPIManager.size());

    kpiMgr->addKPI(kpidefinition2, "TestValueSet2", "TestDisplayName2", 2.0, "TestType2", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getKPIs();
    EXPECT_EQ(2, kpisFromKPIManager.size());

    kpiMgr->addKPI(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);
    kpisFromKPIManager = kpiMgr->getKPIs();
    EXPECT_EQ(2, kpisFromKPIManager.size()); // same KPIDefinition not inserted



    IGSxGUI::KPIValueSet* valueSet = kpisFromKPIManager[0]->getValueSet("TestValueSet1");

    if (valueSet != NULL)
    {
        EXPECT_TRUE(valueSet->isActive() == true );
        EXPECT_STRCASEEQ("TestDisplayName1", valueSet->getDisplayUnit().c_str());
        EXPECT_DOUBLE_EQ(2.0, valueSet->getFactor());
        EXPECT_DOUBLE_EQ(10.0, valueSet->getMin());
        EXPECT_DOUBLE_EQ(200.0, valueSet->getMax());
        EXPECT_DOUBLE_EQ(1, valueSet->getPosition());
    }

    IGSxGUI::KPIValueSet* valueSet1 = kpisFromKPIManager[0]->getValueSet("INVALIDValueSet");
    EXPECT_TRUE(valueSet1 == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTestParam, AddSystemKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();

    vector<IGSxGUI::KPI*> kpisFromKPIManager = kpiMgr->getSystemKPIs();
    EXPECT_EQ(0, kpisFromKPIManager.size());

    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition1("customkpidefinitionName1", "customkpidefinitionDescription", kpivaluedeinitionlist);
    KPIDefinition kpidefinition2("customkpidefinitionName2", "customkpidefinitionDescription", kpivaluedeinitionlist);


    kpisFromKPIManager.clear();

    kpiMgr->addSystemKPI(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getSystemKPIs();
    EXPECT_EQ(1, kpisFromKPIManager.size());

    kpiMgr->addSystemKPI(kpidefinition2, "TestValueSet2", "TestDisplayName2", 2.0, "TestType2", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getSystemKPIs();
    EXPECT_EQ(2, kpisFromKPIManager.size());

    kpiMgr->addSystemKPI(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);
    kpisFromKPIManager = kpiMgr->getSystemKPIs();
    EXPECT_EQ(2, kpisFromKPIManager.size()); // same KPIDefinition not inserted



    IGSxGUI::KPIValueSet* valueSet = kpisFromKPIManager[0]->getValueSet("TestValueSet1");

    if (valueSet != NULL)
    {
        EXPECT_TRUE(valueSet->isActive() == true );
        EXPECT_STRCASEEQ("TestDisplayName1", valueSet->getDisplayUnit().c_str());
        EXPECT_DOUBLE_EQ(2.0, valueSet->getFactor());
        EXPECT_DOUBLE_EQ(10.0, valueSet->getMin());
        EXPECT_DOUBLE_EQ(200.0, valueSet->getMax());
        EXPECT_DOUBLE_EQ(1, valueSet->getPosition());
    }

    IGSxGUI::KPIValueSet* valueSet1 = kpisFromKPIManager[0]->getValueSet("INVALIDValueSet");
    EXPECT_TRUE(valueSet1 == NULL);

    delete kpiMgr;
}


TEST_F(KPIManagerTestParam, AddConsumableTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();

    vector<IGSxGUI::KPI*> kpisFromKPIManager = kpiMgr->getConsumables();
    EXPECT_EQ(0, kpisFromKPIManager.size());

    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition1("customkpidefinitionName1", "customkpidefinitionDescription", kpivaluedeinitionlist);
    KPIDefinition kpidefinition2("customkpidefinitionName2", "customkpidefinitionDescription", kpivaluedeinitionlist);


    kpisFromKPIManager.clear();

    kpiMgr->addConsumable(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getConsumables();
    EXPECT_EQ(1, kpisFromKPIManager.size());

    kpiMgr->addConsumable(kpidefinition2, "TestValueSet2", "TestDisplayName2", 2.0, "TestType2", 10.0, 200.0, 1);

    kpisFromKPIManager = kpiMgr->getConsumables();
    EXPECT_EQ(2, kpisFromKPIManager.size());

    kpiMgr->addConsumable(kpidefinition1, "TestValueSet1", "TestDisplayName1", 2.0, "TestType1", 10.0, 200.0, 1);
    kpisFromKPIManager = kpiMgr->getConsumables();
    EXPECT_EQ(2, kpisFromKPIManager.size()); // same KPIDefinition not inserted



    IGSxGUI::KPIValueSet* valueSet = kpisFromKPIManager[0]->getValueSet("TestValueSet1");

    if (valueSet != NULL)
    {
        EXPECT_TRUE(valueSet->isActive() == true );
        EXPECT_STRCASEEQ("TestDisplayName1", valueSet->getDisplayUnit().c_str());
        EXPECT_DOUBLE_EQ(2.0, valueSet->getFactor());
        EXPECT_DOUBLE_EQ(10.0, valueSet->getMin());
        EXPECT_DOUBLE_EQ(200.0, valueSet->getMax());
        EXPECT_DOUBLE_EQ(1, valueSet->getPosition());
    }

    IGSxGUI::KPIValueSet* valueSet1 = kpisFromKPIManager[0]->getValueSet("INVALIDValueSet");
    EXPECT_TRUE(valueSet1 == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTestParam, FindKPIDefinition)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    KPIValueSetDefinition kpvaluedefinition("customvaluesetdefinitionName", "customvaluesetdefinitionDescription", "customvaluesetdefinitionUnit");
    IGSxKPI::KPIValueSetDefinitionList kpivaluedeinitionlist;
    kpivaluedeinitionlist.push_back(kpvaluedefinition);
    KPIDefinition kpidefinition1("customkpidefinitionName1", "customkpidefinitionDescription", kpivaluedeinitionlist);
    KPIDefinition kpidefinition2("customkpidefinitionName2", "customkpidefinitionDescriptions", kpivaluedeinitionlist);
    KPIDefinition kpidefinition3("customkpidefinitionName3", "customkpidefinitionDescription", kpivaluedeinitionlist);
    KPIDefinitionList kpidefinitionlist;
    kpidefinitionlist.push_back(kpidefinition1);
    kpidefinitionlist.push_back(kpidefinition2);
    kpidefinitionlist.push_back(kpidefinition3);

    IGSxKPI::KPIDefinition actualKPIDefinition1 = kpiMgr->findKPIDefinition(kpidefinitionlist, "customkpidefinitionName2");
    EXPECT_STRCASEEQ("customkpidefinitionName2", actualKPIDefinition1.name().c_str());

    IGSxKPI::KPIDefinition actualKPIDefinition2 = kpiMgr->findKPIDefinition(kpidefinitionlist, "customkpidefinitionName1");
    EXPECT_STRCASEEQ("customkpidefinitionName1", actualKPIDefinition2.name().c_str());

    delete kpiMgr;
}

*/
