/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenterTest.hpp
| Author       : Raja A
| Description  : Header file for Dashboard Presenter test
|
| ! \file        IGSxGUIxDashboardPresenterTest.hpp
| ! \brief       Header file for Dashboard Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDPRESENTERTEST_HPP
#define IGSXGUIXDASHBOARDPRESENTERTEST_HPP
#include <gtest.h>
#include <string>
#include "IGSxGUIxDashboardPresenter.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class DashboardPresenterTest : public ::testing::Test
{
 public:
    DashboardPresenterTest() {}
    virtual ~DashboardPresenterTest() {}

 protected:
    virtual void SetUp()
    {
    }
    virtual void TearDown()
    {
        // Code here will be called immediately after each test
        // (right before the destructor).
    }
};

class StubDashboardView : public IGSxGUI::IDashboardView
{
 public:
    StubDashboardView() {}
    virtual ~StubDashboardView() {}

    virtual void show(SUI::Container*, bool) {}
    virtual void setActive(bool) {}

    virtual void updateKPI(const string& kpiName)
    {
        setKPIName(kpiName);
    }

    virtual void updateSystemKPI(const string& systemKPIName)
    {
        setSystemKPIName(systemKPIName);
    }

    virtual void updateConsumable(const string& consumableName)
    {
        setConsumableName(consumableName);
    }


    std::string systemKPIName() const
    {
        return m_systemKPIName;
    }

    void setSystemKPIName(const std::string &systemKPIName)
    {
        m_systemKPIName = systemKPIName;
    }
    std::string KPIName() const
    {
        return m_KPIName;
    }

    void setKPIName(const std::string &KPIName)
    {
        m_KPIName = KPIName;
    }
    std::string consumableName() const
    {
        return m_consumableName;
    }

    void setConsumableName(const std::string &consumableName)
    {
        m_consumableName = consumableName;
    }

 private:
    std::string m_KPIName;
    std::string m_systemKPIName;
    std::string m_consumableName;
};

#endif  //  IGSXGUIXDASHBOARDPRESENTERTEST_HPP
