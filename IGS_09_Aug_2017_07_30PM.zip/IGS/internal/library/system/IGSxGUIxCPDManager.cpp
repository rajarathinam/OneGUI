/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.cpp
| Author       : Venugopal S
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxCPDManager.cpp
| ! \brief       CPD Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <utility>
#include "IGSxGUIxCPDManager.hpp"
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::CPDManager::CPDManager()
{
}

IGSxGUI::CPDManager::~CPDManager()
{
    try
    {
        IGSxCPD::CPD::getInstance()->unsubscribeToTestStopped();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (std::vector<CPD*>::iterator it = m_CPDs.begin() ; it != m_CPDs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_CPDs.clear();
}

void IGSxGUI::CPDManager::initialize()
{
    IGSxCPD::MetaDescriptions metaDescriptions;
    try
    {
        IGSxCPD::CPD::getInstance()->getTests(metaDescriptions);
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        CPD* cpd = new CPD(metaDescriptions[i]);
        if (cpd != NULL)
        {
            add(cpd);
        }
    }

    try
    {
        IGSxCPD::CPD::getInstance()->subscribeToTestStopped(boost::bind(&CPDManager::onStopped, this, _1));
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }
}

bool IGSxGUI::CPDManager::add(CPD* cpd)
{
    if (cpd != NULL)
    {
        for (size_t i = 0; i < m_CPDs.size(); i++)
        {
            if (m_CPDs[i]->getName() == cpd->getName())
            {
                // CPD with the name already exists, So need not add
                return false;
            }
        }
        m_CPDs.push_back(cpd);
        return true;
    }
    return false;
}

bool IGSxGUI::CPDManager::remove(CPD* cpd)
{
    if (cpd != NULL)
    {
        for (size_t i = 0; i < m_CPDs.size(); i++)
        {
            if (m_CPDs[i]->getName() == cpd->getName())
            {
                m_CPDs.erase(std::remove(m_CPDs.begin(), m_CPDs.end(), cpd), m_CPDs.end());

                delete cpd;
                cpd = NULL;

                return true;
            }
        }
    }
    return false;
}

IGSxGUI::CPD *IGSxGUI::CPDManager::getCPD(const std::string &name) const
{
    CPD* cpd = NULL;

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (m_CPDs[i]->getName() == name)
        {
            cpd = m_CPDs[i];
            break;
        }
    }
    return cpd;
}

std::vector<IGSxGUI::CPD*> IGSxGUI::CPDManager::retrieveAll() const
{
    return m_CPDs;
}

void IGSxGUI::CPDManager::retrieveCPDTestResults(const std::string& cpdname, time_t starttime, time_t stoptime, IGSxCPD::TestResultList& testResults) const
{
    IGSxCPD::CPD::getInstance()->getTestResults(cpdname, starttime, stoptime, testResults);
}

void IGSxGUI::CPDManager::onStopped(const IGS::Result &result) const
{
    retrieveRunningCPD()->onStopped(result);
}

IGSxGUI::CPD *IGSxGUI::CPDManager::retrieveRunningCPD() const
{
    std::string currentTest;
    try
    {
        currentTest = IGSxCPD::CPD::getInstance()->getCurrentTest();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (currentTest == m_CPDs[i]->getName())
        {
            return m_CPDs[i];
        }
    }
    return NULL;
}















