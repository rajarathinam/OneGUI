/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIPresenterTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for KPI Presenter test
|
| ! \file        IGSxGUIxKPIPresenterTest.hpp
| ! \brief       Header file for KPI Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXKPIPRESENTERTEST_HPP
#define IGSXGUIXKPIPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxKPI.hpp"

using std::vector;
using std::list;
using std::string;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSet;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class KPIPresenterTest : public ::testing::Test
{
 public:
  KPIPresenterTest(){}
  virtual ~KPIPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class KPIPresenterTestParam : public ::testing::TestWithParam<string>
{
 public:
    KPIPresenterTestParam(){}
    virtual ~KPIPresenterTestParam(){}
 protected:
    KPIDefinitionList KPIs;
    KPIDefinition KPI_1;
    KPIDefinition KPI_2;
 protected:
  virtual void SetUp()
  {
    KPIValueSetDefinitionList kpivalsetdeflist_1;
    KPIValueSetDefinition valsetdef_1;
    valsetdef_1.setName("MEAN");
    valsetdef_1.setDescription("MEAN");
    valsetdef_1.setUnit("mJ");
    kpivalsetdeflist_1.push_back(valsetdef_1);

    KPIValueSetDefinitionList kpivalsetdeflist_2;
    KPIValueSetDefinition valsetdef_2;
    valsetdef_2.setName("MAX");
    valsetdef_2.setDescription("MAX");
    valsetdef_2.setUnit("µm");
    kpivalsetdeflist_2.push_back(valsetdef_2);

    KPI_1.setName("EUV_Pulse_Energy_Internal");
    KPI_1.setDescription("EUV_Pulse_Energy_Internal");
    KPI_1.setValues(kpivalsetdeflist_1);

    KPI_2.setName("DG_Droplet_Jump_Y");
    KPI_2.setDescription("DG_Droplet_Jump_Y");
    KPI_2.setValues(kpivalsetdeflist_2);

    KPIs.push_back(KPI_1);
    KPIs.push_back(KPI_2);
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXKPIPRESENTERTEST_HPP
