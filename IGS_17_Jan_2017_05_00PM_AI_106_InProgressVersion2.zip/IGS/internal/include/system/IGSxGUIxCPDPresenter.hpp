/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for CPD presenter
|
| ! \file        IGSxGUIxCPDPresenter.hpp
| ! \brief       Header file for CPD presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDPRESENTER_HPP
#define IGSXGUIXCPDPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class CPDPresenter
{
 public:
    explicit CPDPresenter(ICPDView* view, CPDManager* pCPDManager);
    virtual ~CPDPresenter();

    std::vector<CPD*> getCPDs() const;
    bool startCPD(const std::string& cpdName) const;

    void subscribeForEvents();
    void unsubscribeForEvents();

 private:
    CPDPresenter(const CPDPresenter& cpdPresenter);
    CPDPresenter& operator=(const CPDPresenter& cpdPresenter);

    void onCPDStopped(const std::string& strCPD, const IGS::Result& result) const;

    CPDManager* m_pCPDManager;
    ICPDView *m_view;
    std::vector<boost::signals2::connection> m_connections;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDPRESENTER_HPP
