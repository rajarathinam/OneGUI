/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIValueSetTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI ValueSet test
|
| ! \file        IGSxGUIxKPIValueSetTest.cpp
| ! \brief       Implementation of KPI ValueSet test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxKPIValueSetTest.hpp"
#include "IGSxGUIxKpiValueSet.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPIValueSetTestParam,
                        ::testing::Values("MEAN"));

TEST_P(KPIValueSetTestParam, Test1)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);

    if (valset != NULL)
    {
        std::string name = valset->getName();
        EXPECT_STRCASEEQ(name.c_str(), "MEAN");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test2)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);

    if (valset != NULL)
    {
        std::string desc = valset->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "MEAN");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test3)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);
    if (valset != NULL)
    {
        std::string unit = valset->getUnit();
        EXPECT_STRCASEEQ(unit.c_str(), "mJ");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test4)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string name = valset->getName();
        EXPECT_STRCASEEQ(name.c_str(), "MAX");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test5)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string desc = valset->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "MAX");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test6)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string unit = valset->getUnit();
        EXPECT_STRCASEEQ(unit.c_str(), "µm");

        delete valset;
        valset = NULL;
    }
}
TEST_P(KPIValueSetTestParam, Test7)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        valset->setDisplayUnit("");
        EXPECT_STRCASEEQ("", valset->getDisplayUnit().c_str());

        valset->setDisplayUnit(" ");
        EXPECT_STRCASEEQ(" ", valset->getDisplayUnit().c_str());

        valset->setDisplayUnit("kW");
        EXPECT_STRCASEEQ("kW", valset->getDisplayUnit().c_str());

        valset->setDisplayUnit("12345");
        EXPECT_STRCASEEQ("12345", valset->getDisplayUnit().c_str());


        valset->setFactor(DBL_MIN);
        ASSERT_DOUBLE_EQ(DBL_MIN, valset->getFactor());

        valset->setFactor(6.0);
        ASSERT_DOUBLE_EQ(6.0, valset->getFactor());

        valset->setFactor(DBL_MAX);
        ASSERT_DOUBLE_EQ(DBL_MAX, valset->getFactor());

        valset->setMin(DBL_MIN);
        ASSERT_DOUBLE_EQ(DBL_MIN, valset->getMin());

        valset->setMin(99.0);
        ASSERT_DOUBLE_EQ(99.0, valset->getMin());

        valset->setMin(DBL_MAX);
        ASSERT_DOUBLE_EQ(DBL_MAX, valset->getMin());


        valset->setMax(DBL_MIN);
        ASSERT_DOUBLE_EQ(DBL_MIN, valset->getMax());

        valset->setMax(99.0);
        ASSERT_DOUBLE_EQ(99.0, valset->getMax());

        valset->setMax(DBL_MAX);
        ASSERT_DOUBLE_EQ(DBL_MAX, valset->getMax());

        valset->setIndexPosition(INT_MIN);
        EXPECT_EQ(INT_MIN, valset->getIndexPosition());

        valset->setIndexPosition(10);
        EXPECT_EQ(10, valset->getIndexPosition());

        valset->setIndexPosition(INT_MAX);
        EXPECT_EQ(INT_MAX, valset->getIndexPosition());

        valset->setPosition(INT_MIN);
        EXPECT_EQ(INT_MIN, valset->getPosition());

        valset->setPosition(10);
        EXPECT_EQ(10, valset->getPosition());

        valset->setPosition(INT_MAX);
        EXPECT_EQ(INT_MAX, valset->getPosition());


        delete valset;
        valset = NULL;
    }
}


TEST_P(KPIValueSetTestParam, Test8)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        valset->setActive(false);
        EXPECT_TRUE((valset->isActive() ==  false));

        valset->setActive(true);
        EXPECT_TRUE((valset->isActive() ==  true));

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test9)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_3);
    if (valset != NULL)
    {
        time_t test_time = time(0);
        valset->setFactor(2);
        valset->addValue(test_time, 100.0, true);

        IGSxGUI::KPITimeValue newtimeValue =   valset->getLastValue();

        EXPECT_EQ(test_time, newtimeValue.kpiTime);
        EXPECT_NEAR(-73.15, newtimeValue.kpiValue, 0.001);
        EXPECT_TRUE(newtimeValue.isUpdated == true);

        time_t test_time1 = time(0);
        valset->setFactor(3);
        valset->addValue(test_time1, 100.0, true);

        IGSxGUI::KPITimeValue newtimeValue1 =   valset->getLastValue();

        EXPECT_EQ(test_time1, newtimeValue1.kpiTime);
        EXPECT_NEAR(-73.15, newtimeValue1.kpiValue, 0.001);
        EXPECT_TRUE(newtimeValue1.isUpdated == true);

        time_t test_time2 = time(0) + 10;
        valset->setFactor(3);
        valset->addValue(test_time2, 100.0, true);

        IGSxGUI::KPITimeValue newtimeValue2 =   valset->getLastValue();

        EXPECT_EQ(test_time2, newtimeValue2.kpiTime);
        EXPECT_NEAR(26.85, newtimeValue2.kpiValue, 0.001);
        EXPECT_TRUE(newtimeValue2.isUpdated == true);

        delete valset;
        valset = NULL;
    }
}


TEST_P(KPIValueSetTestParam, Test10)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        boost::circular_buffer<IGSxGUI::KPITimeValue> expected_buffer;
        EXPECT_EQ(0, expected_buffer.size());
        EXPECT_EQ(380, valset->getValue().size());

        expected_buffer = valset->getValue();
        EXPECT_EQ(380, expected_buffer.size());



        time_t test_time = time(0);
        valset->setFactor(2);
        valset->addValue(test_time, 100.0, true);

        IGSxGUI::KPITimeValue newtimeValue =   valset->getLastValue();

        EXPECT_EQ(test_time, newtimeValue.kpiTime);
        EXPECT_DOUBLE_EQ(200.0, newtimeValue.kpiValue);
        EXPECT_TRUE(newtimeValue.isUpdated == true);

        time_t test_time1 = time(0) + 10;
        valset->setFactor(0.5);
        valset->addValue(test_time1, 100.0, false);

        IGSxGUI::KPITimeValue newtimeValue1 =   valset->getLastValue();

        EXPECT_EQ(test_time1, newtimeValue1.kpiTime);
        EXPECT_DOUBLE_EQ(50.0, newtimeValue1.kpiValue);
        EXPECT_TRUE(newtimeValue1.isUpdated == false);


        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test11)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);

    if (valset != NULL)
    {
        std::string name = valset->getName();
        EXPECT_STRCASEEQ(name.c_str(), "MEAN");

        std::string desc = valset->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "MEAN");

        std::string unit = valset->getUnit();
        EXPECT_STRCASEEQ(unit.c_str(), "mJ");

        EXPECT_STRCASEEQ("", valset->getDisplayUnit().c_str());

        ASSERT_DOUBLE_EQ(0, valset->getFactor());
        ASSERT_DOUBLE_EQ(0, valset->getMin());
        ASSERT_DOUBLE_EQ(0, valset->getMax());
        EXPECT_TRUE((valset->isActive() ==  false));
        EXPECT_EQ(0, valset->getPosition());

        delete valset;
        valset = NULL;
    }
}

