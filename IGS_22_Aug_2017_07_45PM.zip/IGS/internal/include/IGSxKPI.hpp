/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPI.hpp
| Author       : Thijs Jacobs
| Description  : Proxy interface for FHKxREAD, retrieval of Key Performance 
|                Indicators
|
| ! \file        IGSxKPI.hpp
| ! \brief       Proxy interface for FHKxREAD, retrieval of Key Performance 
|                Indicators
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2017, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXKPI_HPP
#define IGSXKPI_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <ctime>
#include <boost/function.hpp>

#include "IGSxCOMMON.hpp"


namespace IGSxKPI {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// KPI name
typedef std::vector<std::string> KPINameList;


// KPI value
typedef std::vector<double> KPIValueSet;


// KPI data
class KPIData
{
public:
    explicit KPIData(const std::string& _name, time_t _time, const KPIValueSet& _values):m_name( _name), m_time(_time), m_values(_values){}
    explicit KPIData() {}
    virtual ~KPIData() {}

    std::string name() const {return m_name;}
    time_t time() const {return m_time;}
    KPIValueSet* values() {return &m_values;}
    void setName(const std::string& _name) {m_name = _name;}
    void setTime(time_t _time) {m_time = _time;}
    void setValues(const KPIValueSet& _values) {m_values = _values;}

private:
    std::string m_name; // KPI name
    time_t m_time; // the time that the KPI was generated
    KPIValueSet m_values; // the actual KPI set of values
};

typedef std::vector<KPIData> KPIDataList;


// KPI value definition
class KPIValueSetDefinition
{
public:
    explicit KPIValueSetDefinition(const std::string& _name, const std::string& _desc, const std::string& _unit):m_name( _name), m_desc (_desc), m_unit(_unit){}
    explicit KPIValueSetDefinition() {}
    virtual ~KPIValueSetDefinition() {}

    std::string name() const {return m_name;}
    std::string description() const {return m_desc;}
    std::string unit() const {return m_unit;}
    void setName(const std::string& _name) {m_name = _name;}
    void setDescription(const std::string& _desc) {m_desc = _desc;}
    void setUnit(const std::string& _unit) {m_unit = _unit;}

private:
    std::string m_name; // KPI value name
    std::string m_desc; // KPI value description
    std::string m_unit; // KPI value unit of measurement
};

typedef std::vector<KPIValueSetDefinition> KPIValueSetDefinitionList;


// KPI definition
class KPIDefinition
{
public:
    explicit KPIDefinition(const std::string& _name, const std::string& _desc, const KPIValueSetDefinitionList& _values):m_name (_name), m_desc(_desc), m_values (_values){}
    explicit KPIDefinition() {}
    virtual ~KPIDefinition() {}

    std::string name() const {return m_name;}
    std::string description() const {return m_desc;}
    KPIValueSetDefinitionList* values() {return &m_values;}
    void setName(const std::string& _name) {m_name = _name;}
    void setDescription(const std::string& _desc) {m_desc = _desc;}
    void setValues(const KPIValueSetDefinitionList& _values) {m_values = _values;}

private:
    std::string m_name; // KPI name
    std::string m_desc; // KPI description
    KPIValueSetDefinitionList m_values; // KPI value definitions
};

typedef std::vector<KPIDefinition> KPIDefinitionList;


// callback type KPI data update event
typedef boost::function<void (const KPIData&)> KPIDataCallback;


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class KPI
{
// functions throw IGS::exception
public:
    static KPI* getInstance() {return instance;}

    // meta data
    virtual void getKpis(KPIDefinitionList& kpis) = 0;
    virtual void getKpi(const std::string& kpiName, KPIDefinition& kpi) = 0;
    
    // data
    virtual void getKpiData(const std::string& kpiName, time_t startTime, time_t stopTime, KPIDataList& kpiData) = 0;

    // data update
    virtual void subscribeToKpiData(const KPINameList& kpis, const KPIDataCallback& cb) = 0;
    virtual void unsubscribeToKpiData() = 0;

protected:
    // instance
    virtual ~KPI() {}
    static KPI* instance;
};

} // namespace IGSxKPI

#endif // IGSXKPI_HPP

