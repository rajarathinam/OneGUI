/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation file for Utility class
|
| ! \file        IGSxGUIxUtil.cpp
| ! \brief       Implementation file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxUtil.hpp"
#include <QDialog>
#include <QScrollArea>
#include <QApplication>
#include <QTableView>
#include <QHeaderView>
#include <QLabel>
#include <QPushButton>
#include <QTableWidgetItem>
#include <QTextCodec>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QMovie>
#include <string>
#include <algorithm>
#include <SUIDialog.h>
#include <SUIBaseWidget.h>
#include <SUITableWidget.h>
#include <SUILabel.h>
#include <SUITableWidgetImpl.h>
#include <SUILabelImpl.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
QChar IGSxGUI::Util::m_awesomeChar = 0xf2c2;

IGSxGUI::Util::Util()
{
}

void IGSxGUI::Util::setIcon(SUI::BaseWidget* baseWidget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string &color, const int size)
{
    QChar character;

    switch (icon)
    {
        case IGSxGUI::AwesomeIcon::AI_fa_exclamation:
            {
            const QChar exclamation(0xf12a);
            character = exclamation;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle:
            {
            const QChar exclamationTriangle(0xf071);
            character = exclamationTriangle;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_times:
            {
            const QChar times(0xf00d);
            character = times;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_times_circle:
            {
            const QChar timesCircle(0xf057);
            character = timesCircle;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_bell:
            {
            const QChar bell(0xf0f3);
            character = bell;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_sort_desc:
            {
            const QChar downArrow(0xf0dd);
            character = downArrow;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_sort_asc:
            {
            const QChar upArrow(0xf0de);
            character = upArrow;
            break;
            }
       case IGSxGUI::AwesomeIcon::AI_fa_sort_default:
            {
            const QChar defaultArrows(0xf0dc);
            character = defaultArrows;
            break;
            }
       case IGSxGUI::AwesomeIcon::AI_fa_copyright:
            {
            const QChar copyright(0xf1f9);
            character = copyright;
            break;
            }
       case IGSxGUI::AwesomeIcon::AI_fa_cog:
            {
            const QChar cog(0xf013);
            character = cog;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_sliders:
            {
            const QChar slider(0xf1de);
            character = slider;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_dashboard:
            {
            const QChar dashboard(0xf0e4);
            character = dashboard;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_sitemap:
            {
            const QChar sitemap(0xf0e8);
            character = sitemap;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_checkcircle:
            {
            const QChar checkcircle(0xf058);
            character = checkcircle;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_clock:
            {
            const QChar clock(0xf017);
            character = clock;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_crosshairs:
            {
            const QChar crosshairs(0xf05b);
            character = crosshairs;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_areachart:
            {
            const QChar areachart(0xf1fe);
            character = areachart;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_stethoscope:
            {
            const QChar stethoscope(0xf0f1);
            character = stethoscope;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_check:
            {
            const QChar check(0xf00c);
            character = check;
            break;
            }
        case IGSxGUI::AwesomeIcon::AI_fa_close:
            {
            const QChar check(0xf00d);
            character = check;
            break;
            }
        default:
            {
            const QChar defaultIcon(0xf2c2);
            character = defaultIcon;
            break;
            }
    }

    switch (baseWidget->getObjectType())
    {
         case SUI::ObjectType::Label:
         {
             QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
             if (qlabel != NULL)
             {
                 IGSxGUI::Util::setAwesomeStyle(baseWidget, color, size);
                 qlabel->setText(character);
             }
             break;
         }
        case SUI::ObjectType::Button:
        {
            QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
            if (qpushbutton != NULL)
            {
                IGSxGUI::Util::setAwesomeStyle(baseWidget, color, size);
                qpushbutton->setText(character);
            }
            break;
        }
        default:
        {
            // We do not support all widgets
            break;
        }
    }
    m_awesomeChar = character;
}

QChar IGSxGUI::Util::getAwesomeChar()
{
    return IGSxGUI::Util::m_awesomeChar;
}

void IGSxGUI::Util::setGeometry(SUI::Widget* widget, int x, int y, int width, int height)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    if (qwidget != NULL)
    {
        QWidget* qparent = qwidget->parentWidget();
        qwidget->setGeometry(x, qparent->y() + y, width, height);
    }
}

void IGSxGUI::Util::setWindowFrame(SUI::Dialog* dialog, bool enable)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);

    if (qdialog != NULL)
    {
        if (enable)
        {
            qdialog->setWindowFlags(Qt::Dialog);
        } else {
            qdialog->setWindowFlags(Qt::Sheet | Qt::FramelessWindowHint);
            qdialog->setFixedSize(qdialog->geometry().size());
        }
    }
}

void IGSxGUI::Util::disableScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL)
    {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");

        if (scrollArea != NULL)
        {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
    }
}

void IGSxGUI::Util::setParent(SUI::Widget* widget, SUI::Widget *parent)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    SUI::BaseWidget* suiparent = dynamic_cast<SUI::BaseWidget*>(parent);

    QWidget* topWidget = suiparent->getWidget()->nativeParentWidget();
    qwidget->setParent(topWidget);
}

void IGSxGUI::Util::processEvents(){
    QApplication::processEvents();
}

const std::string IGSxGUI::Util::elideText(const std::string& str, int fontsize, int width)
{
    std::string elidedtext = str;
    if ((width > 0) && (!str.empty()))
    {
           QFont font("Roboto", fontsize);
           QFontMetrics fm(font);
           QString intext(str.c_str());
           QString outtext = fm.elidedText(intext, Qt::ElideRight, width);

           // To do , last char is not printable char('...')
           QChar ch = outtext.at(outtext.length() - 1);
           if (!static_cast<bool>(ch.toAscii()))
           {
           outtext.chop(4);
           elidedtext = outtext.toStdString() + "...";
           } else {
              elidedtext = outtext.toStdString();
           }
    }
    return elidedtext;
}

void IGSxGUI::Util::sort(int column, SUI::TableWidget* widget, SortOrder::SortOrderEnum order)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableWidget = dynamic_cast<QTableView*>(baseWidget->getWidget());

    QAbstractItemModel* m = tableWidget->model();
    m->sort(column, (order == SortOrder::Descending)? Qt::DescendingOrder : Qt::AscendingOrder);
}

void IGSxGUI::Util::setScalable(SUI::TableWidget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    tableView->verticalHeader()->setResizeMode(QHeaderView::ResizeToContents);
}

void IGSxGUI::Util::setAwesome(SUI::Widget *widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string &color, const int size)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    IGSxGUI::Util::setIcon(baseWidget, icon, color, size);
}

void IGSxGUI::Util::setAwesome(SUI::Widget *widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, SUI::ColorEnum::Color color, const int size)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    IGSxGUI::Util::setIcon(baseWidget, icon, SUI::ColorEnum::toString(color), size);

    switch (baseWidget->getObjectType())
    {
        case SUI::ObjectType::TableWidgetItem:
        {
            QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(baseWidget);
            if (tableItem != NULL)
            {
               tableItem->setFont(QFont("FontAwesome"));
               QTextCodec::setCodecForCStrings(QTextCodec::codecForName("utf8"));
               tableItem->setText(IGSxGUI::Util::getAwesomeChar());
               setColor(widget, color, NULL);
            }
            break;
        }
        default:
        {
            // We do not support all widgets
            break;
        }
    }
}

void IGSxGUI::Util::setAwesomeStyle(SUI::BaseWidget *baseWidget, const std::string &customcolor, const int size)
{
    QString style("font-family: FontAwesome;");

    if (customcolor != "")
    {
        style.append("color: " + QString::fromStdString(customcolor) + ";");
    }

    if (size != NO_SIZE)
    {
        style.append("font-size: " + QString::number(size) + "px;");
    }

    switch (baseWidget->getObjectType())
    {
         case SUI::ObjectType::Label:
         {
             QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
             if (qlabel != NULL)
             {
                 qlabel->setStyleSheet(style);
             }
             break;
         }
        case SUI::ObjectType::Button:
        {
            QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
            if (qpushbutton != NULL)
            {
                qpushbutton->setStyleSheet(style);
            }
            break;
        }
        default:
        {
            // We do not support all widgets
            break;
        }
    }
}

void IGSxGUI::Util::setColor(SUI::Widget* widget, SUI::ColorEnum::Color color, SUI::TableWidget* tableWidget)
{
    QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(widget);

    if (tableItem != NULL)
    {
        switch (color)
        {
            case SUI::ColorEnum::White:
            {
                tableItem->setForeground(Qt::white);
                break;
            }
            case SUI::ColorEnum::Red:
            {
                tableItem->setForeground(Qt::red);
                break;
            }
            case SUI::ColorEnum::Yellow:
            {
                tableItem->setForeground(Qt::yellow);
                break;
            }
            case SUI::ColorEnum::Blue:
            {
                const int ALERTTABLE_FGCOLOR_RED = 10;
                const int ALERTTABLE_FGCOLOR_GREEN = 168;
                const int ALERTTABLE_FGCOLOR_BLUE = 251;

                tableItem->setForeground(QColor::fromRgb(ALERTTABLE_FGCOLOR_RED, ALERTTABLE_FGCOLOR_GREEN, ALERTTABLE_FGCOLOR_BLUE));
                break;
            }
            case SUI::ColorEnum::Black:
            {
                tableItem->setForeground(Qt::black);
                break;
            }
            case SUI::ColorEnum::Gray:
            {
                tableItem->setForeground(Qt::gray);
                break;
            }
            default:
            {
                tableItem->setForeground(Qt::white);
                break;
            }
        }
        if (tableWidget != NULL)
        {
            SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
            QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
            tableView->update();
        }
    }
}

void IGSxGUI::Util::addLabel(SUI::TableWidget *tableWidget, int row, int column)
{
    SUI::TableWidgetImpl* tableWidgetImpl = dynamic_cast<SUI::TableWidgetImpl*>(tableWidget);

    SUI::BaseWidget* newWidget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::Label, tableWidgetImpl->getWidget());
    newWidget->setVisible(false);
    newWidget->addCellProperties(SUI::AlignmentEnum::Stretch);
    SUI::Widget *w = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(newWidget));
    tableWidgetImpl->updateCell(row, column, SUI::AlignmentEnum::HCenter, w);
    newWidget->setVisible(true);
}

void IGSxGUI::Util::addButton(SUI::TableWidget *tableWidget, int row, int column)
{
    SUI::TableWidgetImpl* tableWidgetImpl = dynamic_cast<SUI::TableWidgetImpl*>(tableWidget);

    SUI::BaseWidget* newWidget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::Button, tableWidgetImpl->getWidget());
    newWidget->setVisible(false);
    newWidget->addCellProperties(SUI::AlignmentEnum::Stretch);
    SUI::Widget *w = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(newWidget));
    tableWidgetImpl->updateCell(row, column, SUI::AlignmentEnum::HCenter, w);
    newWidget->setVisible(true);
}
void IGSxGUI::Util::setTranslucentBackground(SUI::Dialog *dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL)
    {
        Qt::WindowFlags flags = qdialog->windowFlags();
        qdialog->setWindowFlags(flags | Qt::WindowStaysOnTopHint);
        qdialog->setAttribute(Qt::WA_TranslucentBackground);
    }
}

void IGSxGUI::Util::setFadeOut(SUI::Dialog* dialog, int duration)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);

    if (qdialog != NULL)
    {
        QGraphicsOpacityEffect *effect = new QGraphicsOpacityEffect(qdialog);
        // qdialog is being passed as parent to QGraphicsOpacityEffect.
        // memory of QGraphicsOpacityEffect object will be released once parent sui->dialog is deleted
        qdialog->setGraphicsEffect(effect);

        QPropertyAnimation *animation = new QPropertyAnimation(effect, "opacity");
        animation->setDuration(duration);
        animation->setStartValue(1);
        animation->setEndValue(0);
        animation->setEasingCurve(QEasingCurve::Linear);
        // animation object will be deleted/released once the animation is stopped (by the property QPropertyAnimation::DeleteWhenStopped)
        animation->start(QPropertyAnimation::DeleteWhenStopped);
    }
}

void IGSxGUI::Util::setImageToLabel(SUI::Label* label, SUI::Dialog *dialog, const std::string &resourcepath)
{
    SUI::LabelImpl* labelimpl = dynamic_cast<SUI::LabelImpl*>(label);
    QLabel *progressbarLabel = labelimpl->getWidget();

    if (progressbarLabel != NULL)
    {
        QString pathProgressbar = QString::fromUtf8(resourcepath.c_str());
        QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
        QMovie *movie = new QMovie(pathProgressbar, QByteArray(), qdialog);
        // qdialog is being passed as parent to QMovie.
        // memory of QMovie object will be released once parent sui->dialog is deleted
        if (movie->isValid())
        {
            progressbarLabel->setMovie(movie);
            movie->start();
        }
    }
}



