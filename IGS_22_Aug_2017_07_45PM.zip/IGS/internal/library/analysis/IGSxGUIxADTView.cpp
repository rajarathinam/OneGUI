/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = "IGSxGUIxADT.xml";
const std::string IGSxGUI::ADTView::STRING_EMPTY = "";
const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "All ADTs";
const std::string IGSxGUI::ADTView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::ADTView::STRING_ADTVIEW_SHOWN = "ADTView is shown.";
const char* IGSxGUI::ADTView::STRING_ADT_MESSAGE = "Start ADT button pressed, Adt Name: ";

const std::string IGSxGUI::ADTView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::ADTView::STRING_SPACE = "  ";
const int IGSxGUI::ADTView::ITEMS_TO_REMOVE = 20;

IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_bRunningADT(false),
    m_selectedSubSystem(""),
    m_selectedADT("")
{
    m_presenter = new ADTPresenter(this, pADTManager);
}

IGSxGUI::ADTView::~ADTView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    loadContainers();
    init();
    IGS_INFO(STRING_ADTVIEW_SHOWN);
}

void IGSxGUI::ADTView::init()
{
    sui->tawADTSubsystem->showGrid(false);

    m_listADT = m_presenter->getADTs();
    m_listSubsystemADTs = m_presenter->getADTs();

    loadSubSystems();
    loadADTs();
}

void IGSxGUI::ADTView::onSubSystemClosePressed()
{
  EnableCountLabels();
  DisableCloseButtons();
}

void IGSxGUI::ADTView::EnableCountLabels()
{
  for(int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
      dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 1))->setVisible(true);
    }
}
void IGSxGUI::ADTView::DisableCloseButtons()
{
  for(int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
      dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 2))->setVisible(false);
    }
}

void IGSxGUI::ADTView::onSubsystemPressed()
{
    EnableCountLabels();
    DisableCloseButtons();
    std::list<std::string> items = sui->tawADTSubsystem->getSelectedItems();
    std::string strSelectedRow = items.front();

    strSelectedRow.erase(0, ITEMS_TO_REMOVE);
    strSelectedRow.erase(strSelectedRow.size()-2, strSelectedRow.size());
    int row = (boost::lexical_cast<int>(strSelectedRow)-1);
    dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(row, 1))->setVisible(false);
    dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(row, 2))->setVisible(true);

    std::string selectedText = sui->tawADTSubsystem->getItemText((boost::lexical_cast<int>(strSelectedRow)-1), 0);

    //size_t position = selectedText.find('(');
    boost::trim(selectedText);
    m_selectedSubSystem = selectedText;

    std::vector<ADT*> listSubsystemADTs;

    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == selectedText))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    loadADTs();

}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::loadADTs()
{
  std::vector<IGSxGUI::ADT *> adts = getSelectedSubSystemADTs();
  std::cout << adts.size() << std::endl;
}

void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(const IGS::Result &result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;
    }
}

void IGSxGUI::ADTView::startADT(const std::string &adtName) const
{
    IGS_INFO(std::string(STRING_ADT_MESSAGE + adtName));
    m_presenter->startADT(adtName);
}

void IGSxGUI::ADTView::loadContainers()
{
}

void IGSxGUI::ADTView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemADTs.size(); i++)
    {
        subsystem.name = m_listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = m_listSubsystemADTs[i];
        listStringSubsystem.push_back(m_listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;


    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        IGSxGUI::Util::addLabel(sui->tawADTSubsystem, i,1);
        SUI::Label* label = dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 1));
        label->setStyleSheetClass("adtsubsystem");
        IGSxGUI::Util::addButton(sui->tawADTSubsystem, i,2);
        SUI::Button* button = dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(i, 2));
       button->setVisible(false);
       button->clicked = boost::bind(&ADTView::onSubSystemClosePressed, this);
        IGSxGUI::Util::setAwesome(button, IGSxGUI::AwesomeIcon::AI_fa_close,"#1b3e92",12);
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        sui->tawADTSubsystem->appendRow();
        sui->tawADTSubsystem->setItemText(static_cast<int>(i), 0, subsyscount.nameSubsystem);
        dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 1))->setText(subsys);        
    }
    sui->tawADTSubsystem->removeRow(sui->tawADTSubsystem->rowCount() - 1);
    IGSxGUI::Util::setScalable(sui->tawADTSubsystem);


}

void IGSxGUI::ADTView::setHandlers()
{
    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
}

void IGSxGUI::ADTView::setTextArea(const std::string& /*adtDescription*/, const std::string & adtTestName, const std::string& /*adtTestType*/) const
{
    if (!m_listADT.empty())
    {
        std::string textADTHtmlFilePath = "";
        size_t noofADTs = m_listADT.size();
        for (size_t index = 0; index < noofADTs; ++index)
        {
            if (m_listADT[index]->getName() == adtTestName)
            {
                textADTHtmlFilePath =  m_listADT[index]->getHtmlFile();
                break;
            }
        }
    }
}
