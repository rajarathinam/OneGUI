/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsPresenter.hpp
| Author       : Raja
| Description  : Header file for Machineconstants presenter
|
| ! \file        IGSxGUIxMachineconstantsPresenter.hpp
| ! \brief       Header file for Machineconstants presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSPRESENTER_HPP
#define IGSXGUIXMACHINECONSTANTSPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class MachineconstantsPresenter
{
 public:
    explicit MachineconstantsPresenter(IMachineconstantsView* view, MachineconstantsManager* pCPDManager);
    virtual ~MachineconstantsPresenter();



 private:
    MachineconstantsPresenter(const CPDPresenter& cpdPresenter);
    MachineconstantsPresenter& operator=(const CPDPresenter& cpdPresenter);


    MachineconstantsManager* m_pMachineconstantsManager;
    IMachineconstantsView* m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSPRESENTER_HPP
