/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include <SUIDialog.h>
#include <SUIObjectList.h>
#include <SUIButton.h>
#include <SUIUserControl.h>
#include <SUITimer.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = "IGSxGUIxADT.xml";
const std::string IGSxGUI::ADTView::STRING_EMPTY = "";
const std::string IGSxGUI::ADTView::STRING_SINGLESPACE = " ";
const char IGSxGUI::ADTView::NEWLINE_CHAR = '\n';
const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "ALL ADTs";
const std::string IGSxGUI::ADTView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::ADTView::STRING_ADTVIEW_SHOWN = "ADTView is shown.";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::ADTView::STRING_ADTSUBSYSTEM_STYLE = "adtsubsystem";
const std::string IGSxGUI::ADTView::STRING_SLASH = " / ";
const std::string IGSxGUI::ADTView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::ADTView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::ADTView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const std::string IGSxGUI::ADTView::CUSTOM_STYLESHEET = "customCss.css";
const std::string IGSxGUI::ADTView::STRING_ADT_ALREADY_RUNNING = "ADT is already running";
const std::string IGSxGUI::ADTView::STRING_ADT_SHOWING = "Opening ADT...";
const char* IGSxGUI::ADTView::STRING_ADT_MESSAGE = "Start ADT button pressed, Adt Name: ";
const int IGSxGUI::ADTView::ADTSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::ADTView::AWESOME_ANGLE_SIZE = 22;
const int IGSxGUI::ADTView::ADTTABLE_ROW_SIZE = 62;
const int IGSxGUI::ADTView::NORMAL_SUBSYSTEM_ROW_SIZE = 40;
const int IGSxGUI::ADTView::EXTENDED_SUBSYSTEM_ROW_SIZE = 60;
const std::string::size_type IGSxGUI::ADTView::MAX_SUBSYSTEM_CHARS_PER_CELL = 21;

IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_bRunningADT(false),
    m_selectedSubSystem(""),
    m_selectedSubsystemRowNum(-1),
    m_selectedAdt(""),
    m_selectedAdtRowNum(-1),
    m_isDescFolded(true),
    m_isCloseButtonPressed(false),
    m_isInternalCallToSubsystemPressed(false),
    m_startingAdtTimer(SUI::Timer::createTimer())
{
    m_presenter = new ADTPresenter(this, pADTManager);
    m_startingAdtTimer->setSingleShot(true);
    m_startingAdtTimer->timeout = boost::bind(&ADTView::onShowADTStartingTimeout, this);
}

IGSxGUI::ADTView::~ADTView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }

    IGSxGUI::Util::addCustomStylesheet(sui->wvwADTHTMLDescription, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));

    setHandlers();
    init();
    IGS_INFO(STRING_ADTVIEW_SHOWN);
}

void IGSxGUI::ADTView::init()
{
    sui->tawADTSubsystem->showGrid(false);
    sui->tawADT->showGrid(false);

    m_listADT = m_presenter->getADTs();
    m_listSubsystemADTs = m_presenter->getADTs();

    loadSubSystems();

    if ((m_selectedSubSystem != "") || (m_selectedAdt != ""))
    {
        reload();
    } else {
        loadADTTable();
    }
}

void IGSxGUI::ADTView::onSubSystemClosePressed()
{
    EnableCountLabels();
    m_isCloseButtonPressed = true;
    DisableCloseButtons();
    m_isCloseButtonPressed = false;

    IGSxGUI::Util::clearSelection(sui->tawADTSubsystem);

    m_selectedSubSystem = "";
    m_selectedSubsystemRowNum = -1;

    loadADTTable();
}

void IGSxGUI::ADTView::EnableCountLabels()
{
    for (int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 2))->setVisible(true);
    }
}
void IGSxGUI::ADTView::DisableCloseButtons()
{
    for (int rowIndex = 0; rowIndex < sui->tawADTSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(rowIndex, 3))->setVisible(false);
    }
}

void IGSxGUI::ADTView::onSubsystemPressed()
{
    if (m_isCloseButtonPressed)
    {
        return;
    }
    if (!m_isInternalCallToSubsystemPressed)
    {
        m_selectedAdt = "";
        m_selectedAdtRowNum = -1;
    }

    std::vector<int> items = sui->tawADTSubsystem->getSelectedRows();
    if (items.size() > 0)
    {
        EnableCountLabels();
        DisableCloseButtons();
        m_selectedSubsystemRowNum = items[0];
        dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 2))->setVisible(false);
        dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 3))->setVisible(true);

        std::string selectedText = sui->tawADTSubsystem->getItemText(boost::lexical_cast<int>(m_selectedSubsystemRowNum), 1);
        std::replace(selectedText.begin(), selectedText.end(), NEWLINE_CHAR, ' ');
        boost::trim(selectedText);
        m_selectedSubSystem = selectedText;
        sui->lblAllADTs->setText(STRING_ALL_ADTS + STRING_SLASH + m_selectedSubSystem);

        std::vector<ADT*> listSelectedSubsystemADTs = getSelectedSubSystemADTs();
        m_usercontrols.clear();
        populateADTTable(listSelectedSubsystemADTs);
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
        container subsys = m_listSubsystems[i];
        if (subsys.name == m_selectedSubSystem)
        {
            listSubsystemADTs.push_back(subsys.adt);
        }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::setDescriptionPaneVisible(bool visibility)
{
    sui->lblLine->setVisible(visibility);
    sui->lblAngle->setVisible(visibility);
    sui->lblSelectedADT->setVisible(visibility);
    sui->btnOpenADT->setVisible(visibility);
    sui->btnDescription->setVisible(visibility);
    sui->wvwADTHTMLDescription->setVisible(visibility);
}

void IGSxGUI::ADTView::populateADTTable(std::vector<ADT*> listADT)
{
    sui->tawADT->removeRows(1, sui->tawADT->rowCount()-1);
    for (size_t i = 0 ; i < listADT.size() - 1; i++)
    {
        sui->tawADT->appendRow();
    }
    for (int row = 0; row < sui->tawADT->rowCount(); ++row)
    {
        SUI::Widget *widget = sui->tawADT->getWidgetItem(row, 0);
        IGSxGUI::Util::setADTUCTNormalStyle(widget);
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        usercontrol->clicked = boost::bind(&ADTView::onTableADTRowPressed, this, row);
        usercontrol->hoverEntered = boost::bind(&ADTView::onADTUCTHoverEntered, this, row);
        usercontrol->hoverLeft = boost::bind(&ADTView::onADTUCTHoverLeft, this, row);
        m_usercontrols.push_back(usercontrol);

        IGSxGUI::Util::setTextToADTUserControl(widget, 0, listADT[row]->getName());
        IGSxGUI::Util::setTextToADTUserControl(widget, 1, listADT[row]->getDescription());
        IGSxGUI::Util::setTextToADTUserControl(widget, 2, STRING_EMPTY);
        IGSxGUI::Util::setRowHeight(sui->tawADT, row, ADTTABLE_ROW_SIZE);
    }
    IGSxGUI::Util::clearSelection(sui->tawADT);
    setDescriptionPaneVisible(false);
}

void IGSxGUI::ADTView::loadADTTable()
{
    m_usercontrols.clear();
    populateADTTable(m_listADT);
    sui->lblAllADTs->setText(STRING_ALL_ADTS);
}

void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(const IGS::Result &result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;
    }
}

void IGSxGUI::ADTView::insertCountLabelAndCloseButton(size_t i)
{
    IGSxGUI::Util::addLabel(sui->tawADTSubsystem, i, 2);
    SUI::Label* label = dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 2));
    label->setStyleSheetClass(STRING_ADTSUBSYSTEM_STYLE);
    IGSxGUI::Util::addButton(sui->tawADTSubsystem, i, 3);
    SUI::Button* button = dynamic_cast<SUI::Button*>(sui->tawADTSubsystem->getWidgetItem(i, 3));
    button->setVisible(false);
    button->clicked = boost::bind(&ADTView::onSubSystemClosePressed, this);
    IGSxGUI::Util::setAwesome(button, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, ADTSUBSYSTEM_CLOSEBUTTON_SIZE);
}

void IGSxGUI::ADTView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    if (subsyscount.nameSubsystem.length() > MAX_SUBSYSTEM_CHARS_PER_CELL)
    {
        std::string str1 = STRING_EMPTY;
        std::string str2 = STRING_EMPTY;
        std::vector<std::string> tokens;
        boost::split(tokens, subsyscount.nameSubsystem, boost::is_any_of(STRING_SINGLESPACE));
        for (size_t index = 0; index < tokens.size(); ++index)
          {
            if (str1.length() < MAX_SUBSYSTEM_CHARS_PER_CELL)
            {
                str1 = str1 + STRING_SINGLESPACE+ tokens[index];
            } else {
                str2 = str2 + STRING_SINGLESPACE + tokens[index];
            }
          }
        boost::trim(str1);
        boost::trim(str2);
        sui->tawADTSubsystem->setItemText(static_cast<int>(i), 1, str1 + NEWLINE_CHAR + str2);
    } else {
        sui->tawADTSubsystem->setItemText(static_cast<int>(i), 1, subsyscount.nameSubsystem);
    }
    IGSxGUI::Util::setColor(sui->tawADTSubsystem->getWidgetItem(i, 1), SUI::ColorEnum::White, sui->tawADTSubsystem);
    dynamic_cast<SUI::Label*>(sui->tawADTSubsystem->getWidgetItem(i, 2))->setText(subsys);
}

void IGSxGUI::ADTView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemADTs.size(); i++)
    {
        subsystem.name = m_listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = m_listSubsystemADTs[i];
        listStringSubsystem.push_back(m_listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        insertCountLabelAndCloseButton(i);
        sui->tawADTSubsystem->appendRow();
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        if (subsyscount.nameSubsystem.length() < MAX_SUBSYSTEM_CHARS_PER_CELL)
        {
            IGSxGUI::Util::setRowHeight(sui->tawADTSubsystem, i, NORMAL_SUBSYSTEM_ROW_SIZE);
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawADTSubsystem, i, EXTENDED_SUBSYSTEM_ROW_SIZE);
        }
        setValuesToRowWidgets(subsys, i, subsyscount);
    }

    sui->tawADTSubsystem->removeRow(sui->tawADTSubsystem->rowCount() - 1);
}

void IGSxGUI::ADTView::setHandlers()
{
    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
    sui->btnOpenADT->clicked = boost::bind(&ADTView::onOpenADTClicked, this);
    sui->btnDescription->clicked = boost::bind(&ADTView::onDescriptionClicked, this);
    sui->btnDescription->hoverEntered = boost::bind(&ADTView::onDescriptionHoverEntered, this);
    sui->btnDescription->hoverLeft = boost::bind(&ADTView::onDescriptionHoverLeft, this);
}

void IGSxGUI::ADTView::onTableADTRowPressed(int rowindex)
{
    SUI::Widget *widget = sui->tawADT->getWidgetItem(rowindex, 0);
    IGSxGUI::Util::setADTUCTClickedStyle(widget);
    m_selectedAdt = IGSxGUI::Util::getADTNameFromUserControl(widget);
    boost::trim(m_selectedAdt);
    if (m_selectedAdtRowNum == rowindex)
    {
        IGSxGUI::Util::setADTUCTNormalStyle(sui->tawADT->getWidgetItem(rowindex, 0));
        m_selectedAdt = "";
        m_selectedAdtRowNum = -1;
        showADTDetailsPage(false, m_selectedAdt);
    } else {
        m_selectedAdtRowNum = rowindex;
        EnableCountLabels();
        for (int i = 0; i < sui->tawADT->rowCount(); ++i )
        {
            IGSxGUI::Util::setADTUCTNormalStyle(sui->tawADT->getWidgetItem(i, 0));
        }
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawADT->getWidgetItem(rowindex, 0));
        showADTDetailsPage(true, m_selectedAdt);
    }
}

void IGSxGUI::ADTView::onADTUCTHoverEntered(int index)
{
    if (m_selectedAdtRowNum != index)
    {
        SUI::Widget *widget = sui->tawADT->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::ADTView::onADTUCTHoverLeft(int index)
{
  if (m_selectedAdtRowNum != index)
  {
        SUI::Widget *widget = sui->tawADT->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOffStyle(widget);
  }
}

void IGSxGUI::ADTView::onDescriptionHoverEntered()
{
    if (m_isDescFolded)
    {
        IGSxGUI::Util::setUnderline(sui->btnDescription, true);
    }
}

void IGSxGUI::ADTView::onDescriptionHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnDescription, false);
}

void IGSxGUI::ADTView::showADTDetailsPage(bool isVisible, const std::string &adtName)
{
    sui->lblLine->setVisible(isVisible);
    sui->lblAngle->setVisible(isVisible);
    sui->lblSelectedADT->setVisible(isVisible);
    sui->btnOpenADT->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->wvwADTHTMLDescription->setVisible(isVisible);

    if (isVisible)
    {
        sui->lblSelectedADT->setText(adtName);
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);

        if (m_isDescFolded)
        {
            showHTMLReport(false);
        } else {
            IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showHTMLReport(true);
        }
    }
}

void IGSxGUI::ADTView::onDescriptionClicked()
{
    if (m_isDescFolded)
    {
        m_isDescFolded = false;
        showHTMLReport(true);
        IGSxGUI::Util::setUnderline(sui->btnDescription, false);
    } else {
        m_isDescFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showHTMLReport(false);
    }
}

void IGSxGUI::ADTView::onOpenADTClicked()
{
    IGS_INFO(std::string(STRING_ADT_MESSAGE + m_selectedAdt));

    if (m_presenter->isADTRunning(m_selectedAdt))
    {
        sui->lblStartingAdt->setText(STRING_ADT_ALREADY_RUNNING);
    } else {
        sui->lblStartingAdt->setText(STRING_ADT_SHOWING);
    }
    sui->lblStartingAdt->setVisible(true);
    IGSxGUI::Util::processEvents();

    const int timout = 2000;
    m_startingAdtTimer->start(timout);

    m_presenter->startADT(m_selectedAdt);
}

void IGSxGUI::ADTView::onShowADTStartingTimeout()
{
    sui->lblStartingAdt->setVisible(false);
}

void IGSxGUI::ADTView::showHTMLReport(bool isVisible)
{
    if (isVisible)
    {
        if (m_selectedAdt != "")
        {
            IGSxGUI::ADT* adt = m_presenter->getADT(m_selectedAdt);

            if (adt != NULL)
            {
                IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
                std::string strADTHTMLFilePath = adt->getHtmlFile();
                sui->wvwADTHTMLDescription->setVisible(true);
                sui->wvwADTHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strADTHTMLFilePath));
                sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
            }
        }
    } else {
        sui->wvwADTHTMLDescription->setVisible(false);
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
    }
}

void IGSxGUI::ADTView::reload()
{
    if (m_selectedSubSystem != "")
    {
        m_isInternalCallToSubsystemPressed = true;
        IGSxGUI::Util::selectRow(sui->tawADTSubsystem, m_selectedSubsystemRowNum);
        m_isInternalCallToSubsystemPressed = false;
    } else {
        loadADTTable();
    }

    if (m_selectedAdt != "")
    {
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawADT->getWidgetItem(m_selectedAdtRowNum, 0));
        showADTDetailsPage(true, m_selectedAdt);

        if (m_isDescFolded)
        {
            IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showHTMLReport(false);
        } else {
            showHTMLReport(true);
        }
    }
}
