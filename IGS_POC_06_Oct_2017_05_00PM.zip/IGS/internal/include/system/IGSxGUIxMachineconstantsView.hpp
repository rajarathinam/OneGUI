
/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Machineconstants View
|
| ! \file        IGSxGUIxICPDView.hpp
| ! \brief       Header file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <unordered_map>
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{

class MachineconstantsView : public IMachineconstantsView
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const std::string&, const IGS::Result& /*result*/);
    virtual void setActive(bool);
    void onRowPressed(int row);
    void onParameterNameHoverEntered();
    void onParameterNameHoverLeft();
    void onParameterValueHoverEntered();
    void onParameterValueHoverLeft();

    void onParameterRowPressed(int row);
    void onParameterUCTHoverEntered(int row);
    void onParameterUCTHoverLeft(int row);

    void onSearchButtonHoverEntered();
    void onSearchButtonHoverLeft();
    void onSearchTextEdited(const std::string &text);
    void onSearchTextEditFinished();
    void onSearchClearHoverLeft();
    void onSearchClearHoverEntered();

    void setHandlers();
    void setUCTHandlers(SUI::Widget *widget, int row, bool readonly);
    void createTableData();
    void onSearchClearPressed();
    void onSearchParameterPressed();
    void onValueChanged();
    void setTableRows(int value);
private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);
    void init();
    int searchForParameters(const std::string &textToSearch);

    SUI::MachineconstantsView *sui;

    std::vector<std::string> m_tabledata;

    static const int ROW_HEIGHT;
    static const int MAX_VISIBLE_ROWS;
    static const int TOTAL_PARAMETERS_COUNT;
    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;
    static const std::string STRING_SEARCH_PARAMETER;
    static const std::string STRING_GREY_REGULAR;
    static const std::string STRING_BLUE_REGULAR;
    static const std::string STRING_PARAMETER_FOUND;
    static const std::string STRING_PARAMETERS_FOUND;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSVIEW_HPP
