/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.hpp
| Author       : Venugopal S
| Description  : Header file for CPD view
|
| ! \file        IGSxGUIxCPDView.hpp
| ! \brief       Header file for CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDVIEW_HPP
#define IGSXGUIXCPDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class CPDView;
class Label;
class Button;
class UserControl;
class Timer;
}  // namespace SUI

namespace IGSxGUI{

struct structContainer
{
    std::string name;
    CPD* cpd;

    structContainer() : name(""), cpd(NULL)
    {
    }
};
typedef structContainer container;

struct structSubsystemCount
{
    std::string nameSubsystem;
    int count;

    structSubsystemCount() : nameSubsystem(""), count(0)
    {
    }
};
typedef structSubsystemCount subSystemCount;

class CPDView : public ICPDView
{
 public:
    explicit CPDView(CPDManager *pCPDManager);
    virtual ~CPDView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const std::string&, const IGS::Result&);
    virtual void setActive(bool bActive);

 private:
    CPDView(const CPDView &);
    CPDView& operator=(const CPDView &);

    void init();
    void reload();
    void setHandlers();
    void loadCPDTable();
    void loadSubSystems();
    void onOpenCPDClicked();
    void EnableCountLabels();
    void onSubsystemPressed();
    void DisableCloseButtons();
    void onDescriptionClicked();
    void onDescriptionHoverLeft();
    void onSubSystemClosePressed();
    void onShowCPDStartingTimeout();
    void onDescriptionHoverEntered();
    std::vector<CPD*> getSelectedSubSystemCPDs();
    void onCPDUCTHoverLeft(int index);
    void showHTMLReport(bool);
    void onCPDUCTHoverEntered(int index);
    void onTableCPDRowPressed(int rowindex);
    void populateCPDTable(std::vector<CPD*> listCPD);
    void insertCountLabelAndCloseButton(size_t i);
    void setDescriptionPaneVisible(bool);
    void showCPDDetailsPage(bool, const std::string&);
    void setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount);

    SUI::CPDView *sui;
    CPDPresenter *m_presenter;

    std::vector<CPD*> m_listCPD;
    std::vector<CPD*> m_listSubsystemCPDs;
    std::vector<IGSxGUI::container> m_listSubsystems;
    std::vector<IGSxGUI::subSystemCount> m_listSubsystemCount;
    std::vector<SUI::UserControl*>  m_usercontrols;

    bool m_bRunningCPD;
    std::string m_selectedSubSystem;
    int m_selectedSubsystemRowNum;
    std::string m_selectedCPD;
    int m_selectedCPDRowNum;
    bool m_isDescFolded;
    bool m_isCloseButtonPressed;
    bool m_isInternalCallToSubsystemPressed;
    boost::shared_ptr<SUI::Timer> m_startingCPDTimer;

    static const std::string STRING_ALL_CPDS;
    static const std::string CPDVIEW_LOAD_FILE;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STYLE_ASML_ORANGEBUTTON;
    static const std::string STYLE_ASML_DARKBLUEBUTTON;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STRING_EMPTY;
    static const std::string STRING_SLASH;
    static const std::string STRING_CPDVIEW_SHOWN;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STRING_CPDSUBSYSTEM_STYLE;
    static const std::string CUSTOM_STYLESHEET;
    static const std::string STRING_SINGLESPACE;
    static const char NEWLINE_CHAR;
    static const std::string STRING_CPD_ALREADY_RUNNING;
    static const std::string STRING_CPD_SHOWING;
    static const char* STRING_CPD_MESSAGE;
    static const int CPDSUBSYSTEM_CLOSEBUTTON_SIZE;
    static const int AWESOME_ANGLE_SIZE;
    static const int CPDTABLE_ROW_SIZE;
    static const int NORMAL_SUBSYSTEM_ROW_SIZE;
    static const int EXTENDED_SUBSYSTEM_ROW_SIZE;
    static const std::string::size_type MAX_SUBSYSTEM_CHARS_PER_CELL;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDVIEW_HPP
