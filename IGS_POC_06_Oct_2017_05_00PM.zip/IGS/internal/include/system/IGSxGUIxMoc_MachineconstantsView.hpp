/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.hpp
| ! \brief       Header file for Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class MachineconstantsView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class Button;
class TableWidget;
class LineEdit;
class Label;
class ScrollBar;

class MachineconstantsView
{
 private:
    MachineconstantsView();

    void setupSUI(const char *XMLFileName);
    void setupSUIContainer(const char *XMLFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    Dialog *dialog;
    Button *btnParameterName;
    Label *lblParameterNameTooltip;
    Button *btnParameterValue;
    Label *lblParameterValueTooltip;
    TableWidget *tawParameters;
    LineEdit *lneSearchParameterText;
    Button *btnSearchParameter;
    Button *btnSearchClear;
    Label *lblEntriesFound;
    ScrollBar *scb29;


    friend class ::IGSxGUI::MachineconstantsView;
};
}  // namespace SUI
#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
