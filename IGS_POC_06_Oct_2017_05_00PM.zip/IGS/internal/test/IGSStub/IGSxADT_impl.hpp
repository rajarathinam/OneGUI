/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADT_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxADT stub
|
| ! \file        IGSxADT_impl.hpp
| ! \brief       Header file for IGSxADT stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXADT_IMPL_HPP
#define IGSXADT_IMPL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxADT {

class ADT_Stub :public ADT
{
 public:
    static ADT* getInstance();

    // get all tools
    virtual void getAdts(MetaDescriptions& adts);

    // start a tool
    virtual void startAdt(const std::string& adtName);

    // Is ADT running?
    virtual bool isAdtRunning(const std::string& adtName);

 protected:
    ADT_Stub();
    virtual ~ADT_Stub() {}
 private:
    std::string m_runningAdt;
};
}  // namespace IGSxADT
#endif  // IGSXADT_IMPL_HPP
