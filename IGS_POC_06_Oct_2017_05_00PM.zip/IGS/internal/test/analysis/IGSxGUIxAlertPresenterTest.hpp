/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertPresenterTest.hpp
| Author       : Venugopal S
| Description  : Header file for Alert Presenter test
|
| ! \file        IGSxGUIxAlertPresenterTest.hpp
| ! \brief       Header file for Alert Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTPRESENTERTEST_HPP
#define IGSXGUIXALERTPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include "IGSxGUIxAlertPresenter.hpp"
#include "IGSxGUIxAlertEvent.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class AlertPresenterTest : public ::testing::Test
{
 public:
  AlertPresenterTest(){}
  virtual ~AlertPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
class AlertViewStub : public IGSxGUI::IAlertView
{
 private:
  bool m_status;
 public:
    AlertViewStub() : m_status(false){}
    ~AlertViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {
        m_status = true;
    }
    void updateAlerts(int /*nAlertCount*/, IGSxGUI::AlertInfo /*alertInfo*/) {
        m_status = true;
    }
    void setActive(bool /*bActive*/) {
        m_status = true;
    }

    void setStatus(bool bstatus)
    {
        m_status = bstatus;
    }
    bool getStatus() const
    {
        return m_status;
    }
};
#endif  // IGSXGUIXALERTPRESENTERTEST_HPP
