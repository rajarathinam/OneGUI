/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenterTest.hpp
| Author       : Raja
| Description  : Header file for ADT Presenter test
|
| ! \file        IGSxGUIxADTPresenterTest.hpp
| ! \brief       Header file for ADT Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTRESENTERTEST_HPP
#define IGSXGUIXADTPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxADTPresenter.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class ADTPresenterTest : public ::testing::Test
{
 public:
  ADTPresenterTest(){}
  virtual ~ADTPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIXADTPRESENTERTEST_HPP
