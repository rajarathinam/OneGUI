/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDateTime.hpp
| Author       : Raja A
| Description  : Header file for Date and Time
|
| ! \file        IGSxGUIxDateTime.hpp
| ! \brief       Header file for Date and Time
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDATETIME_HPP
#define IGSXGUIXDATETIME_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <SUITime.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
const std::string STRING_TIME = "Time";
const std::string STRING_DATETIME_FORMAT1 = "%l:%M%p";
const std::string STRING_DATETIME_FORMAT2 = "%d/%m/%Y";

struct TimeDescOrderComparator
{
 public:
    bool operator()(const IGSxCPD::TestResult& testresult1, const IGSxCPD::TestResult& testresult2)
    {
        if (testresult1.time() > testresult2.time())
        {
            return true;
        }else {
            return false;
        }
    }
};
class DateTime
{
 public:
    static std::string currentDateTime(const std::string& dateTime)
    {
        time_t     now = time(0);
        struct tm  tstruct;
        char       buf[80];
        tstruct = *localtime_r(&now, &tstruct);
        if (dateTime == STRING_TIME)
        {
            strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT1.c_str(), &tstruct);
        } else {
            strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT2.c_str(), &tstruct);
        }
        return buf;
    }

    static std::string formatTime(const time_t& in_time, const std::string& format)
    {
        char buff[20];
        strftime(buff, 20, format.c_str(), localtime(&in_time));
        std::string formatted_str(buff);
        return formatted_str;
    }
    static time_t DateTimeToTime_t(const int& year, const int& month, const int& day, const  boost::shared_ptr<SUI::Time>& time)
    {
         static time_t result;
         struct tm time_struct;
         time_struct.tm_hour = time->getHour();
         time_struct.tm_min = time->getMinute();
         time_struct.tm_sec = 0;  // skipping seconds
         time_struct.tm_year = year - 1900;
         time_struct.tm_mon = month - 1;
         time_struct.tm_mday = day;
         time_struct.tm_isdst = 0;
         result = timegm(&time_struct);

         return result;
    }
};
}  //  namespace IGSxGUI
#endif  // IGSXGUIXDATETIME_HPP
