/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADT.hpp
| Author       : Venugopal S
| Description  : Header file for ADT
|
| ! \file        IGSxGUIxADT.hpp
| ! \brief       Header file for ADT
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADT_HPP
#define IGSXGUIXADT_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ADT
{
 public:
    explicit ADT(const IGSxADT::MetaDescription &metaDescription);
    virtual ~ADT();

    std::string getName() const;
    std::string getDescription() const;
    std::string getSubsystem() const;
    std::string getHtmlFile() const;

    bool start() const;

 private:
    ADT(ADT const &);
    ADT& operator=(ADT const &);

    std::string m_name;
    std::string m_subsystem;
    std::string m_description;
    std::string m_htmlFile;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADT_HPP
