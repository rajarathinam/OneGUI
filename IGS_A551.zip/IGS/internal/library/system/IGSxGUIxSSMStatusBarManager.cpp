/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMStatusBarManager.cpp
| Author       : Saket K
| Description  : Implementation of SSM Statusbar manager
|
| ! \file        IGSxGUIxSSMStatusBarManager.cpp
| ! \brief       Implementation of Statusbar manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUILabel.h>
#include <IGSxGUIxSSMStatusBarManager.hpp>
#include <boost/bind.hpp>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIGroupBox.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string UNKNOWN_TEXT = "UNKNOWN";
const std::string UNKNOWN_TIME = "<Unknown>";
const std::string ELAPSED_TIME_TEXT = "00:00:00";


IGSxGUI::SSMStatusBarManager::SSMStatusBarManager(StateList &states) :
    mStates(states),
    mTransitionTimer(SUI::Timer::createTimer()),
    mTransitionStartTime(SUI::Time::createTime())
{
    mTransitionTimer->timeout = boost::bind(&SSMStatusBarManager::onTransitionTimeout, this);
}

void IGSxGUI::SSMStatusBarManager::initWidgets(SUI::GroupBox* gbxCurrentState,
                                        SUI::GroupBox* gbxTransitionState,
                                        SUI::Label* lblCurrentStateText,
                                        SUI::Label* lblFromText,
                                        SUI::Label* lblToText,
                                        SUI::Label* lblStartTimeText,
                                        SUI::Label* lblExpectedDurationText,
                                        SUI::Label* lblElapsedTimeText)
{
    mGbxCurrentState = gbxCurrentState;
    mGbxTransitionState = gbxTransitionState;
    mlblCurrentStateText = lblCurrentStateText;
    mlblFromText = lblFromText;
    mlblToText = lblToText;
    mlblStartTimeText = lblStartTimeText;
    mlblExpectedDurationText = lblExpectedDurationText;
    mlblElapsedTimeText = lblElapsedTimeText;
}

void IGSxGUI::SSMStatusBarManager::show(IGSxGUI::TransitionData &activeTransition)
{

    if(activeTransition.From == activeTransition.To)
    {

        if(activeTransition.TransitionResult == IGSxSSM::ERROR || activeTransition.FunctionResult == IGSxSSM::FUNCTION_ERROR)
        {
            mlblCurrentStateText->setText(UNKNOWN_TEXT);
        }
        else if(activeTransition.TransitionResult == IGSxSSM::OK)
        {
            mlblCurrentStateText->setText(getStateText(activeTransition.From));
        }
        else if(activeTransition.TransitionResult == IGSxSSM::ABORTED)
        {
            mlblCurrentStateText->setText(UNKNOWN_TEXT);
        }
        mGbxTransitionState->hide();
        mGbxCurrentState->show();
    }
    else
    {
        mElapsedDurationSeconds = 0;
        mTransitionTimer->start(1000);
        mExpectedDurationSeconds = activeTransition.ExpectedDuration / 1000;

        mlblElapsedTimeText->setText(ELAPSED_TIME_TEXT);
        mlblFromText->setText(getStateText(activeTransition.From));
        mlblToText->setText(getStateText(activeTransition.To));

        mTransitionStartTime = SUI::Time::createTime();
        mlblStartTimeText->setText(mTransitionStartTime->toString());

        updateExpectedDuration(activeTransition.ExpectedDuration);
        mGbxTransitionState->show();
        mGbxCurrentState->hide();
    }

}

void IGSxGUI::SSMStatusBarManager::updateExpectedDuration(const int expectedDuration)
{
    boost::shared_ptr<SUI::Time> expectedTime(SUI::Time::createTime());
    expectedTime->addMSecs(expectedDuration);
    boost::shared_ptr<SUI::Time> currentTime(SUI::Time::createTime());
    boost::shared_ptr<SUI::Time> remainingTime(SUI::Time::createTime());
    remainingTime->setHMS(expectedTime->getHour() - currentTime->getHour(),
                          expectedTime->getMinute() - currentTime->getMinute(),
                          expectedTime->getSecond() - currentTime->getSecond());

    std::string expectedDurationText = remainingTime->toString();
    if(expectedDurationText == "") {
        expectedDurationText = UNKNOWN_TIME;
    }

    mlblExpectedDurationText->setText(expectedDurationText);
}

void IGSxGUI::SSMStatusBarManager::setActive(bool bActive)
{
    if(!bActive)
    {
        mTransitionTimer->stop();
    }
}

void IGSxGUI::SSMStatusBarManager::onTransitionTimeout()
{
     if( mElapsedDurationSeconds == mExpectedDurationSeconds )
     {
         mTransitionTimer->stop();
     }
     else
     {
         boost::shared_ptr<SUI::Time> currentTime(SUI::Time::createTime());
         boost::shared_ptr<SUI::Time> remainingTime(SUI::Time::createTime());
         remainingTime->setHMS(currentTime->getHour() - mTransitionStartTime->getHour(),
                               currentTime->getMinute() - mTransitionStartTime->getMinute(),
                               currentTime->getSecond() - mTransitionStartTime->getSecond());

         std::string elapsedTimeText = remainingTime->toString();
         if(elapsedTimeText == "") {
             elapsedTimeText = UNKNOWN_TIME;
         }
         mlblElapsedTimeText->setText(elapsedTimeText);
     }

     ++mElapsedDurationSeconds;
}


std::string IGSxGUI::SSMStatusBarManager::getStateText(const IGSxSSM::StateIDType& stateId) const
{
    std::string stateName;
    for(size_t index = 0; index < mStates.size(); ++index)
    {
        if (mStates[index]->getId() == stateId)
        {
           stateName = mStates[index]->getStateName();
           std::replace(stateName.begin(), stateName.end(), '\n', ' ' );
           break;
        }
    }
    return stateName;
}
