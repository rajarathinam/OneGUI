/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.cpp
| Author       : Raja
| Description  : Machine constants manager Implementation
|
| ! \file        IGSxGUIxMachineconstantsManager.cpp
| ! \brief       Machine constants Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <iomanip>
#include <boost/bind.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/find.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include "IGSxPAR.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

namespace IGSxGUI
{

ParameterValue::~ParameterValue()
{ }

template<typename TYPE>
class ParameterValueType: public IGSxGUI::ParameterValue
{
private:
    TYPE m_value;

public:
    explicit ParameterValueType<TYPE>(TYPE defaultValue) : m_value(defaultValue)
    { }

    virtual void FromString(std::string strValue)
    {
        m_value = boost::lexical_cast<TYPE>(strValue);
    }

    virtual std::string ToString()
    {
        return boost::lexical_cast<std::string>(m_value);
    }

protected:
    TYPE getValue() const { return m_value; }
};


class ParameterValueInt: public ParameterValueType<int>
{
public:
    ParameterValueInt() : ParameterValueType<int>(0)
    { }

    explicit ParameterValueInt(int value) : ParameterValueType<int>(value)
    { }

    virtual int ToInt()
    {
        return getValue();
    }

    virtual IGSxGUI::ParameterValue* CreateCopy()
    {
        return new ParameterValueInt(getValue());
    }
};

class ParameterValueUint: public ParameterValueType<unsigned int>
{
public:
    ParameterValueUint() : ParameterValueType<unsigned int>(0)
    { }

    explicit ParameterValueUint(unsigned int value) : ParameterValueType<unsigned int>(value)
    { }

    virtual unsigned int ToUint()
    {
        return getValue();
    }

    virtual ParameterValue* CreateCopy()
    {
        return new ParameterValueUint(getValue());
    }
};


class ParameterValueDouble: public ParameterValueType<double>
{
public:
    ParameterValueDouble() : ParameterValueType<double>(0.0)
    { }

    explicit ParameterValueDouble(double value) : ParameterValueType<double>(value)
    { }

    virtual double ToDouble()
    {
        return getValue();
    }

    virtual ParameterValue* CreateCopy()
    {
        return new ParameterValueDouble(getValue());
    }
};

class ParameterValueBool: public ParameterValue
{
private:
    bool m_value;

public:
    ParameterValueBool() : m_value(false)
    { }

    explicit ParameterValueBool(bool value) : m_value(value)
    { }

    virtual void FromString(std::string strValue)
    {
        m_value = boost::lexical_cast<int>(strValue) == 1;
    }

    virtual std::string ToString()
    {
        return (m_value ? "True (1)" : "False (0)");
    }

    virtual bool ToBool()
    {
        return m_value;
    }

    virtual ParameterValue* CreateCopy()
    {
        return new ParameterValueBool(m_value);
    }
};

class ParameterValueFloatArray: public ParameterValue
{
private:
    std::vector<double> m_value;
    void adjustDoublePrecision(std::string &paramvalue);

public:
    ParameterValueFloatArray()
    { }

    explicit ParameterValueFloatArray(const std::vector<double>& value) : m_value(value)
    {
    }

    ParameterValueFloatArray(const std::vector<double>& value, int targetSize)
    {
        for (size_t i = 0; i < value.size() && i < static_cast<size_t>(targetSize); ++i)
        {
            m_value.push_back(value.at(i));
        }
    }

    virtual void FromString(std::string strValue)
    {
        std::vector<std::string> values;
        boost::split(values, strValue, boost::is_any_of(","));
        m_value.erase(m_value.begin(), m_value.end());

        for (unsigned int i = 0; i < values.size(); ++i)
        {
            std::string value = values[i];
            double val = boost::lexical_cast<double>(value);
            m_value.push_back(val);
        }
    }

    virtual std::string ToString()
    {
        if (m_value.empty())
        {
            return "";
        }

        std::string first = boost::lexical_cast<std::string>(m_value[0]);
        adjustDoublePrecision(first);
        std::string result = first;
        for (int i = 1; i < static_cast<int>(m_value.size()); ++i)
        {
            std::string tmp = boost::lexical_cast<std::string>(m_value[i]);
            adjustDoublePrecision(tmp);
            result += "," + tmp;
        }
        return result;
    }

    virtual std::vector<double> ToFloatarray()
    {
        return m_value;
    }

    virtual ParameterValue* CreateCopy()
    {
        return new ParameterValueFloatArray(m_value);
    }

    virtual int getItemCount() { return static_cast<int>(m_value.size()); }
};

void ParameterValueFloatArray::adjustDoublePrecision(std::string& paramvalue) {
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1,1);
        }
    }
}

} // namespace IGSxGUI


namespace
{

// https://stackoverflow.com/questions/3152241/case-insensitive-stdstring-find
template<typename charT>
struct my_equal {
    explicit my_equal( const std::locale& loc ) : loc_(loc) {}
    bool operator()(charT ch1, charT ch2)
    {
        return std::toupper(ch1, loc_) == std::toupper(ch2, loc_);
    }
private:
    const std::locale& loc_;
};

// contains substring (case insensitive)
template<typename T>
bool contains_substr( const T& strTarget, const T& strToSearch)
{
    const std::locale& loc = std::locale();
    typename T::const_iterator it = std::search( strTarget.begin(), strTarget.end(),
                                                 strToSearch.begin(), strToSearch.end(), my_equal<typename T::value_type>(loc) );
    return  it != strTarget.end();
}

// helper classes
class Visitor : public IGSxPAR::IParameterTypeVisitor
{
private:
    std::vector<IGSxGUI::ParameterData>* m_parameterData;

public:
    explicit Visitor(std::vector<IGSxGUI::ParameterData>* parameterData)
    {
        m_parameterData = parameterData;
    }

    virtual void visit(const IGSxPAR::IntType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.name(), type.config().unit(),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueInt(type.value())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueInt(type.config().def())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueInt(type.config().min())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueInt(type.config().max())),
                                                          !type.writeAccess(), IGSxGUI::TYPE_int));
    }

    virtual void visit(const IGSxPAR::UIntType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.name(), type.config().unit(),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueUint(type.value())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueUint(type.config().def())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueUint(type.config().min())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueUint(type.config().max())),
                                                          !type.writeAccess(), IGSxGUI::TYPE_uint));
    }

    virtual void visit(const IGSxPAR::BoolType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.value().name(), "",
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueBool(type.value().value())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueBool(type.def())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueBool()),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueBool()),
                                                          !type.writeAccess(), IGSxGUI::TYPE_boolean));
    }

    virtual void visit(const IGSxPAR::FloatType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.name(), type.config().unit(),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.value())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.config().def())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.config().min())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.config().max())),
                                                          !type.writeAccess(), IGSxGUI::TYPE_double));
    }

    virtual void visit(const IGSxPAR::FloatArrayType& type )
    {
        m_parameterData->push_back(IGSxGUI::ParameterData(type.value().name(), type.config().unit(),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueFloatArray(type.value().value())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueFloatArray(type.config().def(), type.config().maxSize())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.config().min())),
                                                          IGSxGUI::ParameterValuePtr(new IGSxGUI::ParameterValueDouble(type.config().max())),
                                                          !type.writeAccess(), IGSxGUI::TYPE_floatarray, type.config().labels(),
                                                          type.config().minSize(), type.config().maxSize()));
    }
};

class UpdateVisitor : public IGSxPAR::IValueVisitor
{
private:
    IGSxGUI::ParameterData* m_parameterData;

public:
    explicit UpdateVisitor(IGSxGUI::ParameterData* parameterData)
    {
        m_parameterData = parameterData;
    }

    virtual void visit( const IGSxPAR::IntValue&  value)
    {
        m_parameterData->changeValue(boost::lexical_cast<std::string>(value.value()));
        m_parameterData->resetPreviousValue();
    }

    virtual void visit( const IGSxPAR::UIntValue&  value)
    {
        m_parameterData->changeValue(boost::lexical_cast<std::string>(value.value()));
        m_parameterData->resetPreviousValue();
    }

    virtual void visit( const IGSxPAR::FloatValue& value)
    {
        m_parameterData->changeValue(boost::lexical_cast<std::string>(value.value()));
        m_parameterData->resetPreviousValue();
    }

    virtual void visit( const IGSxPAR::BoolValue&  value)
    {
        m_parameterData->changeValue(boost::lexical_cast<std::string>(value.value()));
        m_parameterData->resetPreviousValue();
    }

    virtual void visit( const IGSxPAR::FloatArrayValue&  value)
    {
        std::string valuesAsString;
        if (!value.value().empty())
        {
            valuesAsString = boost::lexical_cast<std::string>(value.value().at(0));
            for (int i = 1; i < static_cast<int>(value.value().size()); ++i)
            {
                valuesAsString += "," + boost::lexical_cast<std::string>(value.value().at(i));
            }
        }

        m_parameterData->changeValue(valuesAsString);
        m_parameterData->resetPreviousValue();
    }
};

IGSxGUI::MachineconstantsManager* gMachineconstantsManager;

void onParamUpdated(const IGSxPAR::IValuePtrVector& values)
{
    if (gMachineconstantsManager != NULL) {
        for (int i = 0; i < static_cast<int>(values.size()); ++i) {
            IGSxGUI::ParameterData* parameterData = gMachineconstantsManager->findParameter(values[i]->name());
            if (parameterData != NULL) {
                UpdateVisitor visitor(parameterData);
                values[i]->accept(visitor);
            }
        }
        if (IGSxGUI::MachineconstantsManager::m_callback != NULL) {
            IGSxGUI::MachineconstantsManager::m_callback();
        }
    }
}


}  // namespace




IGSxGUI::Node::Node(std::string name, int level, Node* parentNode) :
    m_name(name), m_level(level), m_parentNode(parentNode)
{
}

IGSxGUI::Node::~Node()
{
    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i) {
        delete m_childNodes[i];
    }
    m_childNodes.clear();
}


const std::string IGSxGUI::Node::getName() const
{
    return m_name;
}

IGSxGUI::Node* IGSxGUI::Node::getParentNode()
{
    return m_parentNode;
}

IGSxGUI::Node* IGSxGUI::Node::findChildNode(const std::string& name)
{
    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i) {
        if (m_childNodes[i]->getName() == name) {
            return m_childNodes[i];
        }
    }
    return NULL;
}

IGSxGUI::Node* IGSxGUI::Node::addChildNode(const std::string& name)
{
    m_childNodes.push_back(new Node(name, m_level + 1, this));
    return m_childNodes[m_childNodes.size()-1];
}

void IGSxGUI::Node::addParameter(IGSxGUI::ParameterData* parameter)
{
    m_parameters.push_back(parameter);
}

std::vector<IGSxGUI::ParameterData*>& IGSxGUI::Node::getParameters()
{
    return m_parameters;
}

void IGSxGUI::Node::getChildNodeTitles(std::vector<std::string>* targetList )
{
    targetList->clear();
    for (int i = 0; i < static_cast<int>(m_childNodes.size()); ++i) {
        targetList->push_back(m_childNodes[i]->getName());
    }
}

int IGSxGUI::ParameterData::treeLevel = 0;



IGSxGUI::ParameterData::ParameterData(const std::string& name, const std::string& unit, boost::shared_ptr<ParameterValue> currentValue,
                                      boost::shared_ptr<ParameterValue> defaultValue, ParameterValuePtr minValue, ParameterValuePtr maxValue,
                                      bool readOnly, IGSxGUI::ITEMTYPE type) :
    m_name(name), m_unit(unit), m_defaultValue(defaultValue), m_currentValue(currentValue), m_previousValue(currentValue->CreateCopy()),
    m_minValue(minValue), m_maxValue(maxValue), m_itemType(type), m_updated(false), m_readOnly(readOnly), m_minValueCount(1), m_maxValueCount(1)
{
    ComputeComponentIndexes();
}

IGSxGUI::ParameterData::ParameterData(const std::string& name, const std::string& unit, boost::shared_ptr<ParameterValue> currentValue,
                                      boost::shared_ptr<ParameterValue> defaultValue, ParameterValuePtr minValue, ParameterValuePtr maxValue,
                                      bool readOnly, IGSxGUI::ITEMTYPE type,
                                      const std::vector<std::string>& labels, int minValueCount, int maxValueCount) :
    m_name(name), m_unit(unit), m_defaultValue(defaultValue), m_currentValue(currentValue), m_previousValue(currentValue->CreateCopy()),
    m_minValue(minValue), m_maxValue(maxValue), m_itemType(type), m_updated(false), m_readOnly(readOnly), m_labels(labels), m_minValueCount(minValueCount), m_maxValueCount(maxValueCount)
{
    ComputeComponentIndexes();

    // make sure the number of labels is equal to the max. number of values
    if (static_cast<int>(m_labels.size()) > m_maxValueCount)
    {
        m_labels.erase(m_labels.begin() + m_maxValueCount, m_labels.end());
    }
    else
    {
        while (static_cast<int>(m_labels.size()) < m_maxValueCount)
        {
            m_labels.push_back("");
        }
    }
}

const std::vector<std::string>& IGSxGUI::ParameterData::getLabels() const
{
    return m_labels;
}

IGSxGUI::ParameterData* IGSxGUI::ParameterData::getPtr()
{
    return this;
}


const std::string& IGSxGUI::ParameterData::getName() const
{
    return m_name;
}


std::string IGSxGUI::ParameterData::getDisplayName() const
{
    if (treeLevel <= 0 || static_cast<int>(m_componentIndexes.size()) == 0) {
        if (m_unit != "") {
            return m_name + " (" + m_unit + ")";
        } else {
            return m_name;
        }
    }
    if (treeLevel >= static_cast<int>(m_componentIndexes.size())) {
        if (m_unit != "") {
            return m_name.substr(m_componentIndexes[m_componentIndexes.size() - 1] + 1) + " (" + m_unit + ")";
        } else {
            return m_name.substr(m_componentIndexes[m_componentIndexes.size() - 1] + 1);
        }
    }
    if (m_unit != "") {
        return m_name.substr(m_componentIndexes[treeLevel - 1] + 1) + " (" + m_unit + ")";
    } else {
        return m_name.substr(m_componentIndexes[treeLevel - 1] + 1);
    }
}


std::string IGSxGUI::ParameterData::getComponent(int index) const
{
    if (index < 0 || index >= static_cast<int>(m_componentIndexes.size())) {
        return "";
    } else if (index == 0) {
        return m_name.substr(0, m_componentIndexes[0]);
    } else {
        return m_name.substr(m_componentIndexes[index - 1] + 1, m_componentIndexes[index] - m_componentIndexes[index - 1] - 1);
    }
}


int IGSxGUI::ParameterData::getComponentCount() const
{
    return m_componentIndexes.size();
}


void IGSxGUI::ParameterData::changeValue(std::string newValue)
{
    m_currentValue->FromString(newValue);
    m_updated = true;
}


void IGSxGUI::ParameterData::revertValue()
{
    m_currentValue = IGSxGUI::ParameterValuePtr(m_previousValue->CreateCopy());
    m_updated = false;
}


bool IGSxGUI::ParameterData::isReadOnly() const
{
    return m_readOnly;
}


bool IGSxGUI::ParameterData::isUpdated() const
{
    return m_updated;
}

void IGSxGUI::ParameterData::setSelected(bool flag)
{
    m_selected = flag;
}
bool IGSxGUI::ParameterData::isSelected() const
{

    return m_selected;
}

void IGSxGUI::ParameterData::resetUpdateFlag()
{
    m_updated = false;
}

boost::shared_ptr<IGSxGUI::ParameterValue> IGSxGUI::ParameterData::getCurrentValue() const
{
    return m_currentValue;
}

boost::shared_ptr<IGSxGUI::ParameterValue> IGSxGUI::ParameterData::getPreviousValue() const
{
    return m_previousValue;
}

boost::shared_ptr<IGSxGUI::ParameterValue> IGSxGUI::ParameterData::getDefaultValue() const
{
    return m_defaultValue;
}

void IGSxGUI::ParameterData::resetPreviousValue()
{
    m_previousValue = IGSxGUI::ParameterValuePtr(m_currentValue->CreateCopy());
    m_updated = false;
}

IGSxGUI::ITEMTYPE IGSxGUI::ParameterData::getValueType()
{
    return m_itemType;
}

boost::shared_ptr<IGSxGUI::ParameterValue> IGSxGUI::ParameterData::getMinValue() const
{
    return m_minValue;
}

boost::shared_ptr<IGSxGUI::ParameterValue> IGSxGUI::ParameterData::getMaxValue() const
{
    return m_maxValue;
}

int IGSxGUI::ParameterData::getMinValueCount() const
{
    return m_minValueCount;
}

int IGSxGUI::ParameterData::getMaxValueCount() const
{
    return m_maxValueCount;
}

int IGSxGUI::ParameterData::getActualValueCount() const
{
    return m_minValueCount == m_maxValueCount ? m_maxValueCount : getCurrentValue()->getItemCount();
}

void IGSxGUI::ParameterData::ComputeComponentIndexes()
{
    for (size_t i = 0; i < m_name.size(); ++i) {
        if (m_name[i] == '/') {
            m_componentIndexes.push_back(i);
        }
    }
}

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::ParametersChangedCallback IGSxGUI::MachineconstantsManager::m_callback = NULL;


IGSxGUI::MachineconstantsManager::MachineconstantsManager()
{
    lastHistoryUpdateTime = time(0);
    time_t startTime = lastHistoryUpdateTime - (10000 * 24 * 60 * 60); // 10 000 days ago
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::ParameterChangeHistoryVector history;
    inst->GetChangeHistory(startTime, lastHistoryUpdateTime, history);
    for (size_t i = 0; i <  history.size(); ++i) {
        IGSxPAR::ParameterChangeHistory temp = history[i];
        ParameterHistory paramHisdata(temp.parameter_name(), temp.time_of_change(), temp.changed_by(), temp.reason(), temp.old_value(), temp.new_value(),false );
        m_history.push_back(paramHisdata);
    }
}

IGSxGUI::MachineconstantsManager::~MachineconstantsManager()
{
    if (m_rootNode != NULL) {
        delete m_rootNode;
    }
    gMachineconstantsManager = NULL;
}
void IGSxGUI::MachineconstantsManager::registerToParameterUpdated(IGSxGUI::ParametersChangedCallback cb)
{
    IGSxGUI::MachineconstantsManager::m_callback = cb;
}
void IGSxGUI::MachineconstantsManager::unSubscribeToParameterUpdated()
{
    IGSxPAR::PAR::getInstance()->unsubscribeValuesChanged();
}

void IGSxGUI::MachineconstantsManager::subscribeToParameterUpdated()
{
    IGSxPAR::PAR::getInstance()->subscribeValuesChanged(boost::bind(&onParamUpdated, _1));
}

void IGSxGUI::MachineconstantsManager::initialize()
{
    IGSxPAR::PAR::getInstance()->subscribeValuesChanged(boost::bind(&onParamUpdated, _1));
    createTableData();
    gMachineconstantsManager = this;
}

void IGSxGUI::MachineconstantsManager::createTableData()
{
    m_tabledata.clear();
    std::string filter = "^.+$"; // Regular expression for all strings with at least one character
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::ParameterTypePtrVector parameters;
    inst->Read(filter, parameters);
    Visitor visitor(&m_tabledata);
    for (int i = 0;  i < static_cast<int>(parameters.size()); ++i) {
        IGSxPAR::ParameterTypePtr parameter = parameters[i];
        parameter->accept(visitor);
    }
    m_rootNode = new IGSxGUI::Node("Parameters", 0, NULL);
    m_currentNode = m_rootNode;
    m_breadCrumPath.clear();
    m_breadCrumPath.push_back(m_rootNode->getName());
    for (int i = 0; i <  static_cast<int>(m_tabledata.size()); ++i) {
        registerNodes(m_tabledata[i].getPtr());
    }
}

void IGSxGUI::MachineconstantsManager::registerNodes(ParameterData* parameter)
{
    Node* parentNode = m_rootNode;
    parameter->setSelected(false);
    parentNode->addParameter(parameter);
    for (int i = 0; i < parameter->getComponentCount(); ++i) {
        std::string title = parameter->getComponent(i);
        Node* childNode = parentNode->findChildNode(title);
        if (childNode == NULL) {
            childNode = parentNode->addChildNode(title);
        }
        childNode->addParameter(parameter);
        parentNode = childNode;
    }
}

int IGSxGUI::MachineconstantsManager::getParameterCount()
{
    return static_cast<int>(m_currentNode->getParameters().size());
}

std::vector<IGSxGUI::ParameterData*> IGSxGUI::MachineconstantsManager::getParameterData()
{
    return m_currentNode->getParameters();
}

std::vector<IGSxGUI::ParameterData*> IGSxGUI::MachineconstantsManager::getAllParameterData()
{
    return m_rootNode->getParameters();
}

IGSxGUI::ParameterData* IGSxGUI::MachineconstantsManager::findParameter(const std::string& name)
{
    if (name.empty()) {
        return NULL;
    }
    std::string tmpname = name;
    size_t pos = tmpname.find('(');
    if (pos != std::string::npos) {
        tmpname.erase(pos - 1, tmpname.size());
    }
    std::vector<IGSxGUI::ParameterData>::iterator it = std::find_if(m_tabledata.begin(), m_tabledata.end(), find_parameter(tmpname));
    return (it != m_tabledata.end()) ? it->getPtr() : NULL;
}

void IGSxGUI::MachineconstantsManager::saveUpdatedParameters(const std::string& userId, const std::string& reason, std::vector<std::string>& failedParameterNames)
{
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::TransactionInfo transactionInfo(userId, reason);
    IGSxPAR::IValuePtrVector values;
    for (size_t i = 0; i < m_tabledata.size(); ++i) {
        if (m_tabledata.at(i).isUpdated()) {
            IGSxGUI::ITEMTYPE  type= m_tabledata.at(i).getValueType();
            switch (type) {
            case IGSxGUI::TYPE_int:
                values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::IntValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue()->ToInt())));
                break;
            case IGSxGUI::TYPE_uint:
                values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::UIntValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue()->ToUint())));
                break;
            case IGSxGUI::TYPE_double:
                values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::FloatValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue()->ToDouble())));
                break;
            case IGSxGUI::TYPE_floatarray:
                values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::FloatArrayValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue()->ToFloatarray())));
                break;
            case IGSxGUI::TYPE_boolean:
                values.push_back(boost::shared_ptr<IGSxPAR::IValue>(new IGSxPAR::BoolValue(m_tabledata.at(i).getName(), m_tabledata.at(i).getCurrentValue()->ToBool())));
                break;
            }
        }
    }
    IGSxPAR::StringVectorType failedParameters;
    inst->Write(transactionInfo, values, failedParameters);

    for (int i = 0; i < static_cast<int>(failedParameters.size()); ++i)
    {
        failedParameterNames.push_back(failedParameters[i]);
    }
    for (size_t i = 0; i < m_tabledata.size(); ++i) {
        if (m_tabledata.at(i).isUpdated()
                && std::find(failedParameterNames.begin(), failedParameterNames.end(), m_tabledata.at(i).getName()) == failedParameterNames.end())
        {
            m_tabledata.at(i).resetUpdateFlag();
        }
    }
}

void IGSxGUI::MachineconstantsManager::cancelUpdatedParameters()
{
    for (size_t i = 0; i < m_tabledata.size(); ++i) {
        if (m_tabledata.at(i).isUpdated()) {
            m_tabledata.at(i).revertValue();
        }
    }
}


int IGSxGUI::MachineconstantsManager::searchForParameters(const std::string& textToSearch, std::vector<ParameterData*>*  matchedparameters)
{
    matchedparameters->clear();
    if (textToSearch.empty()) {
        return 0;
    }
    int count = 0;
    for (int i = 0; i < static_cast<int>(m_currentNode->getParameters().size()); ++i) {
        if (contains_substr(m_currentNode->getParameters()[i]->getDisplayName(), textToSearch)) {
            ++count;
            matchedparameters->push_back(m_currentNode->getParameters()[i]);
        }
    }
    return count;
}

void IGSxGUI::MachineconstantsManager::getChildNodeTitles(std::vector<std::string>* childNodeTitles)
{
    m_currentNode->getChildNodeTitles(childNodeTitles);
}

void IGSxGUI::MachineconstantsManager::navigateToChild(const std::string& childNodeTitle)
{
    Node* childNode = m_currentNode->findChildNode(childNodeTitle);
    if (childNode != NULL) {
        m_currentNode = childNode;
        m_breadCrumPath.push_back(m_currentNode->getName());
        IGSxGUI::ParameterData::treeLevel++;
    }
}

void IGSxGUI::MachineconstantsManager::navigateBack()
{
    if (m_currentNode->getParentNode() != NULL) {
        m_currentNode = m_currentNode->getParentNode();
        m_breadCrumPath.erase(m_breadCrumPath.begin() + m_breadCrumPath.size() - 1);
        IGSxGUI::ParameterData::treeLevel--;
    }
}

void IGSxGUI::MachineconstantsManager::navigateToBreadCrum(const std::string& breadCrumTitle)
{
    if (breadCrumTitle == "Parameters") {
        m_currentNode = m_rootNode;
        m_breadCrumPath.clear();
        m_breadCrumPath.push_back(m_rootNode->getName());
        IGSxGUI::ParameterData::treeLevel = 0;
        return;
    }
    Node*  parentNode = m_currentNode->getParentNode();
    while (parentNode != NULL) {
        if (parentNode->getName() == breadCrumTitle) {
            m_currentNode = parentNode;
            while (m_breadCrumPath[m_breadCrumPath.size() - 1] != breadCrumTitle && m_breadCrumPath.size() > 1) {
                m_breadCrumPath.erase(m_breadCrumPath.begin() + m_breadCrumPath.size() - 1);
                IGSxGUI::ParameterData::treeLevel--;
            }
            return;
        }
        parentNode = parentNode->getParentNode();
    }
}

const std::vector<std::string>& IGSxGUI::MachineconstantsManager::getBreadCrumTitles()
{
    return m_breadCrumPath;
}

std::string IGSxGUI::MachineconstantsManager::getCurrentNodeName()
{
    return (m_currentNode->getName());
}

void IGSxGUI::MachineconstantsManager::getHistory(ParameterHistoryVector& outHistory)
{
    for (size_t i = 0; i <  m_history.size(); ++i)
    {
        outHistory.push_back(m_history[i]);
    }

    time_t t_start = lastHistoryUpdateTime;
    lastHistoryUpdateTime = time(0);
    IGSxPAR::PAR* inst = IGSxPAR::PAR::getInstance();
    IGSxPAR::ParameterChangeHistoryVector history;
    inst->GetChangeHistory(t_start, lastHistoryUpdateTime, history);
    for (size_t i = 0; i <  history.size(); ++i) {
        IGSxPAR::ParameterChangeHistory temp = history[i];
        ParameterHistory paramHisdata(temp.parameter_name(), temp.time_of_change(), temp.changed_by(), temp.reason(), temp.old_value(), temp.new_value(), false );

        // keep the old history for the next request
        m_history.push_back(paramHisdata);
        outHistory.push_back(paramHisdata);
    }
}

void IGSxGUI::Node::sortasc() {
    std::sort(m_parameters.begin(), m_parameters.end(), ascOrder());
}

void IGSxGUI::MachineconstantsManager::sortParamsAscending() {
    m_rootNode->sortasc();
    m_currentNode->sortasc();
}

void IGSxGUI::Node::sortdes() {
    std::sort(m_parameters.begin(), m_parameters.end(), desOrder());
}

void IGSxGUI::MachineconstantsManager::sortParamsDescending() {
    m_rootNode->sortdes();
    m_currentNode->sortdes();
}
