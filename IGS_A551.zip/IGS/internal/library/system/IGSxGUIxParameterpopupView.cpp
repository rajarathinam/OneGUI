/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Parameterpopup view
|
| ! \file        IGSxGUIxParameterpopupView.cpp
| ! \brief       Implementation of Parameterpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <FWQxCore/SUIResourcePath.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/regex.hpp>
#include <string>
#include <iomanip>
#include <vector>
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMoc_ParameterpopupView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::ParameterpopupView::BUTTON_SIZE = 24;
const int IGSxGUI::ParameterpopupView::MAXIMUM_DOUBLE_PRECISION = 8;

const std::string IGSxGUI::ParameterpopupView::PARAMETERPOPUPVIEW_LOAD_FILE = "IGSxGUIxParameterPopup.xml";
const std::string IGSxGUI::ParameterpopupView::STRING_PARAMETERPOPUPVIEW_SHOWN = "ParameterPopupView is Shown.";
const std::string IGSxGUI::ParameterpopupView::radiobutton_12px_normal_fill = SUI::ResourcePath::getResourceFile("radiobutton_12px_normal_fill.png");
const std::string IGSxGUI::ParameterpopupView::radiobutton_12px_normal = SUI::ResourcePath::getResourceFile("radiobutton_12px_normal.png");

IGSxGUI::ParameterpopupView::ParameterpopupView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager):
    sui(new SUI::ParameterpopupView)
{
    sui->setupSUI(PARAMETERPOPUPVIEW_LOAD_FILE.c_str());
    m_pMachineconstantsManager = pMachineconstantsManager;
}


IGSxGUI::ParameterpopupView::~ParameterpopupView()
{
}

void IGSxGUI::ParameterpopupView::show(int booltype)
{
    IGSxGUI::Util::setDialogHeight(sui->dialog, 251);
    IGSxGUI::Util::setDialogWidth(sui->dialog, 446);

    std::vector<SUI::Widget*> widgetVector;
    widgetVector.push_back(sui->rbtnParamTrue);
    widgetVector.push_back(sui->rbtnParamFalse);
    IGSxGUI::Util::boolDialogInstallEventFileter(widgetVector);

    IGSxGUI::Util::setAwesome(sui->btnSingleDialogLineEditClear, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
    sui->btnPopUpdate->setEnabled(false);
    if (booltype != 0) {
        sui->lneValue->setVisible(false);
        sui->btnSingleDialogLineEditClear->setVisible(false);
        sui->gbxParameterRadio->setVisible(true);
        sui->lblDefaultValue->setGeometry(20, 155, 100, 30);
        sui->lblDefaultValueNumber->setGeometry(106, 155, 60, 30);
    } else {
        sui->lneValue->setVisible(true);
        sui->btnSingleDialogLineEditClear->setVisible(true);
        sui->gbxParameterRadio->setVisible(false);
        sui->lblDefaultValue->setGeometry(237, 94, 100, 30);
        sui->lblDefaultValueNumber->setGeometry(320, 94, 60, 30);
    }
    init();
    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    if (booltype == 0) {
        sui->lneValue->setFocus();
    }
    if (sui->rbtnParamTrue->isChecked()) {
        m_radioButtonValue = "True (1)";
    } else {
        m_radioButtonValue = "False (0)";
    }
    IGSxGUI::Util::executeDialog(sui->dialog);
    IGS_INFO(STRING_PARAMETERPOPUPVIEW_SHOWN);
}

void IGSxGUI::ParameterpopupView::init()
{
    SUI::Widget* lineEdit = sui->lneValue;
    IGSxGUI::Util::setEventFilterForParameterPopupDialog(lineEdit);

    IGSxGUI::Util::setWordWrap(sui->lblParameterName);
    IGSxGUI::Util::setWordWrap(sui->lblUnrecommendedValueDesc);
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#666666", BUTTON_SIZE);
    sui->btnClose->clicked = boost::bind(&ParameterpopupView::onCloseButtonPressed, this);
    sui->btnPopCancel->clicked = boost::bind(&ParameterpopupView::onCloseButtonPressed, this);
    sui->btnClose->hoverEntered = boost::bind(&ParameterpopupView::onCloseButtonHoverEntered, this);
    sui->btnClose->hoverLeft = boost::bind(&ParameterpopupView::onCloseButtonHoverLeft, this);
    sui->btnPopReset->clicked = boost::bind(&ParameterpopupView::onResetButtonPressed, this);
    sui->btnPopUpdate->clicked = boost::bind(&ParameterpopupView::onUpdatebuttonPressed, this);
    sui->lneValue->textChanged = boost::bind(&ParameterpopupView::onParamValueTextChanged, this, _1);
    sui->rbtnParamTrue->checkStateChanged = boost::bind(&ParameterpopupView::onRbtnChecked, this);
    sui->btnSingleDialogLineEditClear->clicked = boost::bind(&ParameterpopupView::clearLineEdit, this);
}

void IGSxGUI::ParameterpopupView::clearLineEdit()
{
    sui->lneValue->clearText();
    sui->lneValue->setFocus();
    sui->btnSingleDialogLineEditClear->setVisible(false);
}

void IGSxGUI::ParameterpopupView::onRbtnChecked()
{
    std::string name = sui->lblParameterName->getText();
    formatParamNameBack(name);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    std::string previousValue  = "";
    std::string currentValue  = "";
    if (parameterData != NULL) {
         previousValue = parameterData->getPreviousValue()->ToString();
         currentValue = parameterData->getCurrentValue()->ToString();
    }
    if (sui->rbtnParamTrue->isChecked()) {
        IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal_fill);
        IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal);
        m_radioButtonValue = "True (1)";
    } else {
        IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal_fill);
        IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal);
        m_radioButtonValue = "False (0)";
    }
    if ( (previousValue.compare(m_radioButtonValue) != 0) && (currentValue.compare(m_radioButtonValue) != 0)) {
        sui->btnPopUpdate->setEnabled(true);
    } else {
        sui->btnPopUpdate->setEnabled(false);
    }
}

void IGSxGUI::ParameterpopupView::onCloseButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#000080", BUTTON_SIZE);
}

void IGSxGUI::ParameterpopupView::onCloseButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#666666", BUTTON_SIZE);
}

void IGSxGUI::ParameterpopupView::onCloseButtonPressed()
{
    sui->gbxUnrecommendedValue->setVisible(false);
    sui->btnPopUpdate->setEnabled(false);
    sui->dialog->close();
}
void IGSxGUI::ParameterpopupView::onResetButtonPressed()
{
    sui->btnPopUpdate->setEnabled(false);
    sui->gbxUnrecommendedValue->setVisible(false);
    std::string value = sui->lblDefaultValueNumber->getText();
    if (sui->lneValue->isVisible()) {
        sui->lneValue->setText(value);
        sui->lneValue->setFocus();
        IGSxGUI::Util::selectLineEditText(sui->lneValue);
    } else {
        if (value == "True (1)") {
            sui->rbtnParamTrue->setChecked(true);
            IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal_fill);
            IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal);
        } else {
            sui->rbtnParamFalse->setChecked(true);
            IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal_fill);
            IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal);
        }
    }
}

void IGSxGUI::ParameterpopupView::onUpdatebuttonPressed()
{
    std::string name = getParameterName();
    std::string value = getParameterValue();
    if (validateText(value)) {
        m_valueChanged(name, value);
    }
}
boost::signals2::connection IGSxGUI::ParameterpopupView::registerForValueChanged(const IGSxGUI::ParameterpopupView::ValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}
void IGSxGUI::ParameterpopupView::setParameterName(const std::string& name)
{
    sui->lblParameterName->setText(name);
}
std::string IGSxGUI::ParameterpopupView::getParameterName() const
{
    return sui->lblParameterName->getText();
}
void IGSxGUI::ParameterpopupView::setParameterValue(const std::string& value, int booltype)
{
    if (booltype != 0) {
        if (value == "True (1)") {
            sui->rbtnParamTrue->setChecked(true);
            IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal_fill);
            IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal);
        } else {
            sui->rbtnParamFalse->setChecked(true);
            IGSxGUI::Util::setRadiobutonNormalCheckedStyle(sui->rbtnParamFalse, radiobutton_12px_normal_fill);
            IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(sui->rbtnParamTrue, radiobutton_12px_normal);
        }
    } else {
        sui->lneValue->setText(value);
    }
}
std::string IGSxGUI::ParameterpopupView::getParameterValue() const
{
    if (sui->lneValue->isVisible()) {
        return sui->lneValue->getText();
    } else {
        if (sui->rbtnParamTrue->isChecked()) {
            return "1";
        } else {
            return "0";
        }
    }
}
void IGSxGUI::ParameterpopupView::setParameterDefaultValue(const std::string& defaultvalue)
{
    sui->lblDefaultValueNumber->setText(defaultvalue);
}
std::string IGSxGUI::ParameterpopupView::getParameterDefaultValue() const
{
    return sui->lblDefaultValueNumber->getText();
}

void IGSxGUI::ParameterpopupView::close()
{
  sui->dialog->close();
}
void IGSxGUI::ParameterpopupView::setParent(SUI::Widget *parent)
{
    IGSxGUI::Util::setParent(sui->dialog, parent);
}

void IGSxGUI::ParameterpopupView::onParamValueTextChanged(const std::string& value)
{
    if (sui->lneValue->getText() != "") {
        sui->btnSingleDialogLineEditClear->setVisible(true);
    } else {
        sui->btnSingleDialogLineEditClear->setVisible(false);
    }
    sui->gbxUnrecommendedValue->setVisible(false);
    sui->lneValue->setStyleSheetClass("floatArrayLe");
    if (value != "") {
        std::string name = sui->lblParameterName->getText();
        formatParamNameBack(name);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
        if (parameterData != NULL) {
            IGSxGUI::ITEMTYPE it = parameterData->getValueType();
            switch (it) {
            case IGSxGUI::TYPE_int: {
                regularExpressionCheckInteger(value);
                int tempValue;
                try {
                    tempValue = boost::lexical_cast<int>(value);
                } catch (...) {
                    return;
                }
                int  previousValue =  (parameterData->getPreviousValue()->ToInt());
                int  currentValue =  (parameterData->getCurrentValue()->ToInt());
                if ((tempValue != currentValue) && (tempValue != previousValue)) {
                    sui->btnPopUpdate->setEnabled(true);
                }
            }
            break;
            case IGSxGUI::TYPE_uint: {
                regularExpressionCheckUnsignedInteger(value);
                uint tempValue;
                try {
                    tempValue = boost::lexical_cast<uint>(value);
                } catch (...) {
                    return;
                }
                uint  previousValue =  (parameterData->getPreviousValue()->ToUint());
                uint  currentValue =  (parameterData->getCurrentValue()->ToUint());
                if ((tempValue != currentValue) && (tempValue != previousValue)) {
                    sui->btnPopUpdate->setEnabled(true);
                } else {
                    sui->btnPopUpdate->setEnabled(false);
                }
            }
            break;
            case IGSxGUI::TYPE_double: {
                regularExpressionCheckDouble(value);
                double tempValue;
                try {
                    tempValue = boost::lexical_cast<double>(value);
                } catch (...) {
                    return;
                }
                double  currentValue =  (parameterData->getPreviousValue()->ToDouble());
                if (std::fabs(tempValue - currentValue) <= 0.01) {
                    sui->btnPopUpdate->setEnabled(true);
                }
            }
            break;
            default:
                break;
            }
        }
    } else {
        sui->btnPopUpdate->setEnabled(false);
    }
}

bool IGSxGUI::ParameterpopupView::validateText(const std::string& value)
{
    std::string name = sui->lblParameterName->getText();
    formatParamNameBack(name);

    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    if (parameterData != NULL) {
        IGSxGUI::ITEMTYPE it = parameterData->getValueType();
        switch (it) {
            case IGSxGUI::TYPE_int:
                {
                    return validateIntegerText(parameterData, value);
                }
                break;
            case IGSxGUI::TYPE_uint:
                {
                    return validateUnsigendIntegerText(parameterData, value);
                }
                break;
            case IGSxGUI::TYPE_double:
                {
                    return validateDoubleText(parameterData, value);
                }
                break;
            default:
                break;
        }
    }
    return true;
}

bool IGSxGUI::ParameterpopupView::validateIntegerText(ParameterData* parameterData, const std::string& value)
{
    if (!tryLexicalConvert<int>(value)) {
        showWarning(parameterData);
        return false;
    }

    if (boost::lexical_cast<int>(value) < parameterData->getMinValue()->ToInt() ||
        boost::lexical_cast<int>(value) > parameterData->getMaxValue()->ToInt()) {
        showWarning(parameterData);
        return false;
    } else {
        sui->gbxUnrecommendedValue->setVisible(false);
        sui->lneValue->setStyleSheetClass("floatArrayLe");
        return true;
    }
}

bool IGSxGUI::ParameterpopupView::validateUnsigendIntegerText(ParameterData* parameterData, const std::string& value)
{
    if (!tryLexicalConvert<unsigned int>(value)) {
        showWarning(parameterData);
        return false;
    }

    if (boost::lexical_cast<unsigned int>(value) < parameterData->getMinValue()->ToUint() ||
        boost::lexical_cast<unsigned int>(value) > parameterData->getMaxValue()->ToUint()) {
        showWarning(parameterData);
        return false;
    } else {
        sui->gbxUnrecommendedValue->setVisible(false);
        sui->lneValue->setStyleSheetClass("floatArrayLe");
        return true;
    }
}

bool IGSxGUI::ParameterpopupView::validateDoubleText(ParameterData* parameterData, const std::string& value)
{
    if (!tryLexicalConvert<double>(value)) {
        showWarning(parameterData);
        return false;
    }

    if (boost::lexical_cast<double>(value) < parameterData->getMinValue()->ToDouble() ||
        boost::lexical_cast<double>(value) > parameterData->getMaxValue()->ToDouble()) {
        showWarning(parameterData);
        return false;
    } else {
        sui->gbxUnrecommendedValue->setVisible(false);
        sui->lneValue->setStyleSheetClass("floatArrayLe");
        return true;
    }
}

SUI::Label* IGSxGUI::ParameterpopupView::getParameterNameType() const
{
    return sui->lblParameterName;
}

void IGSxGUI::ParameterpopupView::showWarning(ParameterData* parameterData) {
    sui->gbxUnrecommendedValue->setVisible(true);
    sui->lneValue->setStyleSheetClass("floatArrayLeWarning");
    std::string min = parameterData->getMinValue()->ToString();
    adjustDoublePrecision(min);
    std::string max = parameterData->getMaxValue()->ToString();
    adjustDoublePrecision(max);
    std::string txt ="Please enter a value between " + min + " and " + max;
    sui->lblUnrecommendedValueDesc->setText(txt);
    sui->lneValue->setFocus();
    IGSxGUI::Util::selectLineEditText(sui->lneValue);
}

void IGSxGUI::ParameterpopupView::regularExpressionCheckInteger(const std::string& value)
{
    boost::regex intregex("^[-+]?[0-9]+$");
    if (!boost::regex_match(value, intregex)) {
        std::string tempval = value;
        int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
        if (x == 0) {
            return;
        }
        if (value.size() == 1 && (value.at(0) == '-' || value.at(0) == '+')) {
            return;
        }
        eraseEnteredCharFromLineEdit(tempval, x-1);
        return;
    }
}

void IGSxGUI::ParameterpopupView::regularExpressionCheckUnsignedInteger(const std::string& value)
{
    boost::regex uintregex("^[0-9]+$");
    if (!boost::regex_match(value, uintregex)) {
        std::string tempval = value;
        int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
        if (x == 0) {
            return;
        }
        eraseEnteredCharFromLineEdit(tempval, x-1);
        return;
    }
}

void IGSxGUI::ParameterpopupView::regularExpressionCheckDouble(const std::string& value)
{
    static size_t sizevar = value.size();
    int textremoved = 0;
    if (sizevar > value.size()) {
        textremoved = 1;
    }
    sizevar = value.size();

    boost::regex dblregex("^[-+]?[0-9]*[.]?[0-9]{1, 8}([eE][-+]?[0-9]{1,2})?$");
    if (!boost::regex_match(value, dblregex)) {
        sui->btnPopUpdate->setEnabled(false);
        std::string valuetmp = value;
        int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);

        if (valuetmp.size() == 0) {
            sui->btnPopUpdate->setEnabled(true);
            return;
        }

        // do not allow more than one '-' or '+' at start
        // also do not allow -+ and +- at start
        if (valuetmp.size() == 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+')) {
            return;
        } else if (valuetmp.size() > 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+') && (valuetmp.at(1) == '-' || valuetmp.at(1) == '+')) {
            eraseEnteredCharFromLineEdit(valuetmp, x-1);
            return;
        }

        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            // do not allow 'e' or 'E'at 0th position
            if (valuetmp.size() == 1) {
                if (valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow any character other than comapred below
            if (valatcur != 'e' && valatcur != 'E' && valatcur != '-' && valatcur != '+' && valatcur != '.' && !textremoved) {
                eraseEnteredCharFromLineEdit(valuetmp, x-1);
                return;
            }

            // do not allow 'e' or 'E' before '.'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valuetmp.find('.', x) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow '.' after 'e' or 'E'
            if (valatcur == '.') {
                if (valuetmp.rfind('e', x-1) != std::string::npos || valuetmp.rfind('E', x-1) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }
        }

        if (x > 1) {
            char valatcur = valuetmp.at(x-1);
            char valatprev = valuetmp.at(x-2);
            // do not allow more than one '-' after 'e' or 'E'
            // also do not allow -+ and +- after 'e' or 'E'
            if (valatcur == '-') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('-', x) != std::string::npos || valuetmp.find('+', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow more than one '+' after 'e' or 'E'
            // also do not allow -+ and +- after 'e' or 'E'
            if (valatcur == '+') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('+', x) != std::string::npos || valuetmp.find('-', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow 'e' or 'E' immediately after after '-'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '-') {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow 'e' or 'E' immediately after after '+'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '+') {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }
        }

        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            // do not allow more than 8 digits after '.'
            size_t pos1 = valuetmp.find('.');
            if (pos1 != std::string::npos) {
                size_t pos2 = valuetmp.find('e');
                size_t pos3 = valuetmp.find('E');
                if (pos2 != std::string::npos || pos3 != std::string::npos) {
                    std::string tmp = "";
                    if (pos2 != std::string::npos) {
                        tmp = valuetmp.substr(pos1+1, pos2-pos1-1);
                    } else {
                        tmp = valuetmp.substr(pos1+1, pos3-pos1-1);
                    }
                    if (tmp.size() > 8) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
                        eraseEnteredCharFromLineEdit(valuetmp, x-1);
                        return;
                    } else if (tmp.size() == 0) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
                        if (valatcur == 'e' || valatcur == 'E') {
                            eraseEnteredCharFromLineEdit(valuetmp, x-1);
                            return;
                        }
                    }
                } else if (valuetmp.size() - pos1 > 8) {
                    int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow more than one 'e' or 'E'
            int count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == 'e' || valuetmp.at(i) == 'E') {
                    ++count;
                }
            }
            if (count >1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
                if (valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }

            // do not allow more than one '.'
            count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == '.') {
                    ++count;
                }
            }
            if (count >1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(sui->lneValue);
                if (valatcur == '.') {
                    eraseEnteredCharFromLineEdit(valuetmp, x-1);
                    return;
                }
            }
        }
        return;
    }
    sui->btnPopUpdate->setEnabled(true);
}

void IGSxGUI::ParameterpopupView::eraseEnteredCharFromLineEdit(std::string& text, int pos) {
    text.erase(pos, 1);
    sui->lneValue->setText(text);
    IGSxGUI::Util::setLineEditCursorPosition(sui->lneValue, pos);
}

void IGSxGUI::ParameterpopupView::formatParamNameBack(std::string& name)
{
    while (true) {
        std::size_t pos = name.find('\n');
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            return;
        }
    }
}

void IGSxGUI::ParameterpopupView::adjustDoublePrecision(std::string& paramvalue) {
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1, 1);
        }
    }
}
