/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <string>
#include <vector>
#include <utility>
#include <iomanip>
#include <algorithm>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_TITLE = "lblTitle";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_NOBUTTON = "btnNo";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_YESBUTTON = "btnYes";
const std::string IGSxGUI::MachineconstantsView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_MESSAGE = "lblMessage";
const std::string IGSxGUI::MachineconstantsView::COLOR_LINEEDIT_CANCEL = "#8c8c8c";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const std::string IGSxGUI::MachineconstantsView::DIALOG_TITLE = "Cancel pending changes?";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETER_FOUND = "parameter found";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETER = "searchparameter";
const std::string IGSxGUI::MachineconstantsView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_BLUEBG = "BlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETERS_FOUND = "parameters found";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_ORANGEBG = "OrangeBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PENDINGPARAMLABEL_STYLE = "pendingParameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCHPARAM_NOITALIC = "searchparameterNoItalic";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_HOVERBLUEBG = "HoverBlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::DIALOG_MESSAGE = "All changed values will be discarded";
const std::string IGSxGUI::MachineconstantsView::CANCELPOPUP_LOAD_FILE = "IGSxGUIxMachineConstantPopup.xml";
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETERGREYBGITALIC = "searchparameterGreyBGItalic";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR_CLICKED = "#FFFFFF";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_CLICKED = "PendingParameterCancelClicked";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERED = "PendingParameterCancelHovered";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERLEFT = "PendingParameterCancelHoverLeft";
const std::string IGSxGUI::MachineconstantsView::COLOR_GREY_DARK = "#4d4d4d";
const std::string IGSxGUI::MachineconstantsView::STYLE_DISABLE_LABEL = "disableLabel";
const std::string IGSxGUI::MachineconstantsView::STYLE_DISABLE_BACKGROUND = "disableBackground";
const std::string IGSxGUI::MachineconstantsView::STYLE_AWESOME_ICONCOLOR = "#4d4d4d";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::MachineconstantsView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::MachineconstantsView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETERGREYBGNONITALIC = "searchparameterGreyBGNonItalic";

const int IGSxGUI::MachineconstantsView::DIALOG_X = 0;
const int IGSxGUI::MachineconstantsView::DIALOG_Y = 60;
const int IGSxGUI::MachineconstantsView::ROW_HEIGHT = 40;
const int IGSxGUI::MachineconstantsView::MULTILINE_ROW_HEIGHT = 60;
const int IGSxGUI::MachineconstantsView::MULTILINE_ROW_HEIGHT_INCREASE = 20;
const int IGSxGUI::MachineconstantsView::BUTTON_SIZE = 18;
const int IGSxGUI::MachineconstantsView::DIALOG_WIDTH = 1920;
const int IGSxGUI::MachineconstantsView::DIALOG_HEIGHT = 130;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS = 18;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 720;
const int IGSxGUI::MachineconstantsView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::MachineconstantsView::PENDINGPARAM_CLOSEBUTTON_SIZE = 20;
const int IGSxGUI::MachineconstantsView::PENDINGPARAM_BI_TIME = 10000;
const size_t IGSxGUI::MachineconstantsView::MAX_CHARS_OF_PARAMETERTREE_CELL = 20;
const int IGSxGUI::MachineconstantsView::MAX_CHARS_OF_PARAMS_PER_LINE = 40;
const int IGSxGUI::MachineconstantsView::BOOL_TYPE_DIALOG = 1;
const int IGSxGUI::MachineconstantsView::MAXIMUM_DOUBLE_PRECISION = 8;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 670;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_TABLE_YPOSITION = 75;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE = 50;
const size_t IGSxGUI::MachineconstantsView::MAX_VISIBLE_CHARS_OF_PARAM_VALUE = 14;

namespace IGSxGUI
{

class BreadCrum
{
  public:
    static const int CRUM_DISTANCE = 5;
    static const int CRUM_MARGIN = 17;
    static const int PIXELS_PER_CHARACTER = 12;
    static const int SLASH_WIDTH = 8;

  public:
    BreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum, SUI::Button* btnPrevious) :
        m_lblSlash(lblSlash), m_btnBreadCrum(btnBreadCrum), m_btnPrevious(btnPrevious)
    {
    }

    SUI::Button* getMainButton()
    {
        return m_btnBreadCrum;
    }

    void Reposition(std::string strCrum)
    {
        // hide the slash if the bread crum that follows is empty
        m_lblSlash->setVisible(!strCrum.empty());
        SUI::Rect rectSlash = m_lblSlash->getGeometry();
        rectSlash.setX(m_btnPrevious->getGeometry().getX() + m_btnPrevious->getGeometry().getWidth() + CRUM_DISTANCE);
        rectSlash.setWidth(SLASH_WIDTH);
        m_lblSlash->setGeometry(rectSlash);
        m_btnBreadCrum->setText(strCrum);
        SUI::Rect rectButton = m_btnBreadCrum->getGeometry();
        rectButton.setX(rectSlash.getX() + rectSlash.getWidth() + CRUM_DISTANCE);
        rectButton.setWidth(IGSxGUI::Util::getButtonTextWidth(m_btnBreadCrum, strCrum) + CRUM_MARGIN);
        m_btnBreadCrum->setGeometry(rectButton);
    }

  private:
    SUI::Label*  m_lblSlash;
    SUI::Button* m_btnBreadCrum;
    SUI::Button* m_btnPrevious;
};

class BreadCrumResizer
{
  public:
    explicit BreadCrumResizer(SUI::Button* btnStart) : m_btnStart(btnStart)
    {
    }

    void AddBreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum)
    {
        m_breadCrums.push_back(new BreadCrum(lblSlash, btnBreadCrum,
                                             m_breadCrums.size() == 0 ? m_btnStart : m_breadCrums[m_breadCrums.size()-1]->getMainButton()));
    }

    void RepositionAll(const std::vector<std::string>& breadCrumTitles)
    {
        m_btnStart->setText(breadCrumTitles[0]);
        SUI::Rect rectButton = m_btnStart->getGeometry();
        int pixelsWide = IGSxGUI::Util::getButtonTextWidth(m_btnStart, breadCrumTitles[0]);
        rectButton.setWidth(pixelsWide + BreadCrum::CRUM_MARGIN);
        m_btnStart->setGeometry(rectButton);
        for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
            m_breadCrums[i]->Reposition(i < static_cast<int>(breadCrumTitles.size() - 1) ? breadCrumTitles[i + 1] : "");
        }
    }

    ~BreadCrumResizer()
    {
        for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
            delete m_breadCrums[i];
        }
    }

  private:
    SUI::Button*            m_btnStart;
    std::vector<BreadCrum*> m_breadCrums;
};

}  // namespace IGSxGUI

IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager):
    sui(new SUI::MachineconstantsView),
    m_selectedParameterRowNum(-1),
    m_selectedPendingParameterRowNum(-1),
    m_parameterview(pMachineconstantsManager),
    m_floatArrayDialog(pMachineconstantsManager),
    m_historyview(pMachineconstantsManager),
    m_searchText(""),
    m_breadCrumResizer(NULL)
{
    m_pMachineconstantsManager = pMachineconstantsManager;
    m_dialog = SUI::UILoader::loadUI(CANCELPOPUP_LOAD_FILE.c_str());
}

IGSxGUI::MachineconstantsView::~MachineconstantsView()
{
    if (m_breadCrumResizer != NULL) {
        delete m_breadCrumResizer;
    }
}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(MACHINECONSTANTSVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    init();
    IGSxGUI::Util::setScrollbarWidthOfTable(sui->tawParameterTree, 20);
    IGSxGUI::Util::setScrollbarWidthOfTable(sui->tawMCPendingParam, 20);
    IGSxGUI::Util::setCommonEventHandler(sui->gbxPageOne, sui->tawParameters, this);
    IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::init()
{
    IGSxGUI::MachineconstantsManager::registerToParameterUpdated(boost::bind(&IGSxGUI::MachineconstantsView::updateViewOnParamSaveEventReceive, this));
    breadCrumpButtonList.clear();
    breadCrumpButtonList.push_back(sui->btnBC1);
    breadCrumpButtonList.push_back(sui->btnBC2);
    breadCrumpButtonList.push_back(sui->btnBC3);
    breadCrumpButtonList.push_back(sui->btnBC4);
    breadCrumpButtonList.push_back(sui->btnBC5);
    breadCrumpButtonList.push_back(sui->btnBC6);
    m_breadCrumResizer = new IGSxGUI::BreadCrumResizer(sui->btnBC1);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash1, sui->btnBC2);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash2, sui->btnBC3);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash3, sui->btnBC4);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash4, sui->btnBC5);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash5, sui->btnBC6);
    sui->lblAllCategories->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->lblBackImage, IGSxGUI::AwesomeIcon::AI_fa_angle_left, SUI::ColorEnum::White, 30);
    sui->lblBackImage->setVisible(false);
    sui->btnBack->setText("BACK");
    sui->btnBack->setVisible(false);
    sui->txaPendingParamSaveChangeReason->clearText();
    IGSxGUI::Util::setTextEditPaletteColor(sui->txaPendingParamSaveChangeReason, "#0AA8FB", "#FFFFFF");
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
    IGSxGUI::Util::setAwesome(sui->lblSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->btnPendingParamSaveNameLnEditCancel, IGSxGUI::AwesomeIcon::AI_fa_close, COLOR_LINEEDIT_CANCEL, 15);
    IGSxGUI::Util::setAwesome(sui->lblPendingParamErrorCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblPendingParamErrorCrossImage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
    sui->tawMCPendingParam->showGrid(false);
    sui->tawMCPendingParam->setRowVisible(0, false);
    sui->tawMCPendingParam->setListViewMode(false);
    IGSxGUI::Util::hideTableDefaultVerticalScrollbar(sui->tawParameters);
    setHandlers();
    showFinalSaveScreenItems(false);
    showSearchEntriesParameter(false);
    if (m_pendingParameterList.size() > 0) {
        showNoPendingParameterScreen(false);
        showSaveCancelButtons(true);
    } else {
        showNoPendingParameterScreen(true);
        showSaveCancelButtons(false);
    }
    IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
    sui->lblPendingParamFinalSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
    sui->gbxPendingParamFinalSaveButton->setEnabled(false);
    initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
    sui->tawParameterTree->showGrid(false);
    IGSxGUI::Util::disableTableItemsSelection(sui->tawParameterTree);
    onParameterTreeItemPressed(0);
}

void IGSxGUI::MachineconstantsView::setActive(bool bActive)
{
    m_active = bActive;
}

void IGSxGUI::MachineconstantsView::setHandlers()
{
    std::vector<SUI::Widget*> paramTableWidgetVector;
    paramTableWidgetVector.push_back(sui->btnParameterName);
    paramTableWidgetVector.push_back(sui->btnParameterName2);
    paramTableWidgetVector.push_back(sui->btnParameterNameUpArrow);
    paramTableWidgetVector.push_back(sui->btnParameterNameDownArrow);
    IGSxGUI::Util::parameterTableHeaderInstallEventFilter(paramTableWidgetVector);
    std::vector<SUI::Widget*> pendingParamTableWidgetVector;
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterName);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameUpArrow);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameDownArrow);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameUpDownArrow);
    IGSxGUI::Util::pendingParameterTableHeaderInstallEventFilter(pendingParamTableWidgetVector);
    sui->btnCancel->clicked = boost::bind(&MachineconstantsView::onCancelButtonPressed, this);
    sui->btnHistory->hoverLeft = boost::bind(&MachineconstantsView::onHistoryHoverLeft, this);
    sui->uctSaveButton->clicked = boost::bind(&MachineconstantsView::onUCTSaveButtonClicked, this);
    sui->uctSaveButton->pressed = boost::bind(&MachineconstantsView::onUCTSaveButtonPressed, this);
    sui->btnHistory->hoverEntered = boost::bind(&MachineconstantsView::onHistoryHoverEntered, this);
    sui->btnHistory->clicked = boost::bind(&MachineconstantsView::onHistoryPressed, this);
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->uctSaveButton->hoverLeft = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOff, this);
    sui->uctSaveButton->hoverEntered = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOn, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnPendingParamCancelSave->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnFinalSave, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->lnePendingParamSaveName->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveTxtChanged, this, _1);
    sui->btnPendingParamSaveNameLnEditCancel->clicked = boost::bind(&MachineconstantsView::PendingParamSaveNameLnEditCancel, this);
    sui->txaPendingParamSaveChangeReason->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveChangeReasonTxtChanged, this, _1);
    sui->tawParameterTree->rowClicked = boost::bind(&MachineconstantsView::onParameterTreeItemPressed, this, _1);
    sui->btnBack->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    sui->btnBack->hoverEntered = boost::bind(&MachineconstantsView::onBackHoverEntered, this);
    sui->btnBack->hoverLeft = boost::bind(&MachineconstantsView::onBackHoverLeft, this);
    sui->lblBackImage->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    m_parameterview.registerForValueChanged(boost::bind(&MachineconstantsView::onParameterValueChanged, this, _1, _2));
    m_floatArrayDialog.registerForFloatArrayValueChanged(boost::bind(&MachineconstantsView::onFloatArrayParameterValueChanged, this, _1, _2));
    sui->btnBC1->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump1HoverEntered, this);
    sui->btnBC2->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump2HoverEntered, this);
    sui->btnBC3->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump3HoverEntered, this);
    sui->btnBC4->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump4HoverEntered, this);
    sui->btnBC5->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump5HoverEntered, this);
    sui->btnBC6->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump6HoverEntered, this);
    sui->btnBC1->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump1HoverLeft, this);
    sui->btnBC2->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump2HoverLeft, this);
    sui->btnBC3->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump3HoverLeft, this);
    sui->btnBC4->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump4HoverLeft, this);
    sui->btnBC5->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump5HoverLeft, this);
    sui->btnBC6->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump6HoverLeft, this);
    sui->btnBC1->clicked = boost::bind(&MachineconstantsView::onBreadCrump1Clicked, this);
    sui->btnBC2->clicked = boost::bind(&MachineconstantsView::onBreadCrump2Clicked, this);
    sui->btnBC3->clicked = boost::bind(&MachineconstantsView::onBreadCrump3Clicked, this);
    sui->btnBC4->clicked = boost::bind(&MachineconstantsView::onBreadCrump4Clicked, this);
    sui->btnBC5->clicked = boost::bind(&MachineconstantsView::onBreadCrump5Clicked, this);
    sui->btnBC6->clicked = boost::bind(&MachineconstantsView::onBreadCrump6Clicked, this);
    sui->btnRetryPendingParamSave->clicked = boost::bind(&MachineconstantsView::pendingParamRetrySave, this);
    sui->btnCancelPendingParamSave->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage, this);
    sui->lblPendingParamErrorCloseImage->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage, this);
    sui->btnParameterName->clicked = boost::bind(&MachineconstantsView::sortParamsDescending, this);
    sui->btnParameterName2->clicked = boost::bind(&MachineconstantsView::sortParamsAscending, this);
    IGSxGUI::Util::setAwesome(sui->btnParameterNameUpArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnParameterNameDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, "#1B3E93", 11);
    sui->btnParameterNameUpArrow->clicked = boost::bind(&MachineconstantsView::sortParamsDescending, this);
    sui->btnParameterNameDownArrow->clicked = boost::bind(&MachineconstantsView::sortParamsAscending, this);
    sui->btnPendingParameterName->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameUpArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameUpDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_default, "#1B3E93", 11);
    sui->btnPendingParameterNameUpArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    sui->btnPendingParameterNameDownArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    sui->btnPendingParameterNameUpDownArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
}

void IGSxGUI::MachineconstantsView::onCancelYesPressed()
{
    removePendingParamTableRows();
    showSaveCancelButtons(false);
    showNoPendingParameterScreen(true);
    m_pendingParameterList.clear();
    m_dialog->close();
}

void IGSxGUI::MachineconstantsView::updateViewOnParamSaveEventReceive()
{
    if (!m_active)
        return;
    for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(paramname);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + paramname;
        } else {
            fullName = paramname;
        }
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData->getCurrentValue()->ToString() == parameterData->getPreviousValue()->ToString()) {
            std::string paramvalue = parameterData->getCurrentValue()->ToString();
            IGSxGUI::ITEMTYPE type = parameterData->getValueType();
            if (type == IGSxGUI::TYPE_double) {
                adjustDoublePrecision(paramvalue);
            } else if (type == IGSxGUI::TYPE_floatarray) {
                std::vector<std::string> values;
                boost::split(values, paramvalue, boost::is_any_of(","));
                paramvalue = "";
                for (unsigned int i = 0; i < values.size(); ++i) {
                    std::string value = values[i];
                    adjustDoublePrecision(value);
                    paramvalue = paramvalue + "," + value;
                }
                paramvalue.erase(0, 1);
            }
            formatParamValue(widget, paramvalue, 173);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
            parameterData->resetUpdateFlag();
        }
        if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
            IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
        } else {
            IGSxGUI::Util::setParameterUCTGreyStyle(widget, 1);
        }
    }
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
    return;
}

void IGSxGUI::MachineconstantsView::setDefaultPropertiesWhenUpdatingParamTable()
{
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->btnParameterName->setEnabled(true);
    sui->btnParameterName2->setEnabled(true);
    sui->btnParameterNameUpArrow->setEnabled(true);
    sui->btnParameterNameDownArrow->setEnabled(true);
    sui->tawParameterTree->rowClicked = boost::bind(&MachineconstantsView::onParameterTreeItemPressed, this, _1);
    sui->btnBack->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    sui->btnBC1->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump1HoverEntered, this);
    sui->btnBC2->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump2HoverEntered, this);
    sui->btnBC3->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump3HoverEntered, this);
    sui->btnBC4->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump4HoverEntered, this);
    sui->btnBC5->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump5HoverEntered, this);
    sui->btnBC6->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump6HoverEntered, this);
    sui->btnBC1->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump1HoverLeft, this);
    sui->btnBC2->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump2HoverLeft, this);
    sui->btnBC3->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump3HoverLeft, this);
    sui->btnBC4->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump4HoverLeft, this);
    sui->btnBC5->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump5HoverLeft, this);
    sui->btnBC6->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump6HoverLeft, this);
    sui->btnBC1->clicked = boost::bind(&MachineconstantsView::onBreadCrump1Clicked, this);
    sui->btnBC2->clicked = boost::bind(&MachineconstantsView::onBreadCrump2Clicked, this);
    sui->btnBC3->clicked = boost::bind(&MachineconstantsView::onBreadCrump3Clicked, this);
    sui->btnBC4->clicked = boost::bind(&MachineconstantsView::onBreadCrump4Clicked, this);
    sui->btnBC5->clicked = boost::bind(&MachineconstantsView::onBreadCrump5Clicked, this);
    sui->btnBC6->clicked = boost::bind(&MachineconstantsView::onBreadCrump6Clicked, this);
}

void IGSxGUI::MachineconstantsView::saveButtonPressedOnPendingParamFinalSaveScreen()
{
    uctPendingParamFinalSaveClicked();
}

void IGSxGUI::MachineconstantsView::cancelButtonPressedOnPendingParamFinalSaveScreen()
{
    onCancelPressedOnFinalSave();
}

void IGSxGUI::MachineconstantsView::updateParameterTableOnCancelingFinalSave()
{
    setDefaultPropertiesWhenUpdatingParamTable();
    int value = 0;
    if (sui->scbParametersTable->isVisible()) {
        value = sui->scbParametersTable->getValue();
    }
    std::vector<ParameterData*> collection = m_pMachineconstantsManager->getParameterData();
    std::vector<ParameterData*>::iterator it = collection.begin();
    std::advance(it, value);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row, ++it) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        widget->setEnabled(true);
        if ((*it)->isReadOnly()) {
            setUCTHandlers(widget, row, true);
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        } else {
            setUCTHandlers(widget, row, false);
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
            if ((*it)->getDefaultValue()->ToString() != (*it)->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::updateParameterTable()
{
    setDefaultPropertiesWhenUpdatingParamTable();
    int value = 0;
    if (sui->scbParametersTable->isVisible()) {
        value = sui->scbParametersTable->getValue();
    }
    std::vector<ParameterData*> collection = m_pMachineconstantsManager->getParameterData();
    std::vector<ParameterData*>::iterator it = collection.begin();
    if (!m_searchText.empty()) {
        m_pMachineconstantsManager->searchForParameters(m_searchText, &m_matchedparameters);
        collection = m_matchedparameters;
        it = collection.begin();
    }
    std::advance(it, value);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row, ++it) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        widget->setEnabled(true);
        if ((*it)->isReadOnly()) {
            setUCTHandlers(widget, row, true);
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        } else {
            setUCTHandlers(widget, row, false);
            IGSxGUI::Util::setParameterUCTGroupBoxNormalStyle(widget);
        }
    }
}

void IGSxGUI::MachineconstantsView::onCancelButtonPressed()
{
    createPopup(DIALOG_TITLE, DIALOG_MESSAGE);
    m_dialog->show();
}

void IGSxGUI::MachineconstantsView::showSaveCancelButtons(bool bShow)
{
    sui->btnCancel->setVisible(bShow);
    sui->uctSaveButton->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showPendingParamWidgets(bool bShow)
{
    sui->tawMCPendingParam->setVisible(bShow);
    sui->gbxPendingParamName->setVisible(bShow);
    sui->btnPendingParameterValue->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenItems(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamSaveNameLnEdit->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(bShow);
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showSearchEntriesParameter(bool bShow)
{
    sui->lblEntriesFound->setVisible(bShow);
    if (bShow) {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
    }
}

void IGSxGUI::MachineconstantsView::showNoPendingParameterScreen(bool bShow)
{
    sui->btnNoPendingParameters->setVisible(bShow);
    sui->tawMCPendingParam->setVisible(!bShow);
    sui->gbxPendingParamName->setVisible(!bShow);
    sui->btnPendingParameterValue->setVisible(!bShow);
    if (bShow) {
        showFinalSaveScreenItems(false);
    }
}

void IGSxGUI::MachineconstantsView::createPopup(const std::string& title, const std::string& message)
{
    m_dialog->setWindowTitle(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_TITLE)->setText(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_MESSAGE)->setText(message);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_YESBUTTON)->clicked = boost::bind(&MachineconstantsView::onCancelYesPressed, this);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_NOBUTTON)->clicked = boost::bind(&SUI::Dialog::close, m_dialog);
    m_dialog->setModal(true);
    IGSxGUI::Util::setParent(m_dialog, sui->btnSearchAndClearIcon);
    IGSxGUI::Util::disableScrollbars(m_dialog);
    IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
    IGSxGUI::Util::setWindowFrame(m_dialog, false);
}

void IGSxGUI::MachineconstantsView::setUCTHandlers(SUI::Widget *widget, int row, bool readonly)
{
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    if (!readonly) {
        usercontrol->clicked = boost::bind(&MachineconstantsView::onParameterRowPressed, this, row);
        usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onParameterUCTHoverEntered, this, row);
        usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onParameterUCTHoverLeft, this, row);
    } else {
        usercontrol->clicked = NULL;
        usercontrol->hoverEntered = NULL;
        usercontrol->hoverLeft = NULL;
    }
}

void IGSxGUI::MachineconstantsView::populateData(std::vector<ParameterData*>::iterator it, int row)
{
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string paramvalue = (*it)->getPreviousValue()->ToString();
    IGSxGUI::ITEMTYPE type = (*it)->getValueType();
    if (type == IGSxGUI::TYPE_double) {
        adjustDoublePrecision(paramvalue);
    } else if (type == IGSxGUI::TYPE_floatarray) {
        std::vector<std::string> values;
        boost::split(values, paramvalue, boost::is_any_of(","));
        paramvalue = "";
        for (unsigned int i = 0; i < values.size(); ++i) {
            std::string value = values[i];
            adjustDoublePrecision(value);
            paramvalue = paramvalue + "," + value;
        }
        paramvalue.erase(0, 1);
    }
    formatParamValue(widget, paramvalue, 173);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
    std::pair <std::string, int> formattedText = formatParamName((*it)->getDisplayName());
    IGSxGUI::Util::setRowHeight(sui->tawParameters, row, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
    if ((*it)->isReadOnly()) {
        setUCTHandlers(widget, row, true);
        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
    } else {
        setUCTHandlers(widget, row, false);
        if ((*it)->isSelected()) {
            IGSxGUI::Util::setParameterUCTClickedStyle(widget);
        } else {
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
        }
        if ((*it)->getDefaultValue()->ToString() != (*it)->getPreviousValue()->ToString()) {
            IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
        }
    }
}

void IGSxGUI::MachineconstantsView::initializeTableRows(int rows, std::vector<ParameterData*> collection)
{
    if (rows <= 0) {
        sui->tawParameters->setVisible(false);
        sui->scbParametersTable->setVisible(false);
    } else {
        sui->tawParameters->showGrid(false);
        sui->tawParameters->setVisible(true);
        int noofrows = rows;
        if (rows > MAX_VISIBLE_ROWS) {
            noofrows = MAX_VISIBLE_ROWS;
            sui->scbParametersTable->setValue(0);
            sui->scbParametersTable->setVisible(true);
            sui->scbParametersTable->setMinValue(0);
            sui->scbParametersTable->setMaxValue(static_cast<int>(collection.size()) - MAX_VISIBLE_ROWS);
            sui->scbParametersTable->setPageStep(1);
        } else {
            sui->scbParametersTable->setVisible(false);
        }
        sui->tawParameters->removeRows(1, (sui->tawParameters->rowCount() - 1));
        for (int i = 0; i < (noofrows - 1); ++i) {
            sui->tawParameters->appendRow();
        }
    }
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = MAX_VISIBLE_ROWS;
    }
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    int totalRowHeight = 0;
    int max_rows = 0;
    for (; max_rows < rows; ++max_rows, ++beg_it) {
        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            break;
        }
        std::pair <std::string, int> formattedText = formatParamName((*beg_it)->getDisplayName());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    }
    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        max_rows--;
        // display the scrollbar when number of items are <=MAX_VISIBLE_ROWS and all items do not fit in the visible space
        if ((static_cast<int>(collection.size()) <=  MAX_VISIBLE_ROWS) && (max_rows < static_cast<int>(collection.size()))) {
            sui->scbParametersTable->setValue(0);
            sui->scbParametersTable->setVisible(true);
            sui->scbParametersTable->setMinValue(0);
            sui->scbParametersTable->setMaxValue(static_cast<int>(collection.size()) - max_rows);
        }
    }
    if (max_rows < rows) {
        sui->tawParameters->removeRows(max_rows, rows - max_rows);
    }
    setData(0, max_rows, collection);
}

void IGSxGUI::MachineconstantsView::setData(int value, int rows, std::vector<ParameterData*> collection)
{
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    std::vector<ParameterData*>::iterator it = collection.end();
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
    }
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonClicked()
{
    std::vector<SUI::Widget*> pendingParamSaveScreenWidgetVector;
    pendingParamSaveScreenWidgetVector.push_back(sui->lnePendingParamSaveName);
    pendingParamSaveScreenWidgetVector.push_back(sui->txaPendingParamSaveChangeReason);
    pendingParamSaveScreenWidgetVector.push_back(sui->gbxPendingParamFinalSaveButton);
    pendingParamSaveScreenWidgetVector.push_back(sui->btnPendingParamCancelSave);
    IGSxGUI::Util::pendingParameterSaveScreenInstallEventFileter(pendingParamSaveScreenWidgetVector, this);
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
        SUI::Widget *widget = dynamic_cast<SUI::Widget*>(sui->tawParameters->getWidgetItem(row, 0));
        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + name;
        } else {
            fullName = name;
        }
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        usercontrol->clicked = NULL;
        usercontrol->hoverLeft = NULL;
        usercontrol->hoverEntered = NULL;
    }
    sui->scbParametersTable->valueChanged = NULL;
    sui->lneSearchParameterText->textChanged = NULL;
    sui->lneSearchParameterText->editingFinished = NULL;
    sui->lneSearchParameterText->setEnabled(false);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETERGREYBGITALIC);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETERGREYBGNONITALIC);
    }
    sui->btnParameterName->setEnabled(false);
    sui->btnParameterName2->setEnabled(false);
    sui->btnParameterNameUpArrow->setEnabled(false);
    sui->btnParameterNameDownArrow->setEnabled(false);
    sui->tawParameterTree->rowClicked = NULL;
    sui->btnBack->clicked = NULL;
    sui->btnBC1->hoverEntered = NULL;
    sui->btnBC2->hoverEntered = NULL;
    sui->btnBC3->hoverEntered = NULL;
    sui->btnBC4->hoverEntered = NULL;
    sui->btnBC5->hoverEntered = NULL;
    sui->btnBC6->hoverEntered = NULL;
    sui->btnBC1->hoverLeft = NULL;
    sui->btnBC2->hoverLeft = NULL;
    sui->btnBC3->hoverLeft = NULL;
    sui->btnBC4->hoverLeft = NULL;
    sui->btnBC5->hoverLeft = NULL;
    sui->btnBC6->hoverLeft = NULL;
    sui->btnBC1->clicked = NULL;
    sui->btnBC2->clicked = NULL;
    sui->btnBC3->clicked = NULL;
    sui->btnBC4->clicked = NULL;
    sui->btnBC5->clicked = NULL;
    sui->btnBC6->clicked = NULL;
    if (sui->lnePendingParamSaveName->getText().empty()) {
        sui->lblPendingParamSaveNameLnEdit->setVisible(true);
        sui->btnPendingParamSaveNameLnEditCancel->setVisible(false);
    } else {
        sui->lblPendingParamSaveNameLnEdit->setVisible(false);
        sui->btnPendingParamSaveNameLnEditCancel->setVisible(true);
    }
    if (sui->txaPendingParamSaveChangeReason->getText().empty()) {
        sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(true);
    }
    sui->btnSearchAndClearIcon->clicked = NULL;
    sui->btnSearchAndClearIcon->hoverLeft = NULL;
    sui->btnSearchAndClearIcon->hoverEntered = NULL;
    showSaveCancelButtons(false);
    showPendingParamWidgets(false);
    showFinalSaveScreenPendingParams(true);
    sui->lnePendingParamSaveName->setFocus();
    IGSxGUI::Util::selectLineEditText(sui->lnePendingParamSaveName);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenPendingParams(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonPressed()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOn()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOff()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::setTableRows(int value, std::vector<ParameterData*> collection)
{
    int rows = static_cast<int>(collection.size()) - value;
    if (rows > MAX_VISIBLE_ROWS) {
        rows = MAX_VISIBLE_ROWS;
    }
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    std::advance(beg_it, value);
    int totalRowHeight = 0;
    int row = 0;
    for (; row < rows; ++row, ++beg_it) {
        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            break;
        }
        std::pair <std::string, int> formattedText = formatParamName((*beg_it)->getDisplayName());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    }
    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        row--;
    }
    // When the position of scrollbar reaches its maximum value but still there are few rows left to be displayed (which happens when number of rows that
    // can fit in table are less than MAX_VISIBLE_ROWS), change the maximum value and the current value of scrollbar as per number of rows left to be displayed
    // so that left out rows can also be displayed
    if (value == sui->scbParametersTable->getMaxValue() && row < MAX_VISIBLE_ROWS && beg_it != collection.end()) {
        sui->scbParametersTable->setMaxValue(value + MAX_VISIBLE_ROWS - row);
        sui->scbParametersTable->setValue(value);
    }
    if (row > sui->tawParameters->rowCount()) {
        int count = row - sui->tawParameters->rowCount();
        for (int i = 0; i < count; ++i) {
            sui->tawParameters->appendRow();
        }
    } else if (row < sui->tawParameters->rowCount()) {
        int count = sui->tawParameters->rowCount() - row;
        for (int i = 0; i < count; ++i) {
            sui->tawParameters->removeRow(sui->tawParameters->rowCount() -1);
        }
    }
    setData(value, row, collection);
}

void IGSxGUI::MachineconstantsView::onParameterValueChanged(const std::string& name, const std::string& value)
{
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    if (parameterData != NULL) {
        m_parameterview.close();
        parameterData->changeValue(value);
        std::string paramvalue = parameterData->getCurrentValue()->ToString();
        IGSxGUI::ITEMTYPE type = parameterData->getValueType();
        if (type == IGSxGUI::TYPE_double) {
            adjustDoublePrecision(paramvalue);
        }
        std::pair<std::string, std::string> nameValuePair(searchname, paramvalue);
        m_pendingParameterList.push_back(nameValuePair);
        UpdatePendingParamTable(searchname, paramvalue);
    }
    showSaveCancelButtons(true);
    showNoPendingParameterScreen(false);
}


void IGSxGUI::MachineconstantsView::onFloatArrayParameterValueChanged(const std::string& name, const std::string& value)
{
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    if (parameterData != NULL) {
        m_floatArrayDialog.close();
        parameterData->changeValue(value);
        std::string paramvalue = value;
        std::vector<std::string> values;
        boost::split(values, paramvalue, boost::is_any_of(","));
        paramvalue = "";
        for (unsigned int i = 0; i < values.size(); ++i) {
            std::string dblValue = values[i];
            adjustDoublePrecision(dblValue);
            paramvalue = paramvalue + "," + dblValue;
        }
        paramvalue.erase(0, 1);
        std::pair<std::string, std::string> nameValuePair(searchname, paramvalue);
        m_pendingParameterList.push_back(nameValuePair);
        UpdatePendingParamTable(searchname, paramvalue);
    }
    showSaveCancelButtons(true);
    showNoPendingParameterScreen(false);
}

std::string IGSxGUI::MachineconstantsView::getFullParameterName(const std::string& name)
{
    std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
    std::string fullName = "";
    if (vec.size() > 1) {
        vec.erase(vec.begin());
        std::string parameterCategory = boost::join(vec, "/");
        boost::trim(parameterCategory);
        fullName = parameterCategory + "/" + name;
    } else {
        fullName = name;
    }
    return fullName;
}

IGSxGUI::ParameterData* IGSxGUI::MachineconstantsView::getParameterDataForName(const std::string& name)
{
    std::string fullName = getFullParameterName(name);
    return (m_pMachineconstantsManager->findParameter(fullName));
}

void IGSxGUI::MachineconstantsView::clearSelectionForAllParameterdata()
{
    size_t totalSize = m_pMachineconstantsManager->getAllParameterData().size();
    for (size_t i = 0; i < totalSize; ++i) {
        m_pMachineconstantsManager->getAllParameterData().at(i)->setSelected(false);
    }
}

void IGSxGUI::MachineconstantsView::onParameterRowPressed(int row)
{
    m_selectedParameterRowNum = row;
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);
    if (isCtrlKeyPressed()) {
        if (parameterData->isSelected()) {
            parameterData->setSelected(false);
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
        } else {
            parameterData->setSelected(true);
            IGSxGUI::Util::setParameterUCTClickedStyle(widget);
            IGSxGUI::Util::processEvents();
        }
    } else {
        clearSelectionForAllParameterdata();
        parameterData->setSelected(true);
        for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
            std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            formatParamNameBack(name);
            ParameterData* parameterData = getParameterDataForName(name);
            if (parameterData->isSelected()) {
                IGSxGUI::Util::setParameterUCTClickedStyle(widget);
                IGSxGUI::Util::processEvents();
            } else if (parameterData->isReadOnly()) {
                IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
            } else {
                IGSxGUI::Util::setParameterUCTNormalStyle(widget);
            }
        }
        if (parameterData != NULL) {
            if (parameterData->getValueType() == IGSxGUI::TYPE_floatarray) {
                std::pair <std::string, int> formattedText = formatFloatArrayDialogParamName(fullName);
                fullName = formattedText.first;
                m_floatArrayDialog.setParameterName(fullName);
                m_floatArrayDialog.setParent(sui->lneSearchParameterText);  // any widget can be passed
                m_floatArrayDialog.show();
            } else {
                std::pair <std::string, int> formattedText = formatDialogParamName(fullName);
                fullName = formattedText.first;
                m_parameterview.setParameterName(fullName);
                m_parameterview.setParent(sui->lneSearchParameterText);  // any widget can be passed
                if (parameterData->getValueType() == IGSxGUI::TYPE_boolean) {
                    m_parameterview.setParameterDefaultValue(parameterData->getDefaultValue()->ToString());
                    m_parameterview.setParameterValue(parameterData->getCurrentValue()->ToString(), BOOL_TYPE_DIALOG);
                    m_parameterview.show(BOOL_TYPE_DIALOG);
                } else {
                    std::string def = parameterData->getDefaultValue()->ToString();
                    std::string paramvalue = parameterData->getCurrentValue()->ToString();
                    IGSxGUI::ITEMTYPE type = parameterData->getValueType();
                    if (type == IGSxGUI::TYPE_double) {
                        adjustDoublePrecision(paramvalue);
                        adjustDoublePrecision(def);
                    }
                    m_parameterview.setParameterDefaultValue(def);
                    m_parameterview.setParameterValue(paramvalue, BOOL_TYPE_DIALOG == 0 ? 1 : 0);
                    m_parameterview.show(BOOL_TYPE_DIALOG == 0 ? 1 : 0);
                }
            }
        }
        m_selectedParameterRowNum = -1;
        IGSxGUI::Util::setParameterUCTNormalStyle(widget);
        if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
            IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
        }
    }
}


void IGSxGUI::MachineconstantsView::onParameterUCTHoverEntered(int row)
{
    /*  SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
      std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);

      std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
      std::string fullName = "";
      if (vec.size() > 1) {
          vec.erase(vec.begin());
          std::string parameterCategory = boost::join(vec, "/");
          boost::trim(parameterCategory);
          fullName = parameterCategory + "/" + name;
      } else {
          fullName = name;
      }*/
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);
    if (!parameterData->isSelected()) {
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawParameters->getWidgetItem(row, 0));
            if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
            std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
            if (value.find("...") != std::string::npos) {
                std::string paramvalue = parameterData->getPreviousValue()->ToString();
                IGSxGUI::ITEMTYPE type = parameterData->getValueType();
                if (type == IGSxGUI::TYPE_double) {
                    adjustDoublePrecision(paramvalue);
                } else if (type == IGSxGUI::TYPE_floatarray) {
                    std::vector<std::string> values;
                    boost::split(values, paramvalue, boost::is_any_of(","));
                    paramvalue = "";
                    for (unsigned int i = 0; i < values.size(); ++i) {
                        std::string value = values[i];
                        adjustDoublePrecision(value);
                        paramvalue = paramvalue + "," + value;
                    }
                    paramvalue.erase(0, 1);
                    if (paramvalue.size() > 100) {
                        splitToMultilineToolTip(paramvalue, 100);
                    }
                }
                sui->tawParameters->setToolTip(paramvalue);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverLeft(int row)
{
    // When popup window shows up after clicking the table row, focus goes out of the clicked row and onParameterUCTHoverLeft event gets generated
    // which makes this method called and clicked row becomes un-highlighted. Do not apply HoverOffStyle to the selected row, so that the
    // selected row will be remain selected even after popup window shows up.
    /*SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);

    std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
    std::string fullName = "";
    if (vec.size() > 1) {
        vec.erase(vec.begin());
        std::string parameterCategory = boost::join(vec, "/");
        boost::trim(parameterCategory);
        fullName = parameterCategory + "/" + name;
    } else {
        fullName = name;
    }
    */
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);
    if (!parameterData->isSelected()) {
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            if (m_selectedParameterRowNum != row) {
                IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawParameters->getWidgetItem(row, 0));
            }
            if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
        sui->tawParameters->setToolTip("");
    }
}

void IGSxGUI::MachineconstantsView::onHistoryHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, true);
}

void IGSxGUI::MachineconstantsView::onHistoryHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, false);
}

void IGSxGUI::MachineconstantsView::onHistoryPressed()
{
    m_historyview.setParent(sui->btnHistory);
    m_historyview.show();
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_BLUE_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowClosePressed(int rowNumber)
{
    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    tabwidget->setStyleSheetClass(PENDINGPARAMCANCEL_CLICKED);
    IGSxGUI::Util::processEvents();
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    if (parameterData != NULL) {
        parameterData->revertValue();
    }
    bool pendingParamTableScrollBarVisibleBefore = false;
    if (!isPendingParamTableScrollBarVisible()) {
        moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, rowNumber));
    } else {
        pendingParamTableScrollBarVisibleBefore = true;
    }
    for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(paramname);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + paramname;
        } else {
            fullName = paramname;
        }
        if (fullName == name) {
            if (parameterData->getDefaultValue()->ToString() == parameterData->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTValueNormalStyle(widget, 1);
            } else {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
    }
    if (sui->tawMCPendingParam->rowCount() == 1) {
        sui->tawMCPendingParam->setRowVisible(0, false);
        showSaveCancelButtons(false);
        showNoPendingParameterScreen(true);
        IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
        tabwidget->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERLEFT);
    } else {
        sui->tawMCPendingParam->removeRow(rowNumber);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            pendingParamApplyRowBehavior(row);
        }
    }
    updatePendingParameterList(name);
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onSearchTextEdited(const std::string &text)
{
    m_searchText = text;
    if (m_searchText != "") {
        if (m_searchText == STRING_SEARCH_PARAMETER) {
            sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        } else {
            sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
        }
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
    } else {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    }
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
    refreshParameterList();
}

void IGSxGUI::MachineconstantsView::refreshParameterList()
{
    if (m_searchText.empty()) {
        showSearchEntriesParameter(false);
        initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
    } else {
        sui->lneSearchParameterText->setText(m_searchText);
        showSearchEntriesParameter(true);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
        int entriesfound = m_pMachineconstantsManager->searchForParameters(m_searchText, &m_matchedparameters);
        initializeTableRows(entriesfound, m_matchedparameters);
        sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND);
    }
}

void IGSxGUI::MachineconstantsView::refreshPendingParameterList()
{
    if (m_pendingParameterList.size() > 0) {
        for (size_t i = 0; i < m_pendingParameterList.size(); i++) {
            UpdatePendingParamTable(m_pendingParameterList[i].first, m_pendingParameterList[i].second);
        }
    }
}

void IGSxGUI::MachineconstantsView::onValueChanged()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(sui->scbParametersTable->getValue(), m_pMachineconstantsManager->getParameterData());
    } else {
        setTableRows(sui->scbParametersTable->getValue(), m_matchedparameters);
    }
}

void IGSxGUI::MachineconstantsView::onSearchTextEditFinished()
{
    if (m_searchText == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    } else {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
    }
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::UpdatePendingParamTable(const std::string &name, const std::string &value)
{
    int rowNumber;
    if ((sui->tawMCPendingParam->rowCount() == 1) && (!sui->tawMCPendingParam->isRowVisible(0))) {
        rowNumber = 0;
        sui->tawMCPendingParam->setRowVisible(rowNumber, true);
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        // After pending parameters have been saved or cancelled or removed, adding a row only requires to update with new name and value
        // since we are not actually deleting the last row while performing saving or cancel or removing last row in pending parameters.
        if (!paramname.empty()) {
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            moveSaveCancelButtons(DOWN, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
            std::string paramvalue = value;
            formatParamValue(widget, paramvalue, 161);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
            return;
        }
        std::pair <std::string, int> formattedText = formatPendingParamName(name);
        IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        moveSaveCancelButtons(DOWN, (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
    } else {
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            std::pair <std::string, int> tmpname = formatPendingParamName(name);
            std::string formattedText = tmpname.first;
            if (paramname == formattedText) {
                std::string paramvalue = value;
                formatParamValue(widget, paramvalue, 161);
                IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
                return;
            }
        }
        if (!isPendingParamTableScrollBarVisible()) {
            sui->tawMCPendingParam->appendRow();
            rowNumber = sui->tawMCPendingParam->rowCount() - 1;
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            if (!isPendingParamTableScrollBarVisible()) {
                moveSaveCancelButtons(DOWN, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            } else {
                adjustCancelSaveButtonGeometryDown();
            }
        } else {
            sui->tawMCPendingParam->appendRow();
            rowNumber = sui->tawMCPendingParam->rowCount() - 1;
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        }
    }
    configurePendingParamTableRow(rowNumber, name, value);
}

void IGSxGUI::MachineconstantsView::configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value)
{
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    std::pair <std::string, int> formattedText = formatPendingParamName(name);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
    std::string paramvalue = value;
    formatParamValue(widget, paramvalue, 161);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
    pendingParamApplyRowBehavior(rowNumber);
    sui->btnPendingParameterNameUpDownArrow->setVisible(true);
    sui->btnPendingParameterNameUpArrow->setVisible(false);
    sui->btnPendingParameterNameDownArrow->setVisible(false);
    IGSxGUI::Util::scrollToBottom(sui->tawMCPendingParam);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveClicked()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);
    IGSxGUI::Util::processEvents();
    showSaveCancelButtons(true);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(false);
    performPendingParamSaving();
    sui->lneSearchParameterText->setEnabled(true);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
    }
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverEntered()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverLeft()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveChangeReasonTxtChanged(const std::string &text)
{
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(text.empty());
    std::string name = sui->lnePendingParamSaveName->getText();
    boost::trim(name);
    std::string reason = sui->txaPendingParamSaveChangeReason->getText();
    boost::trim(reason);
    changeFinalSaveButtonStyle(name, reason);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveTxtChanged(const std::string &text)
{
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(!text.empty());
    sui->lblPendingParamSaveNameLnEdit->setVisible(text.empty());
    std::string name = sui->lnePendingParamSaveName->getText();
    boost::trim(name);
    std::string reason = sui->txaPendingParamSaveChangeReason->getText();
    boost::trim(reason);
    changeFinalSaveButtonStyle(name, reason);
}

void IGSxGUI::MachineconstantsView::updatePendingParameterList(std::string pendingParamName)
{
    if (!pendingParamName.empty()) {
        for (size_t i = 0; i < m_pendingParameterList.size(); i++) {
            if (m_pendingParameterList[i].first == pendingParamName) {
                m_pendingParameterList.erase(std::remove(m_pendingParameterList.begin(), m_pendingParameterList.end(),
                                             m_pendingParameterList[i]), m_pendingParameterList.end());
                break;
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::changeFinalSaveButtonStyle(const std::string& name, const std::string& reason)
{
    if (name.empty() || reason.empty()) {
        sui->uctPendingParamFinalSave->clicked = NULL;
        sui->uctPendingParamFinalSave->hoverLeft = NULL;
        sui->uctPendingParamFinalSave->hoverEntered = NULL;
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
        sui->gbxPendingParamFinalSaveButton->setEnabled(false);
    } else {
        sui->uctPendingParamFinalSave->clicked = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveClicked, this);
        sui->uctPendingParamFinalSave->hoverLeft = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverLeft, this);
        sui->uctPendingParamFinalSave->hoverEntered = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverEntered, this);
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass("");
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
        sui->gbxPendingParamFinalSaveButton->setEnabled(true);
    }
}

void IGSxGUI::MachineconstantsView::removePendingParamTableRows()
{
    int rowcount = sui->tawMCPendingParam->rowCount();
    for (int row = rowcount - 1; row >= 0; --row) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(pendingparamname);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(pendingparamname);
        if (parameterData != NULL) {
            parameterData->revertValue();
        }
        for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
            SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            formatParamNameBack(paramname);
            std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
            std::string fullName = "";
            if (vec.size() > 1) {
                vec.erase(vec.begin());
                std::string parameterCategory = boost::join(vec, "/");
                boost::trim(parameterCategory);
                fullName = parameterCategory + "/" + paramname;
            } else {
                fullName = paramname;
            }
            if (fullName == pendingparamname) {
                if (parameterData->getDefaultValue()->ToString() == parameterData->getPreviousValue()->ToString()) {
                    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                } else {
                    IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                }
            }
        }
        if (row == 0) {
            continue;
        }
        bool pendingParamTableScrollBarVisibleBefore = false;
        if (!isPendingParamTableScrollBarVisible()) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row));
        } else {
            pendingParamTableScrollBarVisibleBefore = true;
        }
        sui->tawMCPendingParam->removeRow(row);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
    }
    moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, 0));
    sui->tawMCPendingParam->setRowVisible(0, false);
}

void IGSxGUI::MachineconstantsView::moveSaveCancelButtons(const moveDirection &dir, int pixels)
{
    int xCancel = sui->btnCancel->getGeometry().getX();
    int yCancel = sui->btnCancel->getGeometry().getY();
    int widthCancel = sui->btnCancel->getGeometry().getWidth();
    int heightCancel = sui->btnCancel->getGeometry().getHeight();
    int xSave = sui->uctSaveButton->getGeometry().getX();
    int ySave = sui->uctSaveButton->getGeometry().getY();
    int widthSave = sui->uctSaveButton->getGeometry().getWidth();
    int heightSave = sui->uctSaveButton->getGeometry().getHeight();
    switch (dir) {
    case UP: {
        yCancel -= pixels;
        ySave -= pixels;
        break;
    }
    case DOWN: {
        yCancel += pixels;
        ySave += pixels;
        break;
    }
    default:
        break;
    }
    sui->btnCancel->setGeometry(xCancel, yCancel, widthCancel, heightCancel);
    sui->uctSaveButton->setGeometry(xSave, ySave, widthSave, heightSave);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveNameLnEditCancel()
{
    sui->lnePendingParamSaveName->clearText();
    sui->lnePendingParamSaveName->setFocus();
}

void IGSxGUI::MachineconstantsView::onCancelPressedOnFinalSave()
{
    showSaveCancelButtons(true);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(false);
    updateParameterTableOnCancelingFinalSave();
    setHandlers();
    sui->lneSearchParameterText->setEnabled(true);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
    }
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverEntered(int row)
{
    IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawMCPendingParam->getWidgetItem(row, 0));
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    if (value.find("...") != std::string::npos) {
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(pendingparamname);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(pendingparamname);
        if (parameterData != NULL) {
            std::string paramvalue = parameterData->getCurrentValue()->ToString();
            IGSxGUI::ITEMTYPE type = parameterData->getValueType();
            if (type == IGSxGUI::TYPE_double) {
                adjustDoublePrecision(paramvalue);
            } else if (type == IGSxGUI::TYPE_floatarray) {
                std::vector<std::string> values;
                boost::split(values, paramvalue, boost::is_any_of(","));
                paramvalue = "";
                for (unsigned int i = 0; i < values.size(); ++i) {
                    std::string value = values[i];
                    adjustDoublePrecision(value);
                    paramvalue = paramvalue + "," + value;
                }
                paramvalue.erase(0, 1);
                if (paramvalue.size() > 100) {
                    splitToMultilineToolTip(paramvalue, 100);
                }
            }
            sui->tawMCPendingParam->setToolTip(paramvalue);
        }
    }
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverLeft(int row)
{
    // When popup window shows up after clicking the pending parameter table row, focus goes out of the clicked row
    // and onPendingParameterHoverLeft event gets generated which makes this method called and clicked row becomes
    // un-highlighted. Do not apply HoverOffStyle to the selected row, so that the selected row will be remain selected
    // even after popup window shows up.
    if (m_selectedPendingParameterRowNum != row) {
        IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawMCPendingParam->getWidgetItem(row, 0));
    }
    sui->tawMCPendingParam->setToolTip("");
}

void IGSxGUI::MachineconstantsView::onPendingParameterClicked(int row)
{
    m_selectedPendingParameterRowNum = row;
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
    IGSxGUI::Util::processEvents();
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    if (parameterData != NULL) {
        if (parameterData->getValueType() == IGSxGUI::TYPE_floatarray) {
            std::pair <std::string, int> formattedText = formatFloatArrayDialogParamName(searchname);
            searchname = formattedText.first;
            m_floatArrayDialog.setParameterName(searchname);
            m_floatArrayDialog.setParent(sui->lneSearchParameterText);  // any widget can be passed
            m_floatArrayDialog.show();
        } else {
            std::pair <std::string, int> formattedText = formatDialogParamName(searchname);
            name = formattedText.first;
            m_parameterview.setParameterName(name);
            m_parameterview.setParent(sui->btnHistory);  // any widget can be passed
            if (parameterData->getValueType() == IGSxGUI::TYPE_boolean) {
                m_parameterview.setParameterDefaultValue(parameterData->getDefaultValue()->ToString());
                m_parameterview.setParameterValue(value, BOOL_TYPE_DIALOG);
                m_parameterview.show(BOOL_TYPE_DIALOG);
            } else {
                std::string def = parameterData->getDefaultValue()->ToString();
                adjustDoublePrecision(def);
                m_parameterview.setParameterDefaultValue(def);
                m_parameterview.setParameterValue(value, BOOL_TYPE_DIALOG == 0 ? 1 : 0);
                m_parameterview.show(BOOL_TYPE_DIALOG == 0 ? 1 : 0);
            }
        }
    }
    m_selectedPendingParameterRowNum = -1;
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
}

void IGSxGUI::MachineconstantsView::pendingParamApplyRowBehavior(int row)
{
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&MachineconstantsView::onPendingParameterClicked, this, row);
    usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterHoverEntered, this, row);
    usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterHoverLeft, this, row);
    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(row, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
    SUI::Button* button = dynamic_cast<SUI::Button*>(tabwidget);
    button->clicked = boost::bind(&MachineconstantsView::onPendingParameterRowClosePressed, this, row);
    button->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHovered, this, row);
    button->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHoverLeft, this, row);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHovered(int row)
{
    sui->tawMCPendingParam->getWidgetItem(row, 1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERED);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHoverLeft(int row)
{
    sui->tawMCPendingParam->getWidgetItem(row, 1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERLEFT);
}

void IGSxGUI::MachineconstantsView::onBackPressed()
{
    m_pMachineconstantsManager->navigateBack();
    if (sui->btnParameterName->isVisible()) {
        m_pMachineconstantsManager->sortParamsAscending();
    } else {
        m_pMachineconstantsManager->sortParamsDescending();
    }
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
}


void IGSxGUI::MachineconstantsView::onParameterTreeItemPressed(int rowNumber)
{
    std::string text = sui->tawParameterTree->getItemText(rowNumber, 0);
    text.erase(std::remove(text.begin(), text.end(), '\n'), text.end());
    m_pMachineconstantsManager->navigateToChild(text);
    if (sui->btnParameterName->isVisible()) {
        m_pMachineconstantsManager->sortParamsAscending();
    } else {
        m_pMachineconstantsManager->sortParamsDescending();
    }
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
    refreshPendingParameterList();
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1Clicked()
{
    onBreadCrumpClicked(0);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2Clicked()
{
    onBreadCrumpClicked(1);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3Clicked()
{
    onBreadCrumpClicked(2);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4Clicked()
{
    onBreadCrumpClicked(3);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5Clicked()
{
    onBreadCrumpClicked(4);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6Clicked()
{
    onBreadCrumpClicked(5);
}

void IGSxGUI::MachineconstantsView::onBreadCrumpClicked(int index)
{
    if (m_pMachineconstantsManager->getCurrentNodeName() != breadCrumpButtonList[index]->getText()) {
        if (index == 0) {
            m_pMachineconstantsManager->navigateToBreadCrum("Parameters");
        } else {
            m_pMachineconstantsManager->navigateToBreadCrum(breadCrumpButtonList[index]->getText());
        }
        if (sui->btnParameterName->isVisible()) {
            m_pMachineconstantsManager->sortParamsAscending();
        } else {
            m_pMachineconstantsManager->sortParamsDescending();
        }
        refreshTreeViewAndBreadCrums();
        refreshParameterList();
    }
}

void IGSxGUI::MachineconstantsView::refreshTreeViewAndBreadCrums()
{
    const std::vector<std::string>& breadCrumList =  m_pMachineconstantsManager->getBreadCrumTitles();
    if (breadCrumList.size() == 1) {
        sui->lblAllCategories->setVisible(true);
        sui->lblBackImage->setVisible(false);
        sui->btnBack->setVisible(false);
    } else {
        sui->lblAllCategories->setVisible(false);
        sui->lblBackImage->setVisible(true);
        sui->btnBack->setVisible(true);
    }
    this->m_breadCrumResizer->RepositionAll(breadCrumList);
    std::vector<std::string> childNodeTitles;
    m_pMachineconstantsManager->getChildNodeTitles(&childNodeTitles);
    int childNodeCount = static_cast<int>(childNodeTitles.size());
    if (childNodeCount == 0) {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        sui->tawParameterTree->setItemText(0, 0, "No Subcategories");
        IGSxGUI::Util::setRowHeight(sui->tawParameterTree, 0, ROW_HEIGHT);
    } else {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        for (int row = 0 ; row < childNodeCount - 1; ++row) {
            sui->tawParameterTree->appendRow();
        }
        for (int row = 0 ; row < sui->tawParameterTree->rowCount(); ++row) {
            if (childNodeTitles[row].length() > MAX_CHARS_OF_PARAMETERTREE_CELL) {
                std::string formattedText = formatParamaterCatogoryName(childNodeTitles[row]);
                sui->tawParameterTree->setItemText(row, 0, formattedText);
                IGSxGUI::Util::setRowHeight(sui->tawParameterTree, row, MULTILINE_ROW_HEIGHT);
            } else {
                sui->tawParameterTree->setItemText(row, 0, childNodeTitles[row]);
                IGSxGUI::Util::setRowHeight(sui->tawParameterTree, row, ROW_HEIGHT);
            }
        }
    }
    IGSxGUI::Util::clearSelection(sui->tawParameterTree);
}

void IGSxGUI::MachineconstantsView::busyIndicatorWindowClose()
{
    sui->gbxPendingParamSaveError->setVisible(true);
}

void IGSxGUI::MachineconstantsView::pendingParamRetrySave()
{
    sui->gbxPendingParamSaveError->setVisible(false);
    performPendingParamSaving();
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonPressed()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        showSearchEntriesParameter(false);
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        sui->lneSearchParameterText->clearText();
        break;
    }
    default:
        break;
    }
}

void IGSxGUI::MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage()
{
    updateParameterTable();
    sui->gbxPendingParamSaveError->setVisible(false);
    sui->gbxBI->setVisible(false);
}

void IGSxGUI::MachineconstantsView::performPendingParamSaving()
{
    sui->gbxBI->setVisible(true);
    std::vector<std::string> failedParameterNames;
    m_pMachineconstantsManager->saveUpdatedParameters(sui->lnePendingParamSaveName->getText(), sui->txaPendingParamSaveChangeReason->getText(), failedParameterNames);
    std::vector<int> pendingParamIndexesToBeRemoved;
    for (int rowcount = 0; rowcount < sui->tawMCPendingParam->rowCount(); ++rowcount) {
        SUI::Widget *pendingparamwidget = sui->tawMCPendingParam->getWidgetItem(rowcount, 0);
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 0);
        formatParamNameBack(pendingparamname);
        size_t pos = pendingparamname.find('(');
        if (pos != std::string::npos) {
            pendingparamname.erase(pos - 1, pendingparamname.size());
        }
        if (std::find(failedParameterNames.begin(), failedParameterNames.end(), pendingparamname) == failedParameterNames.end()) {
            pendingParamIndexesToBeRemoved.push_back(rowcount);
        }
    }
    for (int i = static_cast<int>(pendingParamIndexesToBeRemoved.size()) - 1; i > 0; --i) {
        bool pendingParamTableScrollBarVisibleBefore = false;
        if (!isPendingParamTableScrollBarVisible()) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[i]));
        } else {
            pendingParamTableScrollBarVisibleBefore = true;
        }
        sui->tawMCPendingParam->removeRows(pendingParamIndexesToBeRemoved[i], 1);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
    }
    if (static_cast<int>(pendingParamIndexesToBeRemoved.size()) > 0) {
        m_pendingParameterList.clear();
        if (sui->tawMCPendingParam->rowCount() == 1) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[0]));
            sui->tawMCPendingParam->setRowVisible(0, false);
            sui->lnePendingParamSaveName->clearText();
            sui->txaPendingParamSaveChangeReason->clearText();
            showSaveCancelButtons(false);
            showFinalSaveScreenItems(false);
            showNoPendingParameterScreen(true);
            sui->gbxPendingParamSaveError->setVisible(false);
            sui->gbxBI->setVisible(false);
            updateParameterTable();
        } else {
            bool pendingParamTableScrollBarVisibleBefore = false;
            if (!isPendingParamTableScrollBarVisible()) {
                moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[0]));
            } else {
                pendingParamTableScrollBarVisibleBefore = true;
            }
            sui->tawMCPendingParam->removeRows(pendingParamIndexesToBeRemoved[0], 1);
            if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
                adjustCancelSaveButtonGeometryUp();
            }
            for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
                pendingParamApplyRowBehavior(row);
                SUI::Widget *pendingparamwidget = sui->tawMCPendingParam->getWidgetItem(row, 0);
                std::string pendingparamName = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 0);
                std::string pendingparamValue = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 1);
                formatParamNameBack(pendingparamName);
                std::pair<std::string, std::string> nameValuePair(pendingparamName, pendingparamValue);
                m_pendingParameterList.push_back(nameValuePair);
            }
        }
    }
    sui->gbxPendingParamSaveError->setVisible(sui->tawMCPendingParam->isRowVisible(0));
}

std::string IGSxGUI::MachineconstantsView::formatParamaterCatogoryName(const std::string& name)
{
    std::vector<int> vec;
    // Identify the individual word indices
    for (size_t i = 1; i < name.size(); ++i) {
        if (::isupper(name[i]) != 0 && ::isupper(name[i - 1]) == 0) {
            vec.push_back(i);
        }
    }
    // Extract the individual words
    int start = 0;
    std::vector<std::string> tokens;
    for (size_t i = 0, numberOfCharacters = 0; i < vec.size(); ++i) {
        numberOfCharacters = vec[i] - start;
        tokens.push_back(name.substr(start, static_cast<int>(numberOfCharacters)));
        start = vec[i];
    }
    tokens.push_back(name.substr(start));
    // Split the complete paramtername into two lines
    size_t totalTokens = tokens.size();
    std::string temp = "";
    std::string str1 = "";
    std::string str2 = "";
    bool flag = true;
    for (size_t index = 0; index < totalTokens ; ++index) {
        temp += tokens[index];
        if ((temp.length() < MAX_CHARS_OF_PARAMETERTREE_CELL) && (flag)) {
            str1 = str1 + tokens[index];
            temp = str1;
        } else {
            str2 = str2 + tokens[index];
            temp = str2;
            flag = false;
        }
    }
    std::string strMultiLine = str1 + '\n' + str2;
    return strMultiLine;
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatPendingParamName(const std::string& name)
{
    SUI::Widget* widget = sui->tawMCPendingParam->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 545;
    return formatName(name, widget, "table", columnWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatParamName(const std::string& name)
{
    SUI::Widget* widget = sui->tawParameters->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 585;
    return formatName(name, widget, "table", columnWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatDialogParamName(const std::string& name)
{
    SUI::Label* label = m_parameterview.getParameterNameType();
    int labelWidth = 500;
    return formatName(name, dynamic_cast<SUI::Widget*>(label), "label", labelWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatFloatArrayDialogParamName(const std::string& name)
{
    SUI::Label* label = m_floatArrayDialog.getParameterNameType();
    int labelWidth = 500;
    return formatName(name, dynamic_cast<SUI::Widget*>(label), "label", labelWidth);
}

size_t IGSxGUI::MachineconstantsView::getSplitPosition(const std::string& name, SUI::Widget* widget, const std::string& type, int width)
{
    int total_chars_width = 0;
    for (size_t i = 0; i < name.size(); ++i) {
        std::string str(1, name[i]);
        if (type == "table") {
            total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 0);
        } else if (type == "label") {
            total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLabel(str, widget);
        }
        if (total_chars_width > width) {
            return i-1;
        }
    }
    return 0;
}

void IGSxGUI::MachineconstantsView::extractSubStr(std::size_t found,  int& num_of_rows, std::string& retname, std::string& tmpname)
{
    if (retname == "") {
        retname = tmpname.substr(0, found);
    } else {
        retname = retname + '\n' + tmpname.substr(0, found);
    }
    num_of_rows++;
    tmpname = tmpname.substr(found, tmpname.size());
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatName(const std::string& name, SUI::Widget* widget, const std::string& type, int width)
{
    size_t search_pos = getSplitPosition(name, widget, type, width);
    static std::string retname = "";
    static int num_of_rows = 1;
    std::string tmpname = name;
    if (search_pos == 0) {
        std::string ret = retname + '\n' + tmpname;
        if (retname == "") {
            ret = tmpname;
            num_of_rows = 1;
        }
        int rows = num_of_rows;
        retname = "";
        num_of_rows = 1;
        return std::make_pair(ret, rows);
    }
    std::size_t found = tmpname.rfind('/', search_pos);
    if (found == std::string::npos) {
        std::size_t found = tmpname.find_first_of('(');
        // found <= 3 is to avoid indefinite looping that may occur when we find the same character '(' repeatedly which is moved to tmpname
        // found > search_pos is found after search position which is consdered as not found
        if (found == std::string::npos || found > search_pos || found <= 3) {
            std::size_t found = tmpname.rfind('_', search_pos);
            if (found == std::string::npos) {
                int position = UpperCasePositionBackwards(tmpname, search_pos);
                // <= 3 is to avoid indefinite looping that may occur when we find the same UPPERCASE character repeatedly which is moved to tmpname
                if (position <= 3) {
                    extractSubStr(search_pos, num_of_rows, retname, tmpname);
                } else {
                    extractSubStr(position, num_of_rows, retname, tmpname);
                }
            } else {
                extractSubStr(found+1, num_of_rows, retname, tmpname);
            }
        } else {
            extractSubStr(found, num_of_rows, retname, tmpname);
        }
    } else {
        // we do not want the units of type "(x/y)" gets split at '/'
        // split at first '(' for units which have more than one '('
        std::size_t found2 = tmpname.find_first_of('(');
        if (found2 != std::string::npos && found2 < found) {
            found = found2;
            extractSubStr(found, num_of_rows, retname, tmpname);
        } else {
            extractSubStr(found+1, num_of_rows, retname, tmpname);
        }
    }
    return formatName(tmpname, widget, type, width);
}

int IGSxGUI::MachineconstantsView::UpperCasePositionBackwards(const std::string& name, int fromPos)
{
    for (int i = fromPos; i > 0; --i) {
        if (::isupper(name[i]) != 0 && ::isupper(name[i - 1]) == 0) {
            return i;
        }
    }
    return 0;
}

void IGSxGUI::MachineconstantsView::formatParamNameBack(std::string& name)
{
    while (true) {
        std::size_t pos = name.find('\n');
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            return;
        }
    }
}

void IGSxGUI::MachineconstantsView::adjustDoublePrecision(std::string& paramvalue)
{
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1, 1);
        }
    }
}

bool IGSxGUI::MachineconstantsView::isPendingParamTableScrollBarVisible()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    return (totalrowheight > PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT);
}

// adjusts the save and cancel buttons of pending parameter table by moving up when scroll bar gets removed due to removal of table rows
// so that the distance between buttons and table is maintained as per specs which is now 50
void IGSxGUI::MachineconstantsView::adjustCancelSaveButtonGeometryUp()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    SUI::Rect btnCancel = sui->btnCancel->getGeometry();
    SUI::Rect uctSaveButton = sui->uctSaveButton->getGeometry();
    int xCancel = btnCancel.getX();
    int widthCancel = btnCancel.getWidth();
    int heightCancel = btnCancel.getHeight();
    int xSave = uctSaveButton.getX();
    int widthSave = uctSaveButton.getWidth();
    int heightSave = uctSaveButton.getHeight();
    sui->btnCancel->setGeometry(xCancel, PENDING_PARAM_TABLE_YPOSITION+totalrowheight+PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE, widthCancel, heightCancel);
    sui->uctSaveButton->setGeometry(xSave, PENDING_PARAM_TABLE_YPOSITION+totalrowheight+PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE, widthSave, heightSave);
}

// adjusts the save and cancel buttons of pending parameter table by moving down when scroll bar gets added due to addition of table rows
// so that the distance between buttons and table is maintained as per specs which is now 50
void IGSxGUI::MachineconstantsView::adjustCancelSaveButtonGeometryDown()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount() - 1; ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    moveSaveCancelButtons(DOWN, PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT - totalrowheight);
}

void IGSxGUI::MachineconstantsView::sortParamsAscending()
{
    m_pMachineconstantsManager->sortParamsAscending();
    sui->btnParameterName2->setVisible(false);
    sui->btnParameterNameDownArrow->setVisible(false);
    sui->btnParameterName->setVisible(true);
    sui->btnParameterNameUpArrow->setVisible(true);
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
}

void IGSxGUI::MachineconstantsView::sortParamsDescending()
{
    m_pMachineconstantsManager->sortParamsDescending();
    sui->btnParameterName2->setVisible(true);
    sui->btnParameterNameDownArrow->setVisible(true);
    sui->btnParameterName->setVisible(false);
    sui->btnParameterNameUpArrow->setVisible(false);
    refreshTreeViewAndBreadCrums();
    refreshParameterList();
}

void IGSxGUI::MachineconstantsView::onBackHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBack, true);
}

void IGSxGUI::MachineconstantsView::onBackHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBack, false);
}

void IGSxGUI::MachineconstantsView::sortPendingParams()
{
    int rowcount = sui->tawMCPendingParam->rowCount();
    std::vector<std::pair<std::string, std::string> > pendingParams;
    for (int i = 0; i < rowcount; ++i) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(i, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        pendingParams.push_back(std::make_pair(name, IGSxGUI::Util::getTextFromParameterUserControl(widget, 1)));
    }
    if (sui->btnPendingParameterNameUpArrow->isVisible()) {
        std::sort(pendingParams.begin(), pendingParams.end(), desOrderPendingParam());
        sui->btnPendingParameterNameDownArrow->setVisible(true);
        sui->btnPendingParameterNameUpArrow->setVisible(false);
    } else {
        std::sort(pendingParams.begin(), pendingParams.end(), ascOrderPendingParam());
        sui->btnPendingParameterNameDownArrow->setVisible(false);
        sui->btnPendingParameterNameUpArrow->setVisible(true);
    }
    sui->btnPendingParameterNameUpDownArrow->setVisible(false);
    m_pendingParameterList.clear();
    for (int i = 0; i < rowcount; ++i) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(i, 0);
        std::pair <std::string, int> formattedText = formatPendingParamName(pendingParams.at(i).first);
        IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, i, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
        IGSxGUI::Util::setTextToParameterUserControl(widget, 1, pendingParams.at(i).second);
        std::pair<std::string, std::string> nameValuePair(pendingParams.at(i).first, pendingParams.at(i).second);
        m_pendingParameterList.push_back(nameValuePair);
    }
    IGSxGUI::Util::scrollToTop(sui->tawMCPendingParam);
}

void IGSxGUI::MachineconstantsView::formatParamValue(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        name.replace(i-1, name.size(), "...");
        while (formatParamValueAfterAddingDots(widget, name, columnWidth)) {}
    }
}

int IGSxGUI::MachineconstantsView::formatParamValueAfterAddingDots(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        size_t pos = name.find("....");  // after adding 3 dots there is possibility that the value will have 4 dots as the values are double
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            size_t pos = name.find("...");
            name.erase(pos-1, 1);
        }
        return 1;
    } else {
        size_t pos = name.find("....");
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        }
        return 0;
    }
}

void IGSxGUI::MachineconstantsView::splitToMultilineToolTip(std::string& value, size_t charCount)
{
    std::string retname = "";
    std::string tempstr = value;
    while (tempstr.size() > charCount) {
        size_t pos = tempstr.rfind(',', charCount);
        retname = retname + "\n" + tempstr.substr(0, pos+1);
        tempstr = tempstr.substr(pos+1, tempstr.size());
    }
    retname.erase(0, 1);
    value = retname + "\n" + tempstr;
}

std::string IGSxGUI::MachineconstantsView::getParameterData()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        return getParameterStr(m_pMachineconstantsManager->getParameterData());
    } else {
        return getParameterStr(m_matchedparameters);
    }
}

std::string IGSxGUI::MachineconstantsView::getParameterStr(std::vector<ParameterData*> t_parameterData)
{
    std::string text = "";
    for (size_t i = 0; i < t_parameterData.size(); ++i) {
        if ((t_parameterData[i]->isSelected() == true) && (!t_parameterData[i]->isReadOnly())) {
            std::string paramName = t_parameterData[i]->getDisplayName();
            text += "\""+ paramName + "\",";
            std::string value = t_parameterData[i]->getCurrentValue()->ToString();
            text += "\""+ value + "\",";
            text += "\n";
        }
    }
    return text;
}

void IGSxGUI::MachineconstantsView::replaceText(std::string &str, std::string from, std::string to)
{
    for (std::size_t index =0; (index = str.find(from, index))!= std::string::npos; ++index) {
        str.replace(index, from.length(), to);
        ++index;
    }
}

void IGSxGUI::MachineconstantsView::selectAllRows()
{
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        ParameterData* parameterData = getParameterDataForName(name);
        if (!parameterData->isReadOnly()) {
            IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
        }
    }
    std::vector<ParameterData*> parameterDataCollection = m_pMachineconstantsManager->getAllParameterData();
    if (sui->lneSearchParameterText->getText().empty()) {
        for (size_t i = 0; i < parameterDataCollection.size(); ++i) {
            parameterDataCollection[i]->setSelected(true);
        }
    } else {
        for (size_t i = 0; i < m_matchedparameters.size(); ++i) {
            m_matchedparameters[i]->setSelected(true);
        }
    }
    /*
        for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
            std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            formatParamNameBack(name);
            std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
            std::string fullName = "";
            if (vec.size() > 1) {
                vec.erase(vec.begin());
                std::string parameterCategory = boost::join(vec, "/");
                boost::trim(parameterCategory);
                fullName = parameterCategory + "/" + name;
            } else {
                fullName = name;
            }
            ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
            if (!parameterData->isReadOnly()) {
                parameterData->setSelected(true);
                IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
            }
        }
        */
}

void IGSxGUI::MachineconstantsView::setCtrlKeyPressed(bool isCtrlKeyPressed)
{
    m_isCtrlKeyPressed = isCtrlKeyPressed;
}

bool IGSxGUI::MachineconstantsView::isCtrlKeyPressed() const
{
    return m_isCtrlKeyPressed;
}
