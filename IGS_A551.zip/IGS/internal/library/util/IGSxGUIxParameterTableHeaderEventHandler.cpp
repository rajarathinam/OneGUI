#include "IGSxGUIxParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

IGSxGUIxParameterTableHeaderEventHandler::IGSxGUIxParameterTableHeaderEventHandler() {
}

void IGSxGUIxParameterTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);

    parameterNameAsc = dynamic_cast<QPushButton*>(baseWidget1->getWidget());
    parameterNameDes = dynamic_cast<QPushButton*>(baseWidget2->getWidget());
    upArrow = dynamic_cast<QPushButton*>(baseWidget3->getWidget());
    downArrow = dynamic_cast<QPushButton*>(baseWidget4->getWidget());

    parameterNameAsc->installEventFilter(this);
    parameterNameDes->installEventFilter(this);
    upArrow->installEventFilter(this);
    downArrow->installEventFilter(this);
}

void IGSxGUIxParameterTableHeaderEventHandler::mousePressed()
{
    parameterNameAsc->setStyleSheet("color:#FF7F45");
    parameterNameDes->setStyleSheet("color:#FF7F45");
    upArrow->setStyleSheet("color:#FF7F45");
    downArrow->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxParameterTableHeaderEventHandler::mouseReleased()
{
    parameterNameAsc->setStyleSheet("color:#1B3E93");
    parameterNameDes->setStyleSheet("color:#1B3E93");
    upArrow->setStyleSheet("color:#1B3E93");
    downArrow->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxParameterTableHeaderEventHandler::mouseEnter()
{
    parameterNameAsc->setStyleSheet("color:#B3E2FF");
    parameterNameDes->setStyleSheet("color:#B3E2FF");
    upArrow->setStyleSheet("color:#B3E2FF");
    downArrow->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxParameterTableHeaderEventHandler::mouseLeft()
{
    parameterNameAsc->setStyleSheet("color:#1B3E93");
    parameterNameDes->setStyleSheet("color:#1B3E93");
    upArrow->setStyleSheet("color:#1B3E93");
    downArrow->setStyleSheet("color:#1B3E93");
}

