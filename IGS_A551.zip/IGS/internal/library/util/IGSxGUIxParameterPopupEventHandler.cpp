#include "IGSxGUIxParameterPopupEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

IGSxGUIxParameterPopupEventHandler::IGSxGUIxParameterPopupEventHandler() {
}

void IGSxGUIxParameterPopupEventHandler::installEvents(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    m_lneEdit = dynamic_cast<QLineEdit*>(baseWidget->getWidget());
    m_lneEdit->installEventFilter(this);
}

void IGSxGUIxParameterPopupEventHandler::selectLineEditText()
{
    m_lneEdit->selectAll();
}
