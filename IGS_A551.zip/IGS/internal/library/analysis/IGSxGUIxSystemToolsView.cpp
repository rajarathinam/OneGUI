﻿/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsView.cpp
| Author       : Venugopal S
| Description  : Implementation of SystemTools view
|
| ! \file        IGSxGUIxSystemToolsView.cpp
| ! \brief       Implementation of SystemTools view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxSystemToolsView.hpp"
#include <string>
#include <vector>
#include "IGSxGUIxMoc_SystemToolsView.hpp"
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxUtils/SUITimer.h>
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::SystemToolsView::TIMER_INTERVAL = 4000;
const std::string IGSxGUI::SystemToolsView::SYSTEMTOOL = "Machine Based Diagnostic System";
const std::string IGSxGUI::SystemToolsView::TOOL_STARTED = "Machine Based Diagnostic System has started";
const std::string IGSxGUI::SystemToolsView::TOOL_NOT_AVAILABLE = "Machine Based Diagnostic System is not available";
const std::string IGSxGUI::SystemToolsView::SYSTEMTOOLS_LOAD_FILE = "IGSxGUIxSystemTools.xml";
const std::string IGSxGUI::SystemToolsView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const std::string IGSxGUI::SystemToolsView::STRING_EMPTY = "";

IGSxGUI::SystemToolsView::SystemToolsView(SystemToolsManager *pSysToolManager) :
    sui(new SUI::SystemToolsView),
    m_manager(pSysToolManager),
    m_bActivePage(false),
    m_timer(SUI::Timer::createTimer())
{
    m_timer->setInterval(TIMER_INTERVAL);
    m_timer->timeout = boost::bind(&SystemToolsView::on_timeout, this);
}

IGSxGUI::SystemToolsView::~SystemToolsView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SystemToolsView::show(SUI::Container *MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(SYSTEMTOOLS_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    init();
}

void IGSxGUI::SystemToolsView::setActive(bool bActive)
{    
    m_bActivePage = bActive;
}

void IGSxGUI::SystemToolsView::setHandlers()
{
    sui->btnOpenSystemTool->clicked = boost::bind(&SystemToolsView::onOpenSystemToolClicked, this);
}

void IGSxGUI::SystemToolsView::init()
{
    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
    sui->tawSystemTool->showGrid(false);

    SUI::Widget *widget = sui->tawSystemTool->getWidgetItem(0, 0);
    IGSxGUI::Util::setSystemToolUCTNormalStyle(widget);

    IGSxGUI::Util::setTextToSystemToolUserControl(widget, 0, SYSTEMTOOL);
    IGSxGUI::Util::setTextToSystemToolUserControl(widget, 1, STRING_EMPTY);
    IGSxGUI::Util::setSystemToolUCTClickedStyle(sui->tawSystemTool->getWidgetItem(0, 0));


    if (m_manager->isMbdsViewerAvailable()) {
        if (m_timer->isActive()) {
            sui->btnOpenSystemTool->setEnabled(false);
            sui->lblMessage->setVisible(true);
            sui->lblMessage->setText(TOOL_STARTED);
        } else {
            sui->btnOpenSystemTool->setEnabled(true);
            sui->lblMessage->setVisible(false);
        }
    } else {
        sui->btnOpenSystemTool->setEnabled(false);
        sui->lblMessage->setVisible(true);
        sui->lblMessage->setText(TOOL_NOT_AVAILABLE);
    }
}

void IGSxGUI::SystemToolsView::onOpenSystemToolClicked()
{
    sui->lblMessage->setVisible(true);

    m_manager->startMbdsViewer();
    m_timer->start();
    sui->lblMessage->setText(TOOL_STARTED);
    sui->btnOpenSystemTool->setEnabled(false);
}

void IGSxGUI::SystemToolsView::on_timeout()
{
    if(m_bActivePage) {
        sui->lblMessage->setText(STRING_EMPTY);
        sui->btnOpenSystemTool->setEnabled(true);
    }
    m_timer->stop();
}
