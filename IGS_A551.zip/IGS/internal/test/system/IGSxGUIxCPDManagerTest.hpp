/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManagerTest.hpp
| Author       : Venugopal S
| Description  : Header file for CPD Manager test
|
| ! \file        IGSxGUIxCPDManagerTest.hpp
| ! \brief       Header file for CPD Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDMANAGERTEST_HPP
#define IGSXGUIXCPDMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <string>
#include "IGSxGUIxCPDManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class CPDManagerTest : public ::testing::Test
{
 public:
    CPDManagerTest() : m_cpdManager(NULL){}
    virtual ~CPDManagerTest(){}

 protected:
    IGSxGUI::CPDManager* m_cpdManager;

  virtual void SetUp()
  {
     m_cpdManager = new IGSxGUI::CPDManager();

     IGSxCPD::MetaDescriptions cpdDescriptions;
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDFFMDFC", "Calibration", "FinalFocusMetrology", "CPD FFM Default Filter Calibration", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html"));
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPD_CODMCL", "Performance", "Cleaning", "Collector and Metrology Cleaning CPD", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPD_CODMCL/CPD_CODMCL_description.html"));
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDDGSABC", "Calibration", "DropletGeneratorSteering", "DGS Actuator Basis Calibration", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSABC/CPDDGSABC_description.html"));
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("LDN_HPSNLC", "Diagnostics", "HighPowerSeed", "LDN_HPSNLC test", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/LDN_HPSNLC/LDN_HPSNLC_description.html"));
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("CPDDGSESI", "Diagnostics", "DropletGeneratorSteering", "DGSS Encoder Loop System Identification", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSESI/CPDDGSESI_description.html"));
     cpdDescriptions.push_back(IGSxCPD::MetaDescription("FDD_DUMREG", "Calibration", "FinalFocusAssembly", "FDD_DUMREG test", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/FDD_DUMREG/FDD_DUMREG_description.html"));

     for (size_t i = 0; i < cpdDescriptions.size(); i++)
     {
         IGSxGUI::CPD* cpd = new IGSxGUI::CPD(cpdDescriptions[i]);
         m_cpdManager->add(cpd);
     }
  }

  virtual void TearDown()
  {
    std::vector<IGSxGUI::CPD*> cpdList = m_cpdManager->retrieveAll();
    for (size_t i = 0; i < cpdList.size(); i++)
    {
        m_cpdManager->remove(cpdList[i]);
    }

    delete m_cpdManager;
    m_cpdManager = NULL;
  }
};
#endif  // IGSXGUIXCPDMANAGERTEST_HPP
