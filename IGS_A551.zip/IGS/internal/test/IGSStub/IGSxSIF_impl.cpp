/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSIF_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxSIF interface
|
| ! \file        IGSxSIF_impl.cpp
| ! \brief       Stub impementation of IGSxSIF interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxSIF_impl.hpp"
#include <iostream>
#include <FWQxUtils/SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxSIF::SIF *IGSxSIF::SIF_Stub::getInstance()
{
    static SIF_Stub _instance;
    return &_instance;
}

IGSxSIF::SIF* IGSxSIF::SIF::instance = IGSxSIF::SIF_Stub::getInstance();

IGSxSIF::SIF_Stub::SIF_Stub():
    m_counter(0)
{
}

bool IGSxSIF::SIF_Stub::isMbdsViewerAvailable()
{
    ++m_counter;

    if (m_counter % 3 == 0) {
        return false;
    } else {
        return true;
    }
}

bool IGSxSIF::SIF_Stub::startMbdsViewer()
{
    std::cerr << "MBDS : Started" << std::endl;
    return true;
}
