/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMView.hpp
| Author       : Saket K
| Description  : Header file for System state manager View
|
| ! \file        IGSxGUIxSSMView.hpp
| ! \brief       Header file for SSM View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMSTATEMANAGERVIEW_HPP
#define IGSXGUIXSYSTEMSTATEMANAGERVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <IGSxGUIxISSMView.hpp>
#include <IGSxGUIxSSMState.hpp>
#include <IGSxGUIxSSMManager.hpp>
#include <IGSxGUIxSSMPresenter.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SSMView;
class Container;
}

namespace IGSxGUI{
class SSMTabView;

class SSMView : public ISSMView
{

 public:
    explicit SSMView(SSMManager &ssmManager);
    virtual ~SSMView();
    virtual void show(SUI::Container*, bool);
    virtual void setActive(bool bActive);
    virtual SUI::Container* getContainer();
private:
    void indexChanged(int index);
    void buttonClicked();
    void showTab(TabType tab);
    void refreshContainers();
    void resetAllTabs();
    void update();
    void setTabIcon();

    SUI::SSMView *sui;
    SSMPresenter* m_SSMPresenter;
    SSMManager& m_SSMManager;
    static const std::string SYSTEMSTATEMANAGER_VIEW_LOAD_FILE;
    static const std::string IMAGE_LOGO;
    std::vector<SUI::Container*> containers;
    SUI::Container* currentContainer;

    SSMTabView* m_Tab1;
    SSMTabView* m_Tab2;
    SSMTabView* m_Tab3;
    SSMTabView* m_Tab4;
    SSMTabView* m_Tab5;
    SSMTabView* m_Tab6;
    IGSxGUI::TabType m_currentTab;
    bool m_Active;
};

}

#endif
