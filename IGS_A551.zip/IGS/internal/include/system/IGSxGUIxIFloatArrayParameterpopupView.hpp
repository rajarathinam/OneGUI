#ifndef IGSXGUIXIFLOATARRAYPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXIFLOATARRAYPARAMETERPOPUPVIEW_HPP


/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIContainer.h>
#include <string>
#include "IGSxCOMMON.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IFloatArrayParameterpopupView
{
 public:
    IFloatArrayParameterpopupView() {}
    virtual ~IFloatArrayParameterpopupView() {}
    virtual void show() = 0;
};
}  // namespace IGSxGUI
#endif // IGSXGUIXIFLOATARRAYPARAMETERPOPUPVIEW_HPP
