#ifndef IGSXGUIXHISTORYPOPUPVIEW_HPP
#define IGSXGUIXHISTORYPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include <vector>
#include <utility>
#include <map>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxIHistoryCallback.hpp"
#include "IGSxGUIxIHistorypopupView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI
{
class HistorypopupView;
}  // namespace SUI

namespace IGSxGUI
{
class SortedByColumn
{
 public:
    typedef enum
    {
        None,
        ParameterName,
        ChangedOn,
        ChangedBy,
        Reason
    } SortedColumEnum;
};


class HistorypopupView : public IHistorypopupView, public IHistoryCallBack
{
   public:
    explicit HistorypopupView(IGSxGUI::MachineconstantsManager* machineConstantsManager);
    virtual ~HistorypopupView();
    virtual void show();

    void onUCTCloseHistoryClicked();
    void onUCTCloseHistoryPressed();
    void onUCTCloseHistoryHoverOn();
    void onUCTCloseHistoryHoverOff();

    void onParameterNameHeaderClicked();
    void onChangedOnHeaderClicked();
    void onChangedByHeaderClicked();
    void onReasonHeaderClicked();

    void onParameterHistoryHoverEntered(int);
    void onParameterHistoryHovLeft(int);
    void onParameterHistoryClicked(int);

    void setParent(SUI::Widget *parent);
    void initializeTableRows(IGSxGUI::ParameterHistoryVector collection);
    void populateData(std::vector<ParameterHistory>::iterator it, int row);
    void onValueChanged();
    void onSearchTextEdited(const std::string &text);
    void onSearchTextEditFinished();
    void onSearchClearPressed();
    void onSearchClearHoverLeft();
    void onSearchClearHoverEntered();
    void calculateTotalRowHeight(std::vector<ParameterHistory> collection, int& totalRowHeight, int& max_rows);
    void setValuesToScrollbar(bool visibility, int minValue, int maxValue, int actualValue);
    void calculateTotalRowHeightUtility(std::vector<ParameterHistory> collection, int &totalRowHeight, int &max_rows, int i);
    void selectAllRows();
    void setCtrlKeyPressed(bool isCtrlKeyPressed);
    std::string getParameterHistoryData();
private:
    HistorypopupView(const HistorypopupView &);
    HistorypopupView& operator=(const HistorypopupView &);
    void init();
    void getData();
    void arrangeTableData(ParameterHistoryVector &tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder);
    IGSxGUI::MachineconstantsManager *m_machineConstantsManager;
    IGSxGUI::ParameterHistoryVector m_historyData;
    IGSxGUI::ParameterHistoryVector m_matchedparameters;
    SUI::HistorypopupView *sui;
    int m_selectedHistoryRowNum;
    int m_lastIndex;
    bool m_isCtrlKeyPressed;
    std::string m_searchText;
    IGSxGUI::SortOrder::SortOrderEnum m_paramNameOrder;
    IGSxGUI::SortOrder::SortOrderEnum m_changedOnOrder;
    IGSxGUI::SortOrder::SortOrderEnum m_changedByOrder;
    IGSxGUI::SortOrder::SortOrderEnum m_reasonOrder;
    IGSxGUI::SortOrder::SortOrderEnum m_currentOrder;

    IGSxGUI::SortedByColumn::SortedColumEnum m_currentSortedColumn;

    typedef bool (*FPTR)(IGSxGUI::ParameterHistory, IGSxGUI::ParameterHistory);
    std::map<int, std::vector<FPTR> > m_sortFunctionMap;

    static const int ROW_HEIGHT;
    static const int BUTTON_SIZE;
    static const int SORT_ICON_SIZE;
    static const size_t MAX_CHARS_OF_PARAMS_PER_LINE;
    static const int MULTILINE_ROW_HEIGHT_INCREASE;
    static const int MAX_VISIBLE_ROWS;
    static const int MAX_VISIBLE_ROWS_TOTAL_HEIGHT;

    static const int IMAGE_WIDTH;
    static const int WIDGET_HEIGHT;


    static const int CONSTANT_ZERO;
    static const int PARAMNAME_WIDTH_BEFORE_SORTING;
    static const int PARAMNAME_WIDTH_AFTER_SORTING;
    static const int CHANGEDON_WIDTH_BEFORE_SORTING;
    static const int CHANGEDON_WIDTH_AFTER_SORTING;
    static const int CHANGEDBY_WIDTH_BEFORE_SORTING;
    static const int CHANGEDBY_WIDTH_AFTER_SORTING;
    static const int REASON_WIDTH_BEFORE_SORTING;
    static const int REASON_WIDTH_AFTER_SORTING;

    static const int TOOLTIP_WIDTH;
    static const std::string STRING_NEWLINE;
    static const std::string STRING_EMPTY;

    static const std::string HISTORYPOPUPVIEW_LOAD_FILE;
    static const std::string STRING_HISTORYPOPUPVIEW_SHOWN;
    static const std::string STRING_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETERS_FOUND;
    static const std::string STRING_PARAMETERNAME;
    static const std::string STRING_CHANGEDON;
    static const std::string STRING_CHANGEDBY;
    static const std::string STRING_REASON;

    static const int AWESOME_CLOSE_SIZE;
    static const std::string STRING_GREY_REGULAR;
    static const std::string STRING_BLUE_REGULAR;
    static const std::string STRING_BLUE_HEADER;

    static const std::string STYLE_AWESOME_ICONCOLOR;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STYLE_ASML_ORANGELABEL;
    static const std::string STYLE_SEARCH_PARAMETER;
    static const std::string STYLE_SEARCHPARAM_NOITALIC;
    static const std::string STYLE_ACTIVE_CPDLABEL_BLACK;
    static const std::string STYLE_HOVERON;
    static const std::string STYLE_HISTORY_SELECTED_HEADER;
    static const std::string STYLE_HISTORY_NORMAL_HEADER;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    void applyDataAndStyles(int rowIndex);
    std::pair<std::string, int> getFormattedsParamNameAndCalculateLineCount(const std::string &name);
    int UpperCasePosition(const std::string &name);
    void setData(int value, int rows, std::vector<ParameterHistory> collection);
    void setUCTHandlers(SUI::Widget *widget, int row);
    void setTableRows(int value, std::vector<ParameterHistory> collection);
    void refreshParameterList();
    void showSearchEntriesParameter(bool bShow);
    int searchForParameters(const std::string &textToSearch, std::vector<ParameterHistory> &matchedparameters);
    void extractSubStr(std::size_t found, int &num_of_rows, std::string &retname, std::string &tmpname);
    void calculateTotalRowHeightReverse(int rows, std::vector<ParameterHistory> collection, int &totalRowHeight, int &max_rows);
    void setDataReverse(int endIndex, std::vector<ParameterHistory> collection);
    void adjustTableRowVisibility(SUI::TableWidget *tablewidget, int numberOfRows);
    int numberOfRowsVisisble(SUI::TableWidget *tablewidget);
    void setHandlers();
    void createMaxVisibleRows(SUI::TableWidget *tableWidget, int numberOfRows);
    void sortCollection(IGSxGUI::ParameterHistoryVector &tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder, SUI::Label *label);
    void createSortingMap();
    std::string getFullReasonFromHistoryData(std::string& paramName, std::string& oldvalue,  \
                                                                        std::string& newvalue,  std::string& changedby, \
                                                                         std::string& timeStr);
    void formatParamNameBack(std::string &name);
    std::string formatToolTipText(const std::string &inStr, int width);
    std::pair<std::string, int> formatNameAndCalculateLineCount(const std::string &name, SUI::Widget *widget, int width);
    size_t getSplitPosition(const std::string &name, SUI::Widget *widget, int width);
    int getPositionOfLastUpperCaseCharacter(const std::string &name, int fromPos);
    std::string formatToolTipTextUtil(const std::string &inStr, int width);
    std::vector<IGSxGUI::ParameterHistory>::iterator getParameterHistorySelectionForRow(int row);
    std::vector<IGSxGUI::ParameterHistory>::iterator findParameterHistory(IGSxGUI::ParameterHistory t_ParameterHistory);
    bool isParameterHistoryDataSelected(int row);
    std::string getParameterHistoryStr(IGSxGUI::ParameterHistoryVector &t_historyData);
    void replaceText(std::string& str, std::string from, std::string to);
};
}  // namespace IGSxGUI
#endif // IGSXGUIXHISTORYPOPUPVIEW_HPP
