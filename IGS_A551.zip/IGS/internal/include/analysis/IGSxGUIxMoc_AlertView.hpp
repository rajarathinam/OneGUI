/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_AlertView.hpp
| Author       : Raja A
| Description  : Header file for Alert Viewer
|
| ! \file        IGSxGUIxMoc_AalertView.hpp
| ! \brief       Header file for Alert Viewer
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_ALERTVIEW_HPP
#define IGSXGUIXMOC_ALERTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class AlertView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class TableWidget;
class Label;
class Button;
class UserControl;
class GraphicsView;
class AlertView
{
 private:
    AlertView();
    void setupSUI(const char *XMLFileName);
    void setupSUIContainer(const char *xmlFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    Dialog *dialog;
    TableWidget *tawAlert;
    Label *lblAlertHeader;
    Button *btnNoAlerts;
    Label *lblHeaderBottom;
    UserControl *uctSeverity;
    Label *lblSeverity;
    Label *lblSeverityImage;
    UserControl *uctTimeReported;
    Label *lblTimeReported;
    Label *lblTimeReportedImage;
    UserControl *uctCode;
    Label *lblCode;
    Label *lblCodeImage;
    Button *btnMessage;
    Label *lblalarms;
    Label *lblerrors;
    Label *lblwarnings;
    Label *lblalarmsimage;
    Label *lblerrorsimage;
    Label *lblwarningsimage;
    GraphicsView *imvLogo;


    friend class ::IGSxGUI::AlertView;
};
}  // namespace SUI
#endif // IGSXGUIXMOC_ALERTVIEW_HPP
