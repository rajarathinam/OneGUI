/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxISystemToolsView.hpp
| Author       : Venugopal S
| Description  : Interface file for System tools view
|
| ! \file        IGSxGUIxISystemToolsView.hpp
| ! \brief       Interface file for System tools view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISYSTEMTOOLSVIEW_HPP
#define IGSXGUIXISYSTEMTOOLSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class ISystemToolsView
{
 public:
    ISystemToolsView() {}
    virtual ~ISystemToolsView() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXISYSTEMTOOLSVIEW_HPP
