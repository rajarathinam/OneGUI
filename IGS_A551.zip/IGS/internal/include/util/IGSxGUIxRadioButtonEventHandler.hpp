#ifndef IGSXGUIXRADIOBUTTONEVENTHANDLER_H
#define IGSXGUIXRADIOBUTTONEVENTHANDLER_H

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QRadioButton>
#include <SUIBaseWidget.h>
#include <SUIRadioButtonImpl.h>
#include <string>
#include <vector>

class IGSxGUIxRadioButtonEventHandler : public QObject
{
    Q_OBJECT
 public:
    IGSxGUIxRadioButtonEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void trueRbtnHoverEntered();
    void falseRbtnHoverEntered();
    void trueRbtnHoverLeft();
    void falseRbtnHoverLeft();
    void trueRbtnPressed();
    void falseRbtnPressed();
    void trueRbtnReleased();
    void falseRbtnReleased();
 protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString rbtn = object->objectName();
        if (mouseEvent->type() == QEvent::Enter) {
            if (rbtn == "rbtnParamTrue") {
                trueRbtnHoverEntered();
            } else {
                falseRbtnHoverEntered();
            }
        }
        if (mouseEvent->type() == QEvent::Leave) {
            if (rbtn == "rbtnParamTrue") {
                trueRbtnHoverLeft();
            } else {
                falseRbtnHoverLeft();
            }
        }
        if (mouseEvent->type() == QEvent::MouseButtonPress) {
            if (rbtn == "rbtnParamTrue") {
                trueRbtnPressed();
            } else {
                falseRbtnPressed();
            }
        }
        if (mouseEvent->type() == QEvent::MouseButtonRelease) {
            if (rbtn == "rbtnParamTrue") {
                trueRbtnReleased();
            } else {
                falseRbtnReleased();
            }
        }
        return object->eventFilter(object, event);
    }

 private:
    QRadioButton* trRbtn;
    QRadioButton* faRbtn;

    static const std::string radiobutton_12px_normal;
    static const std::string radiobutton_12px_normal_fill;
    static const std::string radiobutton_12px_hover;
    static const std::string radiobutton_12px_hover_fill;
    static const std::string radiobutton_12px_pressed;
    static const std::string radiobutton_12px_pressed_fill;
};
#endif  // IGSXGUIXRADIOBUTTONEVENTHANDLER_H
