#ifndef IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
#define IGSXGUIXFLOATARRAYEVENTHANDLER_HPP

#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>
#include <vector>
#include <string>

class IGSxGUIxFloatArrayEventHandler : public QObject
{
    Q_OBJECT
 public:
    explicit IGSxGUIxFloatArrayEventHandler(QObject *parent = 0);
    void setWidgetVector(std::vector<SUI::Widget*> widgetVector, std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector);
    void setTableWidget(SUI::TableWidget *tableWidget);

    void focusNextWidget();
    void focusPreviousWidget();

    void focusUtil(int index);
    void setDefaultStyleToFloatArrayButtons();
    void showXButtonutil(bool isKeyNavigation);
    void setErrorFoundFlag(bool *errorFound);
    void setCurrentIndex(int *currentIndex);
    void showXButton();
protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QString objname = object->objectName();
        std::string objName = objname.toStdString();
        if (event->type() == QEvent::KeyPress) {
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            int key = keyEvent->key();
            switch (key) {
            case Qt::Key_Backtab:
                focusPreviousWidget();
                showXButtonForKeyNavigation();
                return true;
            case Qt::Key_Tab:
                if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                    focusPreviousWidget();
                    showXButtonForKeyNavigation();
                } else {
                    focusNextWidget();
                    showXButtonForKeyNavigation();

                }
                return true;
            default:
                return object->eventFilter(object, event);
            }
        } /*else if (event->type() == QEvent::MouseButtonPress && objName != "Dialog") {
            showXButton();
        } else if (event->type() == QEvent::MouseButtonDblClick && objName != "Dialog") {
            selectLineEditText();
        }
        return object->eventFilter(object, event);*/
        else if (event->type() == QEvent::MouseButtonPress && objName != "Dialog") {
           showXButton();
           return true;
           }
        else if (event->type() == QEvent::MouseButtonDblClick && objName != "Dialog") {
           selectLineEditText();
           return true;

       }
       return object->eventFilter(object, event);

    }
 private:
    int *m_currentIndex;
    int totalWidgetCount;
    bool *isErrorFound;
    bool m_enableIndex;
    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    QWidget* btnUpdate;
    QWidget* btnCancel;
    QWidget* btnReset;
    QString buttonStylesheet;
    QString lineEditStylesheet;
    std::vector<SUI::Widget *> m_widgetVector;
    std::vector<SUI::Widget *> m_lineEditWidgetVector;
    std::vector<SUI::Widget *> m_clearButtonWidgetVector;
    void setWidgetsToDefaultStyle();
    void showXButtonForMouseClick(std::string objName);
    int getCurrentFocusedLineEditIndex();
    void showXButtonForKeyNavigation();
    void selectLineEditText();
};
#endif  // IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
