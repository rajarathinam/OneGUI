/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.hpp
| Author       : Raja A
| Description  : Header file for ADT view
|
| ! \file        IGSxGUIxADTView.hpp
| ! \brief       Header file for ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTVIEW_HPP
#define IGSXGUIXADTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxIADTView.hpp"
#include "IGSxGUIxADTPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class ADTView;
class Label;
class Button;
class UserControl;
class Timer;
}  // namespace SUI

namespace IGSxGUI{

struct structContainer
{
    std::string name;
    ADT* adt;

    structContainer() : name(""), adt(NULL)
    {
    }
};
typedef structContainer container;

struct structSubsystemCount
{
    std::string nameSubsystem;
    int count;

    structSubsystemCount() : nameSubsystem(""), count(0)
    {
    }
};
typedef structSubsystemCount subSystemCount;

class ADTView : public IADTView
{
 public:
    explicit ADTView(ADTManager *pADTManager);
    virtual ~ADTView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const IGS::Result& result);
    virtual void setActive(bool bActive);

 private:
    ADTView(const ADTView &);
    ADTView& operator=(const ADTView &);

    void init();
    void reload();
    void setHandlers();
    void loadADTTable();
    void loadSubSystems();
    void onOpenADTClicked();
    void EnableCountLabels();
    void onSubsystemPressed();
    void DisableCloseButtons();
    void onDescriptionClicked();
    void onDescriptionHoverLeft();
    void onSubSystemClosePressed();
    void onShowADTStartingTimeout();
    void onDescriptionHoverEntered();
    std::vector<ADT*> getSelectedSubSystemADTs();
    void onADTUCTHoverLeft(int index);
    void showHTMLReport(bool isVisible);
    void onADTUCTHoverEntered(int index);
    void onTableADTRowPressed(int rowindex);
    void populateADTTable(std::vector<ADT*>);
    void insertCountLabelAndCloseButton(size_t i);
    void setDescriptionPaneVisible(bool visibility);
    void showADTDetailsPage(bool isVisible, const std::string& adtName);
    void setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount);

    SUI::ADTView *sui;
    ADTPresenter *m_presenter;

    std::vector<ADT*> m_listADT;
    std::vector<ADT*> m_listSubsystemADTs;
    std::vector<IGSxGUI::container> m_listSubsystems;
    std::vector<IGSxGUI::subSystemCount> m_listSubsystemCount;
    std::vector<SUI::UserControl*>  m_usercontrols;

    bool m_bRunningADT;
    std::string m_selectedSubSystem;
    int m_selectedSubsystemRowNum;
    std::string m_selectedAdt;
    int m_selectedAdtRowNum;
    bool m_isDescFolded;
    bool m_isCloseButtonPressed;
    bool m_isInternalCallToSubsystemPressed;
    boost::shared_ptr<SUI::Timer> m_startingAdtTimer;

    static const std::string STRING_ALL_ADTS;
    static const std::string ADTVIEW_LOAD_FILE;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STYLE_ASML_ORANGEBUTTON;
    static const std::string STYLE_ASML_DARKBLUEBUTTON;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STRING_EMPTY;
    static const std::string STRING_SLASH;
    static const std::string STRING_ADTVIEW_SHOWN;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STRING_ADTSUBSYSTEM_STYLE;
    static const std::string CUSTOM_STYLESHEET;
    static const std::string STRING_SINGLESPACE;
    static const char NEWLINE_CHAR;
    static const std::string STRING_ADT_ALREADY_RUNNING;
    static const std::string STRING_ADT_SHOWING;
    static const char* STRING_ADT_MESSAGE;
    static const int ADTSUBSYSTEM_CLOSEBUTTON_SIZE;
    static const int AWESOME_ANGLE_SIZE;
    static const int ADTTABLE_ROW_SIZE;
    static const int NORMAL_SUBSYSTEM_ROW_SIZE;
    static const int EXTENDED_SUBSYSTEM_ROW_SIZE;
    static const int MAX_SUBSYSTEM_CHARS_PER_CELL;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADTVIEW_HPP
