

/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIMachineconstantsView.hpp
| Author       : Raja
| Description  : Interface file for Machineconstants View
|
| ! \file        IGSxGUIxIMachineconstantsView.hpp
| ! \brief       Interface file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXIMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxCOMMON.hpp"
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IMachineconstantsView
{
 public:
    IMachineconstantsView() {}
    virtual ~IMachineconstantsView() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void updateStatus(const std::string& strCPD, const IGS::Result& result) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI

#endif // IMACHINECONSTANTSVIEW_H
