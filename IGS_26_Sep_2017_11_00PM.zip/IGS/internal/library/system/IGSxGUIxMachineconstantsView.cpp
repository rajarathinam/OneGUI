/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include "IGSxLOG.hpp"
#include <SUIButton.h>
#include <SUITableWidget.h>
#include <IGSxGUIxUtil.hpp>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";

IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager */*pMachineconstantsManager*/):
    sui(new SUI::MachineconstantsView)
{

}


IGSxGUI::MachineconstantsView::~MachineconstantsView()
{

}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{

      if (sui != NULL)
       {
           sui->setupSUIContainer("IGSxGUIxMachineconstants.xml", MainScreenContainer);
       }

  init();
  IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::updateStatus(const std::string &, const IGS::Result &/*result*/)
{

}

void IGSxGUI::MachineconstantsView::setActive(bool /*bActive*/)
{

}

void IGSxGUI::MachineconstantsView::init()
{
   sui->tawParameters->insertRows(1,20000);
   sui->btnParameterName->hoverEntered = boost::bind(&MachineconstantsView::onParameterNameHoverEntered, this);
   sui->btnParameterName->hoverLeft = boost::bind(&MachineconstantsView::onParameterNameHoverLeft, this);

}

void IGSxGUI::MachineconstantsView::onParameterNameHoverEntered()
{
   IGSxGUI::Util::setUnderline(sui->btnParameterName, true);
}\
void IGSxGUI::MachineconstantsView::onParameterNameHoverLeft()
{
   IGSxGUI::Util::setUnderline(sui->btnParameterName, false);
}





