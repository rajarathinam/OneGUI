/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIManager.cpp
| Author       : Sabari Chandra Sekar
| Description  : KPI manager Implementation
|
| ! \file        IGSxKPIManager.cpp
| ! \brief       KPI Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <string>
#include <vector>
#include <SUIResourcePath.h>
#include "IGSxGUIxKPIManager.hpp"
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const string IGSxGUI::KPIManager::KPI_WHITELIST_FILE = "IGSxGUIxKPIWhitelist.xml";

const string IGSxGUI::KPIManager::STRING_KPI = "KPI";
const string IGSxGUI::KPIManager::STRING_KPIS = "KPIs";
const string IGSxGUI::KPIManager::STRING_EMPTY = "";
const string IGSxGUI::KPIManager::STRING_SYSTEMKPI = "System";
const string IGSxGUI::KPIManager::STRING_CONSUMABLE = "Consumable";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_NAME = "<xmlattr>.name";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_VALUESET = "<xmlattr>.valueset";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_TYPE = "<xmlattr>.type";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_DISPLAYNAME = "<xmlattr>.unit";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_FACTOR = "<xmlattr>.factor";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_MIN = "<xmlattr>.min";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_MAX = "<xmlattr>.max";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_POSITION = "<xmlattr>.position";
const string IGSxGUI::KPIManager::STRING_NO_KPIS_FOUND = "Kpi definition not found: ";

const int IGSxGUI::KPIManager::TIMER_INTERVAL = 10000;
const int IGSxGUI::KPIManager::TIME_SIX_HOURS = 21600;
const int IGSxGUI::KPIManager::AMOUNT_OF_SECONDS_IN_MINUTE = 60;

IGSxGUI::KPIManager::KPIManager():
    m_timer(SUI::Timer::createTimer())
{
    m_timer->timeout = boost::bind(&KPIManager::onTimeout, this);
}

IGSxGUI::KPIManager::~KPIManager()
{
    m_timer->stop();

    for (std::vector<KPI*>::iterator it = m_KPIs.begin() ; it != m_KPIs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    for (std::vector<KPI*>::iterator it = m_SystemKPIs.begin() ; it != m_SystemKPIs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    for (std::vector<KPI*>::iterator it = m_Consumables.begin() ; it != m_Consumables.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_KPIs.clear();
    m_SystemKPIs.clear();
    m_Consumables.clear();
}

void IGSxGUI::KPIManager::initialize(const std::string &filePath)
{
    boost::property_tree::ptree treeWhiteListKPIDefinition;

    read_xml(SUI::ResourcePath::getResourceFile(filePath), treeWhiteListKPIDefinition);

    IGSxKPI::KPIDefinitionList kpiDefinitionList;
    try
    {
        IGSxKPI::KPI::getInstance()->getKpis(kpiDefinitionList);
    } catch(IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    BOOST_FOREACH(boost::property_tree::ptree::value_type const& nodeKPI, treeWhiteListKPIDefinition.get_child(STRING_KPIS))
    {
        if ( nodeKPI.first == STRING_KPI )
        {
            try
            {
                string name = nodeKPI.second.get_child(STRING_ATTRIBUTE_NAME).data();
                string valueSet = nodeKPI.second.get_child(STRING_ATTRIBUTE_VALUESET).data();
                string type = nodeKPI.second.get_child(STRING_ATTRIBUTE_TYPE).data();
                string displayname = nodeKPI.second.get_child(STRING_ATTRIBUTE_DISPLAYNAME).data();
                std::string factorstring = nodeKPI.second.get_child(STRING_ATTRIBUTE_FACTOR).data();
                std::string minstring = nodeKPI.second.get_child(STRING_ATTRIBUTE_MIN).data();
                std::string maxstring = nodeKPI.second.get_child(STRING_ATTRIBUTE_MAX).data();
                std::string position = nodeKPI.second.get_child(STRING_ATTRIBUTE_POSITION).data();

                double factor = atof(factorstring.c_str());
                double min = atof(minstring.c_str());
                double max = atof(maxstring.c_str());
                int pos = atoi(position.c_str());
                IGSxKPI::KPIDefinition kpiDefinition = findKPIDefinition(kpiDefinitionList, name);

                if (type == STRING_KPI)
                {
                    addKPI(kpiDefinition, valueSet, displayname, factor, type, min, max, pos);
                } else if (type == STRING_SYSTEMKPI) {
                    addSystemKPI(kpiDefinition, valueSet, displayname, factor, type, min, max, pos);
                } else if (type == STRING_CONSUMABLE) {
                    addConsumable(kpiDefinition, valueSet, displayname, factor, type, min, max, pos);
                }
            } catch(IGS::Exception& ex)
            {
                IGS_ERROR(ex.what());
            }
        }
    }

    m_previousPollTime = (time(NULL) - TIME_SIX_HOURS) / AMOUNT_OF_SECONDS_IN_MINUTE;
    // Fire the first onTimeout manually to trigger a retrieval of the data.
    onTimeout();
}

IGSxKPI::KPIDefinition IGSxGUI::KPIManager::findKPIDefinition(const IGSxKPI::KPIDefinitionList& list, const std::string& name) const
{
    IGSxKPI::KPIDefinitionList::const_iterator itr = list.begin();
    while (itr != list.end())
    {
        if ((*itr).name() == name)
        {
            return (*itr);
        }
        ++itr;
    }

    throw IGS::Exception(STRING_NO_KPIS_FOUND + name);
}

void IGSxGUI::KPIManager::addKPI(IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue, int position)
{
    KPI* kpi = getKPI(kpiDefinition.name());

    if (kpi == NULL)
    {
        kpi = new KPI(kpiDefinition);
        kpi->setType(type);
        m_KPIs.push_back(kpi);
    }

    KPIValueSet* valueSet = kpi->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
        valueSet->setPosition(position);
    }
}

void IGSxGUI::KPIManager::addSystemKPI(IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue, int position)
{
    KPI* systemkpi = getSystemKPI(kpiDefinition.name());

    if (systemkpi == NULL)
    {
        systemkpi = new KPI(kpiDefinition);
        systemkpi->setType(type);
        m_SystemKPIs.push_back(systemkpi);
    }

    KPIValueSet* valueSet = systemkpi->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
        valueSet->setPosition(position);
    }
}

void IGSxGUI::KPIManager::addConsumable(IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue, int position)
{
    KPI* consumable = getConsumable(kpiDefinition.name());

    if (consumable == NULL)
    {
        consumable = new KPI(kpiDefinition);
        consumable->setType(type);
        m_Consumables.push_back(consumable);
    }

    KPIValueSet* valueSet = consumable->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
        valueSet->setPosition(position);
    }
}

vector<IGSxGUI::KPI*> IGSxGUI::KPIManager::getKPIs() const
{
    return m_KPIs;
}

vector<IGSxGUI::KPI *> IGSxGUI::KPIManager::getSystemKPIs() const
{
    return m_SystemKPIs;
}

vector<IGSxGUI::KPI *> IGSxGUI::KPIManager::getConsumables() const
{
    return m_Consumables;
}

IGSxGUI::KPI* IGSxGUI::KPIManager::getKPI(const string& name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_KPIs.size(); i++)
    {
        if (m_KPIs[i]->getName() == name)
        {
            kpi = m_KPIs[i];
            break;
        }
    }
    return kpi;
}

IGSxGUI::KPI *IGSxGUI::KPIManager::getSystemKPI(const std::string &name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_SystemKPIs.size(); i++)
    {
        if (m_SystemKPIs[i]->getName() == name)
        {
            kpi = m_SystemKPIs[i];
            break;
        }
    }
    return kpi;
}

IGSxGUI::KPI *IGSxGUI::KPIManager::getConsumable(const std::string &name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_Consumables.size(); i++)
    {
        if (m_Consumables[i]->getName() == name)
        {
            kpi = m_Consumables[i];
            break;
        }
    }
    return kpi;
}

void IGSxGUI::KPIManager::receiveKPIDataEvent(const IGSxKPI::KPIData& /*kpiData*/)
{
}

void IGSxGUI::KPIManager::getKPIData(time_t polltime)
{
    for (unsigned int i = 0; i < m_KPIs.size(); i++)
    {
        IGSxKPI::KPIDataList dataList;
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_KPIs[i]->getName(), m_previousPollTime*AMOUNT_OF_SECONDS_IN_MINUTE, polltime*AMOUNT_OF_SECONDS_IN_MINUTE, dataList);
        } catch (IGS::Exception& ex) {
            IGS_ERROR(ex.what());
        }

        if (dataList.size() > 0)
        {
            m_KPIs[i]->updateValues(dataList, true);
        }
    }
}

void IGSxGUI::KPIManager::getSystemKPIData(time_t polltime)
{
    for (unsigned int i = 0; i < m_SystemKPIs.size(); i++)
    {
        IGSxKPI::KPIDataList dataList, dataList2;
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_SystemKPIs[i]->getName(), m_previousPollTime*AMOUNT_OF_SECONDS_IN_MINUTE, polltime*AMOUNT_OF_SECONDS_IN_MINUTE, dataList);

            for (time_t j = m_previousPollTime; j < polltime; j++)
            {
                bool found = false;
                IGSxKPI::KPIData data;

                for (unsigned int n = 0; n < dataList.size(); n++)
                {
                    if ((dataList.at(n).time() / AMOUNT_OF_SECONDS_IN_MINUTE) == j)
                    {
                        data = dataList.at(n);
                        found = true;
                        break;
                    }
                }

                if (!found)
                {
                    IGSxKPI::KPIValueSet valueSet;
                    for (unsigned int n = 0; n < m_SystemKPIs[i]->getValueSets().size(); n++)
                    {
                        valueSet.push_back(0);
                    }

                    data.setName(m_SystemKPIs[i]->getName());
                    data.setTime(j*AMOUNT_OF_SECONDS_IN_MINUTE);
                    data.setValues(valueSet);
                }

                dataList2.push_back(data);
            }
        } catch (IGS::Exception& ex) {
            IGS_ERROR(ex.what());
        }

        if (!dataList2.empty())
        {
            if (dataList.size() > 0)
            {
                m_SystemKPIs[i]->updateValues(dataList2, true);
            } else {
                m_SystemKPIs[i]->updateValues(dataList2, false);
            }
        }
    }
}

void IGSxGUI::KPIManager::getConsumableData(time_t polltime)
{
    for (unsigned int i = 0; i < m_Consumables.size(); i++)
    {
        IGSxKPI::KPIDataList dataList;
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_Consumables[i]->getName(), m_previousPollTime*AMOUNT_OF_SECONDS_IN_MINUTE, polltime*AMOUNT_OF_SECONDS_IN_MINUTE, dataList);
        } catch (IGS::Exception& ex) {
            IGS_ERROR(ex.what());
        }

        if (dataList.size() > 0)
        {
            m_Consumables[i]->updateValues(dataList, true);
        }
    }
}

void IGSxGUI::KPIManager::onTimeout()
{
    time_t currentPollTime = time(NULL) / AMOUNT_OF_SECONDS_IN_MINUTE;
    if (m_previousPollTime < currentPollTime)
    {
        getKPIData(currentPollTime);
        getSystemKPIData(currentPollTime);
        getConsumableData(currentPollTime);

        m_previousPollTime = currentPollTime;
    }
    m_timer->start(TIMER_INTERVAL);
}
