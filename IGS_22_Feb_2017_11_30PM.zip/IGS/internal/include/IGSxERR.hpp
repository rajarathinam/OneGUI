/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR.hpp
| Author       : Thijs Jacobs
| Description  : Interface to retrieve the XER event log
|
| ! \file        IGSxERR.hpp
| ! \brief       Interface to retrieve the XER event log
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSxERR_HPP
#define IGSxERR_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/


namespace IGSxERR {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class EventLogger
{
// functions throw IGS::exception
public:
    static EventLogger* getInstance() {return instance;}

    // get the event log as a fully qualified filename
    virtual std::string getEventLog() = 0;
    virtual std::string getPreviousEventLog() = 0;

protected:
    // instance
    virtual ~EventLogger() {}
    static EventLogger* instance;
};

} // namespace IGSxERR

#endif // IGSxERR_HPP

