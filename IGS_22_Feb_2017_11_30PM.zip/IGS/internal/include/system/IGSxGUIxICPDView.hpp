/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxICPDView.hpp
| Author       : Venugopal S
| Description  : Interface file for CPD view
|
| ! \file        IGSxGUIxICPDView.hpp
| ! \brief       Interface file for CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXICPDVIEW_HPP
#define IGSXGUIXICPDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxCOMMON.hpp"
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class ICPDView
{
 public:
    ICPDView() {}
    virtual ~ICPDView() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void updateStatus(const std::string& strCPD, const IGS::Result& result) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXICPDVIEW_HPP
