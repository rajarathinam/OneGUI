/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsPresenter.cpp
| Author       : Raja
| Description  : Machineconstants Presenter Implementation
|
| ! \file        IGSxGUIxMachineconstantsPresenter.cpp
| ! \brief       Machineconstants Presenter Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
