/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for Splash Presenter
|
| ! \file        IGSxGUIxSplashPresenter.hpp
| ! \brief       Header file for Splash Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSPLASHPRESENTER_HPP
#define IGSXGUIXSPLASHPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxISplashView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class SplashPresenter
{
 public:
    explicit SplashPresenter(IGSxGUI::ISplashView* view);
    virtual ~SplashPresenter();

    std::string getMachineId() const;
    std::string getReleaseId() const;

 private:
    IGSxGUI::ISplashView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSPLASHPRESENTER_HPP
