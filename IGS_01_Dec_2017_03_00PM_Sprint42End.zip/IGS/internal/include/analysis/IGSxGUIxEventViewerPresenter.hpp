/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for Event Viewer presenter
|
| ! \file        IGSxGUIxEventViewerPresenter.hpp
| ! \brief       Header file for Event Viewer presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXEVENTVIEWERPRESENTER_HPP
#define IGSXGUIXEVENTVIEWERPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxIEventViewerView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class EventViewerPresenter
{
 public:
    explicit EventViewerPresenter(IGSxGUI::IEventViewerView* view);
    virtual ~EventViewerPresenter();

    void getEventLog(std::string &activeLog, std::string &previousLog);

 private:
    EventViewerPresenter(const EventViewerPresenter& eventViewerPresenter);
    EventViewerPresenter& operator=(const EventViewerPresenter& eventViewerPresenter);

    IEventViewerView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXEVENTVIEWERPRESENTER_HPP
