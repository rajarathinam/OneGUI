/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIManagerTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for KPI Manager test
|
| ! \file        IGSxGUIxKPIManagerTest.hpp
| ! \brief       Header file for KPI Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXKPIMANAGERTEST_HPP
#define IGSXGUIXKPIMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxKPI.hpp"

using std::vector;
using std::list;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSet;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class KPIManagerTest : public ::testing::Test
{
 public:
    KPIManagerTest(){}
    virtual ~KPIManagerTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
  static const std::string STUB_KPI_WHITELIST_FILE;
};
#endif  // IGSXGUIXKPIMANAGERTEST_HPP
