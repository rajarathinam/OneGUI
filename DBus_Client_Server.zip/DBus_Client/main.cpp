#include "Widget.h"
#include <QApplication>
#include <QDBusConnection>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    new MyAdaptor(&w);
    QDBusConnection dbus = QDBusConnection::sessionBus();
    dbus.registerObject("/Text",&w);
    dbus.registerService("org.rajarathinam.Text");
    w.show();

    return a.exec();
}
