#include "Widget.h"
#include "ui_Widget.h"
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusReply>
#include <QMessageBox>
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    connect(ui->lineEdit,SIGNAL(textChanged(QString)),
            this,SLOT(displayMessage()));

}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    // To do

    if (!QDBusConnection::sessionBus().isConnected()) {
            qDebug() <<"Cannot connect to the D-Bus session bus.\n" "To start it, run:\n" "\teval `dbus-launch --auto-syntax`\n";

        }
    QDBusInterface iface("org.freedesktop.DBus",  // from list on left
                         "/org/freedesktop/DBus", // from first line of screenshot
                         "org.freedesktop.DBus",  // from above Methods
                         QDBusConnection::sessionBus());
    QDBusReply<QStringList> reply = iface.call("ListNames");
    if(reply.isValid())
    {
        qDebug() << reply.value();
    } else {
        qDebug() << "Error:" << reply.error().message();
    }
}

void Widget::setText(const QString &text)
{
    ui->lineEdit->setText(text);

}
QString Widget::getText()
{
    return (ui->lineEdit->text());

}

void Widget::displayMessage()
{
    QMessageBox msg;
    msg.setText("Text Changed....");
    msg.exec();

}
void MyAdaptor::setText(const QString &text)
{
    widget->setText(text);
}

QString MyAdaptor::getText(const QString &text)
{
   return ( widget->getText()) ;
}


