#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDBusAbstractAdaptor>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT


public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

Q_SIGNALS:
     Q_SCRIPTABLE void textChanged();

private slots:
    void on_pushButton_clicked();
public Q_SLOTS:
    void setText(const QString& text);
    QString getText();
    void displayMessage();


public:
    Ui::Widget *ui;
};


class MyAdaptor:QDBusAbstractAdaptor
{
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "org.rajarathinam.Text")
Q_SIGNALS:
     Q_SCRIPTABLE void textChanged();
public Q_SLOTS:
    void setText(const QString& text);
    QString getText(const QString& text);
public:
    explicit MyAdaptor(Widget* ptr):QDBusAbstractAdaptor(ptr),widget(ptr)
    {

    }
    Widget *widget;

};




#endif // WIDGET_H
