#include "Widget.h"
#include "ui_Widget.h"
#include <QDBusInterface>
#include <QDBusReply>
#include <QDebug>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    if (!QDBusConnection::sessionBus().isConnected()) {
            qDebug() <<"Cannot connect to the D-Bus session bus.\n" "To start it, run:\n" "\teval `dbus-launch --auto-syntax`\n";

        }
    QDBusInterface iface("org.rajarathinam.Text",  // from list on left
                         "/Text", // from first line of screenshot
                         "org.rajarathinam.Text",  // from above Methods
                         QDBusConnection::sessionBus());
    QDBusReply<QString> reply = iface.call("getText");
    if(reply.isValid())
    {
        qDebug() << reply.value();
    } else {
        qDebug() << "Error:" << reply.error().message();
    }
}

Widget::~Widget()
{
    delete ui;
}
