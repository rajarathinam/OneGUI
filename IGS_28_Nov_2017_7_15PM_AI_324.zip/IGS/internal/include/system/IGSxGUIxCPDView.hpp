/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.hpp
| Author       : Venugopal S
| Description  : Header file for CPD view
|
| ! \file        IGSxGUIxCPDView.hpp
| ! \brief       Header file for CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDVIEW_HPP
#define IGSXGUIXCPDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <SUITableWidget.h>
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class CPDView;
class Label;
class Button;
class Timer;
class UserControl;
}  // namespace SUI

namespace IGSxGUI{


struct structContainer
{
    std::string name;
    CPD* cpd;

    structContainer() : name(""), cpd(NULL)
    {
    }
};
typedef structContainer container;

struct structSubsystemCount
{
    std::string nameSubsystem;
    int count;

    structSubsystemCount() : nameSubsystem(""), count(0)
    {
    }
};
typedef structSubsystemCount subSystemCount;

class CPDView : public ICPDView
{
 public:
    explicit CPDView(CPDManager *pCPDManager);
    virtual ~CPDView();
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void updateStatus(const std::string& strCPD, const IGS::Result& result);
    virtual void setActive(bool bActive);

 private:
    CPDView(const CPDView &);
    CPDView& operator=(const CPDView &);

    enum CPD_TYPE
    {
        TYPE_CALIBRATION,
        TYPE_PERFORMANCE,
        TYPE_DIAGNOSTICS,
        TYPE_NONE
    };

    void init();
    void reload();
    void initCommon();
    void setHandlers();
    void loadActiveCPD();
    void loadTestTypes();
    void onOpenCPDClicked();
    void loadCPDTypeRadios();
    void EnableCountLabels();
    void loadSubSystemTable();
    void onSubsystemPressed();
    void loadTestReportTable();
    void DisableCloseButtons();
    void moveDescriptionToDown();
    void onUCTActiveCPDPressed();
    void onBtnTestReportsClicked();
    void onBtnDescriptionClicked();
    void onSubSystemClosePressed();
    void onRadioButtonAllPressed();
    void onBtnTestReportHoverLeft();
    void onUCTCloseReportsPressed();
    void onUCTCloseReportsHoverOn();
    void onUCTCloseReportsHoverOff();
    void onBtnDescriptionHoverLeft();
    void countAllSubSystemsTesttype();
    void onBtnTestReportHoverEntered();
    void onBtnDescriptionHoverEntered();
    void onBtnViewSelectedReportsPressed();
    void countSelectedSubSystemsTesttype();
    void onRadioButtonCalibrationPressed();
    void onRadioButtonPerformancePressed();
    void onRadioButtonDiagnosticsPressed();
    void moveDescriptionToOriginalPosition();

    void onCPDUCTHoverLeft(int index);
    void onCPDUCTHoverEntered(int index);
    void onTableCPDRowPressed(int rowindex);
    void showDescriptionHTML(bool isVisible);
    void showTestReportTable(bool isVisible);
    void insertCountLabelAndCloseButton(size_t i);
    void onTableTestReportUCTHoverLeft(int index);
    void onTableTestReportRowPressed(int rowindex);
    void onTableTestReportUCTHoverEntered(int index);
    void setTestReportRowStyleDisabled(SUI::Widget *widget);
    void setTestReportRowStyle(SUI::TableWidget *tablewidget);
    void loadCPDTableByType(CPD_TYPE cpdType, bool isReloading);
    void showRightPane(bool isVisible, const std::string&CPDName);
    void loadCPDTable(std::vector<CPD*> listCPD, bool isReloading);
    void setTestReportRowStyleEnabled(SUI::Widget *widget, int rowIndex);
    void setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount);
    void intersectCPDs(std::vector<CPD*> listTestTypeCPDs, std::vector<CPD*> listSubSystemCPDs);

    std::string getRequiredSpace(size_t count);
    std::vector<CPD*> getSelectedSubSystemCPDs() const;
    std::vector<CPD*> getTestCPDsByName(const std::string& testtypeName) const;

    SUI::CPDView *sui;
    CPDPresenter *m_presenter;
    CPD_TYPE m_cpdTypeSelected;

    std::vector<CPD*> m_listCPD;
    std::vector<IGSxGUI::container> m_listTestTypes;
    std::vector<IGSxGUI::container> m_listSubsystems;

    std::string m_selectedCPD;
    std::string m_nameActiveCPD;
    std::string m_selectedSubSystem;

    int m_countAllCPD;
    int m_countCalibration;
    int m_countPerformance;
    int m_countDiagnostics;
    int m_selectedCPDRowNum;
    int m_selectedSubsystemRowNum;

    bool m_isReloading;
    bool m_isDescFolded;
    bool m_isCPDActivated;
    bool m_isTestReportFolded;
    bool m_isCloseButtonPressed;
    bool m_isActiveCPDDescShown;
    bool m_isInternalCallToSubsystemPressed;

    static const std::string STRING_ALL_CPDS;
    static const std::string CPDVIEW_LOAD_FILE;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STYLE_ASML_ORANGEBUTTON;
    static const std::string STYLE_ASML_ORANGELABEL;
    static const std::string STYLE_ASML_DARKBLUEBUTTON;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STYLE_ENABLED_BUTTON;
    static const std::string STYLE_DISABLED_BUTTON;
    static const std::string STYLE_ACTIVE_CPDLABEL_BLACK;
    static const std::string STYLE_ACTIVE_CPDLABEL_GREY;
    static const std::string STYLE_AWESOME_ICONCOLOR;
    static const std::string STYLE_AWESOMEACTIVE_ICONCOLOR;
    static const std::string STYLE_INACTIVE_CPD;
    static const std::string STYLE_HOVERON;
    static const std::string STYLE_ACTIVE_GROUPBOX;
    static const std::string STYLE_INACTIVE_GROUPBOX;
    static const std::string STRING_EMPTY;
    static const std::string STRING_SLASH;
    static const std::string STRING_CPDVIEW_SHOWN;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STRING_CPDSUBSYSTEM_STYLE;
    static const std::string CUSTOM_STYLESHEET;
    static const std::string STRING_SINGLESPACE;
    static const std::string STRING_CALIBRATION;
    static const std::string STRING_PERFORMANCE;
    static const std::string STRING_DIAGNOSTICS;
    static const std::string STRING_NOACTIVE_CPD;
    static const std::string STRING_ALL;
    static const std::string STRING_DATETIME_FORMAT;
    static const char NEWLINE_CHAR;
    static const std::string STRING_CPDLOG1;
    static const std::string STRING_CPDLOG2;
    static const std::string STRING_MAINTENANCE;
    static const std::string STRING_TESTREPORTS;
    static const std::string STRING_CLOSEREPORT;
    static const std::string STRING_CLOSEREPORTS;
    static const std::string STRING_VIEW_SELECTED_REPORT;
    static const std::string STRING_VIEW_SELECTED_REPORTS;
    static const int CPDSUBSYSTEM_CLOSEBUTTON_SIZE;
    static const int AWESOME_ICON_SIZE;
    static const int AWESOME_ANGLE_SIZE;
    static const int AWESOME_CLOSE_SIZE;
    static const int AWESOME_ACTIVEANGLE_SIZE;
    static const int CPDTABLE_ROW_SIZE;
    static const int NORMAL_SUBSYSTEM_ROW_SIZE;
    static const int EXTENDED_SUBSYSTEM_ROW_SIZE;
    static const int HOURS_PER_DAY;
    static const int NUMBER_OF_DAYS;
    static const int SECONDS_PER_HOUR;
    static const int MAX_NUMBER_OF_SELECTED_ROWS;
    static const int REQUIRED_SPACE_FOUR;
    static const int REQUIRED_SPACE_FIVE;
    static const std::string::size_type MAX_SUBSYSTEM_CHARS_PER_CELL;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDVIEW_HPP
