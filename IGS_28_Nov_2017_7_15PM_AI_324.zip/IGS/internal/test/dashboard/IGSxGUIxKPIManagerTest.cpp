/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIManagerTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI Manager test
|
| ! \file        IGSxGUIxKPIManagerTest.cpp
| ! \brief       Implementation of KPI Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKPIManagerTest.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
const string KPIManagerTest::STUB_KPI_WHITELIST_FILE = "IGSxGUIxStubKPIWhitelist.xml";
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/


TEST_F(KPIManagerTest, GetKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    size_t noofKPIs = kpiMgr->getKPIs().size();
    EXPECT_EQ(3, noofKPIs);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, GetSystemKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    size_t noofKPIs = kpiMgr->getSystemKPIs().size();
    EXPECT_EQ(2, noofKPIs);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, GetConsumablesTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    size_t noofKPIs = kpiMgr->getConsumables().size();
    EXPECT_EQ(1, noofKPIs);

    delete kpiMgr;
}


TEST_F(KPIManagerTest, GetKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getKPI("AMP_PA0in_MpPpPower_On");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    EXPECT_STRCASEEQ("AMP_PA0in_MpPpPower_On", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, GetSystemKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getSystemKPI("Closed_Loop_EUV_Power_at_IF");
    ASSERT_TRUE(kpiFromKPIManager != NULL);

    EXPECT_STRCASEEQ("Closed_Loop_EUV_Power_at_IF", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, GetConsumableTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getConsumable("EUV_Pulse_Energy_Internal");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    EXPECT_STRCASEEQ("EUV_Pulse_Energy_Internal", kpiFromKPIManager->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);


    kpiFromKPIManager = kpiMgr->getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);

    delete kpiMgr;
}
TEST_F(KPIManagerTest, AddKPITestWithDuplicateKPI)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getKPIs();

    // findKPIDefinition Test
    EXPECT_STRCASEEQ("AMP_PA0in_MpPpPower_On", listofKPIs[0]->getName().c_str());
    EXPECT_STRCASEEQ("Seed table MP+PP power on droplet", listofKPIs[0]->getDescription().c_str());

    EXPECT_EQ(3, listofKPIs.size());  // not 4 (as given in StubKPIWhitelist.xml)

    IGSxGUI::KPI* lastkpiinserted = listofKPIs.back();

    EXPECT_STRCASEEQ("AMP_PA3out_MpPpPower_On", lastkpiinserted->getName().c_str());
    EXPECT_STRCASENE("LeakagePwr_Off", lastkpiinserted->getName().c_str());

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddKPITestWithValidValueSet)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getKPIs();
    EXPECT_EQ(3, listofKPIs.size());  // not 4 (as given in StubKPIWhitelist.xml)

    // Get second KPI inserted
    IGSxGUI::KPI* secondKPI = listofKPIs[1];

    // Get second KPI value set (ref. StubKPIWhitelist.xml)
    IGSxGUI::KPIValueSet *valueSet = secondKPI->getValueSet("MEAN");

    EXPECT_TRUE(valueSet->isActive() == true);
    EXPECT_STRCASEEQ("W", valueSet->getDisplayUnit().c_str());
    EXPECT_DOUBLE_EQ(1, valueSet->getFactor());
    EXPECT_DOUBLE_EQ(0, valueSet->getMin());
    EXPECT_DOUBLE_EQ(150, valueSet->getMax());
    EXPECT_EQ(2, valueSet->getPosition());

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddKPITestWithInValidValueSet)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getKPIs();
    EXPECT_EQ(3, listofKPIs.size());  // not 4 (as given in StubKPIWhitelist.xml)

    // Get third KPI inserted
    IGSxGUI::KPI* thirdKPI = listofKPIs[2];

    // Get third KPI value set (ref. StubKPIWhitelist.xml)
    IGSxGUI::KPIValueSet *valueSet = thirdKPI->getValueSet("INVALID");
    EXPECT_TRUE(valueSet == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddSystemKPITestWithValidValueSet)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getSystemKPIs();
    EXPECT_EQ(2, listofKPIs.size());

    // Get first KPI inserted
    IGSxGUI::KPI* firstKPI = listofKPIs[0];

    // Get first KPI value set (ref. StubKPIWhitelist.xml)
    IGSxGUI::KPIValueSet *valueSet = firstKPI->getValueSet("MEAN");

    EXPECT_TRUE(valueSet->isActive() == true);
    EXPECT_STRCASEEQ("W", valueSet->getDisplayUnit().c_str());
    EXPECT_DOUBLE_EQ(1, valueSet->getFactor());
    EXPECT_DOUBLE_EQ(0, valueSet->getMin());
    EXPECT_DOUBLE_EQ(100, valueSet->getMax());
    EXPECT_EQ(1, valueSet->getPosition());

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddSystemKPITestWithInValidValueSet)
{
  IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getSystemKPIs();
    EXPECT_EQ(2, listofKPIs.size());

    // Get second KPI inserted
    IGSxGUI::KPI* secondKPI = listofKPIs[1];

    // Get second KPI value set (ref. StubKPIWhitelist.xml)
    IGSxGUI::KPIValueSet *valueSet = secondKPI->getValueSet("INVALID");
    EXPECT_TRUE(valueSet == NULL);

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddConsumableTestWithValidValueSet)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getConsumables();
    EXPECT_EQ(1, listofKPIs.size());

    // Get first KPI inserted
    IGSxGUI::KPI* firstKPI = listofKPIs[0];

    // Get first KPI value set (ref. StubKPIWhitelist.xml)
    IGSxGUI::KPIValueSet *valueSet = firstKPI->getValueSet("MEAN");

    EXPECT_TRUE(valueSet->isActive() == true);
    EXPECT_STRCASEEQ("%", valueSet->getDisplayUnit().c_str());
    EXPECT_DOUBLE_EQ(1, valueSet->getFactor());
    EXPECT_DOUBLE_EQ(100, valueSet->getMin());
    EXPECT_DOUBLE_EQ(0, valueSet->getMax());
    EXPECT_EQ(1, valueSet->getPosition());

    delete kpiMgr;
}

TEST_F(KPIManagerTest, AddConsumableTestWithInValidValueSet)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(STUB_KPI_WHITELIST_FILE);

    vector<IGSxGUI::KPI*> listofKPIs = kpiMgr->getConsumables();
    EXPECT_EQ(1, listofKPIs.size());

    IGSxGUI::KPI* secondKPI = listofKPIs[1];

    IGSxGUI::KPIValueSet *valueSet = secondKPI->getValueSet("INVALID");
    EXPECT_TRUE(valueSet == NULL);

    delete kpiMgr;
}

