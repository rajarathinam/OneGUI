/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManager.cpp
| Author       : Venugopal S
| Description  : ADT manager Implementation
|
| ! \file        IGSxGUIxADTManager.cpp
| ! \brief       ADT Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTManager.hpp"
#include <boost/bind.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <string>
#include <vector>
#include <algorithm>
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::ADTManager::ADTManager()
{
}
IGSxGUI::ADTManager::~ADTManager()
{
    std::vector<ADT*>::iterator end_it = m_ADTs.end();
    for (std::vector<ADT*>::iterator it = m_ADTs.begin() ; it != end_it; ++it)
    {
        delete (*it);
    }
    m_ADTs.clear();
}

void IGSxGUI::ADTManager::initialize()
{
    IGSxADT::MetaDescriptions metaDescriptions;

    try
    {
        IGSxADT::ADT::getInstance()->getAdts(metaDescriptions);
    } catch (IGS::Exception& ex) {
         IGS_ERROR(ex.what());
    }
    size_t t_metaDescriptions_size = metaDescriptions.size();
    for (size_t i = 0; i < t_metaDescriptions_size; i++)
    {
        // Trim the spaces
        IGSxADT::MetaDescription  metaDescription = metaDescriptions[i];
        std::string name = boost::trim_copy(metaDescription.name());
        std::string subsystem = boost::trim_copy(metaDescription.subSystem());
        std::string description = boost::trim_copy(metaDescription.description());
        std::string descriptionFile = boost::trim_copy(metaDescription.htmlFile());
        IGSxADT::MetaDescription newMetaDescription(name,subsystem, description, descriptionFile);

        ADT* adt = new ADT(newMetaDescription);
        if (adt != NULL)
        {
            add(adt);
        }
    }
}
bool IGSxGUI::ADTManager::add(ADT* adt)
{
    if (adt != NULL)
    {
        for (size_t i = 0; i < m_ADTs.size(); i++)
        {
            if (m_ADTs[i]->getName() == adt->getName())
            {
                // ADT with the name already exists, So need not add
                return false;
            }
        }
        m_ADTs.push_back(adt);
        return true;
    }
    return false;
}

bool IGSxGUI::ADTManager::remove(ADT* adt)
{
    if (adt != NULL)
    {
        for (size_t i = 0; i < m_ADTs.size(); i++)
        {
            if (m_ADTs[i]->getName() == adt->getName())
            {
                m_ADTs.erase(std::remove(m_ADTs.begin(), m_ADTs.end(), adt), m_ADTs.end());

                delete adt;
                adt = NULL;

                return true;
            }
        }
    }
    return false;
}
IGSxGUI::ADT *IGSxGUI::ADTManager::getADT(const std::string &name) const
{
    ADT* adt = NULL;
    size_t t_ADTs_size = m_ADTs.size();
    for (size_t i = 0; i < t_ADTs_size; i++)
    {
        if (m_ADTs[i]->getName() == name)
        {
            adt = m_ADTs[i];
            break;
        }
    }
    return adt;
}
std::vector<IGSxGUI::ADT*> IGSxGUI::ADTManager::retrieveAll()
{
    return m_ADTs;
}















