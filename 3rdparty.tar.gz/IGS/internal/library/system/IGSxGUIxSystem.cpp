/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystem.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin
|
| ! \file        IGSxGUIxSystem.cpp
| ! \brief       Implementation of System plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystem.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::System::System():m_driverManager(new DriverManager())
{
    m_driverManager->initialize();
    m_systemView = new IGSxGUI::SystemView(m_driverManager);    
}

IGSxGUI::System::~System()
{
    delete m_driverManager;
    delete m_systemView;
}

void IGSxGUI::System:: show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    // instantiate the SystemView
    m_systemView->show(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::System:: showCPD(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    // instantiate the CPDView
    m_systemView->showCPD(MainScreenContainer, bIsFirstTimeDisplay);

}

void IGSxGUI::System:: setActive(bool bActive)
{
    m_systemView->setActive(bActive);
}

void IGSxGUI::System::subscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->registerToSystemStateChanged(cb);
}

void IGSxGUI::System::unsubscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->unregisterToSystemStateChanged(cb);
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::System::retrieveSystemState()
{
    return m_driverManager->getSystemState();
}
