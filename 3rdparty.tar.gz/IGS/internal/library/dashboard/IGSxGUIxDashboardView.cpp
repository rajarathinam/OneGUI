/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUITableWidget.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView)
{
    m_presenter = new DashboardPresenter(this,pKpiManager);
}

IGSxGUI::DashboardView::~DashboardView()
{    
    delete m_presenter;
    delete sui;
}

void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);

    m_listKPIs = m_presenter->getKPIs();

    for (size_t i = 0; i < m_listKPIs.size(); i++)
    {
        KPI* kpi = m_listKPIs[i];

        for (size_t j = 0; j < kpi->getValueSets().size(); j++)
        {
            KPIValueSet* valueSet = kpi->getValueSets()[j];
            std::list<std::string> listRowData;

            listRowData.push_back(kpi->getName());
            listRowData.push_back(valueSet->getName());

            listRowData.push_back(boost::lexical_cast<string>(valueSet->getValue().back()));
            listRowData.push_back("");

            sui->tawKPI->insertRows(i+1,1);
            sui->tawKPI->addData(i+1,listRowData);
        }
    }
}

void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else
    {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::DashboardView::updateKPI(string kpiName, string valueSetName, vector<double> values)
{
    for (int i = 1; i < sui->tawKPI->rowCount(); i++)
    {
        if (sui->tawKPI->getItemText(i,0) == kpiName && sui->tawKPI->getItemText(i,1) == valueSetName)
        {
            sui->tawKPI->setItemText(i,2,boost::lexical_cast<string>(values[0]));
            break;
        }
    }
}
