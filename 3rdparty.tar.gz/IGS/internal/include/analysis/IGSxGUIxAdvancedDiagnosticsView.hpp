/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsView.hpp
| Author       : Venugopal S
| Description  : Header file for Advanced Diagnostics view
|
| ! \file        IGSxGUIxAdvancedDiagnosticsView.hpp
| ! \brief       Header file for Advanced Diagnostics view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADVANCEDDIAGNOSTICSVIEW_HPP
#define IGSXGUIXADVANCEDDIAGNOSTICSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxIAdvancedDiagnosticsView.hpp"
#include "IGSxGUIxAdvancedDiagnosticsPresenter.hpp"
#include "IGSxGUIxADTManager.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AdvancedDiagnosticsView;
}

namespace IGSxGUI{
class AdvancedDiagnosticsView : public IAdvancedDiagnosticsView
{
 public:
    AdvancedDiagnosticsView(ADTManager* pADTManager);
    virtual ~AdvancedDiagnosticsView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    AdvancedDiagnosticsView(const AdvancedDiagnosticsView&);
    AdvancedDiagnosticsView& operator=(const AdvancedDiagnosticsView&);

    void onBtnStartADTPressed();

    SUI::AdvancedDiagnosticsView *sui;
    AdvancedDiagnosticsPresenter *m_presenter;

    static const std::string LOAD_FILE_ADVANCED_DIAGNOSTICS;
    static const std::string STR_ADT_LIST;
    static const std::string STR_CPD_LIST;
    static const std::string STR_INCORRECT_SELECTION;
    static const std::string STR_STARTED;
    static const std::string STR_STOPPED;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADVANCEDDIAGNOSTICSVIEW_HPP
