/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIParser.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI Parser
|
| ! \file        IGSxKPIParser.cpp
| ! \brief       Implementation of KPI Parser
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxKPIParser.hpp"
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <IGSxCOMMON.hpp>

using std::pair;
using boost::property_tree::ptree;
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const string IGSxKPI::KPIParser::STRING_KPI = "KPI";
const string IGSxKPI::KPIParser::STRING_KPIS = "KPIs";
const string IGSxKPI::KPIParser::STRING_STARTVALUE = "Startvalue";
const string IGSxKPI::KPIParser::STRING_UNIT = "Unit";
const string IGSxKPI::KPIParser::STRING_DESCRIPTION = "Description";
const string IGSxKPI::KPIParser::STRING_VALUE = "Value";
const string IGSxKPI::KPIParser::STRING_VALUESETS = "KPIValueSets";
const string IGSxKPI::KPIParser::STRING_ATTRIBUTE = "<xmlattr>";
const string IGSxKPI::KPIParser::STRING_ATTRIBUTE_NAME = "<xmlattr>.name";

const string IGSxKPI::KPIParser::KPI_DEFINITION_FILE = IGS::Resource::path("IGSxKPIDefinition.xml");
const string IGSxKPI::KPIParser::KPI_VALUESET_DEFINITION_FILE = IGS::Resource::path("IGSxKPIValueSetDefinition.xml");

IGSxKPI::KPIParser::KPIParser()
{
}

void IGSxKPI::KPIParser::loadKPI()
{
    loadKPIDefinition();
    loadKPIValueSetDefinition();
}

map<string, KPIINFO> IGSxKPI::KPIParser::getKPIs()
{
    return m_mapKPIDefinitions;
}

void IGSxKPI::KPIParser::loadKPIDefinition()
{
    ptree treeKPIDefinition;
    read_xml(KPI_DEFINITION_FILE,treeKPIDefinition);

    BOOST_FOREACH( boost::property_tree::ptree::value_type const& nodeKPI, treeKPIDefinition.get_child(STRING_KPIS))
    {
        KPIINFO kpiInfo;
        pair<string, KPIINFO> KpiPair;
        kpiInfo.KpiValueSet.clear();

        ptree treeKPI = nodeKPI.second;

        if( nodeKPI.first == STRING_KPI )
        {
            KpiPair.first = nodeKPI.second.get_child(STRING_ATTRIBUTE_NAME).data();

            BOOST_FOREACH( boost::property_tree::ptree::value_type const& nodeKPIChild, treeKPI.get_child(""))
            {
                if ( nodeKPIChild.first != STRING_ATTRIBUTE )
                {
                    kpiInfo.desc = treeKPI.get<std::string>(nodeKPIChild.first);
                }
            }
        }
        KpiPair.second = kpiInfo;
        m_mapKPIDefinitions.insert(KpiPair);
    }
}

void IGSxKPI::KPIParser::loadKPIValueSetDefinition()
{
    ptree treeKPIValueSetDefinition;
    read_xml(KPI_VALUESET_DEFINITION_FILE, treeKPIValueSetDefinition);

    BOOST_FOREACH( boost::property_tree::ptree::value_type const& nodeKPI, treeKPIValueSetDefinition.get_child(STRING_VALUESETS))
    {
        if( nodeKPI.first == STRING_KPI)
        {
           map<string, KPIINFO>::iterator itKPIDef = m_mapKPIDefinitions.find(nodeKPI.second.get_child(STRING_ATTRIBUTE_NAME).data());

           if (itKPIDef != m_mapKPIDefinitions.end())
           {
                KPIINFO kpi = itKPIDef->second;

                ptree treeEachKPI = nodeKPI.second;

                BOOST_FOREACH( boost::property_tree::ptree::value_type const& nodeValue, treeEachKPI.get_child(""))
                {
                   if( nodeValue.first == STRING_VALUE)
                   {
                      KpiValueSetDefinition valdef;
                      valdef.name = nodeValue.second.get_child(STRING_ATTRIBUTE_NAME).data();
                      ptree treeEachValue = nodeValue.second;

                      BOOST_FOREACH( boost::property_tree::ptree::value_type const& nodeValueChild, treeEachValue.get_child(""))
                      {
                         if( nodeValueChild.first != STRING_ATTRIBUTE)
                         {
                             if( nodeValueChild.first == STRING_DESCRIPTION)
                             {
                                 valdef.desc = treeEachValue.get<string>( nodeValueChild.first );
                             }
                             if( nodeValueChild.first == STRING_UNIT)
                             {
                                 valdef.unit = treeEachValue.get<string>( nodeValueChild.first );
                             }
                             if( nodeValueChild.first == STRING_STARTVALUE)
                             {
                                 valdef.values.push_back(treeEachValue.get<double>( nodeValueChild.first ));
                             }
                         }
                      }
                      kpi.KpiValueSet.push_back(valdef);
                   }
                }
                itKPIDef->second = kpi;
           }
        }
    }
}
