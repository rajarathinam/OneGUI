/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMockISystemView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin view interface test
|
| ! \file        IGSxGUIxMockISystemView.cpp
| ! \brief       Implementation of System plugin view interface test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMockISystemView.hpp"
#include <gtest.h>
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxISystem.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
using ::testing::AtLeast;
// Dummy Tests - to be implemented later
TEST(ISystemViewTest, show)
{
}

TEST(ISystemViewTest, showErrors)
{
}

TEST(ISystemViewTest, updateSysFunction)
{
}

TEST(ISystemViewTest, updateDriver)
{
}




