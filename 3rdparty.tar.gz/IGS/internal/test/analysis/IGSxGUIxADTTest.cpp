/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTTest.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT test
|
| ! \file        IGSxGUIxADTTest.cpp
| ! \brief       Implementation of ADT test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTTest.hpp"
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTTest, Test_1)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);
    EXPECT_STRCASEEQ(adt.getName().c_str(), metaData.name().c_str());
    EXPECT_STRCASEEQ(adt.getDescription().c_str(), metaData.description().c_str());
    EXPECT_STRCASEEQ(adt.getSubsystem().c_str(), metaData.subSystem().c_str());
    EXPECT_STRCASEEQ(adt.getHtmlFile().c_str(), metaData.htmlFile().c_str());
}

TEST_F(ADTTest, Test_2)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);
    ASSERT_TRUE(adt.start());
}
