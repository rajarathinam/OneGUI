#!/bin/bash
#
#-------------------------------------------------------------------------------
#   build.sh
#   
#   A script to build the trunk
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"

# Functions
function print_message(){
	echo "******************************"
	echo "**** $1"
	echo "******************************"
}

# script
if [ "$1" == "help" ] || [ "$1" == "?" ]; then
	echo "******************************"
	echo "**** HELP"
	echo "****"
	echo "**** help: Displays this help documentation."
	echo "**** clean: Cleans the build before the build is started."
	echo "******************************"
	exit
fi

print_message "Starting build"

qmake48 $(pwd)/../../IGS/InitTerminate.pro -r -spec linux-g++-64


if [ "$1" == "clean" ]; then
	print_message "Cleaning up"
	make -f Makefile clean
fi

make -f Makefile
if [ "$?" != 0 ]; then
	print_message "Build failed!"
	exit 1
fi


print_message "Build success!"
exit 0