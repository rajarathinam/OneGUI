/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITableWidgetItem.h
| Author       :
| Description  : Header file for class SUI::TableWidgetItem.
|
| ! \file        SUITableWidgetItem.h
| ! \brief       Header file for class SUI::TableWidgetItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUITABLEWIDGETITEM_H
#define SUITABLEWIDGETITEM_H

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIAlignable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TableWidgetItem class
 */
class SUI_SHARED_EXPORT TableWidgetItem : public Widget, public IText, public IAlignable
{
public:
    virtual ~TableWidgetItem();
    
protected:
    TableWidgetItem();

};
}

#endif // SUITABLEWIDGETITEM_H
