/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIListView.h
| Author       :
| Description  : Header file for class SUI::ListView.
|
| ! \file        SUIListView.h
| ! \brief       Header file for class SUI::ListView.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILISTVIEW_H
#define SUILISTVIEW_H

#include "SUIWidget.h"
#include "SUIStringList.h"

#include "SUIIText.h"
#include "SUIIClickable.h"
#include "SUIIFilterable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the ListView Widget
 */
class SUI_SHARED_EXPORT ListView : public Widget, public IText, public IClickable, public StringList, public IFilterable
{
public:
    virtual ~ListView();
    
protected:
    ListView();
};
}

#endif // SUILISTVIEW_H
