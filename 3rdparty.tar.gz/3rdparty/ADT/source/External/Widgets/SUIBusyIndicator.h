/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIBusyIndicator.h
| Author       :
| Description  : Header file for class SUI::BusyIndicator.
|
| ! \file        SUIBusyIndicator.h
| ! \brief       Header file for class SUI::BusyIndicator.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUSYINDICATOR_H
#define SUIBUSYINDICATOR_H

#include "SUIWidget.h"
#include "SUIIAnimatable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief Specific Interface for the BusyIndicator Widget
 */
class SUI_SHARED_EXPORT BusyIndicator : public Widget, public IAnimatable
{
public:
    virtual ~BusyIndicator();
    
protected:
    BusyIndicator();

};
}

#endif // SUIBUSYINDICATOR_H
