/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckGroupBox.h
| Author       :
| Description  : Header file for class SUI::CheckGroupBox.
|
| ! \file        SUICheckGroupBox.h
| ! \brief       Header file for class SUI::CheckGroupBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICHECKGROUPBOX_H
#define SUICHECKGROUPBOX_H

#include "SUIICheckable.h"
#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIBGColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The CheckGroupBox class
 */
class SUI_SHARED_EXPORT CheckGroupBox : public Widget, public IText, public IBGColorable, public ICheckable
{
public:
    virtual ~CheckGroupBox();

protected:
    CheckGroupBox();
    CheckGroupBox(const SUI::ObjectType::Type &type);
};
}

#endif // SUICHECKGROUPBOX_H
