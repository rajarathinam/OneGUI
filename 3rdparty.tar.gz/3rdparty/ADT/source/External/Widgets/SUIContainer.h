/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIContainer.h
| Author       :
| Description  : Header file for class SUI::Container.
|
| ! \file        SUIContainer.h
| ! \brief       Header file for class SUI::Container.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICONTAINER_H
#define SUICONTAINER_H

#include "SUIWidget.h"


namespace SUI {
class ObjectList;

/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief Specific Interface for the Container Widget
 */
class SUI_SHARED_EXPORT Container : public Widget
{
public:
    virtual ~Container();

    /*!
     * \brief setUiFilename
     * Specify the UI file to be opened and displayed in this container
     * \param path to the XML UI file
     */
    virtual void setUiFilename(std::string filename) = 0;

    /*!
     * \brief getObjectList
     * Returns a list of objects, currently inside the container
     * \return
     */
    virtual ObjectList *getObjectList() = 0;
    
protected:
    Container();
};
}

#endif // SUICONTAINER_H


