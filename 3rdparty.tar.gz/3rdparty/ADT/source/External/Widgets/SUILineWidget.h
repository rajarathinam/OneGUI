/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILineWidget.h
| Author       :
| Description  : Header file for class SUI::LineWidget.
|
| ! \file        SUILineWidget.h
| ! \brief       Header file for class SUI::LineWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILINEWIDGET_H
#define SUILINEWIDGET_H

#include "SUIWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The LineWidget class
 */
class SUI_SHARED_EXPORT LineWidget : public Widget
{
public:
    virtual ~LineWidget();

protected:
    LineWidget();
};
}
#endif // SUILINEWIDGET_H
