/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButtonBar.h
| Author       :
| Description  : Header file for class SUI::ButtonBar.
|
| ! \file        SUIButtonBar.h
| ! \brief       Header file for class SUI::ButtonBar.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUTTONBAR_H
#define SUIBUTTONBAR_H

#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ButtonBar class
 */
class SUI_SHARED_EXPORT ButtonBar : public Widget
{
public:
    virtual ~ButtonBar();
    
protected:
    ButtonBar();
};
}
#endif // SUIBUTTONBAR_H
