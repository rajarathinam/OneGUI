/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIUserControl.h
| Author       :
| Description  : Header file for class SUI::UserControl.
|
| ! \file        SUIUserControl.h
| ! \brief       Header file for class SUI::UserControl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIUSERCONTROL_H
#define SUIUSERCONTROL_H

#include "SUISharedExport.h"
#include "SUIIClickable.h"
#include "SUIIHoverable.h"

#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The UserControl class
 */
class SUI_SHARED_EXPORT UserControl : public Widget, public IClickable, public IHoverable
{
public:
    virtual ~UserControl();
    
protected:
    UserControl();

};
}

#endif // SUIUSERCONTROL_H
