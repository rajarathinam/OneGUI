/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDoubleSpinBox.h
| Author       :
| Description  : Header file for class SUI::DoubleSpinBox.
|
| ! \file        SUIDoubleSpinBox.h
| ! \brief       Header file for class SUI::DoubleSpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIDOUBLESPINBOX_H
#define SUIDOUBLESPINBOX_H

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIErrorMode.h"
#include "SUIIAlignable.h"
#include "SUIINumeric.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the DoubleSpinBox Widget
 */
class SUI_SHARED_EXPORT DoubleSpinBox : public Widget, public IErrorMode, public INumeric<double>, public IAlignable
{
public:
    virtual ~DoubleSpinBox();
    
protected:
    DoubleSpinBox();
    DoubleSpinBox(const SUI::ObjectType::Type &type);

};
}

#endif // SUIDOUBLESPINBOX_H
