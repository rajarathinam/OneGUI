/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIPlotWidget.h
| Author       :
| Description  : Header file for class SUI::PlotWidget.
|
| ! \file        SUIPlotWidget.h
| ! \brief       Header file for class SUI::PlotWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIPLOTWIDGET_H
#define SUIPLOTWIDGET_H

#include "SUICurveColorEnum.h"
#include "SUIPlotAxisEnum.h"
#include "SUILineStyleEnum.h"
#include "SUIScaleTypeEnum.h"
#include "SUIGridStyleEnum.h"
#include "SUIMarkerSymbolEnum.h"

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIClickable.h"

#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief Specific Interface for the plot widget Widget
 */
class SUI_SHARED_EXPORT PlotWidget : public Widget, public IText, public IClickable
{
public:
    virtual ~PlotWidget();

    /*!
     * \brief enableLegend
     * Enables (on == true) or disables the plot's legend
     * \param on
     */
    virtual void enableLegend(bool on) = 0;

    /*!
     * \brief setRectangle
     * This function adds a new rectangle to the PlotWidget.
     * If it doesn't already exist and set is true.\n
     * If set is true and the rectangle does not exist yet, it makes a new rectangle at the given position, with the given color and
     * the given label. If set is false and the rectangle exists, it will hide that rectangle.
     * If the rectangle does not exist and set is false, nothing happens.
     * If the rectangle exists and set is true, it is being redrawn with the
     * appropriate parameters, so one can change the start, end, color and label
     * of an existing rectangle.
     * \param id - The ID for the Rectangle
     * \param xstart - The X coordinate where the rectangle should begin.
     * \param xend - The X coordinate where the rectangle should end.
     * \param color - The color of the rectangle.
     * \param set - Defines whether the rectangle must be turned on or off.
     * \param label - The name / label of the rectangle.
     * \param axis    -   Which axis to use
     * \param orientation - Valid values are 'Vertical' (= default) or 'Horizontal'.
     * \param yside - Valid values are 'Left' (= default) or 'Right'. Is not used when orientation is 'Vertical'
     */
    virtual void setRectangle(int id, double xstart, double xend, CurveColorEnum::CurveColor color, bool set, const std::string &label, const PlotAxisEnum::PlotAxis axis) = 0;

    /*!
     * \brief setROI
     * This function sets or hides a Region Of Interest in the PlotWidget
     * \param    id  	    -   The ID of the ROI
     * \param    set         -   Turns the region on or off
     * \param    label 		-   The name / label of the rectangle.
     * \param    color       -   The color of the ROI
     * \param    xstart      -   The start point x value, related to the bottom x scale
     * \param    ystart      -   The start point y value, related to the left y scale
     * \param    xend        -   The end point x value, related to the bottom x scale
     * \param    yend        -   The end point y value, related to the left y scale
     * \param    axis        -   Indicates which Y axis to relate to.
     * \remark   If setting the ROI off, the geometry, the color and the axis of the ROI is of no interest. Hence
     *           the default values, so you don't have to supply them.
     */
    virtual void setROI(int id, bool set, const std::string &label, int xstart = INT_MAX, int xend = INT_MAX, int ystart = INT_MAX, int yend = INT_MAX,
                            CurveColorEnum::CurveColor color = CurveColorEnum::Black, const PlotAxisEnum::PlotAxis axis = PlotAxisEnum::yLeft) = 0;

    /*!
     * \brief clearDataset with name setName
     * This function clears all data from the PlotDataSet.
     * \note It does NOT delete it. Thus, it can still be used when filled with new data.
     * \param setName - The name of the new DataSet.
     */
    virtual void clearDataset(const std::string &setName) = 0;

    /*!
     * \brief createDataset
     * This function creates a new PlotDataSet, if it doesn't already exist and appends it to the mDataSetList.
     * \param setName - The name of the new DataSet.
     * \param side - Used for setting the Y Axis of the plot curve
     */
    virtual void createDataset(const std::string &setName, PlotAxisEnum::PlotAxis side) = 0;

    /*!
     * \brief deleteDataset
     * This function deletes a PlotDataSet (if it exists) and removes it from the mDataSetList.
     * \param setName - The name of the new DataSet.
     */
    virtual void deleteDataset(const std::string &setName) = 0;

    /*!
     * \brief getDatasetList
     * This function returns a semicolon separated string with all the DataSet names.
     * \return std::string - The semicolon separated list of all DataSet names
     */
    virtual std::string getDatasetList() const = 0;

    /*!
     * \brief hideDataset
     * This function hides (on == false) or shows the named data set.
     * \param setName - The name of the DataSet.
     * \param on - Indicates setting hide on or off.
     */
    virtual void hideDataset(const std::string &setName, bool on = true) = 0;

    /*!
     * \brief setDataPoint
     * This function adds a new point (x,y) to the curve with name setName. It calls checkInterval() when appropriate.
     * \param setName - The name of the DataSet.
     * \param x - The X value of the point.
     * \param y - The Y value of the point.
     */
    virtual void setDataPoint(const std::string &setName, const double x, const double y) = 0;

    /*!
     * \brief setDataPoints
     * This function adds a collection of data points to the curve with name setName. This makes a deep
     * copy of the data
     * \param setName - The name of the DataSet.
     * \param xData   - The X point array.
     * \param yData   - The Y point array.
     * \param size    - size of xData and YData.
     */
    virtual void setDataPoints(const std::string &setName, const double *xData, const double *yData, int size) = 0;

    /*!
     * \brief setRawDataPoints
     * This function adds a collection of data points to the curve with name setName. No deep copy is created,
     * so the plot data needs to be kept alive
     * \param setName - The name of the DataSet.
     * \param xData   - The X point array.
     * \param yData   - The Y point array.
     * \param size    - size of xData and YData.
     */
    virtual void setRawDataPoints(const std::string &setName, const double *xData, const double *yData, int size) = 0;

    /*!
     * \brief autoReplot
     * This function indicates whether autoreplot should occur or not
     * \param bAutoReplotEnable - Defines autoplot is to be enabled or not.
     */
    virtual void autoReplot(bool bAutoReplotEnable) = 0;

    /*!
     * \brief replot
     * This function redraws the plot. Redraw the plot. If the autoReplot option is not set
     * (which is the default) or if any curves are attached to raw data, the plot has to be
     * refreshed explicitly in order to make changes visible.
     */
    virtual void replot() const = 0;

    /*!
     * \brief setStyle
     * This function sets the style (line color, line style and pen width) for the named curve
     * \param setName - The name of the PlotDataSet to set the style for.
     * \param color - The color to set.
     * \param linestyle - The line style to set (See LineStyleEnum::LineStyle).
     * \param penwidth - The pen width to set.
     */
    virtual void setStyle(const std::string &setName, CurveColorEnum::CurveColor color, LineStyleEnum::LineStyle linestyle, int penwidth) = 0;

    /*!
     * \brief setScaleType
     * sets the type of scale used at a side of the plotwidget
     * \param side - The side of the plotwidget. side can only be
     * - EnumYSide::Y_LEFT - The left side of the plot widget
     * - EnumYSide::Y_RIGHT - The right side of the plot widget
     * If something else is given the value EnumYSide::Y_RIGHT will be applied.
     * \param type - The type of scale used. type can only be:
     * - EnumScaleType::LINEAR_SCALE - a linear Scale
     * - EnumScaleType::LOG_SCALE - a logarimic Scale
     */
    virtual void setScaleType(PlotAxisEnum::PlotAxis side, ScaleTypeEnum::ScaleType type) = 0;

    /*!
     * \brief setXAutoShift
     * Sets X-axis auto shift to on (set == true) or off (set == false).
     * When the X Scale has Auto Scale turned on, mXScaleAutoShift must always be false.
     * \param set
     */
    virtual void setXAutoShift(bool set) = 0;

    /*!
     * \brief setXGrid
     * Enables or disables the X Grid for the Max lines and the Min lines.
     * \param style - Valid values: Off = No Grid, Normal = Main grid lines, Detail = Main and sub grid lines.
     */
    virtual void setXGrid(GridStyleEnum::GridStyle style) = 0;

    /*!
     * \brief setYGrid
     * Enables or disables the Y Grid for the Max lines and the Min lines.
     * \param style - Valid values: EnumGridStyle::GRID_OFF = No Grid, EnumGridStyle::GRID_NORMAL = Main grid lines,
     * EnumGridStyle::GRID_Detail = Main and sub grid lines.
     */
    virtual void setYGrid(GridStyleEnum::GridStyle style) = 0;

    /*!
     * \brief setXLabel
     * sets the label of the X Axis
     * \param label - The label for the X Axis
     */
    virtual void setXLabel(const std::string &label) = 0;

    /*!
     * \brief setYLeftLabel
     * Sets the label of the left Y Axis
     * \param label - The label for the left Y Axis
     */
    virtual void setYLeftLabel(const std::string &label) = 0;

    /*!
     * \brief setYRightLabel
     * Sets the label of the right Y Axis
     * \param label - The label for the right Y Axis
     */
    virtual void setYRightLabel(const std::string &label) = 0;

    /*!
     * \brief setXScale
     * Sets the X Scale from xMin to xMax.
     * If xMin is between -0.01 and 0.01 and xMax is between -0.01 and 0.01, the X Scale is set to AutoScale
     * \param xMin - The minimum X value for the X Scale
     * \param xMax - The maximum X value for the X Scale
     */
    virtual void setXScale(double xMin, double xMax) = 0;

    /*!
     * \brief setYLeftScale
     * Sets the Left Y Scale from yMin to yMax
     * If yMin is between -0.01 and 0.01 and yMax is between -0.01 and 0.01, the Y Scale is set to AutoScale
     * Because the Text label y position of the rectangle's is calculated from the Canvas,
     * these positions have to be recalculated, when the Y Scale changes
     * \param yMin - The minimum Y value for the Left Y Scale
     * \param yMax - The maximum Y value for the Left Y Scale
     */
    virtual void setYLeftScale(double yMin, double yMax) = 0;

    /*!
     * \brief setYRightScale
     * Sets the Right Y Scale from yMin to yMax.
     * When yMin is between -0.01 and 0.01 and yMax is between -0.01 and 0.01, the Y Scale is set to AutoScale
     * \param yMin - The minimum Y value for the Right Y Scale
     * \param yMax - The maximum Y value for the Right Y Scale
     */
    virtual void setYRightScale(double yMin, double yMax) = 0;

    /*!
     * \brief setTitle
     * Sets the title of the plot
     * \param title - The text to set
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief getTitle
     * Returns the plot's title
     * \return - the title text
     */
    virtual std::string getTitle() const = 0;

    /*!
     * \brief setPlotMarker
     * Sets the marker (color, symbol and size) for the named curve
     * \param setName - The name of the PlotDataSet to set the marker for
     * \param color - The color to set
     * \param markerSymbol - The symbol to set (See MarkerSymbolEnum::MarkerSymbol)
     * \param symbolSize - The width to set
     */
    virtual void setPlotMarker(const std::string &setName, CurveColorEnum::CurveColor color, MarkerSymbolEnum::MarkerSymbol markerSymbol, int symbolSize) = 0;

protected:
    PlotWidget();
};
}

#endif // SUIPLOTWIDGET_H
