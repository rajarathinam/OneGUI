/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsItem.h
| Author       :
| Description  : Header file for class SUI::GraphicsItem.
|
| ! \file        SUIGraphicsItem.h
| ! \brief       Header file for class SUI::GraphicsItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIGRAPHICSITEM_H
#define SUIGRAPHICSITEM_H

#include "SUIObject.h"

namespace SUI {
/*!
 * \ingroup FWQxGraphicsItems
 *
 * \brief Base class of GraphicsItems
 *
 * GraphicsItem is the base class of which more specific GraphicsItems must derive from.
 */
class SUI_SHARED_EXPORT GraphicsItem : public Object
{

public:
    virtual ~GraphicsItem();

    /*!
     * \brief setId
     * Sets the ID of the graphics item
     * \param id
     */
    void setId(const std::string &id);

    /*!
     * \brief getId
     * Returns the ID of the graphics item
     * \return
     */
    virtual std::string getId() const;

    /*!
     * \brief setPosition
     * Sets the X and Y coordinates of the GraphicsItem
     * \param double x - The X coordinate of the GraphicsItem.
     * \param double y - The Y coordinate of the GraphicsItem.
     * \remarks GraphicsItems will only be visible when they are inside the scene rectangle.
     */
    virtual void setPosition(double x, double y);

    /*!
     * \brief setX
     * Set the x coordinate
     * \param double x
     */
    virtual void setX(double x);

    /*!
     * \brief setY
     * Set the y coordinate
     * \param double y
     */
    virtual void setY(double y);

    /*!
     * \brief getX
     * Returns the X coordinate of the GraphicsItem
     * \return int - The X coordinate of the GraphicsItem
     */
    double getX() const;

    /*!
     * \brief getY
     * Returns the Y coordinate of the GraphicsItem
     * \return int - The Y coordinate of the GraphicsItem
     */
    double getY() const;

    /*!
     * \brief setZValue
     * Set the Z value of the graphics item. The Z value decides the
     * stacking order of sibling (neighboring) items
     * \param z
     */
    void setZValue(double z);

    /*!
     * \brief getZValue
     * Returns the Z value (stacking order)
     * \fn getZValue
     * \return double
     */
    double getZValue() const;

    /*!
     * \brief getBoundingRectWidth
     * Returns the width of the bounding rectangle
     * \return double
     */
    virtual double getBoundingRectWidth() const;

    /*!
     * \brief getBoundingRectHeight
     * Returns the height of the bounding rectangle
     * \return double
     */
    virtual double getBoundingRectHeight() const;
        
    /*!
     * \brief setVisible
     * Sets the visibility of the graphics item. If visible is false,
     * the item is not drawn and do not receive any events
     */
    virtual void setVisible(bool visible);
    
    /*!
     * \brief isVisible
     * Returns whether the graphics item is visible or not
     * \return bool
     */
    virtual bool isVisible() const;
    
    /*!
     * \brief setEnabled
     * Enables or disables a graphics item. All children of the graphics item
     * are also diabled if 'enabled' equals false
     */
    virtual void setEnabled(bool enabled);
    
    /*!
     * \brief isEnabled
     * Returns whether the graphics item is enabled or disabled
     * \return bool
     */
    virtual bool isEnabled() const;
    
    /*!
     * \brief setToolTip
     * Sets the tooltip of the graphics item. If 'toolTip' is empty,
     * the item's tooltip is cleared
     */
    void setToolTip(const std::string &toolTip);

    /*!
     * \brief getToolTip
     * Returns the tooltip of the graphics item
     * \return std:string
     */
    std::string getToolTip() const;

    /*!
     * \brief getParent
     * Returns the parent graphics item of this item
     * \return GraphicsItem
     */
    GraphicsItem *getParent() const;
    
    /*!
     * \brief setMoveable
     * Enables or disables ('enabled' equals false) to possibility to move the graphics item
     */
    void setMoveable(bool enabled);
    
    /*!
     * \brief setFocusable
     * Enables or disables ('enabled' equals false) to possibility of the graphics item to receive focus
     */
    void setFocusable(bool enabled);
    
    /*!
     * \brief setSelectable
     * Enables or disables ('enabled' equals false) to possibility to select the graphics item
     */
    void setSelectable(bool enabled);
    
protected:
    // only for derived classes
    GraphicsItem(const SUI::ObjectType::Type &type, void *implementation, SUI::GraphicsItem *parent = NULL);

    // hidden implementation pointer, accessible to friend classes and derived classes
    void *implementation;

    friend class GraphicsScene;
    friend class ObjectFactory;
    
private:
    GraphicsItem *parent;
    
    std::string id;
};
}

#endif // SUIGRAPHICSITEM_H
