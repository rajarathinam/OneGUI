/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITime.h
| Author       :
| Description  : Header file for class SUI::Time.
|
| ! \file        SUITime.h
| ! \brief       Header file for class SUI::Time.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUITIME_H
#define SUI_SUITIME_H

#include "SUISharedExport.h"
#include "SUIDateTimeEnum.h"

#include <string>

#include <boost/shared_ptr.hpp>

namespace SUI {

/*!
 * \ingroup FWQxUtils
 *
 * \brief The Time class
 */
class SUI_SHARED_EXPORT Time
{

public:
    virtual ~Time();

    /*!
     * \brief addMSecs
     * Adds ms milliseconds to the datetime of this object
     * ms can be positive or negative
     * \param ms
     */
    virtual void addMSecs(int ms) = 0;

    /*!
     * \brief addSecs
     * Adds s seconds to the datetime of this object
     * s can be positive or negative
     * \param s
     */
    virtual void addSecs(int s) = 0;

    /*!
     * \brief getElapsed
     * Returns the number of milliseconds that have elapsed since
     * the last time start() or restart() was called. Note that the
     * counter wraps to zero 24 hours after the last call to start() or restart.
     * \return
     */
    virtual int getElapsed() const = 0;

    /*!
     * \brief getHour
     * Returns the hour part (0 to 23) of the time.
     * \return
     */
    virtual int getHour() const = 0;

    /*!
     * \brief isNull
     * Returns true if the time is null; otherwise returns false.
     * A null time is also an invalid time.
     * \return
     */
    virtual bool isNull() const = 0;

    /*!
     * \brief isValid
     * Returns true if the time is valid; otherwise returns false.
     * For example, the time 23:30:55.746 is valid, but 24:12:30 is invalid.
     * \return
     */
    virtual bool isValid() const = 0;

    /*!
     * \brief getMinute
     * Returns the minute part (0 to 59) of the time.
     * \return
     */
    virtual int getMinute() const = 0;

    /*!
     * \brief getMsec
     * Returns the millisecond part (0 to 999) of the time.
     * \return
     */
    virtual int getMsec() const = 0;

    /*!
     * \brief restart
     * Sets this time to the current time and returns the number of
     * milliseconds that have elapsed since the last time start() or restart() was called.
     * This function is guaranteed to be atomic and is thus very handy for repeated measurements.
     * Call start() to start the first measurement, and restart() for each later measurement.
     * Note that the counter wraps to zero 24 hours after the last call to start() or restart().
     * \return
     */
    virtual int restart() = 0;

    /*!
     * \brief getSecond
     * Returns the second part (0 to 59) of the time.
     * \return
     */
    virtual int getSecond() const = 0;

    /*!
     * \brief setHMS
     * Sets the time to hour h, minute m, seconds s and milliseconds ms.
     * h must be in the range 0 to 23, m and s must be in the range 0 to 59, and ms must be in
     * the range 0 to 999. Returns true if the set time is valid; otherwise returns false.
     * \param h
     * \param m
     * \param s
     * \param ms
     * \return
     */
    virtual bool setHMS(int h, int m, int s, int ms = 0) = 0;

    /*!
     * \brief start
     * Sets this time to the current time. This is practical for timing:
     */
    virtual void start() = 0;

    /*!
     * \brief toString
     * Returns the time as a string. The format parameter determines the format of the result string.
     * Examples are 'hh:mm:ss:zzz' and 'H:m:s a'
     * If the datetime is invalid, an empty string is returned
     * \param format
     * \return
     */
    virtual std::string toString(const std::string &format) const = 0;

    /*!
     * \brief toString
     * Returns the time as a string. Milliseconds are not included.
     * The format parameter determines the format of the string.
     * See DateTimeEnum::DateFormat
     * \param format
     * \return
     */
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const = 0;

    /*!
     * \brief operator !=
     * Returns true if this time is different from t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator!=(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief operator <
     * Returns true if this time is earlier than t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator<(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief operator <=
     * Returns true if this time is earlier than or equal to t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator<=(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief operator ==
     * Returns true if this time is equal to t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator==(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief operator >
     * Returns true if this time is later than t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator>(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief operator >=
     * Returns true if this time is later than or equal to t; otherwise returns false.
     * \param t
     * \return
     */
    virtual bool operator>=(const boost::shared_ptr<Time> &t) const = 0;

    /*!
     * \brief createTime
     * Creates the time object
     * \return
     */
    static boost::shared_ptr<Time> createTime();

};

} // namespace SUI

#endif // SUI_SUITIME_H
