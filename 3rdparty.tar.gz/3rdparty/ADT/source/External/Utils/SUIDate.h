/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDate.h
| Author       :
| Description  : Header file for class SUI::Date.
|
| ! \file        SUIDate.h
| ! \brief       Header file for class SUI::Date.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUIDATE_H
#define SUI_SUIDATE_H

#include "SUISharedExport.h"

#include "SUIDateTimeEnum.h"

#include <string>

#include <boost/shared_ptr.hpp>

namespace SUI {

/*!
 * \ingroup FWQxUtils
 *
 * \brief The Date class
 */
class SUI_SHARED_EXPORT Date
{
public:
    virtual ~Date();

    /*!
     * \brief addDays
     * Adds ndays to the current date. ndays can be positive or negative
     * \param ndays
     */
    virtual void addDays(int ndays) = 0;

    /*!
     * \brief addMonths
     * Adds nmonths to the current date. nmonths can be positive or negative
     * \param nmonths
     */
    virtual void addMonths(int nmonths) = 0;

    /*!
     * \brief addYears
     * Adds nyears to the current date. nyears can be positive or negative
     * \param nyears
     */
    virtual void addYears(int nyears) = 0;

    /*!
     * \brief getDay
     * Returns the day of the month
     * \return
     */
    virtual int getDay() const = 0;

    /*!
     * \brief getDayOfWeek
     * Returns the week day. 1 = Monday, 7 = Sunday
     * \return
     */
    virtual int getDayOfWeek() const = 0;

    /*!
     * \brief getDayOfYear
     * Returns the day of the year (1 to 365 or 366 on leap years)
     * \return
     */
    virtual int getDayOfYear() const = 0;

    /*!
     * \brief getDaysInMonth
     * Returns the number of days in the month (28 to 31)
     * \return
     */
    virtual int getDaysInMonth() const = 0;

    /*!
     * \brief getDaysInYear
     * Returns the number of days in the year (365 or 366)
     * \return
     */
    virtual int getDaysInYear() const = 0;

    /*!
     * \brief getDate
     * Extracts the current year, month and day and stores it in getYear, getMonth and getDay
     * \param getYear
     * \param getMonth
     * \param getDay
     */
    virtual void getDate(int * getYear, int * getMonth, int * getDay) = 0;

    /*!
     * \brief isNull
     * Returns whether the date is NULL (true) or not
     * \return
     */
    virtual bool isNull() const = 0;

    /*!
     * \brief isValid
     * Returns whether the date is valid (true) or not
     * \return
     */
    virtual bool isValid() const = 0;

    /*!
     * \brief getMonth
     * Returns the number corresponding to the month of this date
     * 1 = "January", ..., 12 = "December"
     * \return
     */
    virtual int getMonth() const = 0;

    /*!
     * \brief setDate
     * Sets the current year, month and day. Returns true if the date is valid
     * \param getYear
     * \param getMonth
     * \param getDay
     * \return
     */
    virtual bool setDate(int getYear, int getMonth, int getDay) = 0;

    /*!
     * \brief toJulianDay
     * Converts the date to a Julian day
     * \return
     */
    virtual int toJulianDay() const = 0;

    /*!
     * \brief toString
     * Returns the date as a string. The format parameter defines
     * the format of the result string. Examples of format are:
     * 'dd.MM.yyyy' or 'ddd MMMM d yy'
     * \param format
     * \return
     */
    virtual std::string toString(const std::string &format) const = 0;

    /*!
     * \brief toString
     * Returns the date as a string. The format parameter defines
     * the format of the string. format is of type DateTimeEnum::DateFormat .
     * Default is DateTimeEnum::TextDate
     * \param format
     * \return
     */
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const = 0;

    /*!
     * \brief getWeekNumber
     * Returns the weeknumber and stores the year in yearNumber, unless yearNumber
     * is null (the default). If the date is invalid, 0 is returned
     * \param yearNumber
     * \return
     */
    virtual int getWeekNumber(int * yearNumber = 0) const = 0;

    /*!
     * \brief getYear
     * Returns the year of this date. Negative numbers indicate years before 1 A.D. = 1 C.E.
     * Example: year -44 is 44 B.C.
     * \return
     */
    virtual int getYear() const = 0;

    /*!
     * \brief operator !=
     * Returns true if this date is different from d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator!=(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief operator <
     * Returns true if this date is earlier than d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator<(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief operator <=
     * Returns true if this date is earlier than or equal to d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator<=(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief operator ==
     * Returns true if this date is equal to d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator==(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief operator >
     * Returns true if this date is later than d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator>(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief operator >=
     * Returns true if this date is later than or equal to d; otherwise returns false.
     * \param d
     * \return
     */
    virtual bool operator>=(const boost::shared_ptr<Date> &d) const = 0;

    /*!
     * \brief createDate
     * Creates the Date object
     * \return
     */
    static boost::shared_ptr<Date> createDate();
};

} // namespace SUI

#endif // SUI_SUIDATE_H
