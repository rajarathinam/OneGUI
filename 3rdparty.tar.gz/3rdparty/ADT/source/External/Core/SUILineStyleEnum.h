/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILineStyleEnum.h
| Author       :
| Description  : Header file for class SUI::LineStyleEnum.
|
| ! \file        SUILineStyleEnum.h
| ! \brief       Header file for class SUI::LineStyleEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILINESTYLEENUM_H
#define SUILINESTYLEENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe line styles.
 */
class LineStyleEnum
{
public:
    /*!
     * \brief LineStyle
     * The line style enumeration
     */
    typedef enum
    {
        Solid,
        Dash,
        Dot,
        DashDot,
        DashDotLine
    } LineStyle;
};
}
#endif // SUILINESTYLEENUM_H
