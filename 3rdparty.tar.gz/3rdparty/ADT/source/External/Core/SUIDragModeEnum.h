/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDragModeEnum.h
| Author       :
| Description  : Header file for class SUI::DragModeEnum.
|
| ! \file        SUIDragModeEnum.h
| ! \brief       Header file for class SUI::DragModeEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIDRAGMODEENUM_H
#define SUIDRAGMODEENUM_H

#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe curve colors.
 */
class DragModeEnum
{
public:
    /*!
     * \brief Mode
     * The drag mode enumeration
     */
    typedef enum
    {
        None,
        ScrollHandDrag,
        RubberBandDrag
    } Mode;
    
    /*!
     * \brief fromString
     * Converts a string to a Mode enumeration
     * \param style
     * \return
     */
    static DragModeEnum::Mode fromString(const std::string &style);

    /*!
     * \brief toString
     * Converts a drag mode enumeration to a string
     * \param style
     * \return
     */
    static std::string toString(const DragModeEnum::Mode &style);
    
};
}
#endif // SUIDRAGMODEENUM_H
