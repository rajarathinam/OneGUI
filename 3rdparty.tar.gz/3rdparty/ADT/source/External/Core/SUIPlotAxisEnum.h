/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIPlotAxisEnum.h
| Author       :
| Description  : Header file for class SUI::PlotAxisEnum.
|
| ! \file        SUIPlotAxisEnum.h
| ! \brief       Header file for class SUI::PlotAxisEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIPLOTAXISENUM_H
#define SUIPLOTAXISENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe plot axis and x-axis date/time options.
 */
class PlotAxisEnum
{
public:
    /*!
     * \brief PlotAxis
     * This enum type is used to describe plot axis options.
     */
    enum PlotAxis
    {
        xBottom,
        xTop,
        yLeft,
        yRight
    };

    /*!
     * \brief XAxisDateTime
     * This enum type is used to describe x-axis date/time options.
     */
    enum XAxisDateTime
    {
        NORMAL,
        DATE,
        TIME,
        DATETIME
    };
};
}
#endif // SUIPLOTAXISENUM_H
