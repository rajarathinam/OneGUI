/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIFilterable.h
| Author       :
| Description  : Header file for class SUI::IFilterable.
|
| ! \file        SUIIFilterable.h
| ! \brief       Header file for class SUI::IFilterable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIIFILTERABLE_H
#define SUIIFILTERABLE_H

#include <string>

#include "SUISharedExport.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for using a filter
 */
class SUI_SHARED_EXPORT IFilterable
{
public:
    virtual ~IFilterable() {}

    /*!
     * \brief setFilter
     * Specifies a filter that needs to be applied
     * \param filter - The string to filter on
     * \param on - Turn filter on or off
     * \param columnNo - The column to apply the filter to, 0 for all columns
     * \param casesensitive - Turn case sensitive filtering on or off
     */
    virtual void setFilter(const std::string &filter, bool on, int columnNo = 0, bool casesensitive = true) = 0;
};
}

#endif // SUIIFILTERABLE_H
