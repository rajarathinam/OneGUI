/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDoxygen.h
| Author       :
| Description  :
|
| ! \file        SUIDoxygen.h
| ! \brief
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef DOXYGEN_H
#define DOXYGEN_H

/*!
This file contains all the groups for the doxygen generation
*/

/*!
  The main groups are the projects

  \defgroup FWQxCore The Core API
  \defgroup FWQxWidgets The Widget API
  \defgroup FWQxGraphicsItems The GraphicsItem API
  \defgroup FWQxUtils The Util API
*/

#endif // DOXYGEN_H
