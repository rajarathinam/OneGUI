/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIExternalEvent.h
| Author       :
| Description  : Header file for class SUI::ExternalEvent.
|
| ! \file        SUIExternalEvent.h
| ! \brief       Header file for class SUI::ExternalEvent.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIEXTERNALEVENT_H
#define SUIEXTERNALEVENT_H

#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The ExternalEvent class
 */
class SUI_SHARED_EXPORT ExternalEvent
{
public:
    virtual ~ExternalEvent() {}
    virtual void emitEvent() = 0;
};
}


#endif // SUIEXTERNALEVENT_H
