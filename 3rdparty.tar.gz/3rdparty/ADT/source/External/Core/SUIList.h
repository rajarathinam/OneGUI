/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIList.h
| Author       :
| Description  : Header file for class SUI::List.
|
| ! \file        SUIList.h
| ! \brief       Header file for class SUI::List.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#ifndef SUILIST_H
#define SUILIST_H

#include <list>
#include <string>

#include <boost/function.hpp>

namespace SUI {

template<typename T>
/*!
 * \ingroup FWQxCore
 *
 * \brief Generic list class of type 'T'
 */
class List
{
public:
    virtual ~List() {}

    /*!
     * \brief clearItems
     * Clears all items from the widget
     */
    virtual void clearItems() = 0;

    /*!
     * \brief getItems
     * Retrieves all items from the widget
     * \return
     */
    virtual std::list<T> getItems() const = 0;

    /*!
     * \brief removeItems
     * Removes items (specified in itemList) from the list
     * \param itemlist
     */
    virtual void removeItems(const std::list<T> &itemlist) = 0;

    /*!
     * \brief selectionChanged
     * Callback function that is called when the selection in the list has changed.
     */
    boost::function<void()> selectionChanged;

    /*!
     * \brief getSelectedItems
     * Retrieves all selected items from the list
     * \return
     */
    virtual std::list<T> getSelectedItems() const = 0;

    /*!
     * \brief selectItem
     * Selects the item based on row- and column number.
     * \param   const int row - The row number
     * \param   const int col - The column number
     */
    virtual void selectItem(const int row, const int col = 0) = 0;

    /*!
     * \brief selectItem
     * Selects the item with a specified id
     * \param   const std::string idstr - The id of the item to select
     */
    virtual void selectItem(const std::string idstr) = 0;
    
    /*!
     * \brief addItems
     * Add items, specified in itemlist, to the list
     * \param itemlist
     */
    virtual void addItems(const std::list<T> &itemlist) = 0;
};
}

#endif // SUILIST_H
