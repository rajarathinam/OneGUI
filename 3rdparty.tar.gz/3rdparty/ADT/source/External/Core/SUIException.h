/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIException.h
| Author       :
| Description  : Header file for class SUI::Exception.
|
| ! \file        SUIException.h
| ! \brief       Header file for class SUI::Exception.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIEXCEPTION_H
#define SUIEXCEPTION_H

#include <string>

#include <exception>
#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Exception class
 */
class SUI_SHARED_EXPORT Exception : public std::exception
{
public:
    /*!
     * \brief Exception
     * constructs an std::exception with the given msg
     * \param msg
     */
    Exception(const std::string &msg);

    virtual ~Exception() throw();

    /*!
     * \brief getExceptionMessage
     * return Exception Message
     * \return
     */
    std::string getExceptionMessage() const;

    /*!
     * \brief what
     * A pointer to a c-string with content related to the exception.
     * \return
     */
    virtual const char *what() const throw();

private:
    std::string mMessage;

    Exception();
};
}
#endif // SUIEXCEPTIONS_H
