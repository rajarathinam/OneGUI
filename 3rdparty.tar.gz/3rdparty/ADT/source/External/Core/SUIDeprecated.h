/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDeprecated.h
| Author       :
| Description  :
|
| ! \file        SUIDeprecated.h
| ! \brief
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIDEPRECATED_H
#define SUIDEPRECATED_H

//#ifndef SUI_DEPRECATED_ENABLE_ERROR
//#  pragma GCC diagnostic warning "-Wdeprecated-declarations"
//#endif
//
//#ifdef __GNUC__
//#  define SUI_DEPRECATED __attribute__((deprecated))
//#elif defined(_MSC_VER)
//#  define SUI_DEPRECATED __declspec(deprecated)
//#else
//#  pragma message("WARNING: You need to implement DEPRECATED for this compiler")
#  define SUI_DEPRECATED
//#endif

#endif // SUIDEPRECATED_H
