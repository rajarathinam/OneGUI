/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIBGColorable.h
| Author       :
| Description  : Header file for class SUI::IBGColorable.
|
| ! \file        SUIIBGColorable.h
| ! \brief       Header file for class SUI::IBGColorable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIIBGCOLORABLE_H
#define SUIIBGCOLORABLE_H

#include "SUIColorEnum.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the background color property of a widget
 */
class IBGColorable
{
public:
    virtual ~IBGColorable() {}

    /*!
     * \brief getBGColor
     * Get the current background color of the widget
     * \return The current background color of the widget
     */
    virtual SUI::ColorEnum::Color getBGColor() const = 0;

    /*!
     * \brief setBGColor
     * Set the current background color of the widget
     * \param color The background color to be set
     * \exception ArgumentException
     * \remarks This function throws a ArgumentException exception when the widget does not support setting the invalid color.
     */
    virtual void setBGColor(const SUI::ColorEnum::Color color) = 0;
};
}

#endif // SUIIBGCOLORABLE_H
