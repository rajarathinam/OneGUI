/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIIAlignable.h
| Author       :
| Description  : Header file for class SUI::IAlignable.
|
| ! \file        SUIIAlignable.h
| ! \brief       Header file for class SUI::IAlignable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IALIGNABLE_H
#define IALIGNABLE_H

#include "SUIAlignmentEnum.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for alignment of a widget
 */
class IAlignable
{
public:
    virtual ~IAlignable() {}

    /*!
     * \brief setAlignment
     * Sets the alignment
     * \param align The kind of alignment to set
     */
    virtual void setAlignment(AlignmentEnum::Alignment align) = 0;

    /*!
     * \brief getAlignment
     * Returns the current alignment
     * \return
     */
    virtual AlignmentEnum::Alignment getAlignment() const = 0;
};
}

#endif // IALIGNABLE_H
