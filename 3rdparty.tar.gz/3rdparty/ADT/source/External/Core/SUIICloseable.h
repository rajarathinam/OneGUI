/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIICloseable.h
| Author       :
| Description  : Header file for class SUI::ICloseable.
|
| ! \file        SUIICloseable.h
| ! \brief       Header file for class SUI::ICloseable.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#ifndef SUICLOSEABLE_H
#define SUICLOSEABLE_H

#include <boost/function.hpp>
#include <SUISharedExport.h>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Interface for the Viewer close handling
 */
class SUI_SHARED_EXPORT ICloseable
{
public:

    ICloseable();
    virtual ~ICloseable()  {}

    /*!
     * \brief close
     * Close the viewer
     */
    virtual void close() = 0;

    /*!
     * \brief closed
     * Callback when the viewer was closed.
     */
    boost::function<void()> closed;

    /*!
     * \brief aboutToClose
     * Callback when the viewer is about to be closed
     */
    boost::function<void()> aboutToClose;

    /*!
     * \brief isCloseable
     * Returns whether the viewer is closeable
     * \return
     */
    virtual bool isCloseable();

    /*!
     * \brief setCloseable
     * Sets the closeable state of the viewer
     * \param value
     */
    virtual void setCloseable(bool value);

private:
    bool closeable;
};
}

#endif // SUICLOSEABLE_H
