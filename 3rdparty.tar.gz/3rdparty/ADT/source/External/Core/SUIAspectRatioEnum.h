/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIAspectRatioEnum.h
| Author       :
| Description  : Header file for class SUI::AspectRatioEnum.
|
| ! \file        SUIAspectRatioEnum.h
| ! \brief       Header file for class SUI::AspectRatioEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIASPECTRATIOENUM_H
#define SUIASPECTRATIOENUM_H

#include <string>

namespace SUI {
class AspectRatioEnum
{
public:
    /*!
     * \brief Mode
     * The aspect ratio enumeration
     */
    typedef enum
    {
        IgnoreAspectRatio,
        KeepAspectRatio,
        KeepAspectRatioByExpanding
    } Mode;
    
    /*!
     * \brief fromString
     * Converts a string to an aspect ratio enumeration
     * \param style
     * \return
     */
    static Mode fromString(const std::string &style);

    /*!
     * \brief toString
     * Converts an aspect ratio enumeration to a string
     * \param style
     * \return
     */
    static std::string toString(const Mode &style);
};
}
#endif // SUIASPECTRATIOENUM_H
