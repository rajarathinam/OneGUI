/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIFontSizeEnum.h
| Author       :
| Description  : Header file for class SUI::FontSizeEnum.
|
| ! \file        SUIFontSizeEnum.h
| ! \brief       Header file for class SUI::FontSizeEnum.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIFONTSIZEENUM_H
#define SUIFONTSIZEENUM_H

#include <map>
#include <string>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe fontsize styles.
 */
class FontSizeEnum
{
public:
    /*!
     * \brief FontSize
     * The font size enumeration
     */
    typedef enum
    {
        Uninitialized,
        Big,
        Normal,
        Small
    } FontSize;

    /*!
     * \brief toString
     * gets string for FontSize Enum
     * \param size
     * \return
     */
    static std::string toString(const FontSize &size);

    /*!
     * \brief fromString
     * gets FontSize enum value from string description
     * \param size
     * \return
     */
    static FontSize fromString(const std::string &size);

private:
    static const std::map<FontSize, const std::string> fontSizeStringMap;
    static const std::map<const std::string,FontSize> stringFontSizeMap;

    static const std::map<const std::string,FontSize> createStringFontSizeMap();
};
}
#endif // SUIFONTSIZEENUM_H
