/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDialogSerializer.h
| Author       :
| Description  : Header file for class SUI::DialogSerializer.
|
| ! \file        SUIDialogSerializer.h
| ! \brief       Header file for class SUI::DialogSerializer.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIGUISERIALIZER_H
#define SUIGUISERIALIZER_H

#include "SUISharedExport.h"

#include "SUIGUIDefinitionVisitor.h"

#include <QString>
#include <QXmlStreamWriter>
#include <QFile>

namespace SUI {
class DialogSerializer: public GUIDefinitionVisitor
{
public:
    typedef enum
    {
        Read,
        Write
    } rticGuiSerializerMode;

    DialogSerializer(const QString startElement, rticGuiSerializerMode mode);
    virtual ~DialogSerializer();

    void openFile(const QString &filename);
    void closeFile();
    virtual void writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value);
    virtual void writeInclude(const QString &include, const QString &fileName);

    virtual GUIDefinitionVisitor &openChildWidget();
    virtual void closeChildWidget();
    void acceptVisitor(GUIDefinitionVisitor &visitor);
    int getWidgetCount() const;

private:
    QXmlStreamWriter *mXmlWriter;
    QXmlStreamReader *mXmlReader;
    QFile *mFile;
    rticGuiSerializerMode mMode;
    QString mStartElement;
    int mWidgetCount;
};
}
#endif // SUIGUISERIALIZER_H
