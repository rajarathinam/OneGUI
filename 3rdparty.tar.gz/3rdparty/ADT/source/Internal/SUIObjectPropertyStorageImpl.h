/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIObjectPropertyStorageImpl.h
| Author       :
| Description  : Header file for class SUI::ObjectPropertyStorageImpl.
|
| ! \file        SUIObjectPropertyStorageImpl.h
| ! \brief       Header file for class SUI::ObjectPropertyStorageImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIGUIPROPERTYSTORAGE_H
#define SUIGUIPROPERTYSTORAGE_H

#include <QString>
#include <QMap>

#include "SUIObjectPropertyStorage.h"

namespace SUI {
class ObjectPropertyStorageImpl : public ObjectPropertyStorage
{
public:
    ObjectPropertyStorageImpl();

    virtual QSet<SUI::ObjectPropertyTypeEnum::Type> getPropertyTypes() const;
    virtual QMap<QString,QString> getIncludes() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QString getPropertyValue(ObjectPropertyTypeEnum::Type propertyID) const;

    virtual void setInclude(const QString &include, const QString &fileName);

private:
    QMap<ObjectPropertyTypeEnum::Type, QString> mStoredProperties;
    QMap<QString, QString> mIncludes;
};
}

#endif // SUIGUIPROPERTYSTORAGE_H
