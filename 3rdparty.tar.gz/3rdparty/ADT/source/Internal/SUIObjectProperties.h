/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIObjectProperties.h
| Author       :
| Description  : Header file for class SUI::ObjectProperties.
|
| ! \file        SUIObjectProperties.h
| ! \brief       Header file for class SUI::ObjectProperties.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIOBJECTPROPERTIES_H
#define SUIOBJECTPROPERTIES_H

#include "SUIObjectPropertyStorage.h"
#include "SUIObjectPropertyTypeEnum.h"

#include <QString>
#include <QMap>

namespace SUI {
class ObjectProperty;
/*!
 \brief
*/
class ObjectProperties : public ObjectPropertyStorage
{
public:
    ObjectProperties(bool supportsChildren);
    virtual ~ObjectProperties();

    /*!
     \brief

     \fn getPropertyList
     \return QStringList
    */
    virtual QSet<SUI::ObjectPropertyTypeEnum::Type> getPropertyTypes() const;
    virtual QMap<QString,QString> getIncludes() const;

    virtual void setInclude(const QString &include, const QString &fileName);
    /*!
     \brief

     \fn setPropertyValue
     \param propertyID
     \param propertyValue
    */
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) = 0;
    /*!
     \brief

     \fn setPropertyValues
     \param propertyID
     \param propertyValue
    */
    virtual void setPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    /*!
     \brief

     \fn getPropertyValue
     \param propertyID
     \return QString
    */
    virtual QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;

    /*!
     * \brief getPropertyValues
     * \param propertyID
     * \return
     */
    virtual QString getPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID) const;

    /*!
     * \brief incrementPropertyValue
     * Increment the specified Property
     * \param propertyID
     * \param propertyValue
     */
    virtual void incrementPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, int propertyValue);

    /*!
     \brief

     \fn supportsChildren
     \return bool
    */
    bool childrenSupported() const;

    void addProperty(SUI::ObjectProperty *property);

    /*!
     * \brief getProperty
     * \param type
     * \return
     */
    virtual SUI::ObjectProperty *getProperty(SUI::ObjectPropertyTypeEnum::Type type) const;

    void setPropertyReadonly(SUI::ObjectPropertyTypeEnum::Type property, bool readOnly = true);
    bool isPropertyReadonly(SUI::ObjectPropertyTypeEnum::Type property) const;
    void setPropertyHidden(SUI::ObjectPropertyTypeEnum::Type property, bool visible = false);
    bool isPropertyVisible(SUI::ObjectPropertyTypeEnum::Type property) const;

private:
    const bool supportsChildren;

    QMap<SUI::ObjectPropertyTypeEnum::Type, SUI::ObjectProperty *> properties;

    QMap<QString,QString> includes;

};
}

#endif // SUIOBJECTPROPERTIES_H
