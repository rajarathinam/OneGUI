/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDateTimeImpl.h
| Author       :
| Description  : Header file for class SUI::DateTimeImpl.
|
| ! \file        SUIDateTimeImpl.h
| ! \brief       Header file for class SUI::DateTimeImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUIDATETIMEIMPL_H
#define SUI_SUIDATETIMEIMPL_H

#include <QDateTime>

#include "SUIDateTime.h"

namespace SUI {

class DateTimeImpl : public QDateTime, public DateTime
{

private:
    explicit DateTimeImpl();

    friend class DateTime;

public:
    virtual void addDays(int ndays);
    virtual void addMSecs(int64_t msecs);
    virtual void addMonths(int nmonths);
    virtual void addSecs(int s);
    virtual void addYears(int nyears);
//    boost::shared_ptr<Date> getDate() const;
    virtual int daysTo(const boost::shared_ptr<DateTime> &other) const;
    virtual bool isNull() const;
    virtual bool isValid() const;
    virtual int64_t getMsecsTo(const boost::shared_ptr<SUI::DateTime> &other) const;
    virtual int getSecsTo(const boost::shared_ptr<SUI::DateTime> &other) const;
    virtual void setDate(const boost::shared_ptr<SUI::Date> &date);
    virtual void setMSecsSinceEpoch(int64_t msecs);
    virtual void setTime(const boost::shared_ptr<Time> &time);
    virtual void setTimeSpec(DateTimeEnum::TimeSpec spec);
    virtual void setTime_t(uint seconds);
    virtual boost::shared_ptr<Time> getTime() const;
    virtual DateTimeEnum::TimeSpec getTimeSpec() const;
    boost::shared_ptr<DateTime> toLocalTime() const;
    virtual int64_t toMSecsSinceEpoch() const;
    virtual std::string toString(const std::string &format) const;
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const;
//    boost::shared_ptr<Date> toTimeSpec(DateTimeEnum::TimeSpec specification) const;
    virtual uint toTime_t() const;
//    boost::shared_ptr<DateTime> toUTC() const;

    virtual bool operator!=(const boost::shared_ptr<DateTime> &other) const;
    virtual bool operator<(const boost::shared_ptr<DateTime> &other) const;
    virtual bool operator<=(const boost::shared_ptr<DateTime> &other) const;
    virtual bool operator==(const boost::shared_ptr<DateTime> &other) const;
    virtual bool operator>(const boost::shared_ptr<DateTime> &other) const;
    virtual bool operator>=(const boost::shared_ptr<DateTime> &other) const;

};

} // namespace SUI

#endif // SUI_SUIDATETIMEIMPL_H
