/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITimerImpl.h
| Author       :
| Description  : Header file for class SUI::TimerImpl.
|
| ! \file        SUITimerImpl.h
| ! \brief       Header file for class SUI::TimerImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUITIMERIMPL_H
#define SUI_SUITIMERIMPL_H

#include <SUITimer.h>

#include <QTimer>

namespace SUI {

class TimerImpl : public QTimer, public SUI::Timer
{

    Q_OBJECT

private:
    explicit TimerImpl(QObject *parent = 0);

    friend class Timer;

public:
    virtual bool isActive() const;

    virtual bool isSingleShot() const;
    virtual void setSingleShot(bool singleShot);

    virtual int	interval() const;
    virtual void setInterval(int msec);

    virtual int	getTimerId() const;

    virtual void start(int msec);
    virtual void start();
    virtual void stop();

private slots:
    void onTimeout();

};

} // namespace SUI

#endif // SUI_SUITIMERIMPL_H
