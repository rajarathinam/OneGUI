/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIBusyIndicatorImpl.h
| Author       :
| Description  : Header file for class SUI::BusyIndicatorImpl.
|
| ! \file        SUIBusyIndicatorImpl.h
| ! \brief       Header file for class SUI::BusyIndicatorImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUSYINDICATORIMPL_H
#define SUIBUSYINDICATORIMPL_H

#include "SUIBusyIndicator.h"

#include "SUIBaseWidget.h"

#include "CustomLabel.h"

class QMovie;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The BusyIndicator class
 */
class BusyIndicatorImpl : public BaseWidget, public BusyIndicator
{
    Q_OBJECT
public:
    explicit BusyIndicatorImpl(QWidget *parent = NULL);

    virtual void startAnimation();
    virtual void stopAnimation();

    virtual void initialize(const ObjectContext &context);
    virtual CustomLabel *getWidget() const;

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

private:
    QMovie *mMovie;

    BusyIndicatorImpl(const BusyIndicatorImpl &rhs);
    BusyIndicatorImpl &operator=(const BusyIndicatorImpl &rhs);
};
}

#endif // SUIBUSYINDICATORIMPL_H
