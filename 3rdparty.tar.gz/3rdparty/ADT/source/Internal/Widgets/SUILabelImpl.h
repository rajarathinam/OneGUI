/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILabelImpl.h
| Author       :
| Description  : Header file for class SUI::LabelImpl.
|
| ! \file        SUILabelImpl.h
| ! \brief       Header file for class SUI::LabelImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILABELIMPL_H
#define SUILABELIMPL_H

#include <QLabel>

#include "SUIBaseWidget.h"
#include "SUILabel.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Label class
 */
class LabelImpl: public BaseWidget, public Label
{
    Q_OBJECT
public:
    explicit LabelImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual QLabel *getWidget() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual SUI::ColorEnum::Color getBGColor() const;
    virtual void setBGColor(const SUI::ColorEnum::Color color);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual AlignmentEnum::Alignment getAlignment() const;

    virtual void setFontSize(const FontSizeEnum::FontSize &fontSize);
    virtual FontSizeEnum::FontSize getFontSize() const;

    void setPropScientific();

private:
    LabelImpl(const LabelImpl &rhs);
    LabelImpl &operator=(const LabelImpl &rhs);
};
}

#endif // SUILABELIMPL_H
