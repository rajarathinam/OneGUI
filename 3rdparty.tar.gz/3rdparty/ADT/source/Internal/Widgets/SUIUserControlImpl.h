/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIUserControlImpl.h
| Author       :
| Description  : Header file for class SUI::UserControlImpl.
|
| ! \file        SUIUserControlImpl.h
| ! \brief       Header file for class SUI::UserControlImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIUSERCONTROLIMPL_H
#define SUIUSERCONTROLIMPL_H

#include "SUIUserControl.h"
#include "SUIBaseWidget.h"

class QObject;
class QWidget;
class QEvent;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The UserControl class
 */
class UserControlImpl : public BaseWidget, public UserControl
{
    Q_OBJECT
public:
    explicit UserControlImpl(QWidget *parent = NULL);

    int getNextIDNumber() { return (++mCurrentID); }

protected:
    virtual bool eventFilter(QObject *obj, QEvent *event);

private slots:
    void handleClicked();

private:
    int mCurrentID; // Used by WidgetController::setUCtrlDefaultID()

    UserControlImpl(const UserControlImpl &rhs);
    UserControlImpl &operator=(const UserControlImpl &rhs);
};
}

#endif // SUIUSERCONTROLIMPL_H
