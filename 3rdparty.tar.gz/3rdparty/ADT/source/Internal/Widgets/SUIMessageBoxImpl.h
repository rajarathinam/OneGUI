/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIMessageBoxImpl.h
| Author       :
| Description  : Header file for class SUI::MessageBoxImpl.
|
| ! \file        SUIMessageBoxImpl.h
| ! \brief       Header file for class SUI::MessageBoxImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIMESSAGEBOXIMPL_H
#define SUIMESSAGEBOXIMPL_H

#include "SUIBaseWidget.h"
#include "SUIMessageBox.h"

#include <QMessageBox>

namespace SUI {
class MessageBoxImpl: public BaseWidget, public MessageBox
{
    Q_OBJECT

public:
    explicit MessageBoxImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QMessageBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual void clearText();
    virtual std::string getText() const;
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setButtonText(const std::list<std::string> &text);
    virtual std::string handleButtonRetour() { return mButtonText.toStdString(); }
    virtual void setDefaultButton(const std::string &button);
    virtual void setTitle(const std::string &titleText) { getWidget()->setWindowTitle(QString::fromStdString(titleText)); }
    virtual std::string getTitle() const { return getWidget()->windowTitle().toStdString(); }

    virtual void setIcon(MessageBoxIconEnum::MessageBoxIconType icon);

private slots:
    void handleClicked(QAbstractButton *button);

private:
    QString mButtonText;

    MessageBoxImpl(const MessageBoxImpl &rhs);
    MessageBoxImpl &operator=(const MessageBoxImpl &rhs);
};
}

#endif // SUIMESSAGEBOXIMPL_H
