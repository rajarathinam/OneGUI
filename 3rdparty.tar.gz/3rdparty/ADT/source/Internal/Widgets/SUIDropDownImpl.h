﻿/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIDropDownImpl.h
| Author       :
| Description  : Header file for class SUI::DropDownImpl.
|
| ! \file        SUIDropDownImpl.h
| ! \brief       Header file for class SUI::DropDownImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIDROPDOWNIMPL_H
#define SUIDROPDOWNIMPL_H

#include <QComboBox>

#include "SUIDropDown.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The DropDown class
 */
class DropDownImpl : public BaseWidget, public DropDown
{
    Q_OBJECT
public:
    explicit DropDownImpl(QWidget *parent = NULL);

    virtual void addItems(const std::list<std::string> &aItems);
    virtual std::list<std::string> getItems() const;
    virtual void clearItems();
    virtual void removeItems(const std::list<std::string> &itemlist);
    virtual std::list<std::string> getSelectedItems() const;
    QString getAllColumnItems(int columnno) const;

    virtual void initialize(const ObjectContext &context);

    virtual QComboBox *getWidget() const;

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    void setBold(bool bold);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual SUI::ColorEnum::Color getBGColor() const;
    virtual void setBGColor(const SUI::ColorEnum::Color color);

    virtual void setMode(ErrorModeEnum::ErrorMode mode);

    virtual void selectItem(const int row, const int col = 0);
    virtual void selectItem(const std::string idstr);

    virtual int getCurrentIndex() const;

    virtual std::string getCurrentText() const;

    virtual void setItemText(int index, const std::string &text);
    virtual std::string getItemText(int index) const;

    virtual void setCurrentIndex(int index);

private slots:
    void onCurrenIndexChanged();

private:
    QStringList formatString(QString &aStr);

    DropDownImpl(const DropDownImpl &rhs);
    DropDownImpl &operator = (const DropDownImpl &rhs);
};
}

#endif // SUIDROPDOWNIMPL_H
