/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITreeViewItemImpl.h
| Author       :
| Description  : Header file for class SUI::TreeViewItemImpl.
|
| ! \file        SUITreeViewItemImpl.h
| ! \brief       Header file for class SUI::TreeViewItemImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUITREEVIEWITEMIMPL_H
#define SUITREEVIEWITEMIMPL_H

#include "CustomLabel.h"

#include "SUIBaseWidget.h"
#include "SUITreeViewItem.h"

namespace SUI {
class TreeViewImpl;

/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TreeViewItem class
 */
class TreeViewItemImpl : public BaseWidget, public TreeViewItem
{
    Q_OBJECT
public:
    explicit TreeViewItemImpl(QWidget *parent = NULL);

    void setTreeviewParent(const TreeViewImpl *treeParent);

    void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual CustomLabel *getWidget() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

private:
    TreeViewImpl *mTreeView;

    TreeViewItemImpl(const TreeViewItemImpl &rhs);
    TreeViewItemImpl &operator=(const TreeViewItemImpl &rhs);

private slots:
    void selectRow();
};
}

#endif // SUITREEVIEWITEMIMPL_H
