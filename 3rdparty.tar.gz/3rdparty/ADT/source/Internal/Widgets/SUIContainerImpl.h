/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIContainerImpl.h
| Author       :
| Description  : Header file for class SUI::ContainerImpl.
|
| ! \file        SUIContainerImpl.h
| ! \brief       Header file for class SUI::ContainerImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICONTAINERIMPL_H
#define SUICONTAINERIMPL_H

#include "SUIBaseWidget.h"
#include "SUIContainer.h"
#include "SUIQUiLoader.h"

#include <QScrollArea>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Container class
 */
class ContainerImpl : public BaseWidget, public Container
{
    Q_OBJECT
public:
    explicit ContainerImpl(QWidget *parent = NULL);
    virtual void setUiFilename(std::string filename);
    virtual ObjectList *getObjectList();

    virtual void initialize(const ObjectContext &context);
    virtual QWidget *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

private:
    SUI::ObjectList mObjectList;
    QScrollArea* mScrollArea;
};
}

#endif // SUICONTAINERIMPL_H
