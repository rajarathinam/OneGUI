/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGraphicsViewImpl.h
| Author       :
| Description  : Header file for class SUI::GraphicsViewImpl.
|
| ! \file        SUIGraphicsViewImpl.h
| ! \brief       Header file for class SUI::GraphicsViewImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIGRAPHICSVIEWIMPL_H
#define SUIGRAPHICSVIEWIMPL_H

#include "SUIBaseWidget.h"
#include "SUIGraphicsView.h"

#include "CustomGraphicsView.h"

#include "SUIImageEnum.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The GraphicsViewImpl class
 */
class GraphicsViewImpl : public BaseWidget, public GraphicsView
{
    Q_OBJECT

public:
    explicit GraphicsViewImpl(QWidget *parent = NULL);

    virtual CustomGraphicsView *getWidget() const;

    virtual void initialize(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    
    int getBorderWidth() const;

protected:
    virtual void setGeometry();

private:
    GraphicsViewImpl();
    GraphicsViewImpl(const GraphicsViewImpl &rhs);
    GraphicsViewImpl &operator=(const GraphicsViewImpl &rhs);
};
}

#endif // SUIGRAPHICSVIEWIMPL_H
