/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUICheckBoxImpl.h
| Author       :
| Description  : Header file for class SUI::CheckBoxImpl.
|
| ! \file        SUICheckBoxImpl.h
| ! \brief       Header file for class SUI::CheckBoxImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICHECKBOXIMPL_H
#define SUICHECKBOXIMPL_H

#include <QCheckBox>

#include "SUICheckBox.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The CheckBox class
 */
class CheckBoxImpl: public BaseWidget, public CheckBox
{
    Q_OBJECT

public:
    explicit CheckBoxImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QCheckBox *getWidget() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setChecked(bool checked);
    virtual bool isChecked() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

private slots:
    void handleCheckedChanged(bool newState);

private:
    CheckBoxImpl(const CheckBoxImpl &rhs);
    CheckBoxImpl &operator=(const CheckBoxImpl &rhs);

};
}

#endif // SUICHECKBOXIMPL_H
