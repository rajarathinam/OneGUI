/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIFileDialogImpl.h
| Author       :
| Description  : Header file for class SUI::FileDialogImpl.
|
| ! \file        SUIFileDialogImpl.h
| ! \brief       Header file for class SUI::FileDialogImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIFILEDIALOGIMPL_H
#define SUIFILEDIALOGIMPL_H

#include <QStringList>

#include "SUIBaseWidget.h"
#include "SUIFileDialog.h"
#include "CustomFileDialog.h"

namespace SUI {

class FileDialogImpl : public BaseWidget, public FileDialog
{
    Q_OBJECT

public:
    FileDialogImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual CustomFileDialog *getWidget() const;

    virtual void setTitle(const std::string &title);
    virtual void setAcceptMode(AcceptMode mode);
    virtual void setAcceptButtonText(const std::string &message) ;
    virtual void setFilter(const std::list<std::string> &filter);
    virtual void setDirectory(const std::string &path);
    virtual void setRootDirectory(const std::string &rootpath);
    virtual std::string getSelectedFiles() const;
    virtual void show(const std::string &title, const std::string &message, const std::list<std::string> &filters, AcceptMode mMode); //main interface

    virtual void setVisible(bool visible);
    
private slots:
    void onClicked(int result);
    void onDirectoryEntered(QString path);

private:
    enum OnCloseResult {Cancel, Accept};

    QStringList mFilenameList;
    QString mRootDir;
    int mMode; //Browser mode, file,save,dir

    void centerWidget();

    FileDialogImpl(const FileDialogImpl &rhs);
    FileDialogImpl &operator=(const FileDialogImpl &rhs);
};
}

#endif // SUIFILEDIALOGIMPL_H
