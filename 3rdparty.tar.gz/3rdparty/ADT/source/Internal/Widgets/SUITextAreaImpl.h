/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITextAreaImpl.h
| Author       :
| Description  : Header file for class SUI::TextAreaImpl.
|
| ! \file        SUITextAreaImpl.h
| ! \brief       Header file for class SUI::TextAreaImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUITEXTAREAIMPL_H
#define SUITEXTAREAIMPL_H

#include <QTextEdit>

#include "SUITextArea.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TextArea class
 */
class TextAreaImpl : public BaseWidget, public TextArea
{
    Q_OBJECT

public:
    explicit TextAreaImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QTextEdit *getWidget() const;

    virtual void setText(const std::string &value);
    virtual void clearText();
    virtual std::string getText() const;
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setAutoScroll(bool scroll);
    virtual void setReadonly(bool readOnly);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual void setMode(ErrorModeEnum::ErrorMode mode);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;

private slots:
    void onTextChanged();

private:
    bool 	mBold;
    AlignmentEnum::Alignment mAlign;

    QString colorSelect(QString color);

    TextAreaImpl(const TextAreaImpl &rhs);
    TextAreaImpl &operator=(const TextAreaImpl &rhs);
};
}

#endif // SUITEXTAREAIMPL_H
