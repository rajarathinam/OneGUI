/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIWidgetPageImpl.h
| Author       :
| Description  : Header file for class SUI::WidgetPageImpl.
|
| ! \file        SUIWidgetPageImpl.h
| ! \brief       Header file for class SUI::WidgetPageImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIWIDGETPAGEIMPL_H
#define SUIWIDGETPAGEIMPL_H

#include "SUIBasePageImpl.h"
#include "SUIWidgetPage.h"

class QWidget;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The WidgetPage class
 */
class WidgetPageImpl : public BasePageImpl, public WidgetPage
{
   
public:
    explicit WidgetPageImpl(QWidget *parent = NULL);

private:
    WidgetPageImpl(const WidgetPageImpl &rhs);
    WidgetPageImpl &operator=(const WidgetPageImpl &rhs);
};
}

#endif // SUIWIDGETPAGEIMPL_H
