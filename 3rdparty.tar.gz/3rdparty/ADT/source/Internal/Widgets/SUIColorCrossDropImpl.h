/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIColorCrossDropImpl.h
| Author       :
| Description  : Header file for class SUI::ColorCrossDropImpl.
|
| ! \file        SUIColorCrossDropImpl.h
| ! \brief       Header file for class SUI::ColorCrossDropImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUICOLORCROSSDROPIMPL_H
#define SUICOLORCROSSDROPIMPL_H

#include <QComboBox>

#include "SUIColorCrossDrop.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ColorCrossDrop class
 */
class ColorCrossDropImpl : public BaseWidget, public ColorCrossDrop
{
    Q_OBJECT
public:
    explicit ColorCrossDropImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QComboBox *getWidget() const;

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private slots:
    void onCurrentIndexChanged();

private:
    void setValues();
    QImage image(QString color);

    ColorCrossDropImpl();
    ColorCrossDropImpl(const ColorCrossDropImpl &rhs);
    ColorCrossDropImpl &operator = (const ColorCrossDropImpl &rhs);
};
}

#endif // SUICOLORCROSSDROPIMPL_H
