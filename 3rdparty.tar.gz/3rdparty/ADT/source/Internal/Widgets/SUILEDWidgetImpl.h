/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUILEDWidgetImpl.h
| Author       :
| Description  : Header file for class SUI::LEDWidgetImpl.
|
| ! \file        SUILEDWidgetImpl.h
| ! \brief       Header file for class SUI::LEDWidgetImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUILEDWIDGETIMPL_H
#define SUILEDWIDGETIMPL_H

#include <QLabel>

#include "SUILEDWidget.h"

#include "SUIBaseWidget.h"

namespace SUI {
class SUI_DEPRECATED LEDWidgetImpl : public BaseWidget, public LEDWidget
{
    Q_OBJECT
public:
    explicit LEDWidgetImpl(QWidget *parent = NULL);

    virtual QLabel *getWidget() const;
    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private:
    LEDWidgetImpl(const LEDWidgetImpl &rhs);
    LEDWidgetImpl &operator=(const LEDWidgetImpl &rhs);

};
}

#endif // SUILEDWIDGETIMPL_H
