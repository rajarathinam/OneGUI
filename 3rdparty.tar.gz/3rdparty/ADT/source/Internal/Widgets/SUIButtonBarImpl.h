/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButtonBarImpl.h
| Author       :
| Description  : Header file for class SUI::ButtonBarImpl.
|
| ! \file        SUIButtonBarImpl.h
| ! \brief       Header file for class SUI::ButtonBarImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUTTONBARIMPL_H
#define SUIBUTTONBARIMPL_H

#include "SUIBaseWidget.h"

#include "SUIButtonBar.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ButtonBar class
 */
class ButtonBarImpl : public BaseWidget, public ButtonBar
{
    Q_OBJECT
public:
    explicit ButtonBarImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);

private:
    ButtonBarImpl(const ButtonBarImpl &rhs);
    ButtonBarImpl &operator=(const ButtonBarImpl &rhs);

};
}


#endif // SUIBUTTONBARIMPL_H
