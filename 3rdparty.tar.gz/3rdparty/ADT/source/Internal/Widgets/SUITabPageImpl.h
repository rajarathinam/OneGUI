/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUITabPageImpl.h
| Author       :
| Description  : Header file for class SUI::TabPageImpl.
|
| ! \file        SUITabPageImpl.h
| ! \brief       Header file for class SUI::TabPageImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUITABPAGEIMPL_H
#define SUITABPAGEIMPL_H

#include "SUIBasePageImpl.h"
#include "SUITabPage.h"

#include <QFrame>

class QWidget;

namespace SUI {
class TabWidgetImpl;
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TabPage class
 */
class TabPageImpl : public BasePageImpl, public TabPage
{
    Q_OBJECT
public:
    explicit TabPageImpl(QWidget *parent = NULL);

    virtual QFrame *getWidget() const;

    virtual void initialize(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setTabText(const std::string &title);
    virtual std::string getTabText() const;

    virtual std::string getIconName() const;
    virtual void setIconName(const std::string &icon);
    virtual void removeIcon();
    virtual const std::list<std::string> getAvailableIconNames() const;

    void setTabWidgetParent(TabWidgetImpl *tabwidget);

    bool isChild(std::string widgetId);
    
    virtual void setVisible(bool visible);
    virtual void setEnabled(bool enabled);

private:
    SUI::TabWidgetImpl *mParentTabWidget;

    TabPageImpl(const TabPageImpl &rhs);
    TabPageImpl &operator=(const TabPageImpl &rhs);
};
}

#endif // SUITABPAGEIMPL_H
