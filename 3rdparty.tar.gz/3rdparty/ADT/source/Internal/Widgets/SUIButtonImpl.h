/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIButtonImpl.h
| Author       :
| Description  : Header file for class SUI::ButtonImpl.
|
| ! \file        SUIButtonImpl.h
| ! \brief       Header file for class SUI::ButtonImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIBUTTONIMPL_H
#define SUIBUTTONIMPL_H

#include "SUIButton.h"

#include "SUIBaseWidget.h"
#include "SUIAlignmentEnum.h"

#include <CustomPushButton.h>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Button class
 */
class ButtonImpl : public BaseWidget, public Button
{
    Q_OBJECT
public:
    explicit ButtonImpl(QWidget *parent = NULL);

    virtual CustomPushButton *getWidget() const;

    virtual void initialize(const ObjectContext &context);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setImage(const std::string &value);
    virtual void setImage(unsigned char *data , int width, int height, ImageEnum::Format format);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

protected:
    virtual void setGeometry();

private slots:
    void handleClicked();
    void loadDefaultImage();
    void loadPressedImage();

private:
    ButtonImpl(const ButtonImpl &rhs);
    ButtonImpl &operator=(const ButtonImpl &rhs);

};
}

#endif // SUIBUTTONIMPL_H
