/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIQuestionMarkImpl.h
| Author       :
| Description  : Header file for class SUI::QuestionMarkImpl.
|
| ! \file        SUIQuestionMarkImpl.h
| ! \brief       Header file for class SUI::QuestionMarkImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIQUESTIONMARKIMPL_H
#define SUIQUESTIONMARKIMPL_H

#include "CustomToolButton.h"

#include "SUIBaseWidget.h"
#include "SUIQuestionMark.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The QuestionMark class
 */
class QuestionMarkImpl : public BaseWidget, public QuestionMark
{
    Q_OBJECT
public:
    explicit QuestionMarkImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual CustomToolButton *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    void setContent(QString content);
    QString getContent();
    void setImage(QString value);
    bool checkContent();

private slots:
    void onMouseRelease();

private:
    QString mFile;
    QString mContent;

    QuestionMarkImpl(const QuestionMarkImpl &rhs);
    QuestionMarkImpl &operator=(const QuestionMarkImpl &rhs);
};
}

#endif // SUIQUESTIONMARKIMPL_H
