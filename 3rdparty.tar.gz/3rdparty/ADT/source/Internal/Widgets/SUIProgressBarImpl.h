/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIProgressBarImpl.h
| Author       :
| Description  : Header file for class SUI::ProgressBarImpl.
|
| ! \file        SUIProgressBarImpl.h
| ! \brief       Header file for class SUI::ProgressBarImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIPROGRESSBARIMPL_H
#define SUIPROGRESSBARIMPL_H

#include "SUIProgressBar.h"
#include "SUIBaseWidget.h"

#include <QProgressBar>

class QTimer;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ProgressBar class
 */
class ProgressBarImpl: public BaseWidget, public ProgressBar
{
    Q_OBJECT

public:
    explicit ProgressBarImpl(QWidget *parent = NULL);
    virtual ~ProgressBarImpl();

    virtual void initialize(const ObjectContext &context);
    virtual QProgressBar *getWidget() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual OrientationEnum::Orientation getOrientation() const;
    virtual void setOrientation(OrientationEnum::Orientation orientation);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual int getValue() const;
    virtual void setValue(int value);
    virtual void disablePercentage(bool disabled);
    virtual void startTimedProgress(int expectedSecs);
    virtual void stopTimedProgress(int showReadyMSecs);

private slots:
    void onValueChanged();
    void onProgressTimer();
    void onResetProgressBarTimer();

private:
    OrientationEnum::Orientation mOrientation;
    QTimer *mProgressTimer;
    int mProgressValue;
    int mMaxProgressValue;

    std::list<SUI::OrientationEnum::Orientation> orientationsEnumList;

    ProgressBarImpl();
    ProgressBarImpl(const ProgressBarImpl &rhs);
    ProgressBarImpl &operator=(const ProgressBarImpl &rhs);
};
}

#endif // SUIPROGRESSBARIMPL_H
