/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIPlotWidgetImpl.h
| Author       :
| Description  : Header file for class SUI::PlotWidgetImpl.
|
| ! \file        SUIPlotWidgetImpl.h
| ! \brief       Header file for class SUI::PlotWidgetImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIPLOTWIDGETIMPL_H
#define SUIPLOTWIDGETIMPL_H

#include <QList>
#include <QMap>
#include <QRectF>
#include "SUIBaseWidget.h"
#include "SUIPlotWidget.h"
#include "CustomPlotDataSet.h"

#include <qwt_plot.h>
#include <qwt_plot_directpainter.h>
#include <qwt_legend.h>
#include <qwt_interval.h>
#include <qwt_symbol.h>
#include <qwt_painter.h>
#include <qwt_plot_zoneitem.h>
#include <qwt_plot_marker.h>
#include <qwt_plot_textlabel.h>
#include <qwt_scale_engine.h>
#include <qwt_date_scale_engine.h>
#include <qwt_plot_grid.h>
#include <qwt_plot_picker.h>
#include <qwt_plot_zoomer.h>
#include <qwt_date_scale_engine.h>
#include <qwt_date_scale_draw.h>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ZoneRectangle class
 */
class ZoneRectangle : public QwtPlotZoneItem
{
public:
    ZoneRectangle(QwtPlot *parent);

    void setColor(const QColor &color);

    void setLabel(QString label);

    void setLabelPosition();

    virtual void setVisible(bool set);

    void setInterval(double min, double max);

private:
    double mMin;
    double mMax;
    QwtPlot *mParent;
    QwtPlotMarker *mLabelMarker;
};

class RangeRectangle : public QwtPlotItem
{
public:
    RangeRectangle();

    void setRectangle(const int x, const int y, const int width, const int height,
                      CurveColorEnum::CurveColor color, PlotAxisEnum::PlotAxis axis, const std::string &label);

    virtual void draw(QPainter *painter, const QwtScaleMap &xMap, const QwtScaleMap &yMap, const QRectF &canvasRect) const;


    static QColor mapColor(CurveColorEnum::CurveColor color);
private:
    QRect mRangeRect;
    QString	mLabel;
    CurveColorEnum::CurveColor mColor;
    PlotAxisEnum::PlotAxis mAxis;
};

class PickerPlotWidget : public QwtPlotPicker
{
public:
    PickerPlotWidget( int xAxis, int yAxis, RubberBand rubberBand, DisplayMode trackerMode, QWidget *canvas);

    void setXAxisScale(PlotAxisEnum::XAxisDateTime aAxis);
protected:
    //Overriding of the trackerText to display text near the picker.
    virtual QwtText trackerTextF(const QPointF &pos) const;
private:
    PlotAxisEnum::XAxisDateTime mXAxis;
};


class ZoomPlotWidget : public QwtPlotZoomer
{
public:
    ZoomPlotWidget(int xAxis, int yAxis, QWidget *canvas);
};

class DateTimeScaleDraw: public QwtDateScaleDraw
{
public:
    DateTimeScaleDraw(Qt::TimeSpec timeSpec);

    void setXAxisScale(PlotAxisEnum::XAxisDateTime aAxis);

    virtual QwtText label(double value) const;
private:
    PlotAxisEnum::XAxisDateTime mXAxis;
};

class PlotWidgetImpl : public BaseWidget, public PlotWidget
{
    Q_OBJECT
public:

    explicit PlotWidgetImpl(QWidget *parent = NULL);
    virtual ~PlotWidgetImpl();

    virtual void initialize(const ObjectContext &context);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void clearDataset(const std::string &setName);
    virtual void createDataset(const std::string &setName, PlotAxisEnum::PlotAxis side);
    virtual void deleteDataset(const std::string &setName);
    virtual std::string getDatasetList() const;
    virtual void hideDataset(const std::string &setName, bool on = true);
    virtual void setDataPoint(const std::string &setName, const double x, const double y);
    virtual void setDataPoints(const std::string &setName, const double *xData, const double *yData, int size);
    virtual void setRawDataPoints(const std::string &setName, const double *xData, const double *yData, int size);
    virtual void autoReplot(bool bAutoReplotEnable);
    virtual void replot() const;

    virtual void setStyle(const std::string &setName, CurveColorEnum::CurveColor color, LineStyleEnum::LineStyle linestyle, int penwidth);
    virtual void setPlotMarker(const std::string &setName, CurveColorEnum::CurveColor color, MarkerSymbolEnum::MarkerSymbol markerSymbol, int symbolSize);
    void clearPlotMarker(const std::string &setName);

    virtual void setRectangle(const int id, const double start, const double end, CurveColorEnum::CurveColor color, bool set,
                              const std::string &label, const PlotAxisEnum::PlotAxis axis);
    virtual void setROI(int id, bool set, const std::string &label, int xstart = INT_MAX, int xend = INT_MAX, int ystart = INT_MAX, int yend = INT_MAX,
                        CurveColorEnum::CurveColor color = CurveColorEnum::Black, const PlotAxisEnum::PlotAxis axis = PlotAxisEnum::yLeft);

    virtual void enableLegend(bool on);

    virtual void setScaleType(PlotAxisEnum::PlotAxis side, ScaleTypeEnum::ScaleType type);
    virtual void setXAutoShift(bool set);
    virtual void setXGrid(GridStyleEnum::GridStyle style);
    virtual void setYGrid(GridStyleEnum::GridStyle style);
    virtual void setXLabel(const std::string &label);
    virtual void setYLeftLabel(const std::string &label);
    virtual void setYRightLabel(const std::string &label);
    virtual void setXScale(const double xMin, const double xMax);
    virtual void setYLeftScale(const double yMin, const double yMax);
    virtual void setYRightScale(const double yMin, const double yMax);

    virtual void setTitle(const std::string &title);
    virtual std::string getTitle() const;

    void handleClicked();
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    int count() const;

private:
    typedef struct SCALEPOINTS
    {
        double XBottom_min;
        double XBottom_max;
        double YLeft_min;
        double YLeft_max;
        double YRight_min;
        double YRight_max;
    } ScalePoints;

    bool mXScaleAutoShift;
    bool mYLeftSideUsed;
    bool mYRightSideUsed;
    QwtPlot *mPlot;
    QList<CustomPlotDataSet*> mDataSetList;
    QwtInterval mIntervalX;
    QwtInterval mIntervalY;     // Is created to make a difference with Y-axis min and max values, which are currently not used
    QwtPlotDirectPainter *mDirectPainter;
    ScalePoints mScalePoints;
    QMap<int, ZoneRectangle*> mZoneItems;
    ScaleTypeEnum::ScaleType mLeftScaleType;
    ScaleTypeEnum::ScaleType mRightScaleType;
    QwtPlotGrid *mPlotGrid;
    QMap<int,RangeRectangle*> mRangeRectangles;

    PickerPlotWidget *mpicker;
    ZoomPlotWidget *mzoomer[2];

    DateTimeScaleDraw *mXscaleDraw;
    bool mbAutoReplot;

    void checkInterval(const double limit);
    QwtScaleEngine *makeNewEngine(ScaleTypeEnum::ScaleType type);
    void refreshDataRegion(CustomPlotDataSet *dataset, const double maxX);

    PlotWidgetImpl(const PlotWidgetImpl &rhs);
    PlotWidgetImpl &operator=(const PlotWidgetImpl &rhs);

private slots:
    void onScaleChanged();
};
}

#endif // SUIPLOTWIDGETIMPL_H
