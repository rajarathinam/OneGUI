/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomTabWidget.h
| Author       :
| Description  : Header file for class CustomTabWidget.
|
| ! \file        CustomTabWidget.h
| ! \brief       Header file for class CustomTabWidget.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMTABWIDGET_H
#define CUSTOMTABWIDGET_H

#include <QTabWidget>
#include <QTabBar>

class CustomTabWidget : public QTabWidget
{
    Q_OBJECT
public:
    explicit CustomTabWidget(QWidget *parent = NULL);

    QTabBar *getTabBar();
    int getTabIndex(const QPoint &event);
    
private:
    CustomTabWidget();
    CustomTabWidget(const CustomTabWidget &rhs);
    CustomTabWidget &operator=(const CustomTabWidget &rhs);
};

#endif // CUSTOMTABWIDGET_H
