/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomTableItemDelegate.h
| Author       :
| Description  : Header file for class CustomTableItemDelegate.
|
| ! \file        CustomTableItemDelegate.h
| ! \brief       Header file for class CustomTableItemDelegate.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMTABLEITEMDELEGATE_H
#define CUSTOMTABLEITEMDELEGATE_H

#include <QStyledItemDelegate>

class QWidget;

namespace SUI {

class CustomTableItemDelegate : public QStyledItemDelegate
{
public:
    explicit CustomTableItemDelegate(QObject *parent);

protected:
    virtual void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
};

}
#endif // CUSTOMTABLEITEMDELEGATE_H
