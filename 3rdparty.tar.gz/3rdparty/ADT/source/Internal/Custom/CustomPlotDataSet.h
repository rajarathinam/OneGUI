/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomPlotDataSet.h
| Author       :
| Description  : Header file for class CustomPlotDataSet.
|
| ! \file        CustomPlotDataSet.h
| ! \brief       Header file for class CustomPlotDataSet.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef CUSTOMPLOTDATASET_H
#define CUSTOMPLOTDATASET_H

#include <QString>
#include <qwt_plot.h>
#include <qwt_plot_curve.h>
#include <qwt_plot_marker.h>
#include <qwt_symbol.h>

#include "CustomCurveData.h"

#include "SUICurveColorEnum.h"
#include "SUILineStyleEnum.h"
#include "SUIPlotAxisEnum.h"

class CustomPlotDataSet
{
public:
    CustomPlotDataSet(const QString &setName, SUI::PlotAxisEnum::PlotAxis side);
    ~CustomPlotDataSet();

    const QString &getSetName() const;
    QwtPlotCurve *getPlotCurve() const;
    void  clearDataSet();
    int   getPaintedPoints() const;
    void  setPaintedPoints(int val);
    int   size() const;
    QRectF getBoundingRect();
    SUI::PlotAxisEnum::PlotAxis side() const;

    void setDataPoint(double x, double y);
    void setDataBoundingRect(double x, double y);
    void setStyle(SUI::CurveColorEnum::CurveColor color, SUI::LineStyleEnum::LineStyle linestyle, int width);
    void setMarker(SUI::CurveColorEnum::CurveColor color);
    void clearOldData(double limit);

    static QColor toQtColor(const SUI::CurveColorEnum::CurveColor color);
    QList<QwtPlotMarker *> getPlotMarkerList() const;

private:
    int mPaintedPoints;
    QString mSetName;
    QwtPlotCurve *mPlotCurve;
    SUI::PlotAxisEnum::PlotAxis mSide;
    QList<QwtPlotMarker *> mPlotMarkerList;

    CustomPlotDataSet();
    CustomPlotDataSet(const CustomPlotDataSet &rhs);
    CustomPlotDataSet &operator=(const CustomPlotDataSet &rhs);
};

#endif // CUSTOMPLOTDATASET_H
