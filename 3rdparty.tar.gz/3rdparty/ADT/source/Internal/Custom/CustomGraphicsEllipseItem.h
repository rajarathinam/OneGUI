/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomGraphicsEllipseItem.h
| Author       :
| Description  : Header file for class CustomGraphicsEllipseItem.
|
| ! \file        CustomGraphicsEllipseItem.h
| ! \brief       Header file for class CustomGraphicsEllipseItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMGRAPHICSELLIPSEITEM_H
#define CUSTOMGRAPHICSELLIPSEITEM_H

#include <QGraphicsEllipseItem>

class CustomGraphicsEllipseItem : public QGraphicsEllipseItem 
{
   
public:
   explicit CustomGraphicsEllipseItem(const QRectF &rect, QGraphicsItem *parent);

protected:
   virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
   
};

#endif // CUSTOMGRAPHICSELLIPSEITEM_H
