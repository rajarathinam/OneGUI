/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomGraphicsSvgItem.h
| Author       :
| Description  : Header file for class CustomGraphicsSvgItem.
|
| ! \file        CustomGraphicsSvgItem.h
| ! \brief       Header file for class CustomGraphicsSvgItem.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMGRAPHICSSVGITEM_H
#define CUSTOMGRAPHICSSVGITEM_H

#include <QGraphicsSvgItem>

#include <QDomDocument>
#include <QHash>
#include <QHelpEvent>
#include <string>
#include <boost/function.hpp>

#include "SUIColorEnum.h"

class QGraphicsSceneMouseEvent;
class QSvgRenderer;

class CustomGraphicsSvgItem : public QGraphicsSvgItem
{
public:
    explicit CustomGraphicsSvgItem(QGraphicsItem *parent = NULL);

    void setImage(const std::string &image);

    void setElementId(const std::string &id);
    std::string elementId();

    std::list<std::string> getElementIdList(void);
    void setElementColor(const std::string idvalue, const SUI::ColorEnum::Color color);
    void setElementBorderColor(const std::string idvalue, const SUI::ColorEnum::Color borderColor);
    void setElementBorderWidth(const std::string idvalue, const int borderWidth);
    void setElementTextColor(const std::string idvalue, const SUI::ColorEnum::Color color);

    void setElementText(const std::string idvalue, const std::string text);
    std::string getElementText(const std::string idvalue);

    void elideText(int width);
    void resetElideText(void);

    void setElementToolTip(const std::string idvalue, const std::string tipText);
    std::string getElementToolTip(const std::string idvalue);

    typedef boost::function<void(const std::string &)> function_type;
    void setElementDoubleClickEvent(const std::string idvalue, function_type func);

    void setPosition(double x, double y);
    virtual QRectF boundingRect() const;
    void setX(double x);
    void setY(double y);
    void setVisible(bool visible);
    bool isVisible() const;

protected:
    virtual void mouseDoubleClickEvent(QGraphicsSceneMouseEvent *event);
    virtual bool sceneEvent(QEvent *event);

private:
    void recursiveParseSvgImage(QDomNode node);
    void parseSvgImage(void);
    void mapSvgTextElements(void);

    QDomDocument mSvgDomDocument;
    QSvgRenderer *mRenderer;
    QHash<QString, QDomNode> mDomNodeForElement;
    QMap<QString, QString> mMapIdTexts;
    QSizeF mScale;
    int melidelength;
    std::map<std::string, function_type> mIdToFunctypeMap;

    CustomGraphicsSvgItem();
    CustomGraphicsSvgItem(const CustomGraphicsSvgItem &rhs);
    CustomGraphicsSvgItem &operator=(const CustomGraphicsSvgItem &rhs);
};

#endif // CUSTOMGRAPHICSSVGITEM_H
