/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomFileDialog.h
| Author       :
| Description  : Header file for class CustomFileDialog.
|
| ! \file        CustomFileDialog.h
| ! \brief       Header file for class CustomFileDialog.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMFILEDIALOG_H
#define CUSTOMFILEDIALOG_H

#include <QFileDialog>

class QWidget;

class CustomFileDialog : public QFileDialog //to access events
{
    Q_OBJECT
public:
    CustomFileDialog(QWidget *parent = NULL);

protected:
    virtual void changeEvent(QEvent *e);

    // there is no workable mouse press event for QFileDialog object;
    // it only works on the dialog and not the different items on the dialog
    // how to access the listView items of QFileDialog?
    virtual void mousePressEvent(QMouseEvent *e);


};

#endif // CUSTOMFILEDIALOG_H
