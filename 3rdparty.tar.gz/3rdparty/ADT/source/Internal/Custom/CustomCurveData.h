/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomCurveData.h
| Author       :
| Description  : Header file for class CustomCurveData.
|
| ! \file        CustomCurveData.h
| ! \brief       Header file for class CustomCurveData.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMCURVEDATA_H
#define CUSTOMCURVEDATA_H

#include <QVector>
#include <QList>
#include <QPointF>
#include <qwt_series_data.h>

class CustomCurveData : public QwtSeriesData<QPointF>
{
public:
    CustomCurveData();

    virtual QPointF sample(size_t val) const      { return mData[val]; }
    virtual size_t size() const                    { return mData.size(); }
    virtual QRectF boundingRect() const            { return mBoundingRect; }
    void clear()                         { mData.clear(); mBoundingRect = QRectF(1.0, 1.0, -2.0, -2.0); }

    void append(const QPointF point);
    void setBoundingRect(const QPointF point);
    void clearOldData(const double limit);

private:
    QVector<QPointF> mData;
    QRectF mBoundingRect;
};

#endif // CUSTOMCURVEDATA_H
