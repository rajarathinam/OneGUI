/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomDoubleSpinBox.h
| Author       :
| Description  : Header file for class CustomDoubleSpinBox.
|
| ! \file        CustomDoubleSpinBox.h
| ! \brief       Header file for class CustomDoubleSpinBox.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMDOUBLESPINBOX_H
#define CUSTOMDOUBLESPINBOX_H

#include <QDoubleSpinBox>

class CustomDoubleSpinBox : public QDoubleSpinBox
{
    Q_OBJECT
public:
    explicit CustomDoubleSpinBox(QWidget *parent = NULL);

    virtual void stepBy(int steps);
    void setStepSizeValueToFactor(const bool on);

private:
    bool mValueIsFactor;

    CustomDoubleSpinBox();
    CustomDoubleSpinBox(const CustomDoubleSpinBox &rhs);
    CustomDoubleSpinBox &operator=(const CustomDoubleSpinBox &rhs);
};

#endif // CUSTOMDOUBLESPINBOX_H
