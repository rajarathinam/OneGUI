/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomLabel.h
| Author       :
| Description  : Header file for class CustomLabel.
|
| ! \file        CustomLabel.h
| ! \brief       Header file for class CustomLabel.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMLABEL_H
#define CUSTOMLABEL_H

#include <QLabel>

class CustomLabel : public QLabel
{
    Q_OBJECT
public:
    explicit CustomLabel(QWidget *parent = NULL);

protected:
    virtual void mousePressEvent(QMouseEvent *event);

    virtual void hideEvent(QHideEvent *event);
    virtual void showEvent(QShowEvent *event);

signals:
    void select();

    void visibilityChanged(bool isVisible);
};

#endif // CUSTOMLABEL_H
