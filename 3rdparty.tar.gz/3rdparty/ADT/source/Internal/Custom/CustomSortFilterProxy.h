/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : CustomSortFilterProxy.h
| Author       :
| Description  : Header file for class CustomSortFilterProxy.
|
| ! \file        CustomSortFilterProxy.h
| ! \brief       Header file for class CustomSortFilterProxy.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef CUSTOMSORTFILTERPROXY_H
#define CUSTOMSORTFILTERPROXY_H

#include <QSortFilterProxyModel>

namespace SUI {

struct FilterParameters {
    QString filterText;
    Qt::CaseSensitivity caseSensitivity;
};

class CustomSortFilterProxy : public QSortFilterProxyModel
{
    Q_OBJECT
public:
    explicit CustomSortFilterProxy(QObject *parent = 0);

    void setColumnFilterFixedString(int column, const QString &fixedString, Qt::CaseSensitivity caseSensitivity = Qt::CaseInsensitive);

protected:
    virtual bool lessThan(const QModelIndex &, const QModelIndex &) const;
    virtual bool filterAcceptsRow(int sourceRow, const QModelIndex &sourceParent) const;
    virtual QVariant headerData(int section, Qt::Orientation orientation, int role) const;

private:
    QMap<qint32,FilterParameters> columnPatterns;
};

}

#endif // CUSTOMSORTFILTERPROXY_H
