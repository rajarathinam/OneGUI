/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIGUIDefinitionVisitor.h
| Author       :
| Description  : Header file for class SUI::GUIDefinitionVisitor.
|
| ! \file        SUIGUIDefinitionVisitor.h
| ! \brief       Header file for class SUI::GUIDefinitionVisitor.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIGUIDEFINITIONVISITOR_H
#define SUIGUIDEFINITIONVISITOR_H

#include <QString>

#include "SUIObjectPropertyTypeEnum.h"

/*!
 \brief The interface class for interaction the childwidgets
*/
class GUIDefinitionVisitor
{
public:
    /*!
     \brief Deconstructor

     \fn ~IRticGUIDefinitionVisitor
    */
    virtual ~GUIDefinitionVisitor()    {}

    /*!
     \brief Set the property of the widget

     \fn writeWidgetProperty
     \param key - The property key
     \param value - The property value
    */
    virtual void writeWidgetProperty(SUI::ObjectPropertyTypeEnum::Type key, const QString &value) = 0;
    virtual void writeInclude(const QString &include, const QString &fileName) = 0;

    /*!
     \brief Append a child to the childrenlist

     \fn openChildWidget
     \return IRticGUIDefinitionVisitor - The widgetDefinition
    */
    virtual GUIDefinitionVisitor  &openChildWidget() = 0;
    /*!
     \brief Close the childwidget
     \remarks This function doesn't do anything

     \fn closeChildWidget
    */
    virtual void closeChildWidget() = 0;

};

#endif // SUIGUIDEFINITIONVISITOR_H
