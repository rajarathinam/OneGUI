/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIBaseObject.h
| Author       :
| Description  : Header file for class SUI::BaseObject.
|
| ! \file        SUIBaseObject.h
| ! \brief       Header file for class SUI::BaseObject.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_BASEOBJECT_H
#define SUI_BASEOBJECT_H

#include "SUIObjectProperties.h"
#include "SUIObjectType.h"

namespace SUI {

class BaseObject : public ObjectProperties
{
public:   
    typedef enum
    {
        EditorSelector,
        EditorForm,
        Gui
    } ObjectContext;

    BaseObject(const ObjectContext &objectContext, const ObjectType::Type &objectType, bool supportsChildren);

    virtual void initialize(const ObjectContext &context);

    void setId(const std::string &id);
    std::string getId() const;

    virtual void setVisible(bool visible) = 0;
    virtual bool isVisible() const;

    virtual std::string getToolTip() const = 0;
    virtual void setToolTip(const std::string &toolTip) = 0;

    bool isToolTipEnabled() const;
    void setToolTipEnabled(bool enabled);

    ObjectType::Type getObjectType() const;
    
    ObjectContext getObjectContext() const;
    void setObjectContext(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

private:
    const ObjectType::Type objectType;
    
    ObjectContext objectContext;

    bool toolTipEnabled;
};

} // namespace SUI

#endif // SUI_BASEOBJECT_H
