/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIApplicationImpl.h
| Author       :
| Description  : Header file for class SUI::ApplicationImpl.
|
| ! \file        SUIApplicationImpl.h
| ! \brief       Header file for class SUI::ApplicationImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_SUIAPPLICATIONIMPL_H
#define SUI_SUIAPPLICATIONIMPL_H

#include "SUIApplication.h"

#include <QApplication>

namespace SUI {

class ApplicationImpl : public QApplication, public SUI::Application
{
public:
    explicit ApplicationImpl(int &argc, char *argv[]);

    virtual int exec();


    virtual void setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Country country);
    virtual void setLocale(SUI::LocaleEnum::Language language, SUI::LocaleEnum::Script script, SUI::LocaleEnum::Country country);

    virtual std::list<std::string> getArguments() const;

protected:
    virtual bool notify(QObject *object, QEvent *event);
};

}

#endif // SUI_SUIAPPLICATIONIMPL_H
