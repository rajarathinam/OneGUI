/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIExternalEventHandlerImpl.h
| Author       :
| Description  : Header file for class SUI::ExternalEventHandlerImpl.
|
| ! \file        SUIExternalEventHandlerImpl.h
| ! \brief       Header file for class SUI::ExternalEventHandlerImpl.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUIEXTERNALEVENTHANDLERIMPL_H
#define SUIEXTERNALEVENTHANDLERIMPL_H

#include "SUIExternalEvent.h"

#include <QObject>

namespace SUI {

class ExternalEventHandlerImpl : public QObject
{
    Q_OBJECT
public:
    explicit ExternalEventHandlerImpl(SUI::ExternalEvent *event);

    virtual ~ExternalEventHandlerImpl();

private slots:
    void emitEvent();

private:
    ExternalEvent  *mEvent;
};
} // namespace SUI
#endif // SUIEXTERNALEVENTHANDLERIMPL_H
