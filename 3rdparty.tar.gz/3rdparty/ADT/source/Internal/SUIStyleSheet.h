/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SUIStyleSheet.h
| Author       :
| Description  : Header file for class SUI::StyleSheet.
|
| ! \file        SUIStyleSheet.h
| ! \brief       Header file for class SUI::StyleSheet.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef SUI_STYLESHEET_H
#define SUI_STYLESHEET_H

#include "SUIObjectType.h"
#include <string>
#include <list>

namespace SUI {

class StyleSheet
{
public:

    static SUI::StyleSheet *getInstance();

    std::string getStyleSheet();
    void setStyleSheet(const std::string styleSheet);

    std::list<std::string> getStyleSheetClassByObjectType(const ObjectType::Type &ObjectType = SUI::ObjectType::None);

private:
    static std::string styleSheetPath;
    std::string mstyleSheet;

    static std::string readStyleSheet();
    typedef std::list<std::string> StaticStyleSheetClassList;
    static std::map<SUI::ObjectType::Type,const StaticStyleSheetClassList> styleSheetClassByObjectType;

    StyleSheet();
    StyleSheet(const StyleSheet&);
    StyleSheet &operator=(const StyleSheet &);
};

} // namespace SUI

#endif // SUI_STYLESHEET_H
