/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxApplication.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxStubView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string STRING_RESOURCE = "/Resource/";
const std::string STRING_SIMULATION = "simulation";

int main(int argc, char *argv[])
{
    int result = 1;

    char* currentDir = get_current_dir_name();
    boost::shared_ptr<IGSxGUI::IGSxGUIxApplication> app(new IGSxGUI::IGSxGUIxApplication(argc, argv, currentDir + STRING_RESOURCE));
    dynamic_cast<IGSxKPI::KPI_Stub*>(IGSxKPI::KPI::getInstance())->enableKPIGeneration(true);

    if (argc > 1)
    {
        std::string strPluginName(argv[1]);
        if (strPluginName == STRING_SIMULATION)
        {
            // Start stub implementations
            IGSxGUI::IStubView *stubView;
            stubView = new IGSxGUI::StubView();
            if (stubView != NULL)
            {
                stubView->show();
            }
        }
    }
    result = app->exec();
    app.reset();
    delete currentDir;
    return result;
}


