/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIManagerTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for KPI Manager test
|
| ! \file        IGSxGUIxKPIManagerTest.hpp
| ! \brief       Header file for KPI Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXKPIMANAGERTEST_HPP
#define IGSXGUIXKPIMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxKPI.hpp"

using std::vector;
using std::list;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSet;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class KPIManagerTest : public ::testing::Test
{
 public:
    KPIManagerTest(){}
    virtual ~KPIManagerTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class KPIManagerTestParam : public ::testing::TestWithParam<std::string>
{
 public:
    KPIManagerTestParam(){}
    virtual ~KPIManagerTestParam(){}
 protected:
    KPIDefinitionList KPIs;
    KPIDefinition KPIDEF1;
    KPIDefinition KPIDEF2;

 protected:
  virtual void SetUp()
  {
    KPIValueSetDefinitionList kpivalsetdeflist_1;
    KPIValueSetDefinition valsetdef_1;
    KPIValueSetDefinitionList kpivalsetdeflist_2;
    KPIValueSetDefinition valsetdef_2;

    valsetdef_1.setName("MEAN");
    valsetdef_1.setDescription("MEAN");
    valsetdef_1.setUnit("mJ");
    kpivalsetdeflist_1.push_back(valsetdef_1);

    valsetdef_2.setName("MAX");
    valsetdef_2.setDescription("MAX");
    valsetdef_2.setUnit("µm");
    kpivalsetdeflist_2.push_back(valsetdef_2);

    KPIDEF1.setName("EUV_Pulse_Energy_Internal");
    KPIDEF1.setDescription("EUV_Pulse_Energy_Internal");
    KPIDEF1.setValues(kpivalsetdeflist_1);

    KPIDEF2.setName("DG_Droplet_Jump_Y");
    KPIDEF2.setDescription("DG_Droplet_Jump_Y");
    KPIDEF2.setValues(kpivalsetdeflist_2);

    KPIs.push_back(KPIDEF1);
    KPIs.push_back(KPIDEF2);
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXKPIMANAGERTEST_HPP
