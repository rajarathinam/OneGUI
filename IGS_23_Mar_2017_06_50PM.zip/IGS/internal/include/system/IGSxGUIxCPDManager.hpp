/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.hpp
| Author       : Venugopal S
| Description  : Header file for CPD Manager
|
| ! \file        IGSxGUIxCPDManager.hpp
| ! \brief       Header file for CPD Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDMANAGER_HPP
#define IGSXGUIXCPDMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <map>
#include <string>
#include "IGSxGUIxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class CPDManager
{
 public:
    CPDManager();
    virtual ~CPDManager();

    void initialize();
    void add(CPD *cpd);
    void remove(CPD *cpd);
    CPD* getCPD(const std::string& name) const;
    CPD* retrieveRunningCPD() const;
    std::vector<CPD*> retrieveAll() const;
    void retrieveCPDTestResults(const std::string&, time_t starttime, time_t stoptime, IGSxCPD::TestResultList&) const;
    void onStopped(const IGS::Result& result) const;

 private:
    CPDManager(CPDManager const &);
    CPDManager& operator=(CPDManager const &);

    std::vector<CPD*> m_CPDs;
};

}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDMANAGER_HPP
