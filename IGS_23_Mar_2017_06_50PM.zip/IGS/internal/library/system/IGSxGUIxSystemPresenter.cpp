/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin Presenter
|
| ! \file        IGSxGUIxSystemPresenter.cpp
| ! \brief       Implementation of System plugin Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemPresenter.hpp"
#include <string>
#include <vector>
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::SystemPresenter::SystemPresenter(IGSxGUI::ISystemView* view, DriverManager* pDriverManager):
    m_pDriverManager(pDriverManager),
    m_view(view)
{
    m_pDriverManager->registerToSystemStateChanged(boost::bind(&IGSxGUI::SystemPresenter::onSystemStateChanged, this, _1));

    std::vector<IGSxGUI::SystemFunction*> sysFunctions = m_pDriverManager->getSystemFunctions();

    for (size_t i = 0; i < sysFunctions.size(); ++i)
    {
        sysFunctions[i]->registerToSysFunStateChanged(boost::bind(&IGSxGUI::SystemPresenter::onSysFunStateChanged, this, _1, _2, _3, _4));

        std::vector<IGSxGUI::Driver*> drivers = sysFunctions[i]->getDrivers();

        for (size_t j = 0; j < drivers.size(); ++j)
        {
            std::string drvName = drivers[j]->getName();
            sysFunctions[i]->getDriver(drvName)->registerToDriverStateChanged(boost::bind(&IGSxGUI::SystemPresenter::onDriverStateChanged, this, _1, _2));
        }
    }
}
IGSxGUI::SystemPresenter::~SystemPresenter()
{
    // Do not delete m_view, we are not the owner.
}

void IGSxGUI::SystemPresenter::Initialize()
{
    try
    {
        InitTerminate::getInstance()->initializeSystem(boost::bind(&IGSxGUI::SystemPresenter::onInitializeComplete, this, _1));
    } catch (IGS::Exception& ex)
    {
        handleException(ex.what());
    }
}

void IGSxGUI::SystemPresenter::Terminate()
{
    try
    {
        InitTerminate::getInstance()->terminateSystem(boost::bind(&IGSxGUI::SystemPresenter::onTerminateComplete, this, _1));
    } catch (IGS::Exception& ex)
    {
        handleException(ex.what());
    }
}

void IGSxGUI::SystemPresenter::Resolve()
{
    Initialize();
}

std::vector<IGSxGUI::Driver*> IGSxGUI::SystemPresenter::getDrivers(const std::string &systemFunction) const
{
    std::vector<IGSxGUI::Driver*> drivers;
    if (systemFunction != "")
    {
        drivers = m_pDriverManager->getSystemFunction(systemFunction)->getDrivers();
    }
    return drivers;
}

std::vector<IGSxGUI::SystemFunction*> IGSxGUI::SystemPresenter::getSystemFunctions() const
{
    return m_pDriverManager->getSystemFunctions();
}

void IGSxGUI::SystemPresenter::onInitializeComplete(const IGS::Result &result) const
{
    if (result != IGS::OK)
    {
        m_pDriverManager->setSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }
    m_view->initializationCompleted();
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::SystemPresenter::getSystemState() const
{
    return m_pDriverManager->getSystemState();
}

void IGSxGUI::SystemPresenter::onTerminateComplete(const IGS::Result &result) const
{
    if (result != IGS::OK)
    {
        m_pDriverManager->setSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }
    m_view->termintationCompleted();
}

int IGSxGUI::SystemPresenter::getInitializedDriverCount() const
{
    int nInitializedDriverCount = 0;
    std::vector<IGSxGUI::SystemFunction*> sysFunctions = m_pDriverManager->getSystemFunctions();

    for (size_t i = 0; i < sysFunctions.size(); ++i)
    {
        std::vector<IGSxGUI::Driver*> drivers = sysFunctions[i]->getDrivers();

        for (size_t j = 0; j < drivers.size(); j++ )
        {
            IGSxITS::DriverState::DriverStateEnum driverState = drivers[j]->getState();
             if ((driverState == DriverState::DS_INITIALIZED) && (drivers[j]->isImplemented()))
             {
                 ++nInitializedDriverCount;
             }
        }
    }
    return nInitializedDriverCount;
}

void IGSxGUI::SystemPresenter::onSysFunStateChanged(const SystemState::SystemStateEnum &state, const std::string &strSysFunction, const int& nInitializedDriverCount, const int& nTerminatedDriverCount) const
{
    m_view->updateSysFunction(state, strSysFunction, nInitializedDriverCount, nTerminatedDriverCount);
}

void IGSxGUI::SystemPresenter::onDriverStateChanged(const DriverState::DriverStateEnum &state, const std::string &strDriver) const
{
    m_view->updateDriver(state, strDriver);
}

void IGSxGUI::SystemPresenter::onSystemStateChanged(const SystemState::SystemStateEnum &state) const
{
    m_view->updateMainStatus(state);
}

void IGSxGUI::SystemPresenter::handleException(const std::string& eMsg)
{
    m_pDriverManager->setSystemState(SystemState::SS_RECOVERY_REQUIRED);
    IGS_ERROR(eMsg);
}
