/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR_impl.hpp
| Author       : Surya Tiwari
| Description  : Header file for IGSxERR implementation
|
| ! \file        IGSxERR_impl.hpp
| ! \brief       Header file for IGSxERR implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXERR_IMPL_HPP
#define IGSXERR_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxERR.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/


namespace IGSxERR {

class EventLogger_Stub :public EventLogger
{
 public:
    static EventLogger* getInstance();

    virtual std::string getEventLog();
    virtual std::string getPreviousEventLog();

 protected:
    EventLogger_Stub();
    virtual ~EventLogger_Stub() {}

    std::string m_currentfilename;
    std::string m_previousfilename;
};
}  // namespace IGSxERR
#endif  // IGSXERR_IMPL_HPP
