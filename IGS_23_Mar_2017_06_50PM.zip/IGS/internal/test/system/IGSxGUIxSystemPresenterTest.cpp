/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenterTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Presenter test
|
| ! \file        IGSxGUIxSystemPresenterTest.cpp
| ! \brief       Implementation of System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxSystemPresenterTest.hpp"
#include "IGSxGUIxDriverManager.hpp"
#include "IGSxGUIxISystemView.hpp"
#include "IGSxGUIxSystemView.hpp"
#include "IGSxGUIxDriver.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        SystemPresenterTestParam,
                        ::testing::Values("SF-04"));

TEST_P(SystemPresenterTestParam, Test1)
{
    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();
    SystemViewStub* stubView = new SystemViewStub();

    if ( drvMgr != NULL)
    {
        drvMgr->addSystemFunctions(Sysfunctions);
    }

    IGSxGUI::SystemFunction* sysFunc = drvMgr->getSystemFunction("SF-04");
    for (size_t i = 0; i < Drivers.size(); i++)
    {
        sysFunc->addDriver(Drivers[i], DriverState::DS_TERMINATED);
    }

    IGSxGUI::SystemPresenter* ptr = new IGSxGUI::SystemPresenter(stubView, drvMgr);

    if (ptr != NULL)
    {
        vector<IGSxGUI::Driver*> drv = ptr->getDrivers("SF-04");
        EXPECT_EQ(drv.size(), 5);
    }

    if (ptr != NULL)
    {
        delete ptr;
        ptr = NULL;
    }
    if (drvMgr != NULL)
    {
        delete drvMgr;
        drvMgr = NULL;
    }
    if (stubView != NULL)
    {
        delete stubView;
        stubView = NULL;
    }
}
