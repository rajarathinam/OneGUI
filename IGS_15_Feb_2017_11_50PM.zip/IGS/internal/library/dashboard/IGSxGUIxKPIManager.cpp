/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIManager.cpp
| Author       : Sabari Chandra Sekar
| Description  : KPI manager Implementation
|
| ! \file        IGSxKPIManager.cpp
| ! \brief       KPI Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const string IGSxGUI::KPIManager::KPI_WHITELIST_FILE = IGS::Resource::path("IGSxGUIxKPIWhitelist.xml");

const string IGSxGUI::KPIManager::STRING_KPI = "KPI";
const string IGSxGUI::KPIManager::STRING_KPIS = "KPIs";
const string IGSxGUI::KPIManager::STRING_EMPTY = "";
const string IGSxGUI::KPIManager::STRING_SYSTEMKPI = "System";
const string IGSxGUI::KPIManager::STRING_CONSUMABLE = "Consumable";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_NAME = "<xmlattr>.name";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_VALUESET = "<xmlattr>.valueset";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_TYPE = "<xmlattr>.type";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_DISPLAYNAME = "<xmlattr>.unit";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_FACTOR = "<xmlattr>.factor";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_MIN = "<xmlattr>.min";
const string IGSxGUI::KPIManager::STRING_ATTRIBUTE_MAX = "<xmlattr>.max";

const int IGSxGUI::KPIManager::TIMER_INTERVAL = 60000;
const int IGSxGUI::KPIManager::TIME_SIX_HOURS_TWENTY_MINUTES = 22800;

IGSxGUI::KPIManager::KPIManager():
    m_timer(SUI::Timer::createTimer())
{
    m_previousPollTime = time(NULL) - TIME_SIX_HOURS_TWENTY_MINUTES;
    m_timer->timeout = boost::bind(&KPIManager::onTimeout, this);
}

IGSxGUI::KPIManager::~KPIManager()
{
    m_timer->stop();

    for (std::vector<KPI*>::iterator it = m_KPIs.begin() ; it != m_KPIs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    for (std::vector<KPI*>::iterator it = m_SystemKPIs.begin() ; it != m_SystemKPIs.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    for (std::vector<KPI*>::iterator it = m_Consumables.begin() ; it != m_Consumables.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_KPIs.clear();
    m_SystemKPIs.clear();
    m_Consumables.clear();
}

void IGSxGUI::KPIManager::initialize()
{
    boost::property_tree::ptree treeWhiteListKPIDefinition;
    read_xml(KPI_WHITELIST_FILE, treeWhiteListKPIDefinition);

    BOOST_FOREACH(boost::property_tree::ptree::value_type const& nodeKPI, treeWhiteListKPIDefinition.get_child(STRING_KPIS))
    {
        if ( nodeKPI.first == STRING_KPI )
        {
            string name = nodeKPI.second.get_child(STRING_ATTRIBUTE_NAME).data();
            string valueSet = nodeKPI.second.get_child(STRING_ATTRIBUTE_VALUESET).data();
            string type = nodeKPI.second.get_child(STRING_ATTRIBUTE_TYPE).data();
            string displayname = nodeKPI.second.get_child(STRING_ATTRIBUTE_DISPLAYNAME).data();
            double factor = atof(nodeKPI.second.get_child(STRING_ATTRIBUTE_FACTOR).data().c_str());
            double min = atof(nodeKPI.second.get_child(STRING_ATTRIBUTE_MIN).data().c_str());
            double max = atof(nodeKPI.second.get_child(STRING_ATTRIBUTE_MAX).data().c_str());

            if (type == STRING_KPI)
            {
                IGSxKPI::KPIDefinition kpiDefinition;
                try
                {
                    IGSxKPI::KPI::getInstance()->getKpi(name, kpiDefinition);
                    addKPI(kpiDefinition, valueSet, displayname, factor, type, min, max);
                } catch (IGS::Exception& /*ex*/) {
                    // ToDo, determine what to do
                }
            } else if (type == STRING_SYSTEMKPI) {
                IGSxKPI::KPIDefinition kpiDefinition;
                try
                {
                    IGSxKPI::KPI::getInstance()->getKpi(name, kpiDefinition);
                    addSystemKPI(kpiDefinition, valueSet, displayname, factor, type, min, max);
                } catch (IGS::Exception& /*ex*/) {
                    // ToDo, determine what to do
                }
            } else if (type == STRING_CONSUMABLE) {
                IGSxKPI::KPIDefinition kpiDefinition;
                try
                {
                    IGSxKPI::KPI::getInstance()->getKpi(name, kpiDefinition);
                    addConsumable(kpiDefinition, valueSet, displayname, factor, type, min, max);
                } catch (IGS::Exception& /*ex*/) {
                    // ToDo, determine what to do
                }
            }
        }
    }

    try
    {
        IGSxKPI::KPI::getInstance()->subscribeToKpiData(STRING_EMPTY, boost::bind(&IGSxGUI::KPIManager::receiveKPIDataEvent, this, _1));
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }
    // Fire the first onTimeout manually to trigger a retrieval of the data.
    onTimeout();
}

void IGSxGUI::KPIManager::addKPI(const IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue)
{
    KPI* kpi = getKPI(kpiDefinition.name());

    if (kpi == NULL)
    {
        kpi = new KPI(kpiDefinition);
        kpi->setType(type);
        m_KPIs.push_back(kpi);
    }

    KPIValueSet* valueSet = kpi->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
    }
}

void IGSxGUI::KPIManager::addSystemKPI(const IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue)
{
    KPI* systemkpi = getKPI(kpiDefinition.name());

    if (systemkpi == NULL)
    {
        systemkpi = new KPI(kpiDefinition);
        systemkpi->setType(type);
        m_SystemKPIs.push_back(systemkpi);
    }

    KPIValueSet* valueSet = systemkpi->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
    }
}

void IGSxGUI::KPIManager::addConsumable(const IGSxKPI::KPIDefinition &kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue)
{
    KPI* consumable = getKPI(kpiDefinition.name());

    if (consumable == NULL)
    {
        consumable = new KPI(kpiDefinition);
        consumable->setType(type);
        m_Consumables.push_back(consumable);
    }

    KPIValueSet* valueSet = consumable->getValueSet(valueSetName);

    if (valueSet != NULL)
    {
        valueSet->setActive(true);
        valueSet->setDisplayUnit(displayName);
        valueSet->setFactor(factor);
        valueSet->setMin(minValue);
        valueSet->setMax(maxValue);
    }
}

vector<IGSxGUI::KPI*> IGSxGUI::KPIManager::getKPIs() const
{
    return m_KPIs;
}

vector<IGSxGUI::KPI *> IGSxGUI::KPIManager::getSystemKPIs() const
{
    return m_SystemKPIs;
}

vector<IGSxGUI::KPI *> IGSxGUI::KPIManager::getConsumables() const
{
    return m_Consumables;
}

IGSxGUI::KPI* IGSxGUI::KPIManager::getKPI(const string& name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_KPIs.size(); i++)
    {
        if (m_KPIs[i]->getName() == name)
        {
            kpi = m_KPIs[i];
            break;
        }
    }
    return kpi;
}

IGSxGUI::KPI *IGSxGUI::KPIManager::getSystemKPI(const std::string &name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_SystemKPIs.size(); i++)
    {
        if (m_SystemKPIs[i]->getName() == name)
        {
            kpi = m_SystemKPIs[i];
            break;
        }
    }
    return kpi;
}

IGSxGUI::KPI *IGSxGUI::KPIManager::getConsumable(const std::string &name) const
{
    KPI* kpi = NULL;

    for (size_t i = 0; i < m_Consumables.size(); i++)
    {
        if (m_Consumables[i]->getName() == name)
        {
            kpi = m_Consumables[i];
            break;
        }
    }
    return kpi;
}

void IGSxGUI::KPIManager::receiveKPIDataEvent(const IGSxKPI::KPIData& kpiData)
{
  KPI* kpi = getKPI(kpiData.name());
  if (kpi != NULL)
  {
       kpi->updateValue(kpiData);
  }
}

void IGSxGUI::KPIManager::getKPIData()
{
    for (unsigned i = 0; i < m_KPIs.size(); i++)
    {
        IGSxKPI::KPIDataList dataList;

        time_t now = time(NULL);
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_KPIs[i]->getName(), m_previousPollTime, now, dataList);
        } catch (IGS::Exception& /*ex*/) {
            // ToDo, determine what to do.
        }

        if (dataList.size() > 0)
        {
            m_KPIs[i]->updateValues(dataList);
        }
    }
}

void IGSxGUI::KPIManager::getSystemKPIData()
{
    for (unsigned i = 0; i < m_SystemKPIs.size(); i++)
    {
        IGSxKPI::KPIDataList dataList;

        time_t now = time(NULL);
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_SystemKPIs[i]->getName(), m_previousPollTime, now, dataList);
        } catch (IGS::Exception& /*ex*/) {
            // ToDo, determine what to do.
        }

        if (dataList.size() > 0)
        {
            m_SystemKPIs[i]->updateValues(dataList);
        }
    }
}

void IGSxGUI::KPIManager::getConsumableData()
{
    for (unsigned i = 0; i < m_Consumables.size(); i++)
    {
        IGSxKPI::KPIDataList dataList;

        time_t now = time(NULL);
        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(m_Consumables[i]->getName(), m_previousPollTime, now, dataList);
        } catch (IGS::Exception& /*ex*/) {
            // ToDo, determine what to do.
        }

        if (dataList.size() > 0)
        {
            m_Consumables[i]->updateValues(dataList);
        }
    }
}

void IGSxGUI::KPIManager::onTimeout()
{
    getKPIData();
    getSystemKPIData();
    getConsumableData();

    m_previousPollTime = time(NULL);
    m_timer->start(TIMER_INTERVAL);
}



