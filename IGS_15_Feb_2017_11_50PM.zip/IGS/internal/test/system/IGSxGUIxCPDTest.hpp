/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDTest.hpp
| Author       : Venugopal S
| Description  : Header file for CPD test
|
| ! \file        IGSxGUIxCPDTest.hpp
| ! \brief       Header file for CPD test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDTEST_HPP
#define IGSXGUIXCPDTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class CPDTest : public ::testing::Test
{
 public:
    CPDTest(){}
    virtual ~CPDTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXCPDTEST_HPP
