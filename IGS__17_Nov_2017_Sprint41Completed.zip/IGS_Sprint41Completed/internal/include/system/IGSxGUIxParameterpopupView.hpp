/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.hpp
| Author       : Raja
| Description  : Header file for Parameterpopup View
|
| ! \file        IGSxGUIxParameterpopupView.hpp
| ! \brief       Header file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXPARAMETERPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include "IGSxGUIxIParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class ParameterpopupView;
}  // namespace SUI

namespace IGSxGUI{

class ParameterpopupView : public IParameterpopupView
{
 public:
    explicit ParameterpopupView();
    virtual ~ParameterpopupView();
    virtual void show();

  void onCloseButtonPressed();
  void setParameterName(const std::string &name);
  void setParameterValue(const std::string &value);
  void setParameterDefaultValue(const std::string &defaultvalue);
  std::string getParameterName() const;
  std::string getParameterValue() const;
  std::string getParameterDefaultValue() const;
  void close();

  typedef boost::signals2::signal<void (std::string, std::string)> ValueChanged;
  typedef ValueChanged::slot_type ValueChangedCallback;

  boost::signals2::connection registerForValueChanged(const ValueChangedCallback& cb);

  void onUpdatebuttonPressed();
  void onCloseButtonHoverEntered();
  void onCloseButtonHoverLeft();
  void onResetButtonPressed();
  void setParent(SUI::Widget *parent);
 private:
    ParameterpopupView(const ParameterpopupView &);
    ParameterpopupView& operator=(const ParameterpopupView &);
    void init();

    ValueChanged m_valueChanged;
    SUI::ParameterpopupView *sui;
    static const std::string PARAMETERPOPUPVIEW_LOAD_FILE;
    static const std::string STRING_PARAMETERPOPUPVIEW_SHOWN;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXPARAMETERPOPUPVIEW_HPP
