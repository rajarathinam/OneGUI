

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.cpp
| ! \brief       Implementation of Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include <SUIUILoader.h>
#include <SUIObjectList.h>
#include <SUIDialog.h>
#include <SUIContainer.h>
#include <SUIButton.h>
#include <SUILabel.h>
#include <SUITableWidget.h>
#include <SUILineEdit.h>
#include <SUIScrollBar.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::MachineconstantsView::MachineconstantsView() :
    dialog(NULL),
    btnParameterName(NULL),
    lblParameterNameTooltip(NULL),
    btnParameterValue(NULL),
    lblParameterValueTooltip(NULL),
    tawParameters(NULL),
    lneSearchParameterText(NULL),
    btnSearchParameter(NULL),
    btnSearchClear(NULL),
    lblEntriesFound(NULL)

{
}

void SUI::MachineconstantsView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::MachineconstantsView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::MachineconstantsView::loadObjects(ObjectList* objectList)
{
  btnParameterName =  objectList->getObject<Button>("btnParameterName");
  lblParameterNameTooltip = objectList->getObject<Label>("lblParameterNameTooltip");
  btnParameterValue = objectList->getObject<Button>("btnParameterValue");
  lblParameterValueTooltip = objectList->getObject<Label>("lblParameterValueTooltip");
  tawParameters = objectList->getObject<TableWidget>("tawParameters");
  lneSearchParameterText = objectList->getObject<LineEdit>("lneSearchParameterText");
  btnSearchParameter = objectList->getObject<Button>("btnSearchParameter");
  btnSearchClear = objectList->getObject<Button>("btnSearchClear");
  lblEntriesFound = objectList->getObject<Label>("lblEntriesFound");
  scbParametersTable = objectList->getObject<ScrollBar>("scbParametersTable");

}

#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
