/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.cpp
| Author       : Raja
| Description  : Machineconstants manager Implementation
|
| ! \file        IGSxGUIxMachineconstantsManager.cpp
| ! \brief       Machineconstants Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::MachineconstantsManager::MachineconstantsManager()
{
}

IGSxGUI::MachineconstantsManager::~MachineconstantsManager()
{
}
