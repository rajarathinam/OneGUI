/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemFunctionTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System Function test
|
| ! \file        IGSxGUIxSystemFunctionTest.hpp
| ! \brief       Header file for System Function test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMFUNCTIONTEST_HPP
#define IGSXGUIXSYSTEMFUNCTIONTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SystemFunctionTest : public ::testing::Test
{
 public:
    SystemFunctionTest(){}
    virtual ~SystemFunctionTest(){}

 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIXSYSTEMFUNCTIONTEST_HPP
