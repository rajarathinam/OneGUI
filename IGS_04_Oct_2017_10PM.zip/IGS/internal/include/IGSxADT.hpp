/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADT.hpp
| Author       : Thijs Jacobs
| Description  : Proxy interface for FAMxAC,
|                Advanced Diagnostics Tool (ADT) Manager
|                The ADT Manager manages a tool list
|
| ! \file        IGSxADT.hpp
| ! \brief       Proxy interface for FAMxAC,
|                Advanced Diagnostics Tool (ADT) Manager
|                The ADT Manager manages a tool list
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXADT_HPP
#define IGSXADT_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>

#include "IGSxCOMMON.hpp"


namespace IGSxADT {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// ADT meta data
class MetaDescription
{
public:
    explicit MetaDescription(const std::string& _name, const std::string& _subSystem, const std::string& _description, const std::string& _htmlFile):
        m_name(_name), m_subSystem(_subSystem), m_description(_description), m_htmlFile(_htmlFile){}
    virtual ~MetaDescription() {}

    std::string name() const {return m_name;}
    std::string subSystem() const {return m_subSystem;}
    std::string description() const {return m_description;}
    std::string htmlFile() const {return m_htmlFile;}
    void setName(const std::string& _name) {m_name = _name;}
    void setSubSystem(const std::string& _subSystem) {m_subSystem = _subSystem;}
    void setDescription(const std::string& _description) {m_description = _description;}
    void setHtmlFile(const std::string& _htmlFile) {m_htmlFile = _htmlFile;}

private:
    std::string m_name;        // tool name, e.g. Alignment ADT
    std::string m_subSystem;   // sub system, e.g. High Power Seed Module
    std::string m_description; // short description, e.g. Alignment ADT
    std::string m_htmlFile;    // html description file, e.g. LSC_AlignmentADT.html
};
typedef std::vector<MetaDescription> MetaDescriptions;


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class ADT
{
// functions throw IGS::exception
public:
    static ADT* getInstance() {return instance;}

    // get all tools
    virtual void getAdts(MetaDescriptions& adts) = 0;

    // start a tool
    virtual void startAdt(const std::string& adtName) = 0;

    // Is ADT running?
    virtual bool isAdtRunning(const std::string& adtName) = 0;

protected:
    // instance
    virtual ~ADT() {}
    static ADT* instance;
};

} // namespace IGSxADT

#endif // IGSXADT_HPP

