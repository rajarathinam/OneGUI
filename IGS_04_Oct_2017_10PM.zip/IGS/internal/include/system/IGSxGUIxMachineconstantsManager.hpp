/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.hpp
| Author       : Raja
| Description  : Header file for Machineconstants Manager
|
| ! \file        IGSxGUIxMachineconstantsManager.hpp
| ! \brief       Header file for Machinecontants Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSMANAGER_HPP
#define IGSXGUIXMACHINECONSTANTSMANAGER_HPP
namespace IGSxGUI {
class MachineconstantsManager
{
 public:
    MachineconstantsManager();
    virtual ~MachineconstantsManager();

 private:
    MachineconstantsManager(MachineconstantsManager const &);
    MachineconstantsManager& operator=(MachineconstantsManager const &);
};

}  // namespace IGSxGUI
#endif // IGSXGUIXMACHINECONSTANTSMANAGER_HPP
