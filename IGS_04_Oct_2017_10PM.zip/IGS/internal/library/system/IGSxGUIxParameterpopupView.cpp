/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Parameterpopup view
|
| ! \file        IGSxGUIxParameterpopupView.cpp
| ! \brief       Implementation of Parameterpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMoc_ParameterpopupView.hpp"
#include "IGSxLOG.hpp"
#include <SUILabel.h>
#include <SUILineEdit.h>
#include <SUIButton.h>
#include <SUIDialog.h>
#include <IGSxGUIxUtil.hpp>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::ParameterpopupView::PARAMETERPOPUPVIEW_LOAD_FILE = "IGSxGUIxParameterPopup.xml";
const std::string IGSxGUI::ParameterpopupView::STRING_PARAMETERPOPUPVIEW_SHOWN = "ParameterPopupView is Shown.";
IGSxGUI::ParameterpopupView::ParameterpopupView():
    sui(new SUI::ParameterpopupView)
{
  sui->setupSUI(PARAMETERPOPUPVIEW_LOAD_FILE.c_str());

}


IGSxGUI::ParameterpopupView::~ParameterpopupView()
{

}

void IGSxGUI::ParameterpopupView::show()
{
  init();
  IGSxGUI::Util::setWindowFrame(sui->dialog, false);
  IGSxGUI::Util::executeDialog(sui->dialog);
  IGS_INFO(STRING_PARAMETERPOPUPVIEW_SHOWN);
}



void IGSxGUI::ParameterpopupView::init()
{
  IGSxGUI::Util::setWordWrap(sui->lblParameterName);
  sui->btnClose->clicked = boost::bind(&ParameterpopupView::onCloseButtonPressed, this);
}
void IGSxGUI::ParameterpopupView::onCloseButtonPressed()
{
 IGSxGUI::Util::quitDialog(sui->dialog);
}
void IGSxGUI::ParameterpopupView::setParameterName(const std::string& name)
{
  sui->lblParameterName->setText(name);
}
void IGSxGUI::ParameterpopupView::setParameterValue(const std::string& value)
{
  sui->lneValue->setText(value);
}
void IGSxGUI::ParameterpopupView::setParameterDefaultValue(const std::string& defaultvalue)
{
  sui->lblDefaultValue->setText(defaultvalue);
}
