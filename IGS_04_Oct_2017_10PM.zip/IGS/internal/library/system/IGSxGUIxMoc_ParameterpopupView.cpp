

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_ParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Moc Parameterspopup view
|
| ! \file        IGSxGUIxMoc_ParameterpopupView.cpp
| ! \brief       Implementation of Moc Parameterspopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_PARAMETERSPOPUPVIEW_CPP
#define IGSXGUIXMOC_PARAMETERSPOPUPVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_ParameterpopupView.hpp"
#include <SUIUILoader.h>
#include <SUIObjectList.h>
#include <SUIDialog.h>
#include <SUIContainer.h>
#include <SUIFileDialog.h>
#include <SUIMessageBox.h>
#include <SUITabWidget.h>
#include <SUITabPage.h>
#include <SUILineEdit.h>
#include <SUIButton.h>
#include <SUILabel.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::ParameterpopupView::ParameterpopupView() :
    dialog(NULL),
    btnCancel(NULL),
    btnClose(NULL),
    btnReset(NULL),
    btnUpdate(NULL),
    lblDefaultValue(NULL),
    lblDefaultValueNumber(NULL),
    lblParameterName(NULL),
    lblValue(NULL),
    lneValue(NULL)
{
}

void SUI::ParameterpopupView::setupSUI(const char* xmlFileName) {
   dialog = SUI::UILoader::loadUI(xmlFileName);
   loadObjects(dialog->getObjectList());
}


void SUI::ParameterpopupView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
   container->setUiFilename(xmlFileName);
   loadObjects(container->getObjectList());
}


void SUI::ParameterpopupView::loadObjects(SUI::ObjectList* objectList) {
    btnCancel = objectList->getObject<SUI::Button>("btnCancel");
    btnClose = objectList->getObject<SUI::Button>("btnClose");
    btnReset = objectList->getObject<SUI::Button>("btnReset");
    btnUpdate = objectList->getObject<SUI::Button>("btnUpdate");
    lblDefaultValue = objectList->getObject<SUI::Label>("lblDefaultValue");
    lblDefaultValueNumber = objectList->getObject<SUI::Label>("lblDefaultValueNumber");
    lblParameterName = objectList->getObject<SUI::Label>("lblParameterName");
    lblValue = objectList->getObject<SUI::Label>("lblValue");
    lneValue = objectList->getObject<SUI::LineEdit>("lneValue");
}


#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP

