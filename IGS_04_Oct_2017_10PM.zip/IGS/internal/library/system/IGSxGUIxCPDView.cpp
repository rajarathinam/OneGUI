/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include <SUIDialog.h>
#include <SUIObjectList.h>
#include <SUIButton.h>
#include <SUIUserControl.h>
#include <SUITimer.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = "IGSxGUIxCPD.xml";
const std::string IGSxGUI::CPDView::STRING_EMPTY = "";
const std::string IGSxGUI::CPDView::STRING_SINGLESPACE = " ";
const char IGSxGUI::CPDView::NEWLINE_CHAR = '\n';
const std::string IGSxGUI::CPDView::STRING_ALL_CPDS = "ALL CPDs";
const std::string IGSxGUI::CPDView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::CPDView::STRING_CPDVIEW_SHOWN = "CPDView is shown.";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::CPDView::STRING_CPDSUBSYSTEM_STYLE = "CPDsubsystem";
const std::string IGSxGUI::CPDView::STRING_SLASH = " / ";
const std::string IGSxGUI::CPDView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::CPDView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::CUSTOM_STYLESHEET = "customCss.css";
const std::string IGSxGUI::CPDView::STRING_CPD_ALREADY_RUNNING = "CPD is already running";
const std::string IGSxGUI::CPDView::STRING_CPD_SHOWING = "Opening CPD...";
const char* IGSxGUI::CPDView::STRING_CPD_MESSAGE = "Start CPD button pressed, CPD Name: ";
const int IGSxGUI::CPDView::CPDSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::CPDView::AWESOME_ANGLE_SIZE = 22;
const int IGSxGUI::CPDView::CPDTABLE_ROW_SIZE = 62;
const int IGSxGUI::CPDView::NORMAL_SUBSYSTEM_ROW_SIZE = 40;
const int IGSxGUI::CPDView::EXTENDED_SUBSYSTEM_ROW_SIZE = 60;
const int IGSxGUI::CPDView::MAX_SUBSYSTEM_CHARS_PER_CELL = 21;

IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_bRunningCPD(false),
    m_selectedSubSystem(""),
    m_selectedSubsystemRowNum(-1),
    m_selectedCPD(""),
    m_selectedCPDRowNum(-1),
    m_isDescFolded(true),
    m_isCloseButtonPressed(false),
    m_isInternalCallToSubsystemPressed(false),
    m_startingCPDTimer(SUI::Timer::createTimer())
{
    m_presenter = new CPDPresenter(this, pCPDManager);
    m_startingCPDTimer->setSingleShot(true);
    m_startingCPDTimer->timeout = boost::bind(&CPDView::onShowCPDStartingTimeout, this);
}

IGSxGUI::CPDView::~CPDView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::CPDView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }

    //IGSxGUI::Util::addCustomStylesheet(sui->wvwCPDHTMLDescription, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));

   // setHandlers();
    //init();
    //IGS_INFO(STRING_CPDVIEW_SHOWN);
}

void IGSxGUI::CPDView::init()
{
    sui->tawCPDSubsystem->showGrid(false);
    sui->tawCPD->showGrid(false);

    m_listCPD = m_presenter->getCPDs();
    m_listSubsystemCPDs = m_presenter->getCPDs();

    loadSubSystems();

    if ((m_selectedSubSystem != "") || (m_selectedCPD != ""))
    {
        reload();
    } else {
        loadCPDTable();
    }
}

void IGSxGUI::CPDView::onSubSystemClosePressed()
{
    EnableCountLabels();
    m_isCloseButtonPressed = true;
    DisableCloseButtons();
    m_isCloseButtonPressed = false;

    IGSxGUI::Util::clearSelection(sui->tawCPDSubsystem);

    m_selectedSubSystem = "";
    m_selectedSubsystemRowNum = -1;

    loadCPDTable();
}

void IGSxGUI::CPDView::EnableCountLabels()
{
    for (int rowIndex = 0; rowIndex < sui->tawCPDSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(rowIndex, 2))->setVisible(true);
    }
}
void IGSxGUI::CPDView::DisableCloseButtons()
{
    for (int rowIndex = 0; rowIndex < sui->tawCPDSubsystem->rowCount(); ++rowIndex)
    {
        dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(rowIndex, 3))->setVisible(false);
    }
}

void IGSxGUI::CPDView::onSubsystemPressed()
{
    if (m_isCloseButtonPressed)
    {
        return;
    }
    if (!m_isInternalCallToSubsystemPressed)
    {
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
    }

    std::vector<int> items = sui->tawCPDSubsystem->getSelectedRows();
    if (items.size() > 0)
    {
        EnableCountLabels();
        DisableCloseButtons();
        m_selectedSubsystemRowNum = items[0];
        dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 2))->setVisible(false);
        dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 3))->setVisible(true);

        std::string selectedText = sui->tawCPDSubsystem->getItemText(boost::lexical_cast<int>(m_selectedSubsystemRowNum), 1);
        std::replace(selectedText.begin(), selectedText.end(), NEWLINE_CHAR, ' ');
        boost::trim(selectedText);
        m_selectedSubSystem = selectedText;
        sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);

        std::vector<CPD*> listSelectedSubsystemCPDs = getSelectedSubSystemCPDs();
        m_usercontrols.clear();
        populateCPDTable(listSelectedSubsystemCPDs);
    }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getSelectedSubSystemCPDs()
{
    std::vector<IGSxGUI::CPD*> listSubsystemCPDs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
        container subsys = m_listSubsystems[i];
        if (subsys.name == m_selectedSubSystem)
        {
            listSubsystemCPDs.push_back(subsys.cpd);
        }
    }
    return listSubsystemCPDs;
}

void IGSxGUI::CPDView::setDescriptionPaneVisible(bool visibility)
{
    sui->lblLine->setVisible(visibility);
    sui->lblAngle->setVisible(visibility);
    sui->lblSelectedCPD->setVisible(visibility);
    sui->btnOpenCPD->setVisible(visibility);
    sui->btnDescription->setVisible(visibility);
    sui->wvwCPDHTMLDescription->setVisible(visibility);
}

void IGSxGUI::CPDView::populateCPDTable(std::vector<CPD*> listCPD)
{
    sui->tawCPD->removeRows(1, sui->tawCPD->rowCount()-1);
    for (size_t i = 0 ; i < listCPD.size() - 1; i++)
    {
        sui->tawCPD->appendRow();
    }
    for (int row = 0; row < sui->tawCPD->rowCount(); ++row)
    {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(row, 0);
        IGSxGUI::Util::setADTUCTNormalStyle(widget);
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        usercontrol->clicked = boost::bind(&CPDView::onTableCPDRowPressed, this, row);
        usercontrol->hoverEntered = boost::bind(&CPDView::onCPDUCTHoverEntered, this, row);
        usercontrol->hoverLeft = boost::bind(&CPDView::onCPDUCTHoverLeft, this, row);
        m_usercontrols.push_back(usercontrol);

        IGSxGUI::Util::setTextToUserControl(widget, 0, listCPD[row]->getName());
        IGSxGUI::Util::setTextToUserControl(widget, 1, listCPD[row]->getDescription());
        IGSxGUI::Util::setTextToUserControl(widget, 2, STRING_EMPTY);
        IGSxGUI::Util::setRowHeight(sui->tawCPD, row, CPDTABLE_ROW_SIZE);
    }
    IGSxGUI::Util::clearSelection(sui->tawCPD);
    setDescriptionPaneVisible(false);
}

void IGSxGUI::CPDView::loadCPDTable()
{
    m_usercontrols.clear();
    populateCPDTable(m_listCPD);
    sui->lblAllCPDs->setText(STRING_ALL_CPDS);
}

void IGSxGUI::CPDView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::CPDView::updateStatus(const std::string& /*strCPD*/, const IGS::Result& /*result*/)
{
    /*if (result == IGS::OK)
    {
        m_bRunningCPD = false;

        sui->gbxCPD->setBGColor(SUI::ColorEnum::White);
        sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_CPD);
        sui->lblDescription->setText(STRING_NO_ACTIVE_CPD);
        sui->lblType->setVisible(false);
        sui->lblName->setVisible(false);
        sui->lblStatus->setVisible(false);
        sui->btnShowCPD->setVisible(false);
        sui->btnCPDInfo->setVisible(false);
    }*/
}

void IGSxGUI::CPDView::insertCountLabelAndCloseButton(size_t i)
{
    IGSxGUI::Util::addLabel(sui->tawCPDSubsystem, i, 2);
    SUI::Label* label = dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(i, 2));
    label->setStyleSheetClass(STRING_CPDSUBSYSTEM_STYLE);
    IGSxGUI::Util::addButton(sui->tawCPDSubsystem, i, 3);
    SUI::Button* button = dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(i, 3));
    button->setVisible(false);
    button->clicked = boost::bind(&CPDView::onSubSystemClosePressed, this);
    IGSxGUI::Util::setAwesome(button, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, CPDSUBSYSTEM_CLOSEBUTTON_SIZE);
}

void IGSxGUI::CPDView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    if (subsyscount.nameSubsystem.length() > MAX_SUBSYSTEM_CHARS_PER_CELL)
    {
        std::string str1 = STRING_EMPTY;
        std::string str2 = STRING_EMPTY;
        std::vector<std::string> tokens;
        boost::split(tokens, subsyscount.nameSubsystem, boost::is_any_of(STRING_SINGLESPACE));
        for (size_t index = 0; index < tokens.size(); ++index)
          {
            if (str1.length() < MAX_SUBSYSTEM_CHARS_PER_CELL)
            {
                str1 = str1 + STRING_SINGLESPACE+ tokens[index];
            } else {
                str2 = str2 + STRING_SINGLESPACE + tokens[index];
            }
          }
        boost::trim(str1);
        boost::trim(str2);
        sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 1, str1 + NEWLINE_CHAR + str2);
    } else {
        sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 1, subsyscount.nameSubsystem);
    }
    IGSxGUI::Util::setColor(sui->tawCPDSubsystem->getWidgetItem(i, 1), SUI::ColorEnum::White, sui->tawCPDSubsystem);
    dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(i, 2))->setText(subsys);
}

void IGSxGUI::CPDView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemCPDs.size(); i++)
    {
        subsystem.name = m_listSubsystemCPDs[i]->getSubsystem();
        subsystem.cpd = m_listSubsystemCPDs[i];
        listStringSubsystem.push_back(m_listSubsystemCPDs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        insertCountLabelAndCloseButton(i);
        sui->tawCPDSubsystem->appendRow();
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        if (subsyscount.nameSubsystem.length() < MAX_SUBSYSTEM_CHARS_PER_CELL)
        {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, i, NORMAL_SUBSYSTEM_ROW_SIZE);
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, i, EXTENDED_SUBSYSTEM_ROW_SIZE);
        }
        setValuesToRowWidgets(subsys, i, subsyscount);
    }

    sui->tawCPDSubsystem->removeRow(sui->tawCPDSubsystem->rowCount() - 1);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->tawCPDSubsystem->rowClicked = boost::bind(&CPDView::onSubsystemPressed, this);
    sui->btnOpenCPD->clicked = boost::bind(&CPDView::onOpenCPDClicked, this);
    sui->btnDescription->clicked = boost::bind(&CPDView::onDescriptionClicked, this);
    sui->btnDescription->hoverEntered = boost::bind(&CPDView::onDescriptionHoverEntered, this);
    sui->btnDescription->hoverLeft = boost::bind(&CPDView::onDescriptionHoverLeft, this);
}

void IGSxGUI::CPDView::onTableCPDRowPressed(int rowindex)
{
    SUI::Widget *widget = sui->tawCPD->getWidgetItem(rowindex, 0);
    IGSxGUI::Util::setADTUCTClickedStyle(widget);
    m_selectedCPD = IGSxGUI::Util::getADTNameFromUserControl(widget);
    boost::trim(m_selectedCPD);
    if (m_selectedCPDRowNum == rowindex)
    {
        IGSxGUI::Util::setADTUCTNormalStyle(sui->tawCPD->getWidgetItem(rowindex, 0));
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
        showCPDDetailsPage(false, m_selectedCPD);
    } else {
        m_selectedCPDRowNum = rowindex;
        EnableCountLabels();
        for (int i = 0; i < sui->tawCPD->rowCount(); ++i )
        {
            IGSxGUI::Util::setADTUCTNormalStyle(sui->tawCPD->getWidgetItem(i, 0));
        }
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawCPD->getWidgetItem(rowindex, 0));
        showCPDDetailsPage(true, m_selectedCPD);
    }
}

void IGSxGUI::CPDView::onCPDUCTHoverEntered(int index)
{
    if (m_selectedCPDRowNum != index)
    {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setADTUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::CPDView::onCPDUCTHoverLeft(int index)
{
  if (m_selectedCPDRowNum != index)
  {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setADTUCTHoverOffStyle(widget);
  }
}

void IGSxGUI::CPDView::onDescriptionHoverEntered()
{
    if (m_isDescFolded)
    {
        IGSxGUI::Util::setUnderline(sui->btnDescription, true);
    }
}

void IGSxGUI::CPDView::onDescriptionHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnDescription, false);
}

void IGSxGUI::CPDView::showCPDDetailsPage(bool isVisible, const std::string &CPDName)
{
    sui->lblLine->setVisible(isVisible);
    sui->lblAngle->setVisible(isVisible);
    sui->lblSelectedCPD->setVisible(isVisible);
    sui->btnOpenCPD->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->wvwCPDHTMLDescription->setVisible(isVisible);

    if (isVisible)
    {
        sui->lblSelectedCPD->setText(CPDName);
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);

        if (m_isDescFolded)
        {
            showHTMLReport(false);
        } else {
            IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showHTMLReport(true);
        }
    }
}

void IGSxGUI::CPDView::onDescriptionClicked()
{
    if (m_isDescFolded)
    {
        m_isDescFolded = false;
        showHTMLReport(true);
        IGSxGUI::Util::setUnderline(sui->btnDescription, false);
    } else {
        m_isDescFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showHTMLReport(false);
    }
}

void IGSxGUI::CPDView::onOpenCPDClicked()
{
    /*IGS_INFO(std::string(STRING_CPD_MESSAGE + m_selectedCPD));

    if (m_presenter->isCPDRunning(m_selectedCPD))
    {
        sui->lblStartingCPD->setText(STRING_CPD_ALREADY_RUNNING);
    } else {
        sui->lblStartingCPD->setText(STRING_CPD_SHOWING);
    }
    sui->lblStartingCPD->setVisible(true);

    const int timout = 2000;
    m_startingCPDTimer->start(timout);

    m_presenter->startCPD(m_selectedCPD);*/
}

void IGSxGUI::CPDView::onShowCPDStartingTimeout()
{
    sui->lblStartingCPD->setVisible(false);
}

void IGSxGUI::CPDView::showHTMLReport(bool isVisible)
{
    if (isVisible)
    {
        if (m_selectedCPD != "")
        {
            IGSxGUI::CPD* CPD = m_presenter->getCPD(m_selectedCPD);

            if (CPD != NULL)
            {
                IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
                std::string strCPDHTMLFilePath = CPD->getHtmlFile();
                sui->wvwCPDHTMLDescription->setVisible(true);
                sui->wvwCPDHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strCPDHTMLFilePath));
                sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
            }
        }
    } else {
        sui->wvwCPDHTMLDescription->setVisible(false);
        IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
    }
}

void IGSxGUI::CPDView::reload()
{
    if (m_selectedSubSystem != "")
    {
        m_isInternalCallToSubsystemPressed = true;
        IGSxGUI::Util::selectRow(sui->tawCPDSubsystem, m_selectedSubsystemRowNum);
        m_isInternalCallToSubsystemPressed = false;
    } else {
        loadCPDTable();
    }

    if (m_selectedCPD != "")
    {
        IGSxGUI::Util::setADTUCTClickedStyle(sui->tawCPD->getWidgetItem(m_selectedCPDRowNum, 0));
        showCPDDetailsPage(true, m_selectedCPD);

        if (m_isDescFolded)
        {
            IGSxGUI::Util::setAwesome(sui->lblAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showHTMLReport(false);
        } else {
            showHTMLReport(true);
        }
    }
}
