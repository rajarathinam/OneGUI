/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManagerTest.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD Manager test
|
| ! \file        IGSxGUIxCPDManagerTest.cpp
| ! \brief       Implementation of CPD Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxCPDManagerTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(CPDManagerTest, Test1)
{
  std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
  EXPECT_EQ(cpds.size(), 6);

  IGSxGUI::CPD* cpd = new IGSxGUI::CPD(IGSxCPD::MetaDescription("TestName", "TestType", "TestSubSystem", "TestDescription", "TestDescriptionFile"));
  ASSERT_TRUE(cpd != NULL);

  EXPECT_STRCASEEQ("TestName", cpd->getName().c_str());
  EXPECT_STRCASEEQ("TestType", cpd->getTestType().c_str());
  EXPECT_STRCASEEQ("TestDescription", cpd->getDescription().c_str());
  EXPECT_STRCASEEQ("TestSubSystem", cpd->getSubsystem().c_str());
  EXPECT_STRCASEEQ("TestDescriptionFile", cpd->getHtmlFile().c_str());

  ASSERT_TRUE(m_cpdManager->add(cpd));

  cpds = m_cpdManager->retrieveAll();
  EXPECT_EQ(cpds.size(), 7);

  IGSxGUI::CPD* requiredCpd = m_cpdManager->getCPD("TestName");
  ASSERT_TRUE(requiredCpd != NULL);

  EXPECT_STRCASEEQ("TestName", requiredCpd->getName().c_str());
  EXPECT_STRCASEEQ("TestType", requiredCpd->getTestType().c_str());
  EXPECT_STRCASEEQ("TestDescription", requiredCpd->getDescription().c_str());
  EXPECT_STRCASEEQ("TestSubSystem", requiredCpd->getSubsystem().c_str());
  EXPECT_STRCASEEQ("TestDescriptionFile", requiredCpd->getHtmlFile().c_str());

  EXPECT_EQ(requiredCpd, cpd);
}

TEST_F(CPDManagerTest, Test2)
{
    std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);

    IGSxGUI::CPD* requiredCpd = m_cpdManager->getCPD("CPDFFMDFC");
    ASSERT_TRUE(requiredCpd != NULL);

    EXPECT_STRCASEEQ("CPDFFMDFC", requiredCpd->getName().c_str());
    EXPECT_STRCASEEQ("Calibration", requiredCpd->getTestType().c_str());
    EXPECT_STRCASEEQ("CPD FFM Default Filter Calibration", requiredCpd->getDescription().c_str());
    EXPECT_STRCASEEQ("FinalFocusMetrology", requiredCpd->getSubsystem().c_str());
    EXPECT_STRCASEEQ("ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html", requiredCpd->getHtmlFile().c_str());

    ASSERT_TRUE(m_cpdManager->remove(requiredCpd));

    cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 5);
}

TEST_F(CPDManagerTest, Test3)
{
    std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);

    ASSERT_TRUE(cpds[0]->start());

    IGSxGUI::CPD* runningCPD = m_cpdManager->retrieveRunningCPD();
    ASSERT_TRUE(runningCPD != NULL);

    EXPECT_EQ(cpds[0], runningCPD);

    EXPECT_STRCASEEQ(runningCPD->getName().c_str(), cpds[0]->getName().c_str());
    EXPECT_STRCASEEQ(runningCPD->getTestType().c_str(), cpds[0]->getTestType().c_str());
    EXPECT_STRCASEEQ(runningCPD->getSubsystem().c_str(), cpds[0]->getSubsystem().c_str());
    EXPECT_STRCASEEQ(runningCPD->getDescription().c_str(), cpds[0]->getDescription().c_str());
    EXPECT_STRCASEEQ(runningCPD->getHtmlFile().c_str(), cpds[0]->getHtmlFile().c_str());
}

TEST_F(CPDManagerTest, Test4)
{
    std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);

    IGSxGUI::CPD* unKnownCPD = m_cpdManager->getCPD("UNKNOWN");
    ASSERT_TRUE(unKnownCPD == NULL);
}

TEST_F(CPDManagerTest, Test5)
{
    std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);

    IGSxGUI::CPD* newCPD = new IGSxGUI::CPD(IGSxCPD::MetaDescription("CPDFFMDFC", "Calibration", "FinalFocusMetrology", "CPD FFM Default Filter Calibration", "ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html"));
    ASSERT_TRUE(newCPD != NULL);

    ASSERT_FALSE(m_cpdManager->add(newCPD));

    cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);
}

TEST_F(CPDManagerTest, Test6)
{
    std::vector<IGSxGUI::CPD*> cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);

    IGSxGUI::CPD* unknownCPD = new IGSxGUI::CPD(IGSxCPD::MetaDescription("UnknownName", "UnknownType", "UnknownSubSystem", "UnknownDescription", "UnknownDescriptionFile"));
    ASSERT_TRUE(unknownCPD != NULL);

    ASSERT_FALSE(m_cpdManager->remove(unknownCPD));

    cpds = m_cpdManager->retrieveAll();
    EXPECT_EQ(cpds.size(), 6);
}
