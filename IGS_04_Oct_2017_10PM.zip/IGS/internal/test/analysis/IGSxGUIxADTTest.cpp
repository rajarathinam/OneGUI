/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTTest.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT test
|
| ! \file        IGSxGUIxADTTest.cpp
| ! \brief       Implementation of ADT test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxADTTest.hpp"
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTTest, Test_1)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);

    std::string adtname = adt.getName();
    EXPECT_STRCASEEQ("Amplification Chain", adtname.c_str());

    std::string adtdescription = adt.getDescription();
    EXPECT_STRCASEEQ("ADT for high Power Amplification Chain", adtdescription.c_str());

    std::string adtsubsystem = adt.getSubsystem();
    EXPECT_STRCASEEQ("Laser Light Generation and Positioning", adtsubsystem.c_str());

    std::string adthtmlfile = adt.getHtmlFile();
    EXPECT_STRCASEEQ("/usr/local/msc/config/ADT//LAT_ACC.html", adthtmlfile.c_str());
}

TEST_F(ADTTest, Test_2)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);
    ASSERT_TRUE(adt.start());
}
