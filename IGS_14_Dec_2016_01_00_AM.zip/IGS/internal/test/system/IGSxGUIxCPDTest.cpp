/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDTest.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD test
|
| ! \file        IGSxGUIxCPDTest.cpp
| ! \brief       Implementation of CPD test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxCPDTest.hpp"
#include "IGSxGUIxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(CPDTest, Test_1)
{
    IGSxCPD::MetaDescription metaData("CPDFFMDFC","Calibration","CPD FFM Default Filter Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html","FinalFocusMetrology");

    IGSxGUI::CPD cpd(metaData);
    EXPECT_STRCASEEQ(cpd.getName().c_str(), metaData.name().c_str());
    EXPECT_STRCASEEQ(cpd.getTestType().c_str(), metaData.testType().c_str());
    EXPECT_STRCASEEQ(cpd.getDescription().c_str(), metaData.description().c_str());
    EXPECT_STRCASEEQ(cpd.getSubsystem().c_str(), metaData.subSystem().c_str());
    EXPECT_STRCASEEQ(cpd.getHtmlFile().c_str(), metaData.htmlFile().c_str());
}

TEST_F(CPDTest, Test_2)
{
    IGSxCPD::MetaDescription metaData("CPDFFMDFC","Calibration","CPD FFM Default Filter Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html","FinalFocusMetrology");

    IGSxGUI::CPD cpd(metaData);
    ASSERT_TRUE(cpd.start());
}
