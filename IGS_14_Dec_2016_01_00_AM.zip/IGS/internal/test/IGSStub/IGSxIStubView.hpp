/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxIStubView.hpp
| Author       : Arjan Tekelenburg
| Description  : Interfaces for Stub View
|
| ! \file        IGSxIStubView.hpp
| ! \brief       Interface file for Stub View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXISTUBVIEW_HPP
#define IGSXISTUBVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class IStubView
{
 public:
    IStubView(){}
    virtual ~IStubView(){}
    virtual void show() = 0;
    virtual void showStatus(std::string strStatus) = 0;
    virtual void updateKPI(string kpiName, string upTime, vector<double> values) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXISYSTEMVIEW_HPP
