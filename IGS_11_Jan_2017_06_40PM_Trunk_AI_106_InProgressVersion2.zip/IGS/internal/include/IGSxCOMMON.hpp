/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCOMMON.hpp
| Author       : Thijs Jacobs
| Description  : IGS common includes
|
| ! \file        IGSxCOMMON.hpp
| ! \brief       IGS common includes
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXCOMMON_HPP
#define IGSXCOMMON_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <exception>

namespace IGS {
/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// result type
typedef int Result;
const int OK = 0;  // OK result

/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
// resource path
// this is a workaround until the resource path is facilitated by FWQ
class Resource
{
 public:
    Resource()
    {
     // Currently No members to Initialize
    }
    virtual ~Resource()
    {
    }
    static std::string path() { return std::string(""); }  // On ASML side: return std::string(CSDxAPP::BIN_LNX_X86_64_DIR).append("/");
    static std::string path(const std::string& _resFile)
    {
          return std::string(path() + _resFile);
    }
};

// exceptions
class Exception: public std::exception
{
 public:
    explicit Exception(const std::string& message):m_msg(message){}
    virtual ~Exception() throw() {}

    virtual const char* what() const throw() {return m_msg.c_str();}

 private:
    std::string m_msg;
};

}  // namespace IGS

#endif  // IGSXCOMMON_HPP

