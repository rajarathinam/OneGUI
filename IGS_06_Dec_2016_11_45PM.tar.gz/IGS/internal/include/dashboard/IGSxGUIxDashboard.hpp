/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboard.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard page
|
| ! \file        IGSxGUIxDashboard.hpp
| ! \brief       Header file for Dashboard page
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARD_HPP
#define IGSXGUIXDASHBOARD_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIDashboard.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class Dashboard: public IGSxGUI::IDashboard
{
 public:
    Dashboard();
    virtual ~Dashboard();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    Dashboard(Dashboard const &);
    Dashboard& operator=(Dashboard const &);

    IDashboardView *m_dashboardView;
    KPIManager* m_kpiManager;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXDASHBOARD_HPP
