/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard Presenter
|
| ! \file        IGSxGUIxDashboardPresenter.hpp
| ! \brief       Header file for Dashboard Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDPRESENTER_HPP
#define IGSXGUIXDASHBOARDPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxKPI.hpp"
#include "IGSxGUIxKPIManager.hpp"

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class DashboardPresenter
{
 public:
    explicit DashboardPresenter(IGSxGUI::IDashboardView* view, KPIManager* pKPIManager);
    virtual ~DashboardPresenter();

    vector<KPI *> getKPIs();
    vector<KPI *> getSystemKPIs();
    vector<KPI *> getConsumables();

    vector<KPIValueSet*> getKPIValueSets(string kpiName);

    void subscribeForEvents();
    void unsubscribeForEvents();

 private:
    DashboardPresenter(const DashboardPresenter&);
    DashboardPresenter& operator=(const DashboardPresenter&);

    void onKPIDataUpdated(string kpiName, string type, string valueSetName, vector<double> values);

    KPIManager* m_pKPIManager;
    IDashboardView *m_view;

    vector<boost::signals2::connection> m_KPIConnections;
    vector<boost::signals2::connection> m_SystemKPIConnections;
    vector<boost::signals2::connection> m_ConsumableConnections;

    static const string STRING_KPI;
    static const string STRING_SYSTEMKPI;
    static const string STRING_CONSUMABLE;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDASHBOARDPRESENTER_HPP
