/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPluginFactory.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Plugin Factory
|
| ! \file        IGSxGUIxPluginFactory.cpp
| ! \brief       Implementation of Plugin Factory
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxDashboard.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::PluginFactory::PluginFactory():
    m_systemPlugin(NULL),
    m_analysisPlugin(NULL),
    m_dashboardPlugin(NULL)
{
}

IGSxGUI::PluginFactory::~PluginFactory()
{
    delete m_systemPlugin;
    delete m_analysisPlugin;
    delete m_dashboardPlugin;
}

IGSxGUI::ISystem* IGSxGUI::PluginFactory::getSystemPlugin()
{
    if (m_systemPlugin == NULL)
    {
        m_systemPlugin = new IGSxGUI::System();
    }
    return m_systemPlugin;
}

IGSxGUI::IAnalysis* IGSxGUI::PluginFactory::getAnalysisPlugin()
{
    if (m_analysisPlugin == NULL)
    {
        m_analysisPlugin = new IGSxGUI::Analysis();
    }
    return m_analysisPlugin;
}

IGSxGUI::IDashboard* IGSxGUI::PluginFactory::getDashboardPlugin()
{
    if (m_dashboardPlugin == NULL)
    {
        m_dashboardPlugin = new IGSxGUI::Dashboard();
    }
    return m_dashboardPlugin;
}

