/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for Alert presenter
|
| ! \file        IGSxGUIxAlertPresenter.hpp
| ! \brief       Header file for Alert presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTPRESENTER_HPP
#define IGSXGUIXALERTPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2.hpp>
#include <vector>
#include "IGSxGUIxIAlertView.hpp"
#include "IGSxGUIxAlertManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class AlertPresenter
{
 public:
    explicit AlertPresenter(IAlertView* view, AlertManager* pAlertManager);
    virtual ~AlertPresenter();

    std::vector<Alert *> getActiveAlerts() const;
    Alert* getAlert(int nAlertLogID) const;

    void OnAlertUpdated(int nAlertCount, AlertInfo alertInfo) const;

    void subscribeForEvents();
    void unsubscribeForEvents();

 private:
    AlertPresenter(const AlertPresenter& alertPresenter);
    AlertPresenter& operator=(const AlertPresenter& alertPresenter);
    IAlertView *m_view;
    AlertManager *m_pAlertManager;
    boost::signals2::connection m_connection;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXALERTPRESENTER_HPP
