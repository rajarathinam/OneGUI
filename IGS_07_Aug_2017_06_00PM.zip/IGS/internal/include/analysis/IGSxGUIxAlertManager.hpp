/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertManager.hpp
| Author       : Venugopal S
| Description  : Header file for Alert manager
|
| ! \file        IGSxGUIxAlertManager.hpp
| ! \brief       Header file for Alert manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTMANAGER_HPP
#define IGSXGUIXALERTMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxERR.hpp"
#include "IGSxGUIxAlert.hpp"
#include "IGSxGUIxAlertEvent.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class AlertManager
{
 public:
    AlertManager();
    virtual ~AlertManager();

    std::vector<Alert*> getActiveAlerts() const;
    Alert* getAlert(int nAlertLogID) const;

    boost::signals2::connection registerToAlertUpdated(const alertUpdatedCallback& cb);

    void initialize();

 private:
    AlertManager(AlertManager const &);
    AlertManager& operator=(AlertManager const &);

    void onAlertRaised(const IGSxERR::ActivatedAlert& alert);
    void onAlertRemoved(const IGSxERR::DeactivatedAlert& alert);

    alertUpdated m_alertUpdated;
    std::vector<Alert*> m_Alerts;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXALERTMANAGER_HPP
