/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManagerTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver Manager test
|
| ! \file        IGSxGUIxDriverManagerTest.cpp
| ! \brief       Implementation of Driver Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxDriverManagerTest.hpp"
#include "IGSxGUIxSystemState.hpp"
#include "IGSxITS.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(DriverManagerTest, Test1)
{
    ASSERT_TRUE(m_driverManager != NULL);
    std::vector<IGSxGUI::SystemFunction*> sys = m_driverManager->getSystemFunctions();
    EXPECT_EQ(sys.size(), 6);

    IGSxGUI::SystemFunction* sysfun = sys[0];
    ASSERT_TRUE(sysfun != NULL);

    EXPECT_STRCASEEQ(sysfun->getName().c_str(), "SF-04");
    EXPECT_STRCASEEQ(sysfun->getDescription().c_str(), "SF Environmental Mgt");

    IGSxGUI::SystemFunction* sysfun1 = m_driverManager->getSystemFunction("SF-04");
    ASSERT_TRUE(sysfun1 != NULL);

    IGSxGUI::SystemFunction* sysfun2 = m_driverManager->getSystemFunction("UNKNOWN");
    ASSERT_TRUE(sysfun2 == NULL);

    EXPECT_STRCASEEQ(sysfun1->getName().c_str(), "SF-04");
    EXPECT_STRCASEEQ(sysfun1->getDescription().c_str(), "SF Environmental Mgt");
}

TEST_F(DriverManagerTest, Test2)
{
    ASSERT_TRUE(m_driverManager != NULL);
    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    EXPECT_STRCASEEQ(drv->getName().c_str(), "SSD HPRGA");
    EXPECT_STRCASEEQ(drv->getDisplayName().c_str(), "SSD HPRGA");

    IGSxGUI::Driver* drv1 = m_driverManager->getDriver("UNKNOWN");
    ASSERT_TRUE(drv1 == NULL);
}

TEST_F(DriverManagerTest, Test3)
{
    std::vector<IGSxGUI::SystemFunction*> sys = m_driverManager->getSystemFunctions();
    EXPECT_EQ(sys.size(), 6);

    m_driverManager->addSystemFunctions(m_additionalSystemFunctions);

    sys = m_driverManager->getSystemFunctions();
    EXPECT_EQ(sys.size(), 8);
}

TEST_F(DriverManagerTest, Test4)
{
    ASSERT_TRUE(m_driverManager != NULL);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZED, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_INITIALIZING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_TERMINATED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATED, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    m_driverManager->setSystemState(IGSxGUI::SystemState::SS_TERMINATING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());
}

TEST_F(DriverManagerTest, Test5)
{
    ASSERT_TRUE(m_driverManager != NULL);

    std::vector<IGSxGUI::SystemFunction*> sysfuns = m_driverManager->getSystemFunctions();

    for (size_t i= 0; i < sysfuns.size(); i++)
    {
        IGSxGUI::SystemFunction* sysfun = sysfuns[i];
        ASSERT_TRUE(sysfun != NULL);

        std::vector<IGSxGUI::Driver*> drivers =  sysfun->getDrivers();

        for (size_t j= 0; j < drivers.size(); j++)
        {
            IGSxGUI::Driver*  drv = drivers[j];
            ASSERT_TRUE(drv != NULL);

            drv->updateDriverState(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
            EXPECT_EQ(IGSxITS::DriverState::DS_RECOVERY_REQUIRED, drv->getState());
        }
        EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, sysfun->getState());
    }
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());
}

TEST_F(DriverManagerTest, Test6)
{
    ASSERT_TRUE(m_driverManager != NULL);

    std::vector<IGSxGUI::SystemFunction*> sysfuns = m_driverManager->getSystemFunctions();

    for (size_t i= 0; i < sysfuns.size(); i++)
    {
        IGSxGUI::SystemFunction* sysfun = sysfuns[i];
        ASSERT_TRUE(sysfun != NULL);

        std::vector<IGSxGUI::Driver*> drivers =  sysfun->getDrivers();

        for (size_t j= 0; j < drivers.size(); j++)
        {
            IGSxGUI::Driver*  drv = drivers[j];
            ASSERT_TRUE(drv != NULL);

            drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZED);
            EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZED, drv->getState());
        }
        EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZED, sysfun->getState());
    }
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZED, m_driverManager->getSystemState());

    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    drv->updateDriverState(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxITS::DriverState::DS_RECOVERY_REQUIRED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED, m_driverManager->getSystemState());
}

TEST_F(DriverManagerTest, Test7)
{
    ASSERT_TRUE(m_driverManager != NULL);

    std::vector<IGSxGUI::SystemFunction*> sysfuns = m_driverManager->getSystemFunctions();

    for (size_t i= 0; i < sysfuns.size(); i++)
    {
        IGSxGUI::SystemFunction* sysfun = sysfuns[i];
        ASSERT_TRUE(sysfun != NULL);

        std::vector<IGSxGUI::Driver*> drivers =  sysfun->getDrivers();

        for (size_t j= 0; j < drivers.size(); j++)
        {
            IGSxGUI::Driver*  drv = drivers[j];
            ASSERT_TRUE(drv != NULL);

            drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZING);
            EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZING, drv->getState());
        }
        EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun->getState());
    }
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    drv->updateDriverState(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxITS::DriverState::DS_RECOVERY_REQUIRED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());
}


TEST_F(DriverManagerTest, Test8)
{
    ASSERT_TRUE(m_driverManager != NULL);

    std::vector<IGSxGUI::SystemFunction*> sysfuns = m_driverManager->getSystemFunctions();

    for (size_t i= 0; i < sysfuns.size(); i++)
    {
        IGSxGUI::SystemFunction* sysfun = sysfuns[i];
        ASSERT_TRUE(sysfun != NULL);

        std::vector<IGSxGUI::Driver*> drivers =  sysfun->getDrivers();

        for (size_t j= 0; j < drivers.size(); j++)
        {
            IGSxGUI::Driver*  drv = drivers[j];
            ASSERT_TRUE(drv != NULL);

            drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATED);
            EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATED, drv->getState());
        }
        EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATED, sysfun->getState());
    }
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATED, m_driverManager->getSystemState());

    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    drv->updateDriverState(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxITS::DriverState::DS_RECOVERY_REQUIRED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());
}

TEST_F(DriverManagerTest, Test9)
{
    ASSERT_TRUE(m_driverManager != NULL);

    std::vector<IGSxGUI::SystemFunction*> sysfuns = m_driverManager->getSystemFunctions();

    for (size_t i= 0; i < sysfuns.size(); i++)
    {
        IGSxGUI::SystemFunction* sysfun = sysfuns[i];
        ASSERT_TRUE(sysfun != NULL);

        std::vector<IGSxGUI::Driver*> drivers =  sysfun->getDrivers();

        for (size_t j= 0; j < drivers.size(); j++)
        {
            IGSxGUI::Driver*  drv = drivers[j];
            ASSERT_TRUE(drv != NULL);

            drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATING);
            EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATING, drv->getState());
        }
        EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun->getState());
    }
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    IGSxGUI::Driver* drv = m_driverManager->getDriver("SSD HPRGA");
    ASSERT_TRUE(drv != NULL);

    drv->updateDriverState(IGSxITS::DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxITS::DriverState::DS_RECOVERY_REQUIRED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxITS::DriverState::DS_TERMINATED, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, m_driverManager->getSystemState());

    drv->updateDriverState(IGSxITS::DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxITS::DriverState::DS_INITIALIZING, drv->getState());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, m_driverManager->getSystemState());
}
