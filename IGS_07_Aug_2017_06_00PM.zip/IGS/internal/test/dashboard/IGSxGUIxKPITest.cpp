/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPITest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI test
|
| ! \file        IGSxGUIxKPITest.cpp
| ! \brief       Implementation of KPI test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKPITest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPITestParam,
                        ::testing::Values("EUV_Pulse_Energy_Internal"));

TEST_P(KPITestParam, Constructor)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);

    EXPECT_STRCASEEQ(kpi.getName().c_str(), m_kpiDefinition1.name().c_str());
    EXPECT_STRCASEEQ(kpi.getDescription().c_str(), m_kpiDefinition1.description().c_str());
}

TEST_P(KPITestParam, ValueContentSize)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);
}

TEST_P(KPITestParam, TypeTest)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    kpi.setType("KPI");
    EXPECT_STRCASEEQ("KPI", kpi.getType().c_str());

    kpi.setType("System");
    EXPECT_STRCASEEQ("System", kpi.getType().c_str());

    kpi.setType("Consumable");
    EXPECT_STRCASEEQ("Consumable", kpi.getType().c_str());

    kpi.setType("");
    EXPECT_STRCASEEQ("", kpi.getType().c_str());

    kpi.setType(" ");
    EXPECT_STRCASEEQ(" ", kpi.getType().c_str());

    kpi.setType("12345");
    EXPECT_STRCASEEQ("12345", kpi.getType().c_str());

}



TEST_P(KPITestParam, GetActiveValueSet)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);

   for(size_t index = 0; index < valsetlist.size(); ++index)
     {
       EXPECT_TRUE(valsetlist[index]->isActive() == false);
     }

    IGSxGUI::KPIValueSet *invalidActiveValueset = kpi.getActiveValueSet();
    EXPECT_TRUE(invalidActiveValueset ==  NULL);


     valsetlist[1]->setActive(true);
     EXPECT_TRUE(valsetlist[1]->isActive() == true);
     EXPECT_EQ(1, valsetlist[1]->getIndexPosition());

    IGSxGUI::KPIValueSet *validActiveValueset = kpi.getActiveValueSet();
    EXPECT_TRUE(validActiveValueset !=  NULL);
    EXPECT_TRUE(validActiveValueset->isActive() == true);
    EXPECT_EQ(1, validActiveValueset->getIndexPosition());
}


TEST_P(KPITestParam, GetValueSet)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    IGSxGUI::KPIValueSet* valueSet= kpi.getValueSet("");
    EXPECT_TRUE(valueSet ==  NULL);

    IGSxGUI::KPIValueSet* valueSet1= kpi.getValueSet(" ");
    EXPECT_TRUE(valueSet1 ==  NULL);

    IGSxGUI::KPIValueSet* valueSet2= kpi.getValueSet("ValueSetName1_1");
    EXPECT_TRUE(valueSet2 !=  NULL);

    IGSxGUI::KPIValueSet* valueSet3= kpi.getValueSet("INVALID");
    EXPECT_TRUE(valueSet3 ==  NULL);

}

TEST_P(KPITestParam, updateValueTest)
{
  IGSxGUI::KPI kpi(m_kpiDefinition1);
  //kpi.registerForValueChanged(boost::bind(Dummy::onKPIDataUpdated,this, _1, _2));
}

