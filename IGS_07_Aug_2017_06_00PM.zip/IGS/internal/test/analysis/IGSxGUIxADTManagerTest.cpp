/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManagerTest.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT Manager test
|
| ! \file        IGSxGUIxADTManagerTest.cpp
| ! \brief       Implementation of ADT Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxADTManagerTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTManagerTest, Test1)
{
  ASSERT_TRUE(m_adtManager != NULL);

  std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
  EXPECT_EQ(6, adtList.size());

  IGSxGUI::ADT* adt = new IGSxGUI::ADT(IGSxADT::MetaDescription("TestName", "TestSubSystem", "TestDesc", "TestFile"));
  ASSERT_TRUE(adt != NULL);

  EXPECT_STRCASEEQ("TestName", adt->getName().c_str());
  EXPECT_STRCASEEQ("TestSubSystem", adt->getSubsystem().c_str());
  EXPECT_STRCASEEQ("TestDesc", adt->getDescription().c_str());
  EXPECT_STRCASEEQ("TestFile", adt->getHtmlFile().c_str());

  ASSERT_TRUE(m_adtManager->add(adt));

  adtList = m_adtManager->retrieveAll();
  EXPECT_EQ(adtList.size(), 7);

  IGSxGUI::ADT* requiredAdt = m_adtManager->getADT("TestName");
  ASSERT_TRUE(requiredAdt != NULL);

  EXPECT_STRCASEEQ("TestName", requiredAdt->getName().c_str());
  EXPECT_STRCASEEQ("TestSubSystem", requiredAdt->getSubsystem().c_str());
  EXPECT_STRCASEEQ("TestDesc", requiredAdt->getDescription().c_str());
  EXPECT_STRCASEEQ("TestFile", requiredAdt->getHtmlFile().c_str());

  EXPECT_EQ(requiredAdt, adt);
}

TEST_F(ADTManagerTest, Test2)
{
    std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);

    IGSxGUI::ADT* requiredAdt = m_adtManager->getADT("Amplification Chain");
    ASSERT_TRUE(requiredAdt != NULL);

    EXPECT_EQ("Amplification Chain", requiredAdt->getName());
    EXPECT_STRCASEEQ("Laser Light Generation and Positioning", requiredAdt->getSubsystem().c_str());
    EXPECT_STRCASEEQ("ADT for high Power Amplification Chain", requiredAdt->getDescription().c_str());
    EXPECT_STRCASEEQ("LAT_ACC.html", requiredAdt->getHtmlFile().c_str());

    ASSERT_TRUE(m_adtManager->remove(requiredAdt));

    adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 5);
}

TEST_F(ADTManagerTest, Test3)
{
    ASSERT_TRUE(m_adtManager != NULL);

    std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(6, adtList.size());

    ASSERT_TRUE(adtList[0]->start());
}

TEST_F(ADTManagerTest, Test4)
{
    std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);

    IGSxGUI::ADT* unKnownADT = m_adtManager->getADT("UNKNOWN");
    ASSERT_TRUE(unKnownADT == NULL);
}

TEST_F(ADTManagerTest, Test5)
{
    std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);

    IGSxGUI::ADT* newADT = new IGSxGUI::ADT(IGSxADT::MetaDescription("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"));
    ASSERT_TRUE(newADT != NULL);

    ASSERT_FALSE(m_adtManager->add(newADT));

    adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);
}

TEST_F(ADTManagerTest, Test6)
{
    std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);

    IGSxGUI::ADT* unknownADT = new IGSxGUI::ADT(IGSxADT::MetaDescription("UnknownName", "UnknownSubSystem", "UnknownDescription", "UnknownDescriptionFile"));
    ASSERT_TRUE(unknownADT != NULL);

    ASSERT_FALSE(m_adtManager->remove(unknownADT));

    adtList = m_adtManager->retrieveAll();
    EXPECT_EQ(adtList.size(), 6);
}

TEST_F(ADTManagerTest, Test7)
{
    IGSxGUI::ADTManager adtManager;
    std::vector<IGSxGUI::ADT*> adtList = adtManager.retrieveAll();
    EXPECT_EQ(adtList.size(), 0);
    adtManager.initialize();
    adtList = adtManager.retrieveAll();
    EXPECT_EQ(adtList.size(), 12);

    for(size_t index = 0; index < adtList.size(); ++index)
      {
        IGSxGUI::ADT* adt = adtList[index];
        TestMetaType testMetatype= testADT[index];
        EXPECT_STRCASEEQ(adt->getName().c_str(), testMetatype.name.c_str());
        EXPECT_STRCASEEQ(adt->getSubsystem().c_str(), testMetatype.subsystem.c_str());
        EXPECT_STRCASEEQ(adt->getDescription().c_str(), testMetatype.description.c_str());
        EXPECT_STRCASEEQ(adt->getHtmlFile().c_str(), testMetatype.descriptionFile.c_str());

      }
}

TEST_F(ADTManagerTest, Test8)
{
  IGSxGUI::ADTManager adtManager;
  EXPECT_FALSE(adtManager.add(NULL));
}

