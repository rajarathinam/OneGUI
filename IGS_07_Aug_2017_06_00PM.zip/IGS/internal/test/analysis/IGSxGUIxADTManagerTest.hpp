/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManagerTest.hpp
| Author       : Venugopal S
| Description  : Header file for ADT Manager test
|
| ! \file        IGSxGUIxADTManagerTest.hpp
| ! \brief       Header file for ADT Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTMANAGERTEST_HPP
#define IGSXGUIXADTMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    std::string name;
    std::string subsystem;
    std::string description;
    std::string descriptionFile;
} TestMetaType;

TestMetaType testADT[] = {
    {"Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"},
    {"Collector Cooling", "Environmental control", "Collector Cooling ADT", "CCD_CCS.html"},
    {"Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "DGD_CCS.html"},
    {"Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "LEF_FFA.html"},
    {"GVA", "Gas and vacuum", "GVA ADT", "LSC_AlignmentADT.html"},
    {"HP-RGA", "Environmental control", "HP-RGA ADT", "LasersADT.html"},
    {"Heated Tin Vanes Bucket", "Tin Mitigation", "The ADT of the Heated Tin Vanes Bucket (HTVB)", "VDT_DCR.html"},
    {"Plasma Control", "Plasma Generation and Energy Control", "Plasma Control ADT", "PDH_PCL.html"},
    {"Real Time Streaming", "Generic Diagnostics", "The ADT for Real Time data Streaming", "VDA_TvbPlus.html"},
    {"Timing and Energy Control", "Plasma Generation and Energy Control", "Timing and Energy Control (TEC) ADT", "VDA_Fatc.html"},
    {"Vanes Manual Thermal Cycling", "Tin Mitigation", "ADT for the manual thermal cycling of the vanes", "LSC_SystemInfoADT.html"},
    {"Vessel Cooling", "Environmental control", "Vessel Cooling ADT", "LasersADT_HPSM.html"}
};
class ADTManagerTest : public ::testing::Test
{
 public:
    ADTManagerTest(){}
    virtual ~ADTManagerTest(){}

 protected:
  IGSxGUI::ADTManager* m_adtManager;

  virtual void SetUp()
  {
      m_adtManager = new IGSxGUI::ADTManager();

      IGSxADT::MetaDescriptions adtDescriptions;
      adtDescriptions.push_back(IGSxADT::MetaDescription("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Collector Cooling", "Environmental control", "Collector Cooling ADT", " CCD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "DGD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "LEF_FFA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("GVA", "Gas and vacuum", "GVA ADT", "GVA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("HP-RGA", "Environmental control", "HP-RGA ADT", "RCA_RCM.html"));

      for (size_t i = 0; i < adtDescriptions.size(); i++)
      {
          IGSxGUI::ADT* adt = new IGSxGUI::ADT(adtDescriptions[i]);
          m_adtManager->add(adt);
      }
  }

  virtual void TearDown()
  {
      std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
      for (size_t i = 0; i < adtList.size(); i++)
      {
          m_adtManager->remove(adtList[i]);
      }

      delete m_adtManager;
      m_adtManager = NULL;
  }
};
#endif  // IGSXGUIXADTMANAGERTEST_HPP
