/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.cpp
| ! \brief       Implementation of KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int IGSxGUI::KPIValueSet::TOTAL_LIMITING_MINUTES = 380;
const int IGSxGUI::KPIValueSet::DEGREE_CELSIUS_PER_KELVIN = 273.15;
const string IGSxGUI::KPIValueSet::KELVIN = "K";

IGSxGUI::KPIValueSet::KPIValueSet(const IGSxKPI::KPIValueSetDefinition &kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description()),
    m_unit(kpiDefinition.unit()),
    m_displayUnit(""),
    m_factor(0),
    m_min(0),
    m_max(0),
    m_isActive(false)
{
    m_cbKPITimeValue.set_capacity(TOTAL_LIMITING_MINUTES);

    for (int index = 0; index < TOTAL_LIMITING_MINUTES; ++index)
    {
        KPITimeValue kpiTimeValue;

        kpiTimeValue.kpiTime = 0;
        kpiTimeValue.kpiValue = 0.0;

        m_cbKPITimeValue.push_back(kpiTimeValue);
    }
}

IGSxGUI::KPIValueSet::~KPIValueSet()
{
}

string IGSxGUI::KPIValueSet::getName() const
{
    return m_name;
}

string IGSxGUI::KPIValueSet::getDescription() const
{
    return m_desc;
}

string IGSxGUI::KPIValueSet::getUnit() const
{
    return m_unit;
}

std::string IGSxGUI::KPIValueSet::getDisplayUnit() const
{
    return m_displayUnit;
}

double IGSxGUI::KPIValueSet::getFactor() const
{
    return m_factor;
}

double IGSxGUI::KPIValueSet::getMin() const
{
    return m_min;
}
double IGSxGUI::KPIValueSet::getMax() const
{
    return m_max;
}
bool IGSxGUI::KPIValueSet::isActive()
{
    return m_isActive;
}

void IGSxGUI::KPIValueSet::setFactor(double factor)
{
    m_factor = factor;
}

void IGSxGUI::KPIValueSet::setMin(double min)
{
    m_min = min;
}

void IGSxGUI::KPIValueSet::setMax(double max)
{
    m_max = max;
}

void IGSxGUI::KPIValueSet::setDisplayUnit(const std::string &unit)
{
    m_displayUnit = unit;
}

void IGSxGUI::KPIValueSet::setActive(bool active)
{
    m_isActive = active;
}

void IGSxGUI::KPIValueSet::addValue(const time_t &time, const double &value)
{
    KPITimeValue previousKpiTimeValue = m_cbKPITimeValue.back();

    if (time  > previousKpiTimeValue.kpiTime)
    {
        KPITimeValue kpiTimeValue;

        kpiTimeValue.kpiTime = time;
        if (getUnit() == KELVIN)  // Convert Kelvin values to Celsius
        {
            kpiTimeValue.kpiValue = value * m_factor - DEGREE_CELSIUS_PER_KELVIN;
        } else {
            kpiTimeValue.kpiValue = value * m_factor;
        }

        m_cbKPITimeValue.push_back(kpiTimeValue);
    }
}

boost::circular_buffer<IGSxGUI::KPITimeValue> IGSxGUI::KPIValueSet::getValue() const
{
    return m_cbKPITimeValue;
}

IGSxGUI::KPITimeValue IGSxGUI::KPIValueSet::getLastValue() const
{
    return m_cbKPITimeValue.back();
}
