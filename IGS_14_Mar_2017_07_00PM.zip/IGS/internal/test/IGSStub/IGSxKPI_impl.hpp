/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPI_impl.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for IGSxITS stub
|
| ! \file        IGSxKPI_impl.hpp
| ! \brief       Header file for IGSxITS stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXITS_KPI_HPP
#define IGSXITS_KPI_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <map>
#include <SUITimer.h>
#include "IGSxKPI.hpp"
#include "IGSxKPIParser.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxKPI {

class KPI_Stub :public KPI
{
 public:
    static KPI* getInstance();

    // meta data
    virtual void getKpis(KPIDefinitionList& kpis);
    virtual void getKpi(const std::string& kpiName, KPIDefinition& kpi);

    // data
    virtual void getKpiData(const std::string& kpiName, time_t startTime, time_t stopTime, KPIDataList& kpiData);

    // data update
    virtual void subscribeToKpiData(const std::string& kpiName, const KPIDataCallback& cb);
    virtual void unsubscribeToKpiData(const std::string& kpiName);

    void setKpiData(std::string kpiName, std::string, vector<double> values);

 protected:
    KPI_Stub();
    virtual ~KPI_Stub() {}
 private:
    void onTimeout();
    void generateHistory();

    std::vector<KPIDefinition> m_kpidefs;
    std::map<string, KPIINFO> m_mapKPIs;
    boost::shared_ptr<SUI::Timer> m_timer;
    KPIParser m_kpiParser;
    KPIDataCallback m_kpiDataCallback;

    static const int TIMER_INTERVAL;
    static const string STRING_UP;
    static const string STRING_DOWN;
    static const string STRING_RANDOM;
    static const string STRING_KPI_NOTFOUND;
    static const int TIME_SIX_HOURS_TWENTY_MINUTES;
    static const int TIME_TOTAL_MINUTES;
};
}  // namespace IGSxKPI
#endif  // IGSXITS_KPI_HPP
