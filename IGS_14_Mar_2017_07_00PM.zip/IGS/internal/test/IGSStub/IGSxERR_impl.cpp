/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR_impl.cpp
| Author       : Surya Tiwari
| Description  : Implementation of IGSxERR interface
|
| ! \file        IGSxERR_impl.cpp
| ! \brief       Implementation of IGSxERR interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxERR_impl.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxERR::EventLogger *IGSxERR::EventLogger_Stub::getInstance()
{
    static EventLogger_Stub _instance;
    return &_instance;
}

IGSxERR::EventLogger* IGSxERR::EventLogger::instance = IGSxERR::EventLogger_Stub::getInstance();

IGSxERR::EventLogger_Stub::EventLogger_Stub():m_currentfilename("/home/adt/EventLogs/XER_event_log"),m_previousfilename("/home/adt/EventLogs/XER_event_log_S97391_20161210_144317")
{
}

std::string IGSxERR::EventLogger_Stub::getEventLog()
{
    return m_currentfilename;
}

std::string IGSxERR::EventLogger_Stub::getPreviousEventLog()
{
    return m_previousfilename;
}
