/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for Analysis Presenter
|
| ! \file        IGSxGUIxAnalysisPresenter.hpp
| ! \brief       Header file for Analysis Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXANALYSISPRESENTER_HPP
#define IGSXGUIXANALYSISPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2.hpp>
#include <vector>
#include <string>
#include "IGSxGUIxIAnalysisView.hpp"
#include "IGSxGUIxADT.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class AnalysisPresenter
{
 public:
    explicit AnalysisPresenter(IAnalysisView* view);
    virtual ~AnalysisPresenter();

    std::vector<ADT*> getADTs() const;
    bool startADT(const std::string& adtName) const;

 private:
    AnalysisPresenter(const AnalysisPresenter&);
    AnalysisPresenter& operator=(const AnalysisPresenter&);

    ADTManager* m_pADTManager;
    IAnalysisView *m_view;
    boost::signals2::connection m_connection;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXANALYSISPRESENTER_HPP
