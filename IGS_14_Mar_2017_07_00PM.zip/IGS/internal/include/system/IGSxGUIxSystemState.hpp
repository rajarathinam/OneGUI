/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemState.hpp
| Author       : Arjan Tekelenburg
| Description  : Enum file for System State
|
| ! \file        IGSxGUIxSystemState.hpp
| ! \brief       Enum file for System State
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMSTATE_HPP
#define IGSXGUIXSYSTEMSTATE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SystemState
{
 public:
    typedef enum
    {
        SS_TERMINATING,           // executing actions to get to state TERMINATED
        SS_TERMINATED,            // ready for machine shutdown
        SS_INITIALIZING,          // executing actions to get to state INITIALIZED
        SS_INITIALIZED,           // operational conform specification
        SS_RECOVERY_REQUIRED,     // not available conform specification
        SS_PARTIALLY_INITIALIZED  // The system has initialized and terminated drivers
    } SystemStateEnum;

    SystemState(){}
    virtual ~SystemState() {}
};
typedef boost::signals2::signal<void (SystemState::SystemStateEnum)> systemStateChanged;
typedef systemStateChanged::slot_type SystemStateChangedCallback;
}  // namespace IGSxGUI
#endif
