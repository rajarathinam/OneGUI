/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <string>
#include <vector>
#include <utility>
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include <SUIButton.h>
#include <SUILabel.h>
#include <SUILineEdit.h>
#include <SUIScrollBar.h>
#include <SUIUserControl.h>
#include <SUITableWidget.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";
const std::string IGSxGUI::MachineconstantsView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::MachineconstantsView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETER_FOUND = "parameter found";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETERS_FOUND = "parameters found";
const int IGSxGUI::MachineconstantsView::ROW_HEIGHT = 40;
const int IGSxGUI::MachineconstantsView::BUTTON_SIZE = 18;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS = 18;
const int IGSxGUI::MachineconstantsView::TOTAL_PARAMETERS_COUNT = 2000;

struct find_parameter {
    explicit find_parameter(const std::string& text):m_text(text)
    {
    }
    bool operator()(ParameterData data)
    {
        return ( data.name == m_text);
    }
    std::string m_text;
};


IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager */*pMachineconstantsManager*/):
    sui(new SUI::MachineconstantsView)
{
}


IGSxGUI::MachineconstantsView::~MachineconstantsView()
{
}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(MACHINECONSTANTSVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    createTableData();
    init();
    IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::updateStatus(const std::string &, const IGS::Result &/*result*/)
{
}

void IGSxGUI::MachineconstantsView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::MachineconstantsView::setHandlers()
{
    sui->btnParameterName->hoverEntered = boost::bind(&MachineconstantsView::onParameterNameHoverEntered, this);
    sui->btnParameterName->hoverLeft = boost::bind(&MachineconstantsView::onParameterNameHoverLeft, this);
    sui->btnParameterValue->hoverEntered = boost::bind(&MachineconstantsView::onParameterValueHoverEntered, this);
    sui->btnParameterValue->hoverLeft = boost::bind(&MachineconstantsView::onParameterValueHoverLeft, this);
    sui->lneSearchParameterText->textEdited = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->btnSearchParameter->hoverEntered = boost::bind(&MachineconstantsView::onSearchButtonHoverEntered, this);
    sui->btnSearchParameter->hoverLeft = boost::bind(&MachineconstantsView::onSearchButtonHoverLeft, this);
    sui->btnSearchClear->hoverEntered = boost::bind(&MachineconstantsView::onSearchClearHoverEntered, this);
    sui->btnSearchClear->hoverLeft = boost::bind(&MachineconstantsView::onSearchClearHoverLeft, this);
    sui->btnSearchClear->clicked = boost::bind(&MachineconstantsView::onSearchClearPressed, this);
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    m_parameterview.registerForValueChanged(boost::bind(&MachineconstantsView::onParamaterValueChanged, this, _1, _2));
}

void IGSxGUI::MachineconstantsView::setUCTHandlers(SUI::Widget *widget, int row, bool readonly)
{
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    if (!readonly) {
        usercontrol->clicked = boost::bind(&MachineconstantsView::onParameterRowPressed, this, row);
        usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onParameterUCTHoverEntered, this, row);
        usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onParameterUCTHoverLeft, this, row);
    } else {
        usercontrol->clicked = NULL;
        usercontrol->hoverEntered = NULL;
        usercontrol->hoverLeft = NULL;
    }
}

void IGSxGUI::MachineconstantsView::createTableData()
{
    // stub
    m_tabledata.clear();
    int noofentries = TOTAL_PARAMETERS_COUNT;
    int i = 0;
    while (i < noofentries) {
        std::string parametername = "Parameter";
        parametername += boost::lexical_cast<std::string> (i);
        ParameterData pdata;
        pdata.name = parametername;
        pdata.defaultvalue = 100;
        pdata.currentvalue = 99;
        pdata.updated = false;
        if ((i % 2) == 0) {
            pdata.readonly = true;
        } else {
            pdata.readonly = false;
        }
        m_tabledata.push_back(pdata);
        ++i;
    }
}

void IGSxGUI::MachineconstantsView::populateData(std::vector<ParameterData>::iterator it, int row)
{
    IGSxGUI::Util::setRowHeight(sui->tawParameters, row, ROW_HEIGHT);
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, (*it).name);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, boost::lexical_cast<std::string>((*it).currentvalue));
    if ((*it).readonly) {
        setUCTHandlers(widget, row, true);
        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
    } else {
        setUCTHandlers(widget, row, false);
        IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    }
    if ((*it).updated) {
        IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
    }
}

void IGSxGUI::MachineconstantsView::initializeTableRows(int rows, std::vector<ParameterData>& collection)
{
  if (rows <= 0) {
      sui->tawParameters->setVisible(false);
  } else {
      sui->tawParameters->showGrid(false);
      int noofrows = rows;
      if (rows > MAX_VISIBLE_ROWS) {
          noofrows = MAX_VISIBLE_ROWS;
          sui->scbParametersTable->setVisible(true);
          sui->scbParametersTable->setMinValue(0);
          sui->scbParametersTable->setMaxValue(rows - MAX_VISIBLE_ROWS);
      } else {
          sui->scbParametersTable->setVisible(false);
      }
      sui->tawParameters->removeRows(1, sui->tawParameters->rowCount() - 1 );
      for (int i = 0; i < noofrows - 1; ++i) {
          sui->tawParameters->appendRow();
      }
  }
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = MAX_VISIBLE_ROWS;
    }
    setData(0, rows, collection);
}
void IGSxGUI::MachineconstantsView::setData(int value, int rows, std::vector<ParameterData>& collection)
{
    std::vector<ParameterData>::iterator beg_it = collection.begin();
    std::vector<ParameterData>::iterator it = collection.end();
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
    }
}

void IGSxGUI::MachineconstantsView::setTableRows(int value, std::vector<ParameterData>& collection)
{
    int rows = collection.size();
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = MAX_VISIBLE_ROWS;
    }
    setData(value, rows, collection);
}


void IGSxGUI::MachineconstantsView::init()
{
    sui->lblParameterNameTooltip->setVisible(false);
    sui->lblParameterValueTooltip->setVisible(false);
    sui->lneSearchParameterText->setText("");
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);
    sui->btnSearchParameter->setVisible(true);
    sui->btnSearchClear->setVisible(false);
    sui->lblEntriesFound->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, 18);
    initializeTableRows(TOTAL_PARAMETERS_COUNT, m_tabledata);
    setHandlers();
}
void IGSxGUI::MachineconstantsView::onParameterNameHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, true);
    sui->lblParameterNameTooltip->setVisible(true);
}
void IGSxGUI::MachineconstantsView::onParameterNameHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterName, false);
    sui->lblParameterNameTooltip->setVisible(false);
}
void IGSxGUI::MachineconstantsView::onParameterValueHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, true);
    sui->lblParameterValueTooltip->setVisible(true);
}
void IGSxGUI::MachineconstantsView::onParameterValueHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnParameterValue, false);
    sui->lblParameterValueTooltip->setVisible(false);
}
void IGSxGUI::MachineconstantsView::onParamaterValueChanged(const std::string& name, const std::string& value)
{
    std::vector<ParameterData>::iterator it = findParameter(name);
    if (it != m_tabledata.end()) {
              int currentvalue = boost::lexical_cast<int>((*it).currentvalue);
              int newvalue = boost::lexical_cast<int>(value);
              if (newvalue != currentvalue) {
                  (*it).currentvalue = boost::lexical_cast<int>(value);
                  (*it).updated = true;
              }
           }
    if (TOTAL_PARAMETERS_COUNT > MAX_VISIBLE_ROWS) {
        setTableRows(sui->scbParametersTable->getValue(), m_tabledata);
    } else {
        setTableRows(0, m_tabledata);
    }
    m_parameterview.close();
}

void IGSxGUI::MachineconstantsView::onParameterRowPressed(int row)
{
    if (TOTAL_PARAMETERS_COUNT > MAX_VISIBLE_ROWS) {
        setTableRows(sui->scbParametersTable->getValue(), m_tabledata);
    } else {
        setTableRows(0, m_tabledata);
    }
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
    IGSxGUI::Util::processEvents();
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    boost::trim(name);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    boost::trim(value);
    std::vector<ParameterData>::iterator it = findParameter(name);
    if (it != m_tabledata.end()) {
        ParameterData temp = *it;
        m_parameterview.setParameterName(temp.name);
        m_parameterview.setParameterValue(boost::lexical_cast<std::string>(temp.currentvalue));
        m_parameterview.setParameterDefaultValue(boost::lexical_cast<std::string>(temp.defaultvalue));
        m_parameterview.setParent(sui->lneSearchParameterText);  // any widget can be passed
        m_parameterview.show();
    }
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverEntered(int row)
{
    int value = 0;
    if (TOTAL_PARAMETERS_COUNT > MAX_VISIBLE_ROWS) {
        value = sui->scbParametersTable->getValue();
    }
    setTableRows(value, m_tabledata);
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTHoverOnStyle(widget);
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverLeft(int row)
{
    int value = 0;
    if (TOTAL_PARAMETERS_COUNT > MAX_VISIBLE_ROWS) {
        value = sui->scbParametersTable->getValue();
    }
    setTableRows(value, m_tabledata);
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTHoverOffStyle(widget);
}

void IGSxGUI::MachineconstantsView::onSearchButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_BLUE_REGULAR, BUTTON_SIZE);
}


void IGSxGUI::MachineconstantsView::onSearchButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onSearchClearHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_BLUE_REGULAR, BUTTON_SIZE);
}


void IGSxGUI::MachineconstantsView::onSearchClearHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
}


void IGSxGUI::MachineconstantsView::onSearchTextEdited(const std::string &text)
{
    if (text.empty()) {
        sui->lblEntriesFound->setVisible(false);
        sui->btnSearchClear->setVisible(false);
        sui->btnSearchParameter->setVisible(true);
    } else {
        sui->btnSearchParameter->setVisible(false);
        sui->lblEntriesFound->setVisible(true);
        sui->btnSearchClear->setVisible(true);
        IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, 18);
        int entriesfound = searchForParameters(text);
        if (entriesfound == 1) {
            sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETER_FOUND);
        } else {
            sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND);
        }
    }
}
void IGSxGUI::MachineconstantsView::onSearchTextEditFinished()
{
    sui->btnSearchClear->setVisible(true);
}
void IGSxGUI::MachineconstantsView::onSearchClearPressed()
{
    sui->lneSearchParameterText->clearText();
    sui->lblEntriesFound->setVisible(false);
    sui->btnSearchParameter->setVisible(true);
    sui->btnSearchClear->setVisible(false);
}

int IGSxGUI::MachineconstantsView::searchForParameters(const std::string &textToSearch)
{
    int result = 0;
    m_matchedparameters.clear();
    if (!textToSearch.empty()) {
        std::vector<ParameterData>::const_iterator itr;
        int count = 0;
       std::vector<ParameterData>::const_iterator end_itr =  m_tabledata.end();
        for (itr = m_tabledata.begin(); itr != end_itr; ++itr) {
            std::string parametername = (*itr).name;
            if (boost::contains(parametername, textToSearch)) {
                ++count;
                m_matchedparameters.push_back(*itr);
            }
        }
        result = count;
    }
    initializeTableRows(result, m_matchedparameters);
    return result;
}
void IGSxGUI::MachineconstantsView::onValueChanged()
{
   if(sui->lneSearchParameterText->getText().empty()) {
    setTableRows(sui->scbParametersTable->getValue(), m_tabledata);
     } else {
       setTableRows(sui->scbParametersTable->getValue(), m_matchedparameters);
     }
}
std::vector<ParameterData>::iterator IGSxGUI::MachineconstantsView::findParameter(const std::string& parametername)
{
    std::vector<ParameterData>::iterator result = m_tabledata.end();
    if (!parametername.empty()) {
        result = std::find_if(m_tabledata.begin(), m_tabledata.end(), find_parameter(parametername));
    }
    return result;
}
