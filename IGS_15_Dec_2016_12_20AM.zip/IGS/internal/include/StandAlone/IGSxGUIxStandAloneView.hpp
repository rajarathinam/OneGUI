/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStandAloneView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Standalone View
|
| ! \file        IGSxGUIxStandAloneView.hpp
| ! \brief       Header file for Standalone View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSTANDALONEVIEW_HPP
#define IGSXGUIXSTANDALONEVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxStandAlonePresenter.hpp"
#include "IGSxGUIxIStandAloneView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class StandAloneView;
}  // namespace SUI

namespace IGSxGUI {
class StandAloneView: public IGSxGUI::IStandAloneView
{
 public:
    StandAloneView();
    virtual ~StandAloneView();
    void show(std::string strPluginName);
 private:
    SUI::StandAloneView *sui;
    IGSxGUI::StandAlonePresenter *m_presenter;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSTANDALONEVIEW_HPP
