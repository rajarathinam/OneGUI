/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboard.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin
|
| ! \file        IGSxGUIxDashboard.cpp
| ! \brief       Implementation of Dashboard plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDashboard.hpp"
#include "IGSxGUIxDashboardView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Dashboard::Dashboard():m_kpiManager(new KPIManager())
{
    m_kpiManager->initialize();
    m_dashboardView = new IGSxGUI::DashboardView(m_kpiManager);
}

IGSxGUI::Dashboard::~Dashboard()
{
    delete m_dashboardView;
    delete m_kpiManager;
}

void IGSxGUI::Dashboard::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_dashboardView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Dashboard::setActive(bool bActive)
{
    m_dashboardView->setActive(bActive);
}
