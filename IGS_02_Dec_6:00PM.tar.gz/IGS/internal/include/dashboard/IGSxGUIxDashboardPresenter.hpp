/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard Presenter
|
| ! \file        IGSxGUIxDashboardPresenter.hpp
| ! \brief       Header file for Dashboard Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDPRESENTER_HPP
#define IGSXGUIXDASHBOARDPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxKPI.hpp"
#include "IGSxGUIxKPIManager.hpp"

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class DashboardPresenter
{
 public:
    explicit DashboardPresenter(IGSxGUI::IDashboardView* view, KPIManager* pKPIManager);
    virtual ~DashboardPresenter();

    vector<KPI *> getKPIs();
    vector<KPIValueSet*> getKPIValueSets(string kpiName);

    void subscribeForEvents();
    void unsubscribeForEvents();

    vector<Consumable *> getConsumables();
    vector<ConsumableValueSet*> getConsumableValueSets(string consumableName);

 private:
    DashboardPresenter(const DashboardPresenter&);
    DashboardPresenter& operator=(const DashboardPresenter&);

    void onKPIDataUpdated(string kpiName, string valueSetName, vector<double> values);  //  KPI Manager to Presenter

    KPIManager* m_pKPIManager;
    IDashboardView *m_view;
    vector<boost::signals2::connection> m_connections;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDASHBOARDPRESENTER_HPP
