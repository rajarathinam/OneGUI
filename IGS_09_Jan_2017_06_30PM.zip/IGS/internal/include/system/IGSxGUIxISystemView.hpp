/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxISystemView.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface file for System plugin view
|
| ! \file        IGSxGUIxISystemView.hpp
| ! \brief       Interface file for System plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISYSTEMVIEW_HPP
#define IGSXGUIXISYSTEMVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxDriverManager.hpp"
#include "IGSxITS.hpp"
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

typedef boost::function<void (const std::string& eMsg, const std::string& timeStamp)> ErrStateChangedCallback;

class ISystemView
{
 public:
    ISystemView() {}
    virtual ~ISystemView() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
    virtual void showError() = 0;
    virtual void showErrors() = 0;
    virtual void updateSysFunction(const DriverState::DriverStateEnum& state, const std::string& strSysFunction, const int& nInitializedDriverCount, const int& nTerminatedDriverCount) = 0;
    virtual void updateDriver(const DriverState::DriverStateEnum& state, const std::string& strDriver) = 0;
    virtual void updateMainStatus(const SystemState::SystemStateEnum& state) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXISYSTEMVIEW_HPP
