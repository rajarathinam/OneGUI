/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenter.cpp
| Author       : Raja A
| Description  : Implementation of ADT Presenter
|
| ! \file        IGSxGUIxADTPresenter.cpp
| ! \brief       Implementation of ADT Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTPresenter.hpp"
#include <string>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::ADTPresenter::ADTPresenter(IGSxGUI::IADTView* view, ADTManager* pADTManager):
    m_pADTManager(pADTManager),
    m_view(view)
{
}
IGSxGUI::ADTPresenter::~ADTPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTPresenter::getADTs() const
{
    std::vector<IGSxGUI::ADT *> adts;
    if (m_pADTManager != NULL)
    {
        adts = m_pADTManager->retrieveAll();
    }
    return adts;
}

bool IGSxGUI::ADTPresenter::startADT(const std::string &adtName) const
{
    IGSxGUI::ADT* adt = m_pADTManager->getADT(adtName);

    if (adt != NULL)
    {
        return adt->start();
    }
    return false;
}


