/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.cpp
| ! \brief       Implementation of KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int IGSxGUI::KPIValueSet::TOTAL_LIMITING_MINUTES = 360;

IGSxGUI::KPIValueSet::KPIValueSet(const IGSxKPI::KPIValueSetDefinition &kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description()),
    m_unit(kpiDefinition.unit())
{
    m_cbKPITimeValue.set_capacity(TOTAL_LIMITING_MINUTES);

    for (int index = 0; index < TOTAL_LIMITING_MINUTES; ++index)
    {
        KPITimeValue kpiTimeValue;

        kpiTimeValue.kpiTime = 0;
        kpiTimeValue.kpiValue = 0.0;

        m_cbKPITimeValue.push_back(kpiTimeValue);
    }
}

IGSxGUI::KPIValueSet::~KPIValueSet()
{
}

string IGSxGUI::KPIValueSet::getName() const
{
    return m_name;
}

string IGSxGUI::KPIValueSet::getDescription() const
{
    return m_desc;
}

string IGSxGUI::KPIValueSet::getUnit() const
{
    return m_unit;
}

void IGSxGUI::KPIValueSet::addValue(const time_t &time, const vector<double>* valueList)
{
    KPITimeValue kpiTimeValue;

    kpiTimeValue.kpiTime = time;

    if (valueList->size() > 0)
    {
        kpiTimeValue.kpiValue = valueList->at(0);
    }

    m_cbKPITimeValue.push_back(kpiTimeValue);
}

boost::circular_buffer<IGSxGUI::KPITimeValue> IGSxGUI::KPIValueSet::getValue() const
{
    return m_cbKPITimeValue;
}
