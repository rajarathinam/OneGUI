/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard Presenter
|
| ! \file        IGSxGUIxDashboardPresenter.cpp
| ! \brief       Implementation of Dashboard Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxDashboardPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const string IGSxGUI::DashboardPresenter::STRING_KPI = "KPI";
const string IGSxGUI::DashboardPresenter::STRING_SYSTEMKPI = "System";
const string IGSxGUI::DashboardPresenter::STRING_CONSUMABLE = "Consumable";

IGSxGUI::DashboardPresenter::DashboardPresenter(IGSxGUI::IDashboardView* view, KPIManager *pKPIManager):
    m_pKPIManager(pKPIManager),
    m_view(view)
{
}

IGSxGUI::DashboardPresenter::~DashboardPresenter()
{
    // Do not delete m_view or kpimanager, we are not the owner.
    m_KPIConnections.clear();
    m_SystemKPIConnections.clear();
    m_ConsumableConnections.clear();
}

void IGSxGUI::DashboardPresenter::subscribeForEvents()
{
    vector<IGSxGUI::KPI*> kpis = m_pKPIManager->getKPIs();

    for (size_t i = 0; i < kpis.size(); ++i)
    {
        boost::signals2::connection connection = kpis[i]->registerForValueChanged(boost::bind(&DashboardPresenter::onKPIDataUpdated, this, _1, _2, _3));
        m_KPIConnections.push_back(connection);
    }

    vector<IGSxGUI::KPI*> systemkpis = m_pKPIManager->getSystemKPIs();

    for (size_t i = 0; i < systemkpis.size(); ++i)
    {
        boost::signals2::connection connection = systemkpis[i]->registerForValueChanged(boost::bind(&DashboardPresenter::onKPIDataUpdated, this, _1, _2, _3));
        m_SystemKPIConnections.push_back(connection);
    }

    vector<IGSxGUI::KPI*> consumables = m_pKPIManager->getConsumables();

    for (size_t i = 0; i < consumables.size(); ++i)
    {
        boost::signals2::connection connection = consumables[i]->registerForValueChanged(boost::bind(&DashboardPresenter::onKPIDataUpdated, this, _1, _2, _3));
        m_ConsumableConnections.push_back(connection);
    }
}

void IGSxGUI::DashboardPresenter::unsubscribeForEvents()
{
    for (size_t i = 0; i < m_KPIConnections.size(); ++i)
    {
        m_KPIConnections.at(i).disconnect();
    }
    for (size_t i = 0; i < m_SystemKPIConnections.size(); ++i)
    {
        m_SystemKPIConnections.at(i).disconnect();
    }
    for (size_t i = 0; i < m_ConsumableConnections.size(); ++i)
    {
        m_ConsumableConnections.at(i).disconnect();
    }
    m_KPIConnections.clear();
    m_SystemKPIConnections.clear();
    m_ConsumableConnections.clear();
}

vector<IGSxGUI::KPI*> IGSxGUI::DashboardPresenter::getKPIs() const
{
    return m_pKPIManager->getKPIs();
}

vector<IGSxGUI::KPI *> IGSxGUI::DashboardPresenter::getSystemKPIs() const
{
    return m_pKPIManager->getSystemKPIs();
}

vector<IGSxGUI::KPI *> IGSxGUI::DashboardPresenter::getConsumables() const
{
    return m_pKPIManager->getConsumables();
}
IGSxGUI::KPI* IGSxGUI::DashboardPresenter::getKPI(const std::string &kpiName) const
{
    return  m_pKPIManager->getKPI(kpiName);
}
IGSxGUI::KPI* IGSxGUI::DashboardPresenter::getSystemKPI(const std::string &kpiName) const
{
    return  m_pKPIManager->getSystemKPI(kpiName);
}
IGSxGUI::KPI* IGSxGUI::DashboardPresenter::getConsumable(const std::string &kpiName) const
{
    return  m_pKPIManager->getConsumable(kpiName);
}
vector<IGSxGUI::KPIValueSet *> IGSxGUI::DashboardPresenter::getKPIValueSets(const std::string &kpiName) const
{
    vector<IGSxGUI::KPIValueSet *> valueSets;
    KPI* kpi = m_pKPIManager->getKPI(kpiName);

    if (kpi != NULL)
    {
        valueSets = kpi->getValueSets();
    }

    return valueSets;
}

vector<IGSxGUI::KPIValueSet *> IGSxGUI::DashboardPresenter::getSystemKPIValueSets(const std::string &kpiName) const
{
    vector<IGSxGUI::KPIValueSet *> valueSets;
    KPI* kpi = m_pKPIManager->getSystemKPI(kpiName);

    if (kpi != NULL)
    {
        valueSets = kpi->getValueSets();
    }

    return valueSets;
}

vector<IGSxGUI::KPIValueSet *> IGSxGUI::DashboardPresenter::getConsumableValueSets(const std::string &kpiName) const
{
    vector<IGSxGUI::KPIValueSet *> valueSets;
    KPI* kpi = m_pKPIManager->getConsumable(kpiName);

    if (kpi != NULL)
    {
        valueSets = kpi->getValueSets();
    }

    return valueSets;
}

void IGSxGUI::DashboardPresenter::onKPIDataUpdated(const std::string& kpiName, const std::string& type, const std::string& valueSetName)
{
    if (type == STRING_KPI)
    {
        KPI* kpi = m_pKPIManager->getKPI(kpiName);

        if (kpi != NULL)
        {
            m_view->updateKPI(kpiName, kpi->getDisplayName(), kpi->getFactor(), valueSetName);
        }
    } else if (type == STRING_SYSTEMKPI) {
        KPI* systemkpi = m_pKPIManager->getSystemKPI(kpiName);

        if (systemkpi != NULL)
        {
            m_view->updateSystemKPI(kpiName, systemkpi->getFactor());
        }
    } else if (type == STRING_CONSUMABLE) {
        KPI* consumable = m_pKPIManager->getConsumable(kpiName);

        if (consumable != NULL)
        {
            m_view->updateConsumable(kpiName, consumable->getDisplayName(), consumable->getFactor(), consumable->getMin(), consumable->getMax());
        }
    }
}
