/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard View
|
| ! \file        IGSxGUIxDashboardView.hpp
| ! \brief       Header file for Dashboard View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDVIEW_HPP
#define IGSXGUIXDASHBOARDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/circular_buffer.hpp>
#include <boost/date_time.hpp>
#include <utility>
#include <string>
#include <vector>
#include <map>
#include <list>
#include "IGSxGUIxDashboardPresenter.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include <SUIProgressBar.h>
#include <SUIPlotHistogramItem.h>
#include <SUILabel.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class DashboardView;
class UserControl;
class GroupBox;
class Timer;
}

namespace IGSxGUI {
class DashboardView : public IDashboardView
{
 public:
    explicit DashboardView(KPIManager* pKpiManager);
    virtual ~DashboardView();

    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool bActive);

    virtual void updateKPI(const string& kpiName);
    virtual void updateSystemKPI(const string& systemKPIName);
    virtual void updateConsumable(const string& consumableName);

    void buildHistogramGraphs();
    void buildHistogramGraph(const std::string& name, SUI::PlotWidget* plot, IGSxGUI::KPI* kpi, SUI::Label* lblName, SUI::Label* lblValueName, SUI::Label* lblDisplayName, SUI::Label* lblValue, const boost::circular_buffer<double> &buffer);
    void buildKPITable();
    void buildConsumableTable();
    void init();
    void setHandlers();

    void onUCTNormalKPI1_T1HoverOn();
    void onUCTNormalKPI1_T1HoverOff();

    void onUCTNormalKPI2_T1HoverOn();
    void onUCTNormalKPI2_T1HoverOff();

    void onUCTNormalKPI3_T1HoverOn();
    void onUCTNormalKPI3_T1HoverOff();

    void onUCTNormalKPI4_T1HoverOn();
    void onUCTNormalKPI4_T1HoverOff();

    void onUCTNormalKPI5_T1HoverOn();
    void onUCTNormalKPI5_T1HoverOff();

    void onUCTNormalKPI6_T1HoverOn();
    void onUCTNormalKPI6_T1HoverOff();

    void onUCTNormalKPI7_T1HoverOn();
    void onUCTNormalKPI7_T1HoverOff();

    void onUCTNormalKPI8_T1HoverOn();
    void onUCTNormalKPI8_T1HoverOff();

    void onUCTNormalKPI9_T1HoverOn();
    void onUCTNormalKPI9_T1HoverOff();

    void onUCTNormalKPI10_T1HoverOn();
    void onUCTNormalKPI10_T1HoverOff();

    void onUCTNormalKPI1_T2HoverOn();
    void onUCTNormalKPI1_T2HoverOff();

    void onUCTNormalKPI2_T2HoverOn();
    void onUCTNormalKPI2_T2HoverOff();

    void onUCTNormalKPI3_T2HoverOn();
    void onUCTNormalKPI3_T2HoverOff();

    void onUCTNormalKPI4_T2HoverOn();
    void onUCTNormalKPI4_T2HoverOff();

    void onUCTNormalKPI5_T2HoverOn();
    void onUCTNormalKPI5_T2HoverOff();

    void onUCTNormalKPI6_T2HoverOn();
    void onUCTNormalKPI6_T2HoverOff();

    void onUCTNormalKPI7_T2HoverOn();
    void onUCTNormalKPI7_T2HoverOff();

    void onUCTNormalKPI8_T2HoverOn();
    void onUCTNormalKPI8_T2HoverOff();

    void onUCTNormalKPI9_T2HoverOn();
    void onUCTNormalKPI9_T2HoverOff();

    void onUCTNormalKPI10_T2HoverOn();
    void onUCTNormalKPI10_T2HoverOff();

    void onConsumable1HoverOn();
    void onConsumable1HoverOff();
    void onConsumable2HoverOn();
    void onConsumable2HoverOff();
    void onConsumable3HoverOn();
    void onConsumable3HoverOff();
    void onConsumable4HoverOn();
    void onConsumable4HoverOff();
    void onConsumable5HoverOn();
    void onConsumable5HoverOff();
    void onConsumable6HoverOn();
    void onConsumable6HoverOff();
    void onConsumable7HoverOn();
    void onConsumable7HoverOff();
    void onConsumable8HoverOn();
    void onConsumable8HoverOff();
    void onConsumable9HoverOn();
    void onConsumable9HoverOff();
    void onConsumable10HoverOn();
    void onConsumable10HoverOff();

    void loadContainers();

    void setNormalKPIUCTHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;
    void setNormalKPIUCTHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;

    void setConsumableHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;
    void setConsumableHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;

    const std::string currentDateTime(const std::string &dateTime) const;
    const std::string convertTimeToString(const time_t &time) const;
    int getTimeDifferenceInMinutes(const time_t &time1, const time_t &time2) const;

    void setSystemKPIUCTHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;
    void setSystemKPIUCTHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit) const;
    void restoreDashboard();
    void onTimeout();
    void onSliderValueChanged();
    void showHistograms();
    void showHistogramsForValue(const std::string& strSystemKPIName, const time_t& value);
    void addSliderTimes() const;
    void updatePlotXAxisTime(std::list<double> &time_list, const boost::posix_time::ptime& time);
 private:
    DashboardView(const DashboardView&);
    DashboardView& operator=(const DashboardView&);

    SUI::DashboardView *sui;
    DashboardPresenter *m_presenter;
    std::vector<KPI*> m_listKPIs;
    std::vector<KPI*> m_listSystemKPIs;
    std::map<std::string, std::vector<SUI::PlotIntervalSample> > plotsamples;
    std::map<std::string, SUI::PlotHistogramItem *> m_mapKPIHistogram;
    std::map<std::string, SUI::PlotWidget *> m_mapKPIPlots;
    std::map<std::string, std::vector<double> > kpihistogramValues;
    std::map<std::string, double> m_mapKPIMinValue;
    std::map<std::string, double> m_mapKPIMaxValue;
    std::map<std::string, SUI::Label*> m_mapKPIGraphValueLabel;
    std::map<std::string, boost::circular_buffer<double> > m_circularBufferToDraw;
    boost::circular_buffer<double> m_circularBuffer1;
    boost::circular_buffer<double> m_circularBuffer2;
    boost::circular_buffer<double> m_circularBuffer3;
    boost::circular_buffer<double> m_circularBuffer4;
    boost::circular_buffer<double> m_circularBuffer5;
    std::map<std::string, boost::circular_buffer<double> > m_mapKPICircBuffPlotItemValues;

    // Noraml KPI Table 1 containers
    std::vector<SUI::UserControl*> m_listNormalKPIUCTs_T1;
    std::vector<SUI::GroupBox*> m_listNormalKPIGroupBoxes_T1;
    std::vector<SUI::Label*> m_listNormalKPINames_T1;
    std::vector<SUI::Label*> m_listTimeKPIUpdated_T1;
    std::vector<SUI::Label*> m_listTimeKPILastUpdated_T1;
    std::vector<SUI::Label*> m_listNormalKPIValues_T1;
    std::vector<SUI::Label*> m_listNormalKPIUnits_T1;

    // Noraml KPI Table 2 containers
    std::vector<SUI::UserControl*> m_listNormalKPIUCTs_T2;
    std::vector<SUI::GroupBox*> m_listNormalKPIGroupBoxes_T2;
    std::vector<SUI::Label*> m_listNormalKPINames_T2;
    std::vector<SUI::Label*> m_listTimeKPIUpdated_T2;
    std::vector<SUI::Label*> m_listTimeKPILastUpdated_T2;
    std::vector<SUI::Label*> m_listNormalKPIValues_T2;
    std::vector<SUI::Label*> m_listNormalKPIUnits_T2;

    // Consumables
    std::vector<SUI::UserControl*> m_listConsumableUCTs;
    std::vector<SUI::GroupBox*> m_listConsumableGroupBoxes;
    std::vector<SUI::Label*> m_listConsumableNames;
    std::vector<SUI::Label*> m_listConsumableCategories;
    std::vector<SUI::Label*> m_listConsumableTimes;
    std::vector<SUI::Label*> m_listConsumableValues;
    std::vector<SUI::Label*> m_listConsumableUnits;
    std::vector<SUI::ProgressBar*> m_listConsumableProgressbars;

    // System KPI
    std::vector<SUI::UserControl*> m_listSystemKPIUCTs;
    std::vector<SUI::GroupBox*> m_listSystemKPIGroupBoxes;
    std::vector<SUI::PlotWidget*> m_listSystemKPIGraphs;
    std::vector<SUI::Label*> m_listSystemKPIGraphNames;
    std::vector<SUI::Label*> m_listSystemKPIGraphValueSetNames;
    std::vector<SUI::Label*> m_listSystemKPIGraphUnits;
    std::vector<SUI::Label*> m_listSystemKPIGraphValues;
    std::vector<boost::circular_buffer<double> > m_listCircularBuffers;

    static const std::string LOAD_FILE_DASHBOARD;
    static const std::string STRING_EMPTY;
    static const std::string STRING_SINGLE_SPACE;
    static const std::string STRING_TIME;
    static const std::string STRING_ZERO;
    static const std::string STRING_SEPERATOR;
    static const int NO_OF_PLOTITEM_VALUES;
    static const int NO_OF_MAJOR_TICKS;
    static const int NO_OF_MINOR_TICKS;
    static const int TIMER_INTERVAL;
    static const int HISTOGRAM_BAR_START_VALUE;
    static const int HISTOGRAM_BAR_END_VALUE;
    static const int HISTOGRAM_BAR_SEPARATOR;
    static const int SCROLLBAR_MAX_VALUE;
    static const int FIRST_MINUTE;
    static const int SECOND_MINUTE;
    static const int THIRD_MINUTE;
    static const int FOURTH_MINUTE;
    static const int FIFTH_MINUTE;
    static const int SIXTH_MINUTE;

    static const std::string STRING_HISTOGRAM_NAME1;
    static const std::string STRING_HISTOGRAM_NAME2;
    static const std::string STRING_HISTOGRAM_NAME3;
    static const std::string STRING_HISTOGRAM_NAME4;
    static const std::string STRING_HISTOGRAM_NAME5;
    static std::vector<std::string> STRING_HISTOGRAM_NAMES;

    static const std::string STRING_DATETIME_FORMAT1;
    static const std::string STRING_DATETIME_FORMAT2;
    static const std::string STRING_MINUTE_AGO;
    static const std::string STRING_MINUTES_AGO;
    static const int SECONDS_PER_MINUTE;
    static const int SECONDS_PER_HOUR;
    static const int SECONDS_FOR_FIVE_MINUTES;
    static const int COLOR_RED;
    static const int COLOR_GREEN;
    static const int COLOR_BLUE;
    static const int CONVERSION_BUFFER_SIZE;

    static const std::string STYLE_UCT_NORMAL_KPI_HOVER_ON;
    static const std::string STYLE_UCT_NORMAL_KPI_HOVER_OFF;
    static const std::string STYLE_UCT_SYSTEM_KPI_HOVER_ON;
    static const std::string STYLE_UCT_SYSTEM_KPI_HOVER_OFF;
    static const std::string STYLE_UCT_CONSUMABLE_KPI_HOVER_ON;
    static const std::string STYLE_UCT_CONSUMABLE_KPI_HOVER_OFF;
    static const std::string STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT;
    static const std::string STYLE_UCT_NORMAL_KPI_PLAIN_TEXT;
    static const std::string STYLE_UCT_SYSTEM_KPI_CATEGORY_GRAY_TEXT;
    static const std::string STYLE_UCT_SYSTEM_KPI_PLAIN_TEXT;
    static const std::string STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT;
    static const std::string STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT;

    int m_slider_value_backup;
    bool m_slider_move_past_values;
    boost::shared_ptr<SUI::Timer> m_timer;
    bool m_xaxis_update_enabled;
    int64_t m_xaxisstartvalue;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXDASHBOARDVIEW_HPP
