/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManagerTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver Manager test
|
| ! \file        IGSxGUIxDriverManagerTest.hpp
| ! \brief       Header file for Driver Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVERMANAGERTEST_HPP
#define IGSXGUIXDRIVERMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxDriverManager.hpp"

using std::vector;
using std::list;
using IGSxITS::MetaDescriptions;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SystemDriverManagerTest : public ::testing::Test
{
 public:
    SystemDriverManagerTest(){}
    virtual ~SystemDriverManagerTest(){}
 protected:
    MetaDescriptions Drivers;
    MetaDescriptions Sysfunctions;
 protected:
  virtual void SetUp()
  {
        Drivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
        Drivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
        Drivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
        Drivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
        Drivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));

        Sysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class SystemDriverManagerTestParam : public ::testing::TestWithParam<std::string>
{
 public:
    SystemDriverManagerTestParam(){}
    virtual ~SystemDriverManagerTestParam(){}
 protected:
    MetaDescriptions Drivers;
    MetaDescriptions Sysfunctions;
 protected:
  virtual void SetUp()
  {
        Drivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
        Drivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
        Drivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
        Drivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
        Drivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));

        Sysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
        Sysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXDRIVERMANAGERTEST_HPP
