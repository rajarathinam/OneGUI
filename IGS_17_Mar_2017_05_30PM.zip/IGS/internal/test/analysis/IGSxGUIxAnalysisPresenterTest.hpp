#ifndef IGSXGUIXANALYSISPRESENTERTEST_H
#define IGSXGUIXANALYSISPRESENTERTEST_H
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxAnalysisPresenter.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class AnalysisPresenterTest : public ::testing::Test
{
 public:
  AnalysisPresenterTest(){}
  virtual ~AnalysisPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif // IGSXGUIXANALYSISPRESENTERTEST_H
