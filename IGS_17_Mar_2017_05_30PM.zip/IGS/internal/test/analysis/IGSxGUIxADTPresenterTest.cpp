/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of ADT Presenter test
|
| ! \file        IGSxGUIxADTPresenterTest.cpp
| ! \brief       Implementation of ADT Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxADTPresenterTest.hpp"
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

TEST_F(ADTPresenterTest, Test1)
{
    IGSxGUI::ADTManager* pADTManager = new IGSxGUI::ADTManager;
    pADTManager->initialize();
    IGSxGUI::IADTView* ADTview = new IGSxGUI::ADTView(pADTManager);
    IGSxGUI::ADTPresenter* ADTpresenter = new IGSxGUI::ADTPresenter(ADTview, pADTManager);

    std::vector<IGSxGUI::ADT*> adts = ADTpresenter->getADTs();
    EXPECT_EQ(adts.size(), 12);

    std::string adtname = "OneGUI";
    EXPECT_FALSE(ADTpresenter->startADT(adtname));

    ASSERT_TRUE(ADTpresenter->startADT(adts[0]->getName()));

    std::string empty_adtname = "";
    EXPECT_FALSE(ADTpresenter->startADT(empty_adtname));

    EXPECT_EQ(adts.size(), 12);

    if (ADTpresenter != NULL)
    {
        delete ADTpresenter;
        ADTpresenter = NULL;
    }
    if (ADTview != NULL)
    {
        delete ADTview;
        ADTview = NULL;
    }
    if (pADTManager != NULL)
    {
        delete pADTManager;
        pADTManager = NULL;
    }
}
