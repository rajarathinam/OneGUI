/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of Analysis Presenter test
|
| ! \file        IGSxGUIxAnalysisPresenterTest.cpp
| ! \brief       Implementation of Analysis Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxAnalysisPresenterTest.hpp"
#include "IGSxGUIxAnalysisView.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

TEST_F(AnalysisPresenterTest, Test1) {
    IGSxGUI::ADTManager* pADTManager = new IGSxGUI::ADTManager;
    pADTManager->initialize();

    IGSxGUI::AnalysisView* p_analysisview = new IGSxGUI::AnalysisView(pADTManager);
    IGSxGUI::AnalysisPresenter* p_analysisPresenter = new IGSxGUI::AnalysisPresenter(p_analysisview, pADTManager);

    std::vector<IGSxGUI::ADT*> adts = p_analysisPresenter->getADTs();
    EXPECT_EQ(adts.size(), 12);

    std::string adtname = "OneGUI";
    EXPECT_FALSE(p_analysisPresenter->startADT(adtname));

    EXPECT_TRUE(p_analysisPresenter->startADT(adts[0]->getName()));

    std::string empty_adtname = "";
    EXPECT_FALSE(p_analysisPresenter->startADT(empty_adtname));

    if (p_analysisPresenter != NULL) {
        delete p_analysisPresenter;
        p_analysisPresenter = NULL;
    }
    if (p_analysisview != NULL) {
        delete p_analysisview;
        p_analysisview = NULL;
    }
}

TEST_F(AnalysisPresenterTest, Test2) {
    IGSxGUI::ADTManager* pADTManager = NULL;

    IGSxGUI::AnalysisView* p_analysisview = new IGSxGUI::AnalysisView(pADTManager);
    IGSxGUI::AnalysisPresenter* p_analysisPresenter = new IGSxGUI::AnalysisPresenter(p_analysisview, pADTManager);

    std::vector<IGSxGUI::ADT*> adts = p_analysisPresenter->getADTs();
    EXPECT_EQ(adts.size(), 0);

}
