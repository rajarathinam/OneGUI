/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriver.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver
|
| ! \file        IGSxGUIxDriver.hpp
| ! \brief       Header file for Driver
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVER_HPP
#define IGSXGUIXDRIVER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2.hpp>
#include <string>
#include "IGSxITS.hpp"

using IGSxITS::MetaDescription;
using IGSxITS::DriverState;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class Driver
{
 public:
    Driver(const MetaDescription& metaDescription, const DriverState::DriverStateEnum& driverState);
    virtual ~Driver();

    void updateDriverState(const DriverState::DriverStateEnum& driverState);
    DriverState::DriverStateEnum getState() const;
    std::string getName() const;
    std::string getDisplayName() const;
    bool isImplemented() const;
    typedef boost::signals2::signal<void(DriverState::DriverStateEnum, std::string)> stateDriverChanged;
    typedef stateDriverChanged::slot_type stateDriverChangedCallback;

    boost::signals2::connection registerToDriverStateChanged(const stateDriverChangedCallback& cb);

 private:
    std::string m_name;
    std::string m_displayName;
    DriverState::DriverStateEnum m_driverState;

    stateDriverChanged m_stateChanged;
    bool m_isImplemented;
    static const char* NOT_IMPLEMENTED_TAG;
    static const char* STRING_NEW_DRIVER_STATE;
};

struct compareDriver
{
    bool operator()(const IGSxGUI::Driver* lhs, const IGSxGUI::Driver* rhs) const
    {
        return lhs->getDisplayName() < rhs->getDisplayName();
    }
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDRIVER_HPP
