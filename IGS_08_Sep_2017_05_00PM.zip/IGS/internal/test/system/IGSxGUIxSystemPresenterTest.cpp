/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenterTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Presenter test
|
| ! \file        IGSxGUIxSystemPresenterTest.cpp
| ! \brief       Implementation of System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxSystemPresenterTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(SystemPresenterTest, Test1)
{
    SystemViewStub* stubView = new SystemViewStub();
    ASSERT_TRUE(stubView != NULL);

    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();
    ASSERT_TRUE(drvMgr != NULL);

    IGSxGUI::SystemPresenter* presenter = new IGSxGUI::SystemPresenter(stubView, drvMgr);
    ASSERT_TRUE(presenter != NULL);

    drvMgr->addSystemFunctions(m_sysfunctions);

    IGSxGUI::SystemFunction* sysFunc = drvMgr->getSystemFunction("SF-04");

    for (size_t i = 0; i < m_drivers.size(); i++)
    {
        sysFunc->addDriver(m_drivers[i], DriverState::DS_RECOVERY_REQUIRED);
    }

    std::vector<IGSxGUI::SystemFunction*> sysfuns = presenter->getSystemFunctions();
    EXPECT_EQ(6, sysfuns.size());

    vector<IGSxGUI::Driver*> drv = presenter->getDrivers("SF-04");
    EXPECT_EQ(5, drv.size());

    vector<IGSxGUI::Driver*> drv1 = presenter->getDrivers("UNKNOWN");
    EXPECT_EQ(0, drv1.size());

    IGSxGUI::SystemFunction* sysfun = sysfuns[0];
    ASSERT_TRUE(sysfun != NULL);

    sysfun->updateDriverState("SSD HPRGA", IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(1, presenter->getInitializedDriverCount());

    sysfun->updateDriverState("SFC Environmental Mgt", IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(2, presenter->getInitializedDriverCount());

    sysfun->updateDriverState("SSD Gas and Vacuum", IGSxITS::DriverState::DS_INITIALIZED);
    EXPECT_EQ(3, presenter->getInitializedDriverCount());

    drvMgr->setSystemState(IGSxGUI::SystemState::SS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZED, presenter->getSystemState());

    ASSERT_TRUE(presenter != NULL);
    delete presenter;
    presenter = NULL;

    ASSERT_TRUE(drvMgr != NULL);
    delete drvMgr;
    drvMgr = NULL;

    ASSERT_TRUE(stubView != NULL);
    delete stubView;
    stubView = NULL;
}
