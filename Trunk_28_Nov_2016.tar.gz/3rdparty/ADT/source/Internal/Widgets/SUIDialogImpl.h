//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DialogImpl.
// !\description Header file for class SUI::DialogImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDIALOGIMPL_H
#define SUIDIALOGIMPL_H

#include <QDialog>

#include "SUIDialog.h"
#include "SUIQUiLoader.h"
#include "SUIObjectList.h"
#include "SUIGraphicsView.h"

class GUIViewerWidgetController;

namespace SUI {
class DialogImpl : public QDialog, public Dialog
{
    Q_OBJECT

private:
    /*!
     \brief The constructor of the viewer dialog

     \fn Dialog
     \param parent - The parent widget
     \param uiFilename - The filename to load
     \exception XmlException - Will be thrown when the xml has a XML error.\n Will be rethrown from GuiSerializer::openFile
     \exception IOException - Will be thrown when the file doesn't exist.\n
     And if the file isn't writeable or readable.\n
     When the file isn't writeable or readable the exception will be rethrown from GuiSerializer::acceptVisitor
     \exception ArgumentException - Will be thrown when the argument is ""
     */
    explicit DialogImpl(const QString &uiFilename, const QString &uiID = "0", QWidget *parent = NULL);
    friend class UILoader;
    
public:
    virtual SUI::ObjectList *getObjectList();
    void contextMenu(const std::string &widgetID, const std::string &menuOption);
    QList<QString> getChange() const;
    void registerChangedWidget(const std::string &value);
    virtual void close();
    virtual void show();
    virtual void quit();

    virtual void setWindowTitle(const std::string &windowName);
    virtual std::string getWindowTitle() const;
    virtual std::string getFileName() const;

    QList<SUI::Dialog *> getPopupScreens() const;

    virtual void setEnabled(bool enabled);
    virtual bool isEnabled() const;

    virtual void setVisible(bool visible);
    virtual bool isVisible() const;

    virtual void setFocus();
    virtual void clearFocus();
    virtual bool hasFocus() const;
    
    virtual void setModal(bool modal);

    void setId(const std::string &id);
    virtual std::string getId() const;
    
    virtual void setContextMenuItems(const std::list<std::string> &items);
    virtual std::list<std::string> getContextMenuItems() const;

    virtual void setToolTip(const std::string &toolTip);

protected:
    virtual void keyPressEvent(QKeyEvent *event);
    virtual bool eventFilter(QObject *obj, QEvent *event);
    virtual void closeEvent(QCloseEvent *event);

private:
    QString mID;
    QString mFileName;
    SUI::ObjectList mObjectList;
    SUI::ObjectList mUserControlList;

    QList<GUIViewerWidgetController *> mUCtrlList;
    TabOrder mTabOrder;
    int mCurrentTabOrder;

    QMap<QString, SUI::Dialog *> mDialogMap;
    QList<QWidget *> order;
    int curTab;

    SUI_DEPRECATED void addMessagebox();
    SUI_DEPRECATED void addfileBrowser();

signals:
    void sendClosed(QString definitionfile);

private slots:
    void onClosed();
    void onChildClosed(QString id);
};
}

#endif // SUIDIALOGIMPL_H
