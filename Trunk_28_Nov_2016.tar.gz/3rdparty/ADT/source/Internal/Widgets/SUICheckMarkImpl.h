//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CheckMarkImpl.
// !\description Header file for class SUI::CheckMarkImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICHECKMARKIMPL_H
#define SUICHECKMARKIMPL_H

#include <QLabel>

#include "SUIBaseWidget.h"

#include "SUICheckMark.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The CheckMark class
 */
class SUI_DEPRECATED CheckMarkImpl : public BaseWidget, public CheckMark
{
    Q_OBJECT
public:
    explicit CheckMarkImpl(QWidget *parent = NULL);

    virtual QLabel *getWidget() const;
    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private:
    CheckMarkImpl(const CheckMarkImpl &rhs);
    CheckMarkImpl &operator=(const CheckMarkImpl &rhs);
};
}
#endif // SUICHECKMARKIMPL_H
