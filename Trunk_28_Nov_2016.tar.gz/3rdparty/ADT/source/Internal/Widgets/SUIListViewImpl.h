//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ListViewImpl.
// !\description Header file for class SUI::ListViewImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILISTVIEWIMPL_H
#define SUILISTVIEWIMPL_H

#include "SUIBaseWidget.h"
#include "SUIListView.h"

#include <QListWidget>

class QStringListModel;
class QItemSelectionModel;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ListView class
 */
class ListViewImpl: public BaseWidget, public ListView
{
    Q_OBJECT

public:
    enum SortOrder {NoSort, Descending, Ascending, Nat_Desc, Nat_Asc, Nat_Desc_Case, Nat_Asc_Case };

    explicit ListViewImpl(QWidget *parent = NULL);
    virtual ~ListViewImpl();

    virtual QListWidget *getWidget() const;

    virtual std::list<std::string> getItems() const;
    virtual void removeItems(const std::list<std::string> &itemlist);
    virtual void addItems(const std::list<std::string> &itemStdlist);
    virtual std::list<std::string> getSelectedItems() const;
    virtual void selectItem(const int row, const int col = 0);
    virtual void selectItem(const std::string idstr);
    virtual void clearItems();
    QString getAllColumnItems(int columnno = 0) const;
    virtual void setFilter(const std::string &filter, bool on, int columnNo = -1, bool casesensitive = true);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void initialize(const ObjectContext &context);

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    void setSortOrder(SortOrder sOrd = NoSort);

    static int NaturalDescending(const void *s1, const void *s2);
    static int NaturalAscending(const void *s1, const void *s2);
    static int NaturalDescendingCaseSensitive(const void *s1, const void *s2);
    static int NaturalAscendingCaseSensitive(const void *s1, const void *s2);

private slots:
    void handleClicked(QModelIndex &index);
    void handleSelected(const QItemSelection &sel, const QItemSelection &desel);
    void handleSelectionChanged();

private:
    QStringListModel *mItems;
    QStringListModel *mFilteredItems;
    QItemSelectionModel *mSelectionModel;
    QStringList mSelectedItems;
    SortOrder mSortOrder;
    QString mFilter;
    bool mCaseSensFilter;
    QList<QByteArray *> mByteArray; //convert to char*
    char **mStringList; //list to sort
    QStringList mNewList; //new list

    std::list<std::string> formatStdString(std::string inStr);
    void updateWidget();
    void applyFilter(QStringListModel *items);
    void removeAllItems();

    ListViewImpl(const ListViewImpl &rhs);
    ListViewImpl &operator=(const ListViewImpl &rhs);
};
}

#endif // SUILISTVIEWIMPL_H
