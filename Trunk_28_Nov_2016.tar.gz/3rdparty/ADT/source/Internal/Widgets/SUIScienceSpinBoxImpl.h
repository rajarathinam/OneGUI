﻿//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ScienceSpinBoxImpl.
// !\description Header file for class SUI::ScienceSpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUISCIENCESPINBOXIMPL_H
#define SUISCIENCESPINBOXIMPL_H

#include <QDoubleSpinBox>

#include "SUIScienceSpinBox.h"
#include "SUIBaseWidget.h"
#include "CustomScienceSpinBox.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ScienceSpinBox class
 */
class ScienceSpinBoxImpl : public BaseWidget, public ScienceSpinBox
{
    Q_OBJECT
public:
    explicit ScienceSpinBoxImpl(QWidget *parent = NULL);


    virtual void initialize(const ObjectContext &context);
    virtual CustomScienceSpinBox *getWidget() const;

    void setBold(bool bold);

    virtual void setValue(const double val);
    virtual double getValue() const;
    virtual void setMinValue(const double val);
    virtual double getMinValue() const;
    virtual void setMaxValue(const double val);
    virtual double getMaxValue() const;
    virtual void setStepSize(const double val);
    virtual double getStepSize() const;
    virtual void setStepSizeValueToFactor(const bool on);
    virtual void setPrecision(const int val);
    virtual int getPrecision() const;

    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;
    virtual void setMode(ErrorModeEnum::ErrorMode mode);
    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;

private slots:
    void handleValueChanged();

private:
    ScienceSpinBoxImpl(const ScienceSpinBoxImpl &rhs);
    ScienceSpinBoxImpl &operator = (const ScienceSpinBoxImpl &rhs);
};
}

#endif // SUISCIENCESPINBOXIMPL_H
