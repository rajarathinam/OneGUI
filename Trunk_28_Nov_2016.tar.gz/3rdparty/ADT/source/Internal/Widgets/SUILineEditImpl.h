//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LineEditImpl.
// !\description Header file for class SUI::LineEditImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILINEEDITIMPL_H
#define SUILINEEDITIMPL_H

#include "SUIBaseWidget.h"

#include "SUILineEdit.h"

#include <QLineEdit>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The LineEdit class
 */
class LineEditImpl: public BaseWidget, public LineEdit
{
    Q_OBJECT

public:
    explicit LineEditImpl(QWidget *parent = NULL);

    QString changeColor(QString color);
    QString changeColor(SUI::ColorEnum::Color aColor);

    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QLineEdit *getWidget() const;

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

    virtual SUI::ColorEnum::Color getBGColor() const;
    virtual void setBGColor(const SUI::ColorEnum::Color color);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;

    virtual void setMode(ErrorModeEnum::ErrorMode mode);
    virtual void setPlaceHolderText(const std::string &value);
    virtual std::string getPlaceHolderText() const;

private slots:
    void onEditingFinished();
    void onTextEdited(QString newText);
    void onTextChanged(QString newText);

private:
    AlignmentEnum::Alignment mAlign;

    LineEditImpl(const LineEditImpl &rhs);
    LineEditImpl &operator=(const LineEditImpl &rhs);
};
}

#endif // SUILINEEDITIMPL_H
