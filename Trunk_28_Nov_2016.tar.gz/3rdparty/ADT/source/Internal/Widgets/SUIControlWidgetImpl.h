//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ControlWidgetImpl.
// !\description Header file for class SUI::ControlWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUICONTROLWIDGETIMPL_H
#define SUICONTROLWIDGETIMPL_H

#include <QList>
#include <QPicture>
#include <QPixmap>
#include <QLabel>
#include <QString>
#include <QMap>
#include <QImage>
#include <QPoint>
#include <QMouseEvent>

#include "SUIBaseWidget.h"
#include "SUIControlProperties.h"
#include "SUIControlWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ControlWidget class
 */
class SUI_DEPRECATED ControlWidgetImpl : public BaseWidget , public ControlWidget, public ControlProperties
{
    Q_OBJECT

public:
    explicit ControlWidgetImpl(QWidget *parent = NULL);

    virtual QLabel *getWidget() const;
    virtual void initialize(const ObjectContext &context);

    virtual std::string getType() const;
    virtual void setType(const std::string &type);

    virtual std::string getState() const;
    virtual void setState(const std::string &state);
    virtual std::list<std::string> getSupportedStates() const;

    virtual void setPropertyValue(ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    void setImage();

private slots:
    void onCustomContextMenuRequest(QPoint point);

private:
    QString mState;
    QString mType;

    ControlWidgetImpl();
    ControlWidgetImpl(const ControlWidgetImpl &rhs);
    ControlWidgetImpl &operator=(const ControlWidgetImpl &rhs);
};
}

#endif // SUICONTROLWIDGETIMPL_H
