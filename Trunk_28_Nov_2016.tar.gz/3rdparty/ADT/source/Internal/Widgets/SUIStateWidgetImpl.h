//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::StateWidgetImpl.
// !\description Header file for class SUI::StateWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISTATEWIDGETIMPL_H
#define SUISTATEWIDGETIMPL_H

#include "SUIStateWidget.h"
#include "SUIBaseWidget.h"

#include <QLabel>

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The StateWidget class
 *
 * Note: use IWidgetImage if sizable requirements change
 */
class StateWidgetImpl : public BaseWidget, public StateWidget
{
    Q_OBJECT

public:
    explicit StateWidgetImpl(QWidget *parent = NULL);

    virtual QLabel *getWidget() const;
    virtual void initialize(const ObjectContext &context);

    virtual std::string getState() const;
    virtual void setState(const std::string &state);
    virtual std::list<std::string> getSupportedStates() const;
    virtual std::list<std::string> getStatesImages() const;

    void commitChangeState(QString aState);

    void addStates(std::list<std::string> aStates);
    void addImages(std::list<std::string> aImages);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual void setPropertyValues(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

private slots:
    void onCustomContextMenuRequest(QPoint point);

private:
    QString mState;
    QPixmap mImage;
    QStringList mStates;
    QStringList mImages;

    void setmImage(QString aState);

    StateWidgetImpl(const StateWidgetImpl &rhs);
    StateWidgetImpl &operator=(const StateWidgetImpl &rhs);
};
}

#endif // SUISTATEWIDGETIMPL_H
