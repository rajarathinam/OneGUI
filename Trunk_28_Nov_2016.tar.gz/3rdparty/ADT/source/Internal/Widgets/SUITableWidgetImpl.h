//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TableWidgetImpl.
// !\description Header file for class SUI::TableWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUITABLEWIDGETIMPL_H
#define SUITABLEWIDGETIMPL_H

#include "SUIBaseWidget.h"
#include "SUITableWidget.h"
#include "SUIAlignmentEnum.h"
#include "SUIDeprecated.h"
#include "SUIQUiLoader.h"
#include <QTableView>

class QStandardItem;

namespace SUI {

class ObjectList;
class TableWidgetItemImpl;

/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TableWidgetImpl class
 */
class TableWidgetImpl : public BaseWidget, public TableWidget
{
    Q_OBJECT
public:
    explicit TableWidgetImpl(QWidget *parent = NULL, SUI::ObjectList *objectList = NULL);
    virtual ~TableWidgetImpl();
    
    virtual void initialize(const ObjectContext &context);
    virtual QTableView *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void showGrid(const bool bShow);
    virtual void appendRow(const std::string &headertag = std::string(""));
    virtual void removeRow(int row);
    virtual std::string getCellID(int row, int column) const;
    virtual SUI::ObjectType::Type getCellType(int row, int column) const;
    virtual int rowCount() const;
    virtual int columnCount() const;

    virtual void setFilter(const std::string &filter, bool enabled, int column = -1, bool casesensitive = true);

    virtual void setListViewMode(bool on);
    virtual void addData(int row, const std::list<std::string> &data);

    virtual void clearItems();
    virtual std::list<std::string> getItems() const;
    virtual std::list<std::string> getSelectedItems() const;
    virtual void addItems(const std::list<std::string> &itemlist);
    virtual void removeItems(const std::list<std::string> &itemlist);
    virtual std::list<std::string> getColumnItems(int column) const;
    virtual std::list<std::string> getRowItems(int row) const;

    virtual void selectItem(int row, int col = 0);
    virtual void selectItem(const std::string idstr);

    virtual void insertRows(int pos, int count);
    virtual bool removeRows(int pos, int count);

    virtual void insertColumns(int position, int count);
    virtual bool removeColumns(int position, int count);

    void assign(int row, int column, Widget *widget);

    bool SUI_DEPRECATED startReading(int rowcnt, int columncnt);
    bool SUI_DEPRECATED stopReading();

    void SUI_DEPRECATED addNewTableWidgetItem(Widget *widget);

    virtual void setItemText(int row, int column, const std::string &text);
    virtual std::string getItemText(int row, int column) const;

    virtual Widget *getWidgetItemByName(const std::string &name) const;
    virtual void setWidgetItemName(int row, int column, const std::string &name);
    virtual void swapRows(int row1, int row2);
    QStringList setCellWidgetType(int row, int column, Widget *widget);
    void setCellBorderEnabled(int row, int column, bool borderOn) const;

    Widget *getWidgetItem(int row, int column) const;

    QString updateCell(int row, int col, SUI::AlignmentEnum::Alignment alignment, Widget *widget);

public slots:
    void updateTable();

private slots:
    void onSelectionChanged(QItemSelection, QItemSelection);
    void onHorizontalHeaderClicked(QModelIndex index);
    void onVerticalHeaderClicked(QModelIndex index);
    void onHeaderDataChanged();

signals:
    void dataChanged();

private:
    bool mInitDone;
    int mCurReadRowInd;
    int mCurReadColumnInd;

    ObjectList *mObjectList;
    TabOrder mTabOrder;

    QAbstractItemView::SelectionBehavior mPrevSelectionBehavior;
    QAbstractItemView::SelectionMode mPrevSelectionMode;

    void readHeaderTags();
    void removeHeaders();
    void copyRow(int start, int end);

    static QList<QStandardItem*> readHeaderTags(const QString &headerItems);
    static QStringList splitHeaders(const QString &headerItems);

    static QWidget *createIndexWidget(BaseWidget *baseWidget, int columnWidth, int rowHeight, AlignmentEnum::Alignment alignment);

    TableWidgetImpl(const TableWidgetImpl &rhs);
    TableWidgetImpl &operator=(const TableWidgetImpl &rhs);

};

}

#endif // SUITABLEWIDGETIMPL_H
