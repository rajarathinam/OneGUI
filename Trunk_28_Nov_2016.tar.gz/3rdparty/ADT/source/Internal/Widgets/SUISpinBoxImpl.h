//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SpinBoxImpl.
// !\description Header file for class SUI::SpinBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISPINBOXIMPL_H
#define SUISPINBOXIMPL_H

#include <QSpinBox>

#include "SUISpinBox.h"
#include "SUIBaseWidget.h"
#include "CustomSpinBox.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The SpinBox class
 */
class SpinBoxImpl : public BaseWidget, public SpinBox
{
    Q_OBJECT

public:
    explicit SpinBoxImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual CustomSpinBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const;

    virtual void setBold(bool bold);

    virtual void setValue(const int val);
    virtual int getValue() const;
    virtual void setMinValue(const int val);
    virtual int getMinValue() const;
    virtual void setMaxValue(const int val);
    virtual int getMaxValue() const;
    virtual void setStepSize(const int val);
    virtual int getStepSize() const;
    virtual void setStepSizeValueToFactor(const bool on);

    virtual void setMode(ErrorModeEnum::ErrorMode mode);

    virtual void setAlignment(AlignmentEnum::Alignment align);
    virtual SUI::AlignmentEnum::Alignment getAlignment() const;

private slots:
    void handleValueChanged();

private:
    SpinBoxImpl(const SpinBoxImpl &rhs);
    SpinBoxImpl &operator = (const SpinBoxImpl &rhs);
};
}

#endif // SUISPINBOXIMPL_H
