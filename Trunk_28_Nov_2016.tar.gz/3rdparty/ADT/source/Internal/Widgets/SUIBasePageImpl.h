//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::BasePageImpl.
// !\description Header file for class SUI::BasePageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBASEPAGEIMPL_H
#define SUIBASEPAGEIMPL_H

#include "SUIBaseWidget.h"

class QWidget;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The BasePage class
 */
class BasePageImpl : public BaseWidget
{
public:
    explicit BasePageImpl(QWidget *widget, ObjectType::Type objectType, bool childrenSupported);

    virtual void initialize(const ObjectContext &context);

    int addTabOrder(QString position, QString widgetId);

    int replaceTabOrderWidget(QString oldID, QString newID);

    void removeTabOrder(QString widgetId);

    QMap<int, QString> getTablist() const;

    int indexof(QString widgetId);

protected:
    QMap<int, QString> mTablist;

private:
    void insert(int position);
    void lineUp();

    BasePageImpl(const BasePageImpl &rhs);
    BasePageImpl &operator=(const BasePageImpl &rhs);

};
}

#endif // SUIBASEPAGEIMPL_H
