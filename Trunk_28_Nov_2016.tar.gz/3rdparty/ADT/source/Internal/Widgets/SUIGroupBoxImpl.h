//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::GroupBoxImpl.
// !\description Header file for class SUI::GroupBoxImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIGROUPBOXIMPL_H
#define SUIGROUPBOXIMPL_H

#include <QGroupBox>
#include <QMouseEvent>
#include "SUIBaseWidget.h"
#include "SUIGroupBox.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The GroupBox class
 */
class GroupBoxImpl: public BaseWidget, public GroupBox
{
    Q_OBJECT

public:
    explicit GroupBoxImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QGroupBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

    virtual void setHover(bool hover, SUI::ColorEnum::Color color);


    virtual void setBGColor(const SUI::ColorEnum::Color color);
    virtual SUI::ColorEnum::Color getBGColor() const;
protected:
    virtual bool eventFilter(QObject *obj, QEvent *event);
private:
    GroupBoxImpl(const GroupBoxImpl &rhs);
    GroupBoxImpl &operator=(const GroupBoxImpl &rhs);
};
}

#endif // SUIGROUPBOXIMPL_H
