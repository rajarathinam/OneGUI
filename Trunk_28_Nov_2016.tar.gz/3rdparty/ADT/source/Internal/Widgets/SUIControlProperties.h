//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ControlProperties.
// !\description Header file for class SUI::ControlProperties.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICONTROLPROPERTIES_H
#define SUICONTROLPROPERTIES_H

#include "SUIDeprecated.h"

#include <QMap>
#include <QString>
#include <QPixmap>
#include <QImage>
#include <QDataStream>

#include "SUIObjectType.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ControlProps class
 */
class SUI_DEPRECATED ControlProperties
{
public:
    enum ControlType { ValveU, ValveR, ValveL }; //etc..
    enum ControlState { Opened, Closed, Faulted, Unknown };

    QList<QString> getTypes() const;
    QString getTypesString() const;
    QList<QString> getStates() const;
    QString getStatesString() const;

    QMap<QString, ControlType> mTypeMap;
    QMap<QString, ControlState> mStateMap;
};
}

#endif // SUICONTROLPROPERTIES_H
