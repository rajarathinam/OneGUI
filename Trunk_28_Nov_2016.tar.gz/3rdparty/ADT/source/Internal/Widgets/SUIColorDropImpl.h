//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ColorDropImpl.
// !\description Header file for class SUI::ColorDropImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICOLORDROPIMPL_H
#define SUICOLORDROPIMPL_H

#include <QComboBox>

#include "SUIColorDrop.h"
#include "SUIBaseWidget.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The ColorDrop class
 */
class ColorDropImpl : public BaseWidget, public ColorDrop
{
    Q_OBJECT
public:
    explicit ColorDropImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QComboBox *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual SUI::ColorEnum::Color getColor() const;
    virtual void setColor(const SUI::ColorEnum::Color color);

private slots:
    void onCurrentIndexChanged();

private:
    void setValues();
    QImage image(QString color);

    ColorDropImpl();
    ColorDropImpl(const ColorDropImpl &rhs);
    ColorDropImpl &operator = (const ColorDropImpl &rhs);

};
}

#endif // SUIDROPDOWNIMPL_H
