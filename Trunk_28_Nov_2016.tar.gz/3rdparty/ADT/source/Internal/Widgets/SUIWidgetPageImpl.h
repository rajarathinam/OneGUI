//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::WidgetPageImpl.
// !\description Header file for class SUI::WidgetPageImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIWIDGETPAGEIMPL_H
#define SUIWIDGETPAGEIMPL_H

#include "SUIBasePageImpl.h"
#include "SUIWidgetPage.h"

class QWidget;

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The WidgetPage class
 */
class WidgetPageImpl : public BasePageImpl, public WidgetPage
{
   
public:
    explicit WidgetPageImpl(QWidget *parent = NULL);

private:
    WidgetPageImpl(const WidgetPageImpl &rhs);
    WidgetPageImpl &operator=(const WidgetPageImpl &rhs);
};
}

#endif // SUIWIDGETPAGEIMPL_H
