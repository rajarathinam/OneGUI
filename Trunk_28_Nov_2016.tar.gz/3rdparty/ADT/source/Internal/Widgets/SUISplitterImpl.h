//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SplitterImpl.
// !\description Header file for class SUI::SplitterImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUISPLITTERIMPL_H
#define SUISPLITTERIMPL_H

#include <QSplitter>
#include "SUIBaseWidget.h"
#include "SUISplitter.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The Splitter class
 */
class SplitterImpl : public BaseWidget, public Splitter
{
    Q_OBJECT
public:
    typedef enum
    {
        ORIENT_HORIZONTAL,
        ORIENT_VERTICAL
    } ORIENTATION;

    explicit SplitterImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);
    virtual QSplitter *getWidget() const;

    void addSplitterWidget(const BaseWidget *rticwidget);
    void removeSplitterWidget(const BaseWidget *rticwidget);
    void switchSplitterWidgets(const BaseWidget *oldWidget, const BaseWidget *newWidget);
    const BaseWidget *at(const int ind) const;
    void setOrientation(SplitterImpl::ORIENTATION orientation);
    int count() const;
    void setSizes(QList<int> &sizelist);

private:
    QMap<int, BaseWidget *> mSplitterWidgets;
    ORIENTATION mOrientation;

    SplitterImpl(const SplitterImpl &rhs);
    SplitterImpl &operator=(const SplitterImpl &rhs);
};
}

#endif // SUISPLITTERIMPL_H
