//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TabWidgetImpl.
// !\description Header file for class SUI::TabWidgetImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUITABWIDGETIMPL_H
#define SUITABWIDGETIMPL_H

#include "CustomTabWidget.h"

#include "SUIBaseWidget.h"
#include "SUITabWidget.h"

namespace SUI {
class TabPageImpl;
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TabWidget class
 */
class TabWidgetImpl : public BaseWidget, public TabWidget
{
    Q_OBJECT
public:
    explicit TabWidgetImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);

    void addNewTab(TabPage *tabPage);
    bool removeTab();

    virtual void setTabEnabled(const std::string &tabID, bool visible);
    virtual bool isTabEnabled(const std::string &tabID) const;
    
    void setCurrentTabPage(int index);
    
    void renameTab(TabPage *tabPage, const QString &tabLabel);
    
    void setTabToFront(TabPage *curTab);
    int moveNext();
    int movePrevious();

    virtual int getTabIndexOfWidget(const std::string &widgetId) const;
    virtual int getCurrentIndex() const;
    virtual int getTabPageMargin() const;
    
    virtual TabPage *getCurrentTabPage() const;
    virtual TabPage *getTabPage(int index) const;
    virtual TabPage *getTabPage(const std::string &id) const;
    
    void setTabText(const QString &tabWidgetID, const QString &text);
    void setTabText(int index, const QString &text);
    
    void setTabIcon(TabPage *tabPage, const QIcon &icon);
    
    virtual void focusTabPage(int index);

    int getTabPageIndex(TabPage *tabPage) const;
    int getTabbarHeight() const;
    
    virtual CustomTabWidget *getWidget() const;
    QString getTabName(int index) const;
    QString getTabName(const QString &id) const;
    
    void setTabVisible(const std::string &tabPageID, bool visible);

private slots:
    void onCurrentIndexChanged(int);

private:
    QVector<TabPage*> tabPages;
    QMap<TabPage*,bool> tabPageStatus;

    static const int cmTabPageMargin = 6;

    TabPage *previousTab;

    int getTabPageInternalIndex(SUI::TabPage *tabPage) const;

    TabWidgetImpl(const TabWidgetImpl &rhs);
    TabWidgetImpl &operator=(const TabWidgetImpl &rhs);

};
}

#endif // SUITABWIDGETIMPL_H
