//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectPropertyStorage.
// !\description Header file for class SUI::ObjectPropertyStorage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTPROPERTYSTORAGE_H
#define SUIOBJECTPROPERTYSTORAGE_H

#include <QString>
#include <QSet>

#include "SUIObjectPropertyTypeEnum.h"
#include "SUIObjectProperty.h"

/*!
 \brief The interface class for interaction the properties of the objects
*/
class ObjectPropertyStorage
{
public:
    /*!
     \brief Get the propertylist of an object

     \fn getPropertyList
     \return QStringList - The propertylist of an object
    */
    virtual QSet<SUI::ObjectPropertyTypeEnum::Type> getPropertyTypes() const = 0;
    virtual QMap<QString,QString> getIncludes() const = 0;

    /*!
     \brief Set the property value of an object

     \fn setPropertyValue
     \param propertyID - The property ID
     \param propertyValue - The property value
    */
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue) = 0;
    virtual void setInclude(const QString &include, const QString &fileName) = 0;

    /*!
     \brief Get the property value of an object

     \fn getPropertyValue
     \param propertyID - The property ID
     \return QString - The property value
    */
    virtual QString getPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID) const = 0;

    /*!
     \brief Get the propertyclass of an object

     \fn getPropertyDefinition
     \param propertyID - The property ID
     \return ObjectProperty - The propertyclass of an object
    */
    virtual SUI::ObjectProperty *getProperty(SUI::ObjectPropertyTypeEnum::Type propertyID) const = 0;
};

#endif // SUIIGUIPROPERTYSTORAGE_H
