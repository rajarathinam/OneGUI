//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::BaseWidget.
// !\description Header file for class SUI::BaseWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBASEWIDGET_H
#define SUIBASEWIDGET_H

#include <QString>
#include <QWidget>
#include <QSet>

#include "SUIBaseObject.h"
#include "SUIAlignmentEnum.h"
#include "SUIIErrorMode.h"
#include "SUIColorEnum.h"

namespace SUI {
class BaseWidget : public QObject, public BaseObject
{

    Q_OBJECT
public:
    BaseWidget(QWidget *qtwidget, const SUI::ObjectType::Type &objectType, bool childrenSupported);

    virtual ~BaseWidget();

    virtual QWidget *getWidget() const;

    virtual std::string getToolTip() const;
    virtual void setToolTip(const std::string &tooltip);

    void exposeHeightProperty();
    void exposeWidthProperty();
    bool isWidthExposed() const;
    bool isHeightExposed() const; 

    void setFocus();

    virtual void setGeometry();

    virtual void setVisible(bool visible);

    virtual void setEnabled(bool enabled);

    virtual void setMode(ErrorModeEnum::ErrorMode mode);

    bool isEnabled() const;

    virtual QSet<SUI::ObjectPropertyTypeEnum::Type> getPropertyTypes() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    void addCellProperties(SUI::AlignmentEnum::Alignment alignment = SUI::AlignmentEnum::Stretch, std::string cellname = "");

    void setContextMenuItems(const std::list<std::string> &items);
    std::list<std::string> getContextMenuItems() const;

public slots:
    void onCustomContextMenuRequest(QPoint point);
    
protected:
    virtual bool eventFilter(QObject *obj, QEvent *event);
    QString getContextMenuSelectedActionString(QPoint point);

signals:
    void contextMenuSig(QString, QString);

private:
    QWidget *widget;

    bool heightExposed;
    bool widthExposed;

    BaseWidget();
    BaseWidget(const BaseWidget &rhs);
    BaseWidget &operator=(const BaseWidget &rhs);
};
}

#endif // SUIBASEWIDGET_H
