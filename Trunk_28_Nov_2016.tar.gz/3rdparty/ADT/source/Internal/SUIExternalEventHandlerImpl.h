//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ExternalEventHandlerImpl.
// !\description Header file for class SUI::ExternalEventHandlerImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIEXTERNALEVENTHANDLERIMPL_H
#define SUIEXTERNALEVENTHANDLERIMPL_H

#include "SUIExternalEvent.h"

#include <QObject>

namespace SUI {

class ExternalEventHandlerImpl : public QObject
{
    Q_OBJECT
public:
    explicit ExternalEventHandlerImpl(SUI::AbstractExternalEvent *event);

    virtual ~ExternalEventHandlerImpl();

private slots:
    void emitEvent();

private:
    SUI::AbstractExternalEvent  *mEvent;
};
} // namespace SUI
#endif // SUIEXTERNALEVENTHANDLERIMPL_H
