#ifndef SUIOBJECTLISTIMPL_H
#define SUIOBJECTLISTIMPL_H

#include <map>

#include <SUIObjectList.h>

#include <SUIIChangeableSelection.h>
#include <SUIIChangeableValue.h>
#include <SUIIEditableText.h>
#include <SUIIValueValidation.h>

namespace SUI {
class ObjectListImpl: public ObjectList
{
public:
    explicit ObjectListImpl();

public:
    virtual void registerSelectionChangedHandler(std::string widgetID, IWidgetSelectionChangedHandler &selectionHandler);
};
}

#endif // SUIOBJECTLISTIMPL_H
