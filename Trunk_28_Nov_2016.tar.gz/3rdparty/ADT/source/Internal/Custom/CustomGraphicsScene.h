//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomGraphicsScene.
// !\description Header file for class CustomGraphicsScene.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef CUSTOMGRAPHICSSCENE_H
#define CUSTOMGRAPHICSSCENE_H

#include <QGraphicsScene>

#include <QGraphicsSceneMouseEvent>
#include <QGraphicsSceneWheelEvent>

#include <boost/function.hpp>

namespace SUI {
class GraphicsSceneMouseEvent;
}

class CustomGraphicsScene : public QGraphicsScene
{
    Q_OBJECT

public:
    explicit CustomGraphicsScene(QObject *parent = NULL);

    void setBackgroundImage(unsigned char *data , int width, int height, QImage::Format format);
    void setBackgroundImage(const std::string &data);
    void setBackgroundImageFile(const std::string &fileName);

    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseMoved;
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mousePressed;
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseReleased;
    boost::function<void(const boost::shared_ptr<SUI::GraphicsSceneMouseEvent>&)> mouseWheelMoved;
    
protected:
    virtual void mousePressEvent(QGraphicsSceneMouseEvent *event);
    virtual void mouseMoveEvent(QGraphicsSceneMouseEvent *event);
    virtual void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
    virtual void wheelEvent(QGraphicsSceneWheelEvent *event);
    virtual void helpEvent(QGraphicsSceneHelpEvent *event);
    
    virtual void drawBackground(QPainter *painter, const QRectF &rect);

private:
    QPixmap backgroundPixmap;
    
    void setBackgroundImage(const QPixmap &image);
};

#endif // CUSTOMGRAPHICSSCENE_H
