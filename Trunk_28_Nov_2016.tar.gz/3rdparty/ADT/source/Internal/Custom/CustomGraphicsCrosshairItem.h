//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomGraphicsCrosshairItem.
// !\description Header file for class CustomGraphicsCrosshairItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMGRAPHICSCROSSHAIRITEM_H
#define CUSTOMGRAPHICSCROSSHAIRITEM_H

#include <QGraphicsEllipseItem>

class CustomGraphicsCrosshairItem : public QGraphicsEllipseItem
{
public:
    explicit CustomGraphicsCrosshairItem(QGraphicsItem *parent = NULL);

    virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *, QWidget *);

};


#endif // CUSTOMGRAPHICSCROSSHAIRITEM_H
