//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomSpinBox.
// !\description Header file for class CustomSpinBox.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMSPINBOX_H
#define CUSTOMSPINBOX_H

#include <QSpinBox>

class CustomSpinBox : public QSpinBox
{
public:
    CustomSpinBox(QWidget *parent = NULL);

    virtual void stepBy(int steps);
    void setStepSizeValueToFactor(const bool on);

private:
    bool mValueIsFactor;

    CustomSpinBox();
    CustomSpinBox(const CustomSpinBox &rhs);
    CustomSpinBox &operator=(const CustomSpinBox &rhs);
};

#endif // CUSTOMSPINBOX_H
