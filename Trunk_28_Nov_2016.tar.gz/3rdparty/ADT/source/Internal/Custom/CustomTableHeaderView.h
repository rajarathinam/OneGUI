//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomTableHeaderView.
// !\description Header file for class CustomTableHeaderView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMTABLEHEADERVIEW_H
#define CUSTOMTABLEHEADERVIEW_H

#include <QHeaderView>
#include <QPointer>
#include <QAbstractItemModel>

namespace SUI {

class CustomTableHeaderView : public QHeaderView
{
    Q_OBJECT
public:
    explicit CustomTableHeaderView(Qt::Orientation orientation, QWidget *parent = 0);
    virtual ~CustomTableHeaderView();

    QStyleOptionHeader styleOptionForCell(int logicalIndex) const;

    virtual void setModel(QAbstractItemModel *model);

    enum DataRole
    {
        HorizontalHeader = Qt::UserRole,
        VerticalHeader = Qt::UserRole + 1
    };

protected:
    virtual void paintSection(QPainter *painter, const QRect &rect, int logicalIndex) const;
    virtual QSize sectionSizeFromContents(int logicalIndex) const;

private slots:
    void onSectionResized(int logicalIndex);

private:

    class CustomTableHeaderViewPrivateData
    {
    public:
        QPointer<QAbstractItemModel> headerModel;

        void setModel(Qt::Orientation orientation, QAbstractItemModel *model);

        QModelIndex findRootIndex(QModelIndex &index) const;
        QModelIndexList parentIndexes(QModelIndex index) const;

        QModelIndex findLeaf(const QModelIndex &currentIndex, int sectionIndex, int &currentLeafIndex);
        QModelIndex leafIndex(int sectionIndex);
        QModelIndexList searchLeafs(const QModelIndex& curentIndex) const;
        QModelIndexList leafs(const QModelIndex& searchedIndex) const;

        void setForegroundBrush(QStyleOptionHeader& opt, const QModelIndex& index) const;
        void setBackgroundBrush(QStyleOptionHeader& opt, const QModelIndex& index) const;

        QSize cellSize(const QModelIndex& leafIndex, const QHeaderView* hv, QStyleOptionHeader styleOptions) const;

        int	currentCellWidth(const QModelIndex& searchedIndex, const QModelIndex& leafIndex, int sectionIndex, const QHeaderView* hv) const;
        int	currentCellLeft(const QModelIndex& searchedIndex, const QModelIndex& leafIndex,int sectionIndex,int left,const QHeaderView* hv) const;

        int paintHorizontalCell(QPainter *painter, const QHeaderView* hv, const QModelIndex& cellIndex, const QModelIndex& leafIndex,
                                int logicalLeafIndex, const QStyleOptionHeader& styleOptions, const QRect& sectionRect, int top) const;

        void paintHorizontalSection(QPainter *painter, const QRect& sectionRect, int logicalLeafIndex,
                                    const QHeaderView* hv, const QStyleOptionHeader& styleOptions, const QModelIndex& leafIndex) const;

        int paintVerticalCell(QPainter *painter,const QHeaderView* hv,const QModelIndex& cellIndex,const QModelIndex& leafIndex,
                              int logicalLeafIndex,const QStyleOptionHeader& styleOptions,const QRect& sectionRect,int left) const;

        void paintVerticalSection(QPainter *painter,const QRect& sectionRect,int logicalLeafIndex,
                                  const QHeaderView* hv,const QStyleOptionHeader& styleOptions,const QModelIndex& leafIndex) const;
    };

    CustomTableHeaderViewPrivateData *privateData;
};

}


#endif // CUSTOMTABLEHEADERVIEW_H
