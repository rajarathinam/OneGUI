//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class HeaderTags.
// !\description Header file for class HeaderTags.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMHEADERTAGS_H
#define CUSTOMHEADERTAGS_H

#include <QString>
#include <QList>

class HeaderTags
{
public:
    HeaderTags(const QString &tagname);
    HeaderTags(const QString &tagname, const QString &childtags);
    ~HeaderTags();

    const QList<HeaderTags *> &getChildren() const;
    QString getName() const;

private:
    QString mTagName;
    QList<HeaderTags*> mChildren;
};

#endif // CUSTOMHEADERTAGS_H
