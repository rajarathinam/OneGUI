//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomTabWidget.
// !\description Header file for class CustomTabWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMTABWIDGET_H
#define CUSTOMTABWIDGET_H

#include <QTabWidget>
#include <QTabBar>

class CustomTabWidget : public QTabWidget
{
    Q_OBJECT
public:
    explicit CustomTabWidget(QWidget *parent = NULL);

    QTabBar *getTabBar();
    int getTabIndex(const QPoint &event);
    
private:
    CustomTabWidget();
    CustomTabWidget(const CustomTabWidget &rhs);
    CustomTabWidget &operator=(const CustomTabWidget &rhs);
};

#endif // CUSTOMTABWIDGET_H
