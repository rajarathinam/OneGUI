//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomGraphicsEllipseItem.
// !\description Header file for class CustomGraphicsEllipseItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef CUSTOMGRAPHICSELLIPSEITEM_H
#define CUSTOMGRAPHICSELLIPSEITEM_H

#include <QGraphicsEllipseItem>

class CustomGraphicsEllipseItem : public QGraphicsEllipseItem 
{
   
public:
   explicit CustomGraphicsEllipseItem(const QRectF &rect, QGraphicsItem *parent);

protected:
   virtual void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
   
};

#endif // CUSTOMGRAPHICSELLIPSEITEM_H
