//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomGraphicsView.
// !\description Header file for class CustomGraphicsView.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMGRAPHICSVIEW_H
#define CUSTOMGRAPHICSVIEW_H

#include <QGraphicsView>

class QRubberBand;

class CustomGraphicsView : public QGraphicsView
{
    Q_OBJECT
public:
    explicit CustomGraphicsView(QWidget *parent = NULL);
    virtual ~CustomGraphicsView();

    double getScale() const;
    
    void setScrollBarsEnabled(bool scrollBars);
    bool isScrollBarsEnabled() const;
    
    void setMouseWheelZoomEnabled(bool enabled);
    
    void zoom(double scale, int x, int y);
    void setScaleFactor(double scale);
    double getScaleFactor();

    Qt::AspectRatioMode getAspectRatioMode() const;

public slots:
    void fitInView();
    void fitInView(const QRectF &rect, Qt::AspectRatioMode aspectRadioMode = Qt::IgnoreAspectRatio);
    void fitInView(qreal x, qreal y, qreal w, qreal h, Qt::AspectRatioMode aspectRadioMode = Qt::IgnoreAspectRatio);
    void onSceneRectChanged(QRectF);

protected:
    virtual void hideEvent(QHideEvent *event);
    virtual void showEvent(QShowEvent *event);
    
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void wheelEvent(QWheelEvent *event);
    
signals:
    void visibilityChanged(bool);
        
private:
    QRubberBand *mRubberBand;  
    
    Qt::AspectRatioMode mAspectRatioMode;
    
    bool mouseWheelZoomEnabled;
    
    // There is a 2 pixel margin when fitting a rect into the scene and only 1 pixel is needed to replicate previous behavior.
    // This function takes this into account and resizes the given rect accordingly.
    static QRectF removeMarginBug(const QRectF &sceneRect, const QSize &viewerSize);
    QPoint mMouseOrigin;

    // Scale factor for QGraphicsView, set to 1.1 in stead of 1.015
    double mScaleFactor;
};

#endif // CUSTOMGRAPHICSVIEW_H
