//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomTableItemDelegate.
// !\description Header file for class CustomTableItemDelegate.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef CUSTOMTABLEITEMDELEGATE_H
#define CUSTOMTABLEITEMDELEGATE_H

#include <QStyledItemDelegate>

class QWidget;

namespace SUI {

class CustomTableItemDelegate : public QStyledItemDelegate
{
public:
    explicit CustomTableItemDelegate(QObject *parent);

protected:
    virtual void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
};

}
#endif // CUSTOMTABLEITEMDELEGATE_H
