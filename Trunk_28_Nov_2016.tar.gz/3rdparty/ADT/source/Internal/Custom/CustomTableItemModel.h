//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class CustomTableItemModel.
// !\description Header file for class CustomTableItemModel.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef CUSTOMTABLEITEMMODEL_H
#define CUSTOMTABLEITEMMODEL_H

#include <QAbstractTableModel>
#include <QVector>

#include "SUIObjectPropertyTypeEnum.h"

class QStandardItemModel;

namespace SUI {

class Widget;
class TableWidgetItemImpl;
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The TableWidgetItemContainer class
 *
 * Because TableWidget needs a special container for its items, the
 * TableWidgetItemContainer class has been made.
 * Because all QTableWidgetItems have to be written, read, copied and paste in
 * the proper sequence and not in the random sequence of QUuid, this special
 * container has been made to maintain this sequence and the items
 * (TableWidgetItems) can be addressed by row- and column number. All items
 * are kept in a QList. The function to1D() is used to map between a row/column
 * number and an index (from 2D to 1D). The row related functions and column
 * related functions use there own calculation to a QList index.
 */
class CustomTableItemModel : public QAbstractTableModel
{
    Q_OBJECT

public:
    enum CustomRoles
    {
        HorizontalHeaderRole = Qt::UserRole,
        VerticalHeaderRole = Qt::UserRole + 1,
        WidgetRole = Qt::UserRole + 2,
        IDRole = Qt::UserRole + 10 + ObjectPropertyTypeEnum::ID,
        ObjectTypeRole = Qt::UserRole + 10 + ObjectPropertyTypeEnum::ObjectType,
        BorderOnRole = Qt::UserRole + 10 + ObjectPropertyTypeEnum::BorderOn,
        BorderWidthRole = Qt::UserRole + 10 + ObjectPropertyTypeEnum::BorderWidth
    };

    CustomTableItemModel(QObject *parent = 0);
    CustomTableItemModel(int rows, int columns, QObject *parent = 0);

    virtual ~CustomTableItemModel();

    virtual QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    virtual bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole);

    virtual int rowCount(const QModelIndex &parent = QModelIndex()) const;
    virtual int columnCount(const QModelIndex &parent = QModelIndex()) const;

    virtual bool insertRow(int row, const QModelIndex &parent = QModelIndex());
    virtual bool insertRows(int pos, int count, const QModelIndex &parent = QModelIndex());
    virtual bool removeRows(int pos, int count, const QModelIndex &parent = QModelIndex());

    virtual bool insertColumn(int column, const QModelIndex &parent = QModelIndex());
    virtual bool insertColumns(int pos, int count, const QModelIndex &parent = QModelIndex());
    virtual bool removeColumns(int pos, int count, const QModelIndex &parent = QModelIndex());

    void refresh();
    bool indexValid(int row, int column) const;

    void setHeaderModel(Qt::Orientation orientation, QAbstractItemModel *model);

    QAbstractItemModel *getHeaderModel(Qt::Orientation orientation);

signals:
    void headerDataChanged();

private:
    QVector<QVector<Widget*>> container;

    QAbstractItemModel *horizontalHeaderModel;
    QAbstractItemModel *verticalHeaderModel;
};


}

#endif // CUSTOMTABLEITEMMODEL_H
