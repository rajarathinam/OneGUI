//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IViewable.
// !\description Header file for class SUI::IViewable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIVIEWABLE_H
#define SUIIVIEWABLE_H

#include <boost/function.hpp>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief IViewable - interface for Objects that can be visible or not.
 */
class IViewable
{
public:
    virtual ~IViewable() {}

    /*!
     * \brief setVisible
     * Sets the Object visibility property.
     * \param visible - boolean
     */
    virtual void setVisible(bool visible) = 0;

    /*!
     * \brief isVisible
     * Returns a true if the Object is visible, false if not.
     * \return bool  - Is the object visible.
     */
    virtual bool isVisible() const = 0;

    /*!
     * \brief show
     * This method equals setVisible(true)
     * \remarks - see SUI::IViewable::setVisible
     */
    void show()
    { setVisible(true); }

    /*!
     * \brief
     * This method equals setVisible(false)
     * \remarks - see SUI::IViewable::setVisible
     */
    void hide()
    { setVisible(false); }

    /*!
     * \brief visibilityChanged
     * Callback function that is called when the visibility changed.
     */
    boost::function<void(bool)> visibilityChanged;

};
}

#endif // SUIIVIEWABLE_H
