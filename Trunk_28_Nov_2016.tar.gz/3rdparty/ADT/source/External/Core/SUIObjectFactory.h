//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Object.
// !\description Header file for class SUI::Object.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTFACTORY_H
#define SUIOBJECTFACTORY_H

#include <SUIObjectType.h>
#include <SUIVersionInfo.h>

#include <SUIDeprecated.h>

#include <typeinfo>

class QWidget;
    
namespace SUI {
class Object;
class Widget;
class GraphicsItem;
class BaseWidget;
class BaseObject;
class ObjectList;
class Application;
class Dialog;

class GraphicsTextItem;
class GraphicsLineItem;
class GraphicsEllipseItem;
class GraphicsRectItem;
class GraphicsCrosshairItem;
class GraphicsSvgItem;
class GraphicsPixmapItem;

class PlotItem;
class PlotCurveItem;
class PlotHistogramItem;

/*!
 * \ingroup FWQxCore
 *
 * \brief The ObjectFactory class
 */
class ObjectFactory
{
public:

    /*!
     * \brief getInstance
     * Returns the one and only instance
     * \return
     */
    static ObjectFactory *getInstance();

    virtual ~ObjectFactory();

    /*!
     * \brief getName
     * Returns the name field
     * \return
     */
    std::string getName() const;

    /*!
     * \brief getDescription
     * Returns the description field
     * \return
     */
    std::string getDescription() const;

    /*!
     * \brief getVersion
     * Returns the version field
     * \return
     */
    std::string getVersion() const;

    /*!
     * \brief createWidget
     * Creates a widget of a specified type, a given parent (default is NULL) and a given
     * widget list (default is NULL)
     * \param widgetType
     * \param parent
     * \param widgetList
     * \return
     */
    virtual BaseWidget *createWidget(ObjectType::Type widgetType, QWidget *parent = NULL, ObjectList *widgetList = NULL) = 0; //This needs to be fixed, QWidget removed

    /*!
     * \brief toObject
     * Converts an object of type BaseObject to Object
     * \param object
     * \return
     */
    virtual Object *toObject(BaseObject *object) = 0;

    /*!
     * \brief toBaseObject
     * Converts an object of type Object to BaseObject
     * \param object
     * \return
     */
    virtual BaseObject *toBaseObject(Object *object) = 0;

    /*!
     * \brief toBaseObject
     * Converts a const object of type Object to BaseObject
     * \param object
     * \return
     */
    virtual BaseObject *toBaseObject(const Object *object) = 0;

    /*!
     * \brief toBaseObject
     * Converts an object of type Widget to BaseWidget
     * \param object
     * \return
     */
    virtual BaseWidget *toBaseWidget(Widget *object) = 0;

    /*!
     * \brief toBaseObject
     * Converts a const object of type Widget to BaseWidget
     * \param object
     * \return
     */
    virtual BaseWidget *toBaseWidget(const Widget *object) = 0;

    /*!
     * \brief isWidget
     * Returns true if typeInfo is a widget type description; false otherwise
     * \param typeInfo
     * \return
     */
    bool isWidget(const std::type_info &typeInfo) const;

    /*!
     * \brief createWidget_
     * Creates a widget of type T
     * \param parent
     * \return
     */
    template<class T>
    T *createWidget_(QWidget *parent = NULL)
    { return !isWidget(typeid(T)) ? NULL : dynamic_cast<T*>((this->*(widgetTypeMap.find(&typeid(T))->second))(parent)); } //"Type T must inherit from SUI::Widget, i.e. must be in the widgetTypeMap."

    /*!
     * \brief isGraphicsItem
     * Returns whether the object is a graphics item or not
     * \param typeInfo
     * \return
     */
    bool isGraphicsItem(const std::type_info &typeInfo) const;

    /*!
     * \brief createGraphicsItem
     * Creates a graphics item and specifies its parent. Default the parent is NULL
     * \param parent
     * \return
     */
    template<class T>
    T *createGraphicsItem(GraphicsItem *parent = NULL)
    { return new T(parent); }//"Type T must inherit from SUI::GraphicsItem."

    /*!
     * \brief getClassName
     * Returns the class name
     * \param parent
     * \return
     */
    template<class T>
    static std::string getClassName() 
    { std::string t = Demangler()(typeid(T).name()); return t.substr(5,t.size()-1); }
    
    /*!
     * \brief getObjectType
     * Returns the object type
     * \return
     */
    template<class T>
    static SUI::ObjectType getObjectType()
    { return SUI::ObjectType::fromString(getClassName<T>()); }
    
    /*!
     * \brief getImplementation
     * Returns a pointer to the implementation of a graphics item
     * \param item
     * \return
     */
    static void *getImplementation(SUI::GraphicsItem *item);

    /*!
     * \brief getPlotImplementation
     * Returns a pointer to the implementation of a plot item
     * \param item
     * \return
     */
    static void *getPlotImplementation(SUI::PlotItem *item);

protected:
    virtual Widget *createButton(QWidget *parent = NULL) = 0;
    virtual Widget *createLabel(QWidget *parent = NULL) = 0;
    virtual Widget *createLineEdit(QWidget *parent = NULL) = 0;
    virtual Widget *createRadioButton(QWidget *parent = NULL) = 0;
    virtual Widget *createTabWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createTabPage(QWidget *parent = NULL) = 0;
    virtual Widget *createCheckBox(QWidget *parent = NULL) = 0;
    virtual Widget *createGroupBox(QWidget *parent = NULL) = 0;
    virtual Widget *createCheckGroupBox(QWidget *parent = NULL) = 0;
    virtual Widget *createButtonBar(QWidget *parent = NULL) = 0;
    virtual Widget *createTableWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createTableWidgetItem(QWidget *parent = NULL) = 0;
    virtual Widget *createSpinBox(QWidget *parent = NULL) = 0;
    virtual Widget *createDoubleSpinBox(QWidget *parent = NULL) = 0;
    virtual Widget *createDropDown(QWidget *parent = NULL) = 0;
    SUI_DEPRECATED virtual Widget *createCheckMark(QWidget *parent = NULL) = 0;
    SUI_DEPRECATED virtual Widget *createLEDWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createColorDrop(QWidget *parent = NULL) = 0;
    virtual Widget *createColorCrossDrop(QWidget *parent = NULL) = 0;
    virtual Widget *createTextArea(QWidget *parent = NULL) = 0;
    virtual Widget *createProgressBar(QWidget *parent = NULL) = 0;
    virtual Widget *createImageViewer(QWidget *parent = NULL) = 0;
    SUI_DEPRECATED virtual Widget *createMessageBox(QWidget *parent = NULL) = 0;
    virtual Widget *createSplitter(QWidget *parent = NULL) = 0;
    SUI_DEPRECATED virtual Widget *createFileDialog(QWidget *parent = NULL) = 0;
    virtual Widget *createUserControl(QWidget *parent = NULL) = 0;
    virtual Widget *createPlotWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createListView(QWidget *parent = NULL) = 0;
    SUI_DEPRECATED virtual Widget *createControlWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createStateWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createScienceSpinBox(QWidget *parent = NULL) = 0;
    virtual Widget *createQuestionMark(QWidget *parent = NULL) = 0;
    virtual Widget *createBusyIndicator(QWidget *parent = NULL) = 0;
    virtual Widget *createImageWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createTreeView(QWidget *parent = NULL) = 0;
    virtual Widget *createTreeViewItem(QWidget *parent = NULL) = 0;
    virtual Widget *createLineWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createSvgWidget(QWidget *parent = NULL) = 0;
    virtual Widget *createWidgetPage(QWidget *parent = NULL) = 0;
    virtual Widget *createScrollBar(QWidget *parent = NULL) = 0;

private:
    typedef SUI::Widget *(ObjectFactory::*createWidgetFunction)(QWidget *);
    static const std::map<const std::type_info*,createWidgetFunction> widgetTypeMap;

    struct Demangler {
       char *p;
       std::string operator()(const char *name);
       ~Demangler();
    };
    static const SUI::VersionInfo version;
    static const std::string name;
    static const std::string description;

};
}

#endif // SUIIOBJECTFACTORY_H
