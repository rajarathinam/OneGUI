//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::FileDialogOptionEnum.
// !\description Header file for class SUI::FileDialogOptionEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIFILEDIALOGOPTIONENUM_H
#define SUIFILEDIALOGOPTIONENUM_H

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe file open dialog options.
 */
class FileDialogOptionEnum
{
public:
    /*!
     * \brief Option
     * The file dialog options enumeration
     */
    enum Option {
        None = 0x00000000,
        ShowDirsOnly = 0x00000001,
        DontResolveSymlinks = 0x00000002,
        DontConfirmOverwrite = 0x00000004,
        DontUseNativeDialog = 0x00000010,
        ReadOnly = 0x00000020,
        HideNameFilterDetails  = 0x00000040,
        DontUseSheet = 0x00000008,
        DontUseCustomDirectoryIcons = 0x00000080
    };

    /*!
     * \brief Options
     */
    typedef int Options;
};

} // namespace SUI

#endif // SUI_SUIFILEDIALOGOPTIONENUM_H
