//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::INumeric.
// !\description Header file for class SUI::INumeric.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIINUMERIC_H
#define SUIINUMERIC_H

#include <string>

#include <boost/function.hpp>

namespace SUI {
template<typename T>
/*!
 * \ingroup FWQxCore
 *
 * \brief Generic Interface class for interaction with the numeric property's of a Numeric
 */
class INumeric
{
public:
    virtual ~INumeric() {}

    /*!
     * \brief setMinValue
     * Set the min value of the widget
     * \param val : the minimal value
     */
    virtual void setMinValue(const T val) = 0;

    /*!
     * \brief getMinValue
     * Returns the minimal value of the widget
     * \return
     */
    virtual T getMinValue() const = 0;

    /*!
     * \brief setMaxValue
     * Sets the maximum value of the widget
     * \param val : the requested maximum value
     */
    virtual void setMaxValue(const T val) = 0;

    /*!
     * \brief getMaxValue
     * Returns the maximum value
     * \return
     */
    virtual T getMaxValue() const = 0;

    /*!
     * \brief setStepSize
     * Sets the Stepsize of the widget
     * \param Requested step size
     */
    virtual void setStepSize(const T val) = 0;

    /*!
     * \brief getStepSize
     * Returns the stepsize of the widget
     * \return
     */
    virtual T getStepSize() const = 0;

    /*!
     * \brief getValue
     * Returns the current value of the widget
     * \return
     */
    virtual T getValue() const = 0;

    /*!
     * \brief setValue
     * Sets the value of the widget.
     * Note: If value < minvalue, the value will become minvalue,
     * If value > maxvalue, the value will become maxvalue
     * \param val : the requested value
     */
    virtual void setValue(const T val) = 0;

    /*!
     * \brief setStepSizeValueToFactor
     * Sets the stepsize as a factor of the min - max range
     * \param on : Stepfactor (true) or stepvalue (false)
     */
    virtual void setStepSizeValueToFactor(const bool on) = 0;

    /*!
     * \brief setPrecision
     * This interface sets the precision of the widget, in decimals.
     * Sets how many decimals the widget will use for displaying and interpreting doubles.
     * Warning: The maximum value for decimals is DBL_MAX_10_EXP + DBL_DIG (ie. 323) because of the limitations of the double type.
     * Note: The maximum, minimum and value might change as a result of changing this property.
     *
     */
    virtual void setPrecision(const int) {}


    /*!
     * \brief getPrecision
     * Returns the current number of decimals
     * \return
     */
    virtual int getPrecision() const { return 0; }

    /*!
     * \brief valueChanged
     * Callback function that is called when the value has changed.
     * \fn valueChanged
     */
    boost::function<void()> valueChanged;
};
}

#endif // SUIINUM_H
