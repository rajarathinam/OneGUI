//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::CurveColorEnum.
// !\description Header file for class SUI::CurveColorEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUICURVECOLORENUM_H
#define SUICURVECOLORENUM_H

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe curve colors.
 */
class CurveColorEnum
{
public:

    /*!
     * \brief CurveColor
     * The CurveColor enumeration
     */
    typedef enum
    {
        Black,
        Blue,
        Green,
        Red,
        Yellow
    } CurveColor;

};
}
#endif // SUICURVECOLORENUM_H
