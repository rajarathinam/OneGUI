//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::AbstractExternalEvent.
// !\description Header file for class SUI::AbstractExternalEvent.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUIABSTRACTEXTERNALEVENT_H
#define SUIABSTRACTEXTERNALEVENT_H

#include "SUISharedExport.h"

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief The Abstract ExternalEvent class
 */
class SUI_SHARED_EXPORT AbstractExternalEvent
{
public:
    virtual ~AbstractExternalEvent() {}
    virtual void emitEvent() = 0;
};
}


#endif // SUIABSTRACTEXTERNALEVENT_H
