//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IErrorMode.
// !\description Header file for class SUI::IErrorMode.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|



#ifndef SUIIERRORMODE_H
#define SUIIERRORMODE_H

#include "SUIErrorModeEnum.h"

#include <string>

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Global Interface class handling the error mode of the input widgets
 */
class IErrorMode
{
public:
    virtual ~IErrorMode() {}

    /*!
     * \brief IErrorMode
     * Constructor
     */
    IErrorMode() : //FIXME
        mCurrentMode(ErrorModeEnum::None),
        cmErrBckgrndColor("background-color: rgb(255, 0, 0, 50); border-color: red"),
        cmNoneBckgrndColor("background-color: white; border-color: #2f3d5d") {
    } //FIXME

    /*!
     * \brief setMode
     * Sets the error mode of the widget
     * \param mode
     */
    virtual void setMode(ErrorModeEnum::ErrorMode mode) = 0;

protected:
    ErrorModeEnum::ErrorMode mCurrentMode;
    std::string cmErrBckgrndColor;
    std::string cmNoneBckgrndColor;
};
}

#endif // SUIIERRORMODE_H
