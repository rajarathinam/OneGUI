//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::IOrientable.
// !\description Header file for class SUI::IOrientable.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIIORIENTABLE_H
#define SUIIORIENTABLE_H

#include <string>

#include "SUIOrientationEnum.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Global Interface class for interaction with the orientation properties of widgets
 */
class IOrientable
{
public:
    virtual ~IOrientable() {}

    /*!
     * \brief getOrientation
     * Gets the orientation of the widget
     * \return
     */
    virtual OrientationEnum::Orientation getOrientation() const = 0;

    /*!
     * \brief setOrientation
     * Sets the orientation of the widget
     * \param orientation
     */
    virtual void setOrientation(OrientationEnum::Orientation orientation) = 0;
};
}

#endif // SUIIORIENTATION_H
