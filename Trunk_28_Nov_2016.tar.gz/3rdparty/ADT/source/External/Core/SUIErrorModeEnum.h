//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ErrorModeEnum.
// !\description Header file for class SUI::ErrorModeEnum.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIERRORMODEENUM_H
#define SUIERRORMODEENUM_H

#include <string>
#include <map>
#include <list>

namespace SUI {
/*!
 * \ingroup FWQxCore
 *
 * \brief This enum type is used to describe error modes.
 */
class ErrorModeEnum
{
public:
    /*!
     * \brief ErrorMode
     * The Errormode enumeration
     */
    typedef enum
    {
        None,
        Ok,
        Warning,
        Error
    } ErrorMode;

    /*!
     * \brief fromString
     * Converts a string to an ErrorModeEnum object
     * \param errorStr: string to be converted
     * \return
     */
    static ErrorModeEnum::ErrorMode fromString(const std::string &errorStr);

    /*!
     * \brief toString
     * Converts an ErrorModeEnum object to a string
     * \param errorMode: enumeration to be converted
     * \return
     */
    static std::string toString(ErrorModeEnum::ErrorMode errorMode);

    /*!
     * \brief getErrorModeStringList
     * Returns a string list of error modes
     * \return
     */
    static std::list<std::string> getErrorModeStringList();
private:
    static std::map<ErrorModeEnum::ErrorMode,std::string> errorMap;
    static std::list<std::string> errorModeStringList;
};
}
#endif // SUIERRORMODEENUM_H
