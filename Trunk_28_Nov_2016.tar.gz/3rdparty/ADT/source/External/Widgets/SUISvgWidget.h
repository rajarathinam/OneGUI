//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::SvgWidget.
// !\description Header file for class SUI::SvgWidget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISVGWIDGET_H
#define SUISVGWIDGET_H

#include "SUIDeprecated.h"
#include "SUIColorEnum.h"

#include "SUIWidget.h"

#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface class for interaction with the SVG widget
 */
class SUI_DEPRECATED SvgWidget : public Widget
{
public:
    virtual ~SvgWidget();
    /*!
     * \brief getElementIdList
     * Returns a list of all "id" attribute values
     * \return list of all "id" attribute values
     */
    virtual std::list<std::string> getElementIdList() = 0;

    /*!
     * \brief setImage
     * Sets the filename of the SVG image to be loaded in the widget. If the filename
     * is incorrect an exception is thrown. If the file cannot be parsed, an exception
     * is thrown.
     * \param value - filename of SVG image.
     */
    virtual void setImage(const std::string &value) = 0;

    /*!
     * \brief setElementColor
     * Sets the color of an element with corresponding id
     * \param idvalue - id of element to be modified
     * \param color - color to be applied
     */
    virtual void setElementColor(const std::string idvalue, const SUI::ColorEnum::Color color) = 0;

    /*!
     * \brief setElementBorderColor
     * Sets the border color of an element with corresponding id
     * \param idvalue - id of element to be modified
     * \param borderColor - color to be applied
     */
    virtual void setElementBorderColor(const std::string idvalue, const SUI::ColorEnum::Color borderColor) = 0;

    /*!
     * \brief setElementText
     * Sets the text of element with id idvalue
     * \param idvalue - id of element to be modified
     * \param text - the text to be set
     */
    virtual void setElementText(const std::string idvalue, const std::string text) = 0;
    
protected:
    SvgWidget();
};
}

#endif // SUISVGWIDGET_H
