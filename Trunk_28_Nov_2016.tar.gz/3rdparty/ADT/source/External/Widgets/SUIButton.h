//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Button.
// !\description Header file for class SUI::Button.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIBUTTON_H
#define SUIBUTTON_H

#include "SUIIClickable.h"
#include "SUIIAlignable.h"
#include "SUIIText.h"
#include "SUIIImage.h"
#include "SUIWidget.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 *
 * \brief The Button class
 */
class SUI_SHARED_EXPORT Button : public Widget, public IClickable, public IText, public IImage, public IAlignable
{
public:
    virtual ~Button();
    
protected:
    Button();
};
}

#endif // SUIBUTTON_H
