//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::RadioButton.
// !\description Header file for class SUI::RadioButton.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIRADIOBUTTON_H
#define SUIRADIOBUTTON_H

#include "SUIWidget.h"
#include "SUIICheckable.h"
#include "SUIIText.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The RadioButton class
 */
class SUI_SHARED_EXPORT RadioButton : public Widget, public ICheckable, public IText
{
public:
    virtual ~RadioButton();
    
protected:
    RadioButton();

};
}

#endif // SUIRADIOBUTTON_H
