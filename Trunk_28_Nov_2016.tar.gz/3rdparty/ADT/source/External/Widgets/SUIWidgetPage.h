//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::WidgetPage.
// !\description Header file for class SUI::WidgetPage.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIWIDGETPAGE_H
#define SUIWIDGETPAGE_H

#include "SUIWidget.h"

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The WidgetPage class
 */
class SUI_SHARED_EXPORT WidgetPage : public Widget
{
public:
    virtual ~WidgetPage();
    
protected:
    WidgetPage();
};
}
#endif // SUIWIDGETPAGE_H
