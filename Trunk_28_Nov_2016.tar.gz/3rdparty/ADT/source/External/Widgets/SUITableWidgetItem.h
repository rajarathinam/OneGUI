//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::TableWidgetItem.
// !\description Header file for class SUI::TableWidgetItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUITABLEWIDGETITEM_H
#define SUITABLEWIDGETITEM_H

#include "SUIWidget.h"
#include "SUIIText.h"
#include "SUIIAlignable.h"
#include "SUIFontSizeEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The TableWidgetItem class
 */
class SUI_SHARED_EXPORT TableWidgetItem : public Widget, public IText, public IAlignable
{
public:
    virtual ~TableWidgetItem();

    /*!
     * \brief setFontSize
     * Set the TableWidgetItem's font size. Also see FontSizeEnum::FontSize
     * \param fontsize
     */
    virtual void setFontSize(const FontSizeEnum::FontSize &fontsize) = 0;

    /*!
     * \brief
     * Returns the font size (FontSizeEnum::FontSize)
     * \return
     */
    virtual FontSizeEnum::FontSize getFontSize() const = 0;

protected:
    TableWidgetItem();

};
}

#endif // SUITABLEWIDGETITEM_H
