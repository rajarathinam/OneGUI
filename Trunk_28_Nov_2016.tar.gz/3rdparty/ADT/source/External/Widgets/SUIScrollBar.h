//-----------------------------------------------------------------------------|
//                                                                             |
//                            C++ Header File                                  |
//                                                                             |
//-----------------------------------------------------------------------------|
//
// Ident        : SUIScrollBar.h
// Author       : Jan-Pieter Diender
// Description  : Header file for class SUI::ScrollBar.
//
// ! \file        SUIScrollBar.h
// ! \brief       Header file for class SUI::ScrollBar.
//
//-----------------------------------------------------------------------------|
//                                                                             |
//        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
//                           All rights reserved                               |
//                                                                             |
//-----------------------------------------------------------------------------|

#ifndef SUISCROLLBAR_H
#define SUISCROLLBAR_H

#include "SUIWidget.h"
#include "SUIIOrientable.h"
#include "SUIINumeric.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ScrollBar class
 */
class SUI_SHARED_EXPORT ScrollBar : public Widget,  public IOrientable, public INumeric<int>
{
public:
    virtual ~ScrollBar();

    /*!
     * \brief setPageStep
     * Sets size of the thumb, relative to the min-max value range.
     * \param val: value to be set
     */
    virtual void setPageStep(const int val) = 0;

    /*!
     * \brief getPageStep
     * Gets the width of the thumb, relative to the minimum-maximum range,
     * the percentage is not applied
     * \param percentage: value to be set
     */
    virtual int getPageStep() const = 0;


protected:
    ScrollBar();
};
}

#endif // SUISCROLLBAR_H
