//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::FileDialog.
// !\description Header file for class SUI::FileDialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIFILEDIALOG_H
#define SUIFILEDIALOG_H

#include "SUIDeprecated.h"

#include "SUIWidget.h"
#include "SUIIClickable.h"

#include "SUIFileDialogOptionEnum.h"

#include <string>
#include <list>

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The FileDialog class
 */
class FileDialog : public Widget, public IClickable
{
public:
    virtual ~FileDialog();

    /*!
     * \brief AcceptMode
     * The AcceptMode enumeration: File, Save or Directory
     */
    enum AcceptMode { File, Save, Dir };

    /*!
     * \brief getSelectedFiles
     * Returns a ';' separated string of selected filenames
     * \return
     */
    virtual std::string getSelectedFiles() const = 0;

    /*!
     * \brief setAcceptButtonText
     * Sets the text for the Accept button
     * \param message
     */
    virtual void setAcceptButtonText(const std::string &message) = 0;

    /*!
     * \brief setTitle
     * Sets the file dialog title
     * \param title
     */
    virtual void setTitle(const std::string &title) = 0;

    /*!
     * \brief setAcceptMode
     * Sets the accept mode. File for opening files, Save for saving files and Dir for
     * for opening a directory
     * \param mMode
     */
    virtual void setAcceptMode(AcceptMode mMode) = 0;

    /*!
     * \brief setFilter
     * Sets the current file type filter. Multiple filters can be passed
     * \param filters
     */
    virtual void setFilter(const std::list<std::string> &filters) = 0;

    /*!
     * \brief setDirectory
     * Sets the file dialog's current directory
     * \param path
     */
    virtual void setDirectory(const std::string &path) = 0;

    /*!
     * \brief setRootDirectory
     * Sets the file dialog's root directory. The user cannot navigate to a parent
     * of this directory or a path outside the root directory
     * \param rootpath
     */
    virtual void setRootDirectory(const std::string &rootpath) = 0;

    /*!
     * \brief show
     * Shows the file dialog, with a given title, message, filters and accept mode
     * \param title: Title of the dialg
     * \param message: Message to be displayed
     * \param filters: Filters to be applied
     * \param mMode: Acceptance mode
     */
    virtual void show(const std::string &title, const std::string &message, const std::list<std::string> &filters, AcceptMode mMode) = 0;

    /*!
     * \brief getExistingDirectory
     * Returns an existing directory selected by the user.
     * \param parent: Parent of the file dialog
     * \param caption: Text of the file dialog
     * \param dir: The directory that will be opened default
     * \param root: The root directory
     * \param options: File dialog options
     * \return
     */
    static std::string getExistingDirectory(
            Widget *parent = NULL, const std::string &caption = "Select directory", const std::string &dir = "", const std::string &root = "",
            FileDialogOptionEnum::Options options = FileDialogOptionEnum::None);

    /*!
     * \brief getOpenFileName
     * Returns the filename of a selected file
     * \param parent: Parent of the file dialog
     * \param caption: Text of the file dialog
     * \param dir: The directory that will be opened default
     * \param root: The root directory
     * \param filter: File selection filter(s)
     * \param selectedFilter: Index of the selected filter
     * \param options: File dialog options
     * \return
     */
    static std::string getOpenFileName(
            Widget *parent = NULL, const std::string &caption = "Open file", const std::string &dir = "", const std::string &root = "",
            const std::string &filter = "", std::string *selectedFilter = NULL,
            FileDialogOptionEnum::Options options = FileDialogOptionEnum::None);

    /*!
     * \brief getOpenFileNames
     * Returns a list of selected files
     * \param parent: Parent of the file dialog
     * \param caption: Text of the file dialog
     * \param dir: The directory that will be opened default
     * \param root: The root directory
     * \param filter: File selection filter(s)
     * \param selectedFilter: Index of the selected filter
     * \param options: File dialog options
     * \return
     */
    static std::list<std::string> getOpenFileNames(
            Widget *parent, const std::string &caption = "Open file(s)", const std::string &dir = "", const std::string &root = "",
            const std::string &filter = "", std::string *selectedFilter = NULL,
            FileDialogOptionEnum::Options options = FileDialogOptionEnum::None);

    /*!
     * \brief getSaveFileName
     * Returns the filename of a saved file
     * \param parent: Parent of the file dialog
     * \param caption: Text of the file dialog
     * \param dir: The directory that will be opened default
     * \param root: The root directory
     * \param filter: File selection filter(s)
     * \param selectedFilter: Index of the selected filter
     * \param options: File dialog options
     * \return
     */
    static std::string getSaveFileName(
            Widget *parent = NULL, const std::string &caption = "", const std::string &dir = "", const std::string &root = "",
            const std::string &filter = "Save file as", std::string *selectedFilter = NULL,
            FileDialogOptionEnum::Options options = FileDialogOptionEnum::None);

protected:
    FileDialog();
};
}

#endif // SUIFILEDIALOG_H
