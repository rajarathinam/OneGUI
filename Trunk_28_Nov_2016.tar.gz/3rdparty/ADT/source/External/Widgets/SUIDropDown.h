//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DropDown.
// !\description Header file for class SUI::DropDown.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIDROPDOWN_H
#define SUIDROPDOWN_H

#include "SUIWidget.h"
#include "SUIStringList.h"

#include "SUIIText.h"
#include "SUIIColorable.h"
#include "SUIIBGColorable.h"
#include "SUIIErrorMode.h"


namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the DropDown Widget
 */
class SUI_SHARED_EXPORT DropDown : public Widget, public IColorable, public IBGColorable, public StringList, public IErrorMode
{
public:
    virtual ~DropDown();

    /*!
     * \brief getCurrentIndex
     * Returns the index currently selected item in the DropDown box
     * \return
     */
    virtual int getCurrentIndex() const = 0;

    /*!
     * \brief getCurrentText
     * Returns the text currently selected in the DropDown box
     * \return
     */
    virtual std::string getCurrentText() const = 0;

    /*!
     * \brief setItemText
     * Sets the text for the item on the given index in the DropDown box
     * \param index: Index of item
     * \param text: text
     */
    virtual void setItemText(int index, const std::string &text) = 0;

    /*!
     * \brief getItemText
     * Returns the text for the given index in the DropDown box
     * \param index
     * \return
     */
    virtual std::string getItemText(int index) const = 0;

    /*!
     * \brief setCurrentIndex
     * Sets the item with index as the selected item in the DropDown box
     * \param index
     */
    virtual void setCurrentIndex(int index) = 0;

    /*!
     * \brief currentIndexChanged
     * Callback function that is called whenever the index of this widget changed.
     * Returns the new index
     */
    boost::function<void(int)> currentIndexChanged;

    /*!
     * \brief valueChanged
     * Callback function that is called when the value has changed.
     */
    boost::function<void()> valueChanged;

protected:
    DropDown();
};
}

#endif // SUIDROPDOWN_H
