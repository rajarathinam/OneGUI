#!/bin/bash
#
#-------------------------------------------------------------------------------
#   runCppLint.sh
#   
#   A script to run the static code checker Cpp lint
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"

# Variables
CPPLINT_PATH=$(pwd)/../../3rdparty/cpplint/cpplint.py
WORKING_DIRECTORY=$(pwd)/../../IGS/
EXPORT_PATH=$(pwd)/../../lint_report.txt
FILTER=-whitespace/braces,-whitespace/line_length,-legal
FILETYPES=hpp

# Functions
function print_message(){
	echo "******************************"
	echo "**** $1"
	echo "******************************"
}

# script
if [ "$1" == "help" ] || [ "$1" == "?" ]; then
	echo "******************************"
	echo "**** HELP"
	echo "****"
	echo "**** help: Displays this help documentation."
	echo "******************************"
	exit
fi

print_message "Starting analysis"

$CPPLINT_PATH --counting=detailed --filter=$FILTER --extensions=$FILETYPES \
    $( find $WORKING_DIRECTORY -name \*.hpp -or -name \*.cpp ) \
    2>$EXPORT_PATH

grep -e "Category" $EXPORT_PATH

ERRORS_TOTAL=$(grep -e "Total error" $EXPORT_PATH)
ERRORS_TOTAL=${ERRORS_TOTAL##* }

if [ "$ERRORS_TOTAL" == "0" ]; then
	print_message "analysis success!"
	exit 0
else
	print_message "analysis failed, $ERRORS_TOTAL messages found!"
	exit 1
fi

