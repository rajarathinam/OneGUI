#
#
#-------------------------------------------------------------------------------
#   runIT.sh
#   
#   A script to run Init Terminate Application
#-------------------------------------------------------------------------------

#Go to the current directory
cd "${0%/*}"

LD_LIBRARY_PATH=$(pwd)/../../targets/library:$(pwd)/../../3rdparty/ADT/library:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH

curDir=`pwd`

cd $(pwd)/../../targets/bin/

./InitTerminate &

cd $curDir
