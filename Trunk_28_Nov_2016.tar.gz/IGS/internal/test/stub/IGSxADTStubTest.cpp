/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADTStubTest.cpp
| Author       : Venugopal S
| Description  : Implementation of IGSxADT stub test
|
| ! \file        IGSxADTStubTest.cpp
| ! \brief       Implementation of IGSxADT stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxADTStubTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(IGSxADTStubTest, instanceTest)
{
    EXPECT_EQ(IGSxADT::ADT::getInstance(), IGSxADT::ADT::getInstance());
}

TEST_F(IGSxADTStubTest, getAdts)
{
    IGSxADT::MetaDescriptions Adts;
    IGSxADT::ADT::getInstance()->getAdts(Adts);
    EXPECT_EQ(Adts.size(), 12);

    IGSxADT::MetaDescription adt = Adts[0];
    EXPECT_STRCASEEQ(adt.name().c_str(), "Amplification Chain");
    EXPECT_STRCASEEQ(adt.subSystem().c_str(), "Laser Light Generation and Positioning");
    EXPECT_STRCASEEQ(adt.description().c_str(), "ADT for high Power Amplification Chain");
    EXPECT_STRCASEEQ(adt.htmlFile().c_str(), "/usr/local/msc/config/ADT//LAT_ACC.html");
}
