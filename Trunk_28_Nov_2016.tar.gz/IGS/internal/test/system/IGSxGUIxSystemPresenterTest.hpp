/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenterTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System Presenter test
|
| ! \file        IGSxGUIxSystemPresenterTest.hpp
| ! \brief       Header file for System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMPRESENTERTEST_HPP
#define IGSXGUIXSYSTEMPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxSystemPresenter.hpp"
#include "IGSxGUIxISystemView.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
template<typename T>
    ::testing::AssertionResult VectorsMatch(vector<T> Expected, vector<T> Actual)
{
        for (int i=0; i < Expected.size(); i++)
        {
            if (Expected.at(i)->getName().compare(Actual.at(i)->getName()) != 0)
            {
                return ::testing::AssertionFailure();
            }
        }
        return ::testing::AssertionSuccess();
}

template<typename T>
    ::testing::AssertionResult ListMatch(list<T> Expected, list<T> Actual)
{
        while ((!Expected.empty()) && (!Actual.empty()))
        {
            if (Expected.front().compare(Actual.front()) != 0)
            {
                return ::testing::AssertionFailure();
            }
            Expected.pop_front();
            Actual.pop_front();
        }
        return ::testing::AssertionSuccess();
}

class SystemPresenterTest : public ::testing::Test
{
 public:
  SystemPresenterTest(){}
  virtual ~SystemPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
class SystemViewStub : public IGSxGUI::ISystemView
{
 public:
    SystemViewStub() {}
    ~SystemViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {}
    void setActive(bool /*bActive*/) {}
    void showError() {}
    void showErrors() {}
    void updateSysFunction(DriverState::DriverStateEnum /*state*/, std::string /*strSysFunction*/, int /*nInitializedDriverCount*/, int /*nTerminatedDriverCount*/) {}
    void updateDriver(DriverState::DriverStateEnum /*state*/, std::string /*strDriver*/) {}
    void updateMainStatus(IGSxGUI::SystemState::SystemStateEnum /*state*/) {}
};

class SystemPresenterTestParam : public ::testing::TestWithParam<string>
{
 public:
    SystemPresenterTestParam(){}
    virtual ~SystemPresenterTestParam(){}
 protected:
    /*std::vector<IGSxGUI::Driver*> ExpectedDrivers;
    std::vector<IGSxGUI::SystemFunction*> ExpectedSysfunctions;*/

    MetaDescriptions Drivers;
    MetaDescriptions Sysfunctions;
 protected:
  virtual void SetUp()
  {
    Drivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
    Drivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
    Drivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
    Drivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
    Drivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));

    Sysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
    Sysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
    Sysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
    Sysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
    Sysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
    Sysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXSYSTEMPRESENTERTEST_HPP
