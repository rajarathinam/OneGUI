/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxConsumable.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for IGSKPI Consumable
|
| ! \file        IGSxConsumable.hpp
| ! \brief       Header file for IGSxKPI Consumable
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_CONSUMABLE_HPP
#define IGSXKPI_CONSUMABLE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxConsumableValueSet.hpp"

using std::string;
using std::vector;

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class Consumable
{
 public:
    explicit Consumable(IGSxKPI::KPIDefinition consumableDefinition);
    virtual ~Consumable();

    IGSxGUI::ConsumableValueSet *getValueSet(const std::string& name) const;
    vector<ConsumableValueSet *> getValueSets() const;

    string getName() const;
    string getDescription() const;

    void updateValue(IGSxKPI::KPIData kpiData);
    void updateValues(IGSxKPI::KPIDataList kpiDataList);

    typedef boost::signals2::signal<void (string, string, vector<double>)> ValueChanged;
    typedef ValueChanged::slot_type ValueChangedCallback;

    boost::signals2::connection registerForValueChanged(const ValueChangedCallback& cb);

 private:
    Consumable(Consumable const &);
    Consumable& operator=(Consumable const &);

    std::string m_name;  // Consumable name
    std::string m_desc;  // Consumable description

    vector<ConsumableValueSet*> m_ConsumableValueSets;
    ValueChanged m_valueChanged;
};

}  // namespace IGSxGUI
#endif  // IGSXKPI_CONSUMABLE_HPP
