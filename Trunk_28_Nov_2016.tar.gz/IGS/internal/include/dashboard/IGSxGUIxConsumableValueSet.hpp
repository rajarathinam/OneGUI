/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxConsumableValueSet.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for Consumable ValueSet
|
| ! \file        IGSxGUIxConsumableValueSet.hpp
| ! \brief       Header file for Consumable ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_CONSUMABLEVALUESET_HPP
#define IGSXKPI_CONSUMABLEVALUESET_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxKPI.hpp"

using std::string;
using std::vector;
using IGSxKPI::KPIValueSetDefinition;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {

class ConsumableValueSet
{
 public:
    explicit ConsumableValueSet(const KPIValueSetDefinition &consumableDefinition);
    virtual ~ConsumableValueSet();

    string getName() const;
    string getDescription() const;
    string getUnit() const;

    void addValue(vector<double> *valueList);
    void addTime(time_t time);
    vector<double> getValue();
    time_t getTime();

 private:
    ConsumableValueSet(ConsumableValueSet const &);
    ConsumableValueSet& operator=(ConsumableValueSet const &);

    string m_name;  // Consumable Value name
    string m_desc;  // Consumable Value description
    string m_unit;  // Consumable Value unit

    time_t m_time;  // Consumable Data Computed Time
    vector<double> m_valueList;
};
}  // namespace IGSxGUI
#endif  // IGSXKPI_CONSUMABLEVALUESET_HPP
