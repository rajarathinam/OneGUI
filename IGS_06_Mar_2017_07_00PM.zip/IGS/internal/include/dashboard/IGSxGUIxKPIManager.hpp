/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIManager.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for IGSKPI Manager
|
| ! \file        IGSxKPIManager.hpp
| ! \brief       Header file for IGSxKPI Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_MANAGER_HPP
#define IGSXKPI_MANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
#include "IGSxKPI.hpp"
#include <SUITimer.h>

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class KPIManager
{
 public:
    KPIManager();
    virtual ~KPIManager();

    void initialize();

    KPI* getKPI(const string& name) const;
    KPI* getSystemKPI(const string& name) const;
    KPI* getConsumable(const string& name) const;
    vector<KPI*> getKPIs() const;
    vector<KPI*> getSystemKPIs() const;
    vector<KPI*> getConsumables() const;

    void receiveKPIDataEvent(const IGSxKPI::KPIData& kpiData);

 private:
    KPIManager(KPIManager const &);
    KPIManager& operator=(KPIManager const &);

    void getKPIData();
    void getSystemKPIData();
    void getConsumableData();
    void onTimeout();

    void addKPI(const IGSxKPI::KPIDefinition& kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue);
    void addSystemKPI(const IGSxKPI::KPIDefinition& kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue);
    void addConsumable(const IGSxKPI::KPIDefinition& kpiDefinition, const std::string& valueSetName, const std::string& displayName, double factor, const std::string& type, double minValue, double maxValue);

    vector<KPI*> m_KPIs;
    vector<KPI*> m_SystemKPIs;
    vector<KPI*> m_Consumables;

    boost::shared_ptr<SUI::Timer> m_timer;
    time_t m_previousPollTime;

    static const int TIMER_INTERVAL;
    static const int TIME_SIX_HOURS_TWENTY_MINUTES;
    static const string KPI_WHITELIST_FILE;

    static const string STRING_KPI;
    static const string STRING_KPIS;
    static const string STRING_EMPTY;
    static const string STRING_SYSTEMKPI;
    static const string STRING_CONSUMABLE;
    static const string STRING_ATTRIBUTE_NAME;
    static const string STRING_ATTRIBUTE_VALUESET;
    static const string STRING_ATTRIBUTE_TYPE;
    static const string STRING_ATTRIBUTE_DISPLAYNAME;
    static const string STRING_ATTRIBUTE_FACTOR;
    static const string STRING_ATTRIBUTE_MIN;
    static const string STRING_ATTRIBUTE_MAX;
};

}  // namespace IGSxGUI
#endif  // IGSXKPI_MANAGER_HPP
