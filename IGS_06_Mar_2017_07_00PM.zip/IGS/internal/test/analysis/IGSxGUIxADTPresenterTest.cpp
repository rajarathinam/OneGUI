/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of ADT Presenter test
|
| ! \file        IGSxGUIxADTPresenterTest.cpp
| ! \brief       Implementation of ADT Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxADTPresenterTest.hpp"
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

TEST_F(ADTPresenterTest, Test1)
{
    IGSxGUI::ADTManager* pADTManager = new IGSxGUI::ADTManager;
    pADTManager->initialize();
    IGSxGUI::IADTView* ADTview = new IGSxGUI::ADTView(pADTManager);
    IGSxGUI::ADTPresenter* ADTpresenter = new IGSxGUI::ADTPresenter(ADTview, pADTManager);

    std::vector<IGSxGUI::ADT*> adts = ADTpresenter->getADTs();
    EXPECT_EQ(adts.size(), 12);

    ASSERT_TRUE(ADTpresenter->startADT(adts[0]->getName()));

    EXPECT_EQ(adts.size(), 12);

    if (ADTpresenter != NULL)
    {
        delete ADTpresenter;
        ADTpresenter = NULL;
    }
    if (ADTview != NULL)
    {
        delete ADTview;
        ADTview = NULL;
    }
    if (pADTManager != NULL)
    {
        delete pADTManager;
        pADTManager = NULL;
    }
}
