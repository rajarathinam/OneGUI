/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPI_impl.cpp
| Author       : Sabari Chandra Sekar
| Description  : Stub impementation of IGSxKPI interface
|
| ! \file        IGSxKPI_impl.cpp
| ! \brief       Stub impementation of IGSxKPI interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxKPI_impl.hpp"
#include <boost/bind.hpp>
#include <math.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int IGSxKPI::KPI_Stub::TIMER_INTERVAL = 60000;
const string IGSxKPI::KPI_Stub::STRING_UP = "up";
const string IGSxKPI::KPI_Stub::STRING_DOWN = "down";
const string IGSxKPI::KPI_Stub::STRING_RANDOM = "random";
const string IGSxKPI::KPI_Stub::STRING_KPI_NOTFOUND = "KPI Not found";

const int IGSxKPI::KPI_Stub::TIME_TOTAL_MINUTES = 380;
const int IGSxKPI::KPI_Stub::TIME_SIX_HOURS_TWENTY_MINUTES = 22800;

IGSxKPI::KPI *IGSxKPI::KPI_Stub::getInstance()
{
    static KPI_Stub _instance;
    return &_instance;
}

IGSxKPI::KPI* IGSxKPI::KPI::instance = IGSxKPI::KPI_Stub::getInstance();

IGSxKPI::KPI_Stub::KPI_Stub():
    m_timer(SUI::Timer::createTimer()),
    m_kpiDataCallback(NULL)
{
    m_timer->timeout = boost::bind(&KPI_Stub::onTimeout, this);
    m_kpiParser.loadKPI();
    m_mapKPIs = m_kpiParser.getKPIs();

    for (std::map<string,KPIINFO>::iterator it= m_mapKPIs.begin(); it!= m_mapKPIs.end(); ++it)
    {
        string name =  it->first;
        KPIINFO info = it->second;

        KPIValueSetDefinitionList kpiList;

        for (size_t i = 0; i < info.KpiValueSet.size(); i++)
        {
            kpiList.push_back(KPIValueSetDefinition(info.KpiValueSet[i].name, info.KpiValueSet[i].desc, info.KpiValueSet[i].unit));
        }
        m_kpidefs.push_back(KPIDefinition(name,info.desc,kpiList));
    }
    generateHistory();
}

void IGSxKPI::KPI_Stub::getKpis(IGSxKPI::KPIDefinitionList &kpis)
{
    kpis=m_kpidefs;
}

void IGSxKPI::KPI_Stub::getKpi(const std::string &kpiName, IGSxKPI::KPIDefinition &kpi)
{
    bool bFound = false;
    for(size_t i = 0; i < m_kpidefs.size(); i++)
    {
        if(m_kpidefs[i].name() == kpiName)
        {
            kpi=m_kpidefs[i];
            bFound = true;
            return;
        }
    }
    if (!bFound)
    {
        throw IGS::Exception(STRING_KPI_NOTFOUND);
    }
}

void IGSxKPI::KPI_Stub::getKpiData(const std::string& kpiName, time_t startTime, time_t stopTime, IGSxKPI::KPIDataList& kpiData)
{
    map<string, KPIINFO>::iterator itKPI = m_mapKPIs.find(kpiName);

    if (itKPI != m_mapKPIs.end())
    {
        KPIINFO kpiInfo = itKPI->second;
        vector<KpiValueSetDefinition> valSetDefinition = kpiInfo.KpiValueSet;

        for(size_t i = 0; i < valSetDefinition.size(); i++)
        {
            for(size_t j = 0; j < valSetDefinition[i].values.size(); j++)
            {
                if (valSetDefinition[i].times[j] >= startTime  && valSetDefinition[i].times[j] <= stopTime)
                {
                    KPIValueSet valSet;
                    valSet.push_back(valSetDefinition[i].values[j]);

                    KPIData data;
                    data.setName(valSetDefinition[i].name);
                    data.setTime(valSetDefinition[i].times[j]);
                    data.setValues(valSet);

                    kpiData.push_back(data);
                }
            }
        }
    }
    else
    {
        throw IGS::Exception("Error while retrieving KPI data");
    }
}

void IGSxKPI::KPI_Stub::subscribeToKpiData(const std::string& /*kpiName*/, const KPIDataCallback& cb)
{
    m_kpiDataCallback = cb;
    onTimeout();
}

void IGSxKPI::KPI_Stub::unsubscribeToKpiData(const std::string& /*kpiName*/)
{
    if (m_kpiDataCallback)
    {
        m_kpiDataCallback = NULL;
    }
}

void IGSxKPI::KPI_Stub::setKpiData(std::string kpiName, std::string kpiValueSetName, vector<double> values)
{
    map<string, KPIINFO>::iterator itKPI = m_mapKPIs.find(kpiName);

    if (itKPI != m_mapKPIs.end())
    {
        for(size_t i = 0; i < itKPI->second.KpiValueSet.size(); i++)
        {
            if (itKPI->second.KpiValueSet[i].name == kpiValueSetName)
            {
                for(size_t j = 0; j < values.size(); j++)
                {
                    itKPI->second.KpiValueSet[i].values.push_back(values[j]);
                }
            }
        }
    }

    KPIData data;
    data.setName(kpiValueSetName);
    data.setValues(values);

    if(!m_kpiDataCallback.empty())
    {
        m_kpiDataCallback(data);
    }
}

void IGSxKPI::KPI_Stub::onTimeout()
{
    for(map<string, KPIINFO>::iterator itKpi = m_mapKPIs.begin(); itKpi != m_mapKPIs.end(); itKpi++)
    {
        for(size_t i = 0; i < itKpi->second.KpiValueSet.size(); i++)
        {
            int startValue = itKpi->second.KpiValueSet[i].startValue;
            double currentValue = itKpi->second.KpiValueSet[i].currentValue;
            int minValue = itKpi->second.KpiValueSet[i].minValue;
            int maxValue = itKpi->second.KpiValueSet[i].maxValue;
            int stepsize = itKpi->second.KpiValueSet[i].stepSize;
            string direction = itKpi->second.KpiValueSet[i].direction;

            if(currentValue >= minValue && currentValue <= maxValue)
            {
                if(direction == STRING_UP)
                {
                    itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                    itKpi->second.KpiValueSet[i].times.push_back(time(0));

                    int noOfItemsInValueSet = itKpi->second.KpiValueSet[i].values.size();
                    int noOfTimesInValueSet = itKpi->second.KpiValueSet[i].times.size();

                    // Remove the times & values which are older than 6 hours 20 minutes
                    if (noOfItemsInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].values.erase(itKpi->second.KpiValueSet[i].values.begin(),itKpi->second.KpiValueSet[i].values.begin()+(noOfItemsInValueSet - TIME_TOTAL_MINUTES));
                    }
                    if (noOfTimesInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].times.erase(itKpi->second.KpiValueSet[i].times.begin(),itKpi->second.KpiValueSet[i].times.begin()+(noOfTimesInValueSet - TIME_TOTAL_MINUTES));
                    }

                    currentValue = currentValue + stepsize;
                    if(currentValue > maxValue)
                    {
                        currentValue = startValue;
                    }
                    itKpi->second.KpiValueSet[i].currentValue = currentValue;
                }
                else if(direction == STRING_DOWN)
                {
                    itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                    itKpi->second.KpiValueSet[i].times.push_back(time(0));

                    int noOfItemsInValueSet = itKpi->second.KpiValueSet[i].values.size();
                    int noOfTimesInValueSet = itKpi->second.KpiValueSet[i].times.size();

                    // Remove the times & values which are older than 6 hours 20 minutes
                    if (noOfItemsInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].values.erase(itKpi->second.KpiValueSet[i].values.begin(),itKpi->second.KpiValueSet[i].values.begin()+(noOfItemsInValueSet - TIME_TOTAL_MINUTES));
                    }
                    if (noOfTimesInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].times.erase(itKpi->second.KpiValueSet[i].times.begin(),itKpi->second.KpiValueSet[i].times.begin()+(noOfTimesInValueSet - TIME_TOTAL_MINUTES));
                    }

                    currentValue = currentValue - stepsize;
                    if(currentValue < minValue)
                    {
                        currentValue = startValue;
                    }
                    itKpi->second.KpiValueSet[i].currentValue = currentValue;
                }
                else if(direction == STRING_RANDOM)
                {
                    itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                    itKpi->second.KpiValueSet[i].times.push_back(time(0));

                    int noOfItemsInValueSet = itKpi->second.KpiValueSet[i].values.size();
                    int noOfTimesInValueSet = itKpi->second.KpiValueSet[i].times.size();

                    // Remove the times & values which are older than 6 hours 20 minutes
                    if (noOfItemsInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].values.erase(itKpi->second.KpiValueSet[i].values.begin(),itKpi->second.KpiValueSet[i].values.begin()+(noOfItemsInValueSet - TIME_TOTAL_MINUTES));
                    }
                    if (noOfTimesInValueSet > TIME_TOTAL_MINUTES)
                    {
                        itKpi->second.KpiValueSet[i].times.erase(itKpi->second.KpiValueSet[i].times.begin(),itKpi->second.KpiValueSet[i].times.begin()+(noOfTimesInValueSet - TIME_TOTAL_MINUTES));
                    }
                    double r = ((double) rand() / (RAND_MAX));
                    currentValue = minValue + r * (maxValue - minValue);
                    itKpi->second.KpiValueSet[i].currentValue = currentValue;
                }
            }
        }
    }
    m_timer->start(TIMER_INTERVAL);
}

void IGSxKPI::KPI_Stub::generateHistory()
{
    time_t currenttime = time(0) - TIME_SIX_HOURS_TWENTY_MINUTES;
    for (int i = 1; i <= TIME_TOTAL_MINUTES; i++)
    {
        for (map<string, KPIINFO>::iterator itKpi = m_mapKPIs.begin(); itKpi != m_mapKPIs.end(); itKpi++)
        {
            for(size_t i = 0; i < itKpi->second.KpiValueSet.size(); i++)
            {
                double startValue = itKpi->second.KpiValueSet[i].startValue;
                double currentValue = itKpi->second.KpiValueSet[i].currentValue;

                double minValue = itKpi->second.KpiValueSet[i].minValue;
                double maxValue = itKpi->second.KpiValueSet[i].maxValue;
                double stepsize = itKpi->second.KpiValueSet[i].stepSize;
                string direction = itKpi->second.KpiValueSet[i].direction;

                if(currentValue >= minValue && currentValue <= maxValue)
                {
                    if(direction == STRING_UP)
                    {
                        itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                        itKpi->second.KpiValueSet[i].times.push_back(currenttime);
                        currentValue = currentValue + stepsize;
                        if(currentValue > maxValue)
                        {
                            currentValue = startValue;
                        }
                        itKpi->second.KpiValueSet[i].currentValue = currentValue;
                    }
                    else if(direction == STRING_DOWN)
                    {
                        itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                        itKpi->second.KpiValueSet[i].times.push_back(currenttime);
                        currentValue = currentValue - stepsize;
                        if(currentValue < minValue)
                        {
                            currentValue = startValue;
                        }
                        itKpi->second.KpiValueSet[i].currentValue = currentValue;
                    }
                    else if(direction == STRING_RANDOM)
                    {
                        itKpi->second.KpiValueSet[i].values.push_back(currentValue);
                        itKpi->second.KpiValueSet[i].times.push_back(currenttime);
                        double r = ((double) rand() / (RAND_MAX));
                        currentValue = minValue + r * (maxValue - minValue);
                        itKpi->second.KpiValueSet[i].currentValue = currentValue;
                    }
                }
            }
        }
        currenttime = currenttime + 60;
    }
}
