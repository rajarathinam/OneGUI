/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManagerTest.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT Manager test
|
| ! \file        IGSxGUIxADTManagerTest.cpp
| ! \brief       Implementation of ADT Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxADTManagerTest.hpp"
#include "IGSxGUIxADTManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTManagerTest, Test1)
{
  IGSxGUI::ADTManager adtMgr;
  adtMgr.initialize();

  std::vector<IGSxGUI::ADT*> adts = adtMgr.retrieveAll();
  EXPECT_EQ(adts.size(), 12);

  IGSxGUI::ADT* adt = new IGSxGUI::ADT(IGSxADT::MetaDescription("TestName", "TestSubSystem", "TestDesc", "TestFile"));

  if (adt != NULL)
  {
    adtMgr.add(adt);
  }

  adts = adtMgr.retrieveAll();
  EXPECT_EQ(adts.size(), 13);

  IGSxGUI::ADT* requiredAdt = adtMgr.getADT("TestName");

  if (requiredAdt != NULL)
  {
    EXPECT_EQ(requiredAdt, adt);
  }

  adtMgr.remove(adt);

  adts = adtMgr.retrieveAll();
  EXPECT_EQ(adts.size(), 12);
}


