/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System plugin view
|
| ! \file        IGSxGUIxSystemView.hpp
| ! \brief       Header file for System plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMVIEW_HPP
#define IGSXGUIXSYSTEMVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <map>
#include <vector>
#include <string>
#include "IGSxGUIxISystemView.hpp"
#include "IGSxGUIxSystemPresenter.hpp"
#include <SUIColorEnum.h>
#include <SUIButton.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SystemView;
class Button;
class Label;
class GraphicsView;
class UserControl;
class ProgressBar;
class BusyIndicator;
class Timer;
}  // namespace SUI

struct structSysFunUiID
{
    SUI::UserControl* UCT;
    SUI::Label* lblName;
    SUI::GraphicsView* imvSignal;
    SUI::Label* lblStatus;
    SUI::ProgressBar* pgbProgress;
    structSysFunUiID()
    {
        UCT = NULL;
        lblName = NULL;
        imvSignal = NULL;
        lblStatus = NULL;
        pgbProgress = NULL;
    }
};
typedef structSysFunUiID SysFunUiID;
struct structDriverUiID
{
    SUI::UserControl* UCT;
    SUI::Label* lblName;
    SUI::GraphicsView* imvSignal;
    SUI::Label* lblStatus;
    SUI::ProgressBar* pgbProgress;
    SUI::BusyIndicator* bicProgress;
    structDriverUiID()
    {
        UCT = NULL;
        lblName = NULL;
        imvSignal = NULL;
        lblStatus = NULL;
        pgbProgress = NULL;
        bicProgress = NULL;
    }
};
typedef structDriverUiID DriverUiID;
struct structSysFunUiValues
{
    int TotalDriverCount;
    int InitializedDriverCount;
    int TerminatedDriverCount;
    int ProgressValueToBeIncreased;  // Indicates, A determined constant value for each system function, it will be added to the ProgressbarValue
    int ProgressbarValue;            // Indicates, each system function's progressbar value
    bool imageVisibility;
    bool progressbarVisibility;
    std::string NameText;
    std::string StatusText;
    std::string imagePath;
    structSysFunUiValues():
        NameText(""), StatusText(""), imagePath("")
    {
        TotalDriverCount = 0;
        InitializedDriverCount = 0;
        TerminatedDriverCount = 0;
        ProgressValueToBeIncreased = 0;
        ProgressbarValue = 0;
        imageVisibility = false;
        progressbarVisibility = false;
    }
};
typedef structSysFunUiValues SysFunUiValues;
struct structDriverUiValues
{
    std::string NameText;
    std::string StatusText;
    std::string SysFunctionName;
    std::string imagePath;
    bool imageVisibility;
    bool statusTextVisibility;
    bool statusBICVisibility;
    bool isImplemented;
    structDriverUiValues():
        NameText(""), StatusText(""), SysFunctionName(""), imagePath("")
    {
        imageVisibility = false;
        statusTextVisibility = false;
        statusBICVisibility = false;
        isImplemented = false;
    }
};
typedef structDriverUiValues DriverUiValues;
struct structSysFunInfo
{
    SysFunUiID UiID;
    SysFunUiValues UiValues;
    structSysFunInfo()
    {
    }
};
typedef structSysFunInfo SysFunInfo;
struct structDriverInfo
{
    DriverUiID UiID;
    DriverUiValues UiValues;
    structDriverInfo()
    {
    }
};
typedef structDriverInfo DriverInfo;
struct structMainStatusInfo
{
  SUI::ColorEnum::Color color;
  std::string strMessage;
  bool bBtnInitVisibility;
  bool bBtnTerminateVisibility;
  bool bBtnResolveVisibility;
  bool bClockVisibility;
  bool bLblTimerVisibility;
  structMainStatusInfo() : strMessage("")
  {
      color = SUI::ColorEnum::Standard;
      bBtnInitVisibility = false;
      bBtnTerminateVisibility = false;
      bBtnResolveVisibility = false;
      bClockVisibility = false;
      bLblTimerVisibility = false;
  }
};
typedef structMainStatusInfo MainStatusInfo;

namespace IGSxGUI{

class SystemView : public ISystemView
{
 public:
    explicit SystemView(DriverManager* pDriverManager);
    virtual ~SystemView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);
    virtual void showError();
    virtual void showErrors();
    virtual void updateSysFunction(const DriverState::DriverStateEnum& state, const std::string& strSysFunction, const int& nInitializedDriverCount, const int& nTerminatedDriverCount);
    virtual void updateDriver(const DriverState::DriverStateEnum& state, const std::string& strDriver);
    virtual void updateMainStatus(const SystemState::SystemStateEnum& state);

 private:
    SystemView(const SystemView &);
    SystemView& operator=(const SystemView &);
    void onInitializeButtonPressed();
    void onTerminateButtonPressed();
    void onResolveButtonPressed();

    void onBtnSysFun1Pressed();
    void onBtnSysFun2Pressed();
    void onBtnSysFun3Pressed();
    void onBtnSysFun4Pressed();
    void onBtnSysFun5Pressed();
    void onBtnSysFun6Pressed();
    void onBtnSysFun7Pressed();
    void onBtnDriver1Pressed();
    void onBtnDriver2Pressed();
    void onBtnDriver3Pressed();
    void onBtnDriver4Pressed();
    void onBtnDriver5Pressed();
    void onBtnDriver6Pressed();
    void onBtnDriver7Pressed();

    void manipulateSysFunSelection(const int &index, bool bShow);
    void manipulateDriverSelection(const int &index, bool bShow);
    void hideDrivers();
    void hideErrorInfo();
    void reShowErrorInfo(std::string strDriverName);
    void showErrorInfo(const Driver *driver, const int &uctIndex);
    void loadContainers();
    void init();
    void reInit();
    void hideProgressbar();
    void setButtonClickHandlers();
    void onTimerTimeout();
    void showDrivers(SystemFunction *strSysFunDesc, const int &uctIndex);
    void reShowDrivers(const SystemFunction* sysFunction);
    void loadDrivers(const std::string& sysFunctionName);
    void updateStatus(const SUI::ColorEnum::Color& color,
                          const SystemState::SystemStateEnum& state,
                          bool bBtnInitVisibility,
                          bool bBtnTerminateVisibility,
                          bool bBtnResolveVisibility,
                          bool bClockVisibility,
                          bool bLblTimerVisibility);
    void startTimer();
    void showElapsedTime() const;

    SUI::SystemView *sui;
    SystemPresenter *m_presenter;
    std::vector<SystemFunction*> m_listSysFunctions;
    std::vector<Driver*> m_listDrivers;

    std::vector<SUI::UserControl*> m_listSystemFunctionUCT;
    std::vector<SUI::UserControl*> m_listDriverUCT;

    std::vector<SUI::Label*> m_listSystemFunctionNameLabels;
    std::vector<SUI::GraphicsView*> m_listSystemFunctionSignalViews;
    std::vector<SUI::Label*> m_listSystemFunctionStatusLabels;
    std::vector<SUI::ProgressBar*> m_listSystemFunctionProgressBar;

    std::vector<SUI::Label*> m_listDriverNameLabels;
    std::vector<SUI::GraphicsView*> m_listDriverSignalViews;
    std::vector<SUI::Label*> m_listDriverStatusLabels;
    std::vector<SUI::ProgressBar*> m_listDriverProgressBar;
    std::vector<SUI::BusyIndicator*> m_listDriverBusyIndicator;

    std::map<std::string, SysFunInfo>  m_mapSystemFunctions;
    std::map<std::string, DriverInfo>  m_mapDrivers;

    static const std::string m_sysFunStates[];
    static const std::string m_driverStates[];

    static const std::string SYSTEMVIEW_LOAD_FILE;

    static const std::string IMAGE_NOT_OK;
    static const std::string IMAGE_OK;
    static const std::string IMAGE_CLOCK;
    static const std::string IMAGE_LOGO;

    static const std::string STRING_DRIVERS;
    static const std::string STRING_INFORMATION;
    static const std::string STRING_SEPERATOR;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STRING_SLASH;
    static const std::string STRING_SINGLE_SPACE;
    static const std::string STRING_COLON;
    static const std::string STRING_ZERO;
    static const std::string STRING_EMPTY;

    static const std::string STYLECLASS_DEFAULT;
    static const std::string STYLECLASS_DEFAULT_SMALL;
    static const std::string STYLECLASS_SELECTED;
    static const std::string STYLECLASS_SELECTED_SMALL;

    static const int SYSTEM_TIMER_INTERVAL;

    MainStatusInfo m_mainStatus;
    SystemFunction* m_sysFunctionLastSelected;
    int m_indexSysFunctionLastSelected;
    int m_indexDriverLastSelected;

    boost::shared_ptr<SUI::Timer> m_timer;
    std::string m_nameCurrentSelectedSysFunction;
    std::string m_nameCurrentSelectedDriver;
    time_t m_startTime;
    int m_totaldrivercount;
    bool m_bSystemViewActive;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMVIEW_HPP
