/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface file                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIStandAloneView.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface file for Standalone View
|
| ! \file        IGSxITS_stub.hpp
| ! \brief       Interface file for Standalone View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISTANDALONEVIEW_HPP
#define IGSXGUIXISTANDALONEVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class IStandAloneView
{
 public:
    IStandAloneView() {}
    virtual ~IStandAloneView() {}
    virtual void show(std::string strPluginName) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXISTANDALONEVIEW_HPP
