#include <QObject>
#include <QString>

class Worker : public QObject {
    Q_OBJECT

public:
    Worker();
    ~Worker();

public slots:
    void process();

signals:
    void finished();

private:
    // add your variables here
};
