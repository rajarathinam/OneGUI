#include "Worker.h"
#include "IGSxGUIxPluginFactory.hpp"
#include <string>

Worker::Worker() {
}

Worker::~Worker() {
}

// Start processing data.
void Worker::process() {
    std::cout << "Worker called: " << std::endl;
    IGSxGUI::PluginFactory::getInstance().initialize();
    emit finished();
}
