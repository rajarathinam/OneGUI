/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriver.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of driver
|
| ! \file        IGSxGUIxDriver.cpp
| ! \brief       Implementation of driver
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDriver.hpp"
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const char* IGSxGUI::Driver::NOT_IMPLEMENTED_TAG = "[NOT IMPLEMENTED]";

IGSxGUI::Driver::Driver(const MetaDescription& metaDescription, const DriverState::DriverStateEnum &driverState):
    m_name(metaDescription.name()),
    m_displayName(metaDescription.description()),
    m_driverState(driverState)
{
    try {
        if (metaDescription.description().length() > strlen(NOT_IMPLEMENTED_TAG) &&
            boost::starts_with(metaDescription.description(), NOT_IMPLEMENTED_TAG))
        {
            m_isImplemented = false;
            m_displayName.erase(0, strlen(NOT_IMPLEMENTED_TAG));
        } else {
            m_isImplemented = true;
        }
    } catch (boost::bad_lexical_cast& /*ex*/) {
        m_isImplemented = true;
    }
}

IGSxGUI::Driver::~Driver()
{
}

DriverState::DriverStateEnum IGSxGUI::Driver::getState() const
{
    return m_driverState;
}

std::string IGSxGUI::Driver::getName() const
{
    return m_name;
}

std::string IGSxGUI::Driver::getDisplayName() const
{
    return m_displayName;
}

bool IGSxGUI::Driver::isImplemented() const
{
    return m_isImplemented;
}

void IGSxGUI::Driver::updateDriverState(const DriverState::DriverStateEnum &driverState)
{
    if (m_driverState != driverState)
    {
        m_driverState = driverState;

        if (m_isImplemented)
        {
            if (!m_stateChanged.empty())
            {
                m_stateChanged(driverState, this->getName());
            }
            if (!m_stateDriverChanged.empty())
            {
                m_stateDriverChanged(driverState, this->getName());
            }
        }
    }
}

void IGSxGUI::Driver::registerToDriverStateChanged(const stateDriverChanged& cb, bool bIsFromSysFun)
{
    if (bIsFromSysFun)
    {
        m_stateChanged = cb;
    } else {
        m_stateDriverChanged = cb;
    }
}
