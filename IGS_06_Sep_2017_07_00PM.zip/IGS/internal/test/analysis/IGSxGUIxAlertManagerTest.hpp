/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertManagerTest.hpp
| Author       : Venugopal S
| Description  : Header file for Alert Manager test
|
| ! \file        IGSxGUIxAlertManagerTest.hpp
| ! \brief       Header file for Alert Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTMANAGERTEST_HPP
#define IGSXGUIXALERTMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include "IGSxGUIxAlertManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class AlertManagerTest : public ::testing::Test
{
 public:
    AlertManagerTest() :m_AlertManager(NULL)
    {
    }
    virtual ~AlertManagerTest(){}

 protected:
  IGSxGUI::AlertManager* m_AlertManager;

  virtual void SetUp()
  {
      m_AlertManager = new IGSxGUI::AlertManager();
  }

  virtual void TearDown()
  {
      delete m_AlertManager;
      m_AlertManager = NULL;
  }
};
#endif  // IGSXGUIXALERTMANAGERTEST_HPP
