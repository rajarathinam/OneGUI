/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboard.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin
|
| ! \file        IGSxGUIxDashboard.cpp
| ! \brief       Implementation of Dashboard plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDashboard.hpp"
#include "IGSxGUIxDashboardView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Dashboard::Dashboard():m_dashboardView(NULL), m_kpiManager(new KPIManager())
{
}

IGSxGUI::Dashboard::~Dashboard()
{
    if (m_dashboardView != NULL)
    {
        delete m_dashboardView;
        m_dashboardView = NULL;
    }
    if (m_kpiManager != NULL)
    {
        delete m_kpiManager;
        m_kpiManager = NULL;
    }
}

void IGSxGUI::Dashboard::initialize()
{
    if (m_kpiManager != NULL)
    {
        m_kpiManager->initialize();
    }
}

void IGSxGUI::Dashboard::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_dashboardView == NULL)
    {
        m_dashboardView = new IGSxGUI::DashboardView(m_kpiManager);
    }
    m_dashboardView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Dashboard::setActive(bool bActive)
{
    if (m_dashboardView != NULL)
    {
        m_dashboardView->setActive(bActive);
    }
}
