/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.hpp
| Author       : Venugopal S
| Description  : Header file for CPD Manager
|
| ! \file        IGSxGUIxCPDManager.hpp
| ! \brief       Header file for CPD Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCONTROLMANAGER_HPP
#define IGSXGUIXCONTROLMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                    l            |
|----------------------------------------------------------------------------*/

#include <boost/signals2.hpp>

#include "IGSxCTRL.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ControlManager
{
 public:
    ControlManager();
    virtual ~ControlManager();

    void initialize();

    IGSxCTRL::Who::WhoEnum getWhoIsInControl();
    bool requestControl();
    void releaseControl();
    bool canIGetControl();

    typedef boost::signals2::signal<void(IGSxCTRL::Who::WhoEnum)> controlChanged;
    typedef controlChanged::slot_type controlChangedCallback;

    boost::signals2::connection registerToControlChanged(const controlChangedCallback& cb);

 private:
    ControlManager(ControlManager const &);
    ControlManager& operator=(ControlManager const &);

    void onControlChanged(const IGSxCTRL::Who::WhoEnum& who);

    IGSxCTRL::Who::WhoEnum m_who;
    controlChanged m_controlChanged;
};

}  // namespace IGSxGUI
#endif // IGSXGUIXCONTROLMANAGER_HPP
