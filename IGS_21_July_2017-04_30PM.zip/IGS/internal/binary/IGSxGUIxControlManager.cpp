
/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxControlManager.cpp
| Author       : Arjan Tekelenburg
| Description  : Control manager Implementation
|
| ! \file        IGSxGUIxControlManager.cpp
| ! \brief       Control Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <iostream>
#include <boost/bind.hpp>
#include "IGSxGUIxControlManager.hpp"

#include "IGSxLOG.hpp"
#include "IGSxCOMMON.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::ControlManager::ControlManager():
    m_who(IGSxCTRL::Who::NONE)
{
}

IGSxGUI::ControlManager::~ControlManager()
{
}

void IGSxGUI::ControlManager::initialize()
{
    try
    {
        IGSxCTRL::Control::getInstance()->subscribeToControlChanged(boost::bind(&IGSxGUI::ControlManager::onControlChanged, this, _1));
        m_who = IGSxCTRL::Control::getInstance()->whoIsInControl();
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }
}

void IGSxGUI::ControlManager::onControlChanged(const IGSxCTRL::Who::WhoEnum &who)
{
    const std::string message = "Control changed from " + IGSxCTRL::Who::toString(m_who) + " to " + IGSxCTRL::Who::toString(who);
    IGS_INFO(message);
    m_who = who;

    if (!m_controlChanged.empty())
    {
        m_controlChanged(m_who);
    }
}

IGSxCTRL::Who::WhoEnum IGSxGUI::ControlManager::getWhoIsInControl()
{
    return m_who;
}

bool IGSxGUI::ControlManager::canIGetControl()
{
    return (m_who == IGSxCTRL::Who::GUI);
}

bool IGSxGUI::ControlManager::requestControl()
{
    bool returnValue = false;
    try
    {
        returnValue = IGSxCTRL::Control::getInstance()->requestControl();
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    return returnValue;
}

void IGSxGUI::ControlManager::releaseControl()
{
    try
    {
        IGSxCTRL::Control::getInstance()->releaseControl();
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }
}

boost::signals2::connection IGSxGUI::ControlManager::registerToControlChanged(const controlChangedCallback &cb)
{
    return m_controlChanged.connect(cb);
}
