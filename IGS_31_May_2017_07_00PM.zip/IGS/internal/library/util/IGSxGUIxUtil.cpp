/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation file for Utility class
|
| ! \file        IGSxGUIxUtil.cpp
| ! \brief       Implementation file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxUtil.hpp"
#include <QDialog>
#include <QScrollArea>
#include <QApplication>
#include <QTableView>
#include <QHeaderView>
#include <QLabel>
#include <QPushButton>
#include <QTableWidgetItem>
#include <QTextCodec>
#include <string>
#include <algorithm>
#include <SUIDialog.h>
#include <SUIBaseWidget.h>
#include <SUITableWidget.h>
#include <SUILabel.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Util::Util()
{
}

void IGSxGUI::Util::setGeometry(SUI::Widget* widget, int x, int y, int width, int height)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    QWidget* qparent = qwidget->parentWidget();

    if (qwidget != NULL)
    {
        qwidget->setGeometry(x, qparent->y() + y, width, height);
    }
}

void IGSxGUI::Util::setWindowFrame(SUI::Dialog* dialog, bool enable)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);

    if (qdialog != NULL)
    {
        if (enable)
        {
            qdialog->setWindowFlags(Qt::Dialog);
        } else {
            qdialog->setWindowFlags(Qt::Sheet | Qt::FramelessWindowHint);
            qdialog->setFixedSize(qdialog->geometry().size());
        }
    }
}

void IGSxGUI::Util::disableScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL)
    {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");

        if (scrollArea != NULL)
        {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
    }
}

void IGSxGUI::Util::setParent(SUI::Widget* widget, SUI::Widget *parent)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    SUI::BaseWidget* suiparent = dynamic_cast<SUI::BaseWidget*>(parent);

    QWidget* topWidget = suiparent->getWidget()->nativeParentWidget();
    qwidget->setParent(topWidget);
}

void IGSxGUI::Util::processEvents(){
    QApplication::processEvents();
}

const std::string IGSxGUI::Util::elideText(const std::string& str, int fontsize, int width)
{
    std::string elidedtext = str;
    if ((width > 0) && (!str.empty()))
    {
           QFont font("Roboto", fontsize);
           QFontMetrics fm(font);
           QString intext(str.c_str());
           QString outtext = fm.elidedText(intext, Qt::ElideRight, width);

           // To do , last char is not printable char('...')
           QChar ch = outtext.at(outtext.length() - 1);
           if (!ch.toAscii())
           {
           outtext.chop(4);
           elidedtext = outtext.toStdString() + "...";
           } else {
              elidedtext = outtext.toStdString();
           }
    }
    return elidedtext;
}

void IGSxGUI::Util::sort(int column, SUI::TableWidget* widget, SortOrder::SortOrderEnum order)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableWidget = dynamic_cast<QTableView*>(baseWidget->getWidget());

    QAbstractItemModel* m = tableWidget->model();
    m->sort(column, (order == SortOrder::Descending)? Qt::DescendingOrder : Qt::AscendingOrder);
}

void IGSxGUI::Util::setScalable(SUI::TableWidget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    tableView->verticalHeader()->setResizeMode(QHeaderView::ResizeToContents);
}

void IGSxGUI::Util::setAwesome(SUI::Widget *widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, SUI::ColorEnum::Color color)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QChar character;

    switch (icon)
    {
        case IGSxGUI::AwesomeIcon::AI_fa_exclamation:
            character = 0xf12a;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle:
            character = 0xf071;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_times:
            character = 0xf00d;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_times_circle:
            character = 0xf057;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_bell:
            character = 0xf0f3;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_sort_desc:
            character = 0xf0dd;
            break;
        case IGSxGUI::AwesomeIcon::AI_fa_sort_asc:
            character = 0xf0de;
            break;
        default:
            character = 0xf2c2;
            break;
    }

    switch (baseWidget->getObjectType())
    {
        case SUI::ObjectType::Label:
        {
            QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
            if (qlabel != NULL)
            {
                qlabel->setStyleSheet(QString("font-family: FontAwesome; color: ").append(QString::fromStdString(SUI::ColorEnum::toString(color))));
                qlabel->setText(character);
            }
            break;
        }
        case SUI::ObjectType::Button:
        {
            QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
            if (qpushbutton != NULL)
            {
                qpushbutton->setStyleSheet(QString("font-family: FontAwesome; color: ").append(QString::fromStdString(SUI::ColorEnum::toString(color))));
                qpushbutton->setText(character);
            }
            break;
        }
        case SUI::ObjectType::TableWidgetItem:
        {
            QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(baseWidget);
            if (tableItem != NULL)
            {
               tableItem->setFont(QFont("FontAwesome"));
               QTextCodec::setCodecForCStrings(QTextCodec::codecForName("utf8"));
               tableItem->setText(character);
               setColor(widget, color, NULL);
            }
            break;
        }
        default:
        {
            // We do not support all widgets
        }
    }
}

void IGSxGUI::Util::setColor(SUI::Widget* widget, SUI::ColorEnum::Color color, SUI::TableWidget* tableWidget)
{
    QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(widget);

    if (tableItem != NULL)
    {
        switch (color)
        {
            case SUI::ColorEnum::White:
            {
                tableItem->setForeground(Qt::white);
                break;
            }
            case SUI::ColorEnum::Red:
            {
                tableItem->setForeground(Qt::red);
                break;
            }
            case SUI::ColorEnum::Yellow:
            {
                tableItem->setForeground(Qt::yellow);
                break;
            }
            case SUI::ColorEnum::Blue:
            {
                tableItem->setForeground(QColor::fromRgb(10, 168, 251));
                break;
            }
            case SUI::ColorEnum::Black:
            {
                tableItem->setForeground(Qt::black);
                break;
            }
            default:
            {
                tableItem->setForeground(Qt::white);
                break;
            }
        }
        if (tableWidget != NULL)
        {
            SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
            QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
            tableView->update();
        }
    }
}
