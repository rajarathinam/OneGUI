/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIValueSetTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI ValueSet test
|
| ! \file        IGSxGUIxKPIValueSetTest.cpp
| ! \brief       Implementation of KPI ValueSet test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxKPIValueSetTest.hpp"
#include "IGSxGUIxKpiValueSet.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPIValueSetTestParam,
                        ::testing::Values("MEAN"));

TEST_P(KPIValueSetTestParam, Test1)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);

    if (valset != NULL)
    {
        std::string name = valset->getName();
        EXPECT_STRCASEEQ(name.c_str(), "MEAN");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test2)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);

    if (valset != NULL)
    {
        std::string desc = valset->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "MEAN");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test3)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_1);
    if (valset != NULL)
    {
        std::string unit = valset->getUnit();
        EXPECT_STRCASEEQ(unit.c_str(), "mJ");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test4)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string name = valset->getName();
        EXPECT_STRCASEEQ(name.c_str(), "MAX");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test5)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string desc = valset->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "MAX");

        delete valset;
        valset = NULL;
    }
}

TEST_P(KPIValueSetTestParam, Test6)
{
    IGSxGUI::KPIValueSet* valset = new IGSxGUI::KPIValueSet(valsetdef_2);
    if (valset != NULL)
    {
        std::string unit = valset->getUnit();
        EXPECT_STRCASEEQ(unit.c_str(), "µm");

        delete valset;
        valset = NULL;
    }
}
