/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPIManagerTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI Manager test
|
| ! \file        IGSxGUIxKPIManagerTest.cpp
| ! \brief       Implementation of KPI Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxKPIManagerTest.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPIManagerTestParam,
                        ::testing::Values("Test"));

TEST_P(KPIManagerTestParam, Test1)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    if (kpiMgr != NULL)
    {
        kpiMgr->initialize();
    }
    IGSxGUI::KPI* kpi = kpiMgr->getKPI("EUV_Pulse_Energy_Internal");

    if (kpi != NULL)
    {
        std::string name = kpi->getName();
        EXPECT_STRCASEEQ(name.c_str(), "EUV_Pulse_Energy_Internal");
    }

    if (kpiMgr != NULL)
    {
        delete kpiMgr;
        kpiMgr = NULL;
    }
}

TEST_P(KPIManagerTestParam, Test2)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    if (kpiMgr != NULL)
    {
        kpiMgr->initialize();
    }

    IGSxGUI::KPI* kpi = kpiMgr->getKPI("EUV_Pulse_Energy_Internal");
    if (kpi != NULL)
    {
        std::string desc = kpi->getDescription();
        EXPECT_STRCASEEQ(desc.c_str(), "EUV Pulse Energy - Internal");
    }

    if (kpiMgr != NULL)
    {
        delete kpiMgr;
        kpiMgr = NULL;
    }
}
