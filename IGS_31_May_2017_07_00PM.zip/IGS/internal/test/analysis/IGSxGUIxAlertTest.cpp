/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertTest.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert test
|
| ! \file        IGSxGUIxAlertTest.cpp
| ! \brief       Implementation of Alert test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxAlertTest.hpp"
#include "IGSxGUIxAlert.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(AlertTest, Test_1)
{
    IGSxERR::ActivatedAlert newAlert(111, "121", time(NULL), IGSxERR::AlertSeverity::ERROR, "USER1" , "DEV1");

    IGSxGUI::Alert Alert(newAlert);

    int logId = Alert.getLogId();
    EXPECT_EQ(111, logId);

    std::string logCode = Alert.getLogCode();
    EXPECT_STRCASEEQ("121", logCode.c_str());

    IGSxERR::AlertSeverity::AlertSeverityEnum severity = Alert.getSeverity();
    EXPECT_EQ(IGSxERR::AlertSeverity::ERROR, severity);

    std::string userText = Alert.getUserText();
    EXPECT_STRCASEEQ("USER1", userText.c_str());

    std::string devText = Alert.getDeveloperText();
    EXPECT_STRCASEEQ("DEV1", devText.c_str());
}
