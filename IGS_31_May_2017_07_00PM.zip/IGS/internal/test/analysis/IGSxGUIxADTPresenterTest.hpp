/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenterTest.hpp
| Author       : Raja
| Description  : Header file for ADT Presenter test
|
| ! \file        IGSxGUIxADTPresenterTest.hpp
| ! \brief       Header file for ADT Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTRESENTERTEST_HPP
#define IGSXGUIXADTPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <string>
#include "IGSxGUIxADTPresenter.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class ADTPresenterTest : public ::testing::Test
{
 public:
  ADTPresenterTest(){}
  virtual ~ADTPresenterTest(){}

 protected:
  IGSxGUI::ADTManager* m_adtManager;

  virtual void SetUp()
  {
      m_adtManager = new IGSxGUI::ADTManager();

      IGSxADT::MetaDescriptions adtDescriptions;
      adtDescriptions.push_back(IGSxADT::MetaDescription("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "LAT_ACC.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Collector Cooling", "Environmental control", "Collector Cooling ADT", " CCD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "DGD_CCS.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "LEF_FFA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("GVA", "Gas and vacuum", "GVA ADT", "GVA.html"));
      adtDescriptions.push_back(IGSxADT::MetaDescription("HP-RGA", "Environmental control", "HP-RGA ADT", "RCA_RCM.html"));

      for (size_t i = 0; i < adtDescriptions.size(); i++)
      {
          IGSxGUI::ADT* adt = new IGSxGUI::ADT(adtDescriptions[i]);
          m_adtManager->add(adt);
      }
  }
  virtual void TearDown()
  {
      std::vector<IGSxGUI::ADT*> adtList = m_adtManager->retrieveAll();
      for (size_t i = 0; i < adtList.size(); i++)
      {
          m_adtManager->remove(adtList[i]);
      }

      delete m_adtManager;
      m_adtManager = NULL;
  }
};

class ADTViewStub : public IGSxGUI::IADTView
{
 private:
    bool m_status;
 public:
    ADTViewStub() : m_status(false){}
    ~ADTViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {
        m_status = true;
    }
    void setActive(bool /*bActive*/) {
        m_status = true;
    }
    void updateStatus(const IGS::Result& /*result*/) {
        m_status = true;
    }

    void setStatus(bool bstatus)
    {
        m_status = bstatus;
    }
    bool getStatus()
    {
        return m_status;
    }
};

#endif  // IGSXGUIXADTPRESENTERTEST_HPP
