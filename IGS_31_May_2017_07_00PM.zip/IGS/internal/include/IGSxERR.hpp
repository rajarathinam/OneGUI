/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR.hpp
| Author       : Thijs Jacobs
| Description  : Interface to retrieve the XER event log
|
| ! \file        IGSxERR.hpp
| ! \brief       Interface to retrieve the XER event log
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXERR_HPP
#define IGSXERR_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <ctime>
#include <boost/function.hpp>

#include "IGSxCOMMON.hpp"


namespace IGSxERR {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// alert severity
class AlertSeverity
{
public:
    typedef enum
    {
    EVENT = 0, // not expected
    WARNING,
    ERROR,
    ALARM
    } AlertSeverityEnum;

    static std::string toString(AlertSeverityEnum severity)
    {
        static std::string s[] = {"EVENT","WARNING","ERROR","ALARM"};
        return s[severity];
    }
};


// alert definition
class ActivatedAlert
{
public:
    explicit ActivatedAlert(int _logId, const std::string& _logCode,
        time_t _time, AlertSeverity::AlertSeverityEnum _severity,
        const std::string& _userText, const std::string& _developerText):
        m_logId(_logId),
        m_logCode(_logCode),
        m_time(_time),
        m_severity(_severity),
        m_userText(_userText),
        m_developerText(_developerText) {}
    virtual ~ActivatedAlert() {}

    int logId() const {return m_logId;}
    std::string logCode() const {return m_logCode;}
    time_t time() const {return m_time;}
    AlertSeverity::AlertSeverityEnum severity() const {return m_severity;}
    std::string userText() const {return m_userText;}
    std::string developerText() const {return m_developerText;}

    void setLogId(int _logId) {m_logId = _logId;}
    void setLogCode(const std::string& _logCode) {m_logCode = _logCode;}
    void setTime(time_t _time) {m_time = _time;}
    void setSeverity(AlertSeverity::AlertSeverityEnum _severity) {m_severity = _severity;}
    void setUserText(const std::string& _userText) {m_userText = _userText;}
    void setDeveloperText(const std::string& _developerText) {m_developerText = _developerText;}

private:
    int m_logId; // unique identifier for this alert
    std::string m_logCode; // textual representation of the log id
    time_t m_time; // time when this alert was raised
    AlertSeverity::AlertSeverityEnum m_severity; // the severity of this alert
    std::string m_userText; // the alert description for 1st and 2nd line engineers
    std::string m_developerText; // the alert description for software developers
};
typedef std::vector<ActivatedAlert> ActiveAlertList;


class DeactivatedAlert
{
public:
    explicit DeactivatedAlert(int _logId): m_logId(_logId) {}
    virtual ~DeactivatedAlert() {}

    int logId() const {return m_logId;}
    void setLogId(int _logId) {m_logId = _logId;}

private:
    int m_logId; // unique identifier for this alert
};


// callback type alert status changed event
typedef boost::function<void (const ActivatedAlert&)> AlertRaisedCallback;
typedef boost::function<void (const DeactivatedAlert&)> AlertDeactivatedCallback;
/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class EventLogger
{
// functions throw IGS::exception
public:
    static EventLogger* getInstance() {return instance;}

    // get the event log as a fully qualified filename
    // returns empty string when not found
    virtual std::string getEventLog() = 0;
    virtual std::string getPreviousEventLog() = 0;

protected:
    // instance
    virtual ~EventLogger() {}
    static EventLogger* instance;
};

// Alert interface
class Alert
{
// functions throw IGS::exception
public:
    static Alert* getInstance() {return instance;}

    // get the active alerts
    virtual void getActiveAlerts(ActiveAlertList& alerts) = 0;

    // alert notifications
    virtual void subscribeToAlertRaised(const AlertRaisedCallback& cb) = 0;
    virtual void unsubscribeToAlertRaised() = 0;
    virtual void subscribeToAlertDeactivated(const AlertDeactivatedCallback& cb) = 0;
    virtual void unsubscribeToAlertDeactivated() = 0;

protected:
    // instance
    virtual ~Alert() {}
    static Alert* instance;
};

} // namespace IGSxERR

#endif // IGSXERR_HPP

