/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystem.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System plugin
|
| ! \file        IGSxGUIxSystem.hpp
| ! \brief       Header file for System plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEM_HPP
#define IGSXGUIXSYSTEM_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxISystem.hpp"
#include "IGSxGUIxISystemView.hpp"
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class System:public ISystem
{
 public:
    System();
    virtual ~System();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void showCPD(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);
    virtual void subscribeForSystemState(const SystemStateChangedCallback& cb);
    virtual void unsubscribeForSystemState(const SystemStateChangedCallback& cb);
    virtual IGSxGUI::SystemState::SystemStateEnum retrieveSystemState();
    virtual void notifyAlertPopup(bool bAlertPopupRaised);

 private:
    System(System const &);
    System& operator=(System const &);
    IGSxGUI::ISystemView *m_systemView;
    IGSxGUI::ICPDView *m_cpdView;
    DriverManager* m_driverManager;
    CPDManager* m_cpdManager;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEM_HPP
