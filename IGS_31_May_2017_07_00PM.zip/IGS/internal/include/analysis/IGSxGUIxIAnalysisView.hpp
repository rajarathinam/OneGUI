/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIAdvancedDiagnosticsView.hpp
| Author       : Venugopal S
| Description  : Interface file for Advanced Diagnostics view
|
| ! \file        IGSxGUIxIAdvancedDiagnosticsView.hpp
| ! \brief       Interface file for Advanced Diagnostics view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIANALYSISVIEW_HPP
#define IGSXGUIXIANALYSISVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class IAnalysisView
{
 public:
    IAnalysisView() {}
    virtual ~IAnalysisView() {}

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIANALYSISVIEW_HPP
