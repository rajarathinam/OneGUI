/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard Presenter
|
| ! \file        IGSxGUIxDashboardPresenter.cpp
| ! \brief       Implementation of Dashboard Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDashboardPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::DashboardPresenter::DashboardPresenter(IGSxGUI::IDashboardView* view, KPIManager *pKPIManager):
    m_pKPIManager(pKPIManager),
    m_view(view)
{

}

IGSxGUI::DashboardPresenter::~DashboardPresenter()
{
    // Do not delete m_view or kpimanager, we are not the owner.
    m_connections.clear();
}

void IGSxGUI::DashboardPresenter::subscribeForEvents()
{
    vector<IGSxGUI::KPI*> kpis = m_pKPIManager->getKPIs();

    for (size_t i = 0; i < kpis.size(); ++i)
    {
        boost::signals2::connection connection = kpis[i]->registerForValueChanged(boost::bind(&DashboardPresenter::onKPIDataUpdated, this, _1,_2,_3));
        m_connections.push_back(connection);
    }
}

void IGSxGUI::DashboardPresenter::unsubscribeForEvents()
{
    for (size_t i = 0; i < m_connections.size(); ++i)
    {
        m_connections.at(i).disconnect();
    }

    m_connections.clear();
}

vector<IGSxGUI::KPI*> IGSxGUI::DashboardPresenter::getKPIs()
{
    return m_pKPIManager->getKPIs();
}

vector<IGSxGUI::KPIValueSet *> IGSxGUI::DashboardPresenter::getKPIValueSets(std::string kpiName)
{
    vector<IGSxGUI::KPIValueSet *> valueSets;
    KPI* kpi = m_pKPIManager->getKPI(kpiName);

    if (kpi != NULL)
    {
        valueSets = kpi->getValueSets();
    }

    return valueSets;
}

vector<IGSxGUI::Consumable *> IGSxGUI::DashboardPresenter::getConsumables()
{
    return m_pKPIManager->getConsumables();
}

vector<IGSxGUI::ConsumableValueSet *> IGSxGUI::DashboardPresenter::getConsumableValueSets(std::string consumableName)
{
    vector<IGSxGUI::ConsumableValueSet *> valueSets;
    Consumable* consumable = m_pKPIManager->getConsumable(consumableName);

    if (consumable != NULL)
    {
        valueSets = consumable->getValueSets();
    }

    return valueSets;
}

void IGSxGUI::DashboardPresenter::onKPIDataUpdated(string kpiName, string valueSetName, vector<double> values) //  KPI to presenter
{
    m_view->updateKPI(kpiName,valueSetName,values);
}
