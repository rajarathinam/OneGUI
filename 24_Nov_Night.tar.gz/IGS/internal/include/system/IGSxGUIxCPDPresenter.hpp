/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for CPD presenter
|
| ! \file        IGSxGUIxCPDPresenter.hpp
| ! \brief       Header file for CPD presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDPRESENTER_HPP
#define IGSXGUIXCPDPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class CPDPresenter
{
 public:
    explicit CPDPresenter(ICPDView* view, CPDManager* pCPDManager);
    virtual ~CPDPresenter();

    std::vector<CPD*> getCPDs();
    bool startCPD(std::string cpdName);

 private:
    CPDPresenter(const CPDPresenter& cpdPresenter);
    CPDPresenter& operator=(const CPDPresenter& cpdPresenter);

    void onCPDStopped(std::string strCPD, IGS::Result result);

    CPDManager* m_pCPDManager;
    ICPDView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDPRESENTER_HPP
