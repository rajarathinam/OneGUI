/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStandAlonePresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Standalone Presenter
|
| ! \file        IGSxGUIxStandAlonePresenter.hpp
| ! \brief       Header file for Standalone Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSTANDALONEPRESENTER_HPP
#define IGSXGUIXSTANDALONEPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIStandAloneView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class StandAlonePresenter
{
 public:
    explicit StandAlonePresenter(IGSxGUI::IStandAloneView* view);
    virtual ~StandAlonePresenter();
 private:
    IGSxGUI::IStandAloneView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSTANDALONEPRESENTER_HPP
