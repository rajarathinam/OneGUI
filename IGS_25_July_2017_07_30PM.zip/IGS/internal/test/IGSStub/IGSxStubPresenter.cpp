/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxStubPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Stub Presenter
|
| ! \file        IGSxStubPresenter.cpp
| ! \brief       Implementation of Stub Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxStubPresenter.hpp"
#include <boost/bind.hpp>
#include <string>
#include <list>
#include "IGSStub.hpp"
#include "IGSxERR_impl.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxCTRL_impl.hpp"
#include "IGSxLOG.hpp"

using IGSxITS::InitTerminate;
using IGSxKPI::KPI;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::StubPresenter::TIMER_INTERVAL = 60000;
const char* IGSxGUI::StubPresenter::STUB_INITIALIZING = "Initializing...";
const char* IGSxGUI::StubPresenter::STUB_TERMINATING  = "Terminating...";
const char* IGSxGUI::StubPresenter::STUB_INITIALIZED  = "Initialized";
const char* IGSxGUI::StubPresenter::STUB_TERMINATED   = "Terminated";

IGSxGUI::StubPresenter::StubPresenter(IGSxGUI::IStubView* view):
    m_timer(SUI::Timer::createTimer())
{
    m_view = view;
    m_timer->timeout = boost::bind(&StubPresenter::onTimeout, this);

    try
    {
        IGSxKPI::KPI::getInstance()->getKpis(m_KPIDefinitionList);
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }
    m_timer->start(TIMER_INTERVAL);
}

IGSxGUI::StubPresenter::~StubPresenter()
{
    m_timer->stop();
}

void IGSxGUI::StubPresenter::Initialize() const
{
    m_view->showStatus(STUB_INITIALIZING);
    try
    {
        InitTerminate::getInstance()->initializeSystem(boost::bind(&IGSxGUI::StubPresenter::onInitializeComplete, this, _1));
    } catch (IGS::Exception & ex)
    {
        IGS_ERROR(ex.what());
    }
}

void IGSxGUI::StubPresenter::Terminate() const
{
    m_view->showStatus(STUB_TERMINATING);
    try
    {
        InitTerminate::getInstance()->terminateSystem(boost::bind(&IGSxGUI::StubPresenter::onTerminateComplete, this, _1));
    } catch (IGS::Exception & ex)
    {
       IGS_ERROR(ex.what());
    }
}

void IGSxGUI::StubPresenter::fetchKPIInfo() const
{
    for (unsigned i = 0; i < m_KPIDefinitionList.size(); i++)
    {
        KPIDefinition kpiDef;
        KPIDataList dataList;
        string kpiName = m_KPIDefinitionList[i].name();

        time_t now = time(NULL);

        try
        {
            IGSxKPI::KPI::getInstance()->getKpi(kpiName, kpiDef);
        } catch (IGS::Exception& ex) {
            IGS_ERROR(ex.what());
        }

        try
        {
            IGSxKPI::KPI::getInstance()->getKpiData(kpiName, now - 3600, now, dataList);
        } catch (IGS::Exception& ex) {
            IGS_ERROR(ex.what());
        }
        string strUptime;
        vector<double> values;
        for (size_t i = 0; i < dataList.size(); i++)
        {
            KPIData data = dataList[i];

            for (size_t j = 0; j < data.values()->size(); j++)
            {
                values.push_back(data.values()->at(j));
            }
            char buffer[20];
            std::time_t time = data.time();
            std::strftime(buffer, 20, "%H:%M:%S", std::localtime(&time));
            strUptime = buffer;
        }
        m_view->updateKPI(kpiName,strUptime,values);
    }
}

void IGSxGUI::StubPresenter::onInitializeComplete(const IGS::Result& result) const
{
    if (result == IGS::OK)
    {
        m_view->showStatus(STUB_INITIALIZED);
    }
}

void IGSxGUI::StubPresenter::onTerminateComplete(const IGS::Result& result) const
{
    if (result == IGS::OK)
    {
        m_view->showStatus(STUB_TERMINATED);
    }
}

void IGSxGUI::StubPresenter::updateKPI(const std::string &kpiName, const std::string &upTime, const vector<double> &values) const
{
    m_view->updateKPI(kpiName,upTime,values);
}

void IGSxGUI::StubPresenter::enableKPIGeneration(bool enable)
{
    static_cast<IGSxKPI::KPI_Stub*>(KPI::getInstance())->enableKPIGeneration(enable);
}

void IGSxGUI::StubPresenter::onTimeout()
{
    fetchKPIInfo();
    m_timer->start(TIMER_INTERVAL);
}

std::list<std::string> IGSxGUI::StubPresenter::getSystemFunctions() const
{
    IGSxITS::MetaDescriptions metaDescriptions;

    try
    {
        metaDescriptions = InitTerminate::getInstance()->getSysfuns();
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    std::list<std::string> systemFunctions;
    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        systemFunctions.push_back(metaDescriptions[i].name());
    }
    return systemFunctions;
}

std::list<std::string> IGSxGUI::StubPresenter::getSystemFunctionsReadable() const
{
    IGSxITS::MetaDescriptions metaDescriptions;

    try
    {
        metaDescriptions = InitTerminate::getInstance()->getSysfuns();
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    std::list<std::string> systemFunctions;
    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        systemFunctions.push_back(metaDescriptions[i].name() + ": " + metaDescriptions[i].description());
    }
    return systemFunctions;
}


std::list<std::string> IGSxGUI::StubPresenter::getDrivers(const std::string& systemFuncion) const
{
    IGSxITS::MetaDescriptions metaDescriptions;

    try
    {
        metaDescriptions = InitTerminate::getInstance()->getDrivers(systemFuncion);
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    std::list<std::string> drivers;
    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        drivers.push_back(metaDescriptions[i].name());
    }
    return drivers;
}

std::list<std::string> IGSxGUI::StubPresenter::getKPIs() const
{
    KPIDefinitionList kpiDefinitionList;
    std::list<std::string> KPIs;
    try
    {
        IGSxKPI::KPI::getInstance()->getKpis(kpiDefinitionList);
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (size_t i = 0; i < kpiDefinitionList.size(); i++)
    {
        KPIs.push_back(kpiDefinitionList[i].name());
    }
    return KPIs;
}

std::list<std::string> IGSxGUI::StubPresenter::getValueSet(const std::string &kpi) const
{
    KPIDefinition kpiDef;
    KPIValueSetDefinitionList* kpiValueSetDefList;
    std::list<std::string> valueSets;

    try
    {
        IGSxKPI::KPI::getInstance()->getKpi(kpi,kpiDef);
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }

    kpiValueSetDefList = kpiDef.values();

    for (size_t i = 0; i < kpiValueSetDefList->size(); i++)
    {
        KPIValueSetDefinition kpiValSetDef = kpiValueSetDefList->at(i);
        valueSets.push_back(kpiValSetDef.name());
    }
    return valueSets;
}


void IGSxGUI::StubPresenter::setDriverStatus(const std::string &driver, const std::string &state)
{
    for (int enumInt = IGSxITS::DriverState::DS_TERMINATING; enumInt <= IGSxITS::DriverState::DS_RECOVERY_REQUIRED; enumInt++)
    {
        IGSxITS::DriverState::DriverStateEnum enumState = static_cast<IGSxITS::DriverState::DriverStateEnum>(enumInt);
        if (IGSxITS::DriverState::toString(enumState) == state)
        {
            static_cast<IGSxITS::InitTerminate_Stub*>(InitTerminate::getInstance())->setDriverStatus(driver, enumState);
        }
    }
}

void IGSxGUI::StubPresenter::setKPIValue(const std::string &kpiName, const std::string &kpiValueSetName, const vector<double> &values)
{
    static_cast<IGSxKPI::KPI_Stub*>(IGSxKPI::KPI::getInstance())->setKpiData(kpiName,kpiValueSetName,values);
}

void IGSxGUI::StubPresenter::enableThrowExceptions(bool enable)
{
    static_cast<IGSxITS::InitTerminate_Stub*>(InitTerminate::getInstance())->setThrowExceptions(enable);
}

void IGSxGUI::StubPresenter::enableGenerateAlerts(bool generateAlerts)
{
    static_cast<IGSxERR::Alert_Stub*>(IGSxERR::Alert_Stub::getInstance())->enableGenerateAlerts(generateAlerts);
}

void IGSxGUI::StubPresenter::raiseAlert(std::string logCode, std::string userText, IGSxERR::AlertSeverity::AlertSeverityEnum severity)
{
    static_cast<IGSxERR::Alert_Stub*>(IGSxERR::Alert_Stub::getInstance())->raiseAlert(logCode, userText, severity);
}

void IGSxGUI::StubPresenter::deactivateRandomAlert()
{
    static_cast<IGSxERR::Alert_Stub*>(IGSxERR::Alert_Stub::getInstance())->deactivateRandomAlert();
}

void IGSxGUI::StubPresenter::setControl(IGSxCTRL::Who::WhoEnum who)
{
    static_cast<IGSxCTRL::CTRL_Stub*>(IGSxCTRL::CTRL_Stub::getInstance())->setWhoIsInControl(who);
}
