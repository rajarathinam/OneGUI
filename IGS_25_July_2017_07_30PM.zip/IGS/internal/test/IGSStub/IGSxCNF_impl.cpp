/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCNF_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxCNF interface
|
| ! \file        IGSxCNF_impl.cpp
| ! \brief       Stub impementation of IGSxCNF interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxCNF_impl.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxCNF::Configuration *IGSxCNF::CNF_Stub::getInstance()
{
    static CNF_Stub _instance;
    return &_instance;
}

IGSxCNF::Configuration* IGSxCNF::Configuration::instance = IGSxCNF::CNF_Stub::getInstance();

std::string IGSxCNF::CNF_Stub::getMachineId()
{
    return "62175";
}

std::string IGSxCNF::CNF_Stub::getReleaseId()
{
    return "3.2.6 RC8800";
}

