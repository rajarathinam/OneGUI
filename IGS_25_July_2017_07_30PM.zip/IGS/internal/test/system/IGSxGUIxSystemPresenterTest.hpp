/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenterTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System Presenter test
|
| ! \file        IGSxGUIxSystemPresenterTest.hpp
| ! \brief       Header file for System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMPRESENTERTEST_HPP
#define IGSXGUIXSYSTEMPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <string>
#include "IGSxGUIxSystemPresenter.hpp"

using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SystemPresenterTest : public ::testing::Test
{
 public:
  SystemPresenterTest(){}
  virtual ~SystemPresenterTest(){}
 protected:
  MetaDescriptions m_drivers;
  MetaDescriptions m_sysfunctions;

  virtual void SetUp()
  {
      m_sysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
      m_sysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
      m_sysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
      m_sysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
      m_sysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
      m_sysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));

      m_drivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
      m_drivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
      m_drivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
      m_drivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
      m_drivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
class SystemViewStub : public IGSxGUI::ISystemView
{
 private:
  bool m_status;
 public:
    SystemViewStub() : m_status(false){}
    ~SystemViewStub() {}
    void show(SUI::Container* /*MainScreenContainer*/, bool /*bIsFirstTimeDisplay*/) {
        m_status = true;
    }
    void setActive(bool /*bActive*/) {
        m_status = true;
    }
    void termintationCompleted() {
        m_status = true;
    }
    void initializationCompleted() {
        m_status = true;
    }
    void updateSysFunction(const IGSxGUI::SystemState::SystemStateEnum& /*state*/, const std::string& /*strSysFunction*/, const int& /*nInitializedDriverCount*/, const int& /*nTerminatedDriverCount*/) {
        m_status = true;
    }
    void updateDriver(const DriverState::DriverStateEnum& /*state*/, const std::string& /*strDriver*/) {
        m_status = true;
    }
    void updateMainStatus(const IGSxGUI::SystemState::SystemStateEnum& /*state*/) {
        m_status = true;
    }

    void notifyAlertPopup(bool /*bAlertPopupRaised*/) {
        m_status = true;
    }

    void setStatus(bool bstatus)
    {
        m_status = bstatus;
    }
    bool getStatus()
    {
        return m_status;
    }

    void controlChanged(const IGSxCTRL::Who::WhoEnum /*who*/)
    {
    }
};
#endif  // IGSXGUIXSYSTEMPRESENTERTEST_HPP
