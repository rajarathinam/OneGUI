/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxApplication.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxStubView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string STRING_RESOURCE = "/Resource/";
const std::string STRING_SIMULATION = "simulation";

int main(int argc, char *argv[])
{
    int result = 1;

    boost::shared_ptr<IGSxGUIxApplication> app(new IGSxGUIxApplication(argc, argv, get_current_dir_name() + STRING_RESOURCE));

    if (argc > 1)
    {
        std::string strPluginName(argv[1]);
        if (strPluginName == STRING_SIMULATION)
        {
            // Start stub implementations
            dynamic_cast<IGSxKPI::KPI_Stub*>(IGSxKPI::KPI::getInstance())->enableKPIGeneration(true);
            IGSxGUI::IStubView *stubView;
            stubView = new IGSxGUI::StubView();
            if (stubView != NULL)
            {
                stubView->show();
            }
        }
    }
    result = app->exec();
    return result;
}


