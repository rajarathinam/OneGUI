/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCTRL.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface to retrieve control information
|
| ! \file        IGSxCTRL.hpp
| ! \brief       Interface to retrieve control information
| ! \details
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXCTRL_HPP
#define IGSXCTRL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <boost/function.hpp>


namespace IGSxCTRL {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/

class Who
{
public:
    typedef enum
    {
    NONE = 0, // not expected
    TESTMANAGER,
    GUI,
    SCANNER
    } WhoEnum;

    static std::string toString(WhoEnum who)
    {
        static std::string s[] = {"NONE","TESTMANAGER","GUI","SCANNER"};
        return s[who];
    }
};

typedef boost::function<void (const Who::WhoEnum&)> ControlChangedCallback;

/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class Control
{
// functions throw IGS::exception
public:
    static Control* getInstance() {return instance;}

    virtual bool requestControl() = 0;
    virtual void releaseControl() = 0;
    virtual bool canIGetControl() = 0;
    virtual Who::WhoEnum whoIsInControl() = 0;

    // control changed event
    virtual void subscribeToControlChanged(const ControlChangedCallback& cb) = 0;
    virtual void unsubscribeToControlChanged() = 0;

protected:
    // instance
    virtual ~Control() {}
    static Control* instance;
};

} // namespace IGSxCNF

#endif // IGSXCTRL_HPP
