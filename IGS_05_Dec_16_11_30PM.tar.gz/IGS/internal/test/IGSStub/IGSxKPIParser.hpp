/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIParser.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for KPI Parser
|
| ! \file        IGSxKPIParser.hpp
| ! \brief       Header file for KPI Parser
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPIPARSER_HPP
#define IGSXKPIPARSER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <map>

using std::string;
using std::vector;
using std::map;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    string name;
    string desc;
    string unit;
    vector<double> values;
    time_t time;
    int startValue;
    double currentValue;
    int minValue;
    int maxValue;
    int stepSize;
    string direction;
} KpiValueSetDefinition;

typedef struct
{
    string desc;
    vector<KpiValueSetDefinition> KpiValueSet;
} KPIINFO;

namespace IGSxKPI {
class KPIParser
{
 public:
    KPIParser();
    virtual ~KPIParser(){}
    void loadKPI();
    map<string, KPIINFO> getKPIs();

    void loadKPIDefinition();
    void loadKPIValueSetDefinition();

 private:
    KPIParser(KPIParser const&);
    void operator=(KPIParser const&);

    map<string, KPIINFO> m_mapKPIDefinitions;

    static const string KPI_DEFINITION_FILE;
    static const string KPI_VALUESET_DEFINITION_FILE;

    static const string STRING_KPI;
    static const string STRING_KPIS;
    static const string STRING_STARTVALUE;
    static const string STRING_MIN;
    static const string STRING_MAX;
    static const string STRING_STEPSIZE;
    static const string STRING_DIRECTION;
    static const string STRING_VALUE;
    static const string STRING_UNIT;
    static const string STRING_DESCRIPTION;
    static const string STRING_VALUESETS;
    static const string STRING_ATTRIBUTE;
    static const string STRING_ATTRIBUTE_NAME;
};
}  // namespace IGSxKPI

#endif  // IGSXKPIPARSER_HPP
