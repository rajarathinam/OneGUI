/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard View
|
| ! \file        IGSxGUIxDashboardView.hpp
| ! \brief       Header file for Dashboard View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDVIEW_HPP
#define IGSXGUIXDASHBOARDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxDashboardPresenter.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxKPIManager.hpp"
#include <SUIPlotWidget.h>
#include <SUIProgressBar.h>
#include <SUIGroupBox.h>
#include <SUIPlotHistogramItem.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class DashboardView;
class Label;
class UserControl;
}

namespace IGSxGUI {
class DashboardView : public IDashboardView
{
 public:
    explicit DashboardView(KPIManager* pKpiManager);
    virtual ~DashboardView();

    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool bActive);
    virtual void updateKPI(string kpiName, string valueSetName, vector<double> values);

    void constructGraphs();
    void constructKPItable1();
    void constructKPItable2();
    void constructConsumableTable();
    void init();
    void setHandlers();
    void onConsumable1HoverOn();
    void onConsumable1HoverOff();

    void onConsumable2HoverOn();
    void onConsumable2HoverOff();

    void onUCTNormalKPIHoverOn();
    void onUCTNormalKPIHoverOff();

    void loadContainers();

private:
    DashboardView(const DashboardView&);
    DashboardView& operator=(const DashboardView&);

    SUI::DashboardView *sui;
    DashboardPresenter *m_presenter;
    std::vector<KPI*> m_listKPIs;
    std::map<std::string, SUI::PlotHistogramItem *> mapPlotHistogram;

    //Noraml KPI data
    std::vector<SUI::UserControl*> m_listNormalKPIUCTs;
    std::vector<SUI::GroupBox*> m_listNormalKPIGroupBoxes;
    std::vector<SUI::Label*> m_listNormalKPINames;
    std::vector<SUI::Label*> m_listNormalKPICategories;
    std::vector<SUI::Label*> m_listNormalKPITimes;
    std::vector<SUI::Label*> m_listNormalKPIValues;
    std::vector<SUI::Label*> m_listNormalKPIUnits;

    //System KPI data
    std::vector<SUI::UserControl*> m_listSystemKPIUCTs;
    std::vector<SUI::Label*> m_listSystemKPINames;
    std::vector<SUI::Label*> m_listSystemKPICategories;
    std::vector<SUI::Label*> m_listSystemKPITimers;
    std::vector<SUI::Label*> m_listSystemKPIValues;
    std::vector<SUI::Label*> m_listSystemKPIUnits;


    static const std::string LOAD_FILE_DASHBOARD;
    static const std::string STRING_CONSUMABLE1;
    static const std::string STRING_CONSUMABLE2;
    static const std::string STRING_CONSUMABLE3;
    static const std::string STRING_CONSUMABLE4;
    static const std::string STRING_CONSUMABLE5;
    static const std::string STRING_CONSUMABLE6;
    static const std::string STRING_CONSUMABLE7;
    static const std::string STRING_CONSUMABLE8;
    static const std::string STRING_CONSUMABLE9;










};
}  // namespace IGSxGUI
#endif  // IGSXGUIXDASHBOARDVIEW_HPP
