/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.hpp
| Author       : Raja
| Description  : Header file for Parameterpopup View
|
| ! \file        IGSxGUIxParameterpopupView.hpp
| ! \brief       Header file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXPARAMETERPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include "IGSxGUIxIParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
#include <boost/lexical_cast.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class ParameterpopupView;
}  // namespace SUI

namespace IGSxGUI{

class ParameterpopupView : public IParameterpopupView
{
 public:
    explicit ParameterpopupView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager);
    virtual ~ParameterpopupView();
    virtual void show(int booltype);

  void onCloseButtonPressed();
  void setParameterName(const std::string &name);
  void setParameterValue(const std::string &value, int booltype);
  void setParameterDefaultValue(const std::string &defaultvalue);
  std::string getParameterName() const;
  std::string getParameterValue() const;
  std::string getParameterDefaultValue() const;
  void close();
  void onParamValueTextChanged(const std::string& value);
  MachineconstantsManager* m_pMachineconstantsManager;


  typedef boost::signals2::signal<void (std::string, std::string)> ValueChanged;
  typedef ValueChanged::slot_type ValueChangedCallback;

  boost::signals2::connection registerForValueChanged(const ValueChangedCallback& cb);

  void onUpdatebuttonPressed();
  void onCloseButtonHoverEntered();
  void onCloseButtonHoverLeft();
  void onResetButtonPressed();
  void setParent(SUI::Widget *parent);
  SUI::Label* getParameterNameType() const;
  void onRbtnChecked();
  void clearLineEdit();
private:
    ParameterpopupView(const ParameterpopupView &);
    ParameterpopupView& operator=(const ParameterpopupView &);
    void init();
    bool validateIntegerText(ParameterData* parameterData, const std::string& value);
    bool validateUnsigendIntegerText(ParameterData* parameterData, const std::string& value);
    bool validateDoubleText(ParameterData* parameterData, const std::string& value);
    void eraseEnteredCharFromLineEdit(std::string &text, int pos);
    bool validateText(const std::string &value);
    void showWarning(ParameterData *parameterData);
    template <typename TYPE>
    bool tryLexicalConvert(const std::string& value) {
        try {
            boost::lexical_cast<TYPE>(value);
            return true;
        }
        catch (...)
        {
            return false;
        }
    }
    void regularExpressionCheckDouble(const std::string &value);
    void regularExpressionCheckUnsignedInteger(const std::string &value);
    void regularExpressionCheckInteger(const std::string &value);
    void formatParamNameBack(std::string &name);

    ValueChanged m_valueChanged;
    SUI::ParameterpopupView *sui;
    static const int BUTTON_SIZE;
    static const int MAXIMUM_DOUBLE_PRECISION;

    static const std::string PARAMETERPOPUPVIEW_LOAD_FILE;
    static const std::string STRING_PARAMETERPOPUPVIEW_SHOWN;
    static const std::string radiobutton_12px_normal_fill;
    static const std::string radiobutton_12px_normal;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXPARAMETERPOPUPVIEW_HPP
