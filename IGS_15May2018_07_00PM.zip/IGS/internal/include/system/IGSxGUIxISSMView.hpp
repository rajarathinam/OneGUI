/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerView.hpp
| Author       : Saket
| Description  : Header file for System state manager View
|
| ! \file        IGSxGUIxSystemStateManagerView.hpp
| ! \brief       Header file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISYSTEMSTATEMANAGERVIEW_HPP
#define IGSXGUIXISYSTEMSTATEMANAGERVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Container;
}  // namespace SUI

namespace IGSxGUI{

enum TabType
{
    SYSTEM_STATE = 0, LASER_CONTROL, ENV_CONTROL, TIMING_CONTROL, DROPLET_CONTROL, TIN_CONTROL
};

class ISSMView
{
 public:
    ISSMView() {}
    virtual ~ISSMView() {}
    virtual void show(SUI::Container*, bool) = 0;
    virtual void setActive(bool) = 0;
};

}

#endif
