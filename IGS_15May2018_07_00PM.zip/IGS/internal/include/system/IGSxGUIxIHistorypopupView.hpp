#ifndef IGSXGUIXIHISTORYPOPUPVIEW_HPP
#define IGSXGUIXIHISTORYPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIContainer.h>
#include <string>
#include "IGSxCOMMON.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IHistorypopupView
{
 public:
    IHistorypopupView() {}
    virtual ~IHistorypopupView() {}
    virtual void show() = 0;
};
}  // namespace IGSxGUI
#endif // IGSXGUIXIHISTORYPOPUPVIEW_HPP
