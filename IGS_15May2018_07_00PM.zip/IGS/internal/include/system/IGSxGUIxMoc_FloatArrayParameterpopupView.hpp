#ifndef IGSXGUIXMOC_FLOATPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXMOC_FLOATPARAMETERPOPUPVIEW_HPP

//----------------------------------------------------------------------------|
//                          Forward Declarations                              |
//----------------------------------------------------------------------------|
namespace IGSxGUI {
        class FloatArrayParameterpopupView;
} //namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class LineEdit;
class Button;
class Label;
class GroupBox;
class TableWidget;

class FloatArrayParameterpopupView
{
private:
        FloatArrayParameterpopupView();

    void setupSUI(const char *xmlFileName);
    void setupSUIContainer(const char *xmlFileName, SUI::Container *container);
    void loadObjects(SUI::ObjectList *objectList);

    SUI::Dialog *dialog;
    SUI::Button *btnPopCancel;
    SUI::Button *btnClose;
    SUI::Button *btnPopReset;
    SUI::Button *btnPopUpdate;
    SUI::Label *lblDefaultValue;
    SUI::Label *lblParameterName;
    SUI::TableWidget *tawFloatArrayParamaterPopup;
    SUI::TableWidget *tawFloatArrayParamaterPopupForXButton;


    SUI::GroupBox *gbxUnrecommendedValue;
    SUI::Label *lblUnrecommendedValueName;
    SUI::Label *lblUnrecommendedValueDesc;

    SUI::GroupBox *gbxResetValues;
    SUI::Label *lblResetValuesTitle;
    SUI::Button *btnResetYes;
    SUI::Button *btnResetNo;
    SUI::GroupBox *gbxCancelValuesConfirm;
    SUI::Label *lblCancelValuesConfirmTitle;
    SUI::Button *btnCancelConfirmYes;
    SUI::Button *btnCancelConfirmNo;

    friend class ::IGSxGUI::FloatArrayParameterpopupView;
};
} //namespace SUI
#endif // IGSXGUIXMOC_FLOATPARAMETERPOPUPVIEW_HPP
