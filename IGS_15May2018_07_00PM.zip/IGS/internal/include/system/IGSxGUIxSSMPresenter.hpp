/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMPresenter.hpp
| Author       : Saket k
| Description  : Header file for SSM presenter
|
| ! \file        IGSxGUIxSSMPresenter.hpp
| ! \brief       Header file for SSM presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSSMPRESENTER_HPP
#define IGSXGUIXSSMPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <string>
#include "IGSxGUIxISSMView.hpp"
#include "IGSxGUIxSSMManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SSMPresenter
{
 public:
    explicit    SSMPresenter(ISSMView& view, SSMManager& ssmManager);
    virtual ~SSMPresenter();
    void initHandlers();

 private:
    SSMPresenter(const SSMPresenter& ssmPresenter);
    SSMPresenter& operator=(const SSMPresenter& ssmPresenter);

    void stateChanged(IGSxGUI::InnerState innerState, const int index);

    SSMManager& m_SSMManager;
    ISSMView& m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSSMPRESENTER_HPP
