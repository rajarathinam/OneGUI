/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerView.hpp
| Author       : Saket
| Description  : Header file for System state manager View
|
| ! \file        IGSxGUIxSystemStateManagerView.hpp
| ! \brief       Header file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMSTATEMANAGERSTATE_HPP
#define IGSXGUIXSYSTEMSTATEMANAGERSTATE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class UserControl;
class Button;
}  // namespace SUI

namespace IGSxGUI{

enum InnerState{REACHABLE=0, ACTIVE, TRANSITION,  DISABLED};

class State
{
public:
    State(SUI::UserControl* control, SUI::Button* button, InnerState innerState, const int id, const int index);
    SUI::UserControl* getUserControl();
    void show();
    void hide();
    void setInnerState(InnerState innerState);
    InnerState getInnerState() const;
    void initButton(IGSxGUI::InnerState innerState);
    boost::function<void (InnerState, int, int) > clicked;
    void setId(const int id);
    int getId() const;
private:
    void buttonClicked();
    SUI::UserControl* mUsercontrol;
    SUI::Button* mButton;
    InnerState mCurrentState;
    int mId;
    int mIndex;

};

typedef std::vector<IGSxGUI::State*> StateList;

}

#endif
