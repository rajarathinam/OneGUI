/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR.hpp
| Author       : Matthijs den Uijl
| Description  : Proxy interface for FCBxPAR, retrieval of parameter data
|
| ! \file        IGSxPAR.hpp
| ! \brief       Proxy interface for FCBxPAR, retrieval of parameter data
|                Indicators
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2017, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXPAR_HPP
#define IGSXPAR_HPP

#include <string>
#include <vector>
#include "boost/shared_ptr.hpp"
#include "boost/function.hpp"

namespace IGSxPAR
{
  //interface used for the visitor pattern of the IValue specializations, see 
  //https://en.wikipedia.org/wiki/Visitor_pattern
  class IValueVisitor;
  //base class for the value types of uint, int, bool, float and float array
  class IValue
  {
     public: 
        virtual ~IValue(){};

        virtual const std::string& name() const = 0;
        virtual void accept( IValueVisitor& visitor) const = 0;
  };
  
  //Parameter category
  enum CategoryType
  {
     DESIGN = 0,
     CALIBRATION
  };
  
  static std::string toString(CategoryType category)
  {
      static std::string s[] = {"DESIGN","CALIBRATION"};
      return s[category];
  }
  
  //interface used for the visitor pattern of the ParameterType specializations
  //see https://en.wikipedia.org/wiki/Visitor_pattern
  class IParameterTypeVisitor;
  
  //base class of the parameter type. contains the generic information
  // of a parameter.
  class ParameterType
  {
     public:
        explicit ParameterType( CategoryType category, bool write_access):
            m_category( category),
            m_write_access( write_access )
        {
        }
        
        virtual ~ParameterType(){}
        
        CategoryType  category() const {return m_category;}
        bool          writeAccess() const {return m_write_access;}
        
        virtual void accept ( IParameterTypeVisitor& visitor ) const = 0;
        
    private:
        CategoryType m_category;     // category of the parameter
        bool         m_write_access; // write access on the parameter
  };
  
  //the template type for the values with ranges
  template< typename T, typename S = T>
  class Config
  {
     public:
        explicit Config( const T& _default, const S& max, const S& min, const std::string & unit):
           m_default(_default), m_min(min), m_max(max), m_unit(unit){}
        virtual ~Config(){}
        
        const T& def() const { return m_default;}
        const S& min() const { return m_min;}
        const S& max() const { return m_max;}
        const std::string& unit() const { return m_unit;}
                
     private:
        T m_default;
        S m_min;
        S m_max;
        std::string m_unit;
  };
  
  typedef Config<int>          IntConfig;
  typedef Config<unsigned int> UIntConfig;
  typedef Config<double >      FloatConfig;
  typedef Config<std::vector<double>, double > FloatVectorConfig;
    
  
  typedef std::vector<std::string> StringVectorType;
  typedef std::vector<double> FloatArray;
  
  class FloatArrayConfig : public FloatVectorConfig
  {
     public:
        explicit FloatArrayConfig( const FloatVectorConfig& config, const StringVectorType& labels, unsigned int min_size, unsigned int max_size ) :
               FloatVectorConfig( config),m_labels(labels), m_min_size(min_size), m_max_size(max_size){}
        virtual ~FloatArrayConfig(){}
        
        const StringVectorType& labels()const { return m_labels;}
        unsigned int minSize() const{ return m_min_size;}
        unsigned int maxSize() const{ return m_max_size;}


     private:
        StringVectorType m_labels;
        unsigned int m_min_size;
        unsigned int m_max_size;
  };    
  
  //template type for the Value classes
  template<typename T>
  class Value : public IValue
  {
     public:
        explicit Value( const std::string& name, const T& value):
           m_name(name ), m_value( value ){}
        virtual ~Value(){}
     
     public:
        virtual const std::string& name() const { return m_name;}
        const T& value() const {return m_value;}

        void accept( IValueVisitor& visitor) const;
        
     private:
        std::string m_name;
        T m_value;
  };
  
  //definitions of the types for the value objects
  typedef std::vector<double>     DoubleVectorType;
  typedef Value<int>              IntValue;
  typedef Value<unsigned int>     UIntValue;
  typedef Value<bool>             BoolValue;
  typedef Value<double>           FloatValue;
  typedef Value<DoubleVectorType> FloatArrayValue;
  
  class IValueVisitor
  {
       public:
          IValueVisitor(){};
          virtual ~IValueVisitor(){};
          // visit function for integer type
          virtual void visit( const IntValue&  value) = 0;
          virtual void visit( const UIntValue&  value) = 0;
          virtual void visit( const FloatValue& value) = 0;
          virtual void visit( const BoolValue&  value) = 0;
          virtual void visit( const FloatArrayValue&  value) = 0;
            
  };
  
  template <typename T>
  void Value<T>::accept(IValueVisitor& visitor) const
  {
     visitor.visit( *this );
  }
  
  template <typename T>
  class Type : public ParameterType
  {
     public:
        explicit Type(CategoryType category, bool write_access, const Config<T>& config, const Value<T>& value):
           ParameterType( category, write_access), m_config(config), m_value( value)
           {
           }
        public:
           const T& value() const { return m_value.value();}
           const Config<T>& config() const{ return m_config;}
           const std::string& name() const { return m_value.name(); }
        
        public:
           void accept(IParameterTypeVisitor& visitor) const;
           
     private:
        Config<T>   m_config;
        Value<T>    m_value;
        
  };
  
  typedef Type<int>          IntType;
  typedef Type<unsigned int> UIntType;
  typedef Type<double>       FloatType;
  
  class BoolType : public ParameterType
  {
     public:
        explicit BoolType( CategoryType category, bool write_access, bool _default, const BoolValue& value)
           : ParameterType( category, write_access ), m_default( _default),m_value( value ){}
        virtual ~BoolType(){} 
        
        bool  def() const { return m_default;}
        const BoolValue& value() const { return m_value;}
        void accept(IParameterTypeVisitor& visitor) const;
     
     private:
        bool m_default;
        BoolValue m_value;
  };
  
  class FloatArrayType : public ParameterType
  {
     public:
        explicit FloatArrayType( CategoryType category, bool write_access, const FloatArrayConfig& config, const FloatArrayValue& value)
           : ParameterType( category, write_access ), m_config( config ),m_value( value ){}
        virtual ~FloatArrayType(){} 
        
        const FloatArrayConfig& config() const { return m_config;}
        const FloatArrayValue&  value()  const { return m_value;}
        
        void accept(IParameterTypeVisitor& visitor) const;
     
     private:
        FloatArrayConfig m_config;
        FloatArrayValue  m_value;
  };
  
  class IParameterTypeVisitor
  {
     public:
        IParameterTypeVisitor(){}
        virtual ~IParameterTypeVisitor(){}
     
        virtual void visit( const IntType& type )= 0;
        virtual void visit( const UIntType& type ) = 0;
        virtual void visit( const FloatType& type ) = 0;
        virtual void visit( const BoolType& type ) = 0;
        virtual void visit( const FloatArrayType& type ) = 0;
  };
  
  template<typename T>
  void Type<T>::accept(IParameterTypeVisitor& visitor) const
  {
     visitor.visit( *this ); 
  }
  
  void BoolType::accept(IParameterTypeVisitor& visitor) const
  {
     visitor.visit( *this ); 
  }
  
  void FloatArrayType::accept(IParameterTypeVisitor& visitor) const
  {
     visitor.visit( *this ); 
  }
  
  class TransactionInfo
  {
     public:
        explicit TransactionInfo( const std::string& user_id, const std::string& reason ) :
              m_user_id( user_id), m_reason( reason ) {}
        
        virtual ~TransactionInfo(){}
        
        const std::string& userId() const {return m_user_id;}
        const std::string& reason() const  {return m_reason;}
        
     private:     
        std::string m_user_id;
        std::string m_reason;
  };
  
  class ParameterChangeHistory
  {
     public:
        explicit ParameterChangeHistory(
                    const std::string& parameter_name,
                    time_t             time_of_change,
                    const std::string& changed_by,
                    const std::string& reason,
                    const std::string& old_value,
                    const std::string& new_value ) :
                       m_parameter_name(parameter_name),
                       m_time_of_change(time_of_change),
                       m_changed_by(changed_by),
                       m_reason(reason),
                       m_old_value(old_value),
                       m_new_value(new_value){}
        virtual ~ParameterChangeHistory(){}
        
        const std::string& parameter_name() const{ return m_parameter_name;}
        time_t             time_of_change() const{ return m_time_of_change;}
        const std::string& changed_by()     const{ return m_changed_by;}
        const std::string& reason()         const{ return m_reason;}
        const std::string& old_value()      const{ return m_old_value;}
        const std::string& new_value()      const{ return m_new_value;}
     private:
        std::string m_parameter_name;
        time_t      m_time_of_change;
        std::string m_changed_by;
        std::string m_reason;
        std::string m_old_value;
        std::string m_new_value;
  };
  
  typedef boost::shared_ptr<ParameterType> ParameterTypePtr;
  typedef std::vector<ParameterTypePtr> ParameterTypePtrVector;
  typedef boost::shared_ptr<IValue> IValuePtr;
  typedef std::vector<IValuePtr> IValuePtrVector;
  typedef std::vector<ParameterChangeHistory>ParameterChangeHistoryVector;
    
  //events
  typedef boost::function<void (const IValuePtrVector&)> ValuesChangedCallback;

  class PAR
  {
  // functions throw IGS::exception
  public:
      static PAR* getInstance() {return instance;}

      // meta data
      //functions
      virtual void Read( const std::string& filter, ParameterTypePtrVector& parameters )=0;
      virtual void Write( const TransactionInfo& transactionInfo, const IValuePtrVector& values, StringVectorType& failed_parameters)=0;
      virtual void GetChangeHistory(time_t start, time_t end,  ParameterChangeHistoryVector& history)=0;
      
      // data update
      virtual void subscribeValuesChanged(ValuesChangedCallback cb) = 0;
      virtual void unsubscribeValuesChanged() = 0;
  
  protected:
      // instance
      virtual ~PAR() {}
      static PAR* instance;
  };
};

std::string myval = IGSxPAR::toString(IGSxPAR::DESIGN);

#endif // IGSXPAR_HPP
