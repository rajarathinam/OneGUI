#ifndef IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
#define IGSXGUIXFLOATARRAYEVENTHANDLER_HPP

#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>

class IGSxGUIxFloatArrayEventHandler : public QObject
{
    Q_OBJECT
  public:
    explicit IGSxGUIxFloatArrayEventHandler(QObject *parent = 0);
    void setWidgetVector(std::vector<SUI::Widget*> widgetVector, std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector);
    void setTableWidget(SUI::TableWidget *tableWidget);

    void focusNextWidget();
    void focusPreviousWidget();

    void focusUtil(int index);
    void showXButton();
  protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QString objname = object->objectName();
        std::string objName = objname.toStdString();
        if ( event->type() == QEvent::KeyPress) {
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            int key = keyEvent->key();
            switch (key) {
            case Qt::Key_Backtab:
                focusPreviousWidget();
                return true;
            case Qt::Key_Tab:
                if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                    focusPreviousWidget();
                } else {
                    focusNextWidget();
                }
                return true;
            }
        } else if (event->type() == QEvent::MouseButtonPress) {
            if (objName.find("lne-TFAP") != std::string::npos || objName.find("lne-tawFloatArrayParamaterPopup") != std::string::npos) {
                showXButton();
                return true;
            }
        }
        return object->eventFilter(object, event);
    }


  private:
    int m_currentIndex;
    int totalWidgetCount;
    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    QWidget* btnUpdate;
    QWidget* btnCancel;
    QWidget* btnReset;
    QString buttonStylesheet;
    QString lineEditStylesheet;
    std::vector<SUI::Widget *> m_widgetVector;
    std::vector<SUI::Widget *> m_lineEditWidgetVector;
    std::vector<SUI::Widget *> m_clearButtonWidgetVector;
    void setWidgetsToDefaultStyle();

};
#endif // IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
