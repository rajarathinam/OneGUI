/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM.hpp
| Author       : Matthijs den Uijl
| Description  : Proxy interface for System State Management
|
| ! \file        IGSxSSM.hpp
| ! \brief       Proxy interface for System State Management
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2017, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGXXSSM_HPP_
#define IGXXSSM_HPP_

#include "boost/array.hpp"
#include "boost/shared_ptr.hpp"
#include "boost/function.hpp"
#include <vector>

namespace IGSxSSM
{
    //forward declarations
    class StateConfigType;
    class GroupConfigType;
    class StateConfigType;
    class TransitionConfigType;
    class TransitionType;
    class SystemFunctionType;
    class SSM;

    //constants
    static const int STATE_NR_OF_LINES = 2;  //number of lines.
    static const int NR_OF_SYSTEM_FUNCTIONS = 6; // number of system functions
    //defines
    typedef boost::array< std::string, STATE_NR_OF_LINES> StateDescriptionType;
    typedef int StateIDType;
    typedef std::vector< StateConfigType>  StateConfigList;
    typedef std::vector< GroupConfigType>  GroupConfigList;
    typedef std::vector<TransitionConfigType> TransitionConfigList;
    typedef boost::shared_ptr<TransitionType> TransitionTypePtr;
    typedef boost::shared_ptr<SystemFunctionType> SystemFunctionPtr;
    typedef boost::array< SystemFunctionPtr,  NR_OF_SYSTEM_FUNCTIONS>  SystemFunctionPtrList;
    typedef boost::shared_ptr<SSM> SSMPtr;

    //brief       Configuration of state
    class StateConfigType
    {
         public:
            explicit StateConfigType( const StateDescriptionType& description, const  StateIDType& id):
                m_description( description),
                m_id( id )
            {
            }

            virtual ~StateConfigType(){}

            const StateDescriptionType&  description() const {return m_description;}
            const StateIDType& id() const {return m_id;}

        private:
            StateDescriptionType m_description; // description of the state
            StateIDType          m_id;          // id of the state, unique id for a System Function
    };

    //brief       Configuration of the group
    class GroupConfigType
    {
        public:
            explicit GroupConfigType( const std::string& description,
                                const  StateConfigList& states):
                    m_description( description),
                    m_states( states )
                {
                }

            virtual ~GroupConfigType(){}

            const std::string&  description() const {return m_description;}
            const StateConfigList& states() const {return m_states;}

        private:
                std::string          m_description; // description of the group
                StateConfigList      m_states;      // states of the group
    };

    //brief       Configuration of the transitions
    class TransitionType
    {
        public:
            explicit TransitionType(
                            const StateIDType& from,
                            const StateIDType& to ):
                        m_from( from),
                        m_to( to )
            {
            }

            virtual ~TransitionType(){}

            const StateIDType& from() const {return m_from;}
            const StateIDType& to()   const {return m_to;}

        private:
            StateIDType m_from; // the initial state
            StateIDType m_to;   // the target state
    };

    //brief       Transition config type
    class TransitionConfigType
    {
        public:
            explicit TransitionConfigType(
                            const TransitionType& transition,
                            bool  can_be_aborted ):
                        m_transition( transition),
                        m_can_be_aborted( can_be_aborted )
            {
            }

            virtual ~TransitionConfigType(){}

            const TransitionType& transition() const {return m_transition;}
            bool  can_be_aborted() const { return m_can_be_aborted;}

        private:
            TransitionType  m_transition; // the transition
            bool        m_can_be_aborted; //determines whether a transition can be aborted
    };

    //brief       Configuration of the a system function
    class SystemFunctionConfigType
    {
        public:
            explicit SystemFunctionConfigType( const std::string& description,
                                         const GroupConfigList& groups,
                                         const TransitionConfigList& transitions ):
                    m_description( description),
                    m_groups( groups ),
                    m_transitions( transitions )
                {
                }

            virtual ~SystemFunctionConfigType(){}

            const std::string&  description() const {return m_description;}
            const GroupConfigList&          groups() const {return m_groups;}
            const TransitionConfigList&     transitions() const {return m_transitions;}

         private:
            std::string          m_description; // description of the function
            GroupConfigList      m_groups;      // groups of the function
            TransitionConfigList m_transitions; // the possible state transitions of this function
    };

    //brief       Proxy for the system function
    class SystemFunctionType
    {
        public:
            explicit SystemFunctionType( const SystemFunctionConfigType & config):
                    m_config( config )
                {
                }

            virtual ~SystemFunctionType(){}

            //member functions
            const SystemFunctionConfigType&  config() const {return m_config;}
            virtual void set_state( const StateIDType& target ) = 0;
            virtual TransitionTypePtr get_state() const = 0;
            boost::function<void () > update = 0;
        private:
            SystemFunctionConfigType m_config; // configuration of the function
    };

    //brief       State control of the system functions
    class SSM
    {
        public:
          //Get singleton
          static SSMPtr GetInstance() { return instance;};
          virtual ~SSM(){}
            //member functions
          virtual SystemFunctionPtrList functions() = 0;
        protected:
            SSM(){};
            static SSMPtr instance;
    };
};
#endif /* IGXXSSM_HPP_ */
