/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMTabView.cpp
| Author       : Saket K
| Description  : Implementation of SSM view
|
| ! \file        IGSxGUIxSSMTabView.cpp
| ! \brief       Implementation of SSM view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUILabel.h>

#include <boost/bind.hpp>
#include <string>
#include <IGSxGUIxSSMTabView.hpp>
#include "IGSxGUIxMoc_SSMTabView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const int MAX_ROW_COUNT = 3;
const std::string IGSxGUI::SSMTabView::SYSTEMSTATEMANAGER_TAB_LOAD_FILE = "IGSxGUIxSSMTab.xml";
const std::string IGSxGUI::SSMTabView::SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE = "IGSxGUIxSSMTabGroup.xml";

IGSxGUI::SSMTabView::SSMTabView(SSMManager &ssmManager, const IGSxGUI::TabType tabIndex):
    sui(new SUI::SSMTabView),
    States(),
    mTabIndex(tabIndex),
    mManager(ssmManager),
    mStateCounter(0),
    mLoaded(false),
    mPreviousStateIndex(0)
{
}

void IGSxGUI::SSMTabView::setActive(bool /*bActive*/)
{
}

IGSxGUI::SSMTabView::~SSMTabView()
{

    for (std::vector< State* >::iterator it = States.begin() ; it != States.end(); ++it)
    {
      delete (*it);
    }
    States.clear();

}

void IGSxGUI::SSMTabView::addNewState(const int groupIndex, const int stateIndex)
{
    SUI::SUIUCState newUCState = SUIStates[groupIndex][stateIndex];
    newUCState.Button->setText(generateStateName(groupIndex, stateIndex));

    int currentStateId = mManager.getStateId(mTabIndex, groupIndex, stateIndex);
    InnerState currentInnerState = getInnerState(currentStateId);
    State* newState = new State(newUCState.Control, newUCState.Button, currentInnerState, currentStateId, mStateCounter++);
    newState->clicked = boost::bind(&SSMTabView::stateChanged, this, _1, _2, _3);
    States.push_back(newState);
}

void IGSxGUI::SSMTabView::init()
{

    for (std::vector< State* >::iterator it = States.begin() ; it != States.end(); ++it)
    {
      delete (*it);
    }
    States.clear();

    setupStates();


    for(size_t index = 0; index < States.size(); ++index)
    {
        States[index]->show();
    }
}

void IGSxGUI::SSMTabView::stateChanged(IGSxGUI::InnerState innerState, const int newStateId, const int newUIStateIndex)
{
    switch(innerState)
    {
    case IGSxGUI::REACHABLE:
        for(size_t index = 0; index < States.size(); ++index)
        {
            if ((newUIStateIndex != static_cast<int>(index))
                    && (States[index]->getInnerState() != IGSxGUI::ACTIVE)
                    && (States[index]->getInnerState() != IGSxGUI::TRANSITION))

                States[index]->setInnerState(IGSxGUI::DISABLED);
        }
       States[newUIStateIndex]->setInnerState(IGSxGUI::TRANSITION);
       mManager.setTransition(mTabIndex, newStateId);
       break;
   case IGSxGUI::ACTIVE:
       mActiveTransition = mManager.getActiveTransition(mTabIndex);
       if(mManager.isTransitionAbortable(mTabIndex, mActiveTransition))
       {
           mManager.setTransition(mTabIndex, mActiveTransition.first);
       }
       break;
   case IGSxGUI::TRANSITION:
        break;
   case IGSxGUI::DISABLED:
        break;
    }
}

void IGSxGUI::SSMTabView::setupStates()
{

    mStateCounter = 0;

    int groupCount = mManager.getGroupCount(mTabIndex);
    mActiveTransition = mManager.getActiveTransition(mTabIndex);

    for(int groupIndex = 0; groupIndex < groupCount ; ++groupIndex)
    {
        int stateCount = mManager.getStatesCount(mTabIndex, groupIndex);

        for(int stateIndex = 0; stateIndex < stateCount ; ++stateIndex)
        {
            addNewState(groupIndex, stateIndex);
        }
    }

}

void IGSxGUI::SSMTabView::reset()
{
    mLoaded = false;
}

void IGSxGUI::SSMTabView::show(SUI::Container* MainScreenContainer, bool)
{

    if(!mLoaded)
    {
      sui->setupSUIContainer(SYSTEMSTATEMANAGER_TAB_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setupGroups();
    setupUI();
    init();

}

void IGSxGUI::SSMTabView::setupGroups()
{

    int rowCount = mManager.getGroupCount(mTabIndex);
    std::string groupName;
    switch(rowCount)
    {
    case 1:
        if(!mLoaded)
        {
        sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
         mLoaded = true;
        }
        groupName = mManager.getGroupName(mTabIndex, 0);
        sui->groupLabel1->setText(groupName);
        sui->row1->show();
        sui->row2->hide();
        sui->row3->hide();
        break;
    case 2:
        if(!mLoaded)
        {
        sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
        sui->setupGroup2Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row2Container);
         mLoaded = true;
        }
        groupName = mManager.getGroupName(mTabIndex, 0);
        sui->groupLabel1->setText(groupName);
        groupName = mManager.getGroupName(mTabIndex, 1);
        sui->groupLabel2->setText(groupName);
        sui->row1->show();
        sui->row2->show();
        sui->row3->hide();
        break;

    case 3:
        if(!mLoaded)
        {
        sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
        sui->setupGroup2Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row2Container);
        sui->setupGroup3Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row3Container);
         mLoaded = true;
        }
        groupName = mManager.getGroupName(mTabIndex, 0);
        sui->groupLabel1->setText(groupName);
        groupName = mManager.getGroupName(mTabIndex, 1);
        sui->groupLabel2->setText(groupName);
        groupName = mManager.getGroupName(mTabIndex, 2);
        sui->groupLabel3->setText(groupName);
        sui->row1->show();
        sui->row2->show();
        sui->row3->show();
        break;
    }

}


void IGSxGUI::SSMTabView::setupUI()
{
    SUIStates.clear();
    std::vector< SUI::SUIUCState> stateList;
    SUIStates.assign(MAX_ROW_COUNT, stateList);

    if(sui->row1->isVisible())
    {
        SUIStates[0].push_back(SUI::SUIUCState(sui->state11, sui->state11Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state12, sui->state12Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state13, sui->state13Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state14, sui->state14Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state15, sui->state15Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state16, sui->state16Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state17, sui->state17Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state18, sui->state18Btn));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state19, sui->state19Btn));
    }


    if(sui->row2->isVisible())
    {
        SUIStates[1].push_back(SUI::SUIUCState(sui->state22, sui->state22Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state21, sui->state21Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state23, sui->state23Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state24, sui->state24Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state25, sui->state25Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state26, sui->state26Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state27, sui->state27Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state28, sui->state28Btn));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state29, sui->state29Btn));
    }

    if(sui->row3->isVisible())
    {
        SUIStates[2].push_back(SUI::SUIUCState(sui->state31, sui->state31Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state32, sui->state32Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state33, sui->state33Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state34, sui->state34Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state35, sui->state35Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state36, sui->state36Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state37, sui->state37Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state38, sui->state38Btn));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state39, sui->state39Btn));
    }
}

IGSxGUI::InnerState IGSxGUI::SSMTabView::getInnerState(const int stateId) const
{
    IGSxGUI::InnerState currentState = DISABLED;

    if ( (stateId == mActiveTransition.first))
    {
        currentState = ACTIVE;
    }
    else if ( (stateId != mActiveTransition.first) && ( stateId == mActiveTransition.second ))
    {
        currentState = TRANSITION;
    }
    else if ( (mActiveTransition.first == mActiveTransition.second) &&
              (stateId != mActiveTransition.first) &&
              (stateId != mActiveTransition.second) &&
              (mManager.isStateReachable(mTabIndex, stateId)) ) {
              currentState = REACHABLE;
    }

    return currentState;
}


std::string IGSxGUI::SSMTabView::generateStateName(const int groupIndex, const int stateIndex)
{
    std::string stateName;

    stateName += mManager.getStateName(mTabIndex, groupIndex, stateIndex)[0];
    if(mManager.getStateName(mTabIndex, groupIndex, stateIndex)[1] != "")
        stateName += std::string("\n") + mManager.getStateName(mTabIndex, groupIndex, stateIndex)[1];

    return stateName;
}


