/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxFloatParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Parameterpopup view
|
| ! \file        IGSxGUIxFloatParameterpopupView.cpp
| ! \brief       Implementation of FloatParameterpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUILabel.h>
#include <FWQxCore/SUIUILoader.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/regex.hpp>
#include <string>
#include <iomanip>
#include "IGSxGUIxFloatArrayParameterpopupView.hpp"
#include "IGSxGUIxMoc_FloatArrayParameterpopupView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::FloatArrayParameterpopupView::BUTTON_SIZE = 24;

const std::string IGSxGUI::FloatArrayParameterpopupView::FLOATPARAMETERPOPUPVIEW_LOAD_FILE = "IGSxGUIxFloatParameterPopup.xml";
const std::string IGSxGUI::FloatArrayParameterpopupView::STRING_FLOATPARAMETERPOPUPVIEW_SHOWN = "FloatParameterPopupView is Shown.";

IGSxGUI::FloatArrayParameterpopupView::FloatArrayParameterpopupView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager):
    sui(new SUI::FloatArrayParameterpopupView)
{
    sui->setupSUI(FLOATPARAMETERPOPUPVIEW_LOAD_FILE.c_str());
    m_dialog = SUI::UILoader::loadUI(FLOATPARAMETERPOPUPVIEW_LOAD_FILE.c_str());
    m_pMachineconstantsManager = pMachineconstantsManager;
}


IGSxGUI::FloatArrayParameterpopupView::~FloatArrayParameterpopupView()
{
}

void IGSxGUI::FloatArrayParameterpopupView::show()
{

    IGSxGUI::Util::setDialogWidth( sui->dialog, 446);

    std::string name = sui->lblParameterName->getText();
    formatParamNameBack(name);
    parameterData = m_pMachineconstantsManager->findParameter(name);

    int maxValueCount = parameterData->getMaxValueCount();

    sui->gbxUnrecommendedValue->setVisible(false);
    sui->gbxResetValues->setVisible(false);
    sui->gbxCancelValuesConfirm->setVisible(false);

    IGSxGUI::Util::setRowHeight(sui->tawFloatArrayParamaterPopup, 0, 42);

    IGSxGUI::Util::setRowHeight(sui->tawFloatArrayParamaterPopupForXButton, 0, 42);
    SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(0,0));
    IGSxGUI::Util::setAwesome(btn, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
    btn->clicked = boost::bind(&FloatArrayParameterpopupView::clearLineEdit, this, 0);
    btn->setVisible(true);

    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(0,1));
    le->textChanged = boost::bind(&FloatArrayParameterpopupView::onParamValueTextChanged, this, le,0, _1);
    le->editingFinished = boost::bind(&FloatArrayParameterpopupView::onParamValueTextEditFinished, this);
    le->setStyleSheetClass("floatArrayLe");

    SUI::Button* btn1 = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(0,0));
    btn1->hoverEntered = boost::bind(&FloatArrayParameterpopupView::onParamNameLabelEntered, this, 0);
    btn1->hoverLeft = boost::bind(&FloatArrayParameterpopupView::onParamNameLabelLeft, this, 0);
    std::vector<SUI::Widget*> widgetVector;
    std::vector<SUI::Widget*> clearButtonWidgetVector;
    std::vector<SUI::Widget*> lineEditWidgetVector;
    widgetVector.push_back(sui->dialog);
    widgetVector.push_back(le);
    lineEditWidgetVector.push_back(le);
    clearButtonWidgetVector.push_back(btn);
    for(int i=1; i<maxValueCount; i++)
    {
        sui->tawFloatArrayParamaterPopup->appendRow();
        sui->tawFloatArrayParamaterPopupForXButton->appendRow();
        IGSxGUI::Util::setRowHeight(sui->tawFloatArrayParamaterPopup, i, 42);

        IGSxGUI::Util::setRowHeight(sui->tawFloatArrayParamaterPopupForXButton, i, 42);
        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
        IGSxGUI::Util::setAwesome(btn, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
        btn->clicked = boost::bind(&FloatArrayParameterpopupView::clearLineEdit, this, i);
        btn->setVisible(false);

        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        le->textChanged = boost::bind(&FloatArrayParameterpopupView::onParamValueTextChanged, this, le, i, _1);
        le->editingFinished = boost::bind(&FloatArrayParameterpopupView::onParamValueTextEditFinished, this);
        le->setStyleSheetClass("floatArrayLe");

        SUI::Button* btn2 = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,0));
        btn2->hoverEntered = boost::bind(&FloatArrayParameterpopupView::onParamNameLabelEntered, this, i);
        btn2->hoverLeft = boost::bind(&FloatArrayParameterpopupView::onParamNameLabelLeft, this, i);
        widgetVector.push_back(le);
        lineEditWidgetVector.push_back(le);
        clearButtonWidgetVector.push_back(btn);
    }
    widgetVector.push_back(sui->btnPopUpdate);
    widgetVector.push_back(sui->btnPopCancel);
    widgetVector.push_back(sui->btnPopReset);

    init();
    resizeDialog();

    IGSxGUI::Util::disableFloatArrayScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    le->setFocus();
    btn->setVisible(true);
    IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, 0);
    IGSxGUI::Util::setEventFilterForFloatArray(widgetVector, sui->tawFloatArrayParamaterPopup, clearButtonWidgetVector, lineEditWidgetVector);
    IGSxGUI::Util::executeDialog(sui->dialog);


    IGS_INFO(STRING_FLOATPARAMETERPOPUPVIEW_SHOWN);
}

void IGSxGUI::FloatArrayParameterpopupView::init()
{
    IGSxGUI::Util::setWordWrap(sui->lblParameterName);
    IGSxGUI::Util::setWordWrap(sui->lblUnrecommendedValueDesc);
    sui->tawFloatArrayParamaterPopup->showGrid(false);
    sui->tawFloatArrayParamaterPopupForXButton->showGrid(false);

    // clear buttons of line edits are implemented as table over the floatarray table such that each row contains
    // one column with "x" button that will be on top of line edit of floatarray table
    // we have to sync the scrollbars of the two tables so that
    // the clear buttons move in sync with line edits when scrolled
    IGSxGUI::Util::connectFloatArrayTablesScrollbars(sui->tawFloatArrayParamaterPopup, sui->tawFloatArrayParamaterPopupForXButton);
    setParameterValue();
    setParameterDefaultValue();
    setParameterLabels();

    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", BUTTON_SIZE);
    sui->btnClose->clicked = boost::bind(&FloatArrayParameterpopupView::onCloseButtonPressed, this);
    sui->btnPopCancel->clicked = boost::bind(&FloatArrayParameterpopupView::onCancelButtonPressed, this);
    sui->btnClose->hoverEntered = boost::bind(&FloatArrayParameterpopupView::onCloseButtonHoverEntered, this);
    sui->btnClose->hoverLeft = boost::bind(&FloatArrayParameterpopupView::onCloseButtonHoverLeft, this);
    sui->btnPopReset->clicked = boost::bind(&FloatArrayParameterpopupView::onResetButtonPressed, this);
    sui->btnPopUpdate->clicked = boost::bind(&FloatArrayParameterpopupView::onUpdatebuttonPressed, this);
    sui->btnCancelConfirmYes->clicked = boost::bind(&FloatArrayParameterpopupView::cancelYes, this);
    sui->btnCancelConfirmNo->clicked = boost::bind(&FloatArrayParameterpopupView::cancelNo, this);
    sui->btnResetYes->clicked = boost::bind(&FloatArrayParameterpopupView::resetValues, this);
    sui->btnResetNo->clicked = boost::bind(&FloatArrayParameterpopupView::resetValuesNo, this);
}

void IGSxGUI::FloatArrayParameterpopupView::onCloseButtonPressed()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#0AA8FB", BUTTON_SIZE);
    IGSxGUI::Util::processEvents();
    onCancelButtonPressed();
}

void IGSxGUI::FloatArrayParameterpopupView::onCancelButtonPressed()
{
    sui->gbxCancelValuesConfirm->setVisible(true);
    disableDialog();
}

void IGSxGUI::FloatArrayParameterpopupView::cancelYes()
{
    enableDialog();
    sui->tawFloatArrayParamaterPopup->removeRows(1, sui->tawFloatArrayParamaterPopup->rowCount()-1);
    sui->tawFloatArrayParamaterPopupForXButton->removeRows(1, sui->tawFloatArrayParamaterPopupForXButton->rowCount()-1);
    sui->dialog->close();
}

void IGSxGUI::FloatArrayParameterpopupView::cancelNo()
{
    enableDialog();
    sui->gbxCancelValuesConfirm->setVisible(false);
    if (validateFields()) {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(0,1));
        le->setFocus();
        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(0,0));
        btn->setVisible(true);
        IGSxGUI::Util::selectLineEditText(le);
        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, 0);
    } else {
        focusFirstInvalidField();
    }
}

void IGSxGUI::FloatArrayParameterpopupView::onCloseButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#B3E2FF", BUTTON_SIZE);
}

void IGSxGUI::FloatArrayParameterpopupView::onCloseButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", BUTTON_SIZE);
}

void IGSxGUI::FloatArrayParameterpopupView::onResetButtonPressed()
{
    sui->gbxResetValues->setVisible(true);
    disableDialog();
}

void IGSxGUI::FloatArrayParameterpopupView::resetValues()
{
    enableDialog();
    std::vector<double> val = parameterData->getDefaultValue()->ToFloatarray();
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        std ::string tmpval = boost::lexical_cast<std::string>(val.at(i));
        adjustDoublePrecision(tmpval);
        le->setText(tmpval);
    }
    sui->gbxResetValues->setVisible(false);
    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(0,1));
    le->setFocus();
    SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(0,0));
    btn->setVisible(true);
    IGSxGUI::Util::selectLineEditText(le);
    IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, 0);
}

void IGSxGUI::FloatArrayParameterpopupView::resetValuesNo()
{
    enableDialog();
    sui->gbxResetValues->setVisible(false);
    if (validateFields()) {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(0,1));
        le->setFocus();
        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(0,0));
        btn->setVisible(true);
        IGSxGUI::Util::selectLineEditText(le);
        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, 0);
    } else {
        focusFirstInvalidField();
    }
}

void IGSxGUI::FloatArrayParameterpopupView::onUpdatebuttonPressed()
{\
    std::string name = getParameterName();
    std::string value = getParameterValue();
    if (validateFields()) {
        m_valueChanged(name, value);
    }
}

boost::signals2::connection IGSxGUI::FloatArrayParameterpopupView::registerForFloatArrayValueChanged(const IGSxGUI::FloatArrayParameterpopupView::floatArrayValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}

void IGSxGUI::FloatArrayParameterpopupView::onParamValueTextEditFinished()
{
    validateFields();
}

bool IGSxGUI::FloatArrayParameterpopupView::validateFields()
{
    bool isValid = true;
    int minValueCount = parameterData->getMinValueCount();
    int lastFilledEntry = 0;
    for(int i=0; i<sui->tawFloatArrayParamaterPopup->rowCount(); i++)
    {
            SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
            std::string value = le->getText();
            if (value != "") {
                lastFilledEntry = i;
            }
            try {
                boost::lexical_cast<double>(value);
            }
            catch (...)
            {
                if (i < minValueCount) {
                    if (!sui->gbxUnrecommendedValue->isVisible()) {
                        showWarning(le);
                        isValid = false;
                        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                        hideAllClearButtons();
                        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                        btn->setVisible(value != "");
                    } else {
                        le->setStyleSheetClass("floatArrayLeWarning");
                        isValid = false;
                    }
                } else {
                    if (!sui->gbxUnrecommendedValue->isVisible() && value != "") {
                        showWarning(le);
                        isValid = false;
                        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                        hideAllClearButtons();
                        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                        btn->setVisible(value != "");
                    } else if (value != ""){
                        le->setStyleSheetClass("floatArrayLeWarning");
                        isValid = false;
                    } else {
                        le->setStyleSheetClass("floatArrayLe");
                    }
                }
                continue;
            }

            if (boost::lexical_cast<double>(value) < parameterData->getMinValue()->ToDouble() ||
                boost::lexical_cast<double>(value) > parameterData->getMaxValue()->ToDouble()) {
                if (i < minValueCount) {
                    if (!sui->gbxUnrecommendedValue->isVisible()) {
                        showWarning(le);
                        isValid = false;
                        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                        hideAllClearButtons();
                        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                        btn->setVisible(value != "");
                    } else {
                        le->setStyleSheetClass("floatArrayLeWarning");
                        isValid = false;
                    }
                } else {
                    if (!sui->gbxUnrecommendedValue->isVisible() && value != "") {
                        showWarning(le);
                        isValid = false;
                        IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                        hideAllClearButtons();
                        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                        btn->setVisible(value != "");
                    } else if (value != ""){
                        le->setStyleSheetClass("floatArrayLeWarning");
                        isValid = false;
                    } else {
                        le->setStyleSheetClass("floatArrayLe");
                    }
                }
            } else {
                le->setStyleSheetClass("floatArrayLe");
            }
    }

    for(int i=minValueCount; i < lastFilledEntry; ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        std::string value = le->getText();
        if (!sui->gbxUnrecommendedValue->isVisible() && value == "") {
            showWarning(le);
            isValid = false;
            IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
        } else if (value == "") {
            le->setStyleSheetClass("floatArrayLeWarning");
            isValid = false;
        }
    }
    return isValid;
}

void IGSxGUI::FloatArrayParameterpopupView::showWarning(SUI::LineEdit* le) {
    sui->gbxUnrecommendedValue->setVisible(true);
    le->setStyleSheetClass("floatArrayLeWarning");
    std::string txt = "Please enter a value between " + parameterData->getMinValue()->ToString() + " and " + parameterData->getMaxValue()->ToString();
    sui->lblUnrecommendedValueDesc->setText(txt);
    le->setFocus();
    IGSxGUI::Util::selectLineEditText(le);
}

void IGSxGUI::FloatArrayParameterpopupView::setParameterName(const std::string& name)
{
    sui->lblParameterName->setText(name);
}

std::string IGSxGUI::FloatArrayParameterpopupView::getParameterName() const
{
    return sui->lblParameterName->getText();
}

void IGSxGUI::FloatArrayParameterpopupView::setParameterValue()
{
    std::vector<double> cur = parameterData->getCurrentValue()->ToFloatarray();
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount() && i < cur.size(); ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        std ::string val = boost::lexical_cast<std::string>(cur.at(i));
        adjustDoublePrecision(val);
        le->setText(val);
    }
}

std::string IGSxGUI::FloatArrayParameterpopupView::getParameterValue() const
{
    std::string str = "";
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        if (le->getText() != "") {
            str = str + "," + le->getText();
        }
    }
    return str.erase(0,1);
}

void IGSxGUI::FloatArrayParameterpopupView::setParameterDefaultValue()
{
    std::vector<double> def = parameterData->getDefaultValue()->ToFloatarray();
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::Label* la = dynamic_cast<SUI::Label*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,2));
        std ::string val = boost::lexical_cast<std::string>(def.at(i));
        adjustDoublePrecision(val);
        la->setText(val);
    }
}

void IGSxGUI::FloatArrayParameterpopupView::setParameterLabels()
{
    const std::vector<std::string>& labels = parameterData->getLabels();
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::Button* btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,0));
        std::string tmpname = labels[i];
        formatParamButtonName (dynamic_cast<SUI::Widget*>(btn), tmpname);
        btn->setText(tmpname);
    }
}

void IGSxGUI::FloatArrayParameterpopupView::setParent(SUI::Widget *parent)
{
    IGSxGUI::Util::setParent(sui->dialog, parent);
}

void IGSxGUI::FloatArrayParameterpopupView::resizeDialog()
{
    std::string name = sui->lblParameterName->getText();
    int no_of_lines = 1;
    while (true) {
        size_t pos = name.find('\n');
        if (pos == std::string::npos) {
            break;
        }
        no_of_lines++;
        name = name.substr(pos+1);
    }

    int xParamName = sui->lblParameterName->getGeometry().getX();
    int yParamName = sui->lblParameterName->getGeometry().getY();
    int widthParamName = sui->lblParameterName->getGeometry().getWidth();
    int hightParamName = 0;

    if (no_of_lines == 1) {
        hightParamName = 25;
    } else if (no_of_lines == 2) {
        hightParamName = 45;
    } else {
        hightParamName = 65;
    }

    sui->lblParameterName->setGeometry(xParamName,yParamName,widthParamName,hightParamName);

    int row = sui->tawFloatArrayParamaterPopup->rowCount();
    if (row > 16) {
        row = 16;
    }

    SUI::Rect rec = sui->tawFloatArrayParamaterPopup->getGeometry();
    int xTable = rec.getX();
    int yTable = yParamName + hightParamName + 34;
    int widthTable = rec.getWidth();
    int heightTable = rec.getHeight();

    SUI::Rect rec2 = sui->tawFloatArrayParamaterPopupForXButton->getGeometry();
    int xTableForXButton = rec2.getX();
    int widthTableForXButton = rec2.getWidth();
    int heightTableForXButton = rec2.getHeight();

    sui->tawFloatArrayParamaterPopup->setGeometry(xTable,yTable,widthTable,heightTable);
    sui->tawFloatArrayParamaterPopupForXButton->setGeometry(xTableForXButton,yTable,widthTableForXButton,heightTableForXButton);

    int xDefault = sui->lblDefaultValue->getGeometry().getX();
    int widthDefault = sui->lblDefaultValue->getGeometry().getWidth();
    int hightDefault = sui->lblDefaultValue->getGeometry().getHeight();

    sui->lblDefaultValue->setGeometry(xDefault,yTable-9-13,widthDefault,hightDefault);

    int y = sui->tawFloatArrayParamaterPopup->getGeometry().getY() + (row*42) + 54;

    int xUpdate = sui->btnPopUpdate->getGeometry().getX();
    int widthUpdate = sui->btnPopUpdate->getGeometry().getWidth();
    int hightUpdate = sui->btnPopUpdate->getGeometry().getHeight();

    int xCancel = sui->btnPopCancel->getGeometry().getX();
    int widthCancel = sui->btnPopCancel->getGeometry().getWidth();
    int hightCancel = sui->btnPopCancel->getGeometry().getHeight();

    int xReset = sui->btnPopReset->getGeometry().getX();
    int widthReset  = sui->btnPopReset->getGeometry().getWidth();
    int hightReset  = sui->btnPopReset->getGeometry().getHeight();

    sui->btnPopUpdate->setGeometry(xUpdate,y,widthUpdate,hightUpdate);
    sui->btnPopCancel->setGeometry(xCancel,y,widthCancel,hightCancel);
    sui->btnPopReset->setGeometry(xReset,y,widthReset,hightReset);

    int yReset = sui->btnPopReset->getGeometry().getY();

    IGSxGUI::Util::setDialogHeight( sui->dialog, yReset+hightReset+20);
}

void IGSxGUI::FloatArrayParameterpopupView::formatParamNameBack(std::string& name)
{
    while (true) {
        std::size_t pos = name.find('\n');
        if (pos != std::string::npos) {
            name.erase(pos,1);
        } else {
            return;
        }
    }
}

void IGSxGUI::FloatArrayParameterpopupView::onParamValueTextChanged(SUI::LineEdit * le, int row, const std::string& value)
{
    SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(row,0));
    if (le->hasFocus() && le->getText() != "")
    {
        btn->setVisible(true);
    } else {
        btn->setVisible(false);
    }
    sui->gbxUnrecommendedValue->setVisible(false);
    static size_t sizevar = value.size();
    int textremoved = 0;
    if (sizevar > value.size()) {
        textremoved = 1;
    }
    sizevar = value.size();

    boost::regex dblregex("^[-+]?[0-9]*[.]?[0-9]{1, 8}([eE][-+]?[0-9]{1,2})?$");
    if (!boost::regex_match(value, dblregex)) {
        sui->btnPopUpdate->setEnabled(false);
        std::string valuetmp = value;
        int x = IGSxGUI::Util::getLineEditCursorPosition(le);

        if (valuetmp.size() == 0) {
            sui->btnPopUpdate->setEnabled(true);
            return;
        }

        //do not allow more than one '-' or '+' at start
        //also do not allow -+ and +- at start
        if (valuetmp.size() == 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+')) {
            return;
        } else if (valuetmp.size() > 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+') && (valuetmp.at(1) == '-' || valuetmp.at(1) == '+')) {
            eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
            return;
        }

        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            //do not allow 'e' or 'E'at 0th position
            if (valuetmp.size() == 1) {
                if(valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow any character other than comapred below
            if (valatcur != 'e' && valatcur != 'E' && valatcur != '-' && valatcur != '+' && valatcur != '.' && !textremoved) {
                eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                return;
            }

            //do not allow 'e' or 'E' before '.'
            if(valatcur == 'e' || valatcur == 'E') {
                if (valuetmp.find('.', x) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow '.' after 'e' or 'E'
            if(valatcur == '.') {
                if (valuetmp.rfind('e', x-1) != std::string::npos || valuetmp.rfind('E', x-1) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
        }

        if (x > 1) {
            char valatcur = valuetmp.at(x-1);
            char valatprev = valuetmp.at(x-2);
            //do not allow more than one '-' after 'e' or 'E'
            //also do not allow -+ and +- after 'e' or 'E'
            if(valatcur == '-') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('-', x) != std::string::npos || valuetmp.find('+', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow more than one '+' after 'e' or 'E'
            //also do not allow -+ and +- after 'e' or 'E'
            if(valatcur == '+') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('+', x) != std::string::npos || valuetmp.find('-', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow 'e' or 'E' immediately after after '-'
            if(valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '-') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;

                }
            }

            //do not allow 'e' or 'E' immediately after after '+'
            if(valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '+') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;

                }
            }
        }

        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            //do not allow more than 8 digits after '.'
            size_t pos1 = valuetmp.find('.');
            if (pos1 != std::string::npos) {
                size_t pos2 = valuetmp.find('e');
                size_t pos3 = valuetmp.find('E');
                if (pos2 != std::string::npos || pos3 != std::string::npos) {
                    std::string tmp = "";
                    if (pos2 != std::string::npos) {
                        tmp = valuetmp.substr(pos1+1,pos2-pos1-1);
                    } else {
                        tmp = valuetmp.substr(pos1+1,pos3-pos1-1);
                    }
                    if (tmp.size() > 8) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                        eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                        return;
                    } else if (tmp.size() == 0) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                        if(valatcur == 'e' || valatcur == 'E') {
                            eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                            return;
                        }
                    }
                } else if(valuetmp.size() - pos1 > 8) {
                    int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow more than one 'e' or 'E'
            int count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == 'e' || valuetmp.at(i) == 'E') {
                    ++count;
                }
            }
            if (count >1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                if(valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }

            //do not allow more than one '.'
            count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == '.') {
                    ++count;
                }
            }
            if (count >1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                if(valatcur == '.') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
        }
        return;
    }
    sui->btnPopUpdate->setEnabled(true);
}

void IGSxGUI::FloatArrayParameterpopupView::eraseEnteredCharFromLineEdit(SUI::LineEdit *le, std::string& text, int pos) {
    text.erase(pos, 1);
    le->setText(text);
    IGSxGUI::Util::setLineEditCursorPosition(le, pos);
}


SUI::Label* IGSxGUI::FloatArrayParameterpopupView::getParameterNameType() const
{
    return sui->lblParameterName;
}

void IGSxGUI::FloatArrayParameterpopupView::close()
{
    sui->tawFloatArrayParamaterPopup->removeRows(1, sui->tawFloatArrayParamaterPopup->rowCount()-1);
    sui->tawFloatArrayParamaterPopupForXButton->removeRows(1, sui->tawFloatArrayParamaterPopupForXButton->rowCount()-1);
    sui->dialog->close();
}

void IGSxGUI::FloatArrayParameterpopupView::formatParamButtonName(SUI::Widget* widget, std::string& name) {
    int columnWidth = 175;
    int total_chars_width = 0;

    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfButton(str, widget);
        if (total_chars_width > columnWidth) {
            break;
        }
    }

    if (i != name.size()) {
        name.replace(i-1,name.size(),"...");
        while (formatParamButtonNameAfterAddingDots(widget, name));
    }
}

int IGSxGUI::FloatArrayParameterpopupView::formatParamButtonNameAfterAddingDots(SUI::Widget* widget, std::string& name) {
    int columnWidth = 175;
    int total_chars_width = 0;

    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfButton(str, widget);
        if (total_chars_width > columnWidth) {
            break;
        }
    }

    if (i != name.size()) {
        int pos = name.find("...");
        name.erase(pos-1, 1);
        return 1;
    } else {
        return 0;
    }
}

void IGSxGUI::FloatArrayParameterpopupView::onParamNameLabelEntered(int row) {
    const std::vector<std::string>& labels = parameterData->getLabels();
    SUI::Button* btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(row,0));
    std::string str = btn->getText();
    if (str.find("...") != std::string::npos) {
        btn->setToolTip(labels[row]);
    }
}

void IGSxGUI::FloatArrayParameterpopupView::onParamNameLabelLeft(int row) {
    SUI::Button* btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(row,0));
    btn->setToolTip("");
}

void IGSxGUI::FloatArrayParameterpopupView::disableDialog() {
    IGSxGUI::Util::disableTableScrollbar(sui->tawFloatArrayParamaterPopup);
    sui->btnPopCancel->setEnabled(false);
    sui->btnPopReset->setEnabled(false);
    sui->btnPopUpdate->setEnabled(false);
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        le->clearFocus();
        le->editingFinished = NULL;
        le->setEnabled(false);
        le->setStyleSheetClass("floatArrayLeDisable");
        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
        btn->setVisible(false);
    }
}

void IGSxGUI::FloatArrayParameterpopupView::enableDialog() {
    IGSxGUI::Util::enableTableScrollbar(sui->tawFloatArrayParamaterPopup);
    sui->btnPopCancel->setEnabled(true);
    sui->btnPopReset->setEnabled(true);
    sui->btnPopUpdate->setEnabled(true);
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        le->setEnabled(true);
        le->setStyleSheetClass("floatArrayLe");
        le->editingFinished = boost::bind(&FloatArrayParameterpopupView::onParamValueTextEditFinished, this);
    }
}

void IGSxGUI::FloatArrayParameterpopupView::focusFirstInvalidField()
{
    int minValueCount = parameterData->getMinValueCount();
    int lastFilledEntry = 0;
    for(int i=0; i<sui->tawFloatArrayParamaterPopup->rowCount(); i++)
    {
            SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
            std::string value = le->getText();
            if (value != "") {
                lastFilledEntry = i;
            }
            try {
                boost::lexical_cast<double>(value);
            }
            catch (...)
            {
                if (i < minValueCount) {
                    le->setFocus();
                    IGSxGUI::Util::selectLineEditText(le);
                    IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                    SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                    btn->setVisible(value != "");
                    return;
                }
                continue;
            }

            if (boost::lexical_cast<double>(value) < parameterData->getMinValue()->ToDouble() ||
                boost::lexical_cast<double>(value) > parameterData->getMaxValue()->ToDouble()) {
                if (i < minValueCount) {
                    le->setFocus();
                    IGSxGUI::Util::selectLineEditText(le);
                    IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
                    SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
                    btn->setVisible(value != "");
                    return;
                }
            }
    }

    for(int i=minValueCount; i < lastFilledEntry; ++i)
    {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(i,1));
        std::string value = le->getText();
        if (value == "") {
            le->setFocus();
            IGSxGUI::Util::selectLineEditText(le);
            IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, i);
            return;
        }
    }
}

void IGSxGUI::FloatArrayParameterpopupView::adjustDoublePrecision(std::string& paramvalue) {
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1,1);
        }
    }
}

void IGSxGUI::FloatArrayParameterpopupView::clearLineEdit(int row)
{
    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(sui->tawFloatArrayParamaterPopup->getWidgetItem(row,1));
    le->clearText();
    le->setFocus();
    IGSxGUI::Util::scrollTo(sui->tawFloatArrayParamaterPopup, row);
}

void IGSxGUI::FloatArrayParameterpopupView::hideAllClearButtons()
{
    for(int i = 0; i < sui->tawFloatArrayParamaterPopup->rowCount(); ++i)
    {
        SUI::Button *btn = dynamic_cast<SUI::Button*>(sui->tawFloatArrayParamaterPopupForXButton->getWidgetItem(i,0));
        btn->setVisible(false);
    }
}
