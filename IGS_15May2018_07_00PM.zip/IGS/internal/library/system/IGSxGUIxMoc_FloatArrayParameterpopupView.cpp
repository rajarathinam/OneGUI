

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_ParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Moc Parameterspopup view
|
| ! \file        IGSxGUIxMoc_ParameterpopupView.cpp
| ! \brief       Implementation of Moc Parameterspopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_FLOATPARAMETERSPOPUPVIEW_CPP
#define IGSXGUIXMOC_FLOATPARAMETERSPOPUPVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_FloatArrayParameterpopupView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIFileDialog.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIScrollBar.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::FloatArrayParameterpopupView::FloatArrayParameterpopupView() :
    dialog(NULL),
    btnPopCancel(NULL),
    btnClose(NULL),
    btnPopReset(NULL),
    btnPopUpdate(NULL),
    lblDefaultValue(NULL),
    lblParameterName(NULL),
    gbxUnrecommendedValue(NULL),
    lblUnrecommendedValueName(NULL),
    lblUnrecommendedValueDesc(NULL),
    gbxResetValues(NULL),
    lblResetValuesTitle(NULL),
    btnResetYes(NULL),
    btnResetNo(NULL),
    gbxCancelValuesConfirm(NULL),
    lblCancelValuesConfirmTitle(NULL),
    btnCancelConfirmYes(NULL),
    btnCancelConfirmNo(NULL)
{
}

void SUI::FloatArrayParameterpopupView::setupSUI(const char* xmlFileName) {
   dialog = SUI::UILoader::loadUI(xmlFileName);
   loadObjects(dialog->getObjectList());
}


void SUI::FloatArrayParameterpopupView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
   container->setUiFilename(xmlFileName);
   loadObjects(container->getObjectList());
}


void SUI::FloatArrayParameterpopupView::loadObjects(SUI::ObjectList* objectList) {
    btnPopCancel = objectList->getObject<SUI::Button>("btnPopCancel");
    btnClose= objectList->getObject<SUI::Button>("btnClose");
    btnPopReset = objectList->getObject<SUI::Button>("btnPopReset");
    btnPopUpdate = objectList->getObject<SUI::Button>("btnPopUpdate");
    lblDefaultValue = objectList->getObject<SUI::Label>("lblDefaultValue");
    lblParameterName = objectList->getObject<SUI::Label>("lblParameterName");
    tawFloatArrayParamaterPopup = objectList->getObject<TableWidget>("tawFloatArrayParamaterPopup");
    tawFloatArrayParamaterPopupForXButton = objectList->getObject<TableWidget>("tawFloatArrayParamaterPopupForXButton");
    gbxUnrecommendedValue = objectList->getObject<SUI::GroupBox>("gbxUnrecommendedValue");
    lblUnrecommendedValueName = objectList->getObject<SUI::Label>("lblUnrecommendedValueName");
    lblUnrecommendedValueDesc = objectList->getObject<SUI::Label>("lblUnrecommendedValueDesc");
    gbxResetValues = objectList->getObject<SUI::GroupBox>("gbxResetValues");
    lblResetValuesTitle = objectList->getObject<SUI::Label>("lblResetValuesTitle");
    btnResetYes = objectList->getObject<SUI::Button>("btnResetYes");
    btnResetNo = objectList->getObject<SUI::Button>("btnResetNo");
    gbxCancelValuesConfirm = objectList->getObject<SUI::GroupBox>("gbxCancelValuesConfirm");
    lblCancelValuesConfirmTitle = objectList->getObject<SUI::Label>("lblCancelValuesConfirmTitle");
    btnCancelConfirmYes = objectList->getObject<SUI::Button>("btnCancelConfirmYes");
    btnCancelConfirmNo = objectList->getObject<SUI::Button>("btnCancelConfirmNo");
}


#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP


