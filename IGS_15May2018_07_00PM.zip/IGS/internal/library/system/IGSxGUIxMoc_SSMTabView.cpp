

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_SystemStateManagerView.cpp
| Author       : Raja
| Description  : Implementation of Moc SystemStateManagerView
|
| ! \file        SystemStateManagerView.cpp
| ! \brief       Implementation of Moc SystemStateManagerView
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP
#define IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_SSMTabView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUILabel.h>
#include <boost/bind.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::SSMTabView::SSMTabView()
{
}

void SUI::SSMTabView::setupSUI(const char* /*xmlFileName*/) {
}


void SUI::SSMTabView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadObjects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup1Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup1Objects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup2Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup2Objects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup3Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup3Objects(container->getObjectList());
}

void SUI::SSMTabView::loadGroup1Objects(SUI::ObjectList* objectList) {


    state11 = objectList->getObject<SUI::UserControl>("uctState11");
    state12 = objectList->getObject<SUI::UserControl>("uctState12");
    state13 = objectList->getObject<SUI::UserControl>("uctState13");
    state14 = objectList->getObject<SUI::UserControl>("uctState14");
    state15 = objectList->getObject<SUI::UserControl>("uctState15");
    state16 = objectList->getObject<SUI::UserControl>("uctState16");
    state17 = objectList->getObject<SUI::UserControl>("uctState17");
    state18 = objectList->getObject<SUI::UserControl>("uctState18");
    state19 = objectList->getObject<SUI::UserControl>("uctState19");

    state11Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
    state12Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
    state13Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
    state14Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
    state15Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
    state16Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
    state17Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
    state18Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
    state19Btn = objectList->getObject<SUI::Button>("uctState19:btnState");

}

void SUI::SSMTabView::loadGroup2Objects(SUI::ObjectList* objectList) {


       state21 = objectList->getObject<SUI::UserControl>("uctState11");
       state22 = objectList->getObject<SUI::UserControl>("uctState12");
       state23 = objectList->getObject<SUI::UserControl>("uctState13");
       state24 = objectList->getObject<SUI::UserControl>("uctState14");
       state25 = objectList->getObject<SUI::UserControl>("uctState15");
       state26 = objectList->getObject<SUI::UserControl>("uctState16");
       state27 = objectList->getObject<SUI::UserControl>("uctState17");
       state28 = objectList->getObject<SUI::UserControl>("uctState18");
       state29 = objectList->getObject<SUI::UserControl>("uctState19");

       state21Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
       state22Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
       state23Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
       state24Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
       state25Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
       state26Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
       state27Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
       state28Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
       state29Btn = objectList->getObject<SUI::Button>("uctState19:btnState");


}

void SUI::SSMTabView::loadGroup3Objects(SUI::ObjectList* objectList) {

       state31 = objectList->getObject<SUI::UserControl>("uctState11");
       state32 = objectList->getObject<SUI::UserControl>("uctState12");
       state33 = objectList->getObject<SUI::UserControl>("uctState13");
       state34 = objectList->getObject<SUI::UserControl>("uctState14");
       state35 = objectList->getObject<SUI::UserControl>("uctState15");
       state36 = objectList->getObject<SUI::UserControl>("uctState16");
       state37 = objectList->getObject<SUI::UserControl>("uctState17");
       state38 = objectList->getObject<SUI::UserControl>("uctState18");
       state39 = objectList->getObject<SUI::UserControl>("uctState19");

       state31Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
       state32Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
       state33Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
       state34Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
       state35Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
       state36Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
       state37Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
       state38Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
       state39Btn = objectList->getObject<SUI::Button>("uctState19:btnState");
}


void SUI::SSMTabView::loadObjects(SUI::ObjectList* objectList) {


   row1Container = objectList->getObject<SUI::Container>("row1Container");
   row2Container = objectList->getObject<SUI::Container>("row2Container");
   row3Container = objectList->getObject<SUI::Container>("row3Container");





   row1 = objectList->getObject<SUI::GroupBox>("gbxRow1");
   row2 = objectList->getObject<SUI::GroupBox>("gbxRow2");
   row3 = objectList->getObject<SUI::GroupBox>("gbxRow3");

   groupLabel1 = objectList->getObject<SUI::Label>("lblTitleGroup1");
   groupLabel2 = objectList->getObject<SUI::Label>("lblTitleGroup2");
   groupLabel3 = objectList->getObject<SUI::Label>("lblTitleGroup3");
}


#endif // IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP

