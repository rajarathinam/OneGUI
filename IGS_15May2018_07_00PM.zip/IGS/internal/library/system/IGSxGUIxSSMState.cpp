/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMState.cpp
| Author       : Saket K
| Description  : Implementation of SSM State
|
| ! \file        IGSxGUIxSSMState.cpp
| ! \brief       Implementation of SSMState view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIButton.h>
#include <IGSxGUIxSSMState.hpp>
#include <boost/bind.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/


IGSxGUI::State::State(SUI::UserControl *control, SUI::Button *button, InnerState innerState, const int id, const int index) :
    mUsercontrol(control), mButton(button), mCurrentState(innerState), mId(id), mIndex(index)
{
    initButton(mCurrentState);
    button->clicked = boost::bind(&State::buttonClicked, this);
}

void IGSxGUI::State::buttonClicked()
{
     clicked(mCurrentState, mId, mIndex);
}

SUI::UserControl *IGSxGUI::State::getUserControl()
{
    return mUsercontrol;
}

void IGSxGUI::State::show()
{
    mUsercontrol->show();
}

void IGSxGUI::State::hide()
{
    mUsercontrol->hide();
}

void IGSxGUI::State::setInnerState(IGSxGUI::InnerState innerState)
{
    mCurrentState = innerState;
    initButton(mCurrentState);
}

IGSxGUI::InnerState IGSxGUI::State::getInnerState() const
{
    return mCurrentState;
}

void IGSxGUI::State::initButton(IGSxGUI::InnerState innerState)
{
    switch(innerState)
    {
    case REACHABLE:
        mButton->setStyleSheetClass("StateReachable");
        break;
    case ACTIVE:
        mButton->setStyleSheetClass("StateActive");
        break;
    case DISABLED:
         mButton->setStyleSheetClass("StateDisabled");
        break;
    case TRANSITION:
         mButton->setStyleSheetClass("StateTransition");
        break;
    }
}

void IGSxGUI::State::setId(const int id)
{
    mId = id;
}
