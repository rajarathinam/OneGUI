/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMManager.cpp
| Author       : Saket K
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxSSMManager.cpp
| ! \brief       SSM Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSSMManager.hpp"
#include "IGSxLOG.hpp"
#include <boost/bind.hpp>
#include <algorithm>

using namespace IGSxSSM;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

IGSxGUI::SSMManager::SSMManager()
    : m_Instance(),
      m_Functions(),
      m_Groups(),
      m_Transitions(),
      m_ReachableStates(),
      m_ActiveStates()
{

}

IGSxGUI::SSMManager::~SSMManager()
{
}

void IGSxGUI::SSMManager::initialize()
{
    m_Groups.clear();
    m_States.clear();
    m_Transitions.clear();
    m_ReachableStates.clear();
    m_ActiveStates.clear();

    m_Instance = IGSxSSM::SSM::GetInstance();
    m_Functions = m_Instance->functions();

    for(int functionIndex = 0 ; functionIndex < getFunctionCount(); ++functionIndex)
    {
        // Event handling will be changed along with interface definition.
        m_Functions[functionIndex]->update = boost::bind(&SSMManager::stateChanged, this);

        GroupConfigList groups = m_Functions[functionIndex]->config().groups();
        m_Groups.push_back(groups);

        TransitionConfigList transitionList;
        transitionList = m_Functions[functionIndex]->config().transitions();
        m_Transitions.push_back(transitionList);

        StatesList list;
        m_States.push_back(list);

        for(int groupIndex = 0 ; groupIndex < getGroupCount(functionIndex); ++groupIndex)
        {
            m_States[functionIndex].push_back(groups[groupIndex].states());
        }

        populateTransitions(functionIndex);

    }
}

int IGSxGUI::SSMManager::getFunctionCount() const
{
    return static_cast<int>(m_Functions.size());
}

int IGSxGUI::SSMManager::getGroupCount(const int functionIndex) const
{
    return static_cast<int>(m_Groups[functionIndex].size());
}

int IGSxGUI::SSMManager::getStatesCount(const int functionIndex, const int groupIndex) const
{
    return static_cast<int>(m_States[functionIndex][groupIndex].size());
}

void IGSxGUI::SSMManager::populateTransitions( int functionIndex)
{
   IGSxSSM::TransitionConfigList transitions = m_Transitions[functionIndex];

   for(size_t transitionIndex = 0 ; transitionIndex < transitions.size(); ++transitionIndex)
   {
        TransitionConfigType transition = transitions[transitionIndex];

        if (transition.transition().from() == transition.transition().to())
        {
            m_ActiveStates[functionIndex] = transition.transition().from();
        }
        m_ReachableStates[functionIndex].insert(transition.transition().from());
        m_ReachableStates[functionIndex].insert(transition.transition().to());
   }
}

IGSxGUI::Transition IGSxGUI::SSMManager::getActiveTransition(const int functionIndex) const
{
    TransitionTypePtr transition = m_Functions[functionIndex]->get_state();
    return Transition(transition->from(), transition->to());
}

bool IGSxGUI::SSMManager::isTransitionAbortable(const int functionIndex, const Transition &transition) const
{
    IGSxSSM::TransitionConfigList transitions = m_Transitions[functionIndex];
    bool result = false;
    for(size_t transitionIndex = 0 ; transitionIndex < transitions.size(); ++transitionIndex)
    {
         TransitionConfigType currentTransition = transitions[transitionIndex];
         if (currentTransition.transition().from() == transition.first && currentTransition.transition().to() == transition.second)
         {
            result = currentTransition.can_be_aborted();
            break;
         }
    }
    return result;
}

bool IGSxGUI::SSMManager::isStateReachable(const int functionIndex, const int stateId) const
{
   StateIds reachableStateIds = m_ReachableStates.at(functionIndex);
   return (reachableStateIds.find(stateId) != reachableStateIds.end());
}

void IGSxGUI::SSMManager::setTransition(const int functionIndex, const int newStateId)
{
    SystemFunctionPtr functionType =  m_Functions[functionIndex];
    functionType->set_state(StateIDType(newStateId));
}

void IGSxGUI::SSMManager::stateChanged()
{
    update();
}


std::string IGSxGUI::SSMManager::getFunctionName(const int functionIndex) const
{
   SystemFunctionPtr functionType =  m_Functions[functionIndex];
   SystemFunctionConfigType configType = functionType->config();
   return configType.description();
}

std::string IGSxGUI::SSMManager::getGroupName(const int functionIndex, const int groupIndex) const
{
    GroupConfigList group = m_Groups[functionIndex];
    return group[groupIndex].description();
}


IGSxGUI::StateDescriptionType IGSxGUI::SSMManager::getStateName(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].description();
}

int IGSxGUI::SSMManager::getStateId(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].id();
}
