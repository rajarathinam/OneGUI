/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMView.cpp
| Author       : Saket K
| Description  : Implementation of SSM view
|
| ! \file        IGSxGUIxSSMView.cpp
| ! \brief       Implementation of SSM view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIDialog.h>

#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/regex.hpp>
#include <string>
#include "IGSxGUIxISSMView.hpp"
#include "IGSxGUIxSSMView.hpp"
#include "IGSxGUIxSSMTabView.hpp"

#include "IGSxGUIxMoc_SSMView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::SSMView::SYSTEMSTATEMANAGER_VIEW_LOAD_FILE = "IGSxGUIxSSMBase.xml";
const std::string IGSxGUI::SSMView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";

IGSxGUI::SSMView::SSMView(SSMManager& ssmManager):
    sui(new SUI::SSMView),
    m_SSMPresenter(NULL),
    m_SSMManager(ssmManager),
    currentContainer(NULL),
    m_systemStateTab(new IGSxGUI::SSMTabView(ssmManager, SYSTEM_STATE)),
    m_LaserControlTab(new IGSxGUI::SSMTabView(ssmManager, LASER_CONTROL)),
    m_DropletControlTab(new IGSxGUI::SSMTabView(ssmManager, ENV_CONTROL)),
    m_TimingControlTab(new IGSxGUI::SSMTabView(ssmManager, TIMING_CONTROL)),
    m_TinControlTab(new IGSxGUI::SSMTabView(ssmManager, DROPLET_CONTROL)),
    m_EnvControlTab(new IGSxGUI::SSMTabView(ssmManager, TIN_CONTROL)),
    m_currentTab(SYSTEM_STATE)
{
      m_SSMPresenter = new IGSxGUI::SSMPresenter(*this, ssmManager);
      m_SSMManager.update = boost::bind(&IGSxGUI::SSMView::update, this);

}

SUI::Container* IGSxGUI::SSMView::getContainer()
{
    return currentContainer;
}

void IGSxGUI::SSMView::setActive(bool bActive)
{
    m_Active = bActive;
}

void IGSxGUI::SSMView::indexChanged(int index)
{
    showTab(static_cast<TabType>(index));
}

void IGSxGUI::SSMView::showTab(TabType tab)
{
    m_currentTab = tab;
    switch(tab)
    {
    case SYSTEM_STATE:
        m_systemStateTab->show(containers[m_currentTab], true);
        break;
    case LASER_CONTROL:
        m_LaserControlTab->show(containers[m_currentTab], true);
        break;
    case ENV_CONTROL:
        m_EnvControlTab->show(containers[m_currentTab], true);
        break;
    case DROPLET_CONTROL:
        m_DropletControlTab->show(containers[m_currentTab], true);
        break;
    case TIMING_CONTROL:
        m_TimingControlTab->show(containers[m_currentTab], true);
        break;
    case TIN_CONTROL:
        m_TinControlTab->show(containers[m_currentTab], true);
        break;
    }
    m_SSMPresenter->initHandlers();

}

IGSxGUI::SSMView::~SSMView()
{
    delete m_EnvControlTab;
    m_EnvControlTab = NULL;

    delete m_TinControlTab;
    m_TinControlTab = NULL;

    delete m_TimingControlTab;
    m_TimingControlTab = NULL;

    delete m_DropletControlTab;
    m_DropletControlTab = NULL;

    delete m_LaserControlTab;
    m_LaserControlTab = NULL;

    delete m_systemStateTab;
    m_systemStateTab = NULL;

    delete m_SSMPresenter;
    m_SSMPresenter = NULL;


}

void IGSxGUI::SSMView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if(!m_Active)
    {
        sui->setupSUIContainer(SYSTEMSTATEMANAGER_VIEW_LOAD_FILE.c_str(), MainScreenContainer);

        for(int functionIndex = 0 ; functionIndex < m_SSMManager.getFunctionCount(); ++functionIndex)
            sui->tabWidget->getTabPage(functionIndex)->setTabText(m_SSMManager.getFunctionName(functionIndex));

        sui->tabWidget->currentIndexChanged = boost::bind(&SSMView::indexChanged, this, _1);
        sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
        refreshContainers();
        resetAllTabs();
        showTab(SYSTEM_STATE);
    }
}

void IGSxGUI::SSMView::refreshContainers()
{
    containers.clear();
    containers.push_back(sui->container1);
    containers.push_back(sui->container2);
    containers.push_back(sui->container3);
    containers.push_back(sui->container4);
    containers.push_back(sui->container5);
    containers.push_back(sui->container6);
}

void IGSxGUI::SSMView::resetAllTabs()
{
    m_systemStateTab->reset();
    m_LaserControlTab->reset();
    m_DropletControlTab->reset();
    m_TimingControlTab->reset();
    m_TinControlTab->reset();
    m_EnvControlTab->reset();
}

void IGSxGUI::SSMView::update()
{
     showTab(SYSTEM_STATE);
}
