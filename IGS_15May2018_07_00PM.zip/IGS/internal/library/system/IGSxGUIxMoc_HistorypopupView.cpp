
/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_HistorypopupView.cpp
| Author       : Venu
| Description  : Implementation of Moc Historyspopup view
|
| ! \file        IGSxGUIxMoc_HistorypopupView.cpp
| ! \brief       Implementation of Moc Historyspopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_HISTORYPOPUPVIEW_CPP
#define IGSXGUIXMOC_HISTORYPOPUPVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_HistorypopupView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIFileDialog.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIMessageBox.h>
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIScrollBar.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::HistorypopupView::HistorypopupView() :
    dialog(NULL),
    uctCloseHistory(NULL),
    lblCloseImage(NULL),
    lblHistory(NULL),
    lneSearchParameterText(NULL),
    btnSearchParameter(NULL),
    btnSearchClear(NULL),
    lblHistoryEntriesFound(NULL),
    uctParameterName(NULL),
    lblParameterNameHistoryHeaderButtonText(NULL),
    lblParameterNameHistoryHeaderButtonImage(NULL),
    uctChangedOn(NULL),
    lblChangedOnHistoryHeaderButtonText(NULL),
    lblChangedOnHistoryHeaderButtonImage(NULL),
    uctChangedBy(NULL),
    lblChangedByHistoryHeaderButtonText(NULL),
    lblChangedByHistoryHeaderButtonImage(NULL),
    btnParameterOldValue(NULL),
    btnParameterNewValue(NULL),
    uctReason(NULL),
    lblReasonHistoryHeaderButtonText(NULL),
    lblReasonHistoryHeaderButtonImage(NULL),
    tawParametersHistory(NULL)
{
}

void SUI::HistorypopupView::setupSUI(const char* xmlFileName) {
   dialog = SUI::UILoader::loadUI(xmlFileName);
   loadObjects(dialog->getObjectList());
}


void SUI::HistorypopupView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
   container->setUiFilename(xmlFileName);
   loadObjects(container->getObjectList());
}


void SUI::HistorypopupView::loadObjects(SUI::ObjectList* objectList) {

    lblHistory = objectList->getObject<Label>("lblHistory");
    lneSearchParameterText = objectList->getObject<LineEdit>("lneSearchParameterText");
    btnSearchParameter = objectList->getObject<Button>("btnSearchParameter");
    btnSearchClear = objectList->getObject<Button>("btnSearchClear");
    lblHistoryEntriesFound = objectList->getObject<Label>("lblHistoryEntriesFound");
    uctCloseHistory = objectList->getObject<UserControl>("uctCloseHistory");
    lblCloseImage = objectList->getObject<Label>("uctCloseHistory:lblCloseImage");
    uctParameterName = objectList->getObject<UserControl>("uctParameterName");
    lblParameterNameHistoryHeaderButtonText =  objectList->getObject<Label>("uctParameterName:lblHistoryHeaderButtonText");
    lblParameterNameHistoryHeaderButtonImage = objectList->getObject<Label>("uctParameterName:lblHistoryHeaderButtonImage");
    uctChangedOn = objectList->getObject<UserControl>("uctChangedOn");
    lblChangedOnHistoryHeaderButtonText =  objectList->getObject<Label>("uctChangedOn:lblHistoryHeaderButtonText");
    lblChangedOnHistoryHeaderButtonImage = objectList->getObject<Label>("uctChangedOn:lblHistoryHeaderButtonImage");
    uctChangedBy = objectList->getObject<UserControl>("uctChangedBy");
    lblChangedByHistoryHeaderButtonText =  objectList->getObject<Label>("uctChangedBy:lblHistoryHeaderButtonText");
    lblChangedByHistoryHeaderButtonImage = objectList->getObject<Label>("uctChangedBy:lblHistoryHeaderButtonImage");
    btnParameterOldValue = objectList->getObject<Button>("btnParameterOldValue");
    btnParameterNewValue = objectList->getObject<Button>("btnParameterNewValue");
    uctReason = objectList->getObject<UserControl>("uctReason");
    lblReasonHistoryHeaderButtonText =  objectList->getObject<Label>("uctReason:lblHistoryHeaderButtonText");
    lblReasonHistoryHeaderButtonImage = objectList->getObject<Label>("uctReason:lblHistoryHeaderButtonImage");

    tawParametersHistory = objectList->getObject<TableWidget>("tawParametersHistory");
    scbHistoryTable = objectList->getObject<ScrollBar>("scbHistoryTable");
}


#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
