/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMPresenter.cpp
| Author       : Saket K
| Description  : Implementation of SSM Presenter
|
| ! \file        IGSxGUIxSSMPresenter.cpp
| ! \brief       Implementation of SSM Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSSMPresenter.hpp"
#include <string>
#include <vector>
#include <boost/bind.hpp>
#include <IGSxGUIxSSMState.hpp>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::SSMPresenter::SSMPresenter(ISSMView &view, SSMManager &ssmManager):
    m_SSMManager(ssmManager),
    m_view(view)
{
}

IGSxGUI::SSMPresenter::~SSMPresenter()
{
    // Do not delete m_view, we are not the owner.
}

void IGSxGUI::SSMPresenter::initHandlers()
{
    for (StateList::iterator it = m_SSMManager.SystemStates.begin() ; it != m_SSMManager.SystemStates.end(); ++it)
    {
        (*it)->clicked = boost::bind(&SSMPresenter::stateChanged, this, _1, _2);
    }
}


void IGSxGUI::SSMPresenter::stateChanged(IGSxGUI::InnerState innerState, const int index)
{
    if( IGSxGUI::REACHABLE == innerState)
    {
        for (int i =0 ; i <  m_SSMManager.SystemStates.size() ; ++i)
        {
            if (IGSxGUI::ACTIVE == m_SSMManager.SystemStates[i]->getInnerState())
            {
                 m_SSMManager.SystemStates[i]->setInnerState(IGSxGUI::REACHABLE);
                 break;
            }
        }
        m_SSMManager.SystemStates[index]->setInnerState(IGSxGUI::ACTIVE);
    }
}
