#include "IGSxGUIxFloatArrayEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"
#include <QLineEdit>
#include <QPushButton>

IGSxGUIxFloatArrayEventHandler::IGSxGUIxFloatArrayEventHandler(QObject *parent) :
    QObject(parent), m_currentIndex(0), totalWidgetCount(0)
{
}

void IGSxGUIxFloatArrayEventHandler::setWidgetVector(std::vector<SUI::Widget *> widgetVector, std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector)
{
    widgetVector.erase(widgetVector.begin());  // Remove the dialog widget
    m_widgetVector = widgetVector;
    m_lineEditWidgetVector = lineEditWidgetVector;
    m_clearButtonWidgetVector = clearButtonWidgetVector;

    totalWidgetCount = m_widgetVector.size();
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 1]);
    btnReset = dynamic_cast<QWidget*>(baseWidget->getWidget());
    baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 2]);
    btnCancel = dynamic_cast<QWidget*>(baseWidget->getWidget());
    baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 3]);
    btnUpdate = dynamic_cast<QWidget*>(baseWidget->getWidget());

    btnReset->setStyleSheet("border: 1px solid #0AA8FB;color:#0AA8FB;font-family: 'Roboto regular', 'Roboto';font-size: 14px;");
    btnCancel->setStyleSheet("border: 1px solid #0AA8FB;color:#0AA8FB;font-family: 'Roboto regular', 'Roboto';font-size: 14px;");
    btnUpdate->setStyleSheet("background-color: #0AA8FB;color:#FFFFFF;font-family: 'Roboto regular', 'Roboto';font-size: 14px;border:0px");
      //buttonStylesheet = btnUpdate->styleSheet();
}

void IGSxGUIxFloatArrayEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
}


void IGSxGUIxFloatArrayEventHandler::focusPreviousWidget()
{
    int totalWidgetCount = static_cast<int>(m_widgetVector.size());
    if (m_currentIndex == 0) {
        m_currentIndex =  totalWidgetCount - 1;
    } else {
        --m_currentIndex ;
    }
    focusUtil(m_currentIndex);
}


void IGSxGUIxFloatArrayEventHandler::focusNextWidget()
{
    int totalWidgetCount = static_cast<int>(m_widgetVector.size());
    if (m_currentIndex == (totalWidgetCount - 1)) {
        m_currentIndex =  0;
    } else {
        ++m_currentIndex ;
    }
    focusUtil(m_currentIndex);
}
void IGSxGUIxFloatArrayEventHandler::focusUtil(int index)
{
    setWidgetsToDefaultStyle();
    SUI::Widget *widget = m_widgetVector[index];
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
    QString widgetClassName(qWidget->metaObject()->className());
    if ( widgetClassName == QString("QLineEdit")) {
        IGSxGUI::Util::selectRow(m_tableWidget, index);
        qWidget->setFocus();
        qWidget->setStyleSheet("border-color:#0AA8FB");
    } else if (widgetClassName == QString("CustomPushButton")) {
        qWidget->setStyleSheet("border: 2px dotted blue");
    }

}
void IGSxGUIxFloatArrayEventHandler::setWidgetsToDefaultStyle()
{
    int totalWidgetCount = static_cast<int>(m_widgetVector.size());
    for (int i = 0; i < totalWidgetCount; ++i) {
        SUI::Widget *widget = m_widgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QString widgetClassName(qWidget->metaObject()->className());
        QString style = "";
        if ( widgetClassName == QString("QLineEdit")) {
            qWidget->clearFocus();
        } else if (widgetClassName == QString("CustomPushButton")) {
            style = buttonStylesheet;
        }
        qWidget->setStyleSheet(style);
    }
}

void IGSxGUIxFloatArrayEventHandler::showXButton()
{
    for (int i = 0; i < m_lineEditWidgetVector.size(); ++i) {
        SUI::Widget *widget = m_lineEditWidgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QLineEdit *le = dynamic_cast<QLineEdit*>(qWidget);

        SUI::Widget *widget2 = m_clearButtonWidgetVector[i];
        SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widget2);
        QWidget* qWidget2 = dynamic_cast<QWidget*>(baseWidget2->getWidget());
        QPushButton *btn = dynamic_cast<QPushButton*>(qWidget2);

        if (le->hasFocus() && le->text() != "")
        {
            btn->setVisible(true);
            le->deselect();
        } else {
            btn->setVisible(false);
        }
    }
}

