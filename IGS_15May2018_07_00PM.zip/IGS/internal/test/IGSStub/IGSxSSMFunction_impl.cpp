/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxSSM interface
|
| ! \file        IGSxSSM_impl.cpp
| ! \brief       Stub impementation of IGSxSSM interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxSSM.hpp"
#include "IGSxSSM_impl.hpp"
#include <boost/bind.hpp>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

using namespace IGSxSSM;

const int TIMER_INTERVAL = 0;

SystemFunction::SystemFunction( const SystemFunctionConfigType & config) : SystemFunctionType(config),
      mPreviousState(-1),
      mCurrentState(-1),
      mTimer(SUI::Timer::createTimer())
{
     mTimer->timeout = boost::bind(&SystemFunction::onTransitionCompleted, this);
}

void SystemFunction::set_state( const StateIDType& target )
{
    if(-1 == mPreviousState)
        mPreviousState = mCurrentState = target;

    mPreviousState = mCurrentState;
    mCurrentState = target;
    mTimer->start(TIMER_INTERVAL);
}

TransitionTypePtr SystemFunction::get_state() const
{
    return boost::shared_ptr<TransitionType>( new TransitionType(mPreviousState, mCurrentState));
}

void SystemFunction::onTransitionCompleted()
{
    mTimer->stop();
    mPreviousState = mCurrentState;
    update();
}


