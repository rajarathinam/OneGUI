/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxSSM interface
|
| ! \file        IGSxSSM_impl.cpp
| ! \brief       Stub impementation of IGSxSSM interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxSSM.hpp"
#include "IGSxSSM_impl.hpp"
#include <QXmlStreamReader>
#include <QFile>
#include <QDebug>
#include <iostream>
#include <FWQxCore/SUIResourcePath.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/


IGSxSSM::SSMPtr IGSxSSM::SSM::instance = IGSxSSM::SSM_Stub::GetInstance();
const std::string IGSxSSM::SSM_Stub::STRING_RESOURCE = "/Resource";
const std::string IGSxSSM::SSM_Stub::DATA_FILE_NAME = "SSMViewExtended.xml";

IGSxSSM::SSM_Stub::SSM_Stub() : functionTypes()
{
    std::string currentDir(get_current_dir_name());
    SUI::ResourcePath::getInstance()->setResourcePath(currentDir);


    //init();
    initxml();

}

void IGSxSSM::SSM_Stub::init()
{
    GroupConfigList groups;
    StateConfigList statesGroup1;
    StateIDType stateId = 11;
    StateDescriptionType stateDescription;
    stateDescription[0] = std::string("SERVICE");
    StateConfigType state11(stateDescription, stateId);

    stateId = 12;
    stateDescription[0] = std::string("ARAGON");
    StateConfigType state12(stateDescription, stateId);

    stateId = 13;
    stateDescription[0] = std::string("H2");
    StateConfigType state13(stateDescription, stateId);

    stateId = 14;
    stateDescription[0] = std::string("HEATED");
    StateConfigType state14(stateDescription, stateId);

    stateId = 15;
    stateDescription[0] = std::string("PRESSURIZED");
    StateConfigType state15(stateDescription, stateId);

    stateId = 16;
    stateDescription[0] = std::string("STANDBY");
    StateConfigType state16(stateDescription, stateId);

    stateId = 17;
    stateDescription[0] = std::string("READY");
    StateConfigType state17(stateDescription, stateId);

    statesGroup1.push_back(state11);
    statesGroup1.push_back(state12);
    statesGroup1.push_back(state13);
    statesGroup1.push_back(state14);
    statesGroup1.push_back(state15);
    statesGroup1.push_back(state16);
    statesGroup1.push_back(state17);

    groups.push_back(GroupConfigType(std::string("System state"), statesGroup1));

    groups.push_back(GroupConfigType(std::string("Service state"), statesGroup1));

    TransitionConfigList transitions;

    SystemFunctionConfigType configTypeSystemState(std::string("SYSTEM STATE"), groups, transitions);
    SystemFunctionConfigType configTypeLaserControl(std::string("LASER CONTROL"), groups, transitions);
    SystemFunctionConfigType configTypeEnvControl(std::string("ENVIRONMENT CONTROL"), groups, transitions);
    SystemFunctionConfigType configTypetimingControl(std::string("TIMING ENERGY CONTROL"), groups, transitions);
    SystemFunctionConfigType configTypeDropletControl(std::string("DROPLET CONTROL"), groups, transitions);
    SystemFunctionConfigType configTypeTinControl(std::string("TIN DEBRIS CONTROL"), groups, transitions);


    functionTypes[0] =  SystemFunctionPtr(new SystemFunction(configTypeSystemState));
    functionTypes[1] =  SystemFunctionPtr(new SystemFunction(configTypeLaserControl));
    functionTypes[2] =  SystemFunctionPtr(new SystemFunction(configTypeEnvControl));
    functionTypes[3] =  SystemFunctionPtr(new SystemFunction(configTypetimingControl));
    functionTypes[4] =  SystemFunctionPtr(new SystemFunction(configTypeDropletControl));
    functionTypes[5] =  SystemFunctionPtr(new SystemFunction(configTypeTinControl));
}


void IGSxSSM::SSM_Stub::initxml()
{
    std::string fileName = SUI::ResourcePath::getInstance()->getResourceFile(std::string("SSMViewExtended.xml"));
    QFile* xmlFile = new QFile(QString::fromStdString(fileName));
    if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
        qDebug() << "Load XML File Problem coudnt open xmlfile.xml to load settings for download";
        return;
    }
    QXmlStreamReader reader(xmlFile);


    int functionIndex = 0;
    while(reader.readNextStartElement())
    {
        if(reader.name() == "StateManagerTabs")
        {

            while(reader.readNextStartElement())
            {
                if(reader.name() == "Function" && reader.attributes().hasAttribute("name"))
                {
                    TransitionConfigList transitions;
                    GroupConfigList groups;
                     QString functionName = reader.attributes().value("name").toString();
                    StateIDType activeState = -1;

                    while(reader.readNextStartElement())
                    {
                        if(reader.name() == "Group" && reader.attributes().hasAttribute("name"))
                        {
                            QString groupName = reader.attributes().value("name").toString();
                            StateConfigList states;

                            while(reader.readNextStartElement())
                            {
                                if(reader.name() == "State" && reader.attributes().hasAttribute("id"))
                                {
                                    QString stateId = reader.attributes().value("id").toString();
                                    QString stateName = reader.readElementText();
                                    int pos = stateName.indexOf("\\");
                                    StateDescriptionType stateDescription;
                                    if(-1 == pos)
                                    {
                                        stateDescription[0] = std::string(stateName.toStdString());
                                    }
                                    else
                                    {
                                        stateDescription[0] = std::string(stateName.mid(0, pos).toStdString());
                                        stateDescription[1] = std::string(stateName.mid(pos+1).toStdString());
                                    }
                                    StateConfigType state(stateDescription, stateId.toInt());
                                    states.push_back(state);
                                }
                                else
                                {
                                    reader.skipCurrentElement();
                                }

                            }
                            groups.push_back(GroupConfigType(groupName.toStdString(), states));
                        }
                        else if(reader.name() == "Transition" && reader.attributes().hasAttribute("from") && reader.attributes().hasAttribute("to"))
                        {
                            QString from = reader.attributes().value("from").toString();
                            QString to = reader.attributes().value("to").toString();
                            QString abortable = reader.attributes().value("abortable").toString();
                            StateIDType fromState = StateIDType(from.toInt());
                            StateIDType toState = StateIDType(to.toInt());
                            if(fromState == toState)
                                  activeState = StateIDType(from.toInt());


                            transitions.push_back(TransitionConfigType(TransitionType(fromState, toState), (abortable == "1")?true:false));
                            reader.skipCurrentElement();
                        }
                        else
                        {
                            reader.skipCurrentElement();
                        }
                    }

                SystemFunctionConfigType configTypeSystemState(std::string(functionName.toStdString()), groups, transitions);
                SystemFunction* systemFunction = new SystemFunction(configTypeSystemState);
                if(activeState!= -1)
                    systemFunction->set_state(activeState);
                functionTypes[functionIndex++] = SystemFunctionPtr(systemFunction);
                }
            }
        }
    }


//close reader and flush file
reader.clear();
xmlFile->close();


}

//IGSxSSM::SSM_Stub::~SSM_Stub() {}

IGSxSSM::SystemFunctionPtrList IGSxSSM::SSM_Stub::functions()
{
    return functionTypes;
}

IGSxSSM::SSMPtr IGSxSSM::SSM_Stub::GetInstance()
{
    static IGSxSSM::SSMPtr  _instance;
    if (_instance.get() == NULL)
    {
        _instance.reset(new IGSxSSM::SSM_Stub());
    }
    return _instance;
}


