/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR_impl.cpp
| Author       : Jan-Pieter
| Description  : Stub impementation of IGSxPAR interface
|
| ! \file        IGSxPAR_impl.cpp
| ! \brief       Stub impementation of IGSxPAR interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/date_time.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/find.hpp>
#include <boost/lexical_cast.hpp>
#include "IGSxPAR_impl.hpp"
#include "StubParameters.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace
{
enum ITEMTYPE
{
    TYPE_int,
    TYPE_uint,
    TYPE_boolean,
    TYPE_double,
    TYPE_floatarray
};

typedef struct
{
    std::string name;
    std::string unit;
    ITEMTYPE itemType;

    int defaultIntValue;
    int currentIntValue;
    unsigned int defaultUintValue;
    unsigned int currentUintValue;
    double defaultDoubleValue;
    double currentDoubleValue;
    bool defaultBoolValue;
    bool currentBoolValue;
    std::vector<double> defaultFloatArrayValue;
    std::vector<double> currentFloatArrayValue;
}gParameterType;

std::vector<double> CreateDoubleArray(std::string doubleString)
{
    std::vector<std::string> values;
    boost::split(values, doubleString, boost::is_any_of(","));

    std::vector<double> doubles;
    for (int i = 0; i < static_cast<int>(values.size()); ++i)
    {
        doubles.push_back(boost::lexical_cast<double>(values[i]));
    }
    return doubles;
}


#define CREATEPARAMETERS_int(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_int, VALUE, VALUE, 0, 0, 0.0, 0.0, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_uint(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_uint, 0, 0, VALUE, VALUE, 0.0, 0.0, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_double(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_double, 0, 0, 0, 0, VALUE, VALUE, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_boolean(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_boolean, 0, 0, 0, 0, 0.0, 0.0, VALUE, VALUE, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_floatarray(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_floatarray, 0, 0, 0, 0, 0.0, 0.0, true, true, CreateDoubleArray(VALUE), CreateDoubleArray(VALUE) }

#define CREATEPARAMETERS(NAME, VALUE, TYPE, UNIT)\
    CREATEPARAMETERS_##TYPE(NAME, VALUE, UNIT),

gParameterType gParameters[] = {
    PARAMETERS(CREATEPARAMETERS)
};

std::vector<IGSxPAR::ParameterChangeHistory*> gHistory;
IGSxPAR::ValuesChangedCallback gCallback;
bool gCallbackSubscribed = false;
IGSxPAR::IValuePtrVector gValuesForNextEvent;

int getParameterCount()
{
    return sizeof(gParameters)/sizeof(gParameters[0]);
}

int findParameterIndex(std::string str)
{
    for (int i = 0; i < getParameterCount(); ++i)
    {
        if (gParameters[i].name == str)
        {
            return i;
        }
    }
    return -1;
}

int getIntParameterValue(std::string str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentIntValue;
}


void setIntParameterValue(std::string str, int value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentIntValue = value;
}

int getUintParameterValue(std::string str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentUintValue;
}

void setUintParameterValue(std::string str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentUintValue = value;
}

double getFloatParameterValue(std::string str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentDoubleValue;
}

void setFloatParameterValue(std::string str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentDoubleValue = value;
}

int getBoolParameterValue(std::string str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentBoolValue;
}
void setBoolParameterValue(std::string str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentBoolValue = value;
}

std::vector<double> getFloatArrayParameterValue(std::string parameterName)
{
    int index = findParameterIndex(parameterName);
    return index == -1 ? std::vector<double>() : gParameters[index].currentFloatArrayValue;
}

void setFloatArrayParameterValue(std::string str, const std::vector<double>& value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentFloatArrayValue.clear();
    for (int i = 0; i < static_cast<int>(value.size()); ++i)
    {
        gParameters[index].currentFloatArrayValue.push_back(value[i]);
    }
}

bool containsIgnoreCase(const std::string& targetText, const std::string& searchText)
{
    boost::iterator_range<std::string::const_iterator> iterator = boost::ifind_first(targetText, searchText);

    return iterator;
}

void adjustDoublePrecision(std::string& paramvalue) {
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1,1);
        }
    }
}

// helper classes
class WriteValueVisitor : public IGSxPAR::IValueVisitor
{
private:
    std::string m_user;
    std::string m_reason;
    time_t      m_now;

public:
    explicit WriteValueVisitor(const std::string& user, const std::string& reason)
    {
        m_user = user;
        m_reason = reason;
        m_now = time(0);
    }

    virtual void visit(const IGSxPAR::IntValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    boost::lexical_cast<std::string>(getIntParameterValue(type.name())),
                    boost::lexical_cast<std::string>(type.value()));

        gHistory.push_back(historyEntry);
        setIntParameterValue(type.name(), type.value());
        IGSxPAR::IntValue* value = new IGSxPAR::IntValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

    virtual void visit(const IGSxPAR::UIntValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    boost::lexical_cast<std::string>(getUintParameterValue(type.name())),
                    boost::lexical_cast<std::string>(type.value()));

        gHistory.push_back(historyEntry);
        setUintParameterValue(type.name(), type.value());
        IGSxPAR::UIntValue* value = new IGSxPAR::UIntValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }
    virtual void visit(const IGSxPAR::FloatValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        std::string oldVal = boost::lexical_cast<std::string>(getFloatParameterValue(type.name()));
        std::string newVal = boost::lexical_cast<std::string>(type.value());
        adjustDoublePrecision(oldVal);
        adjustDoublePrecision(newVal);
        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason, oldVal, newVal);
        gHistory.push_back(historyEntry);
        setFloatParameterValue(type.name(), type.value());
        IGSxPAR::FloatValue* value = new IGSxPAR::FloatValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }
    virtual void visit(const IGSxPAR::BoolValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    getBoolParameterValue(type.name()) == 0 ? "False (0)" : "True (1)",
                    type.value() == 0 ? "False (0)" : "True (1)");

        gHistory.push_back(historyEntry);
        setBoolParameterValue(type.name(), type.value());
        IGSxPAR::BoolValue* value = new IGSxPAR::BoolValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

    virtual void visit(const IGSxPAR::FloatArrayValue& type)
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    FloatArrayToString(getFloatArrayParameterValue(type.name())),
                    FloatArrayToString(type.value()));

        gHistory.push_back(historyEntry);
        setFloatArrayParameterValue(type.name(), type.value());
        IGSxPAR::FloatArrayValue* value = new IGSxPAR::FloatArrayValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

private:
    std::string ConstructName(std::string plainName)
    {
        std::string fullName = plainName;
        int index  = findParameterIndex(plainName);
        if( index >= 0  && !gParameters[index].unit.empty())
        {
            fullName += " (" + gParameters[index].unit + ")";
        }

        return fullName;
    }

    std::string FloatArrayToString(const std::vector<double>& value)
    {
        if (value.empty())
            return "";

        std::string result = boost::lexical_cast<std::string>(value[0]);
        adjustDoublePrecision(result);
        for (int i = 1; i < static_cast<int>(value.size()); ++i)
        {
            std::string val = boost::lexical_cast<std::string>(value[i]);
            adjustDoublePrecision(val);
            result += "," + val;
        }
        return result;
    }

};

IGSxPAR::ParameterTypePtr createParameter(gParameterType& parameter, bool readOnly)
{
    if (parameter.itemType == TYPE_int)
    {
        IGSxPAR::IntConfig intConfig(parameter.defaultIntValue, 1000000, -1000000, parameter.unit);
        IGSxPAR::IntValue intValue(parameter.name , parameter.currentIntValue);
        boost::shared_ptr<IGSxPAR::IntType> intType(new IGSxPAR::IntType(IGSxPAR::DESIGN, readOnly, intConfig, intValue));

        return intType;
    }
    else if (parameter.itemType == TYPE_uint)
    {
        IGSxPAR::UIntConfig uintConfig(parameter.defaultUintValue, 1000000, 0, parameter.unit);
        IGSxPAR::UIntValue uintValue(parameter.name , parameter.currentUintValue);
        boost::shared_ptr<IGSxPAR::UIntType> uintType(new IGSxPAR::UIntType(IGSxPAR::DESIGN, readOnly, uintConfig, uintValue));

        return uintType;
    }
    else if (parameter.itemType == TYPE_double)
    {
        IGSxPAR::FloatConfig doubleConfig(parameter.defaultDoubleValue, 1000000000.0, -1000000000.0, parameter.unit);
        IGSxPAR::FloatValue doubleValue(parameter.name , parameter.currentDoubleValue);
        boost::shared_ptr<IGSxPAR::FloatType> doubleType(new IGSxPAR::FloatType(IGSxPAR::DESIGN, readOnly, doubleConfig, doubleValue));

        return doubleType;
    }
    else if (parameter.itemType == TYPE_boolean)
    {
        IGSxPAR::BoolValue boolValue(parameter.name , parameter.currentBoolValue);
        boost::shared_ptr<IGSxPAR::BoolType> boolType(new IGSxPAR::BoolType(IGSxPAR::DESIGN, readOnly, parameter.defaultBoolValue, boolValue));

        return boolType;
    }
    else if (parameter.itemType == TYPE_floatarray)
    {
        std::vector<double> cur = parameter.currentFloatArrayValue;
        int no_of_elements = cur.size();
        std::vector<std::string> labels;
        for (int i = 0; i < no_of_elements; ++i)
        {
            labels.push_back("Value " + boost::lexical_cast<std::string>(i + 1));
        }

        std::vector<double> defaultValues;
        for (int i = 0; i < no_of_elements; ++i)
        {
            defaultValues.push_back(i * 100.01);
        }
        int max_input_count = no_of_elements;
        int min_input_count = 0;
        if (no_of_elements < 20) {
            min_input_count = no_of_elements;
        } else {
            min_input_count = no_of_elements/2;
        }
        if (no_of_elements < 2) {
            readOnly = false;
        }
        IGSxPAR::FloatVectorConfig floatVectorConfig(defaultValues, 12345, -1000000.0, parameter.unit);
        IGSxPAR::FloatArrayConfig floatArrayConfig(floatVectorConfig, labels, min_input_count, max_input_count);
        IGSxPAR::FloatArrayValue floatArrayValue(parameter.name , parameter.currentFloatArrayValue);
        boost::shared_ptr<IGSxPAR::FloatArrayType> floatArrayType(new IGSxPAR::FloatArrayType(IGSxPAR::DESIGN, readOnly, floatArrayConfig, floatArrayValue));

        return floatArrayType;
    }
    return IGSxPAR::ParameterTypePtr();
}

void PopulateHistory()
{
    int oneDay = 24 * 60 * 60;
    int oneHour = 60 * 60;
    time_t      date = time(0) - (oneDay * 10);

    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter1", date, "user 1", "reason 1", "1", "2"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter2", date, "user 1", "reason 1", "1", "3"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter1", date, "user 1", "reason 1", "1.0", "2.0"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter2", date, "user 1", "reason 1", "1,2,3", "3,4,5"));
    date = date + oneDay + oneHour;
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter1", date, "user 2", "reason 2", "2", "3"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter2", date, "user 2", "reason 2", "3", "1"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter1", date, "user 2", "reason 2", "2.0", "12.0"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter2", date, "user 2", "reason 2", "3,4,5", "3,4,6"));
}

} // namespace

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxPAR::PAR* IGSxPAR::PAR_Stub::getInstance()
{
    static PAR_Stub _instance;
    return &_instance;
}
IGSxPAR::PAR* IGSxPAR::PAR::instance = IGSxPAR::PAR_Stub::getInstance();

IGSxPAR::PAR_Stub::PAR_Stub() :  m_UpdateEventTimer(SUI::Timer::createTimer())
{
    m_UpdateEventTimer->timeout = boost::bind(&IGSxPAR::PAR_Stub::onUpdateEventTimeOut, this);
    PopulateHistory();
}

IGSxPAR::PAR_Stub::~PAR_Stub()
{
}

void IGSxPAR::PAR_Stub::onUpdateEventTimeOut()
{
    if( gCallbackSubscribed)
    {
        if(gValuesForNextEvent.empty()){
            m_UpdateEventTimer->stop();
            return;
        }else if(gValuesForNextEvent.size() == 1){
            gCallback(gValuesForNextEvent);
            gValuesForNextEvent.clear();
        }else{
            IGSxPAR::IValuePtrVector tempVector(2);
            std::copy(gValuesForNextEvent.begin(), gValuesForNextEvent.begin() + 2, tempVector.begin());
            gValuesForNextEvent.erase(gValuesForNextEvent.begin(), gValuesForNextEvent.begin() + 2);
            gCallback(tempVector);
        }
    } else {
        m_UpdateEventTimer->stop();
        gValuesForNextEvent.clear();
        return;
    }
}

void IGSxPAR::PAR_Stub::subscribeValuesChanged(ValuesChangedCallback cb)
{
    gCallback = cb;
    gCallbackSubscribed = true;
}

void IGSxPAR::PAR_Stub::unsubscribeValuesChanged()
{
    gCallbackSubscribed = false;
}

void IGSxPAR::PAR_Stub::Read( const std::string& filter, ParameterTypePtrVector& parameters )
{
    if (filter.empty())
    {
        for (int i = 0; i < getParameterCount(); ++i)
        {
            ParameterTypePtr parameterType = createParameter(gParameters[i], (i % 7 != 0));
            if (parameterType != NULL)
            {
                parameters.push_back(parameterType);
            }
        }
    } else {
        for (int i = 0; i < getParameterCount(); ++i)
        {
            if (containsIgnoreCase(gParameters[i].name , filter))
            {
                ParameterTypePtr parameterType = createParameter(gParameters[i], (i % 7 != 0));
                if (parameterType != NULL)
                {
                    parameters.push_back(parameterType);
                }
            }
        }
    }
}

void IGSxPAR::PAR_Stub::Write(const TransactionInfo& transactionInfo, const IValuePtrVector& values, StringVectorType &failed_parameters)
{
    WriteValueVisitor writeValueVisitor(transactionInfo.userId(), transactionInfo.reason());

    if (static_cast<int>(values.size()) == 4) {
       failed_parameters.push_back(values[0]->name());
       values[1]->accept(writeValueVisitor);
       values[2]->accept(writeValueVisitor);
       values[3]->accept(writeValueVisitor);
    }
    else if (static_cast<int>(values.size()) == 5) {
       values[0]->accept(writeValueVisitor);
       failed_parameters.push_back(values[1]->name());
       values[2]->accept(writeValueVisitor);
       values[3]->accept(writeValueVisitor);
       failed_parameters.push_back(values[4]->name());
    }
    else
    {
        for (int i = 0; i < static_cast<int>(values.size()); ++i)
        {
            values[i]->accept(writeValueVisitor);
        }
    }

    if (!m_UpdateEventTimer->isActive())
    {
        // the timer from the previous round may still be active
        m_UpdateEventTimer->start(2000);
    }
}

void IGSxPAR::PAR_Stub::GetChangeHistory(time_t start, time_t end, ParameterChangeHistoryVector& history)
{
    for (int i = 0; i < static_cast<int>(gHistory.size()); ++i)
    {
        if (gHistory[i]->time_of_change() >= start && gHistory[i]->time_of_change() <= end)
        {
            history.push_back(*gHistory[i]);
        }
    }
}


