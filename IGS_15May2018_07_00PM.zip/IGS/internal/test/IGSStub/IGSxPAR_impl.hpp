/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR_impl.hpp
| Author       : Jan-Pieter
| Description  : Header file for IGSxPAR stub
|
| ! \file        IGSxPAR_impl.hpp
| ! \brief       Header file for IGSxPAR stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXPAR_IMPL_HPP
#define IGSXPAR_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxPAR.hpp"
#include <FWQxUtils/SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxPAR {

class PAR_Stub : public PAR
{
public:
    static PAR* getInstance();

    PAR_Stub();
    virtual ~PAR_Stub();

    // meta data
    //functions
    virtual void Read( const std::string& filter, ParameterTypePtrVector& parameters );
    virtual void Write(const TransactionInfo&, const IValuePtrVector&, StringVectorType& failed_parameters);
    virtual void GetChangeHistory(time_t, time_t, ParameterChangeHistoryVector&);

    // data update
    virtual void subscribeValuesChanged(ValuesChangedCallback);
    virtual void unsubscribeValuesChanged();

    void onUpdateEventTimeOut();

    boost::shared_ptr<SUI::Timer> m_UpdateEventTimer;
};
}  // namespace IGSxPAR
#endif  // IGSXPAR_IMPL_HPP
