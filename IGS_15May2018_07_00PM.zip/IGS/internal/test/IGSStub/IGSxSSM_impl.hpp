/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxSSM stub
|
| ! \file        IGSxSSM_impl.hpp
| ! \brief       Header file for IGSxSSM stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXSSM_IMPL_HPP
#define IGSXSSM_IMPL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <FWQxUtils/SUITimer.h>
#include "IGSxSSM.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxSSM {

class SSM_Stub :public SSM
{
 public:
//    virtual ~SSM_Stub();
    virtual SystemFunctionPtrList functions();
    static SSMPtr GetInstance();
 protected:
    SSM_Stub();

 private:
    void init();
    void initxml();
    SystemFunctionPtrList functionTypes;
    static const std::string STRING_RESOURCE;
    static const std::string DATA_FILE_NAME;
};

class SystemFunction : public SystemFunctionType
{
public:
    explicit SystemFunction( const SystemFunctionConfigType & config);
    void set_state(const StateIDType& target);
    TransitionTypePtr get_state() const;
    void onTransitionCompleted();

private:
    StateIDType mPreviousState;
    StateIDType mCurrentState;
    boost::shared_ptr<SUI::Timer> mTimer;
};

}  // namespace IGSxSSM
#endif  // IGSXSSM_IMPL_HPP
