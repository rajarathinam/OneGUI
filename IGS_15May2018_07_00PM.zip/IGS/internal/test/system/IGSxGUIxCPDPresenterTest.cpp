/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of System Presenter test
|
| ! \file        IGSxGUIxCPDPresenterTest.cpp
| ! \brief       Implementation of System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxCPDPresenterTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(CPDPresenterTest, Test1)
{
    CPDViewStub* stubView  = new CPDViewStub();
    ASSERT_TRUE(stubView != NULL);

    ASSERT_TRUE(m_cpdManager != NULL);
    IGSxGUI::CPDPresenter* cpdpresenter = new IGSxGUI::CPDPresenter(stubView, m_cpdManager);
    ASSERT_TRUE(cpdpresenter != NULL);

    std::vector<IGSxGUI::CPD*> listCPDs = cpdpresenter->getCPDs();
    EXPECT_EQ(6, listCPDs.size());

    IGSxGUI::CPD* cpd = new IGSxGUI::CPD(IGSxCPD::MetaDescription("TestName", "TestType", "TestSubSystem", "TestDescription", "TestDescriptionFile"));
    ASSERT_TRUE(cpd != NULL);

    m_cpdManager->add(cpd);

    listCPDs = cpdpresenter->getCPDs();
    EXPECT_EQ(7, listCPDs.size());

    IGSxGUI::CPD* unknownCPD = cpdpresenter->getCPD("UNKNOWN");
    ASSERT_TRUE(unknownCPD  == NULL);

    IGSxGUI::CPD* cpd1 = cpdpresenter->getCPD("CPDFFMDFC");
    ASSERT_TRUE(cpd1  != NULL);
    EXPECT_EQ(cpd1->getName(), "CPDFFMDFC");

    ASSERT_TRUE(cpdpresenter != NULL);
    delete cpdpresenter;
    cpdpresenter = NULL;

    ASSERT_TRUE(stubView != NULL);
    delete stubView;
    stubView = NULL;
}

TEST_F(CPDPresenterTest, Test2)
{
    ASSERT_TRUE(m_cpdManager != NULL);

    CPDViewStub* stubView  = new CPDViewStub();
    ASSERT_TRUE(stubView != NULL);

    IGSxGUI::CPDPresenter* cpdpresenter = new IGSxGUI::CPDPresenter(stubView, m_cpdManager);
    ASSERT_TRUE(cpdpresenter != NULL);

    EXPECT_FALSE(cpdpresenter->startCPD(""));
    EXPECT_FALSE(cpdpresenter->startCPD("UNKNOWN"));

    IGSxGUI::CPD* cpd1 = cpdpresenter->getCPD("CPDFFMDFC");
    ASSERT_TRUE(cpd1  != NULL);
    EXPECT_EQ(cpd1->getName(), "CPDFFMDFC");
    EXPECT_FALSE(cpdpresenter->startCPD("CPDFFMDFC"));

    ASSERT_TRUE(cpdpresenter != NULL);
    delete cpdpresenter;
    cpdpresenter = NULL;

    ASSERT_TRUE(stubView != NULL);
    delete stubView;
    stubView = NULL;
}
