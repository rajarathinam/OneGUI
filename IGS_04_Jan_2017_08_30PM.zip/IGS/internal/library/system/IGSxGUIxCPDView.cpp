/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <string>
#include <list>
#include <vector>
#include <algorithm>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include <SUILabel.h>
#include <SUIDialog.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIGroupBox.h>
#include <SUIRadioButton.h>
#include <SUITimer.h>
#include <SUITextArea.h>
#include <SUITableWidget.h>
#include <SUIDropDown.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxCPD.xml");
const std::string IGSxGUI::CPDView::IMAGE_CLOCK = IGS::Resource::path("IGSxSystem_clock.png");
const std::string IGSxGUI::CPDView::STRING_ALL_CPDS = "All CPDs";
const std::string IGSxGUI::CPDView::STRING_CALIBRATION = "Calibration";
const std::string IGSxGUI::CPDView::STRING_PERFORMANCE = "Performance";
const std::string IGSxGUI::CPDView::STRING_DIAGNOSTICS = "Diagnostics";
const std::string IGSxGUI::CPDView::STRING_NO_ACTIVE_CPD = "There is no active CPD";
const std::string IGSxGUI::CPDView::STRING_ACTIVE_CPD = "This is an active CPD";

const std::string IGSxGUI::CPDView::STRING_TIME = "Time";
const std::string IGSxGUI::CPDView::STRING_DATE = "Date";
const std::string IGSxGUI::CPDView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::CPDView::STYLE_CURRENTPAGE = "currentPage";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPD = "ActiveCPD";
const std::string IGSxGUI::CPDView::STYLE_NO_ACTIVE_CPD = "NoActiveCPD";
const int IGSxGUI::CPDView::TIMER_INTERVAL = 4000;

IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_timer(SUI::Timer::createTimer()),
    m_numTotalPages(0),
    m_numLastPageItems(0),
    m_currentPageNo(0),
    m_ActiveCPDBoxToggleFlag(false),
    m_bRunningCPD(false),
    m_selectedSubSystem("")
{
    m_presenter = new CPDPresenter(this, pCPDManager);
}

IGSxGUI::CPDView::~CPDView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

const std::string IGSxGUI::CPDView::currentDateTime(const std::string& dateTime) const
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%l:%M%p", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}

void IGSxGUI::CPDView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
}

void IGSxGUI::CPDView::init()
{
    sui->lblActiveCPD->setColor(SUI::ColorEnum::Gray);
    sui->lblAllCPDs->setColor(SUI::ColorEnum::Gray);

    sui->gbxCPD->setBGColor(SUI::ColorEnum::White);

    sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_CPD);
    sui->lblDescription->setText(STRING_NO_ACTIVE_CPD);
    sui->lblType->setVisible(false);
    sui->lblName->setVisible(false);
    sui->lblStatus->setVisible(false);
    sui->btnShowCPD->setVisible(false);
    sui->btnCPDDetail->setVisible(false);

    sui->imvClock->getGraphicsScene()->setBackgroundImageFile(IMAGE_CLOCK);
    sui->lblDateTime->setText(currentDateTime(STRING_DATE) + currentDateTime(STRING_TIME));
    sui->tawCPDSubsystem->showGrid(false);
    sui->rbtnAll->setChecked(true);

    if (m_presenter != NULL)
    {
        m_listCPD = m_presenter->getCPDs();
        m_listSubsystemCPDs = m_presenter->getCPDs();
    }
    loadTestTypes();
    loadSubSystems();
    loadCPDs();
}

void IGSxGUI::CPDView::initNumberedButtons(const int numTotalPages) const
{
    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if ( boost::lexical_cast<int>(m_listDisplayButtons[i]->getText()) <= numTotalPages)
        {
            m_listDisplayButtons[i]->setEnabled(true);
        } else {
            m_listDisplayButtons[i]->setEnabled(false);
        }
    }
}

void IGSxGUI::CPDView::fetchCPDs(const int nCurrentPageNumber) const
{
    size_t j  = ((nCurrentPageNumber - 1)*10);

    for (size_t i = 0 ; i < m_listCPDUCT.size(); i++)
    {
        if ( j < m_listCPD.size())
        {
            m_listCPDUCT[i]->setVisible(true);
            m_listCPDNameLabels[i]->setText(m_listCPD[j]->getName());
            m_listCPDTypeLabels[i]->setText(m_listCPD[j]->getTestType());
            m_listCPDDescriptionLabels[i]->setText(m_listCPD[j]->getDescription());
            ++j;
        } else {
            m_listCPDUCT[i]->setVisible(false);
        }
    }
}

void IGSxGUI::CPDView::onButtonPrevPressed()
{
    --m_currentPageNo;

    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    } else if (m_currentPageNo < m_numTotalPages) {
        sui->btnNext->setEnabled(true);
    }
    fetchCPDs(m_currentPageNo);

    if (m_currentPageNo <= 4 &&  m_currentPageNo >= 0)
    {
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    } else {
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }
}

void IGSxGUI::CPDView::onButtonNextPressed()
{
    ++m_currentPageNo;

    if (m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    } else if (m_currentPageNo > 1) {
        sui->btnPrev->setEnabled(true);
    }
    fetchCPDs(m_currentPageNo);

    if (m_currentPageNo <= 4 &&  m_currentPageNo >= 0)
    {
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    } else {
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }
}

void IGSxGUI::CPDView::modifyPrevNextButtons() const
{
    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    } else if (m_currentPageNo < m_numTotalPages) {
        sui->btnNext->setEnabled(true);
    }

    if (m_currentPageNo == m_numTotalPages) {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    } else if (m_currentPageNo > 1) {
        sui->btnPrev->setEnabled(true);
    }
}

void IGSxGUI::CPDView::setNumberedButtonStyles(const int nCurrentPage, const std::string style) const
{
    sui->btnOne->setStyleSheetClass(STYLE_NORMAL);
    sui->btnTwo->setStyleSheetClass(STYLE_NORMAL);
    sui->btnThree->setStyleSheetClass(STYLE_NORMAL);
    sui->btnFour->setStyleSheetClass(STYLE_NORMAL);

    if (nCurrentPage == 1)
    {
        sui->btnOne->setStyleSheetClass(style);
    } else if (nCurrentPage == 2) {
        sui->btnTwo->setStyleSheetClass(style);
    } else if (nCurrentPage == 3) {
        sui->btnThree->setStyleSheetClass(style);
    } else if (nCurrentPage == 4) {
        sui->btnFour->setStyleSheetClass(style);
    }
}

void IGSxGUI::CPDView::onButtonOnePressed()
{
    if (m_numTotalPages >= 1)
    {
        m_currentPageNo = 1;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onButtonTwoPressed()
{
    if (m_numTotalPages >= 2)
    {
        m_currentPageNo = 2;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onButtonThreePressed()
{
    if (m_numTotalPages >= 3)
    {
        m_currentPageNo = 3;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onButtonFourPressed()
{
    if (m_numTotalPages >= 4)
    {
        m_currentPageNo = 4;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onActiveCPDShowButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    } else {
        sui->gbxReport->setVisible(true);
        sui->lblCPDDescDescription->setText(sui->lblName->getText());
        sui->lblCPDDescName1->setText(sui->lblName->getText());
        sui->lblCPDDescType1->setText(sui->lblType->getText());
        sui->txaCPDHPACDetail->clearText();
        sui->txaCPDHPACDetail->setText(sui->lblName->getText());
        sui->txaCPDHPACAttention->clearText();
        sui->txaCPDHPACAttention->setText(sui->lblType->getText());
    }
}

void IGSxGUI::CPDView::onWarningCloseButtonPressed()
{
    sui->gbxWarning->setVisible(false);
}

void IGSxGUI::CPDView::onWariningTimeout()
{
    sui->gbxWarning->setVisible(false);
}

void IGSxGUI::CPDView::onButtonTestReportPressed()
{
    sui->gbxPageOne->setVisible(false);
    sui->gbxPageTwo->setVisible(true);
}

void IGSxGUI::CPDView::onSubsystemPressed()
{
    sui->gbxPageOne->setVisible(true);
    sui->gbxPageTwo->setVisible(false);

    std::list<std::string> items = sui->tawCPDSubsystem->getSelectedItems();
    std::string strSelectedRow = items.front();

    strSelectedRow.erase(0, 20);
    strSelectedRow.erase(strSelectedRow.size()-2, strSelectedRow.size());
    std::string selectedText = sui->tawCPDSubsystem->getItemText((boost::lexical_cast<int>(strSelectedRow)-1), 0);

    int position = selectedText.find('(');
    selectedText.erase(position, selectedText.size());
    boost::trim(selectedText);
    m_selectedSubSystem = selectedText;

    std::vector<CPD*> listSubsystemCPDs;

    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
         if ((found != std::string::npos) || (subsys.name == selectedText))
         {
             listSubsystemCPDs.push_back(subsys.cpd);
         }
    }
    intersectCPDs(getTestTypeCPDs(), listSubsystemCPDs);
    loadCPDs();
}

void IGSxGUI::CPDView::onButtonShowReportsPressed()
{
    for (size_t i = 0 ; i < 4; i++)
    {
        m_listCPDReportGroupBox[i]->setVisible(false);
        m_listCPDReportNameLabels[i]->setText("");
        m_listCPDReportTypeLabels[i]->setText("");
        m_listCPDReportDescriptionLabels[i]->setText("");
    }
    std::list<std::string> selectedItems = sui->ddbSubsystem->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::string selectedText = selectedItems.front();

        int position = selectedText.find('(');
        selectedText.erase(position, selectedText.size());
        boost::trim(selectedText);

        std::vector<CPD*> listSubsystemCPDs;

        for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
        {
             container subsys = m_listSubsystems[i];

             std::size_t found = selectedText.find(STRING_ALL_CPDS);
             if ((found != std::string::npos) || (subsys.name == selectedText))
             {
                 listSubsystemCPDs.push_back(subsys.cpd);
             }
        }

        for (size_t i = 0 ; i < listSubsystemCPDs.size(); i++)
        {
            if (i > 3)
            {
                break;
            }
            CPD* cpd = listSubsystemCPDs[i];

            if (cpd != NULL)
            {
                m_listCPDReportGroupBox[i]->setVisible(true);
                m_listCPDReportNameLabels[i]->setText(cpd->getName());
                m_listCPDReportTypeLabels[i]->setText(cpd->getTestType());
                m_listCPDReportDescriptionLabels[i]->setText(cpd->getDescription());
            }
        }
    }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestCPDsByName(const std::string testtypeName) const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++)
    {
         IGSxGUI::container testtype = m_listTestTypes[i];

         if (testtype.name == testtypeName)
         {
             listTestTypeCPDs.push_back(testtype.cpd);
         }
    }
    return listTestTypeCPDs;
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getSelectedSubSystemCPDs() const
{
    std::vector<IGSxGUI::CPD*> listSubsystemCPDs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
         if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
         {
             listSubsystemCPDs.push_back(subsys.cpd);
         }
    }
    return listSubsystemCPDs;
}

void IGSxGUI::CPDView::intersectCPDs(std::vector<IGSxGUI::CPD *> listTestTypeCPDs, std::vector<IGSxGUI::CPD *> listSubSystemCPDs)
{
    m_listCPD.clear();

    std::sort(listSubSystemCPDs.begin(), listSubSystemCPDs.end());
    std::sort(listTestTypeCPDs.begin(), listTestTypeCPDs.end());

    std::set_intersection(listSubSystemCPDs.begin(), listSubSystemCPDs.end(), listTestTypeCPDs.begin(), listTestTypeCPDs.end(), std::back_inserter(m_listCPD));

    if ((m_listCPD.size() <= 0) && sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestTypeCPDs() const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    if (sui->rbtnAll->isChecked())
    {
        listTestTypeCPDs = m_presenter->getCPDs();
    } else if (sui->rbtnCalibration->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_CALIBRATION);
    } else if (sui->rbtnPerformance->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_PERFORMANCE);
    } else if (sui->rbtnDiagnostics->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_DIAGNOSTICS);
    }
    return listTestTypeCPDs;
}

void IGSxGUI::CPDView::onRadioButtonAllPressed()
{
  if (sui->rbtnAll->isChecked())
  {
    intersectCPDs(m_presenter->getCPDs(), getSelectedSubSystemCPDs());
    loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonCalibrationPressed()
{
  if (sui->rbtnCalibration->isChecked())
  {
      intersectCPDs(getTestCPDsByName(STRING_CALIBRATION), getSelectedSubSystemCPDs());
      loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonPerformancePressed()
{
  if (sui->rbtnPerformance->isChecked())
  {
      intersectCPDs(getTestCPDsByName(STRING_PERFORMANCE), getSelectedSubSystemCPDs());
      loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonDiagnosticsPressed()
{
    if (sui->rbtnDiagnostics->isChecked())
    {
        intersectCPDs(getTestCPDsByName(STRING_DIAGNOSTICS), getSelectedSubSystemCPDs());
        loadCPDs();
    }
}

void IGSxGUI::CPDView::loadCPDs()
{
    m_numTotalPages = m_listCPD.size() / m_listCPDUCT.size();
    m_numLastPageItems = m_listCPD.size() % m_listCPDUCT.size();

    m_currentPageNo = 1;

    if ( m_numLastPageItems > 0 )
    {
        ++m_numTotalPages;
    }

    if (m_numTotalPages == 0)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }

    if (m_numTotalPages == 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    if (m_numTotalPages > 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(true);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    initNumberedButtons(m_numTotalPages);
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::CPDView::updateStatus(std::string /*strCPD*/, IGS::Result result)
{
    if (result == IGS::OK)
    {
        m_bRunningCPD = false;

        sui->gbxCPD->setBGColor(SUI::ColorEnum::White);
        sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_CPD);
        sui->lblDescription->setText(STRING_NO_ACTIVE_CPD);
        sui->lblType->setVisible(false);
        sui->lblName->setVisible(false);
        sui->lblStatus->setVisible(false);
        sui->btnShowCPD->setVisible(false);
        sui->btnCPDDetail->setVisible(false);
    }
}

void IGSxGUI::CPDView::startCPD(const std::string cpdName, const std::string cpdType)
{
    if (!m_bRunningCPD)
    {
        if (m_presenter->startCPD(cpdName))
        {
           m_bRunningCPD = true;

           sui->gbxCPD->setBGColor(SUI::ColorEnum::Blue);
           sui->lblDescription->setStyleSheetClass(STYLE_ACTIVE_CPD);
           sui->lblDescription->setText(STRING_ACTIVE_CPD);
           sui->lblName->setVisible(true);
           sui->lblName->setText(cpdName);
           sui->lblType->setVisible(true);
           sui->lblType->setText(cpdType);
           sui->lblStatus->setVisible(true);
           sui->btnShowCPD->setVisible(true);
           sui->btnCPDDetail->setVisible(true);
        }
    } else {
        sui->gbxWarning->setBGColor(SUI::ColorEnum::Blue);
        sui->gbxWarning->setVisible(true);
        m_timer->start(TIMER_INTERVAL);
    }
}

void IGSxGUI::CPDView::onButtonCPD1StartPressed()
{
    startCPD(sui->lblCPD1Name->getText(), sui->lblCPD1Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD2StartPressed()
{
    startCPD(sui->lblCPD2Name->getText(), sui->lblCPD2Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD3StartPressed()
{
    startCPD(sui->lblCPD3Name->getText(), sui->lblCPD3Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD4StartPressed()
{
    startCPD(sui->lblCPD4Name->getText(), sui->lblCPD4Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD5StartPressed()
{
    startCPD(sui->lblCPD5Name->getText(), sui->lblCPD5Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD6StartPressed()
{
    startCPD(sui->lblCPD6Name->getText(), sui->lblCPD6Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD7StartPressed()
{
    startCPD(sui->lblCPD7Name->getText(), sui->lblCPD7Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD8StartPressed()
{
    startCPD(sui->lblCPD8Name->getText(), sui->lblCPD8Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD9StartPressed()
{
    startCPD(sui->lblCPD9Name->getText(), sui->lblCPD9Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD10StartPressed()
{
    startCPD(sui->lblCPD10Name->getText(), sui->lblCPD10Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD1DetailPressed()
{
    setTextArea(sui->lblCPD1Description->getText(), sui->lblCPD1Name->getText(), sui->lblCPD1Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD2DetailPressed()
{
    setTextArea(sui->lblCPD2Description->getText(), sui->lblCPD2Name->getText(), sui->lblCPD2Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD3DetailPressed()
{
    setTextArea(sui->lblCPD3Description->getText(), sui->lblCPD3Name->getText(), sui->lblCPD3Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD4DetailPressed()
{
    setTextArea(sui->lblCPD4Description->getText(), sui->lblCPD4Name->getText(), sui->lblCPD4Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD5DetailPressed()
{
    setTextArea(sui->lblCPD5Description->getText(), sui->lblCPD5Name->getText(), sui->lblCPD5Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD6DetailPressed()
{
    setTextArea(sui->lblCPD6Description->getText(), sui->lblCPD6Name->getText(), sui->lblCPD6Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD7DetailPressed()
{
    setTextArea(sui->lblCPD7Description->getText(), sui->lblCPD7Name->getText(), sui->lblCPD7Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD8DetailPressed()
{
    setTextArea(sui->lblCPD8Description->getText(), sui->lblCPD8Name->getText(), sui->lblCPD8Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD9DetailPressed()
{
    setTextArea(sui->lblCPD9Description->getText(), sui->lblCPD9Name->getText(), sui->lblCPD9Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD10DetailPressed()
{
    setTextArea(sui->lblCPD10Description->getText(), sui->lblCPD10Name->getText(), sui->lblCPD10Type->getText());
}

void IGSxGUI::CPDView::loadContainers()
{
    m_listCPDUCT.clear();
    m_listCPDNameLabels.clear();
    m_listCPDTypeLabels.clear();
    m_listCPDDescriptionLabels.clear();
    m_listCPDTimeLabels.clear();
    m_listDisplayButtons.clear();
    m_listCPDReportGroupBox.clear();
    m_listCPDReportNameLabels.clear();
    m_listCPDReportTypeLabels.clear();
    m_listCPDReportDescriptionLabels.clear();

    m_listCPDUCT.push_back(sui->uctCPD1);
    m_listCPDUCT.push_back(sui->uctCPD2);
    m_listCPDUCT.push_back(sui->uctCPD3);
    m_listCPDUCT.push_back(sui->uctCPD4);
    m_listCPDUCT.push_back(sui->uctCPD5);
    m_listCPDUCT.push_back(sui->uctCPD6);
    m_listCPDUCT.push_back(sui->uctCPD7);
    m_listCPDUCT.push_back(sui->uctCPD8);
    m_listCPDUCT.push_back(sui->uctCPD9);
    m_listCPDUCT.push_back(sui->uctCPD10);

    m_listCPDNameLabels.push_back(sui->lblCPD1Name);
    m_listCPDNameLabels.push_back(sui->lblCPD2Name);
    m_listCPDNameLabels.push_back(sui->lblCPD3Name);
    m_listCPDNameLabels.push_back(sui->lblCPD4Name);
    m_listCPDNameLabels.push_back(sui->lblCPD5Name);
    m_listCPDNameLabels.push_back(sui->lblCPD6Name);
    m_listCPDNameLabels.push_back(sui->lblCPD7Name);
    m_listCPDNameLabels.push_back(sui->lblCPD8Name);
    m_listCPDNameLabels.push_back(sui->lblCPD9Name);
    m_listCPDNameLabels.push_back(sui->lblCPD10Name);

    m_listCPDTypeLabels.push_back(sui->lblCPD1Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD2Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD3Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD4Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD5Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD6Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD7Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD8Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD9Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD10Type);

    m_listCPDDescriptionLabels.push_back(sui->lblCPD1Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD2Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD3Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD4Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD5Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD6Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD7Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD8Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD9Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD10Description);

    m_listCPDTimeLabels.push_back(sui->lblCPD1Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD2Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD3Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD4Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD5Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD6Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD7Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD8Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD9Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD10Time);

    m_listDisplayButtons.push_back(sui->btnOne);
    m_listDisplayButtons.push_back(sui->btnTwo);
    m_listDisplayButtons.push_back(sui->btnThree);
    m_listDisplayButtons.push_back(sui->btnFour);

    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView1);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView2);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView3);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView4);

    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest1);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest2);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest3);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest4);

    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType1);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType2);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType3);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType4);

    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc1);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc2);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc3);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc4);
}

void IGSxGUI::CPDView::loadTestTypes()
{
    container testtype;
    for (size_t i = 0 ; i < m_listCPD.size(); i++)
    {
        testtype.name = m_listCPD[i]->getTestType();
        testtype.cpd = m_listCPD[i];
        m_listTestTypes.push_back(testtype);
    }
}

void IGSxGUI::CPDView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0; i < m_listSubsystemCPDs.size(); i++)
    {
        subsystem.name = m_listSubsystemCPDs[i]->getSubsystem();
        subsystem.cpd = m_listSubsystemCPDs[i];
        listStringSubsystem.push_back(m_listSubsystemCPDs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            container subsystem = m_listSubsystems[j];

            if (listStringSubsystem[i] == subsystem.name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;
    std::string strAllCPDs =  sui->tawCPDSubsystem->getItemText(0, 0) + " (" + boost::lexical_cast<std::string>(m_listSubsystemCPDs.size()) + ")";
    sui->tawCPDSubsystem->setItemText(0, 0, strAllCPDs);
    listTestReportSubSystemItems.push_back(strAllCPDs);

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        subSystemCount subsyscount = m_listSubsystemCount[i];

        std::string subsys = subsyscount.nameSubsystem + " (" + boost::lexical_cast<std::string>(subsyscount.count) + ")";
        std::list<std::string> listRowData;

        listRowData.push_back(subsys);
        listTestReportSubSystemItems.push_back(subsys);

        sui->tawCPDSubsystem->insertRows(i+1, 1);
        sui->tawCPDSubsystem->addData(i+1, listRowData);
    }
    sui->ddbSubsystem->addItems(listTestReportSubSystemItems);
    sui->ddbSubsystem->selectItem(1);
    sui->tawCPDSubsystem->selectItem(0);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->btnShowCPD->clicked     = boost::bind(&CPDView::onActiveCPDShowButtonPressed, this);
    sui->btnCPDDetail->clicked   = boost::bind(&CPDView::onActiveCPDDetailButtonPressed, this);
    sui->rbtnAll->checkStateChanged = boost::bind(&CPDView::onRadioButtonAllPressed, this);
    sui->rbtnCalibration->checkStateChanged = boost::bind(&CPDView::onRadioButtonCalibrationPressed, this);
    sui->rbtnPerformance->checkStateChanged = boost::bind(&CPDView::onRadioButtonPerformancePressed, this);
    sui->rbtnDiagnostics->checkStateChanged = boost::bind(&CPDView::onRadioButtonDiagnosticsPressed, this);

    sui->btnCPD1Start->clicked    = boost::bind(&CPDView::onButtonCPD1StartPressed, this);
    sui->btnCPD2Start->clicked    = boost::bind(&CPDView::onButtonCPD2StartPressed, this);
    sui->btnCPD3Start->clicked    = boost::bind(&CPDView::onButtonCPD3StartPressed, this);
    sui->btnCPD4Start->clicked    = boost::bind(&CPDView::onButtonCPD4StartPressed, this);
    sui->btnCPD5Start->clicked    = boost::bind(&CPDView::onButtonCPD5StartPressed, this);
    sui->btnCPD6Start->clicked    = boost::bind(&CPDView::onButtonCPD6StartPressed, this);
    sui->btnCPD7Start->clicked    = boost::bind(&CPDView::onButtonCPD7StartPressed, this);
    sui->btnCPD8Start->clicked    = boost::bind(&CPDView::onButtonCPD8StartPressed, this);
    sui->btnCPD9Start->clicked    = boost::bind(&CPDView::onButtonCPD9StartPressed, this);
    sui->btnCPD10Start->clicked    = boost::bind(&CPDView::onButtonCPD10StartPressed, this);

    sui->btnCPD1Detail->clicked    = boost::bind(&CPDView::onButtonCPD1DetailPressed, this);
    sui->btnCPD2Detail->clicked    = boost::bind(&CPDView::onButtonCPD2DetailPressed, this);
    sui->btnCPD3Detail->clicked    = boost::bind(&CPDView::onButtonCPD3DetailPressed, this);
    sui->btnCPD4Detail->clicked    = boost::bind(&CPDView::onButtonCPD4DetailPressed, this);
    sui->btnCPD5Detail->clicked    = boost::bind(&CPDView::onButtonCPD5DetailPressed, this);
    sui->btnCPD6Detail->clicked    = boost::bind(&CPDView::onButtonCPD6DetailPressed, this);
    sui->btnCPD7Detail->clicked    = boost::bind(&CPDView::onButtonCPD7DetailPressed, this);
    sui->btnCPD8Detail->clicked    = boost::bind(&CPDView::onButtonCPD8DetailPressed, this);
    sui->btnCPD9Detail->clicked    = boost::bind(&CPDView::onButtonCPD9DetailPressed, this);
    sui->btnCPD10Detail->clicked    = boost::bind(&CPDView::onButtonCPD10DetailPressed, this);

    sui->btnPrev->clicked    = boost::bind(&CPDView::onButtonPrevPressed, this);
    sui->btnNext->clicked    = boost::bind(&CPDView::onButtonNextPressed, this);
    sui->btnOne->clicked    = boost::bind(&CPDView::onButtonOnePressed, this);
    sui->btnTwo->clicked    = boost::bind(&CPDView::onButtonTwoPressed, this);
    sui->btnThree->clicked    = boost::bind(&CPDView::onButtonThreePressed, this);
    sui->btnFour->clicked    = boost::bind(&CPDView::onButtonFourPressed, this);
    sui->btnTestReport->clicked    = boost::bind(&CPDView::onButtonTestReportPressed, this);
    sui->btnShowReports->clicked    = boost::bind(&CPDView::onButtonShowReportsPressed, this);

    sui->tawCPDSubsystem->rowClicked = boost::bind(&CPDView::onSubsystemPressed, this);

    m_timer->timeout = boost::bind(&CPDView::onWariningTimeout, this);
    sui->btnWarningClose->clicked = boost::bind(&CPDView::onWarningCloseButtonPressed, this);
}

void IGSxGUI::CPDView::setTextArea(const std::string cpdDescription, const std::string cpdTestName, const std::string cpdTestType) const
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    } else {
        sui->gbxReport->setVisible(true);
        sui->lblCPDDescDescription->setText(cpdDescription);
        sui->lblCPDDescName1->setText(cpdTestName);
        sui->lblCPDDescType1->setText(cpdTestType);
        sui->txaCPDHPACDetail->clearText();
        sui->txaCPDHPACDetail->setText(cpdTestName);
        sui->txaCPDHPACAttention->clearText();
        sui->txaCPDHPACAttention->setText(cpdTestType);
    }
}

void IGSxGUI::CPDView::onActiveCPDDetailButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    } else {
        sui->gbxReport->setVisible(true);
        sui->lblCPDDescDescription->setText(sui->lblName->getText());
        sui->lblCPDDescName1->setText(sui->lblName->getText());
        sui->lblCPDDescType1->setText(sui->lblType->getText());
        sui->txaCPDHPACDetail->clearText();
        sui->txaCPDHPACDetail->setText(sui->lblName->getText());
        sui->txaCPDHPACAttention->clearText();
        sui->txaCPDHPACAttention->setText(sui->lblType->getText());
    }
}

