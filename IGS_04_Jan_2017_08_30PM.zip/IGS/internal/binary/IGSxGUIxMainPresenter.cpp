/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application Presenter
|
| ! \file        IGSxGUIxMainPresenter.cpp
| ! \brief       Implementation of Main application Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMainPresenter.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::MainPresenter::~MainPresenter()
{
    // Do not delete m_view, we are not the owner.
}

void IGSxGUI::MainPresenter::OnErrorStateChange(const std::string& eMsg)
{
    m_view->showError(eMsg, getTimeStamp());
}

IGSxGUI::MainPresenter::MainPresenter(IGSxGUI::IMainView* view)
{
    if (view != NULL)
    {
        m_view = view;
    }
}

std::string IGSxGUI::MainPresenter::getTimeStamp() const
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buff[80];
    tstruct = *localtime_r(&now, &tstruct);
    strftime(buff, sizeof(buff), "%H:%M%p", &tstruct);
    std::string sTime(buff);
    strftime(buff, sizeof(buff), "%d/%m/%Y", &tstruct);
    std::string sDate(buff);
    return sDate+" "+sTime;
}
