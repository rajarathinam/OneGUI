/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.hpp
| ! \brief       Header file for KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_KPIVALUESET_HPP
#define IGSXKPI_KPIVALUESET_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxKPI.hpp"

using std::string;
using std::vector;
using IGSxKPI::KPIValueSetDefinition;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {

class KPIValueSet
{
 public:
    explicit KPIValueSet(const KPIValueSetDefinition &kpiDefinition);
    virtual ~KPIValueSet();

    string getName() const;
    string getDescription() const;
    string getUnit() const;

    void addValue(const vector<double> *valueList);
    void addTime(const time_t time);
    vector<double> getValue() const;
    time_t getTime() const;

 private:
    KPIValueSet(KPIValueSet const &);
    KPIValueSet& operator=(KPIValueSet const &);

    string m_name;  // KPI Value name
    string m_desc;  // KPI Value description
    string m_unit;  // KPI Value unit

    time_t m_time;
    vector<double> m_valueList;
};
}  // namespace IGSxGUI
#endif  // IGSXKPI_KPIVALUESET_HPP
