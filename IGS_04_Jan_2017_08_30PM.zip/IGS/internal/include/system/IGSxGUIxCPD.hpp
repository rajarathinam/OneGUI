/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPD.hpp
| Author       : Venugopal S
| Description  : Header file for CPD
|
| ! \file        IGSxGUIxCPD.hpp
| ! \brief       Header file for CPD
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPD_HPP
#define IGSXGUIXCPD_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include "IGSxCPD.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class CPD
{
 public:
    explicit CPD(const IGSxCPD::MetaDescription &metaDescription);
    virtual ~CPD();

    std::string getName() const;
    std::string getDescription() const;
    std::string getSubsystem() const;
    std::string getHtmlFile() const;
    std::string getTestType() const;

    bool start() const;
    bool onStopped(IGS::Result result);

    typedef boost::signals2::signal<void (std::string, IGS::Result)> Stopped;
    typedef Stopped::slot_type stoppedCallback;

    boost::signals2::connection registerToCPDStopped(const stoppedCallback& cb);

 private:
    CPD(CPD const &);
    CPD& operator=(CPD const &);

    std::string m_name;
    std::string m_subsystem;
    std::string m_description;
    std::string m_htmlFile;
    std::string m_testType;

    Stopped cpdStopped;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXCPD_HPP
