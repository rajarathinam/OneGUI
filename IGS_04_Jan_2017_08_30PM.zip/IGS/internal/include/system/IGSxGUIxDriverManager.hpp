/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManager.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver manager
|
| ! \file        IGSxGUIxDriverManager.hpp
| ! \brief       Header file for Driver manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVERMANAGER_HPP
#define IGSXGUIXDRIVERMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxSystemFunction.hpp"
#include "IGSxGUIxSystemState.hpp"
#include "IGSxITS.hpp"

using std::vector;
using IGSxITS::DriverStatus;
using IGSxITS::InitTerminate;
using IGSxITS::MetaDescriptions;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class DriverManager
{
 public:
    DriverManager();
    virtual ~DriverManager();

    void addSystemFunctions(const IGSxITS::MetaDescriptions metaDescription);
    SystemFunction* getSystemFunction(const std::string& name) const;
    std::vector<SystemFunction*> getSystemFunctions() const;
    Driver* getDriver(const std::string &name) const;
    SystemState::SystemStateEnum getSystemState() const;

    void registerToSystemStateChanged(const SystemStateChangedCallback& cb);
    void unregisterToSystemStateChanged(const SystemStateChangedCallback& cb);
    void setSystemState(SystemState::SystemStateEnum state);
    void initialize();

 private:
    void determineSystemState();
    void onDriverStatusChanged(const std::string& driverName, const DriverStatus& status) const;
    vector<SystemFunction*> m_systemFunctions;
    systemStateChanged m_systemStateChanged;
    SystemState::SystemStateEnum m_systemState;
    static const char* ERROR_ADDING_SYSFUN;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDRIVERMANAGER_HPP
