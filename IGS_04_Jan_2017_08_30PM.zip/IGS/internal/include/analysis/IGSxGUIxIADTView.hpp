/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIADTView.hpp
| Author       : Raja A
| Description  : Interface file for ADT view
|
| ! \file        IGSxGUIxIADTView.hpp
| ! \brief       Interface file for ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIADTVIEW_HPP
#define IGSXGUIXIADTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <list>
#include <vector>
#include <map>
#include <string>
#include "IGSxITS.hpp"
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IADTView
{
 public:
    IADTView() {}
    virtual ~IADTView() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void updateStatus(IGS::Result result) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIADTVIEW_HPP
