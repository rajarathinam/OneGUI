/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include <SUILabel.h>
#include <SUIDialog.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIGroupBox.h>
#include <SUIRadioButton.h>
#include <SUITimer.h>
#include <SUITextArea.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxCPD.xml");
const std::string IGSxGUI::CPDView::IMAGE_CLOCK = IGS::Resource::path("IGSxSystem_clock.png");
const std::string IGSxGUI::CPDView::STRING_TIME = "Time";
const std::string IGSxGUI::CPDView::STRING_DATE = "Date";
const int IGSxGUI::CPDView::TIMER_INTERVAL = 4000;

IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_timer(SUI::Timer::createTimer()),
    m_numTotalPages(0),
    m_numLastPageItems(0),
    m_currentPageNo(0),
    m_CPDDetailButtonToggleFlag(false)
{
    m_presenter = new CPDPresenter(this,pCPDManager);    
}

IGSxGUI::CPDView::~CPDView()
{
    delete m_presenter;
    delete sui;
}

const std::string IGSxGUI::CPDView::currentDateTime(const std::string& dateTime)
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%l:%M%p", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}

void IGSxGUI::CPDView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
}

void IGSxGUI::CPDView::init()
{
    sui->imvClock->getGraphicsScene()->setBackgroundImageFile(IMAGE_CLOCK);
    sui->lblDateTime->setText(currentDateTime(STRING_DATE) + currentDateTime(STRING_TIME));
    sui->txaCPDDetail->setVisible(false);

    m_listCPD = m_presenter->getCPDs();

    m_numTotalPages = m_listCPD.size() / m_listCPDUCT.size();
    m_numLastPageItems = m_listCPD.size() % m_listCPDUCT.size();

    m_currentPageNo = 1;

    //m_numTotalPages    = 2;
    //m_numLastPageItems = 3;

    if( m_numLastPageItems > 0 )
    {
        ++m_numTotalPages;
    }

    if(m_numTotalPages == 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
    }

    if(m_numTotalPages > 1)
    {
        sui->btnPrev->setEnabled(false);
    }

    initNumberedButtons(m_numTotalPages);

    /*for (size_t i = 0; i < m_listCPDUCT.size(); i++)
    {
        m_listCPDNameLabels[i]->setText(m_listCPD[i]->getName());
        m_listCPDTypeLabels[i]->setText(m_listCPD[i]->getTestType());
        m_listCPDDescriptionLabels[i]->setText(m_listCPD[i]->getDescription());
    }*/
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::initNumberedButtons(int numTotalPages)
{
    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if( boost::lexical_cast<int>(m_listDisplayButtons[i]->getText()) <= numTotalPages)
        {
            m_listDisplayButtons[i]->setEnabled(true);
        }
        else
        {
            m_listDisplayButtons[i]->setEnabled(false);
        }
    }
}

void IGSxGUI::CPDView::fetchCPDs(int nCurrentPageNumber)
{
    int j  = ((nCurrentPageNumber - 1)*10);

    for (size_t i = 0 ; i < m_listCPDUCT.size(); i++)
    {
        m_listCPDNameLabels[i]->setText(m_listCPD[j]->getName());
        m_listCPDTypeLabels[i]->setText(m_listCPD[j]->getTestType());
        m_listCPDDescriptionLabels[i]->setText(m_listCPD[j]->getDescription());
        ++j;
    }
}

void IGSxGUI::CPDView::onButtonPrevPressed()
{
    --m_currentPageNo;

    if(m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    }
    else if(m_currentPageNo < m_numTotalPages)
    {
        sui->btnNext->setEnabled(true);
    }
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onButtonNextPressed()
{
    ++m_currentPageNo;

    if(m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    }
    else if(m_currentPageNo > 1)
    {
        sui->btnPrev->setEnabled(true);
    }
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::modifyPrevNextButtons()
{
    if(m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    }
    else if(m_currentPageNo < m_numTotalPages)
    {
        sui->btnNext->setEnabled(true);
    }

    if(m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    }
    else if(m_currentPageNo > 1)
    {
        sui->btnPrev->setEnabled(true);
    }
}

void IGSxGUI::CPDView::onButtonOnePressed()
{
    if(m_numTotalPages >= 1 )
    {
        m_currentPageNo = 1;
    }
    modifyPrevNextButtons();
}

void IGSxGUI::CPDView::onButtonTwoPressed()
{
    if(m_numTotalPages >= 2 )
    {
        m_currentPageNo = 2;
    }
    modifyPrevNextButtons();
}

void IGSxGUI::CPDView::onButtonThreePressed()
{
    if(m_numTotalPages >= 3 )
    {
        m_currentPageNo = 3;
    }
    modifyPrevNextButtons();
}

void IGSxGUI::CPDView::onButtonFourPressed()
{
    if(m_numTotalPages >= 4 )
    {
        m_currentPageNo = 4;
    }
    modifyPrevNextButtons();
}

void IGSxGUI::CPDView::updateStatus(std::string /*strCPD*/, IGS::Result result)
{
    if(result == IGS::OK)
    {
    }
}

void IGSxGUI::CPDView::onActiveCPDShowButtonPressed()
{
    std::cerr << " Active CPD Show Button Pressed...";
}

void IGSxGUI::CPDView::onWariningTimeout()
{
    sui->gbxWarning->setVisible(false);
}

void IGSxGUI::CPDView::onRadioButtonAllPressed()
{
   if(sui->rbtnAll->isChecked())
   {
    std::cerr << "ALL  button Pressed...";
   }
}

void IGSxGUI::CPDView::onRadioButtonCalibrationPressed()
{
    if(sui->rbtnCalibration->isChecked())
   {
    std::cerr << "CAli  button Pressed...";
   }
}

void IGSxGUI::CPDView::onRadioButtonPerformancePressed()
{
    if(sui->rbtnPerformance->isChecked())
   {
    std::cerr << "Perf button Pressed...";
   }
}

void IGSxGUI::CPDView::onRadioButtonDiagnosticsPressed()
{
    if(sui->rbtnDiagnostics->isChecked())
    {
      std::cerr << "Diagnostics button Pressed...";
    }
}

void IGSxGUI::CPDView::onButtonCPD1StartPressed()
{
    std::cerr << "Start 1 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD2StartPressed()
{
    std::cerr << "Start 2 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD3StartPressed()
{
    std::cerr << "Start 3 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD4StartPressed()
{
    std::cerr << "Start 4 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD5StartPressed()
{
    std::cerr << "Start 5 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD6StartPressed()
{
    std::cerr << "Start 6 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD7StartPressed()
{
    std::cerr << "Start 7 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD8StartPressed()
{
    std::cerr << "Start 8 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD9StartPressed()
{
    std::cerr << "Start 9 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD10StartPressed()
{
    std::cerr << "Start 10 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD1DetailPressed()
{
    std::cerr << "Detail 1 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD2DetailPressed()
{
    std::cerr << "Detail 2 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD3DetailPressed()
{
    std::cerr << "Detail 3 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD4DetailPressed()
{
    std::cerr << "Detail 4 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD5DetailPressed()
{
    std::cerr << "Detail 5 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD6DetailPressed()
{
    std::cerr << "Detail 6 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD7DetailPressed()
{
    std::cerr << "Detail 7 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD8DetailPressed()
{
    std::cerr << "Detail 8 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD9DetailPressed()
{
    std::cerr << "Detail 9 Pressed...";
}

void IGSxGUI::CPDView::onButtonCPD10DetailPressed()
{
    std::cerr << "Detail 10 Pressed...";
}

void IGSxGUI::CPDView::loadContainers()
{
    m_listCPDUCT.clear();
    m_listCPDNameLabels.clear();
    m_listCPDTypeLabels.clear();
    m_listCPDDescriptionLabels.clear();
    m_listCPDTimeLabels.clear();
    m_listDisplayButtons.clear();

    m_listCPDUCT.push_back(sui->uctCPD1);
    m_listCPDUCT.push_back(sui->uctCPD2);
    m_listCPDUCT.push_back(sui->uctCPD3);
    m_listCPDUCT.push_back(sui->uctCPD4);
    m_listCPDUCT.push_back(sui->uctCPD5);
    m_listCPDUCT.push_back(sui->uctCPD6);
    m_listCPDUCT.push_back(sui->uctCPD7);
    m_listCPDUCT.push_back(sui->uctCPD8);
    m_listCPDUCT.push_back(sui->uctCPD9);
    m_listCPDUCT.push_back(sui->uctCPD10);

    m_listCPDNameLabels.push_back(sui->lblCPD1Name);
    m_listCPDNameLabels.push_back(sui->lblCPD2Name);
    m_listCPDNameLabels.push_back(sui->lblCPD3Name);
    m_listCPDNameLabels.push_back(sui->lblCPD4Name);
    m_listCPDNameLabels.push_back(sui->lblCPD5Name);
    m_listCPDNameLabels.push_back(sui->lblCPD6Name);
    m_listCPDNameLabels.push_back(sui->lblCPD7Name);
    m_listCPDNameLabels.push_back(sui->lblCPD8Name);
    m_listCPDNameLabels.push_back(sui->lblCPD9Name);
    m_listCPDNameLabels.push_back(sui->lblCPD10Name);

    m_listCPDTypeLabels.push_back(sui->lblCPD1Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD2Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD3Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD4Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD5Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD6Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD7Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD8Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD9Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD10Type);

    m_listCPDDescriptionLabels.push_back(sui->lblCPD1Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD2Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD3Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD4Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD5Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD6Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD7Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD8Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD9Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD10Description);

    m_listCPDTimeLabels.push_back(sui->lblCPD1Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD2Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD3Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD4Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD5Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD6Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD7Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD8Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD9Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD10Time);

    m_listDisplayButtons.push_back(sui->btnOne);
    m_listDisplayButtons.push_back(sui->btnTwo);
    m_listDisplayButtons.push_back(sui->btnThree);
    m_listDisplayButtons.push_back(sui->btnFour);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->btnStartCPD->clicked    = boost::bind(&CPDView::onCPDStartButtonPressed,this);
    sui->btnShowCPD->clicked     = boost::bind(&CPDView::onActiveCPDShowButtonPressed,this);
    sui->btnCPDDetail->clicked   = boost::bind(&CPDView::onActiveCPDDetailButtonPressed,this);
    sui->rbtnAll->checkStateChanged = boost::bind(&CPDView::onRadioButtonAllPressed,this);
    sui->rbtnCalibration->checkStateChanged = boost::bind(&CPDView::onRadioButtonCalibrationPressed,this);
    sui->rbtnPerformance->checkStateChanged = boost::bind(&CPDView::onRadioButtonPerformancePressed,this);
    sui->rbtnDiagnostics->checkStateChanged = boost::bind(&CPDView::onRadioButtonDiagnosticsPressed,this);

    sui->btnCPD1Start->clicked    = boost::bind(&CPDView::onButtonCPD1StartPressed,this);
    sui->btnCPD2Start->clicked    = boost::bind(&CPDView::onButtonCPD2StartPressed,this);
    sui->btnCPD3Start->clicked    = boost::bind(&CPDView::onButtonCPD3StartPressed,this);
    sui->btnCPD4Start->clicked    = boost::bind(&CPDView::onButtonCPD4StartPressed,this);
    sui->btnCPD5Start->clicked    = boost::bind(&CPDView::onButtonCPD5StartPressed,this);
    sui->btnCPD6Start->clicked    = boost::bind(&CPDView::onButtonCPD6StartPressed,this);
    sui->btnCPD7Start->clicked    = boost::bind(&CPDView::onButtonCPD7StartPressed,this);
    sui->btnCPD8Start->clicked    = boost::bind(&CPDView::onButtonCPD8StartPressed,this);
    sui->btnCPD9Start->clicked    = boost::bind(&CPDView::onButtonCPD9StartPressed,this);
    sui->btnCPD10Start->clicked    = boost::bind(&CPDView::onButtonCPD10StartPressed,this);

    sui->btnCPD1Detail->clicked    = boost::bind(&CPDView::onButtonCPD1DetailPressed,this);
    sui->btnCPD2Detail->clicked    = boost::bind(&CPDView::onButtonCPD2DetailPressed,this);
    sui->btnCPD3Detail->clicked    = boost::bind(&CPDView::onButtonCPD3DetailPressed,this);
    sui->btnCPD4Detail->clicked    = boost::bind(&CPDView::onButtonCPD4DetailPressed,this);
    sui->btnCPD5Detail->clicked    = boost::bind(&CPDView::onButtonCPD5DetailPressed,this);
    sui->btnCPD6Detail->clicked    = boost::bind(&CPDView::onButtonCPD6DetailPressed,this);
    sui->btnCPD7Detail->clicked    = boost::bind(&CPDView::onButtonCPD7DetailPressed,this);
    sui->btnCPD8Detail->clicked    = boost::bind(&CPDView::onButtonCPD8DetailPressed,this);
    sui->btnCPD9Detail->clicked    = boost::bind(&CPDView::onButtonCPD9DetailPressed,this);
    sui->btnCPD10Detail->clicked    = boost::bind(&CPDView::onButtonCPD10DetailPressed,this);

    sui->btnPrev->clicked    = boost::bind(&CPDView::onButtonPrevPressed,this);
    sui->btnNext->clicked    = boost::bind(&CPDView::onButtonNextPressed,this);
    sui->btnOne->clicked    = boost::bind(&CPDView::onButtonOnePressed,this);
    sui->btnTwo->clicked    = boost::bind(&CPDView::onButtonTwoPressed,this);
    sui->btnThree->clicked    = boost::bind(&CPDView::onButtonThreePressed,this);
    sui->btnFour->clicked    = boost::bind(&CPDView::onButtonFourPressed,this);

    m_timer->timeout = boost::bind(&CPDView::onWariningTimeout,this);
}

void IGSxGUI::CPDView::onCPDStartButtonPressed()
{
    sui->gbxWarning->setBGColor(SUI::ColorEnum::Blue);
    sui->gbxWarning->setVisible(true);
    m_timer->start(TIMER_INTERVAL);
}

void IGSxGUI::CPDView::onActiveCPDDetailButtonPressed()
{
    m_CPDDetailButtonToggleFlag = ! m_CPDDetailButtonToggleFlag;
    if(m_CPDDetailButtonToggleFlag == true)
    {
        sui->txaCPDDetail->clearText();
        sui->txaCPDDetail->setVisible(true);
        sui->txaCPDDetail->setText(sui->lblType->getText());
        std::cerr << " Active CPD Details Button Pressed...";
   }
   else
   {
        sui->txaCPDDetail->setVisible(false);
   }
}

