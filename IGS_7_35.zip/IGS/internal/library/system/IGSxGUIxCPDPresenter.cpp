/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of CPD Presenter
|
| ! \file        IGSxGUIxCPDPresenter.cpp
| ! \brief       Implementation of CPD Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxCPDPresenter.hpp"
#include <string>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::CPDPresenter::CPDPresenter(IGSxGUI::ICPDView* view,CPDManager* pCPDManager):
    m_pCPDManager(pCPDManager),
    m_view(view)
{
    std::vector<IGSxGUI::CPD *> CPDs = m_pCPDManager->retrieveAll();

    for (size_t i = 0; i < CPDs.size(); ++i)
    {
        CPDs[i]->registerToCPDStopped(boost::bind(&IGSxGUI::CPDPresenter::onCPDStopped, this, _1, _2));
    }
}
IGSxGUI::CPDPresenter::~CPDPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDPresenter::getCPDs()
{
    return m_pCPDManager->retrieveAll();
}

bool IGSxGUI::CPDPresenter::startCPD(std::string cpdName)
{
    IGSxGUI::CPD* cpd = m_pCPDManager->getCPD(cpdName);
    return cpd->start();
}

void IGSxGUI::CPDPresenter::onCPDStopped(std::string strCPD, IGS::Result result)
{
    m_view->updateStatus(strCPD,result);
}

