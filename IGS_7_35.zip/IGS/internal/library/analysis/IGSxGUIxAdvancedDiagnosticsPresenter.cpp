/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Advanced Diagnostics Presenter
|
| ! \file        IGSxGUIxAdvancedDiagnosticsPresenter.cpp
| ! \brief       Implementation of Advanced Diagnostics Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxAdvancedDiagnosticsPresenter.hpp"
#include "IGSxGUIxADT.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::AdvancedDiagnosticsPresenter::AdvancedDiagnosticsPresenter(IAdvancedDiagnosticsView* view, ADTManager *pADTManager):
    m_pADTManager(pADTManager),
    m_view(view)
{

}

IGSxGUI::AdvancedDiagnosticsPresenter::~AdvancedDiagnosticsPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::ADT *> IGSxGUI::AdvancedDiagnosticsPresenter::getADTs()
{
    return m_pADTManager->retrieveAll();
}


bool IGSxGUI::AdvancedDiagnosticsPresenter::startADT(std::string adtName)
{
    IGSxGUI::ADT* adt = m_pADTManager->getADT(adtName);
    return adt->start();
}




