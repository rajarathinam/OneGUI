/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxStubView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Stub View
|
| ! \file        IGSxStubView.hpp
| ! \brief       Header file for Stub View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXSTUBVIEW_HPP
#define IGSXSTUBVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include <SUIButton.h>
#include <SUILabel.h>
#include "IGSxIStubView.hpp"
#include "IGSxStubPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class StubView;
}  // namespace SUI

namespace IGSxGUI{

class StubView : public IStubView
{
 public:
    StubView();
    ~StubView();

    void show();
    void showStatus(std::string strStatus);
    void updateKPI(string kpiName, string, vector<double> values);

 private:
    void onInitializeButtonPressed();
    void onTerminateButtonPressed();
    void onSetButtonPressed();
    void onKPIValueSetButtonPressed();
    void onSystemFunctionSelected();
    void onddbKPIValueChanged();

    void onSetAllInitializedPressed();
    void onSetAllInitializingPressed();
    void onSetAllTerminatedPressed();
    void onSetAllTerminatingPressed();
    void onSetAllRecRequiredPressed();

    void onCheckBoxStateChanged(bool checked);

    SUI::StubView *sui;
    StubPresenter *m_presenter;
    static const char* STUBVIEW_LOAD_FILE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMVIEW_HPP
