/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxConsumableTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Consumable test
|
| ! \file        IGSxGUIxConsumableTest.cpp
| ! \brief       Implementation of Consumable test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxConsumableTest.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        ConsumableTestParam,
                        ::testing::Values("EUV_Pulse_Energy_Internal"));

TEST_P(ConsumableTestParam, Constructor)
{
    IGSxGUI::Consumable consumable(m_kpiDefinition1);

    EXPECT_STRCASEEQ(consumable.getName().c_str(), m_kpiDefinition1.name().c_str());
    EXPECT_STRCASEEQ(consumable.getDescription().c_str(), m_kpiDefinition1.description().c_str());
}

TEST_P(ConsumableTestParam, ValueContentSize)
{
    IGSxGUI::Consumable consumable(m_kpiDefinition1);
    vector<IGSxGUI::ConsumableValueSet*> valsetlist = consumable.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);
}
