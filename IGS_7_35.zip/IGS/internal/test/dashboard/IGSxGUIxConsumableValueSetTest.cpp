/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxConsumableValueSetTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Consumable ValueSet test
|
| ! \file        IGSxGUIxConsumableValueSetTest.cpp
| ! \brief       Implementation of Consumable ValueSet test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxConsumableValueSetTest.hpp"
#include "IGSxGUIxConsumableValueSet.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        ConsumableValueSetTestParam,
                        ::testing::Values("MEAN"));

TEST_P(ConsumableValueSetTestParam, Test1)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_1);
    std::string name = valset->getName();
    EXPECT_STRCASEEQ(name.c_str(), "MEAN");

    delete valset;
}

TEST_P(ConsumableValueSetTestParam, Test2)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_1);
    std::string desc = valset->getDescription();
    EXPECT_STRCASEEQ(desc.c_str(), "MEAN");

    delete valset;
}

TEST_P(ConsumableValueSetTestParam, Test3)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_1);
    std::string unit = valset->getUnit();
    EXPECT_STRCASEEQ(unit.c_str(), "mJ");

    delete valset;
}

TEST_P(ConsumableValueSetTestParam, Test4)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_2);
    std::string name = valset->getName();
    EXPECT_STRCASEEQ(name.c_str(), "MAX");

    delete valset;
}

TEST_P(ConsumableValueSetTestParam, Test5)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_2);
    std::string desc = valset->getDescription();
    EXPECT_STRCASEEQ(desc.c_str(), "MAX");

    delete valset;
}

TEST_P(ConsumableValueSetTestParam, Test6)
{
    IGSxGUI::ConsumableValueSet* valset = new IGSxGUI::ConsumableValueSet(valsetdef_2);
    std::string unit = valset->getUnit();
    EXPECT_STRCASEEQ(unit.c_str(), "µm");

    delete valset;
}
