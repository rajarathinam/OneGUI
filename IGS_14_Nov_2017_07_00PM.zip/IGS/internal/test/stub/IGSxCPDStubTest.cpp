/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPDStubTest.cpp
| Author       : Venugopal S
| Description  : Implementation of IGSxCPD stub test
|
| ! \file        IGSxCPDStubTest.cpp
| ! \brief       Implementation of IGSxCPD stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxCPDStubTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(IGSxCPDStubTest, instanceTest)
{
    EXPECT_EQ(IGSxCPD::CPD::getInstance(), IGSxCPD::CPD::getInstance());
}

TEST_F(IGSxCPDStubTest, getTests)
{
    IGSxCPD::MetaDescriptions tests;
    IGSxCPD::CPD::getInstance()->getTests(tests);
    EXPECT_EQ(tests.size(), 51);

    IGSxCPD::MetaDescription test = tests[0];
    EXPECT_STRCASEEQ(test.name().c_str(), "CPDFFMDFC");
    EXPECT_STRCASEEQ(test.testType().c_str(), "Calibration");
    EXPECT_STRCASEEQ(test.description().c_str(), "CPD FFM Default Filter Calibration");
    EXPECT_STRCASEEQ(test.htmlFile().c_str(), "GPD_GVCDDT_description.html");
    EXPECT_STRCASEEQ(test.subSystem().c_str(), "Final Focus Metrology");
}

TEST_F(IGSxCPDStubTest, getCurrentTest)
{
    IGSxCPD::CPD::getInstance()->startTest("CPD_CODMCL");
    EXPECT_STRCASEEQ(IGSxCPD::CPD::getInstance()->getCurrentTest().c_str(), "CPD_CODMCL");
}
