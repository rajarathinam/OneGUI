/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <algorithm>
#include <string>
#include <vector>
#include <list>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include <SUIDialog.h>
#include <SUIObjectList.h>
#include <SUIButton.h>
#include <SUIRadioButton.h>
#include <SUIUserControl.h>
#include <SUITimer.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = "IGSxGUIxCPD.xml";
const std::string IGSxGUI::CPDView::STRING_EMPTY = "";
const std::string IGSxGUI::CPDView::STRING_SINGLESPACE = " ";
const char IGSxGUI::CPDView::NEWLINE_CHAR = '\n';
const std::string IGSxGUI::CPDView::STRING_ALL = "All";
const std::string IGSxGUI::CPDView::STRING_ALL_CPDS = "ALL CPDs";
const std::string IGSxGUI::CPDView::STRING_CALIBRATION = "Calibration";
const std::string IGSxGUI::CPDView::STRING_PERFORMANCE = "Performance";
const std::string IGSxGUI::CPDView::STRING_DIAGNOSTICS = "Diagnostics";
const std::string IGSxGUI::CPDView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::CPDView::STRING_CPDVIEW_SHOWN = "CPDView is shown.";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::CPDView::STRING_CPDSUBSYSTEM_STYLE = "adtsubsystem";
const std::string IGSxGUI::CPDView::STRING_SLASH = " / ";
const std::string IGSxGUI::CPDView::STYLE_DISABLED_BUTTON = "disabledButton";
const std::string IGSxGUI::CPDView::STYLE_ENABLED_BUTTON = "Updatelogbutton";
const std::string IGSxGUI::CPDView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::CPDView::STYLE_AWESOME_ICONCOLOR = "#4d4d4d";
const std::string IGSxGUI::CPDView::STYLE_AWESOMEACTIVE_ICONCOLOR = "#8c8c8c";
const std::string IGSxGUI::CPDView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPDLABEL_GREY = "GreyLabel14PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::CPDView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_INACTIVE_CPD = "InactiveStatusDisplayLabel";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_GROUPBOX = "BlueBorderGroupBox";
const std::string IGSxGUI::CPDView::STYLE_INACTIVE_GROUPBOX = "GreyBorderGroupBox";
const std::string IGSxGUI::CPDView::CUSTOM_STYLESHEET = "customCss.css";
const std::string IGSxGUI::CPDView::STRING_CPDLOG1 = "Start CPD pressed: ";
const std::string IGSxGUI::CPDView::STRING_CPDLOG2 = ",CPDType: ";
const std::string IGSxGUI::CPDView::STRING_NOACTIVE_CPD = " There is no active CPD";
const std::string IGSxGUI::CPDView::STRING_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S";
const std::string IGSxGUI::CPDView::STRING_MAINTENANCE = "Maintenance/Calibration";
const std::string IGSxGUI::CPDView::STRING_TESTREPORTS = " / Test reports";
const std::string IGSxGUI::CPDView::STRING_CLOSEREPORT = "Close report";
const std::string IGSxGUI::CPDView::STRING_CLOSEREPORTS = "Close all reports";
const std::string IGSxGUI::CPDView::STRING_VIEW_SLECTED_REPORT = "View selected report...";
const std::string IGSxGUI::CPDView::STRING_VIEW_SLECTED_REPORTS = "View selected reports...";
const int IGSxGUI::CPDView::CPDSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::CPDView::AWESOME_ICON_SIZE = 14;
const int IGSxGUI::CPDView::AWESOME_ANGLE_SIZE = 22;
const int IGSxGUI::CPDView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::CPDView::AWESOME_ACTIVEANGLE_SIZE = 16;
const int IGSxGUI::CPDView::CPDTABLE_ROW_SIZE = 62;
const int IGSxGUI::CPDView::NORMAL_SUBSYSTEM_ROW_SIZE = 40;
const int IGSxGUI::CPDView::EXTENDED_SUBSYSTEM_ROW_SIZE = 60;
const int IGSxGUI::CPDView::HOURS_PER_DAY = 24;
const int IGSxGUI::CPDView::NUMBER_OF_DAYS = 4;
const int IGSxGUI::CPDView::SECONDS_PER_HOUR = 3600;
const std::string::size_type IGSxGUI::CPDView::MAX_SUBSYSTEM_CHARS_PER_CELL = 21;

IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_selectedSubSystem(""),
    m_selectedSubsystemRowNum(-1),
    m_selectedCPD(""),
    m_nameActiveCPD(""),
    m_selectedCPDRowNum(-1),
    m_countAllCPD(0),
    m_countCalibration(0),
    m_countPerformance(0),
    m_countDiagnostics(0),
    m_isDescFolded(true),
    m_isCPDActivated(false),
    m_isActivateCPDDescShown(false),
    m_isTestReportFolded(true),
    m_isCloseButtonPressed(false),
    m_isInternalCallToSubsystemPressed(false)
{
    m_presenter = new CPDPresenter(this, pCPDManager);
}

IGSxGUI::CPDView::~CPDView()
{
    if (m_presenter != NULL) {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL) {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::CPDView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL) {
        sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    init();
    IGS_INFO(STRING_CPDVIEW_SHOWN);
}

void IGSxGUI::CPDView::init()
{
    sui->tawCPDSubsystem->showGrid(false);
    sui->tawCPD->showGrid(false);
    sui->tawTestReports->showGrid(false);
    sui->gbxTestReportPage->setVisible(false);
    sui->gbxFrontPage->setVisible(true);
    IGSxGUI::Util::addCustomStylesheet(sui->wvwCPDHTMLDescription, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwSingleTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwLeftTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwRightTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::setAwesome(sui->lblIconCalibration, IGSxGUI::AwesomeIcon::AI_fa_crosshairs, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblIconPerformance, IGSxGUI::AwesomeIcon::AI_fa_areachart, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblIconDiagnostics, IGSxGUI::AwesomeIcon::AI_fa_stethoscope, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    m_listCPD = m_presenter->getCPDs();
    m_listSubsystemCPDs = m_presenter->getCPDs();
    sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
    sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
    sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);
    loadSubSystems();
    loadTestTypes();
    if ((m_selectedSubSystem != "") || (m_selectedCPD != "")) {
        reload();
    } else {
        loadCPDTable();
    }
    loadActiveCPD();
}

void IGSxGUI::CPDView::onSubSystemClosePressed()
{
    EnableCountLabels();
    m_isCloseButtonPressed = true;
    DisableCloseButtons();
    m_isCloseButtonPressed = false;
    IGSxGUI::Util::clearSelection(sui->tawCPDSubsystem);
    m_selectedSubSystem = "";
    m_selectedSubsystemRowNum = -1;
    m_listCPD = m_presenter->getCPDs();
    loadCPDTable();
}

void IGSxGUI::CPDView::EnableCountLabels()
{
    for (int rowIndex = 0; rowIndex < sui->tawCPDSubsystem->rowCount(); ++rowIndex) {
        dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(rowIndex, 2))->setVisible(true);
    }
}
void IGSxGUI::CPDView::DisableCloseButtons()
{
    for (int rowIndex = 0; rowIndex < sui->tawCPDSubsystem->rowCount(); ++rowIndex) {
        dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(rowIndex, 3))->setVisible(false);
    }
}

void IGSxGUI::CPDView::onTestReportsClicked()
{
    if (m_isTestReportFolded) {
        m_isTestReportFolded = false;
        showTestReports(true);
        moveDescriptionToDown();
        IGSxGUI::Util::setUnderline(sui->btnTestReports, false);
    } else {
        m_isTestReportFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showTestReports(false);
        moveDescriptionToOriginalPosition();
    }
}

void IGSxGUI::CPDView::onSubsystemPressed()
{
    if (m_isCloseButtonPressed) {
        return;
    }
    if (!m_isInternalCallToSubsystemPressed) {
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
    }
    std::vector<int> items = sui->tawCPDSubsystem->getSelectedRows();
    if (items.size() > 0) {
        EnableCountLabels();
        DisableCloseButtons();
        m_selectedSubsystemRowNum = items[0];
        dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 2))->setVisible(false);
        dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(m_selectedSubsystemRowNum, 3))->setVisible(true);
        std::string selectedText = sui->tawCPDSubsystem->getItemText(boost::lexical_cast<int>(m_selectedSubsystemRowNum), 1);
        std::replace(selectedText.begin(), selectedText.end(), NEWLINE_CHAR, ' ');
        boost::trim(selectedText);
        m_selectedSubSystem = selectedText;
        sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);
        countSelectedSubSystemsTesttype();
        sui->rbtnAll->setChecked(true);
        onRadioButtonAllPressed();
        sui->rbtnAll->setText(STRING_ALL + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countAllCPD) + STRING_CLOSE_BRACKET);
        sui->rbtnCalibration->setText(getRequiredSpace(4) + STRING_CALIBRATION + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countCalibration) + STRING_CLOSE_BRACKET);
        sui->rbtnPerformance->setText(getRequiredSpace(5) + STRING_PERFORMANCE + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countPerformance) + STRING_CLOSE_BRACKET);
        sui->rbtnDiagnostics->setText(getRequiredSpace(4) + STRING_DIAGNOSTICS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countDiagnostics) + STRING_CLOSE_BRACKET);
    }
}

void IGSxGUI::CPDView::countSelectedSubSystemsTesttype()
{
    m_countAllCPD = 0;
    m_countCalibration = 0;
    m_countPerformance = 0;
    m_countDiagnostics = 0;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++) {
        container subsys = m_listSubsystems[i];
        if (subsys.name == m_selectedSubSystem) {
            if (subsys.cpd->getTestType() == STRING_CALIBRATION) {
                ++m_countCalibration;
            } else if (subsys.cpd->getTestType() == STRING_PERFORMANCE) {
                ++m_countPerformance;
            } else if (subsys.cpd->getTestType() == STRING_DIAGNOSTICS) {
                ++m_countDiagnostics;
            }
            ++m_countAllCPD;
        }
    }
}

void IGSxGUI::CPDView::setDescriptionPaneVisible(bool visibility)
{
    sui->lblTestReportLine->setVisible(visibility);
    sui->lblDescriptionLine->setVisible(visibility);
    sui->lblTestReportAngle->setVisible(visibility);
    sui->lblDescriptionAngle->setVisible(visibility);
    sui->lblSelectedCPD->setVisible(visibility);
    sui->btnOpenCPD->setVisible(visibility);
    sui->btnTestReports->setVisible(visibility);
    sui->btnDescription->setVisible(visibility);
    sui->wvwCPDHTMLDescription->setVisible(visibility);
    setReportWidgetsVisibility(visibility);
}

void IGSxGUI::CPDView::populateCPDTable(std::vector<CPD*> listCPD)
{
    if (listCPD.size() > 0) {
        sui->tawCPD->setVisible(true);
        sui->tawCPD->removeRows(1, sui->tawCPD->rowCount()-1);
        for (size_t i = 0 ; i < (listCPD.size() - 1); i++) {
            sui->tawCPD->appendRow();
        }
        for (int row = 0; row < sui->tawCPD->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawCPD->getWidgetItem(row, 0);
            IGSxGUI::Util::setCPDUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableCPDRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&CPDView::onCPDUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&CPDView::onCPDUCTHoverLeft, this, row);
            IGSxGUI::Util::setTextToCPDUserControl(widget, 0, listCPD[row]->getName());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 1, listCPD[row]->getDescription());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 3, listCPD[row]->getTestType());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 4, STRING_EMPTY);
            IGSxGUI::Util::setRowHeight(sui->tawCPD, row, CPDTABLE_ROW_SIZE);
        }
        IGSxGUI::Util::clearSelection(sui->tawCPD);
        setDescriptionPaneVisible(false);
    } else {
        sui->tawCPD->setVisible(false);
    }
}

void IGSxGUI::CPDView::loadCPDTable()
{
    populateCPDTable(m_listCPD);
    sui->lblAllCPDs->setText(STRING_ALL_CPDS);
    countAllSubSystemsTesttype();
    sui->rbtnAll->setText(STRING_ALL + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countAllCPD) + STRING_CLOSE_BRACKET);
    sui->rbtnCalibration->setText(getRequiredSpace(4) + STRING_CALIBRATION + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countCalibration) + STRING_CLOSE_BRACKET);
    sui->rbtnPerformance->setText(getRequiredSpace(5) + STRING_PERFORMANCE + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countPerformance) + STRING_CLOSE_BRACKET);
    sui->rbtnDiagnostics->setText(getRequiredSpace(4) + STRING_DIAGNOSTICS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countDiagnostics) + STRING_CLOSE_BRACKET);
}

void IGSxGUI::CPDView::loadActiveCPD()
{
    if (m_isCPDActivated) {
        CPD* cpd = m_presenter->retrieveRunningCPD();
        if (cpd != NULL) {
            std::string testType = cpd->getTestType();
            sui->gbxActiveCPD->setStyleSheetClass(STYLE_ACTIVE_GROUPBOX);
            sui->lblActiveCPDName->setVisible(true);
            sui->lblActiveCPDName->setText(getRequiredSpace(2) + cpd->getName());
            sui->lblActiveCPDName->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
            sui->lblActiveCPDDescription->setVisible(true);
            sui->lblActiveCPDDescription->setText(getRequiredSpace(2) + cpd->getDescription());
            sui->lblActiveCPDDescription->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);
            sui->lblActiveCPDTestType->setVisible(true);
            sui->lblActiveCPDTestType->setText(testType);
            sui->lblActiveCPDTestType->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);
            sui->lblActiveArrow->setVisible(true);
            IGSxGUI::Util::setAwesome(sui->lblActiveArrow, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ACTIVEANGLE_SIZE);
            sui->lblActiveCPDTestTypeIcon->setVisible(true);
            if (testType == STRING_CALIBRATION) {
                IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_crosshairs, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
            } else if (testType == STRING_PERFORMANCE) {
                IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_areachart, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
            } else if (testType == STRING_DIAGNOSTICS) {
                IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_stethoscope, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
            }
        }
    } else {
        sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
        sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);
        sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
        sui->lblActiveCPDDescription->setVisible(false);
        sui->lblActiveCPDTestType->setVisible(false);
        sui->lblActiveCPDTestTypeIcon->setVisible(false);
        sui->lblActiveArrow->setVisible(false);
    }
    if (m_selectedCPDRowNum < 0) {
        if (m_isActivateCPDDescShown) {
            showCPDDetailsPage(true, m_nameActiveCPD);
        } else {
            showCPDDetailsPage(false, m_nameActiveCPD);
        }
    }
}

void IGSxGUI::CPDView::setActive(bool bActive)
{
    if (bActive) {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::CPDView::updateStatus(const std::string& /*strCPD*/, const IGS::Result& result)
{
    if (result == IGS::OK) {
        m_isCPDActivated = false;
        m_isActivateCPDDescShown = false;
        sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
        sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);
        sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
        sui->lblActiveCPDDescription->setVisible(false);
        sui->lblActiveCPDTestType->setVisible(false);
        sui->lblActiveCPDTestTypeIcon->setVisible(false);
        sui->lblActiveArrow->setVisible(false);
    }
}

void IGSxGUI::CPDView::insertCountLabelAndCloseButton(size_t i)
{
    IGSxGUI::Util::addLabel(sui->tawCPDSubsystem, i, 2);
    SUI::Label* label = dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(i, 2));
    label->setStyleSheetClass(STRING_CPDSUBSYSTEM_STYLE);
    IGSxGUI::Util::addButton(sui->tawCPDSubsystem, i, 3);
    SUI::Button* button = dynamic_cast<SUI::Button*>(sui->tawCPDSubsystem->getWidgetItem(i, 3));
    button->setVisible(false);
    button->clicked = boost::bind(&CPDView::onSubSystemClosePressed, this);
    IGSxGUI::Util::setAwesome(button, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, CPDSUBSYSTEM_CLOSEBUTTON_SIZE);
}

void IGSxGUI::CPDView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    if (subsyscount.nameSubsystem.length() > MAX_SUBSYSTEM_CHARS_PER_CELL) {
        std::string str1 = STRING_EMPTY;
        std::string str2 = STRING_EMPTY;
        std::vector<std::string> tokens;
        boost::split(tokens, subsyscount.nameSubsystem, boost::is_any_of(STRING_SINGLESPACE));
        for (size_t index = 0; index < tokens.size(); ++index) {
            if (str1.length() < MAX_SUBSYSTEM_CHARS_PER_CELL) {
                str1 = str1 + STRING_SINGLESPACE+ tokens[index];
            } else {
                str2 = str2 + STRING_SINGLESPACE + tokens[index];
            }
        }
        boost::trim(str1);
        boost::trim(str2);
        sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 1, str1 + NEWLINE_CHAR + str2);
    } else {
        sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 1, subsyscount.nameSubsystem);
    }
    IGSxGUI::Util::setColor(sui->tawCPDSubsystem->getWidgetItem(i, 1), SUI::ColorEnum::White, sui->tawCPDSubsystem);
    dynamic_cast<SUI::Label*>(sui->tawCPDSubsystem->getWidgetItem(i, 2))->setText(subsys);
}

std::string IGSxGUI::CPDView::getRequiredSpace(size_t count)
{
    std::string emptySpace;
    for (size_t i = 0 ; i < count; i++) {
        emptySpace.append(STRING_SINGLESPACE);
    }
    return emptySpace;
}

void IGSxGUI::CPDView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemCPDs.size(); i++) {
        subsystem.name = m_listSubsystemCPDs[i]->getSubsystem();
        subsystem.cpd = m_listSubsystemCPDs[i];
        listStringSubsystem.push_back(m_listSubsystemCPDs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }
    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());
    for (size_t i = 0 ; i < listStringSubsystem.size(); i++) {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++) {
            if (listStringSubsystem[i] == m_listSubsystems[j].name) {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;
        m_listSubsystemCount.push_back(subsyscount);
    }
    std::list<std::string> listTestReportSubSystemItems;
    for (size_t i = 0; i < m_listSubsystemCount.size(); i++) {
        insertCountLabelAndCloseButton(i);
        sui->tawCPDSubsystem->appendRow();
        subSystemCount subsyscount = m_listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        if (subsyscount.nameSubsystem.length() < MAX_SUBSYSTEM_CHARS_PER_CELL) {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, i, NORMAL_SUBSYSTEM_ROW_SIZE);
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, i, EXTENDED_SUBSYSTEM_ROW_SIZE);
        }
        setValuesToRowWidgets(subsys, i, subsyscount);
    }
    sui->tawCPDSubsystem->removeRow(sui->tawCPDSubsystem->rowCount() - 1);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->tawCPDSubsystem->rowClicked = boost::bind(&CPDView::onSubsystemPressed, this);
    sui->btnOpenCPD->clicked = boost::bind(&CPDView::onOpenCPDClicked, this);
    sui->btnTestReports->clicked = boost::bind(&CPDView::onTestReportsClicked, this);
    sui->btnTestReports->hoverEntered = boost::bind(&CPDView::onTestReportHoverEntered, this);
    sui->btnTestReports->hoverLeft = boost::bind(&CPDView::onTestReportHoverLeft, this);
    sui->btnDescription->clicked = boost::bind(&CPDView::onDescriptionClicked, this);
    sui->btnDescription->hoverEntered = boost::bind(&CPDView::onDescriptionHoverEntered, this);
    sui->btnDescription->hoverLeft = boost::bind(&CPDView::onDescriptionHoverLeft, this);
    sui->btnViewSelectedReports->clicked = boost::bind(&CPDView::onBtnViewSelectedReportsPressed, this);
    sui->rbtnAll->checkStateChanged = boost::bind(&CPDView::onRadioButtonAllPressed, this);
    sui->rbtnCalibration->checkStateChanged = boost::bind(&CPDView::onRadioButtonCalibrationPressed, this);
    sui->rbtnPerformance->checkStateChanged = boost::bind(&CPDView::onRadioButtonPerformancePressed, this);
    sui->rbtnDiagnostics->checkStateChanged = boost::bind(&CPDView::onRadioButtonDiagnosticsPressed, this);
    sui->uctCloseReports->clicked = boost::bind(&CPDView::onUCTCloseReportsPressed, this);
    sui->uctCloseReports->hoverEntered = boost::bind(&CPDView::onUCTCloseReportsHoverOn, this);
    sui->uctCloseReports->hoverLeft = boost::bind(&CPDView::onUCTCloseReportsHoverOff, this);
    sui->uctActiveCPD->clicked = boost::bind(&CPDView::onUCTActiveCPDPressed, this);
}

void IGSxGUI::CPDView::onTableCPDRowPressed(int rowindex)
{
    SUI::Widget *widget = sui->tawCPD->getWidgetItem(rowindex, 0);
    IGSxGUI::Util::setCPDUCTClickedStyle(widget);
    m_selectedCPD = IGSxGUI::Util::getADTCPDNameFromUserControl(widget);
    boost::trim(m_selectedCPD);
    if (m_selectedCPDRowNum == rowindex) {
        IGSxGUI::Util::setCPDUCTNormalStyle(sui->tawCPD->getWidgetItem(rowindex, 0));
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
        showCPDDetailsPage(false, m_selectedCPD);
    } else {
        m_selectedCPDRowNum = rowindex;
        EnableCountLabels();
        for (int i = 0; i < sui->tawCPD->rowCount(); ++i ) {
            IGSxGUI::Util::setCPDUCTNormalStyle(sui->tawCPD->getWidgetItem(i, 0));
        }
        IGSxGUI::Util::setCPDUCTClickedStyle(sui->tawCPD->getWidgetItem(rowindex, 0));
        showCPDDetailsPage(true, m_selectedCPD);
    }
}

void IGSxGUI::CPDView::onTableTestResultRowPressed(int rowindex)
{
    const int MINIMUM_VIEWABLE_REPORT_COUNT = 1;
    const int MAXIMUM_VIEWABLE_REPORT_COUNT = 2;
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(rowindex, 0);
    IGSxGUI::Util::setCheckToTestReportUserControl(widget);


    int numRowsChecked = IGSxGUI::Util::getNumCheckedRows(sui->tawTestReports);
    if (numRowsChecked > MAXIMUM_VIEWABLE_REPORT_COUNT) {
        IGSxGUI::Util::setCheckToTestReportUserControl(widget);
    }
    for (int i =0; i < sui->tawTestReports->rowCount(); ++i) {
        SUI::Widget *widget = sui->tawTestReports->getWidgetItem(i, 0);
        if (IGSxGUI::Util::isTestReportSelected(widget)) {
            IGSxGUI::Util::setTestReportUCTClickedStyle(widget);
        } else {
            IGSxGUI::Util::setTestReportUCTNormalStyle(widget);
          }

        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        usercontrol->clicked = boost::bind(&CPDView::onTableTestResultRowPressed, this, i);
        usercontrol->hoverEntered = boost::bind(&CPDView::onTestReportUCTHoverEntered, this, i);
        usercontrol->hoverLeft = boost::bind(&CPDView::onTestReportUCTHoverLeft, this, i);
    }
    if (numRowsChecked >= MINIMUM_VIEWABLE_REPORT_COUNT) {



        std::string captionViewSelectedReport = STRING_EMPTY;
        if ( MINIMUM_VIEWABLE_REPORT_COUNT == numRowsChecked) {
                    captionViewSelectedReport = STRING_VIEW_SLECTED_REPORT;
        } else {
            for (int i =0; i < sui->tawTestReports->rowCount(); ++i) {
                SUI::Widget *widget = sui->tawTestReports->getWidgetItem(i, 0);
                if (!IGSxGUI::Util::isTestReportSelected(widget)) {
                    IGSxGUI::Util::setTestReportUCTDisabledStyle(widget);
                    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
                    usercontrol->clicked = NULL;
                    usercontrol->hoverEntered = NULL;
                    usercontrol->hoverLeft = NULL;
                }
            }
            captionViewSelectedReport = STRING_VIEW_SLECTED_REPORTS;
        }
        sui->btnViewSelectedReports->setText(captionViewSelectedReport);
        sui->btnViewSelectedReports->setEnabled(true);
        sui->btnViewSelectedReports->setStyleSheetClass(STYLE_ENABLED_BUTTON);
    } else {
        sui->btnViewSelectedReports->setEnabled(false);
        sui->btnViewSelectedReports->setStyleSheetClass(STYLE_DISABLED_BUTTON);
    }
}

void IGSxGUI::CPDView::onUCTCloseReportsPressed()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ASML_ORANGELABEL);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_ASML_COLORORANGE, AWESOME_CLOSE_SIZE);
    sui->gbxTestReportPage->setVisible(false);
    sui->gbxFrontPage->setVisible(true);
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    sui->lblCPDHeader->setText(STRING_MAINTENANCE);
}

void IGSxGUI::CPDView::onUCTCloseReportsHoverOn()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_HOVERON);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::CPDView::onUCTCloseReportsHoverOff()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::CPDView::onCPDUCTHoverEntered(int index)
{
    if (m_selectedCPDRowNum != index) {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::CPDView::onTestReportUCTHoverEntered(int index)
{
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(index, 0);
    IGSxGUI::Util::setTestReportUCTHoverOnStyle(widget);
}

void IGSxGUI::CPDView::onCPDUCTHoverLeft(int index)
{
    if (m_selectedCPDRowNum != index) {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOffStyle(widget);
    }
}

void IGSxGUI::CPDView::onTestReportUCTHoverLeft(int index)
{
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(index, 0);
    IGSxGUI::Util::setTestReportUCTHoverOffStyle(widget);
}

void IGSxGUI::CPDView::onDescriptionHoverEntered()
{
    if (m_isDescFolded) {
        IGSxGUI::Util::setUnderline(sui->btnDescription, true);
    }
}

void IGSxGUI::CPDView::onDescriptionHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnDescription, false);
}

void IGSxGUI::CPDView::showCPDDetailsPage(bool isVisible, const std::string &CPDName)
{
    sui->lblTestReportLine->setVisible(isVisible);
    sui->lblTestReportAngle->setVisible(isVisible);
    sui->lblDescriptionLine->setVisible(isVisible);
    sui->lblDescriptionAngle->setVisible(isVisible);
    sui->lblSelectedCPD->setVisible(isVisible);
    sui->btnOpenCPD->setVisible(isVisible);
    sui->btnTestReports->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->wvwCPDHTMLDescription->setVisible(isVisible);
    sui->lblColumnReport->setVisible(isVisible);
    sui->lblColumnDateTime->setVisible(isVisible);
    sui->lblColumnLine->setVisible(isVisible);
    sui->tawTestReports->setVisible(isVisible);
    sui->btnViewSelectedReports->setVisible(isVisible);
    if (isVisible) {
        sui->lblSelectedCPD->setText(CPDName);
        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        if (m_isTestReportFolded) {
            showTestReports(false);
            moveDescriptionToOriginalPosition();
        } else {
            showTestReports(true);
            moveDescriptionToDown();
        }
        if (m_isDescFolded) {
            showHTMLDescription(false);
        } else {
            showHTMLDescription(true);
        }
    }
}

void IGSxGUI::CPDView::onDescriptionClicked()
{
    if (m_isDescFolded) {
        m_isDescFolded = false;
        showHTMLDescription(true);
        IGSxGUI::Util::setUnderline(sui->btnDescription, false);
    } else {
        m_isDescFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showHTMLDescription(false);
    }
}

void IGSxGUI::CPDView::onTestReportHoverEntered()
{
    if (m_isTestReportFolded) {
        IGSxGUI::Util::setUnderline(sui->btnTestReports, true);
    }
}

void IGSxGUI::CPDView::onTestReportHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnTestReports, false);
}

void IGSxGUI::CPDView::onUCTActiveCPDPressed()
{
    std::string activeCPD, noActiveCPD;
    noActiveCPD = STRING_NOACTIVE_CPD;
    activeCPD = sui->lblActiveCPDName->getText();
    boost::trim(activeCPD);
    boost::trim(noActiveCPD);
    if ((activeCPD != noActiveCPD) && (activeCPD != STRING_EMPTY)) {
        if (m_selectedCPDRowNum >= 0) {
            IGSxGUI::Util::clearSelection(sui->tawCPD);
            IGSxGUI::Util::setCPDUCTNormalStyle(sui->tawCPD->getWidgetItem(m_selectedCPDRowNum, 0));
            m_selectedCPD = "";
            m_selectedCPDRowNum = -1;
        }
        if (activeCPD == sui->lblSelectedCPD->getText()) {
            if (sui->lblSelectedCPD->isVisible()) {
                showCPDDetailsPage(false, activeCPD);
                m_isActivateCPDDescShown = false;
            } else {
                showCPDDetailsPage(true, activeCPD);
                m_isActivateCPDDescShown = true;
            }
        } else {
            showCPDDetailsPage(true, activeCPD);
        }
    }
}

void IGSxGUI::CPDView::onOpenCPDClicked()
{
    std::string cpdName = sui->lblSelectedCPD->getText();
    IGSxGUI::CPD* cpd = m_presenter->getCPD(cpdName);
    std::string testType = cpd->getTestType();
    IGS_INFO(STRING_CPDLOG1 + cpdName + STRING_CPDLOG2 + testType);
    if (m_presenter->startCPD(cpdName)) {
        m_isCPDActivated = true;
        m_nameActiveCPD = cpdName;
        sui->gbxActiveCPD->setStyleSheetClass(STYLE_ACTIVE_GROUPBOX);
        sui->lblActiveCPDName->setVisible(true);
        sui->lblActiveCPDName->setText(getRequiredSpace(2) + cpdName);
        sui->lblActiveCPDName->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
        sui->lblActiveCPDDescription->setVisible(true);
        sui->lblActiveCPDDescription->setText(getRequiredSpace(2) + cpd->getDescription());
        sui->lblActiveCPDDescription->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);
        sui->lblActiveCPDTestType->setVisible(true);
        sui->lblActiveCPDTestType->setText(testType);
        sui->lblActiveCPDTestType->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);
        sui->lblActiveArrow->setVisible(true);
        IGSxGUI::Util::setAwesome(sui->lblActiveArrow, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ACTIVEANGLE_SIZE);
        sui->lblActiveCPDTestTypeIcon->setVisible(true);
        if (testType == STRING_CALIBRATION) {
            IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_crosshairs, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
        } else if (testType == STRING_PERFORMANCE) {
            IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_areachart, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
        } else if (testType == STRING_DIAGNOSTICS) {
            IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_stethoscope, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
        }
    }
}

void IGSxGUI::CPDView::showTestReports(bool isVisible)
{
    if (isVisible) {
        IGSxGUI::CPD* CPD = m_presenter->getCPD(sui->lblSelectedCPD->getText());
        if (CPD != NULL) {
            IGSxGUI::Util::setUnderline(sui->btnTestReports, false);
            IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->btnTestReports->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
            setReportWidgetsVisibility(true);
            populateTestReportTable();
            const int MINIMUM_VIEWABLE_REPORT_COUNT = 1;
            int numRowsChecked = IGSxGUI::Util::getNumCheckedRows(sui->tawTestReports);
            if (numRowsChecked >= MINIMUM_VIEWABLE_REPORT_COUNT) {
                sui->btnViewSelectedReports->setEnabled(true);
                sui->btnViewSelectedReports->setStyleSheetClass(STYLE_ENABLED_BUTTON);
            } else {
                sui->btnViewSelectedReports->setEnabled(false);
                sui->btnViewSelectedReports->setStyleSheetClass(STYLE_DISABLED_BUTTON);
            }
        }
    } else {
        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnTestReports->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
        setReportWidgetsVisibility(false);
    }
}

void IGSxGUI::CPDView::showHTMLDescription(bool isVisible)
{
    if (isVisible) {
        IGSxGUI::CPD* CPD = m_presenter->getCPD(sui->lblSelectedCPD->getText());
        if (CPD != NULL) {
            IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            std::string strCPDHTMLFilePath = CPD->getHtmlFile();
            sui->wvwCPDHTMLDescription->setVisible(true);
            sui->wvwCPDHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strCPDHTMLFilePath));
            sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
        }
    } else {
        sui->wvwCPDHTMLDescription->setVisible(false);
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
    }
}

void IGSxGUI::CPDView::setReportWidgetsVisibility(bool visibility)
{
    sui->lblColumnReport->setVisible(visibility);
    sui->lblColumnDateTime->setVisible(visibility);
    sui->lblColumnLine->setVisible((visibility));
    sui->tawTestReports->setVisible(visibility);
    sui->btnViewSelectedReports->setVisible(visibility);
}

void IGSxGUI::CPDView::reload()
{
    if (m_selectedSubSystem != "") {
        m_isInternalCallToSubsystemPressed = true;
        IGSxGUI::Util::selectRow(sui->tawCPDSubsystem, m_selectedSubsystemRowNum);
        m_isInternalCallToSubsystemPressed = false;
    } else {
        loadCPDTable();
    }
    if (m_selectedCPD != "") {
        IGSxGUI::Util::setCPDUCTClickedStyle(sui->tawCPD->getWidgetItem(m_selectedCPDRowNum, 0));
        showCPDDetailsPage(true, m_selectedCPD);
        if (m_isTestReportFolded) {
            IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            sui->btnTestReports->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
            setReportWidgetsVisibility(false);
            moveDescriptionToOriginalPosition();
        } else {
            IGSxGUI::Util::setUnderline(sui->btnTestReports, false);
            IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->btnTestReports->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);
            setReportWidgetsVisibility(true);
            moveDescriptionToDown();
            populateTestReportTable();
            const int MINIMUM_VIEWABLE_REPORT_COUNT = 1;
            int numRowsChecked = IGSxGUI::Util::getNumCheckedRows(sui->tawTestReports);
            if (numRowsChecked >= MINIMUM_VIEWABLE_REPORT_COUNT) {
                sui->btnViewSelectedReports->setEnabled(true);
                sui->btnViewSelectedReports->setStyleSheetClass(STYLE_ENABLED_BUTTON);
            } else {
                sui->btnViewSelectedReports->setEnabled(false);
                sui->btnViewSelectedReports->setStyleSheetClass(STYLE_DISABLED_BUTTON);
            }
        }
        if (m_isDescFolded) {
            IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            showHTMLDescription(false);
        } else {
            showHTMLDescription(true);
        }
    }
}

void IGSxGUI::CPDView::onRadioButtonAllPressed()
{
    if (sui->rbtnAll->isChecked()) {
        intersectCPDs(m_presenter->getCPDs(), getSelectedSubSystemCPDs());
        populateCPDTable(m_listCPD);
    }
}

void IGSxGUI::CPDView::populateTestReportTable()
{
    IGSxCPD::TestResultList cpdTestReports;
    time_t currentTime = time(NULL);
    m_presenter->getCPDTestResults(m_selectedCPD, (currentTime - static_cast<time_t>((NUMBER_OF_DAYS * HOURS_PER_DAY * SECONDS_PER_HOUR))), currentTime, cpdTestReports);
    if (cpdTestReports.size() > 0) {
        sui->tawTestReports->setVisible(true);
        sui->tawTestReports->removeRows(1, sui->tawTestReports->rowCount()-1);
        for (size_t i = 0 ; i < 4; i++) {
            sui->tawTestReports->appendRow();
        }
        for (int row = 0; row < sui->tawTestReports->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawTestReports->getWidgetItem(row, 0);
            IGSxGUI::Util::setTestReportUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableTestResultRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&CPDView::onTestReportUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&CPDView::onTestReportUCTHoverLeft, this, row);
            std::string reportpath =  cpdTestReports[row].htmlReport();
            std::size_t found = reportpath.find_last_of("/\\");
            IGSxGUI::Util::setUnCheckToTestReportUserControl(widget);
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 1, reportpath.substr(found+1));
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 2, boost::lexical_cast<std::string>(IGSxGUI::DateTime::formatTime(cpdTestReports[row].time(), STRING_DATETIME_FORMAT)));
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 3, reportpath);
        }
    } else {
        sui->tawTestReports->setVisible(false);
    }
}

void IGSxGUI::CPDView::onRadioButtonCalibrationPressed()
{
    if (sui->rbtnCalibration->isChecked()) {
        intersectCPDs(getTestCPDsByName(STRING_CALIBRATION), getSelectedSubSystemCPDs());
        populateCPDTable(m_listCPD);
    }
}

void IGSxGUI::CPDView::onRadioButtonPerformancePressed()
{
    if (sui->rbtnPerformance->isChecked()) {
        intersectCPDs(getTestCPDsByName(STRING_PERFORMANCE), getSelectedSubSystemCPDs());
        populateCPDTable(m_listCPD);
    }
}

void IGSxGUI::CPDView::onRadioButtonDiagnosticsPressed()
{
    if (sui->rbtnDiagnostics->isChecked()) {
        intersectCPDs(getTestCPDsByName(STRING_DIAGNOSTICS), getSelectedSubSystemCPDs());
        populateCPDTable(m_listCPD);
    }
}

void IGSxGUI::CPDView::countAllSubSystemsTesttype()
{
    m_countAllCPD = 0;
    m_countCalibration = 0;
    m_countPerformance = 0;
    m_countDiagnostics = 0;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++) {
        container subsys = m_listSubsystems[i];
        if (subsys.cpd->getTestType() == STRING_CALIBRATION) {
            ++m_countCalibration;
        } else if (subsys.cpd->getTestType() == STRING_PERFORMANCE) {
            ++m_countPerformance;
        } else if (subsys.cpd->getTestType() == STRING_DIAGNOSTICS) {
            ++m_countDiagnostics;
        }
        ++m_countAllCPD;
    }
}

void IGSxGUI::CPDView::moveDescriptionToDown()
{
    const int ANGLE_YPOS = 498;
    const int BUTTON_YPOS = 494;
    const int LINE_YPOS = 530;
    const int WEBVIEW_HEIGHT = 360;
    sui->lblDescriptionAngle->setGeometry(sui->lblDescriptionAngle->getGeometry().getX(), ANGLE_YPOS, sui->lblDescriptionAngle->getGeometry().getWidth(), sui->lblDescriptionAngle->getGeometry().getHeight());
    sui->btnDescription->setGeometry(sui->btnDescription->getGeometry().getX(), BUTTON_YPOS, sui->btnDescription->getGeometry().getWidth(), sui->btnDescription->getGeometry().getHeight());
    sui->lblDescriptionLine->setGeometry(sui->lblDescriptionLine->getGeometry().getX(), LINE_YPOS, sui->lblDescriptionLine->getGeometry().getWidth(), sui->lblDescriptionLine->getGeometry().getHeight());
    sui->wvwCPDHTMLDescription->setGeometry(sui->wvwCPDHTMLDescription->getGeometry().getX(), LINE_YPOS, sui->wvwCPDHTMLDescription->getGeometry().getWidth(), WEBVIEW_HEIGHT);
}

void IGSxGUI::CPDView::moveDescriptionToOriginalPosition()
{
    const int ANGLE_YPOS = 198;
    const int BUTTON_YPOS = 194;
    const int LINE_YPOS = 230;
    const int WEBVIEW_HEIGHT = 1060;
    sui->lblDescriptionAngle->setGeometry(sui->lblDescriptionAngle->getGeometry().getX(), ANGLE_YPOS, sui->lblDescriptionAngle->getGeometry().getWidth(), sui->lblDescriptionAngle->getGeometry().getHeight());
    sui->btnDescription->setGeometry(sui->btnDescription->getGeometry().getX(), BUTTON_YPOS, sui->btnDescription->getGeometry().getWidth(), sui->btnDescription->getGeometry().getHeight());
    sui->lblDescriptionLine->setGeometry(sui->lblDescriptionLine->getGeometry().getX(), LINE_YPOS, sui->lblDescriptionLine->getGeometry().getWidth(), sui->lblDescriptionLine->getGeometry().getHeight());
    sui->wvwCPDHTMLDescription->setGeometry(sui->wvwCPDHTMLDescription->getGeometry().getX(), LINE_YPOS, sui->wvwCPDHTMLDescription->getGeometry().getWidth(), WEBVIEW_HEIGHT);
}

void IGSxGUI::CPDView::onBtnViewSelectedReportsPressed()
{
    sui->gbxFrontPage->setVisible(false);
    sui->gbxTestReportPage->setVisible(true);
    sui->lblCPDHeader->setText(sui->lblCPDHeader->getText() + STRING_TESTREPORTS);
    std::vector<std::string> listURL = IGSxGUI::Util::getReportURLfromTestReportTable(sui->tawTestReports);
    if (listURL.size() == 1) {
        sui->wvwSingleTestReport->setVisible(true);
        sui->wvwLeftTestReport->setVisible(false);
        sui->wvwRightTestReport->setVisible(false);
        sui->wvwSingleTestReport->setUrl(listURL[0]);
        sui->lblCloseAllReports->setText(STRING_CLOSEREPORT);
    } else {
        sui->wvwSingleTestReport->setVisible(false);
        sui->wvwLeftTestReport->setVisible(true);
        sui->wvwRightTestReport->setVisible(true);
        sui->wvwLeftTestReport->setUrl(listURL[0]);
        sui->wvwRightTestReport->setUrl(listURL[1]);
        sui->lblCloseAllReports->setText(STRING_CLOSEREPORTS);
    }
}

void IGSxGUI::CPDView::intersectCPDs(std::vector<IGSxGUI::CPD *> listTestTypeCPDs, std::vector<IGSxGUI::CPD *> listSubSystemCPDs)
{
    m_listCPD.clear();
    if (listSubSystemCPDs.size() > 1) {
        std::sort(listSubSystemCPDs.begin(), listSubSystemCPDs.end());
    }
    if (listTestTypeCPDs.size() > 1) {
        std::sort(listTestTypeCPDs.begin(), listTestTypeCPDs.end());
    }
    if ((listSubSystemCPDs.size() > 0) && (listTestTypeCPDs.size() > 0)) {
        std::set_intersection(listSubSystemCPDs.begin(), listSubSystemCPDs.end(), listTestTypeCPDs.begin(), listTestTypeCPDs.end(), std::back_inserter(m_listCPD));
    } else if (listSubSystemCPDs.size() > 0) {
        m_listCPD = listSubSystemCPDs;
    } else {
        m_listCPD = listTestTypeCPDs;
    }
}

void IGSxGUI::CPDView::loadTestTypes()
{
    m_listTestTypes.clear();
    container testtype;
    for (size_t i = 0 ; i < m_listCPD.size(); i++) {
        testtype.name = m_listCPD[i]->getTestType();
        testtype.cpd = m_listCPD[i];
        m_listTestTypes.push_back(testtype);
    }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestCPDsByName(const std::string &testtypeName) const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++) {
        IGSxGUI::container testtype = m_listTestTypes[i];
        if (testtype.name == testtypeName) {
            listTestTypeCPDs.push_back(testtype.cpd);
        }
    }
    return listTestTypeCPDs;
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getSelectedSubSystemCPDs() const
{
    std::vector<IGSxGUI::CPD*> listSubsystemCPDs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++) {
        container subsys = m_listSubsystems[i];
        std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
        if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem)) {
            listSubsystemCPDs.push_back(subsys.cpd);
        }
    }
    return listSubsystemCPDs;
}
