#include "mybutton.h"

MyButton::MyButton()
{

}
