#include "widget.h"
#include <QApplication>
#include <QtWidgets>
#include "mybutton.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyButton button;
    button.setFixedSize(400, 400);
    QChar chara(0xf002);
    button.setText(chara);
    button.show();
   // Widget w;
   // w.show();


    return a.exec();
}
