#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QScrollBar>
#include <QVBoxLayout>


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    model = new QStandardItemModel;
    widget = new QWidget;
    model->setColumnCount(2);
    model->setRowCount(20000);

    ui->lineEdit->setPlaceholderText("raja");
    if(ui->lineEdit->text().isEmpty())
    {
        ui->lineEdit->setStyleSheet("font-style: italic;");
    }
    ui->tableView->setModel(model);
    for(int i = 0; i < model->rowCount(); ++i)
    {
        ui->tableView->setRowHeight(i,40);
    }
    button = new QPushButton;
    buttonclicked = false;
    qDebug() << ui->tableView->verticalScrollBar()->minimum();
    qDebug() << ui->tableView->verticalScrollBar()->maximum();
    ui->tableView->horizontalHeader()->setVisible(false);
    loadTable();
    connect(ui->tableView->verticalScrollBar(),SIGNAL(valueChanged(int)),
            this, SLOT(loadTable()));
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()
{
    ui->tableView->clearSelection();
    ui->tableView->horizontalHeader()->adjustSize();
    for(int i =0; i < model->rowCount(); ++i)
    {
        QModelIndex index = model->index(i, 0);
        button = addADTUserControl(i);
        buttons.push_back(button);
        ui->tableView->setIndexWidget(index, button);
        ui->tableView->resizeRowsToContents();
    }
    foreach (QPushButton* button, buttons)
    {
        connect(button, SIGNAL(clicked(bool)),
                this, SLOT(onRowClicked()));
    }
}

void Widget::onRowClicked()
{

    button = dynamic_cast<QPushButton*>(QObject::sender());
    QLayout *layout = button->layout();
    QVBoxLayout *vboxlayout =  dynamic_cast<QVBoxLayout*>(layout->itemAt(0));
    QLabel *label0 = dynamic_cast<QLabel*>(vboxlayout->layout()->itemAt(0)->widget());
    QMessageBox box;
    box.setText(label0->text());
    box.exec();
}

QPushButton* Widget::addADTUserControl(int number)
{
    QPushButton *button = new QPushButton;
    QVBoxLayout *vlayout = new QVBoxLayout();
    QHBoxLayout *hlayout = new QHBoxLayout();
    QLabel *adtname = new QLabel;
    adtname->setText(QString::number(number+1));
    QSpacerItem *spacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);
    QLabel *arrow = new QLabel("Arrow");
    vlayout->addWidget(adtname);
    hlayout->addLayout(vlayout);
    hlayout->addItem(spacer);
    hlayout->addWidget(arrow);
    button->setLayout(hlayout);
    button->setFixedSize(545, 40);
    button->setStyleSheet("QPushButton:!hover{background-color:white}");
    button->setStyleSheet(button->styleSheet() + "QPushButton:hover:!pressed{background-color:#DAF2FE;}");
    return button;
}

void Widget::loadTable()
{
    int scrollbarvalue = ui->tableView->verticalScrollBar()->value();
    ui->tableView->clearSelection();
    ui->tableView->horizontalHeader()->adjustSize();
    for(int i = scrollbarvalue; i < scrollbarvalue + 20 ; ++i)
    {
       QModelIndex index = model->index(i, 0);
        button = addADTUserControl(i);
        buttons.push_back(button);
        ui->tableView->setIndexWidget(index, button);
    }
    foreach (QPushButton* button, buttons)
    {
        connect(button, SIGNAL(clicked(bool)),
                this, SLOT(onRowClicked()));
    }
}

