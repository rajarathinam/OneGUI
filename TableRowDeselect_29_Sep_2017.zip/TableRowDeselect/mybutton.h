#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QMouseEvent>
#include <QPushButton>

class MyButton : public QPushButton
{
public:
    MyButton();
    void mousePressEvent(QMouseEvent *event)
    {
        if( event->button() == Qt::LeftButton)
        {
            setStyleSheet("font-family: FontAwesome;color:red");
        } else {
            setStyleSheet("color:green");
        }
    }
};

#endif // MYBUTTON_H
