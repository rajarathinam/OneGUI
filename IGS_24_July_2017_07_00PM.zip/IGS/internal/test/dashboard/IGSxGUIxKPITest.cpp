/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPITest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of KPI test
|
| ! \file        IGSxGUIxKPITest.cpp
| ! \brief       Implementation of KPI test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKPITest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        KPITestParam,
                        ::testing::Values("EUV_Pulse_Energy_Internal"));

TEST_P(KPITestParam, Constructor)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);

    EXPECT_STRCASEEQ(kpi.getName().c_str(), m_kpiDefinition1.name().c_str());
    EXPECT_STRCASEEQ(kpi.getDescription().c_str(), m_kpiDefinition1.description().c_str());
}

TEST_P(KPITestParam, ValueContentSize)
{
    IGSxGUI::KPI kpi(m_kpiDefinition1);
    vector<IGSxGUI::KPIValueSet*> valsetlist = kpi.getValueSets();
    EXPECT_EQ(valsetlist.size(), 3);
}
