/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxApplication.hpp
| Author       : Raja A
| Description  : Header file for Application class
|
| ! \file        IGSxGUIxApplication.hpp
| ! \brief       Header file for Application class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXAPPLICATION_H
#define IGSXGUIXAPPLICATION_H

#include <string>
#include <SUIApplication.h>
#include <SUITimer.h>
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxGUIxControlManager.hpp"

class IGSxGUIxApplication
{
 public:
    IGSxGUIxApplication(int argc, char *argv[], const std::string &resourcePath);
    ~IGSxGUIxApplication();
    int exec();

 private:
    void initializePlugins();
    void onInitializePluginsCompleted();
    void onSplashTimeout();

    void onControlChanged(IGSxCTRL::Who::WhoEnum& who);

    static const int TIMER_INTERVAL;
    static const int SPLASHSCREEN_TIMEOUT;

    IGSxGUI::ISplashView *m_splashView;
    IGSxGUI::IMainView *m_mainView;
    std::string m_resourcePath;
    boost::shared_ptr<SUI::Timer> m_splashtimer;
    boost::shared_ptr<SUI::Application> m_app;

    int m_argc;
    char** m_argv;
    int m_count;
    IGSxGUI::ControlManager *m_controlManager;
};

#endif  // IGSXGUIXAPPLICATION_H
