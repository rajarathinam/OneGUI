/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashView.cpp
| Author       : Raja A
| Description  : Implementation of Splash screen view
|
| ! \file        IGSxGUIxSplashView.cpp
| ! \brief       Implementation of Splash screen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxMoc_SplashView.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxLOG.hpp"
#include <SUIDialog.h>
#include <SUIProgressBar.h>
#include <SUIGraphicsView.h>
#include <SUILabel.h>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::SplashView::FADEOUT_TIME = 500;
const std::string IGSxGUI::SplashView::SPLASHVIEW_LOAD_FILE = "IGSxGUIxSplashView.xml";
const std::string IGSxGUI::SplashView::STRING_SPLASHVIEW_SHOWN_LOG = "SplashView is shown.";


IGSxGUI::SplashView::SplashView():
    sui(new SUI::SplashView),
    m_timer(SUI::Timer::createTimer())
{
    if (sui != NULL)
    {
        sui->setupSUI(SPLASHVIEW_LOAD_FILE.c_str());
    }

    m_presenter = new IGSxGUI::SplashPresenter(this);

    m_timer->setSingleShot(true);
    m_timer->timeout = boost::bind(&SplashView::onTimeout, this);

    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    //IGSxGUI::Util::setAwesome(sui->lblCopyrightImage, IGSxGUI::AwesomeIcon::AI_fa_copyright, SUI::ColorEnum::Gray, "");
    IGSxGUI::Util::setTranslucentBackground(sui->dialog);
    sui->lblCopyright->setVisible(false);
    sui->lblCopyrightImage->setVisible(false);
    sui->lblCopyrightText->setVisible(false);
}
IGSxGUI::SplashView::~SplashView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SplashView::show()
{
    sui->dialog->show();
    sui->lblMachineId->setText(m_presenter->getMachineId());
    sui->lblVersion->setText(m_presenter->getReleaseId());

    IGS_INFO(STRING_SPLASHVIEW_SHOWN_LOG);
}

void IGSxGUI::SplashView::hide()
{
    IGSxGUI::Util::setFadeOut(sui->dialog, FADEOUT_TIME);
    m_timer->start(FADEOUT_TIME);
}

void IGSxGUI::SplashView::onTimeout()
{
    sui->dialog->hide();
}

