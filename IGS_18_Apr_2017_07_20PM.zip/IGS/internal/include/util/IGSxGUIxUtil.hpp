/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Utility class
|
| ! \file        IGSxGUIxUtil.hpp
| ! \brief       Header file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXUTIL_HPP
#define IGSXGUIXUTIL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <boost/shared_ptr.hpp>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Widget;
class Dialog;
}

/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class Util
{
 public:
    static void setGeometry(SUI::Widget *widget, int x, int y, int width, int height);
    static void setWindowFrame(SUI::Dialog *dialog, bool enable);
    static void disableScrollbars(SUI::Dialog *dialog);

    /**
     * @brief setParent sets the parent of the widget to the parent from the
     * @param widget The widget to set the parent on
     * @param parent This is the widget where the parent will be taken from
     */
    static void setParent(SUI::Widget *widget, SUI::Widget* parent);

 private:
    Util();
};

}  // namespace IGSxGUI

#endif  // IGSXGUIXUTIL_HPP
