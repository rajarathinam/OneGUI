/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManager.hpp
| Author       : Venugopal S
| Description  : Header file for ADT Manager
|
| ! \file        IGSxGUIxADTManager.hpp
| ! \brief       Header file for ADT Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTMANAGER_HPP
#define IGSXGUIXADTMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ADTManager
{
 public:
    ADTManager();
    virtual ~ADTManager();

    void initialize();
    void add(ADT *adt);
    void remove(ADT *adt);
    ADT* getADT(const std::string& name) const;
    std::vector<ADT*> retrieveAll();

 private:
    ADTManager(ADTManager const &);
    ADTManager& operator=(ADTManager const &);

    std::vector<ADT*> m_ADTs;
};

}  // namespace IGSxGUI
#endif  // IGSXGUIXADTMANAGER_HPP
