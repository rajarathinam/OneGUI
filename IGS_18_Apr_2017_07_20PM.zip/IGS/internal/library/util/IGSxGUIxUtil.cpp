/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation file for Utility class
|
| ! \file        IGSxGUIxUtil.cpp
| ! \brief       Implementation file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxUtil.hpp"

#include <QDialog>
#include <QWidget>
#include <QScrollArea>

#include <SUIWidget.h>
#include <SUIDialog.h>
#include <SUIBaseWidget.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Util::Util()
{
}

void IGSxGUI::Util::setGeometry(SUI::Widget* widget, int x, int y, int width, int height)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    QWidget* qparent = qwidget->parentWidget();

    if (qwidget != NULL)
    {
        qwidget->setGeometry(x, qparent->y() + y, width, height);
    }
}

void IGSxGUI::Util::setWindowFrame(SUI::Dialog* dialog, bool enable)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);

    if (qdialog != NULL)
    {
        if (enable)
        {
            qdialog->setWindowFlags(Qt::Dialog);
        } else {
            qdialog->setWindowFlags(Qt::Sheet | Qt::FramelessWindowHint);
            qdialog->setFixedSize(qdialog->geometry().size());
        }
    }
}

void IGSxGUI::Util::disableScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL)
    {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");

        if (scrollArea != NULL)
        {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
    }
}

void IGSxGUI::Util::setParent(SUI::Widget* widget, SUI::Widget *parent)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    SUI::BaseWidget* suiparent = dynamic_cast<SUI::BaseWidget*>(parent);

    QWidget* topWidget = suiparent->getWidget()->nativeParentWidget();
    qwidget->setParent(topWidget);
}
