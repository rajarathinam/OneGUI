/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenterTest.hpp
| Author       : Raja
| Description  : Header file for CPD Presenter test
|
| ! \file        IGSxGUIxCPDPresenterTest.hpp
| ! \brief       Header file for CPD Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDPRESENTERTEST_HPP
#define IGSXGUIXCPDPRESENTERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxCPDPresenter.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class CPDPresenterTest : public ::testing::Test
{
 public:
  CPDPresenterTest(){}
  virtual ~CPDPresenterTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIXCPDPRESENTERTEST_HPP
