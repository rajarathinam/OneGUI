/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCOMMON.hpp
| Author       : Thijs Jacobs
| Description  : IGS common includes
|
| ! \file        IGSxCOMMON.hpp
| ! \brief       IGS common includes
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXCOMMON_HPP
#define IGSXCOMMON_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <time.h>
#include <string>
#include <sstream>
#include <exception>

//#include <CSDxAPP/CSDxAPPtyp.hpp>


namespace IGS {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// result type
typedef int Result;
const int OK = 0; // OK result

/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
// resource path
// this is a workaround until the resource path is facilitated by FWQ 
class Resource
{
public:
    static std::string path() { return "";/*std::string(CSDxAPP::BASE_DIR).append("/IGS/"); */}
    static std::string path(const std::string& _resFile) { return path() + _resFile; }
};


// utility functions
class Number
{
public:
    static std::string toString(int value) { std::ostringstream s; s << value; return s.str(); }
    static std::string toString(double value) { std::ostringstream s; s << value; return s.str(); }
    static std::string toString(size_t value) { std::ostringstream s; s << value; return s.str(); }
private:
    Number() {}
};

class Time
{
public:
    static std::string toString(time_t time)
    {
        static const std::string FORMAT = "%Y-%m-%d %H:%M:%S";
        return toString(time, FORMAT);
    }

    static std::string toString(time_t time, const std::string &format)
    {
        static const int BUF_SIZE = 20;
        char buf[BUF_SIZE];
        strftime(buf, BUF_SIZE, format.c_str(), localtime(&time));
        return std::string(buf);
    }

private:
    Time() {}
};


// exceptions
class Exception: public std::exception
{
public:
    explicit Exception(const std::string& message) {m_msg = message;}
    virtual ~Exception() throw () {}

    virtual const char* what() const throw () {return m_msg.c_str();}

private:
    std::string m_msg;
};

} // namespace IGS

#endif // IGSXCOMMON_HPP

