/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSIF.hpp
| Author       : Thijs Jacobs
| Description  : Proxy interface for SHDxVIEWERINFO to retrieve the SIF status 
|                and to start the MBDS Viewer
|
| ! \file        IGSxSIF.hpp
| ! \brief       Proxy interface for SHDxVIEWERINFO to retrieve the SIF status 
|                and to start the MBDS Viewer
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXSIF_HPP
#define IGSXSIF_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>


namespace IGSxSIF {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class SIF
{
// functions throw IGS::exception
public:
    static SIF* getInstance() {return instance;}

    // MBDS viewer
    virtual bool isMbdsViewerAvailable() = 0;
    virtual bool startMbdsViewer() = 0;
    
protected:
    // instance
    virtual ~SIF() {}
    static SIF* instance;
};

} // namespace IGSxSIF

#endif // IGSXSIF_HPP

