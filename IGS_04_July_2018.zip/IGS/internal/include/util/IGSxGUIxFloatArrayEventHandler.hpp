#ifndef IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
#define IGSXGUIXFLOATARRAYEVENTHANDLER_HPP

#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <QTimer>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>
#include <vector>
#include <string>

class IGSxGUIxFloatArrayEventHandler : public QObject
{
    Q_OBJECT
 public:
    explicit IGSxGUIxFloatArrayEventHandler(QObject *parent = 0);
    void setWidgetVector(std::vector<SUI::Widget*> widgetVector, std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector);
    void setTableWidget(SUI::TableWidget *tableWidget);

    void focusNextWidget();
    void focusPreviousWidget();

    void focusUtil(int index);
    void setDefaultStyleToFloatArrayButtons();
    void showXButtonutil(bool isKeyNavigation);
    void setErrorFoundFlag(bool *errorFound);
    void setCurrentIndex(int *currentIndex);
    void showXButton();
 protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QString objname = object->objectName();
        std::string objName = objname.toStdString();
        if (event->type() == QEvent::KeyPress) {
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            int key = keyEvent->key();
            switch (key) {
            case Qt::Key_Backtab:
                focusPreviousWidget();
                showXButtonForKeyNavigation();
                return true;
            case Qt::Key_Tab:
                if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                    focusPreviousWidget();
                    showXButtonForKeyNavigation();
                } else {
                    focusNextWidget();
                    showXButtonForKeyNavigation();

                }
                return true;
            default:
                return object->eventFilter(object, event);
            }
        } else if (event->type() == QEvent::MouseButtonPress && objName != "Dialog") {
            showXButton();
            return false;
        } else if (event->type() == QEvent::MouseButtonDblClick && objName != "Dialog") {
            selectLineEditText();
            return true;
        } else if (event->type() == QEvent::FocusIn) {
            QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
            if (qedit != NULL && qedit->selectionStart() != 0) {
                // The line edit is made read only once the focus goes out of it, so that the cursor will disappear which is not happening automatically.
                // Make line edit editable here once focus comes in.
                qedit->setReadOnly(false);
                QTimer::singleShot(0,qedit,SLOT(selectAll()));
            }
            return true;
        } else if (event->type() == QEvent::FocusOut && objName.find("lne-tawFloatArrayParamaterPopup") != std::string::npos) {
            QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
            if (qedit != NULL) {
                resetLineEditStyle(qedit);
            }
            return false;
        }
        return object->eventFilter(object, event);
    }
 private:
    int *m_currentIndex;
    int totalWidgetCount;
    bool *isErrorFound;
    bool m_enableIndex;
    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    QWidget* btnUpdate;
    QWidget* btnCancel;
    QWidget* btnReset;
    QString buttonStylesheet;
    QString lineEditStylesheet;
    std::vector<SUI::Widget *> m_widgetVector;
    std::vector<SUI::Widget *> m_lineEditWidgetVector;
    std::vector<SUI::Widget *> m_clearButtonWidgetVector;
    void setWidgetsToDefaultStyle();
    void showXButtonForMouseClick(std::string objName);
    int getCurrentFocusedLineEditIndex();
    void showXButtonForKeyNavigation();
    void selectLineEditText();
    void resetLineEditStyle(QLineEdit* qedit);
};
#endif  // IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
