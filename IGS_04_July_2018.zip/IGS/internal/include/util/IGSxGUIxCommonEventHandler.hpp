/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCommonEventHandler.hpp
| Author       : Raja A
| Description  : Header file for Common Event Handler
|
| ! \file        IGSxGUIxCommonEventHandler.hpp
| ! \brief       Header file for Common Event Handler
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCOMMONEVENTHANDLER_H
#define IGSXGUIXCOMMONEVENTHANDLER_H

#include <QObject>
#include <QTableView>
#include <QKeyEvent>
#include <QDebug>
#include <SUIGroupBoxImpl.h>
#include <SUITableWidgetImpl.h>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxIViewCallback.hpp"

class IGSxGUIxCommonEventHandler : public QObject
{
    Q_OBJECT
  public:
    explicit IGSxGUIxCommonEventHandler(QObject *parent = 0);
    ~IGSxGUIxCommonEventHandler();
    void setGroupBox(SUI::GroupBox *groupBox);
    void setTableWidget(SUI::TableWidget *tableWidget);
    void setViewCallBack(IGSxGUI::IViewCallback *viewCallBack);
    void selectAllRows();
    void copySelectedRows();
    bool eventFilter(QObject *object, QEvent *event);
private:
    SUI::GroupBox *m_groupBox;
    SUI::TableWidget *m_tableWidget;
    IGSxGUI::IViewCallback *m_viewCallBack;

};
#endif // IGSXGUIXCOMMONEVENTHANDLER_H
