#ifndef IGSXGUIXHISTORYEVENTHANDLER_HPP
#define IGSXGUIXHISTORYEVENTHANDLER_HPP

#include <QObject>
#include <QTableView>
#include <QKeyEvent>
#include <QDebug>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxIHistoryCallback.hpp"

class IGSxGUIxHistoryEventHandler : public QObject
{
    Q_OBJECT
  public:
    explicit IGSxGUIxHistoryEventHandler(QObject *parent = 0);
    ~IGSxGUIxHistoryEventHandler();
    void setDialog(SUI::Dialog *dialog);
    void setTableWidget(SUI::TableWidget *tableWidget);
    void setHistoryCallBack(IGSxGUI::IHistoryCallBack *historyCallBack);
    void selectAllRows();
    void copySelectedRows();
protected:
    bool eventFilter(QObject *object, QEvent *event);

  private:
    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    IGSxGUI::IHistoryCallBack *m_HistoryCallBack;

};


#endif // IGSXGUIXHISTORYEVENTHANDLER_HPP
