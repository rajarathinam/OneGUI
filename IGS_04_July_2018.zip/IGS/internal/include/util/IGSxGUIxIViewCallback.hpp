/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxIViewCallBack.hpp
| Author       : Raja A
| Description  : Header file for IViewCallBack
|
| ! \file        IGSxGUIxSystemDateTime.hpp
| ! \brief       Header file for IViewCallBack
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IVIEWCALLBACK_H
#define IVIEWCALLBACK_H
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
    class IViewCallback
    {
    public:
        virtual std::string getParameterData() = 0;
        virtual void selectAllRows() = 0;
        virtual void setCtrlKeyPressed(bool) = 0;
    };
}  // namespace IGSxGUI
#endif // IVIEWCALLBACK_H
