#ifndef IGSXGUIXIPENDINGPARAMETERSSAVESCREENCALLBACK_HPP
#define IGSXGUIXIPENDINGPARAMETERSSAVESCREENCALLBACK_HPP
namespace IGSxGUI{
class IPendingParametersSaveScreenCallBack
{
 public:
    virtual void saveButtonPressedOnPendingParamFinalSaveScreen() = 0;
    virtual void cancelButtonPressedOnPendingParamFinalSaveScreen() = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIPENDINGPARAMETERSSAVESCREENCALLBACK_HPP
