/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxSystemDateTime.hpp
| Author       : Raja A
| Description  : Header file for System Date and Time
|
| ! \file        IGSxGUIxSystemDateTime.hpp
| ! \brief       Header file for System Date and Time
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXHISTORYCALLBACK_HPP
#define IGSXGUIXHISTORYCALLBACK_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
    class IHistoryCallBack
    {
    public:
        virtual std::string getParameterHistoryData() = 0;
        virtual void selectAllRows() = 0;
        virtual void setCtrlKeyPressed(bool) = 0;
    };
}  // namespace IGSxGUI
#endif  // IGSXGUIXHISTORYCALLBACK_HPP
