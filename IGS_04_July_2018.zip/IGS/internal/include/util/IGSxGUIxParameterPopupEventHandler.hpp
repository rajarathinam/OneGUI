/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterPopupEventHandler.hpp
| Author       : Roopesh Thota
| Description  : Header file for parameter popup dialog event handler
|
| ! \file        IGSxGUIxParameterPopupEventHandler.hpp
| ! \brief       Header file for parameter popup dialog event handler
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXGUIXPARAMETERPOPUPEVENTHANDLER_HPP
#define IGSXGUIXPARAMETERPOPUPEVENTHANDLER_HPP

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QLineEdit>
#include <SUILineEditImpl.h>
#include <SUIBaseWidget.h>

class IGSxGUIxParameterPopupEventHandler : public QObject
{
    Q_OBJECT
 public:
    IGSxGUIxParameterPopupEventHandler();
    void installEvents(SUI::Widget * widget);
 private:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        if (mouseEvent->type() == QEvent::MouseButtonDblClick) {
            selectLineEditText();
            return true;
        }
        return object->eventFilter(object, event);
    }
    void selectLineEditText();
    QLineEdit *m_lneEdit;
};
#endif  // IGSXGUIXPARAMETERPOPUPEVENTHANDLER_HPP
