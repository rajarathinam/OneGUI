/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM.hpp
| Author       : Matthijs den Uijl
| Description  : Proxy interface for System State Management
|
| ! \file        IGSxSSM.hpp
| ! \brief       Proxy interface for System State Management
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXSSM_HPP
#define IGSXSSM_HPP

#include <boost/array.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/function.hpp>
#include <vector>

namespace IGSxSSM
{
    //forward declarations
    class StateConfigType;
    class GroupConfigType;
    class SystemFunctionType;
    class SSM;
    
    //constants
    static const int STATE_NR_OF_LINES = 3;  //number of lines.
    static const int NR_OF_SYSTEM_FUNCTIONS = 6; // number of system functions
    //defines
    typedef boost::array< std::string, STATE_NR_OF_LINES> StateDescriptionType;
    typedef int StateIDType;
    typedef std::vector< StateConfigType>  StateConfigList;
    typedef std::vector< GroupConfigType>  GroupConfigList;
    typedef boost::shared_ptr<SystemFunctionType> SystemFunctionPtr;
    typedef boost::array< SystemFunctionPtr,  NR_OF_SYSTEM_FUNCTIONS>  SystemFunctionPtrList;
    typedef boost::shared_ptr<SSM> SSMPtr;
    
   //Parameter category
    enum TransitionResultType
    {
       OK = 0,
       ABORTED,
       ERROR
    };
   
   enum FunctionResultType
   {
       FUNCTION_OK = 0,
       FUNCTION_ERROR
    };
   
    //Configuration of state
    class StateConfigType
    {
         public:
            explicit StateConfigType( const StateDescriptionType& description, const  StateIDType& id):
                m_description( description),
                m_id( id )
            {
            }
            
            virtual ~StateConfigType(){}
            
            const StateDescriptionType&  description() const {return m_description;}
            const StateIDType& id() const {return m_id;}
            
        private:
            StateDescriptionType m_description; // description of the state
            StateIDType          m_id;          // id of the state, unique id for a System Function
    };
        
    //Configuration of the group
    class GroupConfigType
    {
        public:
            explicit GroupConfigType( const std::string& description,
                                const  StateConfigList& states):
                    m_description( description),
                    m_states( states )
            {
            }
                
            virtual ~GroupConfigType(){}
                
            const std::string&  description() const {return m_description;}
            const StateConfigList& states() const {return m_states;}
                
        private:
            std::string          m_description; // description of the group
            StateConfigList      m_states;      // states of the group
    };
    
    //Configuration of the transitions
    class ReachableStateType
    {
        public:
            explicit ReachableStateType(
                        const StateIDType& state,
                        bool  can_be_aborted ):
                        m_state( state),
                        m_can_be_arborted( can_be_aborted )
            {
            }
                    
            virtual ~ReachableStateType(){}
                    
            const StateIDType& state() const {return m_state;}
            bool can_be_aborted() const {return m_can_be_arborted;}
        
        private:
            StateIDType m_state; // the reachable state
            bool        m_can_be_arborted; // determines whether the state can be aborted
    }; 
    
   typedef std::vector< ReachableStateType > ReachableStateList;

    //Configuration of the a system function
    class SystemFunctionConfigType
    {
        public:
            explicit SystemFunctionConfigType( const std::string& description,
                                               const GroupConfigList& groups ):
                    m_description( description),
                    m_groups( groups )
            {
            }
                
            virtual ~SystemFunctionConfigType(){}
                
            const std::string&  description() const {return m_description;}
            const GroupConfigList&  groups() const {return m_groups;}
     
         private:
            std::string          m_description; // description of the function
            GroupConfigList      m_groups;      // groups of the function
    };
 
    //the events 
    //raised in case a transition has been started
    typedef boost::function<void (const StateIDType& /*from*/,const StateIDType& /*to*/, const unsigned int /*duration*/)> TransitionStartedCallback;
    //raised in case a transition has been completed
    typedef boost::function<void (const StateIDType& /*from*/,const StateIDType& /*to*/ , const TransitionResultType& /*result*/, const ReachableStateList& /*reachable_states*/)> TransitionCompletedCallback;
    //raised in case the state of a SFC has changed with-out a transition
    typedef boost::function<void ()> StateUpdatedCallback;
    //raised in case a set_state has been called
    typedef boost::function<void (const FunctionResultType& /*result*/)> SetStateResultCallback;
    //raised in case a get_state has been called
    typedef boost::function<void (const FunctionResultType& /*result*/, const StateIDType& /*from*/, const StateIDType& /*to*/, const ReachableStateList& /*reachable_states*/)> GetStateResultCallback;
    //Proxy for the system function
    class SystemFunctionType
    {
        public:
            //member functions
            const SystemFunctionConfigType& config() const {return m_config;}
            //set the state
            virtual void set_state( const StateIDType& target ) = 0;
            //set the state
            virtual void get_state()const = 0;
            //subscribe/un-subscribe to/from events
            //Transition started
            virtual void subscribeTransitionStarted(TransitionStartedCallback cb) = 0;
            virtual void unsubscribeTransitionStarted() = 0;         
            //Transition completed
             virtual void subscribeTransitionCompleted(TransitionCompletedCallback cb) = 0;
            virtual void unsubscribeTransitionCompleted() = 0;       
            //State changed
            virtual void subscribeStateUpdated(StateUpdatedCallback cb) = 0;
            virtual void unsubscribeStateUpdated() = 0;        
            //Set state result
            virtual void subscribeSetStateResult(SetStateResultCallback cb) = 0;
            virtual void unsubscribeSetStateResult() = 0;         
            //Get state result
            virtual void subscribeGetStateResult(GetStateResultCallback cb) = 0;
            virtual void unsubscribeGetStateResult() = 0;
        protected:
            SystemFunctionType( const SystemFunctionConfigType& config ) : m_config(config ){}
        private:
            SystemFunctionConfigType m_config;
    };
    
    //State control of the system functions
    class SSM
    {
        public:
          //Get singleton
          static SSMPtr GetInstance() {return instance;};
          virtual ~SSM(){}
          //member functions
          virtual SystemFunctionPtrList functions() = 0;
        
        protected:
            SSM(){};
            static SSMPtr instance;
    };
};
#endif /* IGSXSSM_HPP */
