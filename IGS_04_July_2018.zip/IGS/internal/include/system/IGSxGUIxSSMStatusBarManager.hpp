/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerView.hpp
| Author       : Saket
| Description  : Header file for SSM Status bar manager
|
| ! \file        SSMStatusBarManager.hpp
| ! \brief       Header file for SSM STatus bar manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMSTATUSBARMANAGERSTATE_HPP
#define IGSXGUIXSYSTEMSTATUSBARMANAGERSTATE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <IGSxGUIxSSMManager.hpp>
#include <FWQxUtils/SUITime.h>
#include <FWQxUtils/SUITimer.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class GroupBox;
class Label;
}  // namespace SUI

namespace IGSxGUI{

class SSMStatusBarManager
{
   public:
    SSMStatusBarManager(StateList& states);
    void show(TransitionData &activeTransition);
    void setActive(bool bActive);
    void initWidgets(SUI::GroupBox *gbxCurrentState, SUI::GroupBox *gbxTransitionState, SUI::Label *lblCurrentStateText, SUI::Label *lblFromText, SUI::Label *lblToText, SUI::Label *lblStartTimeText, SUI::Label *lblExpectedDurationText, SUI::Label *lblElapsedTimeText);
private:
        void onTransitionTimeout();
        void updateExpectedDuration(const int expectedDuration);
        std::string getStateText(const IGSxSSM::StateIDType &stateId) const;

        StateList& mStates;
        boost::shared_ptr<SUI::Timer> mTransitionTimer;
        boost::shared_ptr<SUI::Time> mTransitionStartTime;

        int mExpectedDurationSeconds;
        int mElapsedDurationSeconds;

        SUI::GroupBox* mGbxCurrentState;
        SUI::GroupBox* mGbxTransitionState;

        SUI::Label* mlblCurrentStateText;
        SUI::Label* mlblFromText;
        SUI::Label* mlblToText;
        SUI::Label* mlblStartTimeText;
        SUI::Label* mlblExpectedDurationText;
        SUI::Label* mlblElapsedTimeText;

};


}

#endif
