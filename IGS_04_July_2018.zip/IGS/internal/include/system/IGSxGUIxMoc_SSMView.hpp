/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SystemStateManagerView.hpp
| Author       : S Kale
| Description  : Header file
|
| ! \file        SystemStateManagerView.hpp
| ! \brief       Header file
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSUI_MOC_SSMVIEW_HPP
#define IGSXGUIXSUI_MOC_SSMVIEW_HPP

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SSMView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class TabWidget;
class GraphicsView;

class SSMView
{
 private:
    SSMView();

    void setupSUI(const char *);
    void setupSUIContainer(const char *XMLFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    SUI::Container* container1;
    SUI::Container* container2;
    SUI::Container* container3;
    SUI::Container* container4;
    SUI::Container* container5;
    SUI::Container* container6;

    SUI::TabWidget* tabWidget;
    SUI::GraphicsView *imvLogo;

    friend class ::IGSxGUI::SSMView;
};

}  // namespace SUI
#endif  // IGSXGUIXSUI_MOC_SYSTEMVIEW_HPP
