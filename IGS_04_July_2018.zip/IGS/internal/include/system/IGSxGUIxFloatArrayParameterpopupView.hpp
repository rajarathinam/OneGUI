#ifndef IGSXGUIXFLOATPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXFLOATPARAMETERPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include "IGSxGUIxIFloatArrayParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class FloatArrayParameterpopupView;
}  // namespace SUI

namespace IGSxGUI{

class FloatArrayParameterpopupView : public IFloatArrayParameterpopupView
{
public:
    explicit FloatArrayParameterpopupView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager);
    virtual ~FloatArrayParameterpopupView();
    virtual void show();

    void onCloseButtonPressed();
    void setParameterName(const std::string &name);
    void setParameterValue();
    void setParameterDefaultValue();
    std::string getParameterName() const;
    std::string getParameterValue() const;
    void close();
    void onParamValueTextChanged(SUI::LineEdit * le, int row, const std::string& value);


    typedef boost::signals2::signal<void (std::string, std::string)> floatArrayValueChanged;
    typedef floatArrayValueChanged::slot_type floatArrayValueChangedCallback;

    boost::signals2::connection registerForFloatArrayValueChanged(const floatArrayValueChangedCallback& cb);

    void onUpdatebuttonPressed();
    void onCloseButtonHoverEntered();
    void onCloseButtonHoverLeft();
    void onResetButtonPressed();
    void setParent(SUI::Widget *parent);
    void onParamValueTextEditFinished();
    SUI::Label *getParameterNameType() const;
    void onParamNameLabelEntered(int row);
    void onParamNameLabelLeft(int row);
    void onCancelButtonPressed();
    void cancelYes();
    void cancelNo();
    void resetValues();
    void resetValuesNo();
    void clearLineEdit(int row);

private:

    static const int BUTTON_SIZE;
    static const std::string FLOATPARAMETERPOPUPVIEW_LOAD_FILE;
    static const std::string STRING_FLOATPARAMETERPOPUPVIEW_SHOWN;

    MachineconstantsManager* m_pMachineconstantsManager;
    ParameterData* m_parameterData;
    bool m_errorFound;
    int m_currentIndex;
    floatArrayValueChanged m_valueChanged;
    SUI::FloatArrayParameterpopupView *sui;
    SUI::Dialog* m_dialog;
    std::string m_initialValues;

    FloatArrayParameterpopupView(const FloatArrayParameterpopupView &);
    FloatArrayParameterpopupView& operator=(const FloatArrayParameterpopupView &);
    void init();
    void formatParamNameBack(std::string &name);
    void resizeDialog();
    void eraseEnteredCharFromLineEdit(SUI::LineEdit *le, std::string &text, int pos);
    void showWarning(SUI::LineEdit *le);
    bool validateFields();
    void formatParamButtonName(SUI::Widget *widget, std::string &name);
    int formatParamButtonNameAfterAddingDots(SUI::Widget *widget, std::string &name);
    void setParameterLabels();
    void disableDialog();
    void enableDialog();
    void focusFirstInvalidField();
    void adjustDoublePrecision(std::string &paramvalue);
    void hideAllClearButtons();
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXFLOATPARAMETERPOPUPVIEW_HPP
