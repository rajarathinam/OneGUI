/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerTabView.hpp
| Author       : Saket
| Description  : Header file for System state manager View
|
| ! \file        IGSxGUIxSystemStateManagerView.hpp
| ! \brief       Header file for SSM Tab View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMSTATEMANAGERTABVIEW_HPP
#define IGSXGUIXSYSTEMSTATEMANAGERTABVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <boost/function.hpp>
#include <IGSxGUIxISSMView.hpp>
#include <IGSxGUIxSSMManager.hpp>
#include <IGSxGUIxSSMStatusBarManager.hpp>
#include <util/IGSxGUIxUtil.hpp>
#include <FWQxUtils/SUITimer.h>
#include <FWQxUtils/SUITime.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SSMTabView;
class Container;
class UserControl;
class Button;
class Label;

struct SUIUCState
{
    SUI::UserControl* Control;
    SUI::Button* Button;
    SUI::BusyIndicator* BsyIndicator;
    SUI::Label* OverlayLabel;

    SUIUCState(SUI::UserControl* uc, SUI::Button* button, SUI::BusyIndicator* bic, SUI::Label* lbl) : Control(uc), Button(button), BsyIndicator(bic), OverlayLabel(lbl)
    {}
    SUIUCState& operator=(const SUIUCState& obj)
    {
        Control = obj.Control;
        Button = obj.Button;
        BsyIndicator = obj.BsyIndicator;
        OverlayLabel = obj.OverlayLabel;
        return *this;
    }
    SUIUCState(const SUIUCState& obj)
    {
        this->Control = obj.Control;
        this->Button = obj.Button;
        this->BsyIndicator = obj.BsyIndicator;
        this->OverlayLabel = obj.OverlayLabel;
    }
};

}  // namespace SUI

namespace IGSxGUI{

class SSMTabView : public ISSMView
{
 public:
    explicit SSMTabView(SSMManager& ssmManager, const TabType tabIndex);
    virtual ~SSMTabView();
    virtual void show(SUI::Container*, bool);
    virtual void setActive(bool bActive);
    virtual void reset();

private:
    void init();
    void setupGroups();
    void addNewState(const int groupIndex, const int stateIndex);
    void stateChanged(IGSxGUI::InnerState innerState, const int newStateId, const int newUIStateIndex);
    void setupStates();
    void setupUI();
    void setupStatusBar();
    void updateStatusBar();
    std::string getStateText(const IGSxSSM::StateIDType &stateId) const;
    void onTransitionTimeout();

    IGSxGUI::InnerState getInnerState(const int stateId) const;
    std::string generateStateName(const int groupIndex, const int stateIndex);
    void showGroup1();
    void showGroup12();
    void showGroup123();

    SUI::SSMTabView *sui;
    std::vector< std::vector< SUI::SUIUCState> > SUIStates;
    static const std::string SYSTEMSTATEMANAGER_TAB_LOAD_FILE;
    static const std::string SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE;
    StateList States;
    IGSxGUI::TabType mTabIndex;
    SSMManager& mManager;
    SSMStatusBarManager mStatusBarManager;

    IGSxGUI::TransitionData mActiveTransition;
    int mStateCounter;
    bool mLoaded;
    int mPreviousStateIndex;

};

}

#endif
