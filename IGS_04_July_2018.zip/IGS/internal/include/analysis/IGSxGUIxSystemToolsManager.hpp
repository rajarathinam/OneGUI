/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsManager.hpp
| Author       : Venugopal S
| Description  : Header file for SystemTools Manager
|
| ! \file        IGSxGUIxSystemToolsManager.hpp
| ! \brief       Header file for SystemTools Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMTOOLSMANAGER_HPP
#define IGSXGUIXSYSTEMTOOLSMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/


namespace IGSxGUI{
class SystemToolsManager
{
 public:
    explicit SystemToolsManager();
    virtual ~SystemToolsManager();

    void initialize();
    bool isMbdsViewerAvailable() const;
    void startMbdsViewer() const;

 private:
    SystemToolsManager(const SystemToolsManager& SystemToolsManager);
    SystemToolsManager& operator=(const SystemToolsManager& SystemToolsManager);

};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMTOOLSMANAGER_HPP
