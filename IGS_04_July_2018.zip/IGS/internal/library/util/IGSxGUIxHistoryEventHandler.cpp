#include "IGSxGUIxHistoryEventHandler.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include <QApplication>
#include <QClipboard>


IGSxGUIxHistoryEventHandler::IGSxGUIxHistoryEventHandler(QObject *parent) :
    QObject(parent), m_dialog(NULL), m_tableWidget(NULL)
{
}

IGSxGUIxHistoryEventHandler::~IGSxGUIxHistoryEventHandler()
{
}

void IGSxGUIxHistoryEventHandler::setDialog(SUI::Dialog *dialog)
{
    m_dialog = dialog;
}

void IGSxGUIxHistoryEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
}

void IGSxGUIxHistoryEventHandler::setHistoryCallBack(IGSxGUI::IHistoryCallBack  *historyCallBack)
{
    m_HistoryCallBack  = historyCallBack;
}

void IGSxGUIxHistoryEventHandler::selectAllRows()
{
    for (int row = 0; row < m_tableWidget->rowCount(); ++row) {
        IGSxGUI::Util::selectHistoryRow(m_tableWidget, row);
        SUI::Widget *widget = m_tableWidget->getWidgetItem(row, 0);
        IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
    }
    m_HistoryCallBack->selectAllRows();

}

void IGSxGUIxHistoryEventHandler::copySelectedRows()
{
    std::string completCopiedText = m_HistoryCallBack->getParameterHistoryData();
    QClipboard *clipboard = QApplication::clipboard();
    clipboard->setText("");
    clipboard->setText(QString(completCopiedText.c_str()));


}

bool IGSxGUIxHistoryEventHandler::eventFilter(QObject *object, QEvent *event)
{
    int eventType = event->type();
    switch (eventType) {
    case QEvent::KeyPress: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
            m_HistoryCallBack->setCtrlKeyPressed(true);
            if (key == Qt::Key_A) {
                selectAllRows();
            }
            if (key == Qt::Key_C) {
                copySelectedRows();
            }
        }
        return true;
    }
    case QEvent::KeyRelease: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (key == Qt::Key_Control) {
            m_HistoryCallBack->setCtrlKeyPressed(false);
        }
        return true;
    }
    default:
        break;
    }
    return QObject::eventFilter(object, event);
}
