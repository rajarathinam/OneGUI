#include "IGSxGUIxHistoryTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

IGSxGUIxHistoryTableHeaderEventHandler::IGSxGUIxHistoryTableHeaderEventHandler() {
}

void IGSxGUIxHistoryTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);
    SUI::BaseWidget* baseWidget5 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[4]);
    SUI::BaseWidget* baseWidget6 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[5]);
    SUI::BaseWidget* baseWidget7 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[6]);
    SUI::BaseWidget* baseWidget8 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[7]);

    m_parameterNameHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget1->getWidget());
    m_parameterNameHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget2->getWidget());
    m_changedOnHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget3->getWidget());
    m_changedOnHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget4->getWidget());
    m_changedByHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget5->getWidget());
    m_changedByHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget6->getWidget());
    m_reasonHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget7->getWidget());
    m_reasonHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget8->getWidget());

    m_parameterNameHistoryHeaderButtonText->installEventFilter(this);
    m_parameterNameHistoryHeaderButtonImage->installEventFilter(this);
    m_changedOnHistoryHeaderButtonText->installEventFilter(this);
    m_changedOnHistoryHeaderButtonImage->installEventFilter(this);
    m_changedByHistoryHeaderButtonText->installEventFilter(this);
    m_changedByHistoryHeaderButtonImage->installEventFilter(this);
    m_reasonHistoryHeaderButtonText->installEventFilter(this);
    m_reasonHistoryHeaderButtonImage->installEventFilter(this);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet("color:#FF7F45");
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet("color:#FF7F45");
    m_changedOnHistoryHeaderButtonImage->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet("color:#FF7F45");
    m_changedByHistoryHeaderButtonImage->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet("color:#FF7F45");
    m_reasonHistoryHeaderButtonImage->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_changedOnHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_changedByHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_reasonHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet("color:#B3E2FF");
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet("color:#B3E2FF");
    m_changedOnHistoryHeaderButtonImage->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet("color:#B3E2FF");
    m_changedByHistoryHeaderButtonImage->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet("color:#B3E2FF");
    m_reasonHistoryHeaderButtonImage->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_changedOnHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_changedByHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet("color:#1B3E93");
    m_reasonHistoryHeaderButtonImage->setStyleSheet("color:#1B3E93");
}
