#include <QRadioButton>
#include <FWQxCore/SUIResourcePath.h>
#include <sstream>
#include <string>
#include <vector>
#include "IGSxGUIxRadioButtonEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_normal = SUI::ResourcePath::getResourceFile("radiobutton_12px_normal.png");
const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_normal_fill = SUI::ResourcePath::getResourceFile("radiobutton_12px_normal_fill.png");
const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_hover = SUI::ResourcePath::getResourceFile("radiobutton_12px_hover.png");
const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_hover_fill = SUI::ResourcePath::getResourceFile("radiobutton_12px_hover_fill.png");
const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_pressed = SUI::ResourcePath::getResourceFile("radiobutton_12px_pressed.png");
const std::string IGSxGUIxRadioButtonEventHandler::radiobutton_12px_pressed_fill = SUI::ResourcePath::getResourceFile("radiobutton_12px_pressed_fill.png");

IGSxGUIxRadioButtonEventHandler::IGSxGUIxRadioButtonEventHandler() {
}

void IGSxGUIxRadioButtonEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widgetVector[1]);
    QRadioButton* trueBtn = dynamic_cast<QRadioButton*>(baseWidget1->getWidget());
    QRadioButton* falseBtn = dynamic_cast<QRadioButton*>(baseWidget2->getWidget());

    trueBtn->installEventFilter(this);
    falseBtn->installEventFilter(this);

    trRbtn = trueBtn;
    faRbtn = falseBtn;
}

void IGSxGUIxRadioButtonEventHandler::trueRbtnHoverEntered()
{
    std::ostringstream oss;
    if (trRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_hover_fill << ")} QRadioButton{color:#1b3e93;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_hover << ")} QRadioButton{color:#1b3e93;}";
    }
    std::string style = oss.str();
    trRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::falseRbtnHoverEntered()
{
    std::ostringstream oss;
    if (faRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_hover_fill << ")} QRadioButton{color:#1b3e93;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_hover << ")} QRadioButton{color:#1b3e93;}";
    }
    std::string style = oss.str();
    faRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::trueRbtnHoverLeft()
{
    std::ostringstream oss;
    if (trRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_normal_fill << ")} QRadioButton{color:#000000;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_normal << ")} QRadioButton{color:#000000;}";
    }
    std::string style = oss.str();
    trRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::falseRbtnHoverLeft()
{
    std::ostringstream oss;
    if (faRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_normal_fill << ")} QRadioButton{color:#000000;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_normal << ")} QRadioButton{color:#000000;}";
    }
    std::string style = oss.str();
    faRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::trueRbtnPressed()
{
    std::ostringstream oss;
    if (trRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_pressed_fill << ")} QRadioButton{color:#1b3e93;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_pressed << ")} QRadioButton{color:#1b3e93;}";
    }
    std::string style = oss.str();
    trRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::falseRbtnPressed()
{
    std::ostringstream oss;
    if (faRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_pressed_fill << ")} QRadioButton{color:#1b3e93;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_pressed << ")} QRadioButton{color:#1b3e93;}";
    }
    std::string style = oss.str();
    faRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::trueRbtnReleased()
{
    std::ostringstream oss;
    if (trRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_normal_fill << ")} QRadioButton{color:#000000;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_normal << ")} QRadioButton{color:#000000;}";
    }
    std::string style = oss.str();
    trRbtn->setStyleSheet(style.c_str());
}

void IGSxGUIxRadioButtonEventHandler::falseRbtnReleased()
{
    std::ostringstream oss;
    if (faRbtn->isChecked()) {
        oss << "QRadioButton::indicator:checked {image: url(" << radiobutton_12px_normal_fill << ")} QRadioButton{color:#000000;}";
    } else {
        oss << "QRadioButton::indicator:unchecked {image: url(" << radiobutton_12px_normal << ")} QRadioButton{color:#000000;}";
    }
    std::string style = oss.str();
    faRbtn->setStyleSheet(style.c_str());
}
