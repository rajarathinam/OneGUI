/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCommonEventHandler.cpp
| Author       : Raja A
| Description  : Implementation for Common Event Handler
|
| ! \file        IGSxGUIxCommonEventHandler.hpp
| ! \brief       Implementation for Common Event Handler
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include <QClipboard>
#include <QApplication>
#include"IGSxGUIxCommonEventHandler.hpp"

IGSxGUIxCommonEventHandler::IGSxGUIxCommonEventHandler(QObject *parent)
{

}


IGSxGUIxCommonEventHandler::~IGSxGUIxCommonEventHandler()
{

}


void IGSxGUIxCommonEventHandler::setGroupBox(SUI::GroupBox *groupBox)
{
   m_groupBox = groupBox;
}


void IGSxGUIxCommonEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
  m_tableWidget = tableWidget;
}


void IGSxGUIxCommonEventHandler::setViewCallBack(IGSxGUI::IViewCallback *viewCallBack)
{
  m_viewCallBack = viewCallBack;
}




bool IGSxGUIxCommonEventHandler::eventFilter(QObject *object, QEvent *event)
{
    int eventType = event->type();
    switch (eventType) {
    case QEvent::KeyPress: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
            m_viewCallBack->setCtrlKeyPressed(true);
            if (key == Qt::Key_A) {
                m_viewCallBack->selectAllRows();
            }
            if (key == Qt::Key_C) {
                copySelectedRows();
            }
        }
        return true;
    }
    case QEvent::KeyRelease: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (key == Qt::Key_Control) {
            m_viewCallBack->setCtrlKeyPressed(false);
        }
        return true;
    }
    default:
        break;
    }
    return QObject::eventFilter(object, event);
}

void IGSxGUIxCommonEventHandler::copySelectedRows()
{
    std::string completCopiedText = m_viewCallBack->getParameterData();
    QClipboard *clipboard = QApplication::clipboard();
    clipboard->setText("");
    clipboard->setText(QString(completCopiedText.c_str()));


}
