#include "IGSxGUIxPendingParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

IGSxGUIxPendingParameterTableHeaderEventHandler::IGSxGUIxPendingParameterTableHeaderEventHandler() {
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);

    parameterName = dynamic_cast<QPushButton*>(baseWidget1->getWidget());
    upArrow = dynamic_cast<QPushButton*>(baseWidget2->getWidget());
    downArrow = dynamic_cast<QPushButton*>(baseWidget3->getWidget());
    upDownArrow = dynamic_cast<QPushButton*>(baseWidget4->getWidget());

    parameterName->installEventFilter(this);
    upArrow->installEventFilter(this);
    downArrow->installEventFilter(this);
    upDownArrow->installEventFilter(this);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mousePressed()
{
    parameterName->setStyleSheet("color:#FF7F45");
    upArrow->setStyleSheet("color:#FF7F45");
    downArrow->setStyleSheet("color:#FF7F45");
    upDownArrow->setStyleSheet("color:#FF7F45");
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseReleased()
{
    parameterName->setStyleSheet("color:#1B3E93");
    upArrow->setStyleSheet("color:#1B3E93");
    downArrow->setStyleSheet("color:#1B3E93");
    upDownArrow->setStyleSheet("color:#1B3E93");
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseEnter()
{
    parameterName->setStyleSheet("color:#B3E2FF");
    upArrow->setStyleSheet("color:#B3E2FF");
    downArrow->setStyleSheet("color:#B3E2FF");
    upDownArrow->setStyleSheet("color:#B3E2FF");
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseLeft()
{
    parameterName->setStyleSheet("color:#1B3E93");
    upArrow->setStyleSheet("color:#1B3E93");
    downArrow->setStyleSheet("color:#1B3E93");
    upDownArrow->setStyleSheet("color:#1B3E93");
}
