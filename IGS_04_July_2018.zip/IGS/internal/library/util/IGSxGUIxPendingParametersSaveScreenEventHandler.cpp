#include <boost/function.hpp>
#include <QLineEdit>
#include <QPushButton>
#include <vector>
#include <string>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxPendingParametersSaveScreenEventHandler.hpp"

IGSxGUIxPendingParametersSaveScreenEventHandler::IGSxGUIxPendingParametersSaveScreenEventHandler(QObject *parent) :
    QObject(parent)
{
}

void IGSxGUIxPendingParametersSaveScreenEventHandler::installEvents(std::vector<SUI::Widget *> widgetVector)
{
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(widgetVector[3]);

    m_leName = dynamic_cast<QLineEdit*>(baseWidget1->getWidget());
    m_txaReason = dynamic_cast<QTextEdit*>(baseWidget2->getWidget());
    m_gbxSave = dynamic_cast<QGroupBox*>(baseWidget3->getWidget());
    m_btnCancel = dynamic_cast<QPushButton*>(baseWidget4->getWidget());

    m_txaReasonViewport = m_txaReason->viewport();

    m_leName->installEventFilter(this);
    m_txaReasonViewport->installEventFilter(this);
    m_txaReason->installEventFilter(this);
    m_gbxSave->installEventFilter(this);
    m_btnCancel->installEventFilter(this);
}

void IGSxGUIxPendingParametersSaveScreenEventHandler::setPendingParametersSaveScreenCallBack(IGSxGUI::IPendingParametersSaveScreenCallBack* pendingParametersSaveScreenCallBack)
{
    m_pendingParametersSaveScreenCallBack  = pendingParametersSaveScreenCallBack;
}

void IGSxGUIxPendingParametersSaveScreenEventHandler::focusPreviousWidget()
{
    if (m_leName->hasFocus()) {
        m_btnCancel->setStyleSheet("border: 2px dotted #1B3E93");
        m_btnCancel->setFocus();
        m_leName->setStyleSheet("border-color:#AAAAAA");
    } else if (m_txaReason->hasFocus()) {
        m_txaReason->setStyleSheet("border-color:#AAAAAA");
        setTextEditPaletteColor(m_txaReason, "#ffffff", "#000000");
        m_leName->setStyleSheet("border-color:#0AA8FB");
        m_leName->setFocus();
        m_leName->selectAll();
    } else if (m_gbxSave->hasFocus()) {
        m_gbxSave->setStyleSheet("QGroupBox{border: none}");
        m_txaReason->setStyleSheet("border-color:#0AA8FB");
        m_txaReason->setFocus();
        m_txaReason->selectAll();
        setTextEditPaletteColor(m_txaReason, "#0AA8FB", "#FFFFFF");
    } else if (m_btnCancel->hasFocus()){
        m_btnCancel->setStyleSheet("border: 1px solid #0AA8FB");
        if (m_gbxSave->isEnabled()) {
            m_gbxSave->setStyleSheet("QGroupBox{border: 2px dotted #1B3E93}");
            m_gbxSave->setFocus();
        } else {
            m_txaReason->setStyleSheet("border-color:#0AA8FB");
            m_txaReason->setFocus();
            m_txaReason->selectAll();
            setTextEditPaletteColor(m_txaReason, "#0AA8FB", "#FFFFFF");
        }
    }
}

void IGSxGUIxPendingParametersSaveScreenEventHandler::handleReturnKeyPress()
{
    if (m_gbxSave->hasFocus()) {
        m_pendingParametersSaveScreenCallBack->saveButtonPressedOnPendingParamFinalSaveScreen();
        m_gbxSave->setStyleSheet("QGroupBox{border:none}");
        m_leName->setStyleSheet("border-color:#0AA8FB");
    } else if (m_btnCancel->hasFocus()){
        m_pendingParametersSaveScreenCallBack->cancelButtonPressedOnPendingParamFinalSaveScreen();
        m_btnCancel->setStyleSheet("border:1px solid #0AA8FB");
        m_leName->setStyleSheet("border-color:#0AA8FB");
    }
}


void IGSxGUIxPendingParametersSaveScreenEventHandler::focusNextWidget()
{
    if (m_leName->hasFocus()) {
        m_leName->setStyleSheet("border-color:#AAAAAA");
        m_txaReason->setStyleSheet("border-color:#0AA8FB");
        m_txaReason->setFocus();
        m_txaReason->selectAll();
        setTextEditPaletteColor(m_txaReason, "#0AA8FB", "#FFFFFF");
    } else if (m_txaReason->hasFocus()) {
        m_txaReason->setStyleSheet("border-color:#AAAAAA");
        setTextEditPaletteColor(m_txaReason, "#ffffff", "#000000");
        if (m_gbxSave->isEnabled()) {
            m_gbxSave->setStyleSheet("QGroupBox{border: 2px dotted #1B3E93}");
            m_gbxSave->setFocus();
        } else {
            m_btnCancel->setStyleSheet("border: 2px dotted #1B3E93");
            m_btnCancel->setFocus();
        }
    } else if (m_gbxSave->hasFocus()) {
        m_gbxSave->setStyleSheet("QGroupBox{border:none}");
        m_btnCancel->setStyleSheet("border: 2px dotted #1B3E93");
        m_btnCancel->setFocus();
    } else if (m_btnCancel->hasFocus()){
        m_btnCancel->setStyleSheet("border:1px solid #0AA8FB");
        m_leName->setStyleSheet("border-color:#0AA8FB");
        m_leName->setFocus();
        m_leName->selectAll();
    }
}

void IGSxGUIxPendingParametersSaveScreenEventHandler::handleMouseClick()
{
    if (m_leName->hasFocus()) {
        m_leName->setStyleSheet("border-color:#0AA8FB");
        m_txaReason->setStyleSheet("border-color:#AAAAAA");
        m_gbxSave->setStyleSheet("QGroupBox{border:none}");
        m_btnCancel->setStyleSheet("border:1px solid #0AA8FB");
        setTextEditPaletteColor(m_txaReason, "#ffffff", "#000000");
    } else if (m_txaReason->hasFocus()) {
        m_leName->setStyleSheet("border-color:#AAAAAA");
        m_txaReason->setStyleSheet("border-color:#0AA8FB");
        m_gbxSave->setStyleSheet("QGroupBox{border:none}");
        m_btnCancel->setStyleSheet("border:1px solid #0AA8FB");
        setTextEditPaletteColor(m_txaReason, "#0AA8FB", "#FFFFFF");
    }
}


void IGSxGUIxPendingParametersSaveScreenEventHandler::setTextEditPaletteColor(QTextEdit *textEdit, std::string highlightColor, std::string highlightedTextColor)
{
    QPalette qPa = textEdit->palette();
    QString qHighlightColor = QString::fromStdString(highlightColor);
    QString qHighlightedTextColor = QString::fromStdString(highlightedTextColor);
    qPa.setColor(QPalette::Highlight, QColor(qHighlightColor));
    qPa.setColor(QPalette::HighlightedText, QColor(qHighlightedTextColor));
    textEdit->setPalette(qPa);
}
