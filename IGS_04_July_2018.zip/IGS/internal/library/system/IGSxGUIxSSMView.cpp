/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMView.cpp
| Author       : Saket K
| Description  : Implementation of SSM view
|
| ! \file        IGSxGUIxSSMView.cpp
| ! \brief       Implementation of SSM view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIDialog.h>

#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/regex.hpp>
#include <string>
#include "IGSxGUIxISSMView.hpp"
#include "IGSxGUIxSSMView.hpp"
#include "IGSxGUIxSSMTabView.hpp"

#include "IGSxGUIxMoc_SSMView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxCore/SUIResourcePath.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::SSMView::SYSTEMSTATEMANAGER_VIEW_LOAD_FILE = "IGSxGUIxSSMBase.xml";
const std::string IGSxGUI::SSMView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";

IGSxGUI::SSMView::SSMView(SSMManager& ssmManager):
    sui(new SUI::SSMView),
    m_SSMPresenter(NULL),
    m_SSMManager(ssmManager),
    currentContainer(NULL),
    m_Tab1(new IGSxGUI::SSMTabView(ssmManager, TAB_1)),
    m_Tab2(new IGSxGUI::SSMTabView(ssmManager, TAB_2)),
    m_Tab3(new IGSxGUI::SSMTabView(ssmManager, TAB_3)),
    m_Tab4(new IGSxGUI::SSMTabView(ssmManager, TAB_4)),
    m_Tab5(new IGSxGUI::SSMTabView(ssmManager, TAB_5)),
    m_Tab6(new IGSxGUI::SSMTabView(ssmManager, TAB_6)),
    m_currentTab(TAB_1)
{
      m_SSMPresenter = new IGSxGUI::SSMPresenter(*this, ssmManager);
      m_SSMManager.update = boost::bind(&IGSxGUI::SSMView::update, this);
      m_SSMManager.updateTabIcon = boost::bind(&IGSxGUI::SSMView::setTabIcon, this);
}

SUI::Container* IGSxGUI::SSMView::getContainer()
{
    return currentContainer;
}

void IGSxGUI::SSMView::setActive(bool bActive)
{
    m_Active = bActive;
    m_Tab1->setActive(bActive);
    m_Tab2->setActive(bActive);
    m_Tab3->setActive(bActive);
    m_Tab4->setActive(bActive);
    m_Tab5->setActive(bActive);
    m_Tab6->setActive(bActive);
}

void IGSxGUI::SSMView::indexChanged(int index)
{
    showTab(static_cast<TabType>(index));
}

void IGSxGUI::SSMView::showTab(TabType tab)
{
    m_currentTab = tab;
    switch(tab)
    {
    case TAB_1:
        m_Tab1->show(containers[m_currentTab], true);
        break;
    case TAB_2:
        m_Tab2->show(containers[m_currentTab], true);
        break;
    case TAB_3:
        m_Tab3->show(containers[m_currentTab], true);
        break;
    case TAB_5:
        m_Tab4->show(containers[m_currentTab], true);
        break;
    case TAB_4:
        m_Tab5->show(containers[m_currentTab], true);
        break;
    case TAB_6:
        m_Tab6->show(containers[m_currentTab], true);
        break;
    }


}

IGSxGUI::SSMView::~SSMView()
{
    delete m_Tab6;
    m_Tab6 = NULL;

    delete m_Tab5;
    m_Tab5 = NULL;

    delete m_Tab4;
    m_Tab4 = NULL;

    delete m_Tab3;
    m_Tab3 = NULL;

    delete m_Tab2;
    m_Tab2 = NULL;

    delete m_Tab1;
    m_Tab1 = NULL;

    delete m_SSMPresenter;
    m_SSMPresenter = NULL;


}

void IGSxGUI::SSMView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if(!m_Active)
    {
        sui->setupSUIContainer(SYSTEMSTATEMANAGER_VIEW_LOAD_FILE.c_str(), MainScreenContainer);

        for(int functionIndex = 0 ; functionIndex < m_SSMManager.getFunctionCount(); ++functionIndex)
        {
              sui->tabWidget->getTabPage(functionIndex)->setTabText(m_SSMManager.getFunctionName(functionIndex));
        }

        sui->tabWidget->currentIndexChanged = boost::bind(&SSMView::indexChanged, this, _1);
        sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
        refreshContainers();
        resetAllTabs();
        setTabIcon();
        showTab(TAB_1);
    }
}

void IGSxGUI::SSMView::refreshContainers()
{
    containers.clear();
    containers.push_back(sui->container1);
    containers.push_back(sui->container2);
    containers.push_back(sui->container3);
    containers.push_back(sui->container4);
    containers.push_back(sui->container5);
    containers.push_back(sui->container6);
}

void IGSxGUI::SSMView::resetAllTabs()
{
    m_Tab1->reset();
    m_Tab2->reset();
    m_Tab3->reset();
    m_Tab4->reset();
    m_Tab5->reset();
    m_Tab6->reset();
}

void IGSxGUI::SSMView::update()
{
    if(m_Active)
    {
        setTabIcon();
        showTab(TAB_1);
    }
}

void IGSxGUI::SSMView::setTabIcon()
{
    for(int functionIndex = 0 ; functionIndex < m_SSMManager.getFunctionCount(); ++functionIndex)
    {
        if(m_SSMManager.isTransitionActive(functionIndex))
        {
            Util::setIconTabHeader(sui->tabWidget, functionIndex, TabPageIcon::Transition);
        }
        else if(m_SSMManager.isFunctionResultOk(functionIndex) == true)
        {
            Util::setIconTabHeader(sui->tabWidget, functionIndex, TabPageIcon::NoIcon);
        }
        else
        {
            Util::setIconTabHeader(sui->tabWidget, functionIndex, TabPageIcon::Error);
        }
    }
}
