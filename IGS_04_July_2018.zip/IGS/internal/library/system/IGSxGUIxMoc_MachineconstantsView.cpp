

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.cpp
| ! \brief       Implementation of Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMoc_MachineconstantsView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::MachineconstantsView::MachineconstantsView() :
    dialog(NULL),
    btnParameterName(NULL),
    btnParameterValue(NULL),
    lblPendingParameters(NULL),
    btnNoPendingParameters(NULL),
    btnHistory(NULL),
    btnPendingParameterName(NULL),
    btnPendingParameterValue(NULL),
    btnPendingParametersLine(NULL),
    tawParameters(NULL),
    lneSearchParameterText(NULL),
    btnSearchAndClearIcon(NULL),
    lblEntriesFound(NULL),
    uctSaveButton(NULL),
    lblSaveImage(NULL),
    lblSaveText(NULL),
    scbParametersTable(NULL),
    imvLogo(NULL),
    lblPendingParamSaveName(NULL),
    lnePendingParamSaveName(NULL),
    lblPendingParamSaveChangeReason(NULL),
    txaPendingParamSaveChangeReason(NULL),
    btnPendingParamCancelSave(NULL),
    uctPendingParamFinalSave(NULL),
    lblPendingParamFinalSaveImage(NULL),
    lblPendingParamFinalSaveText(NULL),
    gbxPendingParamFinalSaveButton(NULL),
    lblPendingParamSaveChangeReasonTxtArea(NULL),
    lblPendingParamSaveNameLnEdit(NULL),
    btnPendingParamSaveNameLnEditCancel(NULL),
    lblAllCategories(NULL),
    lblBackImage(NULL),
    btnBack(NULL),
    btnBC1(NULL),
    btnBC2(NULL),
    btnBC3(NULL),
    btnBC4(NULL),
    btnBC5(NULL),
    btnBC6(NULL),
    lblBackSlash1(NULL),
    lblBackSlash2(NULL),
    lblBackSlash3(NULL),
    lblBackSlash4(NULL),
    lblBackSlash5(NULL),
    gbxBI(NULL),
    gbxPendingParamSaveError(NULL),
    lblPendingParamSaveErrorTitle(NULL),
    lblPendingParamSaveErrorMessage(NULL),
    lblPendingParamErrorCloseImage(NULL),
    lblPendingParamErrorCrossImage(NULL),
    btnCancelPendingParamSave(NULL),
    btnRetryPendingParamSave(NULL),
    bicPendingParamFinalSave(NULL),
    btnParameterName2(NULL),
    gbxParamName(NULL),
    btnParameterNameDownArrow(NULL),
    btnParameterNameUpArrow(NULL),
    gbxPendingParamName(NULL),
    btnPendingParameterNameDownArrow(NULL),
    btnPendingParameterNameUpArrow(NULL),
    btnPendingParameterNameUpDownArrow(NULL)
{
}

void SUI::MachineconstantsView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::MachineconstantsView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::MachineconstantsView::loadObjects(ObjectList* objectList)
{
    gbxPageOne = objectList->getObject<GroupBox>("gbxPageOne");
    btnParameterName =  objectList->getObject<Button>("btnParameterName");
    btnParameterValue = objectList->getObject<Button>("btnParameterValue");
    tawParameters = objectList->getObject<TableWidget>("tawParameters");
    lneSearchParameterText = objectList->getObject<LineEdit>("lneSearchParameterText");
    btnSearchAndClearIcon = objectList->getObject<Button>("btnSearchAndClearIcon");
    lblEntriesFound = objectList->getObject<Label>("lblEntriesFound");
    scbParametersTable = objectList->getObject<ScrollBar>("scbParametersTable");
    imvLogo = objectList->getObject<GraphicsView>("imvLogo");
    btnCancel = objectList->getObject<Button>("btnCancel");
    uctSaveButton = objectList->getObject<UserControl>("uctSaveButton");
    lblSaveImage = objectList->getObject<Label>("uctSaveButton:lblSaveImage");
    lblSaveText = objectList->getObject<Label>("uctSaveButton:lblSaveText");
    gbxSaveButton = objectList->getObject<GroupBox>("uctSaveButton:gbxSaveButtonUCT");
    lblPendingParameters = objectList->getObject<Label>("lblPendingParameters");
    btnNoPendingParameters = objectList->getObject<Button>("btnNoPendingParameters");
    btnHistory = objectList->getObject<Button>("btnHistory");
    btnPendingParameterName =  objectList->getObject<Button>("btnPendingParameterName");
    btnPendingParameterValue = objectList->getObject<Button>("btnPendingParameterValue");
    btnPendingParametersLine = objectList->getObject<Button>("btnPendingParametersLine");
    tawMCPendingParam = objectList->getObject<TableWidget>("tawMCPendingParam");
    lblPendingParamSaveName = objectList->getObject<Label>("lblPendingParamSaveName");
    lnePendingParamSaveName = objectList->getObject<LineEdit>("lnePendingParamSaveName");
    lblPendingParamSaveChangeReason = objectList->getObject<Label>("lblPendingParamSaveChangeReason");
    txaPendingParamSaveChangeReason = objectList->getObject<TextArea>("txaPendingParamSaveChangeReason");
    btnPendingParamCancelSave = objectList->getObject<Button>("btnPendingParamCancelSave");
    uctPendingParamFinalSave = objectList->getObject<UserControl>("uctPendingParamFinalSave");
    lblPendingParamFinalSaveImage = objectList->getObject<Label>("uctPendingParamFinalSave:lblSaveImage");
    lblPendingParamFinalSaveText = objectList->getObject<Label>("uctPendingParamFinalSave:lblSaveText");
    gbxPendingParamFinalSaveButton = objectList->getObject<GroupBox>("uctPendingParamFinalSave:gbxSaveButtonUCT");
    lblPendingParamSaveChangeReasonTxtArea = objectList->getObject<Label>("lblPendingParamSaveChangeReasonTxtArea");
    lblPendingParamSaveNameLnEdit = objectList->getObject<Label>("lblPendingParamSaveNameLnEdit");
    btnPendingParamSaveNameLnEditCancel = objectList->getObject<Button>("btnPendingParamSaveNameLnEditCancel");
    tawParameterTree = objectList->getObject<TableWidget>("tawParameterTree");
    lblAllCategories = objectList->getObject<Label>("lblAllCategories");
    lblBackImage = objectList->getObject<Label>("lblBackImage");
    btnBack = objectList->getObject<Button>("btnBack");

    btnBC1 = objectList->getObject<Button>("btnBC1");
    btnBC2 = objectList->getObject<Button>("btnBC2");
    btnBC3 = objectList->getObject<Button>("btnBC3");
    btnBC4 = objectList->getObject<Button>("btnBC4");
    btnBC5 = objectList->getObject<Button>("btnBC5");
    btnBC6 = objectList->getObject<Button>("btnBC6");

    lblBackSlash1 = objectList->getObject<Label>("lblBackSlash1");
    lblBackSlash2 = objectList->getObject<Label>("lblBackSlash2");
    lblBackSlash3 = objectList->getObject<Label>("lblBackSlash3");
    lblBackSlash4 = objectList->getObject<Label>("lblBackSlash4");
    lblBackSlash5 = objectList->getObject<Label>("lblBackSlash5");

    bicPendingParamFinalSave = objectList->getObject<BusyIndicator>("bicPendingParamFinalSaveImage");
    gbxBI = objectList->getObject<GroupBox>("gbxBI");
    gbxPendingParamSaveError = objectList->getObject<GroupBox>("gbxPendingParamSaveError");
    lblPendingParamSaveErrorTitle = objectList->getObject<Label>("lblPendingParamSaveErrorTitle");
    lblPendingParamSaveErrorMessage = objectList->getObject<Label>("lblPendingParamSaveErrorMessage");
    lblPendingParamErrorCloseImage = objectList->getObject<Label>("lblPendingParamErrorCloseImage");
    lblPendingParamErrorCrossImage = objectList->getObject<Label>("lblPendingParamErrorCrossImage");
    btnCancelPendingParamSave = objectList->getObject<Button>("btnCancelPendingParamSave");
    btnRetryPendingParamSave = objectList->getObject<Button>("btnRetryPendingParamSave");
    btnParameterName2 =  objectList->getObject<Button>("btnParameterName2");
    gbxParamName = objectList->getObject<GroupBox>("gbxParamName");
    btnParameterNameDownArrow =  objectList->getObject<Button>("btnParameterNameDownArrow");
    btnParameterNameUpArrow =  objectList->getObject<Button>("btnParameterNameUpArrow");
    gbxPendingParamName = objectList->getObject<GroupBox>("gbxPendingParamName");
    btnPendingParameterNameDownArrow =  objectList->getObject<Button>("btnPendingParameterNameDownArrow");
    btnPendingParameterNameUpArrow =  objectList->getObject<Button>("btnPendingParameterNameUpArrow");
    btnPendingParameterNameUpDownArrow =  objectList->getObject<Button>("btnPendingParameterNameUpDownArrow");
}
#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP
