/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsManager.cpp
| Author       : Venugopal S
| Description  : Implementation of System Tools Manager
|
| ! \file        IGSxGUIxSystemToolsManager.cpp
| ! \brief       Implementation of System Tools Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemToolsManager.hpp"
#include "IGSxSIF.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::SystemToolsManager::SystemToolsManager(){
}

IGSxGUI::SystemToolsManager::~SystemToolsManager()
{
    // Do not delete m_view, we are not the owner.
}

void IGSxGUI::SystemToolsManager::initialize()
{
    // Later use to initialize the system tools
}

bool IGSxGUI::SystemToolsManager::isMbdsViewerAvailable() const
{
    return IGSxSIF::SIF::getInstance()->isMbdsViewerAvailable();
}

void IGSxGUI::SystemToolsManager::startMbdsViewer() const
{
    IGSxSIF::SIF::getInstance()->startMbdsViewer();
}
