/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPD.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD
|
| ! \file        IGSxGUIxCPD.cpp
| ! \brief       Implementation of CPD
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxCPD.hpp"
#include "IGSxCPD.hpp"
#include "IGSxCOMMON.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::CPD::CPD(const IGSxCPD::MetaDescription& metaDescription):
    m_name(metaDescription.name()),
    m_subsystem(metaDescription.subSystem()),
    m_description(metaDescription.description()),
    m_htmlFile(metaDescription.htmlFile()),
    m_testType(metaDescription.testType())
{    
}

IGSxGUI::CPD::~CPD()
{    
}

std::string IGSxGUI::CPD::getName() const
{
   return m_name;
}

std::string IGSxGUI::CPD::getDescription() const
{
   return m_description;
}

std::string IGSxGUI::CPD::getSubsystem() const
{
   return m_subsystem;
}

std::string IGSxGUI::CPD::getHtmlFile() const
{
   return m_htmlFile;
}

std::string IGSxGUI::CPD::getTestType() const
{
   return m_testType;
}

bool IGSxGUI::CPD::start()
{
   try
   {
       IGSxCPD::CPD::getInstance()->startTest(getName());
   } catch (IGS::Exception& /*ex*/) {
       // ToDo, determine what to do.
   }
   return true;
}

bool IGSxGUI::CPD::onStopped(IGS::Result result)
{
    if (!cpdStopped.empty())
    {
        cpdStopped(this->getName(),result);
    }
    return true;
}

boost::signals2::connection IGSxGUI::CPD::registerToCPDStopped(const stoppedCallback &cb)
{
    return cpdStopped.connect(cb);

}
