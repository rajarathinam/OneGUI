/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.cpp
| Author       : Venugopal S
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxCPDManager.cpp
| ! \brief       CPD Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxCPDManager.hpp"
#include "IGSxCOMMON.hpp"
#include "IGSxCPD.hpp"
#include <algorithm>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::CPDManager::CPDManager()
{    
}

IGSxGUI::CPDManager::~CPDManager()
{
    try
    {
        IGSxCPD::CPD::getInstance()->unsubscribeToTestStopped();
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }

    for (std::vector<CPD*>::iterator it = m_CPDs.begin() ; it != m_CPDs.end(); ++it)
    {
        delete (*it);
    }
    m_CPDs.clear();
}

void IGSxGUI::CPDManager::initialize()
{
    IGSxCPD::MetaDescriptions metaDescriptions;

    try
    {
        IGSxCPD::CPD::getInstance()->getTests(metaDescriptions);
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }

    for (size_t i = 0; i < metaDescriptions.size(); i++)
    {
        CPD* cpd = new CPD(metaDescriptions[i]);
        add(cpd);
    }

    try
    {
        IGSxCPD::CPD::getInstance()->subscribeToTestStopped(boost::bind(&CPDManager::onStopped, this, _1));
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }
}

void IGSxGUI::CPDManager::add(CPD* cpd)
{
    m_CPDs.push_back(cpd);
}

void IGSxGUI::CPDManager::remove(CPD* cpd)
{
    m_CPDs.erase(std::remove(m_CPDs.begin(), m_CPDs.end(), cpd), m_CPDs.end());

    delete cpd;
}

IGSxGUI::CPD *IGSxGUI::CPDManager::getCPD(const std::string &name) const
{
    CPD* cpd = NULL;

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (m_CPDs[i]->getName() == name)
        {
            cpd = m_CPDs[i];
            break;
        }
    }
    return cpd;
}

std::vector<IGSxGUI::CPD*> IGSxGUI::CPDManager::retrieveAll()
{
    return m_CPDs;
}

void IGSxGUI::CPDManager::onStopped(IGS::Result result)
{
    retrieveRunningCPD()->onStopped(result);
}

IGSxGUI::CPD *IGSxGUI::CPDManager::retrieveRunningCPD()
{
    std::string currentTest;
    try
    {
        currentTest = IGSxCPD::CPD::getInstance()->getCurrentTest();
    } catch (IGS::Exception& /*ex*/) {
        // ToDo, determine what to do.
    }

    for (size_t i = 0; i < m_CPDs.size(); i++)
    {
        if (currentTest == m_CPDs[i]->getName())
        {
            return m_CPDs[i];
        }
    }
    return NULL;
}















