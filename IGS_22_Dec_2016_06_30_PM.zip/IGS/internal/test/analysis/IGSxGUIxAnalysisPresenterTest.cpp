/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenterTest.cpp
| Author       : Venugopal S
| Description  : Implementation of Advanced Diagnostics Presenter test
|
| ! \file        IGSxGUIxAdvancedDiagnosticsPresenterTest.cpp
| ! \brief       Implementation of Advanced Diagnostics Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAnalysisPresenterTest.hpp"
#include "IGSxGUIxIAnalysisView.hpp"
#include "IGSxGUIxAnalysisView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(AnalysisPresenterTest, Test1)
{
    IGSxGUI::ADTManager* adtMgr = new IGSxGUI::ADTManager();


    adtMgr->initialize();



    IGSxGUI::AnalysisPresenter* presenter = new IGSxGUI::AnalysisPresenter(NULL);

    vector<IGSxGUI::ADT*> adts = presenter->getADTs();


    EXPECT_EQ(adts.size(), 12);


    delete presenter;
    delete adtMgr;

}


