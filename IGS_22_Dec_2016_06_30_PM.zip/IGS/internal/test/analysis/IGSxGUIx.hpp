/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenterTest.hpp
| Author       : Venugopal S
| Description  : Header file for Advanced Diagnostics Presenter test
|
| ! \file        IGSxGUIxAdvancedDiagnosticsPresenterTest.hpp
| ! \brief       Header file for Advanced Diagnostics Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIX_ADVANCED_DIAGNOSTICS_PRESENTER_TEST_HPP
#define IGSXGUIX_ADVANCED_DIAGNOSTICS_PRESENTER_TEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxAnalysisPresenter.hpp"

using std::vector;
using std::list;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
template<typename T>
    ::testing::AssertionResult VectorsMatch(vector<T> Expected, vector<T> Actual)
{
        for (int i=0; i < Expected.size(); i++)
        {
            if (Expected.at(i)->getName().compare(Actual.at(i)->getName()) != 0)
            {
                return ::testing::AssertionFailure();
            }
        }
        return ::testing::AssertionSuccess();
}

template<typename T>
    ::testing::AssertionResult ListMatch(list<T> Expected, list<T> Actual)
{
        while ((!Expected.empty()) && (!Actual.empty()))
        {
            if (Expected.front().compare(Actual.front()) != 0)
            {
                return ::testing::AssertionFailure();
            }
            Expected.pop_front();
            Actual.pop_front();
        }
        return ::testing::AssertionSuccess();
}

class AnalysisPresenterTest : public ::testing::Test
{
 public:
  AnalysisPresenterTest(){}
  virtual ~AnalysisPresenterTest(){}
 protected:
  /*MetaDescriptions Drivers;
  MetaDescriptions Sysfunctions;*/
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
      /*Drivers.push_back(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"));
      Drivers.push_back(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"));
      Drivers.push_back(MetaDescription("SSD HPRGA", "SSD HPRGA"));
      Drivers.push_back(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"));
      Drivers.push_back(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"));

      Sysfunctions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
      Sysfunctions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
      Sysfunctions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
      Sysfunctions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
      Sysfunctions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
      Sysfunctions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));*/
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIX_ADVANCED_DIAGNOSTICS_PRESENTER_TEST_HPP
