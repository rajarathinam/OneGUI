/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGS_Timer.cpp
| Author       : Thijs Jacobs
| Description  : Impementation of Timer
|
| ! \file        IGS_Timer.cpp
| ! \brief       Impementation of Timer
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <unistd.h>
#include "IGSTimer.hpp"

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int MS_IN_SEC = 1000;
const int US_IN_MS = 1000;

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGS::Timer::Timer() :
  m_interval(MS_IN_SEC),  // 1 s
  m_elapsedTime(0),
  m_singleShot(false),
  m_quit(true),
  m_callback(NULL)
{
}

IGS::Timer::~Timer()
{
    stop();
}

void IGS::Timer::start()
{
    if (!m_quit)
    {
        stop();
    }
    pthread_create(&m_thread, NULL, runFunc, this);
}

void IGS::Timer::stop()
{
    m_quit = true;
    pthread_join(m_thread, NULL);
}

void *IGS::Timer::runFunc(void *This)
{
    (static_cast<IGS::Timer*>(This))->run();
    return NULL;
}

void IGS::Timer::run()
{
    m_quit = false;
    while (!m_quit)
    {
        usleep(m_interval * US_IN_MS);  // micro seconds
        m_elapsedTime += m_interval;
        if (m_callback)
        {
            m_callback();
        }
    }
    m_elapsedTime = 0;
}

