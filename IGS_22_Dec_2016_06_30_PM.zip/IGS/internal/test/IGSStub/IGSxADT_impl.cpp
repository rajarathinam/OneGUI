/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADT_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxADT interface
|
| ! \file        IGSxADT_impl.cpp
| ! \brief       Stub impementation of IGSxADT interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxADT_impl.hpp"
#include <iostream>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    std::string name;
    std::string subsystem;
    std::string description;
    std::string descriptionFile;
} gMetaType;

gMetaType gADT[] = {
    {"Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html"},
    {"Collector Cooling", "Environmental control", "Collector Cooling ADT", "/usr/local/msc/config/ADT//CCD_CCS.html"},
    {"Droplet Generation Control ADT", "Tin Management", "ADT Droplet Generator Controls", "/usr/local/msc/config/ADT//DGD_CCS.html"},
    {"Final Focus Metrology", "Laser Light Generation and Positioning", "Final Focus Metrology ADT", "/usr/local/msc/config/ADT//LEF_FFA.html"},
    {"GVA", "Gas and vacuum", "GVA ADT", "/usr/local/msc/config/ADT//GVA.html"},
    {"HP-RGA", "Environmental control", "HP-RGA ADT", "/usr/local/msc/config/ADT//RCA_RCM.html"},
    {"Heated Tin Vanes Bucket", "Tin Mitigation", "The ADT of the Heated Tin Vanes Bucket (HTVB)", "/usr/local/msc/config/ADT//VDT_DCR.html"},
    {"Plasma Control", "Plasma Generation and Energy Control", "Plasma Control ADT", "/usr/local/msc/config/ADT//PDH_PCL.html"},
    {"Real Time Streaming", "Generic Diagnostics", "The ADT for Real Time data Streaming", "/usr/local/msc/config/ADT//FDS_FAC.html"},
    {"Timing and Energy Control", "Plasma Generation and Energy Control", "Timing and Energy Control (TEC) ADT", "/usr/local/msc/config/ADT//TIA.html"},
    {"Vanes Manual Thermal Cycling", "Tin Mitigation", "ADT for the manual thermal cycling of the vanes", "/usr/local/msc/config/ADT//VDA_Mtc.html"},
    {"Vessel Cooling", "Environmental control", "Vessel Cooling ADT", "/usr/local/msc/config/ADT//CCT.html"}
};
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxADT::ADT *IGSxADT::ADT_Stub::getInstance()
{
    static ADT_Stub _instance;
    return &_instance;
}

IGSxADT::ADT* IGSxADT::ADT::instance = IGSxADT::ADT_Stub::getInstance();

IGSxADT::ADT_Stub::ADT_Stub()
{
}

void IGSxADT::ADT_Stub::getAdts(MetaDescriptions& adts)
{
    for (size_t i = 0; i < sizeof(gADT) / sizeof(*gADT); i++)
    {
        gMetaType* adt = &gADT[i];
        adts.push_back(MetaDescription(adt->name, adt->subsystem, adt->description, adt->descriptionFile));
    }
}

void IGSxADT::ADT_Stub::startAdt(const std::string &adtName)
{
    std::cerr << "Adt : " << adtName << " started" << std::endl;
}


