
/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIMachineconstantsView.hpp
| Author       : Raja
| Description  : Interface file for Machineconstants View
|
| ! \file        IGSxGUIxICPDView.hpp
| ! \brief       Interface file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{

class MachineconstantsView : public IMachineconstantsView
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const std::string&, const IGS::Result& /*result*/);
    virtual void setActive(bool);

 private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);
    void init();

    SUI::MachineconstantsView *sui;

    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;

};
}  // namespace IGSxGUI
#endif // IGSXGUIXMACHINECONSTANTSVIEW_HPP
