/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlert.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert
|
| ! \file        IGSxGUIxAlert.cpp
| ! \brief       Implementation of Alert
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxAlert.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Alert::Alert(const IGSxERR::ActivatedAlert& alert) :
    m_alert(alert),
    m_isNew(true)
{
}

IGSxGUI::Alert::~Alert()
{
}

int IGSxGUI::Alert::getLogId() const
{
    return m_alert.logId();
}

std::string IGSxGUI::Alert::getLogCode() const
{
    return m_alert.logCode();
}

time_t IGSxGUI::Alert::getTime() const
{
    return m_alert.time();
}

IGSxERR::AlertSeverity::AlertSeverityEnum IGSxGUI::Alert::getSeverity() const
{
    return m_alert.severity();
}

std::string IGSxGUI::Alert::getUserText() const
{
    return m_alert.userText();
}

std::string IGSxGUI::Alert::getDeveloperText() const
{
    return m_alert.developerText();
}

void IGSxGUI::Alert::setNew(bool val)
{
    m_isNew = val;
}

bool IGSxGUI::Alert::isNew() const
{
    return m_isNew;
}
