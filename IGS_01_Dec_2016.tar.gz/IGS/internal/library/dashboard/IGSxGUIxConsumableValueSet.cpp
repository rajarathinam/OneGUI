/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxConsumableValueSet.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of Consumable ValueSet
|
| ! \file        IGSxGUIxConsumableValueSet.cpp
| ! \brief       Implementation of Consumable ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxConsumable.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::ConsumableValueSet::ConsumableValueSet(const IGSxKPI::KPIValueSetDefinition &consumableDefinition):
    m_name(consumableDefinition.name()),
    m_desc(consumableDefinition.description()),
    m_unit(consumableDefinition.unit()),
    m_time(0),
    m_valueList(0,0)
{
}

IGSxGUI::ConsumableValueSet::~ConsumableValueSet()
{
}

string IGSxGUI::ConsumableValueSet::getName() const
{
    return m_name;
}

string IGSxGUI::ConsumableValueSet::getDescription() const
{
    return m_desc;
}

string IGSxGUI::ConsumableValueSet::getUnit() const
{
    return m_unit;
}

void IGSxGUI::ConsumableValueSet::addValue(vector<double>* valueList)
{
    m_valueList.clear();
    for(size_t i = 0; i < valueList->size(); i++)
    {
        m_valueList.push_back(valueList->at(i));
    }
}

void IGSxGUI::ConsumableValueSet::addTime(time_t time)
{
    m_time = time;
}

vector<double> IGSxGUI::ConsumableValueSet::getValue()
{
    return m_valueList;
}

time_t IGSxGUI::ConsumableValueSet::getTime()
{
    return m_time;
}


