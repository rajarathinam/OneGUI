/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Main application Presenter
|
| ! \file        IGSxGUIxMainPresenter.hpp
| ! \brief       Header file for Main application Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMAINPRESENTER_HPP
#define IGSXGUIXMAINPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxIMainView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class MainPresenter
{
 public:
    explicit MainPresenter(IGSxGUI::IMainView* view);
    virtual ~MainPresenter();
    void OnErrorStateChange(const std::string& eMsg);
 private:
    std::string getTimeStamp() const;

    IGSxGUI::IMainView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMAINPRESENTER_HPP
