/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxADTStubTest.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxADT Stub test
|
| ! \file        IGSxADTStubTest.hpp
| ! \brief       Header file for IGSxADT Stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXADTSTUBTEST_HPP
#define IGSXADTSTUBTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include "IGSxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class IGSxADTStubTest : public ::testing::Test
{
 public:
  IGSxADTStubTest(){}
  virtual ~IGSxADTStubTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXADTSTUBTEST_HPP
