/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPD_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxCPD interface
|
| ! \file        IGSxCPD_impl.cpp
| ! \brief       Stub impementation of IGSxCPD interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxCPD_impl.hpp"
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    std::string name;
    std::string testType;
    std::string description;
    std::string descriptionFile;
    std::string subsystem;
} gMetaType;

gMetaType gCPD[] = {
    {"CPDFFMDFC","Calibration","CPD FFM Default Filter Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMDFC/CPDFFMDFC_description.html","FinalFocusMetrology"},
    {"CPD_CODMCL","Performance","Collector and Metrology Cleaning CPD","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPD_CODMCL/CPD_CODMCL_description.html","Cleaning"},
    {"CPDDGSABC","Calibration","DGS Actuator Basis Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSABC/CPDDGSABC_description.html","DropletGeneratorSteering"},
    {"LDN_HPSNLC","Diagnostics","LDN_HPSNLC test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LDN_HPSNLC/LDN_HPSNLC_description.html","HighPowerSeed"},
    {"CPDDGSESI","Diagnostics","DGSS Encoder Loop System Identification","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSESI/CPDDGSESI_description.html","DropletGeneratorSteering"},
    {"FDD_DUMREG","Calibration","FDD_DUMREG test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/FDD_DUMREG/FDD_DUMREG_description.html","FinalFocusAssembly"},
    {"LQR_LBQRUP","Calibration","LQR_LBQRUP test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LQR_LBQRUP/LQR_LBQRUP_description.html","LaserBeamQuality"},
    {"CPDTEMPLATE","Calibration","CPDTEMPLATE","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDTEMPLATE/CPDTEMPLATE_description.html","DropletGeneratorSteering"},
    {"CPDFFASOC","Calibration","M120 Sensor Calibration Offset","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFASOC/CPDFFASOC_description.html","FinalFocusAssembly"},
    {"CPDDGSEHO","Calibration","Encoder Home Offset Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSEHO/CPDDGSEHO_description.html","DropletGeneratorSteering"},
    {"CPDDGSCSI","Diagnostics","Camera-loop System ID","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSCSI/CPDDGSCSI_description.html","DropletGeneratorSteering"},
    {"PMY_PCLYZM","Diagnostics","YZT-map Expert Version","ftp://msc:msc@192.168.4.11//usr/local/msc/script/PMY_PCLYZM/PMY_PCLYZM_description.html","PlasmaControl"},
    {"CPDFFARMF","Performance","Range and Motor Force Verification","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFARMF/CPDFFARMF_description.html","FinalFocusAssembly"},
    {"CPDFFMQCC","Calibration","FFM Quad Cell Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMQCC/CPDFFMQCC_description.html","FinalFocusMetrology"},
    {"CPDDUMMY","Calibration","CPDDUMMY test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDUMMY/CPDDUMMY_description.html","FinalFocusAssembly"},
    {"DDW_DGNWSC","Diagnostics","DG Swap CPD","ftp://msc:msc@192.168.4.11//usr/local/msc/script/DDW_DGNWSC/DDW_DGNWSC_description.html","DropletGeneratorSteering"},
    {"PML_PCLMFL","Calibration","Make First Light CPD","ftp://msc:msc@192.168.4.11//usr/local/msc/script/PML_PCLMFL/PML_PCLMFL_description.html","PlasmaControl"},
    {"CPDFFASPM","Performance","CPDFFASPM","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFASPM/CPDFFASPM_description.html","FinalFocusAssembly"},
    {"CPDDGSCSP","Performance","Camera Settling Performance","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSCSP/CPDDGSCSP_description.html","DropletGeneratorSteering"},
    {"CPDDGSDST","Performance","DGSS Droplet Stability Test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSDST/CPDDGSDST_description.html","DropletGeneratorSteering"},
    {"CPDFFARMF_LMC","Performance","Range and Motor Force LMC Verification","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFARMF_LMC/CPDFFARMF_LMC_description.html","FinalFocusAssembly"},
    {"ECE_ECAETI","Calibration","ESM EUV Timings Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/ECE_ECAETI/ECE_ECAETI_description.html","EnergyControl"},
    {"LCD_FFAFRF_LMC","Performance","Frequency Response Function","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LCD_FFAFRF_LMC/LCD_FFAFRF_LMC_description.html","FinalFocusAssembly"},
    {"LDH_HPSHCC","Calibration","LDH_HPSHCC test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LDH_HPSHCC/LDH_HPSHCC_description.html","HighPowerSeed"},
    {"LCF_FFAMDC","Calibration","FFA M120 Decoupling Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LCF_FFAMDC/LCF_FFAMDC_description.html","FinalFocusAssembly"},
    {"PMS_PCLSPD","Calibration","PMS_PCLSPD","ftp://msc:msc@192.168.4.11//usr/local/msc/script/PMS_PCLSPD/PMS_PCLSPD_description.html","PlasmaControl"},
    {"LDL_HPSLHC","Diagnostics","LDL_HPSLHC test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LDL_HPSLHC/LDL_HPSLHC_description.html","HighPowerSeed"},
    {"FPX_BLUPRT","Calibration","FPX_BLUPRT test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/FPX_BLUPRT/FPX_BLUPRT_description.html","FinalFocusAssembly"},
    {"LTA_LCCPEM","Calibration","LTA_LCCPEM test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LTA_LCCPEM/LTA_LCCPEM_description.html","LaserChainControl"},
    {"LTS_LCCDLS","Calibration","LTS_LCCDLS test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LTS_LCCDLS/LTS_LCCDLS_description.html","LaserChainControl"},
    {"CPDFFMPAR","Calibration","FFM Parameters","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMPAR/CPDFFMPAR_description.html","FinalFocusMetrology"},
    {"FPY_INTERA","Calibration","FPY_INTERA Interactive CPD Test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/FPY_INTERA/FPY_INTERA_description.html","FinalFocusAssembly"},
    {"LEG_FFMDIA_LIGHT","Diagnostics","LEG_FFMDIA test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LEG_FFMDIA_LIGHT/LEG_FFMDIA_LIGHT_description.html","FinalFocusMetrology"},
    {"LEG_FFMDIA_DARK","Diagnostics","LEG_FFMDIA test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LEG_FFMDIA_DARK/LEG_FFMDIA_DARK_description.html","FinalFocusMetrology"},
    {"CPDFFASPM_CO2","Performance","CPDFFASPM","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFASPM_CO2/CPDFFASPM_CO2_description.html","FinalFocusAssembly"},
    {"CPDFFACCT","Diagnostics","Cable Connection Test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFACCT/CPDFFACCT_description.html","FinalFocusAssembly"},
    {"CPDFFAPCM","Performance","CPDFFAPCM","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFAPCM/CPDFFAPCM_description.html","FinalFocusAssembly"},
    {"CPDDGSCOC","Calibration","Camera Offset Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSCOC/CPDDGSCOC_description.html","DropletGeneratorSteering"},
    {"CPDDGSHYS","Diagnostics","DGS Hysteresis","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSHYS/CPDDGSHYS_description.html","DropletGeneratorSteering"},
    {"CPDDGSESP","Performance","DGSS Encoder Loop System Performance","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDDGSESP/CPDDGSESP_description.html","DropletGeneratorSteering"},
    {"LQF_LBQFVM","Calibration","FVM performance test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LQF_LBQFVM/LQF_LBQFVM_description.html","LaserBeamQualification"},
    {"LCE_FFABCT","Calibration","CPD FFA Beam Coordinate Transform","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LCE_FFABCT/LCE_FFABCT_description.html","FinalFocusAssembly"},
    {"CPDFFASPM_LMC","Performance","CPDFFASPM","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFASPM_LMC/CPDFFASPM_LMC_description.html","FinalFocusAssembly"},
    {"CPDFFMRCC","Calibration","RBD Camera Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFMRCC/CPDFFMRCC_description.html","FinalFocusMetrology"},
    {"LCD_FFAFRF_CO2","Performance","Frequency Response Function","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LCD_FFAFRF_CO2/LCD_FFAFRF_CO2_description.html","FinalFocusAssembly"},
    {"CPDFFARMF_CO2","Performance","Range and Motor Force Verification CO2","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFARMF_CO2/CPDFFARMF_CO2_description.html","FinalFocusAssembly"},
    {"LEA_FFMBPC","Calibration","Beam Pointing Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/LEA_FFMBPC/LEA_FFMBPC_description.html","FinalFocusMetrology"},
    {"GPO_GVCOTM","Diagnostics","O2 Measurement for H2 Release CPD","ftp://msc:msc@192.168.4.11//usr/local/msc/script/GPO_GVCOTM/GPO_GVCOTM_description.html","GasVacuumControl"},
    {"TCC_TECCIO","Diagnostics","TCC_TECCIO test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/TCC_TECCIO/TCC_TECCIO_description.html","TimingControl"},
    {"CPDFFAOAC","Calibration","Optical Alignment Calibration","ftp://msc:msc@192.168.4.11//usr/local/msc/script/CPDFFAOAC/CPDFFAOAC_description.html","FinalFocusAssembly"},
    {"ECS_ECASSM","Diagnostics","Local Controller State Management test","ftp://msc:msc@192.168.4.11//usr/local/msc/script/ECS_ECASSM/ECS_ECASSM_description.html","EnergyControl"}
};
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxCPD::CPD_Stub::TASK_STOPPING_TIMER_INTERVAL = 5000;

// instance
IGSxCPD::CPD *IGSxCPD::CPD_Stub::getInstance()
{
    static CPD_Stub _instance;
    return &_instance;
}

IGSxCPD::CPD* IGSxCPD::CPD::instance = IGSxCPD::CPD_Stub::getInstance();

IGSxCPD::CPD_Stub::CPD_Stub():
    m_strCurrentTest(""),
    m_timer(SUI::Timer::createTimer()),
    m_testStoppedCallback(NULL)
{
    m_timer->setInterval(TASK_STOPPING_TIMER_INTERVAL);
    m_timer->timeout = boost::bind(&CPD_Stub::on_timeout, this);
}

void IGSxCPD::CPD_Stub::getTests(IGSxCPD::MetaDescriptions &tests)
{
    for (size_t i = 0; i < sizeof(gCPD) / sizeof(*gCPD); i++)
    {
        gMetaType* CPD = &gCPD[i];
        tests.push_back(MetaDescription(CPD->name, CPD->testType, CPD->subsystem, CPD->description, CPD->descriptionFile));
    }
}

std::string IGSxCPD::CPD_Stub::getCurrentTest()
{
    return m_strCurrentTest;
}

void IGSxCPD::CPD_Stub::subscribeToTestStopped(const IGSxCPD::TestStoppedCallback &cb)
{
    m_testStoppedCallback = cb;
}

void IGSxCPD::CPD_Stub::unsubscribeToTestStopped()
{
    if (m_testStoppedCallback)
    {
        m_testStoppedCallback = NULL;
    }
}

void IGSxCPD::CPD_Stub::startTest(const std::string &testName)
{
    m_strCurrentTest = testName;

    std::cerr << "Test : " << m_strCurrentTest << " started" << std::endl;
    m_timer->start();
}

void IGSxCPD::CPD_Stub::on_timeout()
{
    m_timer->stop();

    std::cerr << "Test : " << getCurrentTest() << " stopped" << std::endl;

    //m_strCurrentTest.clear();

    //Commented the above line as
    //CPDManager::retrieveRunningCPD() returns NULL;

    if(!m_testStoppedCallback.empty())
    {
        m_testStoppedCallback(IGS::OK);
    }
}
void IGSxCPD::CPD_Stub::getTestResults(const std::string &testName, time_t startTime, time_t stopTime, TestResultList &testResults)
{

}






