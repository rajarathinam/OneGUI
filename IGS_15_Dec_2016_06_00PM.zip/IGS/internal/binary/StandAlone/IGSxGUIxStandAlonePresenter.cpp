/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStandAlonePresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Standalone Presenter
|
| ! \file        IGSxGUIxStandAlonePresenter.cpp
| ! \brief       Implementation of Standalone Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxStandAlonePresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::StandAlonePresenter::~StandAlonePresenter()
{
    // Do not delete m_view, we are not the owner.
}

IGSxGUI::StandAlonePresenter::StandAlonePresenter(IGSxGUI::IStandAloneView* view)
{
    m_view = view;
}
