/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStubTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of IGSxITS stub test
|
| ! \file        IGSxGUIxStubTest.cpp
| ! \brief       Implementation of IGSxITS stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxStubTest.hpp"
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(IGSxITSTest, MetaDescriptionTest)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    EXPECT_STRCASEEQ(obj.name().c_str(), "SF-04");
    EXPECT_STRCASEEQ(obj.description().c_str(), "SF Environmental Mgt");
}

TEST_F(IGSxITSTest, MetaDescriptionSetTest)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    obj.setName("SF-05");
    obj.setDescription("SF Pollution Mgt");
    EXPECT_STRCASEEQ(obj.name().c_str(), "SF-05");
    EXPECT_STRCASEEQ(obj.description().c_str(), "SF Pollution Mgt");
}
TEST_F(IGSxITSTest, DriverStatusTest)
{
    DriverStatus drvStatus(DriverState::DS_INITIALIZED);
    DriverState::DriverStateEnum drvstate = drvStatus.driverState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_INITIALIZED");
}

TEST_F(IGSxITSTest, DriverErrorSetTest)
{
    DriverStatus drvStatus(DriverState::DS_TERMINATED);
    DriverState::DriverStateEnum drvstate = drvStatus.driverState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_TERMINATED");
}

TEST_F(IGSxITSTest, getSysfuns)
{
    vector<MetaDescription> Actual = InitTerminate::getInstance()->getSysfuns();
    EXPECT_EQ(Actual.size(), 7);
    vector<MetaDescription> Expected;
    MetaDescription m1("SF-04", "Environmental Control");
    MetaDescription m2("SF-15", "Laser");
    MetaDescription m3("SF-16", "Droplet Generation & Positioning");
    MetaDescription m4("SF-17", "Plasma and Energy Control");
    MetaDescription m5("SF-18", "Spectrally Pure EUV Collection");
    MetaDescription m6("SF-19", "Tin Mitigation");
    MetaDescription m7("SF-20", "Source Machine Control");
    Expected.push_back(m1);
    Expected.push_back(m2);
    Expected.push_back(m3);
    Expected.push_back(m4);
    Expected.push_back(m5);
    Expected.push_back(m6);
    Expected.push_back(m7);

    EXPECT_TRUE(VectorsMatch(Expected, Actual));
}

INSTANTIATE_TEST_CASE_P(InstantiationName,
                        IGSxITSTestParam,
                        ::testing::Values("SF-04"));

TEST_P(IGSxITSTestParam, getDrivers)
{
    vector<MetaDescription> Actual = InitTerminate::getInstance()->getDrivers(GetParam());
    EXPECT_EQ(Actual.size(), 5);
    EXPECT_TRUE(VectorsMatch(ExpectedDrivers, Actual));
}

TEST_F(IGSxITSTest, getInstance)
{
    EXPECT_EQ(InitTerminate::getInstance(), InitTerminate::getInstance());
}
