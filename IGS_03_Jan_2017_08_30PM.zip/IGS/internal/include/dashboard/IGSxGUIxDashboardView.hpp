/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard View
|
| ! \file        IGSxGUIxDashboardView.hpp
| ! \brief       Header file for Dashboard View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDVIEW_HPP
#define IGSXGUIXDASHBOARDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/circular_buffer.hpp>
#include <string>
#include <vector>
#include <map>
#include "IGSxGUIxDashboardPresenter.hpp"
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxGUIxKPIManager.hpp"
#include <SUIPlotWidget.h>
#include <SUIProgressBar.h>
#include <SUIGroupBox.h>
#include <SUIPlotHistogramItem.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class DashboardView;
class Label;
class UserControl;
}

namespace IGSxGUI {
class DashboardView : public IDashboardView
{
 public:
    explicit DashboardView(KPIManager* pKpiManager);
    virtual ~DashboardView();

    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool bActive);

    virtual void updateKPI(string kpiName, string displayName, string factor, string valueSetName, vector<double> values);
    virtual void updateSystemKPI(string systemKPIName, string displayName, string factor, string valueSetName, vector<double> values);
    virtual void updateConsumable(string consumableName, string displayName, string factor, vector<double> values, string min, string max);
    void buildHistogramGraphs();
    void buildNormalKPITable();
    void buildSystemKPITable();
    void buildConsumableTable();
    void init();
    void setHandlers();

    void onUCTNormalKPI1HoverOn();
    void onUCTNormalKPI1HoverOff();

    void onUCTNormalKPI2HoverOn();
    void onUCTNormalKPI2HoverOff();

    void onUCTNormalKPI3HoverOn();
    void onUCTNormalKPI3HoverOff();

    void onUCTNormalKPI4HoverOn();
    void onUCTNormalKPI4HoverOff();

    void onUCTNormalKPI5HoverOn();
    void onUCTNormalKPI5HoverOff();

    void onUCTNormalKPI6HoverOn();
    void onUCTNormalKPI6HoverOff();

    void onUCTNormalKPI7HoverOn();
    void onUCTNormalKPI7HoverOff();

    void onUCTNormalKPI8HoverOn();
    void onUCTNormalKPI8HoverOff();

    void onUCTNormalKPI9HoverOn();
    void onUCTNormalKPI9HoverOff();

    void onUCTNormalKPI10HoverOn();
    void onUCTNormalKPI10HoverOff();

    void onUCTSystemKPI1HoverOn();
      void onUCTSystemKPI1HoverOff();

      void onUCTSystemKPI2HoverOn();
      void onUCTSystemKPI2HoverOff();

      void onUCTSystemKPI3HoverOn();
      void onUCTSystemKPI3HoverOff();

      void onUCTSystemKPI4HoverOn();
      void onUCTSystemKPI4HoverOff();

      void onUCTSystemKPI5HoverOn();
      void onUCTSystemKPI5HoverOff();

      void onUCTSystemKPI6HoverOn();
      void onUCTSystemKPI6HoverOff();

      void onUCTSystemKPI7HoverOn();
      void onUCTSystemKPI7HoverOff();

      void onUCTSystemKPI8HoverOn();
      void onUCTSystemKPI8HoverOff();

      void onUCTSystemKPI9HoverOn();
      void onUCTSystemKPI9HoverOff();

      void onUCTSystemKPI10HoverOn();
      void onUCTSystemKPI10HoverOff();

    void onConsumable1HoverOn();
    void onConsumable1HoverOff();
    void onConsumable2HoverOn();
    void onConsumable2HoverOff();
    void onConsumable3HoverOn();
    void onConsumable3HoverOff();
    void onConsumable4HoverOn();
    void onConsumable4HoverOff();
    void onConsumable5HoverOn();
    void onConsumable5HoverOff();
    void onConsumable6HoverOn();
    void onConsumable6HoverOff();
    void onConsumable7HoverOn();
    void onConsumable7HoverOff();
    void onConsumable8HoverOn();
    void onConsumable8HoverOff();
    void onConsumable9HoverOn();
    void onConsumable9HoverOff();

    void loadContainers();

    void setNormalKPIUCTHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);
    void setNormalKPIUCTHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);


    void setConsumableHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);
    void setConsumableHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);

    const std::string currentDateTime(const std::string &dateTime);

    void setSystemKPIUCTHoverOnStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);
    void setSystemKPIUCTHoverOffStyle(SUI::GroupBox *p_GroupBox, SUI::Label *p_name, SUI::Label *p_category, SUI::Label *p_time, SUI::Label *p_value, SUI::Label *p_unit);
 private:
    DashboardView(const DashboardView&);
    DashboardView& operator=(const DashboardView&);

    SUI::DashboardView *sui;
    DashboardPresenter *m_presenter;
    std::vector<KPI*> m_listKPIs;
    std::vector<KPI*> m_listSystemKPIs;
    std::map<std::string, std::vector<SUI::PlotIntervalSample> > plotsamples;
    std::map<std::string, SUI::PlotHistogramItem *> m_mapKPIHistogram;
    std::map<std::string, SUI::PlotWidget *> m_mapKPIPlots;
    std::map<std::string, std::vector<double> > kpihistogramValues;
    std::map<std::string, double> m_mapKPIMinValue;
    std::map<std::string, double> m_mapKPIMaxValue;
    std::map<std::string, SUI::Label*> m_mapKPIGraphValueLabel;

    boost::circular_buffer<double> m_circularBuffer1;
    boost::circular_buffer<double> m_circularBuffer2;
    boost::circular_buffer<double> m_circularBuffer3;
    boost::circular_buffer<double> m_circularBuffer4;
    boost::circular_buffer<double> m_circularBuffer5;

    std::map<std::string, boost::circular_buffer<double> > m_mapKPICircBuffPlotItemValues;

    SUI::PlotHistogramItem *histogram1;
    SUI::PlotHistogramItem *histogram2;
    SUI::PlotHistogramItem *histogram3;
    SUI::PlotHistogramItem *histogram4;
    SUI::PlotHistogramItem *histogram5;

    // Noraml KPI data
    std::vector<SUI::UserControl*> m_listNormalKPIUCTs;
    std::vector<SUI::GroupBox*> m_listNormalKPIGroupBoxes;
    std::vector<SUI::Label*> m_listNormalKPINames;
    std::vector<SUI::Label*> m_listNormalKPICategories;
    std::vector<SUI::Label*> m_listNormalKPITimes;
    std::vector<SUI::Label*> m_listNormalKPIValues;
    std::vector<SUI::Label*> m_listNormalKPIUnits;

    // System KPI data
    std::vector<SUI::UserControl*> m_listSystemKPIUCTs;
    std::vector<SUI::GroupBox*> m_listSystemKPIGroupBoxes;
    std::vector<SUI::Label*> m_listSystemKPINames;
    std::vector<SUI::Label*> m_listSystemKPICategories;
    std::vector<SUI::Label*> m_listSystemKPITimes;
    std::vector<SUI::Label*> m_listSystemKPIValues;
    std::vector<SUI::Label*> m_listSystemKPIUnits;

    // Consumables
    std::vector<SUI::UserControl*> m_listConsumableUCTs;
    std::vector<SUI::GroupBox*> m_listConsumableGroupBoxes;
    std::vector<SUI::Label*> m_listConsumableNames;
    std::vector<SUI::Label*> m_listConsumableCategories;
    std::vector<SUI::Label*> m_listConsumableTimes;
    std::vector<SUI::Label*> m_listConsumableValues;
    std::vector<SUI::Label*> m_listConsumableUnits;
    std::vector<SUI::ProgressBar*> m_listConsumableProgressbars;

    static const int SYSTEMKPIS_COUNT;
    static const int CONSUMABLES_COUNT;

    static const std::string LOAD_FILE_DASHBOARD;
    static const std::string STRING_TIME;
    static const int NO_OF_PLOTITEM_VALUES;

    static const float HISTOGRAM_BAR_START_VALUE;
    static const float HISTOGRAM_BAR_END_VALUE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXDASHBOARDVIEW_HPP
