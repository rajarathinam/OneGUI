/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManager.hpp
| Author       : Venugopal S
| Description  : Header file for CPD Manager
|
| ! \file        IGSxGUIxCPDManager.hpp
| ! \brief       Header file for CPD Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCPD_MANAGER_HPP
#define IGSXCPD_MANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class CPDManager
{
 public:
    CPDManager();
    virtual ~CPDManager();

    void initialize();
    void add(CPD *cpd);
    void remove(CPD *cpd);
    CPD* getCPD(const std::string& name) const;
    CPD* retrieveRunningCPD();
    std::vector<CPD*> retrieveAll();
    void onStopped(IGS::Result result);

 private:
    CPDManager(CPDManager const &);
    CPDManager& operator=(CPDManager const &);

    std::vector<CPD*> m_CPDs;
};

}  // namespace IGSxGUI
#endif  // IGSXCPD_MANAGER_HPP
