/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <SUILabel.h>
#include <SUIDialog.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIGroupBox.h>
#include <SUIRadioButton.h>
#include <SUITimer.h>
#include <SUITextArea.h>
#include <SUITableWidget.h>
#include <SUIDropDown.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxADT.xml");
const std::string IGSxGUI::ADTView::IMAGE_CLOCK = IGS::Resource::path("IGSxSystem_clock.png");
// const std::string IGSxGUI::ADTView::IMAGE_ADT_DETAIL_INFO = IGS::Resource::path("IGSxADTNext.png");

const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "All ADTs";
const std::string IGSxGUI::ADTView::STRING_CALIBRATION = "Calibration";
const std::string IGSxGUI::ADTView::STRING_PERFORMANCE = "Performance";
const std::string IGSxGUI::ADTView::STRING_DIAGNOSTICS = "Diagnostics";
const std::string IGSxGUI::ADTView::STRING_NO_ACTIVE_ADT = "There is no active ADT";

const std::string IGSxGUI::ADTView::STRING_ADT_HPAC = "Monitor status of the HPAC driver and inititlize terminate it.\nMonitor status of Power amplifiers (from PA0 to PA3) and enable disable High Voltage (HV) on each amplifier.\\nMonitor readings on Power meters (measuring power from PA0-in and  PA0-out to PA3-out).";
const std::string IGSxGUI::ADTView::STRING_ADT_ATTENTION = "HPAC ADT runs on the Master System Controller (MSC) computer.A virtual Network Computing (VCN) connection to MSC can be used to control it.";
const std::string IGSxGUI::ADTView::STRING_TIME = "Time";
const std::string IGSxGUI::ADTView::STRING_DATE = "Date";
const std::string IGSxGUI::ADTView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::ADTView::STYLE_CURRENTPAGE = "currentPage";
const std::string IGSxGUI::ADTView::STYLE_ACTIVE_ADT = "ActiveADT";
const std::string IGSxGUI::ADTView::STYLE_NO_ACTIVE_ADT = "NoActiveADT";
const int IGSxGUI::ADTView::TIMER_INTERVAL = 4000;

IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_timer(SUI::Timer::createTimer()),
    m_numTotalPages(0),
    m_numLastPageItems(0),
    m_currentPageNo(0),
    m_ActiveADTBoxToggleFlag(false),
    m_bRunningADT(false),
    m_selectedSubSystem("")
{
    m_presenter = new ADTPresenter(this, pADTManager);
}

IGSxGUI::ADTView::~ADTView()
{
    delete m_presenter;
    delete sui;
}

const std::string IGSxGUI::ADTView::currentDateTime(const std::string& dateTime)
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%l:%M%p", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
}

void IGSxGUI::ADTView::init()
{
    sui->lblAllADTs->setColor(SUI::ColorEnum::Gray);
    sui->gbxADT->setBGColor(SUI::ColorEnum::White);
    sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_ADT);
    sui->lblDescription->setText(STRING_NO_ACTIVE_ADT);

    sui->lblType->setVisible(false);
    sui->lblName->setVisible(false);
    sui->lblStatus->setVisible(false);
    sui->btnShowADT->setVisible(false);
    sui->btnADTDetail->setVisible(false);
    sui->tawADTSubsystem->showGrid(false);

    m_listADT = m_presenter->getADTs();
    m_listSubsystemADTs = m_presenter->getADTs();

    loadTestTypes();
    loadSubSystems();
    loadADTs();
}

void IGSxGUI::ADTView::initNumberedButtons(int numTotalPages)
{
    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if (boost::lexical_cast<int>(m_listDisplayButtons[i]->getText()) <= numTotalPages)
        {
            m_listDisplayButtons[i]->setEnabled(true);
        }else{
            m_listDisplayButtons[i]->setEnabled(false);
        }
    }
}

void IGSxGUI::ADTView::fetchADTs(int nCurrentPageNumber)
{
    size_t j  = ((nCurrentPageNumber - 1)*10);

    for (size_t i = 0 ; i < m_listADTUCT.size(); i++)
    {
        if (j < m_listADT.size())
        {
            m_listADTUCT[i]->setVisible(true);
            m_listADTNameLabels[i]->setText(m_listADT[j]->getName());
            m_listADTDescriptionLabels[i]->setText(m_listADT[j]->getDescription());
            ++j;
        }else{
            m_listADTUCT[i]->setVisible(false);
        }
    }
}

void IGSxGUI::ADTView::onButtonPrevPressed()
{
    --m_currentPageNo;

    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    }else if (m_currentPageNo < m_numTotalPages){
        sui->btnNext->setEnabled(true);
    }
    fetchADTs(m_currentPageNo);

    if (m_currentPageNo <= 4 &&  m_currentPageNo >= 0)
    {
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }else{
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }
}
void IGSxGUI::ADTView::onButtonNextPressed()
{
    ++m_currentPageNo;

    if (m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    }else if (m_currentPageNo > 1){
        sui->btnPrev->setEnabled(true);
    }
    fetchADTs(m_currentPageNo);

    if (m_currentPageNo <= 4 &&  m_currentPageNo >= 0)
    {
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }else{
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }
}

void IGSxGUI::ADTView::modifyPrevNextButtons()
{
    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    }else if (m_currentPageNo < m_numTotalPages){
        sui->btnNext->setEnabled(true);
    }

    if (m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    }else if (m_currentPageNo > 1){
        sui->btnPrev->setEnabled(true);
    }
}

void IGSxGUI::ADTView::setNumberedButtonStyles(int nCurrentPage, std::string style)
{
    sui->btnOne->setStyleSheetClass(STYLE_NORMAL);
    sui->btnTwo->setStyleSheetClass(STYLE_NORMAL);
    sui->btnThree->setStyleSheetClass(STYLE_NORMAL);
    sui->btnFour->setStyleSheetClass(STYLE_NORMAL);

    if (nCurrentPage == 1)
    {
        sui->btnOne->setStyleSheetClass(style);
    }else if (nCurrentPage == 2){
        sui->btnTwo->setStyleSheetClass(style);
    }else if (nCurrentPage == 3){
        sui->btnThree->setStyleSheetClass(style);
    }else if (nCurrentPage == 4){
        sui->btnFour->setStyleSheetClass(style);
    }
}

void IGSxGUI::ADTView::onButtonOnePressed()
{
    if (m_numTotalPages >= 1)
    {
        m_currentPageNo = 1;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchADTs(m_currentPageNo);
}

void IGSxGUI::ADTView::onButtonTwoPressed()
{
    if (m_numTotalPages >= 2)
    {
        m_currentPageNo = 2;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchADTs(m_currentPageNo);
}

void IGSxGUI::ADTView::onButtonThreePressed()
{
    if (m_numTotalPages >= 3)
    {
        m_currentPageNo = 3;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchADTs(m_currentPageNo);
}

void IGSxGUI::ADTView::onButtonFourPressed()
{
    if (m_numTotalPages >= 4)
    {
        m_currentPageNo = 4;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchADTs(m_currentPageNo);
}

void IGSxGUI::ADTView::onSubsystemPressed()
{
    sui->gbxPageOne->setVisible(true);
    sui->gbxPageTwo->setVisible(false);

    std::list<std::string> items = sui->tawADTSubsystem->getSelectedItems();
    std::string strSelectedRow = items.front();

    strSelectedRow.erase(0, 20);
    strSelectedRow.erase(strSelectedRow.size()-2, strSelectedRow.size());
    std::string selectedText = sui->tawADTSubsystem->getItemText((boost::lexical_cast<int>(strSelectedRow)-1), 0);

    int position = selectedText.find('(');
    selectedText.erase(position, selectedText.size());
    boost::trim(selectedText);
    m_selectedSubSystem = selectedText;

    std::vector<ADT*> listSubsystemADTs;

    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == selectedText))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    intersectADTs(getTestTypeADTs(), listSubsystemADTs);
    loadADTs();
}

void IGSxGUI::ADTView::onButtonShowReportsPressed()
{
    for (size_t i = 0 ; i < 4; i++)
    {
        m_listADTReportGroupBox[i]->setVisible(false);
        m_listADTReportNameLabels[i]->setText("");
        m_listADTReportTypeLabels[i]->setText("");
        m_listADTReportDescriptionLabels[i]->setText("");
    }
    std::list<std::string> selectedItems = sui->ddbSubsystem->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::string selectedText = selectedItems.front();

        int position = selectedText.find('(');
        selectedText.erase(position, selectedText.size());
        boost::trim(selectedText);

        std::vector<ADT*> listSubsystemADTs;

        for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
        {
             container subsys = m_listSubsystems[i];

             std::size_t found = selectedText.find(STRING_ALL_ADTS);
             if ((found != std::string::npos) || (subsys.name == selectedText))
             {
                 listSubsystemADTs.push_back(subsys.adt);
             }
        }

        for (size_t i = 0 ; i < listSubsystemADTs.size(); i++)
        {
            if (i > 3)
            {
                break;
            }
            ADT* adt = listSubsystemADTs[i];

            m_listADTReportGroupBox[i]->setVisible(true);
            m_listADTReportNameLabels[i]->setText(adt->getName());
           // m_listADTReportTypeLabels[i]->setText(adt->getTestType());
            m_listADTReportDescriptionLabels[i]->setText(adt->getDescription());
        }
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getTestADTsByName(std::string testtypeName)
{
    std::vector<IGSxGUI::ADT*> listTestTypeADTs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++)
    {
         IGSxGUI::container testtype = m_listTestTypes[i];

         if (testtype.name == testtypeName)
         {
             listTestTypeADTs.push_back(testtype.adt);
         }
    }
    return listTestTypeADTs;
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::intersectADTs(std::vector<IGSxGUI::ADT *> listTestTypeADTs, std::vector<IGSxGUI::ADT *> listSubSystemADTs)
{
    m_listADT.clear();

    std::sort(listSubSystemADTs.begin(),  listSubSystemADTs.end());
    std::sort(listTestTypeADTs.begin(),  listTestTypeADTs.end());

    std::set_intersection(listSubSystemADTs.begin(), listSubSystemADTs.end(), listTestTypeADTs.begin(), listTestTypeADTs.end(), std::back_inserter(m_listADT));

    if ((m_listADT.size() <= 0) && sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getTestTypeADTs()
{
    std::vector<IGSxGUI::ADT*> listTestTypeADTs;
    listTestTypeADTs = m_presenter->getADTs();
    return listTestTypeADTs;
}


void IGSxGUI::ADTView::loadADTs()
{
    m_numTotalPages = m_listADT.size() / m_listADTUCT.size();
    m_numLastPageItems = m_listADT.size() % m_listADTUCT.size();

    m_currentPageNo = 1;

    if (m_numLastPageItems > 0)
    {
        ++m_numTotalPages;
    }

    if (m_numTotalPages == 0)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(0, "Normal");
    }

    if (m_numTotalPages == 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    if (m_numTotalPages > 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(true);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    initNumberedButtons(m_numTotalPages);
    fetchADTs(m_currentPageNo);
}

void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(std::string /*strADT*/, IGS::Result result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;

        sui->gbxADT->setBGColor(SUI::ColorEnum::White);
        sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_ADT);
        sui->lblDescription->setText(STRING_NO_ACTIVE_ADT);
        sui->lblType->setVisible(false);
        sui->lblName->setVisible(false);
        sui->lblStatus->setVisible(false);
        sui->btnShowADT->setVisible(false);
        sui->btnADTDetail->setVisible(false);
    }
}

void IGSxGUI::ADTView::startADT(std::string adtName)
{
    m_presenter->startADT(adtName);
}

void IGSxGUI::ADTView::onButtonADT1StartPressed()
{
    startADT(sui->lblADT1Name->getText());
}

void IGSxGUI::ADTView::onButtonADT2StartPressed()
{
    startADT(sui->lblADT2Name->getText());
}

void IGSxGUI::ADTView::onButtonADT3StartPressed()
{
    startADT(sui->lblADT3Name->getText());
}

void IGSxGUI::ADTView::onButtonADT4StartPressed()
{
    startADT(sui->lblADT4Name->getText());
}

void IGSxGUI::ADTView::onButtonADT5StartPressed()
{
    startADT(sui->lblADT5Name->getText());
}

void IGSxGUI::ADTView::onButtonADT6StartPressed()
{
    startADT(sui->lblADT6Name->getText());
}

void IGSxGUI::ADTView::onButtonADT7StartPressed()
{
    startADT(sui->lblADT7Name->getText());
}

void IGSxGUI::ADTView::onButtonADT8StartPressed()
{
    startADT(sui->lblADT8Name->getText());
}

void IGSxGUI::ADTView::onButtonADT9StartPressed()
{
    startADT(sui->lblADT9Name->getText());
}

void IGSxGUI::ADTView::onButtonADT10StartPressed()
{
    startADT(sui->lblADT10Name->getText());
}

void IGSxGUI::ADTView::onButtonADT1DetailPressed()
{
    setTextArea(sui->lblADT1Description->getText(), sui->lblADT1Name->getText(), sui->lblADT1Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT2DetailPressed()
{
    setTextArea(sui->lblADT2Description->getText(), sui->lblADT2Name->getText(), sui->lblADT2Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT3DetailPressed()
{
    setTextArea(sui->lblADT3Description->getText(), sui->lblADT3Name->getText(), sui->lblADT3Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT4DetailPressed()
{
    setTextArea(sui->lblADT4Description->getText(), sui->lblADT4Name->getText(), sui->lblADT4Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT5DetailPressed()
{
    setTextArea(sui->lblADT5Description->getText(), sui->lblADT5Name->getText(), sui->lblADT5Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT6DetailPressed()
{
    setTextArea(sui->lblADT6Description->getText(), sui->lblADT6Name->getText(), sui->lblADT6Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT7DetailPressed()
{
    setTextArea(sui->lblADT7Description->getText(), sui->lblADT7Name->getText(), sui->lblADT7Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT8DetailPressed()
{
    setTextArea(sui->lblADT8Description->getText(), sui->lblADT8Name->getText(), sui->lblADT8Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT9DetailPressed()
{
    setTextArea(sui->lblADT9Description->getText(), sui->lblADT9Name->getText(), sui->lblADT9Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::onButtonADT10DetailPressed()
{
    setTextArea(sui->lblADT10Description->getText(), sui->lblADT10Name->getText(), sui->lblADT10Type->getText());
    // sui->btnADT1Detail->setImage(IMAGE_ADT_DETAIL_INFO); // Future use
}

void IGSxGUI::ADTView::loadContainers()
{
    m_listADTUCT.clear();
    m_listADTNameLabels.clear();
    m_listADTTypeLabels.clear();
    m_listADTDescriptionLabels.clear();
    m_listADTTimeLabels.clear();
    m_listDisplayButtons.clear();
    m_listADTReportGroupBox.clear();
    m_listADTReportNameLabels.clear();
    m_listADTReportTypeLabels.clear();
    m_listADTReportDescriptionLabels.clear();

    m_listADTUCT.push_back(sui->uctADT1);
    m_listADTUCT.push_back(sui->uctADT2);
    m_listADTUCT.push_back(sui->uctADT3);
    m_listADTUCT.push_back(sui->uctADT4);
    m_listADTUCT.push_back(sui->uctADT5);
    m_listADTUCT.push_back(sui->uctADT6);
    m_listADTUCT.push_back(sui->uctADT7);
    m_listADTUCT.push_back(sui->uctADT8);
    m_listADTUCT.push_back(sui->uctADT9);
    m_listADTUCT.push_back(sui->uctADT10);

    m_listADTNameLabels.push_back(sui->lblADT1Name);
    m_listADTNameLabels.push_back(sui->lblADT2Name);
    m_listADTNameLabels.push_back(sui->lblADT3Name);
    m_listADTNameLabels.push_back(sui->lblADT4Name);
    m_listADTNameLabels.push_back(sui->lblADT5Name);
    m_listADTNameLabels.push_back(sui->lblADT6Name);
    m_listADTNameLabels.push_back(sui->lblADT7Name);
    m_listADTNameLabels.push_back(sui->lblADT8Name);
    m_listADTNameLabels.push_back(sui->lblADT9Name);
    m_listADTNameLabels.push_back(sui->lblADT10Name);

    m_listADTTypeLabels.push_back(sui->lblADT1Type);
    m_listADTTypeLabels.push_back(sui->lblADT2Type);
    m_listADTTypeLabels.push_back(sui->lblADT3Type);
    m_listADTTypeLabels.push_back(sui->lblADT4Type);
    m_listADTTypeLabels.push_back(sui->lblADT5Type);
    m_listADTTypeLabels.push_back(sui->lblADT6Type);
    m_listADTTypeLabels.push_back(sui->lblADT7Type);
    m_listADTTypeLabels.push_back(sui->lblADT8Type);
    m_listADTTypeLabels.push_back(sui->lblADT9Type);
    m_listADTTypeLabels.push_back(sui->lblADT10Type);

    m_listADTDescriptionLabels.push_back(sui->lblADT1Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT2Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT3Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT4Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT5Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT6Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT7Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT8Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT9Description);
    m_listADTDescriptionLabels.push_back(sui->lblADT10Description);

    m_listADTTimeLabels.push_back(sui->lblADT1Time);
    m_listADTTimeLabels.push_back(sui->lblADT2Time);
    m_listADTTimeLabels.push_back(sui->lblADT3Time);
    m_listADTTimeLabels.push_back(sui->lblADT4Time);
    m_listADTTimeLabels.push_back(sui->lblADT5Time);
    m_listADTTimeLabels.push_back(sui->lblADT6Time);
    m_listADTTimeLabels.push_back(sui->lblADT7Time);
    m_listADTTimeLabels.push_back(sui->lblADT8Time);
    m_listADTTimeLabels.push_back(sui->lblADT9Time);
    m_listADTTimeLabels.push_back(sui->lblADT10Time);

    m_listDisplayButtons.push_back(sui->btnOne);
    m_listDisplayButtons.push_back(sui->btnTwo);
    m_listDisplayButtons.push_back(sui->btnThree);
    m_listDisplayButtons.push_back(sui->btnFour);

    m_listADTReportGroupBox.push_back(sui->gbxADTReportView1);
    m_listADTReportGroupBox.push_back(sui->gbxADTReportView2);
    m_listADTReportGroupBox.push_back(sui->gbxADTReportView3);
    m_listADTReportGroupBox.push_back(sui->gbxADTReportView4);

    m_listADTReportNameLabels.push_back(sui->lblADTReportTest1);
    m_listADTReportNameLabels.push_back(sui->lblADTReportTest2);
    m_listADTReportNameLabels.push_back(sui->lblADTReportTest3);
    m_listADTReportNameLabels.push_back(sui->lblADTReportTest4);

    m_listADTReportTypeLabels.push_back(sui->lblADTReportType1);
    m_listADTReportTypeLabels.push_back(sui->lblADTReportType2);
    m_listADTReportTypeLabels.push_back(sui->lblADTReportType3);
    m_listADTReportTypeLabels.push_back(sui->lblADTReportType4);

    m_listADTReportDescriptionLabels.push_back(sui->lblADTReportDesc1);
    m_listADTReportDescriptionLabels.push_back(sui->lblADTReportDesc2);
    m_listADTReportDescriptionLabels.push_back(sui->lblADTReportDesc3);
    m_listADTReportDescriptionLabels.push_back(sui->lblADTReportDesc4);
}

void IGSxGUI::ADTView::loadTestTypes()
{
    container testtype;
    for (size_t i = 0 ; i < m_listADT.size(); i++)
    {
        // testtype.name = m_listADT[i]->getTestType();
        testtype.adt = m_listADT[i];
        m_listTestTypes.push_back(testtype);
    }
}

void IGSxGUI::ADTView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemADTs.size(); i++)
    {
        subsystem.name = m_listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = m_listSubsystemADTs[i];
        listStringSubsystem.push_back(m_listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            container subsystem = m_listSubsystems[j];

            if (listStringSubsystem[i] == subsystem.name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;
    std::string strAllADTs =  sui->tawADTSubsystem->getItemText(0, 0) + " (" + boost::lexical_cast<std::string>(m_listSubsystemADTs.size()) + ")";
    sui->tawADTSubsystem->setItemText(0, 0, strAllADTs);
    listTestReportSubSystemItems.push_back(strAllADTs);

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        subSystemCount subsyscount = m_listSubsystemCount[i];

        std::string subsys = subsyscount.nameSubsystem + " (" + boost::lexical_cast<std::string>(subsyscount.count) + ")";
        std::list<std::string> listRowData;

        listRowData.push_back(subsys);
        listTestReportSubSystemItems.push_back(subsys);

        sui->tawADTSubsystem->insertRows(i+1, 1);
        sui->tawADTSubsystem->addData(i+1, listRowData);
    }
    sui->ddbSubsystem->addItems(listTestReportSubSystemItems);
    sui->ddbSubsystem->selectItem(1);
    sui->tawADTSubsystem->selectItem(0);
}

void IGSxGUI::ADTView::setHandlers()
{
    sui->btnADTDetail->clicked   = boost::bind(&ADTView::onActiveADTDetailButtonPressed, this);

    sui->btnADT1Start->clicked    = boost::bind(&ADTView::onButtonADT1StartPressed, this);
    sui->btnADT2Start->clicked    = boost::bind(&ADTView::onButtonADT2StartPressed, this);
    sui->btnADT3Start->clicked    = boost::bind(&ADTView::onButtonADT3StartPressed, this);
    sui->btnADT4Start->clicked    = boost::bind(&ADTView::onButtonADT4StartPressed, this);
    sui->btnADT5Start->clicked    = boost::bind(&ADTView::onButtonADT5StartPressed, this);
    sui->btnADT6Start->clicked    = boost::bind(&ADTView::onButtonADT6StartPressed, this);
    sui->btnADT7Start->clicked    = boost::bind(&ADTView::onButtonADT7StartPressed, this);
    sui->btnADT8Start->clicked    = boost::bind(&ADTView::onButtonADT8StartPressed, this);
    sui->btnADT9Start->clicked    = boost::bind(&ADTView::onButtonADT9StartPressed, this);
    sui->btnADT10Start->clicked    = boost::bind(&ADTView::onButtonADT10StartPressed, this);

    sui->btnADT1Detail->clicked    = boost::bind(&ADTView::onButtonADT1DetailPressed, this);
    sui->btnADT2Detail->clicked    = boost::bind(&ADTView::onButtonADT2DetailPressed, this);
    sui->btnADT3Detail->clicked    = boost::bind(&ADTView::onButtonADT3DetailPressed, this);
    sui->btnADT4Detail->clicked    = boost::bind(&ADTView::onButtonADT4DetailPressed, this);
    sui->btnADT5Detail->clicked    = boost::bind(&ADTView::onButtonADT5DetailPressed, this);
    sui->btnADT6Detail->clicked    = boost::bind(&ADTView::onButtonADT6DetailPressed, this);
    sui->btnADT7Detail->clicked    = boost::bind(&ADTView::onButtonADT7DetailPressed, this);
    sui->btnADT8Detail->clicked    = boost::bind(&ADTView::onButtonADT8DetailPressed, this);
    sui->btnADT9Detail->clicked    = boost::bind(&ADTView::onButtonADT9DetailPressed, this);
    sui->btnADT10Detail->clicked    = boost::bind(&ADTView::onButtonADT10DetailPressed, this);

    sui->btnPrev->clicked    = boost::bind(&ADTView::onButtonPrevPressed, this);
    sui->btnNext->clicked    = boost::bind(&ADTView::onButtonNextPressed, this);
    sui->btnOne->clicked    = boost::bind(&ADTView::onButtonOnePressed, this);
    sui->btnTwo->clicked    = boost::bind(&ADTView::onButtonTwoPressed, this);
    sui->btnThree->clicked    = boost::bind(&ADTView::onButtonThreePressed, this);
    sui->btnFour->clicked    = boost::bind(&ADTView::onButtonFourPressed, this);

    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
}

void IGSxGUI::ADTView::setTextArea(std::string /*adtDescription*/, std::string /*adtTestName*/, std::string /*adtTestType*/)
{
    sui->gbxReport->setVisible(true);
    sui->txaADTHPACDetail->clearText();
    sui->txaADTHPACDetail->setText(STRING_ADT_HPAC);
    sui->txaADTHPACAttention->clearText();
    sui->txaADTHPACAttention->setText(STRING_ADT_ATTENTION);
}

void IGSxGUI::ADTView::onActiveADTDetailButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }else{
        sui->gbxReport->setVisible(true);
        sui->lblADTDescDescription->setText(sui->lblName->getText());
        sui->lblADTDescName1->setText(sui->lblName->getText());
        sui->lblADTDescType1->setText(sui->lblType->getText());
        sui->txaADTHPACDetail->clearText();
        sui->txaADTHPACDetail->setText(sui->lblName->getText());
        sui->txaADTHPACAttention->clearText();
        sui->txaADTHPACAttention->setText(sui->lblType->getText());
    }
}


