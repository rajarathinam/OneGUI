/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsView.hpp
| Author       : Venugopal S
| Description  : Header file for SystemTools view
|
| ! \file        IGSxGUIxSystemToolsView.hpp
| ! \brief       Header file for SystemTools view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMTOOLSVIEW_HPP
#define IGSXGUIXSYSTEMTOOLSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxISystemToolsView.hpp"
#include "IGSxGUIxAlertPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SystemToolsView;
class Label;
}
namespace IGSxGUI{

class SystemToolsView : public ISystemToolsView
{
 public:
    explicit SystemToolsView();
    virtual ~SystemToolsView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool);

 private:
    SystemToolsView(const SystemToolsView &);
    SystemToolsView& operator=(const SystemToolsView &);

    void onSystemToolUCTHoverLeft(int index);
    void onSystemToolUCTHoverEntered(int index);
    void onTableSystemToolRowPressed(int rowindex);

    SUI::SystemToolsView *sui;

    int m_selectedSystemToolRowNum;

    static const std::string IMAGE_LOGO;
    static const std::string STRING_EMPTY;
    static const std::string SYSTEMTOOLS_LOAD_FILE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMTOOLSVIEW_HPP
