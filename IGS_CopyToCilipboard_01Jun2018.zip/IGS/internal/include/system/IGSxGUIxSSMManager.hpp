/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMManager.hpp
| Author       : Saket K
| Description  : Header file for SSM Manager
|
| ! \file        IGSxGUIxSSMManager.hpp
| ! \brief       Header file for SSM Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSSMMANAGER_HPP
#define IGSXGUIXSSMMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <map>
#include <set>
#include <string>
#include <vector>
#include "IGSxSSM.hpp"
#include <boost/array.hpp>
#include <IGSxGUIxSSMState.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {

typedef boost::array< std::string, IGSxSSM::STATE_NR_OF_LINES> StateDescriptionType;
typedef std::vector<IGSxSSM::StateConfigList> StatesList;
typedef std::vector<IGSxSSM::GroupConfigList> GroupsList;
typedef std::set<IGSxSSM::StateIDType> StateIds;

struct TransitionData
{
    IGSxSSM::FunctionResultType FunctionResult;
    IGSxSSM::StateIDType From;
    IGSxSSM::StateIDType To;
    IGSxSSM::ReachableStateList ReachableStates;
    IGSxSSM::TransitionResultType TransitionResult;
    unsigned int ExpectedDuration;
};

class SSMManager
{
 public:
    SSMManager();
    virtual ~SSMManager();
    void initialize();
    int getFunctionCount() const;
    std::string getFunctionName(const int functionIndex) const;
    std::string getGroupName(const int functionIndex, const int groupIndex) const;
    int getGroupCount(const int functionIndex) const;
    StateDescriptionType getStateDescription(const int functionIndex, const int groupIndex, const int stateIndex) const;
    StateDescriptionType getStateDescriptionById(const int functionIndex, const IGSxSSM::StateIDType& stateIdType) const;

    int getStateId(const int functionIndex, const int groupIndex, const int stateIndex) const;
    int getStatesCount(const int functionIndex, const int groupIndex) const;
    TransitionData getActiveTransitionData(const int functionIndex) const;
    void getActiveTransition(const int functionIndex) const;
    bool isTransitionAbortable(const int functionIndex,const int stateId) const;
    void setTransition(const int functionIndex, const int newStateId);
    IGSxGUI::InnerState getInnerState(const int functionIndex, const int stateId) const;
    void stateChanged();

    boost::function<void () > update;

    StateList SystemStates;
    StateList LaserControlStates;
    StateList DropletControlStates;
    StateList EnvControlStates;
    StateList TimingControlStates;
    StateList TinControlStates;

private:
    void onGetStateResultFunction(const int functionIndex, const IGSxSSM::FunctionResultType& result, const IGSxSSM::StateIDType& from, const IGSxSSM::StateIDType& to, const IGSxSSM::ReachableStateList& reachable_states);
    void onSetStateResultFunction(const int functionIndex, const IGSxSSM::FunctionResultType& result);
    void onSetStateUpdatedFunction(const int);
    void onSetTransitionStartedFunction(const int functionIndex, const IGSxSSM::StateIDType& from,const IGSxSSM::StateIDType& to, const unsigned int duration);
    void onSetTransitionCompletedFunction(const int functionIndex, const IGSxSSM::StateIDType& from,const IGSxSSM::StateIDType& to , const IGSxSSM::TransitionResultType& result, const IGSxSSM::ReachableStateList& reachable_states);
    bool isStateReachable(int functionIndex, int stateId) const;


    SSMManager(SSMManager const &);
    SSMManager& operator=(SSMManager const &);
    IGSxSSM::SSMPtr m_Instance;
    IGSxSSM::SystemFunctionPtrList m_Functions;
    GroupsList m_Groups;
    std::vector<StatesList> m_States;
    std::map<int, StateIds> m_ReachableStates;
    std::map<int, IGSxSSM::StateIDType> m_ActiveStates;
    std::vector<TransitionData> m_Transitions;

};

}  // namespace IGSxGUI
#endif  // IGSXGUIXSSMMANAGER_HPP
