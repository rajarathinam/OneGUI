/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : SystemStateManagerView.hpp
| Author       : Saket K
| Description  : Header file
|
| ! \file        SystemStateManagerView.hpp
| ! \brief       Header file
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSUI_MOC_SSSMTABVIEW_HPP
#define IGSXGUIXSUI_MOC_SSMTABVIEW_HPP

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SSMTabView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class Button;
class UserControl;
class BusyIndicator;
class GroupBox;
class Label;

class SSMTabView
{
private:
    SSMTabView();

    void setupSUI(const char *);
    void setupSUIContainer(const char *XMLFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    SUI::UserControl* state11;
    SUI::UserControl* state12;
    SUI::UserControl* state13;
    SUI::UserControl* state14;
    SUI::UserControl* state15;
    SUI::UserControl* state16;
    SUI::UserControl* state17;
    SUI::UserControl* state18;
    SUI::UserControl* state19;


    SUI::Button* state11Btn;
    SUI::Button* state12Btn;
    SUI::Button* state13Btn;
    SUI::Button* state14Btn;
    SUI::Button* state15Btn;
    SUI::Button* state16Btn;
    SUI::Button* state17Btn;
    SUI::Button* state18Btn;
    SUI::Button* state19Btn;


    SUI::BusyIndicator* state11Bic;
    SUI::BusyIndicator* state12Bic;
    SUI::BusyIndicator* state13Bic;
    SUI::BusyIndicator* state14Bic;
    SUI::BusyIndicator* state15Bic;
    SUI::BusyIndicator* state16Bic;
    SUI::BusyIndicator* state17Bic;
    SUI::BusyIndicator* state18Bic;
    SUI::BusyIndicator* state19Bic;


    SUI::Label* state11OverlayLabel;
    SUI::Label* state12OverlayLabel;
    SUI::Label* state13OverlayLabel;
    SUI::Label* state14OverlayLabel;
    SUI::Label* state15OverlayLabel;
    SUI::Label* state16OverlayLabel;
    SUI::Label* state17OverlayLabel;
    SUI::Label* state18OverlayLabel;
    SUI::Label* state19OverlayLabel;

    SUI::UserControl* state21;
    SUI::UserControl* state22;
    SUI::UserControl* state23;
    SUI::UserControl* state24;
    SUI::UserControl* state25;
    SUI::UserControl* state26;
    SUI::UserControl* state27;
    SUI::UserControl* state28;
    SUI::UserControl* state29;


    SUI::Button* state21Btn;
    SUI::Button* state22Btn;
    SUI::Button* state23Btn;
    SUI::Button* state24Btn;
    SUI::Button* state25Btn;
    SUI::Button* state26Btn;
    SUI::Button* state27Btn;
    SUI::Button* state28Btn;
    SUI::Button* state29Btn;

    SUI::BusyIndicator* state21Bic;
    SUI::BusyIndicator* state22Bic;
    SUI::BusyIndicator* state23Bic;
    SUI::BusyIndicator* state24Bic;
    SUI::BusyIndicator* state25Bic;
    SUI::BusyIndicator* state26Bic;
    SUI::BusyIndicator* state27Bic;
    SUI::BusyIndicator* state28Bic;
    SUI::BusyIndicator* state29Bic;

    SUI::Label* state21OverlayLabel;
    SUI::Label* state22OverlayLabel;
    SUI::Label* state23OverlayLabel;
    SUI::Label* state24OverlayLabel;
    SUI::Label* state25OverlayLabel;
    SUI::Label* state26OverlayLabel;
    SUI::Label* state27OverlayLabel;
    SUI::Label* state28OverlayLabel;
    SUI::Label* state29OverlayLabel;


    SUI::UserControl* state31;
    SUI::UserControl* state32;
    SUI::UserControl* state33;
    SUI::UserControl* state34;
    SUI::UserControl* state35;
    SUI::UserControl* state36;
    SUI::UserControl* state37;
    SUI::UserControl* state38;
    SUI::UserControl* state39;


    SUI::Button* state31Btn;
    SUI::Button* state32Btn;
    SUI::Button* state33Btn;
    SUI::Button* state34Btn;
    SUI::Button* state35Btn;
    SUI::Button* state36Btn;
    SUI::Button* state37Btn;
    SUI::Button* state38Btn;
    SUI::Button* state39Btn;


    SUI::BusyIndicator* state31Bic;
    SUI::BusyIndicator* state32Bic;
    SUI::BusyIndicator* state33Bic;
    SUI::BusyIndicator* state34Bic;
    SUI::BusyIndicator* state35Bic;
    SUI::BusyIndicator* state36Bic;
    SUI::BusyIndicator* state37Bic;
    SUI::BusyIndicator* state38Bic;
    SUI::BusyIndicator* state39Bic;

    SUI::Label* state31OverlayLabel;
    SUI::Label* state32OverlayLabel;
    SUI::Label* state33OverlayLabel;
    SUI::Label* state34OverlayLabel;
    SUI::Label* state35OverlayLabel;
    SUI::Label* state36OverlayLabel;
    SUI::Label* state37OverlayLabel;
    SUI::Label* state38OverlayLabel;
    SUI::Label* state39OverlayLabel;


    SUI::GroupBox* row1;
    SUI::GroupBox* row2;
    SUI::GroupBox* row3;

    SUI::Label* groupLabel1;
    SUI::Label* groupLabel2;
    SUI::Label* groupLabel3;

    SUI::Container* row1Container;
    SUI::Container* row2Container;
    SUI::Container* row3Container;

    SUI::GroupBox* gbxCurrentState;
    SUI::GroupBox* gbxTransitionState;

    SUI::Label* lblCurrentStateText;
    SUI::Label* lblFromText;
    SUI::Label* lblToText;
    SUI::Label* lblStartTimeText;
    SUI::Label* lblExpectedDurationText;
    SUI::Label* lblElapsedTimeText;

    friend class ::IGSxGUI::SSMTabView;
    void loadGroupObjects(SUI::ObjectList *objectList);
    void setupGroup1Container(const char *xmlFileName, SUI::Container *container);
    void setupGroup2Container(const char *xmlFileName, SUI::Container *container);
    void setupGroup3Container(const char *xmlFileName, SUI::Container *container);
    void loadGroup1Objects(SUI::ObjectList *objectList);
    void loadGroup2Objects(SUI::ObjectList *objectList);
    void loadGroup3Objects(SUI::ObjectList *objectList);
};

}  // namespace SUI
#endif  // IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_HPP
