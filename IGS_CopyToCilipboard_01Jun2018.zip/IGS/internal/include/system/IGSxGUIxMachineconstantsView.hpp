/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Machineconstants View
|
| ! \file        IGSxGUIxMachineconstantsView.hpp
| ! \brief       Header file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxUtils/SUITimer.h>
#include <string>
#include <vector>
#include <utility>
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxFloatArrayParameterpopupView.hpp"
#include "IGSxGUIxHistorypopupView.hpp"
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{
class Node;
class BreadCrumResizer;

struct ascOrderPendingParam {
    bool operator() (const std::pair<std::string, std::string> &data1, const std::pair<std::string, std::string> &data2) {
        return data1.first.compare(data2.first) <= 0;
    }
};

struct desOrderPendingParam {
    bool operator() (const std::pair<std::string, std::string> &data1, const std::pair<std::string, std::string> &data2) {
        return data1.first.compare(data2.first) > 0;
    }
};

class MachineconstantsView : public IMachineconstantsView
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void setActive(bool);

 private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);

    enum moveDirection
    {
       UP = 0,
       DOWN
    }Direction;

    void onHistoryHoverLeft();
    void onHistoryHoverEntered();

    void onUCTSaveButtonClicked();
    void onUCTSaveButtonPressed();
    void onUCTSaveButtonHoverOn();
    void onUCTSaveButtonHoverOff();

    void onSearchTextEditFinished();
    void onSearchAndClearButtonHoverLeft();
    void onSearchAndClearButtonHoverEntered();
    void onSearchTextEdited(const std::string &text);

    void onCancelPressedOnFinalSave();
    void uctPendingParamFinalSaveClicked();
    void PendingParamSaveNameLnEditCancel();
    void uctPendingParamFinalSaveHoverLeft();
    void updateViewOnParamSaveEventReceive();
    void uctPendingParamFinalSaveHoverEntered();

    void init();
    void setHandlers();
    void onBackPressed();
    void onValueChanged();
    void onBackHoverLeft();
    void onHistoryPressed();
    void onBackHoverEntered();
    void onCancelYesPressed();
    void updateParameterTable();
    void onCancelButtonPressed();
    void pendingParamRetrySave();
    void busyIndicatorWindowClose();
    void performPendingParamSaving();
    void onSearchAndClearButtonPressed();
    void onCancelPressedOnSaveErrorPopUpMessage();
    void updateParameterTableOnCancelingFinalSave();
    void setDefaultPropertiesWhenUpdatingParamTable();

    void onPendingParameterRowClosePressed(int rowNumber);
    void pendingParamApplyRowBehavior(int row);
    void onPendingParameterHoverEntered(int row);
    void onPendingParameterHoverLeft(int row);
    void onPendingParameterClicked(int row);
    void onPendingParameterRowCloseHovered(int row);
    void onPendingParameterRowCloseHoverLeft(int row);

    void onParameterRowPressed(int row);
    void onParameterUCTHoverLeft(int row);
    void onParameterUCTHoverEntered(int row);

    void onParameterTreeItemPressed(int rowNUmber);
    int searchForParameters(const std::string &textToSearch);
    void showSaveCancelButtons(bool bShow);
    void showPendingParamWidgets(bool bShow);
    void showFinalSaveScreenItems(bool bShow);
    void showSearchEntriesParameter(bool bShow);
    void configurePendingParamTableRow(size_t i);
    void showNoPendingParameterScreen(bool bShow);
    void showFinalSaveScreenPendingParams(bool bShow);
    void removePendingParamTableRows();
    void PendingParamSaveTxtChanged(const std::string &text);
    void updatePendingParameterList(std::string pendingParamName);
    void moveSaveCancelButtons(const moveDirection& dir, int pixels);
    void setUCTHandlers(SUI::Widget *widget, int row, bool readonly);
    void populateData(std::vector<ParameterData*>::iterator it, int row);
    void PendingParamSaveChangeReasonTxtChanged(const std::string &text);
    void setTableRows(int value, std::vector<ParameterData*> collection);
    void createPopup(const std::string& title, const std::string& message);
    void setData(int value, int rows, std::vector<ParameterData*> collection);
    void initializeTableRows(int rows, std::vector<ParameterData*> collection);
    void onParameterValueChanged(const std::string& name, const std::string& value);
    void UpdatePendingParamTable(const std::string& name, const std::string& value);
    void configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value);
    void refreshTreeViewAndBreadCrums();
    void refreshParameterList();
    void refreshPendingParameterList();
    void onBreadCrump1HoverEntered();
    void onBreadCrump2HoverEntered();
    void onBreadCrump3HoverEntered();
    void onBreadCrump4HoverEntered();
    void onBreadCrump5HoverEntered();
    void onBreadCrump6HoverEntered();

    void onBreadCrump1HoverLeft();
    void onBreadCrump2HoverLeft();
    void onBreadCrump3HoverLeft();
    void onBreadCrump4HoverLeft();
    void onBreadCrump5HoverLeft();
    void onBreadCrump6HoverLeft();

    void onBreadCrump1Clicked();
    void onBreadCrump2Clicked();
    void onBreadCrump3Clicked();
    void onBreadCrump4Clicked();
    void onBreadCrump5Clicked();
    void onBreadCrump6Clicked();

    void onBreadCrumpClicked(int index);
    std::string formatParamaterCatogoryName(const std::string &name);
    void formatParamNameBack(std::string &name);
    int UpperCasePositionBackwards(const std::string& name, int fromPos);
    void changeFinalSaveButtonStyle(const std::string &name, const std::string &reason);
    void adjustDoublePrecision(std::string& paramvalue);
    bool isPendingParamTableScrollBarVisible();
    void adjustCancelSaveButtonGeometryUp();
    void adjustCancelSaveButtonGeometryDown();
    void sortParamsAscending();
    void sortParamsDescending();

    std::pair<std::string, int> formatPendingParamName(const std::string &name);
    std::pair<std::string, int> formatParamName(const std::string &name);
    std::pair<std::string, int> formatDialogParamName(const std::string &name);
    std::pair<std::string, int> formatName(const std::string &name, SUI::Widget *widget, const std::string &type, int width);
    size_t getSplitPosition(const std::string &name, SUI::Widget *widget, const std::string &type, int width);
    void extractSubStr(std::size_t found, int &num_of_rows, std::string &retname, std::string &tmpname);

    void sortPendingParams();
    void formatParamValue(SUI::Widget *widget, std::string &name, int columnWidth);
    int formatParamValueAfterAddingDots(SUI::Widget *widget, std::string &name, int columnWidth);
    void splitToMultilineToolTip(std::string &value, size_t charCount);

    SUI::MachineconstantsView* sui;
    SUI::Dialog* m_dialog;
    int m_selectedParameterRowNum;
    int m_selectedPendingParameterRowNum;
    std::vector<ParameterData> m_tabledata;
    IGSxGUI::ParameterpopupView m_parameterview;
    IGSxGUI::FloatArrayParameterpopupView m_floatArrayDialog;
    IGSxGUI::HistorypopupView m_historyview;

    std::vector<ParameterData*> m_matchedparameters;
    MachineconstantsManager* m_pMachineconstantsManager;
    std::string m_searchText;
    std::vector<SUI::Button*> breadCrumpButtonList;
    BreadCrumResizer* m_breadCrumResizer;
    std::vector<std::pair<std::string, std::string> > m_pendingParameterList;
    IGSxGUI::AwesomeIcon::AwesomeIconEnum m_searchItemIcon;
    bool m_active;

    static const int DIALOG_X;
    static const int DIALOG_Y;
    static const int ROW_HEIGHT;
    static const int MULTILINE_ROW_HEIGHT;
    static const int MULTILINE_ROW_HEIGHT_INCREASE;
    static const int BUTTON_SIZE;
    static const int DIALOG_WIDTH;
    static const int DIALOG_HEIGHT;
    static const int MAX_VISIBLE_ROWS;
    static const int MAX_VISIBLE_ROWS_TOTAL_HEIGHT;
    static const int AWESOME_CLOSE_SIZE;
    static const int PENDINGPARAM_CLOSEBUTTON_SIZE;
    static const int PENDINGPARAM_BI_TIME;
    static const size_t MAX_CHARS_OF_PARAMETERTREE_CELL;
    static const int MAX_CHARS_OF_PARAMS_PER_LINE;
    static const int BOOL_TYPE_DIALOG;
    static const int MAXIMUM_DOUBLE_PRECISION;
    static const int PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT;
    static const int PENDING_PARAM_TABLE_YPOSITION;
    static const int PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE;
    static const size_t MAX_VISIBLE_CHARS_OF_PARAM_VALUE;

    static const std::string IMAGE_LOGO;
    static const std::string DIALOG_TITLE;
    static const std::string DIALOG_MESSAGE;
    static const std::string DIALOG_ID_TITLE;
    static const std::string DIALOG_ID_MESSAGE;
    static const std::string DIALOG_ID_NOBUTTON;
    static const std::string DIALOG_ID_YESBUTTON;
    static const std::string STRING_GREY_REGULAR;
    static const std::string STRING_BLUE_REGULAR;
    static const std::string STYLE_BUTTON_BLUEBG;
    static const std::string COLOR_LINEEDIT_CANCEL;
    static const std::string STYLE_BUTTON_ORANGEBG;
    static const std::string CANCELPOPUP_LOAD_FILE;
    static const std::string STYLE_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETER_FOUND;
    static const std::string STRING_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETERS_FOUND;
    static const std::string STYLE_BUTTON_HOVERBLUEBG;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STYLE_SEARCHPARAM_NOITALIC;
    static const std::string STRING_PENDINGPARAMLABEL_STYLE;
    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;
    static const std::string STYLE_AWESOME_ICONCOLOR;
    static const std::string STYLE_ASML_ORANGELABEL;
    static const std::string STYLE_ACTIVE_CPDLABEL_BLACK;
    static const std::string STYLE_HOVERON;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STRING_CLOSE_BUTTON_COLOR_CLICKED;
    static const std::string PENDINGPARAMCANCEL_CLICKED;
    static const std::string PENDINGPARAMCANCEL_HOVERED;
    static const std::string PENDINGPARAMCANCEL_HOVERLEFT;
    static const std::string COLOR_GREY_DARK;
    static const std::string STYLE_DISABLE_LABEL;
    static const std::string STYLE_DISABLE_BACKGROUND;
    static const std::string STYLE_SEARCH_PARAMETERGREYBGITALIC;
    static const std::string STYLE_SEARCH_PARAMETERGREYBGNONITALIC;
    void onFloatArrayParameterValueChanged(const std::string &name, const std::string &value);
    std::pair<std::string, int> formatFloatArrayDialogParamName(const std::string &name);
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSVIEW_HPP
