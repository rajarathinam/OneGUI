

/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIParameterpopupView.hpp
| Author       : Raja
| Description  : Interface file for Parameterpopup View
|
| ! \file        IGSxGUIxIParameterpopupView.hpp
| ! \brief       Interface file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIPARAMETERPOPUPVIEW_HPP
#define IGSXGUIXIPARAMETERPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIContainer.h>
#include <string>
#include "IGSxCOMMON.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IParameterpopupView
{
 public:
    IParameterpopupView() {}
    virtual ~IParameterpopupView() {}
    virtual void show(int booltype) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIPARAMETERPOPUPVIEW_HPP
