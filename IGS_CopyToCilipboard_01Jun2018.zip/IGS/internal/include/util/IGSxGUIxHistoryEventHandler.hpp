#ifndef IGSXGUIXHISTORYEVENTHANDLER_HPP
#define IGSXGUIXHISTORYEVENTHANDLER_HPP

#include <QObject>
#include <QTableView>
#include <QKeyEvent>
#include <QDebug>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>
#include "IGSxGUIxUtil.hpp"

class IGSxGUIxHistoryEventHandler : public QObject
{
    Q_OBJECT
  public:
    explicit IGSxGUIxHistoryEventHandler(QObject *parent = 0);
    ~IGSxGUIxHistoryEventHandler();
    void setDialog(SUI::Dialog *dialog);
    void setTableWidget(SUI::TableWidget *tableWidget);
    void setHistorypopupView(IGSxGUI::HistorypopupView *historypopupView);
    void setCtrlKeyPressedState(bool *isCtrlKeyPressed);
    void selectAllRows();
    void copySelectedRows();
protected:
    bool eventFilter(QObject *object, QEvent *event);

  private:
    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    bool *m_isCtrlKeyPressed;
    IGSxGUI::HistorypopupView *m_HistorypopupView;


};

#endif // IGSXGUIXHISTORYEVENTHANDLER_HPP
