#ifndef IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP
#define IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QPushButton>
#include <SUIButtonImpl.h>
#include <SUIBaseWidget.h>
#include <vector>

class IGSxGUIxPendingParameterTableHeaderEventHandler : public QObject
{
    Q_OBJECT
 public:
    IGSxGUIxPendingParameterTableHeaderEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void mousePressed();
    void mouseReleased();
    void mouseEnter();
    void mouseLeft();
 protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString rbtn = object->objectName();
        if (mouseEvent->type() == QEvent::MouseButtonPress) {
            mousePressed();
        }
        if (mouseEvent->type() == QEvent::MouseButtonRelease) {
            mouseReleased();
        }
        if (mouseEvent->type() == QEvent::Enter) {
            mouseEnter();
        }
        if (mouseEvent->type() == QEvent::Leave) {
            mouseLeft();
        }
        return object->eventFilter(object, event);
    }
 private:
    QPushButton* parameterName;
    std::vector<SUI::Widget *> m_widgetVector;
    QPushButton* upArrow;
    QPushButton* downArrow;
    QPushButton* upDownArrow;
};
#endif  // IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP
