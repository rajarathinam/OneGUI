#ifndef IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP
#define IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QPushButton>
#include <SUIBaseWidget.h>
#include <SUIButtonImpl.h>
#include <vector>

class IGSxGUIxParameterTableHeaderEventHandler : public QObject
{
    Q_OBJECT
 public:
    IGSxGUIxParameterTableHeaderEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void mousePressed();
    void mouseReleased();
    void mouseEnter();
    void mouseLeft();
 protected:
    bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString rbtn = object->objectName();
        if (mouseEvent->type() == QEvent::MouseButtonPress) {
            mousePressed();
        }
        if (mouseEvent->type() == QEvent::MouseButtonRelease) {
            mouseReleased();
        }
        if (mouseEvent->type() == QEvent::Enter) {
            mouseEnter();
        }
        if (mouseEvent->type() == QEvent::Leave) {
            mouseLeft();
        }
        return object->eventFilter(object, event);
    }
 private:
    std::vector<SUI::Widget *> m_widgetVector;
    QPushButton* parameterNameAsc;
    QPushButton* parameterNameDes;
    QPushButton* upArrow;
    QPushButton* downArrow;
};
#endif  // IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP
