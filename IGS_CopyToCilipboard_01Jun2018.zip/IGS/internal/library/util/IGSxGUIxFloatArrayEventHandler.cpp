#include <QLineEdit>
#include <QPushButton>
#include <vector>
#include <string>
#include "IGSxGUIxFloatArrayEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

IGSxGUIxFloatArrayEventHandler::IGSxGUIxFloatArrayEventHandler(QObject *parent) :
    QObject(parent), totalWidgetCount(0), m_enableIndex(false)
{
}

void IGSxGUIxFloatArrayEventHandler::setWidgetVector(std::vector<SUI::Widget *> widgetVector, std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector)
{
    *m_currentIndex = 0;
    widgetVector.erase(widgetVector.begin());  // Remove the dialog widget
    m_widgetVector = widgetVector;
    m_lineEditWidgetVector = lineEditWidgetVector;
    m_clearButtonWidgetVector = clearButtonWidgetVector;
    totalWidgetCount = m_widgetVector.size();
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 1]);
    btnReset = dynamic_cast<QWidget*>(baseWidget->getWidget());
    baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 2]);
    btnCancel = dynamic_cast<QWidget*>(baseWidget->getWidget());
    baseWidget = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[totalWidgetCount - 3]);
    btnUpdate = dynamic_cast<QWidget*>(baseWidget->getWidget());
    setDefaultStyleToFloatArrayButtons();
}

void IGSxGUIxFloatArrayEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
}


void IGSxGUIxFloatArrayEventHandler::focusPreviousWidget()
{
    setWidgetsToDefaultStyle();
    if (!(*isErrorFound)) {
        if (m_enableIndex) {
            int lineEditFocusedIndex = getCurrentFocusedLineEditIndex();
            if (lineEditFocusedIndex != - 1) {
                *m_currentIndex = lineEditFocusedIndex;
            }
        }
        int totalWidgetCount = static_cast<int>(m_widgetVector.size());
        if (*m_currentIndex == 0) {
            *m_currentIndex = totalWidgetCount - 1;
        } else {
            --(*m_currentIndex);
        }
        focusUtil(*m_currentIndex);
    } else {
        *isErrorFound = false;
        m_enableIndex = true;
        int lineEditFocusedIndex = getCurrentFocusedLineEditIndex();
        if (lineEditFocusedIndex != - 1) {
            *m_currentIndex = lineEditFocusedIndex;
        }
    }
}


void IGSxGUIxFloatArrayEventHandler::focusNextWidget()
{
    setWidgetsToDefaultStyle();
    if (!(*isErrorFound)) {
        int lineEditFocusedIndex = getCurrentFocusedLineEditIndex();
        if (lineEditFocusedIndex != - 1) {
            *m_currentIndex = lineEditFocusedIndex;
        }
        int totalWidgetCount = static_cast<int>(m_widgetVector.size());
        if (*m_currentIndex == (totalWidgetCount - 1)) {
            *m_currentIndex = 0;
        } else {
            ++(*m_currentIndex);
        }
        focusUtil(*m_currentIndex);
    } else {
        *isErrorFound = false;
        m_enableIndex = true;
        int lineEditFocusedIndex = getCurrentFocusedLineEditIndex();
        if (lineEditFocusedIndex != - 1) {
            *m_currentIndex = lineEditFocusedIndex;
        }
    }
}
void IGSxGUIxFloatArrayEventHandler::focusUtil(int index)
{
    SUI::Widget *widget = m_widgetVector[index];
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
    QString widgetClassName(qWidget->metaObject()->className());
    if (widgetClassName == QString("QLineEdit")) {
        IGSxGUI::Util::selectRow(m_tableWidget, index);
        qWidget->setFocus();
        qWidget->setStyleSheet("border-color:#0AA8FB");
    } else if (widgetClassName == QString("CustomPushButton")) {
        qWidget->setStyleSheet("border: 2px dotted blue");
    }
}
void IGSxGUIxFloatArrayEventHandler::setWidgetsToDefaultStyle()
{
    int totalWidgetCount = static_cast<int>(m_widgetVector.size());
    for (int i = 0; i < totalWidgetCount; ++i) {
        SUI::Widget *widget = m_widgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QString widgetClassName(qWidget->metaObject()->className());
        QString style = "";
        if (widgetClassName == QString("QLineEdit")) {
            qWidget->clearFocus();
        } else if (widgetClassName == QString("CustomPushButton")) {
            style = buttonStylesheet;
        }
        qWidget->setStyleSheet(style);
    }
}

void IGSxGUIxFloatArrayEventHandler::showXButtonutil(bool isKeyNavigation)
{
    if(isKeyNavigation == false)
    {
        showXButton();
    } else {

        for (size_t i = 0; i < m_widgetVector.size() - 3; ++i) {
            SUI::Widget *widget = m_widgetVector[i];
            SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
            QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
            QLineEdit *le = dynamic_cast<QLineEdit*>(qWidget);
            SUI::Widget *widget2 = m_clearButtonWidgetVector[i];
            SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widget2);
            QWidget* qWidget2 = dynamic_cast<QWidget*>(baseWidget2->getWidget());
            QPushButton *btn = dynamic_cast<QPushButton*>(qWidget2);
            if (le->hasFocus() && le->text() != "") {
                if ((!isKeyNavigation)) {
                    le->setStyleSheet("border-color:#0AA8FB");
                }
                btn->setVisible(true);
                *m_currentIndex = i;
                le->deselect();
            } else {
                if (!isKeyNavigation)   {
                    le->setStyleSheet("border-color:grey");
                    setDefaultStyleToFloatArrayButtons();
                }
                btn->setVisible(false);
            }
        }    
    }
}
void IGSxGUIxFloatArrayEventHandler::showXButton()
{
    for (int i = 0; i < static_cast<int>(m_lineEditWidgetVector.size()); ++i) {
        SUI::Widget *widget = m_lineEditWidgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QLineEdit *le = dynamic_cast<QLineEdit*>(qWidget);

        SUI::Widget *widget2 = m_clearButtonWidgetVector[i];
        SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widget2);
        QWidget* qWidget2 = dynamic_cast<QWidget*>(baseWidget2->getWidget());
        QPushButton *btn = dynamic_cast<QPushButton*>(qWidget2);

        if (le->hasFocus() && le->text() != "")
        {
            btn->setVisible(true);
            le->deselect();
            *m_currentIndex = i;

        } else {
            btn->setVisible(false);
            /*
            if(widget->getStyleSheetClass() != std::string("floatArrayLeWarning"))
                        {
                widget->setStyleSheetClass("floatArrayLe");
            }*/
        }
    }
}


void IGSxGUIxFloatArrayEventHandler::setErrorFoundFlag(bool *errorFound)
{
    isErrorFound = errorFound;
}

void IGSxGUIxFloatArrayEventHandler::setCurrentIndex(int *currentIndex)
{
    m_currentIndex = currentIndex;
}

void IGSxGUIxFloatArrayEventHandler::showXButtonForKeyNavigation()
{
    showXButtonutil(true);
}

void IGSxGUIxFloatArrayEventHandler::setDefaultStyleToFloatArrayButtons()
{
    btnReset->setStyleSheet("border: 1px solid #0AA8FB;color:#0AA8FB;font-family: 'Roboto regular', 'Roboto';font-size: 14px;");
    btnCancel->setStyleSheet("border: 1px solid #0AA8FB;color:#0AA8FB;font-family: 'Roboto regular', 'Roboto';font-size: 14px;");
    btnUpdate->setStyleSheet("background-color: #0AA8FB;color:#FFFFFF;font-family: 'Roboto regular', 'Roboto';font-size: 14px;border:0px");
}

void IGSxGUIxFloatArrayEventHandler::showXButtonForMouseClick(std::string objName)
{
    if (objName.find("lne-TFAP") != std::string::npos || objName.find("lne-tawFloatArrayParamaterPopup") != std::string::npos) {
        showXButtonutil(false);
    }
}

int IGSxGUIxFloatArrayEventHandler::getCurrentFocusedLineEditIndex()
{
    int result = -1;
    int vecSize = m_widgetVector.size() - 3;
    for (int i = 0; i < vecSize ; ++i) {
        SUI::Widget *widget = m_widgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QLineEdit *le = dynamic_cast<QLineEdit*>(qWidget);
        if (le->hasFocus()) {
            result = i;
            break;
        }
    }
    return result;
}
