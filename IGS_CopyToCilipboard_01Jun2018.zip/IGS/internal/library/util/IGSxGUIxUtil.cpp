/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation file for Utility class
|
| ! \file        IGSxGUIxUtil.cpp
| ! \brief       Implementation file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxUtil.hpp"
#include <FWQxWidgets/SUIDialog.h>
#include <SUIBaseWidget.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <SUITableWidgetImpl.h>
#include <SUILabelImpl.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIWebView.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUITextArea.h>
#include <QDialog>
#include <QScrollArea>
#include <QApplication>
#include <QTableView>
#include <QHeaderView>
#include <QLabel>
#include <QCheckBox>
#include <QPushButton>
#include <QTableWidgetItem>
#include <QTextCodec>
#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QMovie>
#include <QGroupBox>
#include <QLineEdit>
#include <QRadioButton>
#include <QChar>
#include <QString>
#include <QtWebKit/QWebView>
#include <QFontMetrics>
#include <QToolTip>
#include <QScrollBar>
#include <QTextEdit>
#include <string>
#include <algorithm>
#include <sstream>
#include <vector>
#include "IGSxGUIxFloatArrayEventHandler.hpp"
#include "IGSxGUIxRadioButtonEventHandler.hpp"
#include "IGSxGUIxHistoryEventHandler.hpp"
#include "IGSxGUIxParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxPendingParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxHistoryTableHeaderEventHandler.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Util::Util()
{
}

void IGSxGUI::Util::setIcon(SUI::Widget* widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string &color, const int size)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QChar character;
    switch (icon) {
    case IGSxGUI::AwesomeIcon::AI_fa_exclamation: {
        const QChar exclamation(0xf12a);
        character = exclamation;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle: {
        const QChar exclamationTriangle(0xf071);
        character = exclamationTriangle;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_times: {
        const QChar times(0xf00d);
        character = times;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_times_circle: {
        const QChar timesCircle(0xf057);
        character = timesCircle;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_bell: {
        const QChar bell(0xf0f3);
        character = bell;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_sort_desc: {
        const QChar downArrow(0xf0dd);
        character = downArrow;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_sort_asc: {
        const QChar upArrow(0xf0de);
        character = upArrow;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_sort_default: {
        const QChar defaultArrows(0xf0dc);
        character = defaultArrows;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_copyright: {
        const QChar copyright(0xf1f9);
        character = copyright;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_cog: {
        const QChar cog(0xf013);
        character = cog;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_sliders: {
        const QChar slider(0xf1de);
        character = slider;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_dashboard: {
        const QChar dashboard(0xf0e4);
        character = dashboard;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_sitemap: {
        const QChar sitemap(0xf0e8);
        character = sitemap;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_checkcircle: {
        const QChar checkcircle(0xf058);
        character = checkcircle;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_clock: {
        const QChar clock(0xf017);
        character = clock;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_crosshairs: {
        const QChar crosshairs(0xf05b);
        character = crosshairs;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_areachart: {
        const QChar areachart(0xf1fe);
        character = areachart;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_stethoscope: {
        const QChar stethoscope(0xf0f1);
        character = stethoscope;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_check: {
        const QChar check(0xf00c);
        character = check;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        const QChar check(0xf00d);
        character = check;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_angle_left: {
        const QChar angleleft(0xf104);
        character = angleleft;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_angle_right: {
        const QChar angleright(0xf105);
        character = angleright;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_angle_down: {
        const QChar angledown(0xf107);
        character = angledown;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_search: {
        const QChar search(0xf002);
        character = search;
        break;
    }
    case IGSxGUI::AwesomeIcon::AI_fa_save: {
        const QChar save(0xf0c7);
        character = save;
        break;
    }
    default: {
        const QChar defaultIcon(0xf2c2);
        character = defaultIcon;
        break;
    }
    }
    switch (baseWidget->getObjectType()) {
    case SUI::ObjectType::Label: {
        QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
        if (qlabel != NULL) {
            IGSxGUI::Util::setAwesomeStyle(baseWidget, color, size);
            qlabel->setText(character);
        }
        break;
    }
    case SUI::ObjectType::Button: {
        QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
        if (qpushbutton != NULL) {
            IGSxGUI::Util::setAwesomeStyle(baseWidget, color, size);
            qpushbutton->setText(character);
        }
        break;
    }
    case SUI::ObjectType::TableWidgetItem: {
        QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(baseWidget);
        if (tableItem != NULL) {
            tableItem->setFont(QFont("FontAwesome"));
            QTextCodec::setCodecForCStrings(QTextCodec::codecForName("utf8"));
            tableItem->setText(character);
            setColor(widget, SUI::ColorEnum::fromString(color), NULL);
        }
        break;
    }
    default: {
        // We do not support all widgets
        break;
    }
    }
}

void IGSxGUI::Util::setGeometry(SUI::Widget* widget, int x, int y, int width, int height)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    if (qwidget != NULL) {
        QWidget* qparent = qwidget->parentWidget();
        qwidget->setGeometry(x, qparent->y() + y, width, height);
    }
}

void IGSxGUI::Util::setWindowFrame(SUI::Dialog* dialog, bool enable)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL) {
        if (enable) {
            qdialog->setWindowFlags(Qt::Dialog);
        } else {
            qdialog->setWindowFlags(Qt::Sheet | Qt::FramelessWindowHint);
            qdialog->setFixedSize(qdialog->geometry().width(), qdialog->geometry().height());
        }
    }
}

void IGSxGUI::Util::disableScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL) {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");
        if (scrollArea != NULL) {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
    }
}

void IGSxGUI::Util::disableFloatArrayScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    int height = qdialog->height();
    if (qdialog != NULL) {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");
        if (scrollArea != NULL) {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setWidgetResizable(true);
            scrollArea->setMaximumHeight(height);
        }
    }
}

void IGSxGUI::Util::setParent(SUI::Widget* widget, SUI::Widget *parent)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    SUI::BaseWidget* suiparent = dynamic_cast<SUI::BaseWidget*>(parent);
    QWidget* topWidget = suiparent->getWidget()->nativeParentWidget();
    qwidget->setParent(topWidget);
}

void IGSxGUI::Util::processEvents()
{
    QApplication::processEvents();
}

const std::string IGSxGUI::Util::elideText(const std::string& str, int fontsize, int width)
{
    std::string elidedtext = str;
    if ((width > 0) && (!str.empty())) {
        QFont font("Roboto", fontsize);
        QFontMetrics fm(font);
        QString intext(str.c_str());
        QString outtext = fm.elidedText(intext, Qt::ElideRight, width);
        // To do , last char is not printable char('...')
        QChar ch = outtext.at(outtext.length() - 1);
        if (!static_cast<bool>(ch.toAscii())) {
            outtext.chop(4);
            elidedtext = outtext.toStdString() + "...";
        } else {
            elidedtext = outtext.toStdString();
        }
    }
    return elidedtext;
}

void IGSxGUI::Util::sort(int column, SUI::TableWidget* widget, SortOrder::SortOrderEnum order)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableWidget = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QAbstractItemModel* m = tableWidget->model();
    m->sort(column, (order == SortOrder::Descending)? Qt::DescendingOrder : Qt::AscendingOrder);
}

void IGSxGUI::Util::setScalable(SUI::TableWidget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    tableView->verticalHeader()->setResizeMode(QHeaderView::ResizeToContents);
}

void IGSxGUI::Util::setAwesome(SUI::Widget *widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, const std::string &color, const int size)
{
    IGSxGUI::Util::setIcon(widget, icon, color, size);
}

void IGSxGUI::Util::setAwesome(SUI::Widget *widget, IGSxGUI::AwesomeIcon::AwesomeIconEnum icon, SUI::ColorEnum::Color color, const int size)
{
    IGSxGUI::Util::setIcon(widget, icon, SUI::ColorEnum::toString(color), size);
}

void IGSxGUI::Util::setAwesomeStyle(SUI::BaseWidget *baseWidget, const std::string &customcolor, const int size)
{
    QString style("font-family: FontAwesome;");
    if (customcolor != "") {
        style.append("color: " + QString::fromStdString(customcolor) + ";");
    }
    if (size != NO_SIZE) {
        style.append("font-size: " + QString::number(size) + "px;");
    }
    switch (baseWidget->getObjectType()) {
    case SUI::ObjectType::Label: {
        QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
        if (qlabel != NULL) {
            qlabel->setStyleSheet(style);
        }
        break;
    }
    case SUI::ObjectType::Button: {
        QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
        if (qpushbutton != NULL) {
            qpushbutton->setStyleSheet(style);
        }
        break;
    }
    default: {
        // We do not support all widgets
        break;
    }
    }
}

void IGSxGUI::Util::setColor(SUI::Widget* widget, SUI::ColorEnum::Color color, SUI::TableWidget* tableWidget)
{
    QTableWidgetItem* tableItem = dynamic_cast<QTableWidgetItem*>(widget);
    if (tableItem != NULL) {
        switch (color) {
        case SUI::ColorEnum::White: {
            tableItem->setForeground(Qt::white);
            break;
        }
        case SUI::ColorEnum::Red: {
            tableItem->setForeground(Qt::red);
            break;
        }
        case SUI::ColorEnum::Yellow: {
            tableItem->setForeground(Qt::yellow);
            break;
        }
        case SUI::ColorEnum::Blue: {
            const int ALERTTABLE_FGCOLOR_RED = 10;
            const int ALERTTABLE_FGCOLOR_GREEN = 168;
            const int ALERTTABLE_FGCOLOR_BLUE = 251;
            tableItem->setForeground(QColor::fromRgb(ALERTTABLE_FGCOLOR_RED, ALERTTABLE_FGCOLOR_GREEN, ALERTTABLE_FGCOLOR_BLUE));
            break;
        }
        case SUI::ColorEnum::Black: {
            tableItem->setForeground(Qt::black);
            break;
        }
        case SUI::ColorEnum::Gray: {
            tableItem->setForeground(Qt::gray);
            break;
        }
        default: {
            tableItem->setForeground(Qt::white);
            break;
        }
        }
        if (tableWidget != NULL) {
            SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
            QTableView* tableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
            tableView->update();
        }
    }
}

void IGSxGUI::Util::addLabel(SUI::TableWidget *tableWidget, int row, int column)
{
    SUI::TableWidgetImpl* tableWidgetImpl = dynamic_cast<SUI::TableWidgetImpl*>(tableWidget);
    SUI::BaseWidget* newWidget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::Label, tableWidgetImpl->getWidget());
    newWidget->setVisible(false);
    newWidget->addCellProperties(SUI::AlignmentEnum::Stretch);
    SUI::Widget *w = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(newWidget));
    tableWidgetImpl->updateCell(row, column, SUI::AlignmentEnum::HCenter, w);
    newWidget->setVisible(true);
}

void IGSxGUI::Util::addButton(SUI::TableWidget *tableWidget, int row, int column)
{
    SUI::TableWidgetImpl* tableWidgetImpl = dynamic_cast<SUI::TableWidgetImpl*>(tableWidget);
    SUI::BaseWidget* newWidget = SUI::ObjectFactory::getInstance()->createWidget(SUI::ObjectType::Button, tableWidgetImpl->getWidget());
    newWidget->setVisible(false);
    newWidget->addCellProperties(SUI::AlignmentEnum::Stretch);
    SUI::Widget *w = dynamic_cast<SUI::Widget*>(SUI::ObjectFactory::getInstance()->toObject(newWidget));
    tableWidgetImpl->updateCell(row, column, SUI::AlignmentEnum::HCenter, w);
    newWidget->setVisible(true);
}

void IGSxGUI::Util::setTranslucentBackground(SUI::Dialog *dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL) {
        Qt::WindowFlags flags = qdialog->windowFlags();
        qdialog->setWindowFlags(flags | Qt::WindowStaysOnTopHint);
        qdialog->setAttribute(Qt::WA_TranslucentBackground);
    }
}

void IGSxGUI::Util::setFadeOut(SUI::Dialog* dialog, int duration)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL) {
        QGraphicsOpacityEffect *effect = new QGraphicsOpacityEffect(qdialog);
        // qdialog is being passed as parent to QGraphicsOpacityEffect.
        // memory of QGraphicsOpacityEffect object will be released once parent sui->dialog is deleted
        qdialog->setGraphicsEffect(effect);
        QPropertyAnimation *animation = new QPropertyAnimation(effect, "opacity");
        animation->setDuration(duration);
        animation->setStartValue(1);
        animation->setEndValue(0);
        animation->setEasingCurve(QEasingCurve::Linear);
        // animation object will be deleted/released once the animation is stopped (by the property QPropertyAnimation::DeleteWhenStopped)
        animation->start(QPropertyAnimation::DeleteWhenStopped);
    }
}

void IGSxGUI::Util::setImageToLabel(SUI::Label* label, SUI::Dialog *dialog, const std::string &resourcepath)
{
    SUI::LabelImpl* labelimpl = dynamic_cast<SUI::LabelImpl*>(label);
    QLabel *progressbarLabel = labelimpl->getWidget();
    if (progressbarLabel != NULL) {
        QString pathProgressbar = QString::fromUtf8(resourcepath.c_str());
        QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
        QMovie *movie = new QMovie(pathProgressbar, QByteArray(), qdialog);
        // qdialog is being passed as parent to QMovie.
        // memory of QMovie object will be released once parent sui->dialog is deleted
        if (movie->isValid()) {
            progressbarLabel->setMovie(movie);
            movie->start();
        }
    }
}
void IGSxGUI::Util::clearSelection(SUI::TableWidget *tableWidget)
{
    SUI::TableWidgetImpl* tableWidgetImpl = dynamic_cast<SUI::TableWidgetImpl*>(tableWidget);
    tableWidgetImpl->getWidget()->clearSelection();
}

void IGSxGUI::Util::setRowHeight(SUI::TableWidget *tableWidget, int row,  int height)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->setRowHeight(row, height);
}

int IGSxGUI::Util::getRowHeight(SUI::TableWidget *tableWidget, int row)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    return qTableView->rowHeight(row);
}

void IGSxGUI::Util::setColumnWidth(SUI::TableWidget *tableWidget, int column, int width)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->setColumnWidth(column, width);
}


void IGSxGUI::Util::setTextToHistoryParameterUserControl(SUI::Widget* widget, int index, const std::string &text)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    if (baseWidget != NULL) {
        QObject* object = baseWidget->getWidget()->children().at(0);
        QObjectList sublist = object->children();
        QLabel* qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
        if (qlabel != NULL) {
            if (index == 5) {
                QString qString(text.c_str());
                QStringList textList = qString.split('\n');
                QString newText = qString;
                if (textList.count() > 1)
                {
                    newText = textList[0].append("...");
                    newText = qlabel->fontMetrics().elidedText(newText, Qt::ElideRight, 200);
                } else {
                    newText = qlabel->fontMetrics().elidedText(QString(text.c_str()), Qt::ElideRight, 200);
                }
                qlabel->setText(newText);
            } else {
                qlabel->setText(QString(text.c_str()));
            }
        }
    }
}

void IGSxGUI::Util::setTextToParameterUserControl(SUI::Widget* widget, int index, const std::string &text)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject* object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
    if (index == 2) {
        const QChar angleright(0xf105);
        QChar character = angleright;
        qlabel->setStyleSheet("border:0px;font-family: FontAwesome; color:black; font-size:16px");
        qlabel->setText(character);
    } else {
        qlabel->setText(QString::fromStdString(text));
    }
}

std::string IGSxGUI::Util::getTextFromParameterUserControl(SUI::Widget* widget, int index)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject* object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
    std::string str  = qlabel->text().toStdString();
    return str;
}

std::vector<std::string> IGSxGUI::Util::getReportURLfromTestReportTable(SUI::TableWidget *tableWidget)
{
    std::vector<std::string> listURL;
    for (int i = 0; i < tableWidget->rowCount() ; i++) {
        SUI::Widget *widget = tableWidget->getWidgetItem(i, 0);
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QObject *object = baseWidget->getWidget()->children().at(0);
        QObjectList sublist = object->children();
        QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
        if (qcb->isChecked()) {
            QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(3));
            listURL.push_back(qlabel->text().toStdString());
        }
    }
    return listURL;
}

void IGSxGUI::Util::setTextToADTUserControl(SUI::Widget* widget, int index, const std::string &text)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
    if (index == 2) {
        const QChar angleright(0xf105);
        QChar character = angleright;
        QString style = "border:0px;font-family: FontAwesome; color:black; font-size:16px";
        qlabel->setStyleSheet(style);
        qlabel->setText(character);
    } else {
        QString threespaces("   ");
        qlabel->setText(threespaces + QString::fromStdString(text));
    }
}

void IGSxGUI::Util::setTextToSystemToolUserControl(SUI::Widget *widget, int index, const std::string &text)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
    if (index == 1) {
        const QChar angleright(0xf105);
        QChar character = angleright;
        QString style = "border:0px;font-family: FontAwesome; color:black; font-size:16px";
        qlabel->setStyleSheet(style);
        qlabel->setText(character);
    } else {
        QString threespaces("   ");
        qlabel->setText(threespaces + QString::fromStdString(text));
    }
}
void IGSxGUI::Util::setTextToCPDUserControl(SUI::Widget* widget, int index, const std::string &text)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
    if (index == 3) {
        const std::string CALIBRATION = "Calibration";
        const std::string PERFORMANCE = "Performance";
        const std::string DIAGNOSTICS = "Diagnostics";
        QChar character;
        if (text == CALIBRATION) {
            QChar calibration(0xf05b);
            character = calibration;
        } else if (text == PERFORMANCE) {
            QChar performance(0xf1fe);
            character = performance;
        } else if (text == DIAGNOSTICS) {
            QChar diagnostics(0xf0f1);
            character = diagnostics;
        }
        QLabel *qlabelIcon =  dynamic_cast<QLabel*>(sublist.at(2));
        QString style = "border:0px;font-family: FontAwesome; color:#8c8c8c; font-size:16px";
        qlabelIcon->setStyleSheet(style);
        qlabelIcon->setText(character);
        qlabel->setText(QString::fromStdString(text));
    } else if (index == 4) {
        const QChar angleright(0xf105);
        QChar character = angleright;
        QString style = "border:0px;font-family: FontAwesome; color:black; font-size:16px";
        qlabel->setStyleSheet(style);
        qlabel->setText(character);
    } else {
        QString threespaces("   ");
        qlabel->setText(threespaces + QString::fromStdString(text));
    }
}

void IGSxGUI::Util::setCheckToTestReportUserControl(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    qcb->setChecked(!qcb->isChecked());
}

void IGSxGUI::Util::setUnCheckToTestReportUserControl(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    qcb->setChecked(false);
}

std::string IGSxGUI::Util::getADTCPDNameFromUserControl(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(0));
    QString str = qlabel->text();
    return str.toStdString();
}

int IGSxGUI::Util::getNumCheckedRows(SUI::TableWidget *tableWidget)
{
    int count = 0;
    for (int i = 0; i < tableWidget->rowCount() ; i++) {
        SUI::Widget *widget = tableWidget->getWidgetItem(i, 0);
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QObject *object = baseWidget->getWidget()->children().at(0);
        QObjectList sublist = object->children();
        QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
        if (qcb->isChecked()) {
            ++count;
        }
    }
    return count;
}
void IGSxGUI::Util::setADTUCTNormalStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#4d4d4d;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
    QLabel *qlabel3 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel3->setStyleSheet("font-family: FontAwesome;color:black;");
}
void IGSxGUI::Util::setADTUCTClickedStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#1b3e92;color:white;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("color:white;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("font-family: 'Roboto Medium', 'Roboto Regular', 'Roboto';font-size:14px;color:white;");
    QLabel *qlabel3 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel3->setStyleSheet("font-family: FontAwesome;color:white;");
}

void IGSxGUI::Util::setSystemToolUCTNormalStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#4d4d4d;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("font-family: FontAwesome;color:black;");
}

void IGSxGUI::Util::setSystemToolUCTClickedStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#1b3e93;color:white;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("font-family: 'Roboto Regular', 'Roboto';color:white;font-size:16px;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("font-family: FontAwesome;color:white;");
}

void IGSxGUI::Util::setUCTHoverOnStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    const QString hoverOnStyle("background-color:#DAF2FE;color:white;");
    qGroupBox->setStyleSheet(hoverOnStyle);
}
void IGSxGUI::Util::setUCTHoverOffStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    const QString hoverOfStyle("background-color:white;color:black;");
    qGroupBox->setStyleSheet(hoverOfStyle);
}

void IGSxGUI::Util::setSystemToolUCTHoverOnStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    const QString hoverOnStyle("background-color:#DAF2FE;color:white;");
    qGroupBox->setStyleSheet(hoverOnStyle);
}

void IGSxGUI::Util::setSystemToolUCTHoverOffStyle(SUI::Widget *widget)
{
    setSystemToolUCTNormalStyle(widget);
}

void IGSxGUI::Util::setTestReportUCTHoverOnStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    if (qcb->isChecked()) {
        setTestReportUCTClickedStyle(widget);
    } else {
        QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
        const QString hoverOnStyle("background-color:#DAF2FE;");
        qGroupBox->setStyleSheet(hoverOnStyle);
    }
}

void IGSxGUI::Util::setTestReportUCTHoverOffStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    if (qcb->isChecked()) {
        setTestReportUCTClickedStyle(widget);
    } else {
        const QString hoverOfStyle("background-color:white;");
        QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
        qGroupBox->setStyleSheet(hoverOfStyle);
        QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
        qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
        QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
        qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
    }
}

void IGSxGUI::Util::setCPDUCTNormalStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
    QObjectList sublist = object->children();
    QLabel *qlabel0 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel0->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#4d4d4d;");
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel2->setStyleSheet("border:0px;font-family: FontAwesome; color:#8c8c8c; font-size:16px");
    QLabel *qlabel3 =  dynamic_cast<QLabel*>(sublist.at(3));
    qlabel3->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
    QLabel *qlabel4 =  dynamic_cast<QLabel*>(sublist.at(4));
    qlabel4->setStyleSheet("font-family: FontAwesome;color:black;");
}
void IGSxGUI::Util::setCPDUCTClickedStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#1b3e92;color:white;");
    QObjectList sublist = object->children();
    QLabel *qlabel0 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel0->setStyleSheet("color:white;");
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel1->setStyleSheet("font-family: 'Roboto Medium', 'Roboto Regular', 'Roboto';font-size:14px;color:white;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel2->setStyleSheet("font-family: FontAwesome;color:white;");
    QLabel *qlabel3 =  dynamic_cast<QLabel*>(sublist.at(3));
    qlabel3->setStyleSheet("font-family: 'Roboto Medium', 'Roboto Regular', 'Roboto';font-size:14px;color:white;");
    QLabel *qlabel4 =  dynamic_cast<QLabel*>(sublist.at(4));
    qlabel4->setStyleSheet("font-family: FontAwesome;color:white;");
}

void IGSxGUI::Util::setTestReportUCTNormalStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    qcb->setStyleSheet("QCheckBox::indicator{background-color:white}");
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:#8c8c8c;");
}

void IGSxGUI::Util::setTestReportUCTClickedStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#1b3e92;color:white;border: 1px solid #8B97BB;border-left:0px;border-right:0px;border-top:0px;");
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    qcb->setStyleSheet("QCheckBox::indicator{background-color:#DEDEDE}");
    qcb->setStyleSheet("border:0px;");
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:white;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:white;");
}
void IGSxGUI::Util::setTestReportUCTDisabledStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#E2E2E2;color:white;");
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    qcb->setStyleSheet("QCheckBox::indicator{background-color:#DEDEDE}");
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:grey;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(2));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:14px;color:grey;");
}

bool IGSxGUI::Util::isTestReportSelected(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QCheckBox *qcb =  dynamic_cast<QCheckBox*>(sublist.at(0));
    return (qcb->isChecked());
}

void IGSxGUI::Util::setParameterUCTGroupBoxNormalStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
}

void IGSxGUI::Util::setParameterUCTNormalStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#FFFFFF;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
}

void IGSxGUI::Util::setParameterUCTClickedStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#1b3e93;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("color:white;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("font-family: 'Roboto Medium', 'Roboto Regular', 'Roboto';font-size:16px;color:white;");
}

void IGSxGUI::Util::setParameterUCTReadOnlyStyle(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#E2E2E2;");
    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
}
void IGSxGUI::Util::setParameterUCTBoldStyle(SUI::Widget *widget, int index)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(index));
    QString style = "color:#000000; font-weight:bold;";
    qlabel2->setStyleSheet(style);
}
void IGSxGUI::Util::setParameterUCTGreyStyle(SUI::Widget *widget, int index)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(index));
    QString style = "color:#666666;";
    qlabel2->setStyleSheet(style);
}
void IGSxGUI::Util::setParameterUCTValueNormalStyle(SUI::Widget *widget, int index)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(index));
    QString style = "color:#000000;";
    qlabel2->setStyleSheet(style);
}
void IGSxGUI::Util::setParameterUCTHoverOnStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:#DAF2FE;");

    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
}
void IGSxGUI::Util::setParameterUCTHoverOffStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
    qGroupBox->setStyleSheet("background-color:white;");

    QObjectList sublist = object->children();
    QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(0));
    qlabel1->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
    QLabel *qlabel2 =  dynamic_cast<QLabel*>(sublist.at(1));
    qlabel2->setStyleSheet("border:0px;font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;");
}
void IGSxGUI::Util::setUnderline(SUI::Widget *widget, bool isUnderline)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QString style;
    if (isUnderline) {
        style = "text-decoration: underline;";
    } else {
        style = "text-decoration: none;";
    }
    switch (baseWidget->getObjectType()) {
    case SUI::ObjectType::Label: {
        QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
        if (qlabel != NULL) {
            qlabel->setStyleSheet(style);
        }
        break;
    }
    case SUI::ObjectType::Button: {
        QPushButton* qpushbutton = dynamic_cast<QPushButton*>(baseWidget->getWidget());
        if (qpushbutton != NULL) {
            qpushbutton->setStyleSheet(style);
        }
        break;
    }
    default: {
        // We do not support all widgets
        break;
    }
    }
}

void IGSxGUI::Util::selectRow(SUI::TableWidget *tableWidget, int row)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* tableview = dynamic_cast<QTableView*>(baseWidget->getWidget());
    tableview->selectRow(row);
}
void IGSxGUI::Util::selectHistoryRow(SUI::TableWidget *tableWidget, int row)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* tableview = dynamic_cast<QTableView*>(baseWidget->getWidget());
    tableview->setSelectionMode(QAbstractItemView::MultiSelection);
    tableview->setSelectionBehavior(QAbstractItemView::SelectRows);
    QModelIndex index = tableview->model()->index(row, 0);
    tableview->selectionModel()->select(index, QItemSelectionModel::Select);

}
void IGSxGUI::Util::deselectHistoryRow(SUI::TableWidget *tableWidget, int row)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* tableview = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QModelIndex index = tableview->model()->index(row, 0);
    tableview->selectionModel()->select(index, QItemSelectionModel::Deselect);
}

std::vector<int> IGSxGUI::Util::getSelectedRowIndexes(SUI::TableWidget *tableWidget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* tableview = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QItemSelectionModel *selection = tableview->selectionModel();
    std::vector<QModelIndex> listModelIndex = selection->selectedRows().toVector().toStdVector();
    std::vector<int> selectedRows;
    foreach (QModelIndex index, listModelIndex) {
        selectedRows.push_back(index.row());
    }
    return selectedRows;
}
void IGSxGUI::Util::addCustomStylesheet(SUI::WebView *webviewWidget, std::string url)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(webviewWidget);
    QWebView* webview = dynamic_cast<QWebView*>(baseWidget->getWidget());
    webview->settings()->setUserStyleSheetUrl(QUrl::fromLocalFile(QString::fromStdString(url)));
}

void IGSxGUI::Util::executeDialog(SUI::Dialog *dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    qdialog->exec();
}

void IGSxGUI::Util::quitDialog(SUI::Dialog *dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    qdialog->close();
}

void IGSxGUI::Util::setWordWrap(SUI::Widget *widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
    qlabel->setWordWrap(true);
}

void IGSxGUI::Util::setTextToTestReportUserControl(SUI::Widget* widget, int index, const std::string &text)
{
    if (index != 0) {
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QObject *object = baseWidget->getWidget()->children().at(0);
        QObjectList sublist = object->children();
        QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(index));
        qlabel->setText(QString(text.c_str()));
    }
}
void IGSxGUI::Util::setParameterHistoryClickedStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    if (baseWidget != NULL) {
        QObject *object = baseWidget->getWidget()->children().at(0);
        QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
        if (qGroupBox != NULL) {
            qGroupBox->setStyleSheet("background-color:#1b3e93;");
        }
        QObjectList sublist = object->children();
        for (int i = 0; i < sublist.size(); ++i) {
            QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(i));
            if (qlabel1 != NULL) {
                qlabel1->setStyleSheet("color:white;padding-right:10px");
            }
        }
    }
}
void IGSxGUI::Util::setParameterHistoryHoverEnteredStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    if (baseWidget != NULL) {
        QObject *object = baseWidget->getWidget()->children().at(0);
        QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
        if (qGroupBox != NULL) {
            qGroupBox->setStyleSheet("background-color:#DAF2FE;color:black;");
        }
    }
}


void IGSxGUI::Util::setParameterHistoryNormalStyle(SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    if (baseWidget != NULL) {
        QObject *object = baseWidget->getWidget()->children().at(0);
        QGroupBox *qGroupBox =  dynamic_cast<QGroupBox*>(object);
        if (qGroupBox != NULL) {
            qGroupBox->setStyleSheet("background-color:white;");
        }
        QObjectList sublist = object->children();
        for (int i = 0; i < sublist.size(); ++i) {
            QLabel *qlabel1 =  dynamic_cast<QLabel*>(sublist.at(i));
            if (qlabel1 != NULL) {
                qlabel1->setStyleSheet("font-family: 'Roboto Medium','Roboto Regular', 'Roboto';font-size:16px;color:#666666;padding-right:10px");
            }
        }
    }
}

int IGSxGUI::Util::getLineEditCursorPosition(SUI::LineEdit* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QLineEdit* le = dynamic_cast<QLineEdit*>(baseWidget->getWidget());
    return le->cursorPosition();
}

void IGSxGUI::Util::setLineEditCursorPosition(SUI::LineEdit* widget, int pos)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QLineEdit* le = dynamic_cast<QLineEdit*>(baseWidget->getWidget());
    le->setCursorPosition(pos);
}

int IGSxGUI::Util::getCharWidthOfLableInTableColumn(const std::string& str, SUI::Widget* widget, int column)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QObject *object = baseWidget->getWidget()->children().at(0);
    QObjectList sublist = object->children();
    QLabel *qlabel =  dynamic_cast<QLabel*>(sublist.at(column));
    QFont font(qlabel->font().family(), qlabel->font().pixelSize());
    QFontMetrics fm(font);
    return fm.width(QString::fromStdString(str));
}

int IGSxGUI::Util::getCharWidthOfLabel(const std::string& str, SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QLabel* qlabel = dynamic_cast<QLabel*>(baseWidget->getWidget());
    QFont font(qlabel->font().family(), qlabel->font().pixelSize());
    QFontMetrics fm(font);
    return fm.width(QString::fromStdString(str));
}

void IGSxGUI::Util::selectLineEditText(SUI::LineEdit* widget) {
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QLineEdit* le = dynamic_cast<QLineEdit*>(baseWidget->getWidget());
    le->selectAll();
}

void IGSxGUI::Util::setDialogHeight(SUI::Dialog* dialog, int height)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    qdialog->setFixedHeight(height);
}

void IGSxGUI::Util::setDialogWidth(SUI::Dialog* dialog, int width)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    qdialog->setFixedWidth(width);
}

void IGSxGUI::Util::scrollTo(SUI::TableWidget *tableWidget, int row)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QScrollBar *vertScrollbar = qTableView->verticalScrollBar();
    vertScrollbar->setValue(row);
}

void IGSxGUI::Util::connectFloatArrayTablesScrollbars(SUI::TableWidget *tableWidget1, SUI::TableWidget *tableWidget2)
{
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(tableWidget1);
    QTableView* qTableView1 = dynamic_cast<QTableView*>(baseWidget1->getWidget());
    QScrollBar *vertScrollbar1 = qTableView1->verticalScrollBar();

    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(tableWidget2);
    QTableView* qTableView2 = dynamic_cast<QTableView*>(baseWidget2->getWidget());
    QScrollBar *vertScrollbar2 = qTableView2->verticalScrollBar();

    vertScrollbar2->setStyleSheet("QScrollBar{width: 0px;}");
    vertScrollbar2->setVisible(false);

    QObject::connect(vertScrollbar1, SIGNAL(valueChanged(int)), vertScrollbar2, SLOT(setValue(int)));
    QObject::connect(vertScrollbar2, SIGNAL(valueChanged(int)), vertScrollbar1, SLOT(setValue(int)));
}


void IGSxGUI::Util::disableTableScrollbar(SUI::TableWidget *tableWidget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QScrollBar *vertScrollbar = qTableView->verticalScrollBar();
    vertScrollbar->setEnabled(false);
}

void IGSxGUI::Util::enableTableScrollbar(SUI::TableWidget *tableWidget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    QScrollBar *vertScrollbar = qTableView->verticalScrollBar();
    vertScrollbar->setEnabled(true);
}

int IGSxGUI::Util::getButtonTextWidth(SUI::Widget* widget, const std::string& text)
{
SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
QPushButton* button = dynamic_cast<QPushButton*>(baseWidget->getWidget());
QFontMetrics fm(button->fontMetrics());
int pixelsWide = fm.width(QString(text.c_str()));
return pixelsWide;
}

int IGSxGUI::Util::getCharWidthOfButton(const std::string& str, SUI::Widget* widget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QPushButton* qbtn = dynamic_cast<QPushButton*>(baseWidget->getWidget());
    QFont font(qbtn->font().family(), qbtn->font().pixelSize());
    QFontMetrics fm(font);
    return fm.width(QString::fromStdString(str));
}

void IGSxGUI::Util::setEventFilterForFloatArray(std::vector<SUI::Widget*> widgetVector, SUI::TableWidget *tableWidget,\
                                                std::vector<SUI::Widget*> clearButtonWidgetVector, std::vector<SUI::Widget*> lineEditWidgetVector,\
                                                bool *errorFound, int *currentIndex)
{
    IGSxGUIxFloatArrayEventHandler *eventHandler =  new IGSxGUIxFloatArrayEventHandler;
    eventHandler->setTableWidget(tableWidget);
    QDialog* qdialog = dynamic_cast<QDialog*>(widgetVector[0]);
    eventHandler->setCurrentIndex(currentIndex);
    eventHandler->setWidgetVector(widgetVector, clearButtonWidgetVector, lineEditWidgetVector); // e
    eventHandler->setErrorFoundFlag(errorFound);

    qdialog->installEventFilter(eventHandler);
    for (size_t i = 0; i < lineEditWidgetVector.size(); ++i) {
        SUI::Widget *widget = lineEditWidgetVector[i];
        SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
        QWidget* qWidget = dynamic_cast<QWidget*>(baseWidget->getWidget());
        QLineEdit *le = dynamic_cast<QLineEdit*>(qWidget);
        le->installEventFilter(eventHandler);
    }
}

void IGSxGUI::Util::setEventFilterForHistory(SUI::Dialog *dialog, SUI::TableWidget *tableWidget, bool *isCtrlPressed, IGSxGUI::HistorypopupView *ptrHistorypopupView)
{
    IGSxGUIxHistoryEventHandler *eventHandler = new IGSxGUIxHistoryEventHandler;
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    qdialog->installEventFilter(eventHandler);
    eventHandler->setHistorypopupView(ptrHistorypopupView);
    eventHandler->setDialog(dialog);
    eventHandler->setTableWidget(tableWidget);
    eventHandler->setCtrlKeyPressedState(isCtrlPressed);
}

void IGSxGUI::Util::boolDialogInstallEventFileter(std::vector<SUI::Widget*> widgetVector)
{
    IGSxGUIxRadioButtonEventHandler *eventHandler = new IGSxGUIxRadioButtonEventHandler();
    eventHandler->installEvents(widgetVector);
}

void IGSxGUI::Util::setRadiobutonNormalUncheckedStyle(SUI::RadioButton* widget, std::string path) {
    std::ostringstream oss;
    oss << "QRadioButton::indicator:unchecked {image: url(" << path << ")} QRadioButton{color:#000000;}";
    std::string style1 = oss.str();
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QRadioButton* ra = dynamic_cast<QRadioButton*>(baseWidget->getWidget());
    ra->setStyleSheet(style1.c_str());
}

void IGSxGUI::Util::setRadiobutonNormalCheckedStyle(SUI::RadioButton* widget, std::string path) {
    std::ostringstream oss;
    oss << "QRadioButton::indicator:checked {image: url(" << path << ")} QRadioButton{ color:#000000;}";
    std::string style1 = oss.str();
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(widget);
    QRadioButton* ra = dynamic_cast<QRadioButton*>(baseWidget->getWidget());
    ra->setStyleSheet(style1.c_str());
}

void IGSxGUI::Util::scrollToBottom(SUI::TableWidget *tableWidget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->scrollToBottom();
}

void IGSxGUI::Util::scrollToTop(SUI::TableWidget *tableWidget)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(tableWidget);
    QTableView* qTableView = dynamic_cast<QTableView*>(baseWidget->getWidget());
    qTableView->scrollToTop();
}

void IGSxGUI::Util::setTextEditPaletteColor(SUI::TextArea *TextArea, std::string highlightColor, std::string highlightedTextColor)
{
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(TextArea);
    QTextEdit* qTa = dynamic_cast<QTextEdit*>(baseWidget->getWidget());
    QPalette qPa = qTa->palette();
    QString qHighlightColor = QString::fromStdString(highlightColor);
    QString qHighlightedTextColor = QString::fromStdString(highlightedTextColor);
    qPa.setColor(QPalette::Highlight, QColor(qHighlightColor));
    qPa.setColor(QPalette::HighlightedText, QColor(qHighlightedTextColor));
    qTa->setPalette(qPa);
}

void IGSxGUI::Util::parameterTableHeaderInstallEventFilter(std::vector<SUI::Widget*> widgetVector)
{
    IGSxGUIxParameterTableHeaderEventHandler *eventHandler = new IGSxGUIxParameterTableHeaderEventHandler();
    eventHandler->installEvents(widgetVector);
}

void IGSxGUI::Util::pendingParameterTableHeaderInstallEventFilter(std::vector<SUI::Widget*> widgetVector)
{
    IGSxGUIxPendingParameterTableHeaderEventHandler *eventHandler = new IGSxGUIxPendingParameterTableHeaderEventHandler();
    eventHandler->installEvents(widgetVector);
}

void IGSxGUI::Util::historyTableHeaderInstallEventFilter(std::vector<SUI::Widget*> widgetVector)
{
    IGSxGUIxHistoryTableHeaderEventHandler *eventHandler = new IGSxGUIxHistoryTableHeaderEventHandler();
    eventHandler->installEvents(widgetVector);
}
