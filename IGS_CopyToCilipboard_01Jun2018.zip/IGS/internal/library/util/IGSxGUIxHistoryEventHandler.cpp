#include "IGSxGUIxHistoryEventHandler.hpp"
#include "IGSxGUIxHistorypopupView.hpp"
//#include <QApplication>
//#include <QClipboard>


IGSxGUIxHistoryEventHandler::IGSxGUIxHistoryEventHandler(QObject *parent) :
    QObject(parent), m_dialog(NULL), m_tableWidget(NULL)
{
}

IGSxGUIxHistoryEventHandler::~IGSxGUIxHistoryEventHandler()
{
}

void IGSxGUIxHistoryEventHandler::setDialog(SUI::Dialog *dialog)
{
    m_dialog = dialog;
}

void IGSxGUIxHistoryEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
}

void IGSxGUIxHistoryEventHandler::setHistorypopupView(IGSxGUI::HistorypopupView *historypopupView)
{
    m_HistorypopupView = historypopupView;
}

void IGSxGUIxHistoryEventHandler::setCtrlKeyPressedState(bool *isCtrlKeyPressed)
{
    m_isCtrlKeyPressed = isCtrlKeyPressed;
}

void IGSxGUIxHistoryEventHandler::selectAllRows()
{
    for (int row = 0; row < m_tableWidget->rowCount(); ++row) {
        IGSxGUI::Util::selectHistoryRow(m_tableWidget, row);
        SUI::Widget *widget = m_tableWidget->getWidgetItem(row, 0);
        IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
    }
    m_HistorypopupView->selectAllRows();

}

void IGSxGUIxHistoryEventHandler::copySelectedRows()
{
    std::vector<int> selectedRows = IGSxGUI::Util::getSelectedRowIndexes(m_tableWidget);
    std::string completCopiedText = "";
    foreach (int row, selectedRows) {
        SUI::Widget *widget = m_tableWidget->getWidgetItem(row, 0);
        std::string paramName = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        completCopiedText += "\""+ paramName + "\",";
        std::string oldValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
        completCopiedText += "\""+ oldValue + "\",";
        std::string newValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
        completCopiedText += "\""+ newValue + "\",";
        std::string changedTime = IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
        completCopiedText += "\""+ changedTime + "\",";
        std::string changedBy = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
        completCopiedText += "\""+ changedBy + "\",";
        std::string reason = IGSxGUI::Util::getTextFromParameterUserControl(widget, 5);
        completCopiedText += "\""+ reason + "\"";
        completCopiedText += "\n";

    }

    QClipboard *clipboard = QApplication::clipboard();
    clipboard->setText("");
    clipboard->setText(QString(completCopiedText.c_str()));

}

bool IGSxGUIxHistoryEventHandler::eventFilter(QObject *object, QEvent *event)
{
    int eventType = event->type();
    switch (eventType) {
    case QEvent::KeyPress: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
            *m_isCtrlKeyPressed = true;
            if (key == Qt::Key_A) {
                selectAllRows();
            }
        }
        return true;
    }
    case QEvent::KeyRelease: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        int key = keyEvent->key();
        if (key == Qt::Key_Control) {
            *m_isCtrlKeyPressed = false;
        }
        return true;
    }
    default:
        break;
    }
    return QObject::eventFilter(object, event);
}
