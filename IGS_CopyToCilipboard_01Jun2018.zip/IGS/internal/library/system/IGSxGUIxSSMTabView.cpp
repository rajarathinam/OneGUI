/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMTabView.cpp
| Author       : Saket K
| Description  : Implementation of SSM view
|
| ! \file        IGSxGUIxSSMTabView.cpp
| ! \brief       Implementation of SSM view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIBusyIndicator.h>

#include <boost/bind.hpp>
#include <string>
#include <algorithm>
#include <IGSxGUIxSSMTabView.hpp>
#include "IGSxGUIxMoc_SSMTabView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const int MAX_ROW_COUNT = 3;
const std::string IGSxGUI::SSMTabView::SYSTEMSTATEMANAGER_TAB_LOAD_FILE = "IGSxGUIxSSMTab.xml";
const std::string IGSxGUI::SSMTabView::SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE = "IGSxGUIxSSMTabGroup.xml";

IGSxGUI::SSMTabView::SSMTabView(SSMManager &ssmManager, const IGSxGUI::TabType tabIndex):
    sui(new SUI::SSMTabView),
    States(),
    mTabIndex(tabIndex),
    mManager(ssmManager),
    mStatusBarManager(States),
    mStateCounter(0),
    mLoaded(false),
    mPreviousStateIndex(0)
{
}

void IGSxGUI::SSMTabView::setActive(bool /*bActive*/)
{
}

IGSxGUI::SSMTabView::~SSMTabView()
{

    for (std::vector< State* >::iterator it = States.begin() ; it != States.end(); ++it)
    {
      delete (*it);
    }
    States.clear();

}

void IGSxGUI::SSMTabView::addNewState(const int groupIndex, const int stateIndex)
{
    SUI::SUIUCState newUCState = SUIStates[groupIndex][stateIndex];
    std::string stateName = generateStateName(groupIndex, stateIndex);
    int currentStateId = mManager.getStateId(mTabIndex, groupIndex, stateIndex);
    InnerState currentInnerState = getInnerState(currentStateId);
    bool abortable = mManager.isTransitionAbortable(mTabIndex, currentStateId);
    State* newState = new State(newUCState.Control, newUCState.Button, newUCState.BsyIndicator, newUCState.OverlayLabel, currentInnerState, currentStateId, abortable, mStateCounter++);
    newState->setStateName(stateName);
    newState->clicked = boost::bind(&SSMTabView::stateChanged, this, _1, _2, _3);
    States.push_back(newState);
}

void IGSxGUI::SSMTabView::init()
{
    mManager.getActiveTransition(mTabIndex);

    for (std::vector< State* >::iterator it = States.begin() ; it != States.end(); ++it)
    {
      delete (*it);
    }
    States.clear();

    setupStates();
    updateStatusBar();

    for(size_t index = 0; index < States.size(); ++index)
    {
        States[index]->show();
    }
}


void IGSxGUI::SSMTabView::updateStatusBar()
{
    mActiveTransition = mManager.getActiveTransitionData(mTabIndex);
    mStatusBarManager.show(mActiveTransition);
}

void IGSxGUI::SSMTabView::stateChanged(IGSxGUI::InnerState innerState, const int newStateId, const int newUIStateIndex)
{  
    mActiveTransition = mManager.getActiveTransitionData(mTabIndex);

    switch(innerState)
    {
    case IGSxGUI::REACHABLE:
        for(size_t index = 0; index < States.size(); ++index)
        {
            // Set states disabled which are not currently part of active transition.
            if ((newUIStateIndex != static_cast<int>(index))
                    && (States[index]->getInnerState() != IGSxGUI::ACTIVE)
                    && (States[index]->getInnerState() != IGSxGUI::TRANSITION_START))
            {
                States[index]->setInnerState(IGSxGUI::DISABLED);
            }
            else if(mActiveTransition.From == States[index]->getId())
            {
                States[index]->setInnerState(IGSxGUI::TRANSITION_START);
            }
        }
           States[newUIStateIndex]->setInnerState(IGSxGUI::TRANSITION_END);
           mManager.setTransition(mTabIndex, newStateId);
           updateStatusBar();
       break;
   case IGSxGUI::ACTIVE:
        break;
   case IGSxGUI::TRANSITION_START:
        if( States[newUIStateIndex]->getAbortable() ) {
            mManager.setTransition(mTabIndex, mActiveTransition.From);
            updateStatusBar();
        }
        break;
   case IGSxGUI::TRANSITION_END:
         break;
   case IGSxGUI::DISABLED:
        break;
    }


}

void IGSxGUI::SSMTabView::setupStates()
{
    mStateCounter = 0;
    int groupCount = mManager.getGroupCount(mTabIndex);
    mActiveTransition = mManager.getActiveTransitionData(mTabIndex);
    for(int groupIndex = 0; groupIndex < groupCount ; ++groupIndex)
    {
        int stateCount = mManager.getStatesCount(mTabIndex, groupIndex);

        for(int stateIndex = 0; stateIndex < stateCount ; ++stateIndex)
        {
            addNewState(groupIndex, stateIndex);
        }
    }
}

void IGSxGUI::SSMTabView::reset()
{
    mLoaded = false;
}

void IGSxGUI::SSMTabView::show(SUI::Container* MainScreenContainer, bool)
{

    if(!mLoaded)
    {
      sui->setupSUIContainer(SYSTEMSTATEMANAGER_TAB_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setupGroups();
    setupUI();
    setupStatusBar();
    init();

}

void IGSxGUI::SSMTabView::setupGroups()
{

    int rowCount = mManager.getGroupCount(mTabIndex);
    switch(rowCount)
    {
    case 1:
        showGroup1();
        break;
    case 2:
        showGroup12();
        break;
    case 3:
        showGroup123();
        break;
    }

}

void IGSxGUI::SSMTabView::showGroup1()
{
    std::string groupName;
    if(!mLoaded)
    {
    sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
     mLoaded = true;
    }
    groupName = mManager.getGroupName(mTabIndex, 0);
    sui->groupLabel1->setText(groupName);
    sui->row1->show();
    sui->row2->hide();
    sui->row3->hide();
}

void IGSxGUI::SSMTabView::showGroup12()
{
    std::string groupName;
    if(!mLoaded)
    {
    sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
    sui->setupGroup2Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row2Container);
     mLoaded = true;
    }
    groupName = mManager.getGroupName(mTabIndex, 0);
    sui->groupLabel1->setText(groupName);
    groupName = mManager.getGroupName(mTabIndex, 1);
    sui->groupLabel2->setText(groupName);
    sui->row1->show();
    sui->row2->show();
    sui->row3->hide();
}


void IGSxGUI::SSMTabView::showGroup123()
{
    std::string groupName;
    if(!mLoaded)
    {
    sui->setupGroup1Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row1Container);
    sui->setupGroup2Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row2Container);
    sui->setupGroup3Container(SYSTEMSTATEMANAGER_TAB_GROUP_LOAD_FILE.c_str(), sui->row3Container);
     mLoaded = true;
    }
    groupName = mManager.getGroupName(mTabIndex, 0);
    sui->groupLabel1->setText(groupName);
    groupName = mManager.getGroupName(mTabIndex, 1);
    sui->groupLabel2->setText(groupName);
    groupName = mManager.getGroupName(mTabIndex, 2);
    sui->groupLabel3->setText(groupName);
    sui->row1->show();
    sui->row2->show();
    sui->row3->show();
}

void IGSxGUI::SSMTabView::setupUI()
{
    SUIStates.clear();
    std::vector< SUI::SUIUCState> stateList;
    SUIStates.assign(MAX_ROW_COUNT, stateList);

    if(sui->row1->isVisible())
    {
        SUIStates[0].push_back(SUI::SUIUCState(sui->state11, sui->state11Btn, sui->state11Bic, sui->state11OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state12, sui->state12Btn, sui->state12Bic, sui->state12OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state13, sui->state13Btn, sui->state13Bic, sui->state13OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state14, sui->state14Btn, sui->state14Bic, sui->state14OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state15, sui->state15Btn, sui->state15Bic, sui->state15OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state16, sui->state16Btn, sui->state16Bic, sui->state16OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state17, sui->state17Btn, sui->state17Bic, sui->state17OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state18, sui->state18Btn, sui->state18Bic, sui->state18OverlayLabel));
        SUIStates[0].push_back(SUI::SUIUCState(sui->state19, sui->state19Btn, sui->state19Bic, sui->state19OverlayLabel));
    }

    if(sui->row2->isVisible())
    {
        SUIStates[1].push_back(SUI::SUIUCState(sui->state22, sui->state22Btn, sui->state21Bic, sui->state21OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state21, sui->state21Btn, sui->state22Bic, sui->state22OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state23, sui->state23Btn, sui->state23Bic, sui->state23OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state24, sui->state24Btn, sui->state24Bic, sui->state24OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state25, sui->state25Btn, sui->state25Bic, sui->state25OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state26, sui->state26Btn, sui->state26Bic, sui->state26OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state27, sui->state27Btn, sui->state27Bic, sui->state27OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state28, sui->state28Btn, sui->state28Bic, sui->state28OverlayLabel));
        SUIStates[1].push_back(SUI::SUIUCState(sui->state29, sui->state29Btn, sui->state29Bic, sui->state29OverlayLabel));
    }

    if(sui->row3->isVisible())
    {
        SUIStates[2].push_back(SUI::SUIUCState(sui->state31, sui->state31Btn, sui->state31Bic, sui->state31OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state32, sui->state32Btn, sui->state32Bic, sui->state32OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state33, sui->state33Btn, sui->state33Bic, sui->state33OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state34, sui->state34Btn, sui->state34Bic, sui->state34OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state35, sui->state35Btn, sui->state35Bic, sui->state35OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state36, sui->state36Btn, sui->state36Bic, sui->state36OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state37, sui->state37Btn, sui->state37Bic, sui->state37OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state38, sui->state38Btn, sui->state38Bic, sui->state38OverlayLabel));
        SUIStates[2].push_back(SUI::SUIUCState(sui->state39, sui->state39Btn, sui->state39Bic, sui->state39OverlayLabel));
    }
}

void IGSxGUI::SSMTabView::setupStatusBar()
{
    mStatusBarManager.initWidgets(sui->gbxCurrentState,
                           sui->gbxTransitionState,
                           sui->lblCurrentStateText,
                           sui->lblFromText,
                           sui->lblToText,
                           sui->lblStartTimeText,
                           sui->lblExpectedDurationText,
                           sui->lblElapsedTimeText);
}

IGSxGUI::InnerState IGSxGUI::SSMTabView::getInnerState(const int stateId) const
{
    IGSxGUI::InnerState currentState = DISABLED;
    currentState = mManager.getInnerState(mTabIndex, stateId);
    return currentState;
}


std::string IGSxGUI::SSMTabView::generateStateName(const int groupIndex, const int stateIndex)
{
    std::string stateName;

    stateName += mManager.getStateDescription(mTabIndex, groupIndex, stateIndex)[0];
    if(mManager.getStateDescription(mTabIndex, groupIndex, stateIndex)[1] != "")
        stateName += std::string("\n") + mManager.getStateDescription(mTabIndex, groupIndex, stateIndex)[1];

    return stateName;
}


