/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenter.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD Presenter
|
| ! \file        IGSxGUIxCPDPresenter.cpp
| ! \brief       Implementation of CPD Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxCPDPresenter.hpp"
#include <string>
#include <vector>
#include <map>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::CPDPresenter::CPDPresenter(IGSxGUI::ICPDView* view, CPDManager* pCPDManager):
    m_pCPDManager(pCPDManager),
    m_view(view)
{
}
IGSxGUI::CPDPresenter::~CPDPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDPresenter::getCPDs() const
{
    return m_pCPDManager->retrieveAll();
}
void IGSxGUI::CPDPresenter::getCPDTestResults(const std::string& cpdname, IGSxCPD::TestResultList& testResults) const
{
    m_pCPDManager->retrieveCPDTestResults(cpdname, testResults);
}

IGSxGUI::CPD* IGSxGUI::CPDPresenter::getCPD(const std::string &cpdName) const
{
    return(m_pCPDManager->getCPD(cpdName));
}

IGSxGUI::CPD *IGSxGUI::CPDPresenter::retrieveRunningCPD() const
{
    return m_pCPDManager->retrieveRunningCPD();
}

bool IGSxGUI::CPDPresenter::startCPD(const std::string &cpdName) const
{
    return m_pCPDManager->openCPD(cpdName);
}

void IGSxGUI::CPDPresenter::subscribeForEvents()
{
    std::vector<IGSxGUI::CPD *> CPDs = m_pCPDManager->retrieveAll();

    for (size_t i = 0; i < CPDs.size(); ++i)
    {
        boost::signals2::connection connection = CPDs[i]->registerToCPDStopped(boost::bind(&IGSxGUI::CPDPresenter::onCPDStopped, this, _1, _2));
        m_connections.push_back(connection);
    }
}

void IGSxGUI::CPDPresenter::unsubscribeForEvents()
{
    for (size_t i = 0; i < m_connections.size(); ++i)
    {
        m_connections.at(i).disconnect();
    }
    m_connections.clear();
}

void IGSxGUI::CPDPresenter::onCPDStopped(const std::string &strCPD, const IGS::Result &result) const
{
    m_view->updateStatus(strCPD, result);
}

