/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMState.cpp
| Author       : Saket K
| Description  : Implementation of SSM State
|
| ! \file        IGSxGUIxSSMState.cpp
| ! \brief       Implementation of SSMState view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <FWQxWidgets/SUILabel.h>
#include <IGSxGUIxSSMState.hpp>
#include <boost/bind.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const SUI::Rect IGSxGUI::State::NON_TRANSITION_STATE_RECT = SUI::Rect(32,32,120,60);
const SUI::Rect IGSxGUI::State::TRANSITION_STATE_RECT = SUI::Rect(32,22,120,80);

IGSxGUI::State::State(SUI::UserControl *control, SUI::Button *button, SUI::BusyIndicator* bic, SUI::Label* lbl,  InnerState innerState, const int id, const bool abortable, const int index) :
    mUsercontrol(control), mButton(button), mBusyIndicator(bic), mOverlayLabel(lbl), mCurrentState(innerState), mId(id),mAbortable(abortable), mIndex(index)
{
    initButton(mCurrentState);
    button->clicked = boost::bind(&State::buttonClicked, this);
}

void IGSxGUI::State::buttonClicked()
{
     clicked(mCurrentState, mId, mIndex);
}

SUI::UserControl *IGSxGUI::State::getUserControl()
{
    return mUsercontrol;
}

void IGSxGUI::State::show()
{
    mUsercontrol->show();
}

void IGSxGUI::State::hide()
{
    mUsercontrol->hide();
}

void IGSxGUI::State::setInnerState(IGSxGUI::InnerState innerState)
{
    mCurrentState = innerState;
    initButton(mCurrentState);
}

IGSxGUI::InnerState IGSxGUI::State::getInnerState() const
{
    return mCurrentState;
}

void IGSxGUI::State::initButton(IGSxGUI::InnerState innerState)
{
    switch(innerState)
    {
    case REACHABLE:
    {
        mButton->setStyleSheetClass("StateReachable");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case ACTIVE:
    {
        mButton->setStyleSheetClass("StateActive");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case DISABLED:
    {
        mButton->setStyleSheetClass("StateDisabled");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case TRANSITION_START:
    {
        (mAbortable) ? mButton->setStyleSheetClass("StateTransitionStartAbortable") :
                       mButton->setStyleSheetClass("StateTransitionStartNonAbortable");
        mButton->setGeometry(TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case TRANSITION_END:
    {
        mButton->setStyleSheetClass("StateTransitionEnd");
        mButton->setGeometry(TRANSITION_STATE_RECT);
        mOverlayLabel->setText(mButton->getText());
        mButton->setText("");
        mBusyIndicator->show();
        mOverlayLabel->show();
        break;
    }
    }
}

void IGSxGUI::State::setId(const int id)
{
    mId = id;
}

void IGSxGUI::State::setAbortable(bool abortable)
{
    mAbortable = abortable;
}

bool IGSxGUI::State::getAbortable() const
{
    return mAbortable;
}

int IGSxGUI::State::getId() const
{
    return mId;
}

std::string IGSxGUI::State::getStateName() const
{
    return mName;
}

void IGSxGUI::State::setStateName(const std::string& stateName)
{
    mName = stateName;
    mButton->setText(mName);
}
