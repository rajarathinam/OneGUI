/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxHistorypopupView.cpp
| Author       : Venu
| Description  : Implementation of Historypopup view
|
| ! \file        IGSxGUIxHistorypopupView.cpp
| ! \brief       Implementation of Historypopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <string>
#include <utility>
#include <vector>
#include <algorithm>
#include "IGSxGUIxHistorypopupView.hpp"
#include "IGSxGUIxMoc_HistorypopupView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxSystemDateTime.hpp"


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::HistorypopupView::BUTTON_SIZE = 18;
const int IGSxGUI::HistorypopupView::SORT_ICON_SIZE = 11;
const std::string IGSxGUI::HistorypopupView::HISTORYPOPUPVIEW_LOAD_FILE = "IGSxGUIxHistoryPopup.xml";
const std::string IGSxGUI::HistorypopupView::STRING_HISTORYPOPUPVIEW_SHOWN = "HistoryPopupView is Shown.";
const std::string IGSxGUI::HistorypopupView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::HistorypopupView::STRING_PARAMETERS_FOUND = "parameters found";
const std::string IGSxGUI::HistorypopupView::STRING_PARAMETERNAME = "PARAMETER NAME";
const std::string IGSxGUI::HistorypopupView::STRING_CHANGEDON = " CHANGED ON";
const std::string IGSxGUI::HistorypopupView::STRING_CHANGEDBY = " CHANGED BY";
const std::string IGSxGUI::HistorypopupView::STRING_REASON = " REASON";

const std::string IGSxGUI::HistorypopupView::STYLE_HISTORY_SELECTED_HEADER = "historyselectedheader";
const std::string IGSxGUI::HistorypopupView::STYLE_HISTORY_NORMAL_HEADER = "historyparametername";
const std::string IGSxGUI::HistorypopupView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::HistorypopupView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::HistorypopupView::STRING_BLUE_HEADER = "#1B3E93";
const std::string IGSxGUI::HistorypopupView::STYLE_AWESOME_ICONCOLOR = "#AAAAAA";
const std::string IGSxGUI::HistorypopupView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::HistorypopupView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::HistorypopupView::STYLE_SEARCH_PARAMETER = "searchparameter";
const std::string IGSxGUI::HistorypopupView::STYLE_SEARCHPARAM_NOITALIC = "searchparameterNoItalic";
const std::string IGSxGUI::HistorypopupView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::HistorypopupView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::HistorypopupView::STRING_EMPTY = "";
const int IGSxGUI::HistorypopupView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::HistorypopupView::ROW_HEIGHT = 40;
const size_t IGSxGUI::HistorypopupView::MAX_CHARS_OF_PARAMS_PER_LINE = 45;
const int IGSxGUI::HistorypopupView::MULTILINE_ROW_HEIGHT_INCREASE = 20;
const int IGSxGUI::HistorypopupView::MAX_VISIBLE_ROWS = 13;
const int IGSxGUI::HistorypopupView::MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 520;

const int IGSxGUI::HistorypopupView::CONSTANT_ZERO = 0;
const int IGSxGUI::HistorypopupView::IMAGE_WIDTH = 20;
const int IGSxGUI::HistorypopupView::WIDGET_HEIGHT = 30;
const int IGSxGUI::HistorypopupView::PARAMNAME_WIDTH_BEFORE_SORTING = 127;
const int IGSxGUI::HistorypopupView::PARAMNAME_WIDTH_AFTER_SORTING = 140;
const int IGSxGUI::HistorypopupView::CHANGEDON_WIDTH_BEFORE_SORTING = 94;
const int IGSxGUI::HistorypopupView::CHANGEDON_WIDTH_AFTER_SORTING = 102;
const int IGSxGUI::HistorypopupView::CHANGEDBY_WIDTH_BEFORE_SORTING = 90;
const int IGSxGUI::HistorypopupView::CHANGEDBY_WIDTH_AFTER_SORTING = 98;
const int IGSxGUI::HistorypopupView::REASON_WIDTH_BEFORE_SORTING = 60;
const int IGSxGUI::HistorypopupView::REASON_WIDTH_AFTER_SORTING = 68;


const int IGSxGUI::HistorypopupView::TOOLTIP_WIDTH = 60;
const std::string IGSxGUI::HistorypopupView::STRING_NEWLINE = "\n";
const std::string IGSxGUI::HistorypopupView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";

// https://stackoverflow.com/questions/3152241/case-insensitive-stdstring-find
template<typename charT>
struct my_equal {
    explicit my_equal(const std::locale& loc) : loc_(loc) {}
    bool operator()(charT ch1, charT ch2)
    {
        return std::toupper(ch1, loc_) == std::toupper(ch2, loc_);
    }
  private:
    const std::locale& loc_;
};

// contains substring (case insensitive)
template<typename T>
bool contains_substr(const T& strTarget, const T& strToSearch)
{
    const std::locale& loc = std::locale();
    typename T::const_iterator it = std::search(strTarget.begin(), strTarget.end(),
                                    strToSearch.begin(), strToSearch.end(), my_equal<typename T::value_type>(loc) );
    return  it != strTarget.end();
}

struct find_historyData {
    std::string m_name;
    std::string m_oldvalue;
    std::string m_newvalue;
    std::string m_author;
    time_t m_time;
    find_historyData(std::string& name, std::string& oldvalue, std::string& newvalue, std::string& author, time_t time) : \
        m_name(name), m_oldvalue(oldvalue), m_newvalue(newvalue), m_author(author), m_time(time) {}
    bool operator()(const IGSxGUI::ParameterHistory& data) const
    {
        bool result = (data.parameter_name().compare(m_name) == 0) && (data.old_value().compare(m_oldvalue) == 0) &&\
                      (data.new_value().compare(m_newvalue) == 0) && (data.time_of_change() == m_time) && \
                      (data.changed_by().compare(m_author) == 0);
        return result;
    }
};
bool compareByParameterNameAsc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.parameter_name() < rhs.parameter_name();
}

bool compareByParameterNameDesc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.parameter_name() > rhs.parameter_name();
}
bool compareByChangedOnAsc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.time_of_change() < rhs.time_of_change();
}

bool compareByChangedOnDesc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.time_of_change() > rhs.time_of_change();
}
bool compareByChangedByAsc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.changed_by() < rhs.changed_by();
}

bool compareByChangedByDesc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.changed_by() > rhs.changed_by();
}

bool compareByReasonAsc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.reason() < rhs.reason();
}

bool compareByReasonDesc(const IGSxGUI::ParameterHistory lhs, const IGSxGUI::ParameterHistory rhs)
{
    return lhs.reason() > rhs.reason();
}

IGSxGUI::HistorypopupView::HistorypopupView(IGSxGUI::MachineconstantsManager* machineConstantsManager):
    sui(new SUI::HistorypopupView), m_isCtrlKeyPressed(false), m_searchText(STRING_EMPTY)
{
    sui->setupSUI(HISTORYPOPUPVIEW_LOAD_FILE.c_str());
    m_machineConstantsManager = machineConstantsManager;
}


IGSxGUI::HistorypopupView::~HistorypopupView()
{
    if (sui != NULL) {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::HistorypopupView::show()
{
    init();
    setHandlers();
    getData();
    m_changedOnOrder = IGSxGUI::SortOrder::Descending;
    m_currentOrder = m_changedOnOrder;
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedOn;
    arrangeTableData(m_historyData, m_currentSortedColumn, m_changedOnOrder);
    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::setEventFilterForHistory(sui->dialog, sui->tawParametersHistory, &m_isCtrlKeyPressed, this);
    IGSxGUI::Util::executeDialog(sui->dialog);
    IGS_INFO(STRING_HISTORYPOPUPVIEW_SHOWN);
}

void IGSxGUI::HistorypopupView::init()
{
    m_selectedHistoryRowNum =  -1;
    m_paramNameOrder = IGSxGUI::SortOrder::Ascending;
    m_changedOnOrder = IGSxGUI::SortOrder::Ascending;
    m_changedByOrder = IGSxGUI::SortOrder::Ascending;
    m_reasonOrder = IGSxGUI::SortOrder::Ascending;
    sui->lneSearchParameterText->setText(STRING_EMPTY);
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);
    sui->btnSearchParameter->setVisible(true);
    sui->btnSearchClear->setVisible(false);
    sui->lblHistoryEntriesFound->setVisible(false);
    sui->lblParameterNameHistoryHeaderButtonText->setText(STRING_PARAMETERNAME);
    sui->lblChangedOnHistoryHeaderButtonText->setText(STRING_CHANGEDON);
    sui->lblChangedByHistoryHeaderButtonText->setText(STRING_CHANGEDBY);
    sui->lblReasonHistoryHeaderButtonText->setText(STRING_REASON);
    IGSxGUI::Util::setAwesome(sui->btnSearchParameter, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    createMaxVisibleRows(sui->tawParametersHistory, MAX_VISIBLE_ROWS);
    createSortingMap();
}
void IGSxGUI::HistorypopupView::createMaxVisibleRows(SUI::TableWidget *tableWidget, int numberOfRows)
{
    if (tableWidget) {
        tableWidget->removeRows(1, sui->tawParametersHistory->rowCount() - 1);
        for (int i = 0; i < (numberOfRows - 1); ++i) {
            tableWidget->appendRow();
        }
    }
}

void IGSxGUI::HistorypopupView::setHandlers()
{
    std::vector<SUI::Widget*> historyTableHeaderWidgetVector;
    historyTableHeaderWidgetVector.push_back(sui->lblParameterNameHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblParameterNameHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedOnHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedOnHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedByHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedByHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblReasonHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblReasonHistoryHeaderButtonImage);
    IGSxGUI::Util::historyTableHeaderInstallEventFilter(historyTableHeaderWidgetVector);

    sui->uctCloseHistory->clicked = boost::bind(&HistorypopupView::onUCTCloseHistoryClicked, this);
    sui->uctCloseHistory->hoverEntered = boost::bind(&HistorypopupView::onUCTCloseHistoryHoverOn, this);
    sui->uctCloseHistory->hoverLeft = boost::bind(&HistorypopupView::onUCTCloseHistoryHoverOff, this);
    sui->uctCloseHistory->pressed = boost::bind(&HistorypopupView::onUCTCloseHistoryPressed, this);
    sui->uctParameterName->clicked = boost::bind(&HistorypopupView::onParameterNameHeaderClicked, this);
    sui->uctChangedOn->clicked = boost::bind(&HistorypopupView::onChangedOnHeaderClicked, this);
    sui->uctChangedBy->clicked = boost::bind(&HistorypopupView::onChangedByHeaderClicked, this);
    sui->uctReason->clicked = boost::bind(&HistorypopupView::onReasonHeaderClicked, this);
    sui->scbHistoryTable->valueChanged = boost::bind(&HistorypopupView::onValueChanged, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&HistorypopupView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&HistorypopupView::onSearchTextEditFinished, this);
    sui->btnSearchClear->clicked = boost::bind(&HistorypopupView::onSearchClearPressed, this);
    sui->btnSearchClear->hoverLeft = boost::bind(&HistorypopupView::onSearchClearHoverLeft, this);
    sui->btnSearchClear->hoverEntered = boost::bind(&HistorypopupView::onSearchClearHoverEntered, this);
}

void IGSxGUI::HistorypopupView::onSearchTextEdited(const std::string &text)
{
    m_searchText = text;
    m_selectedHistoryRowNum = -1;
    refreshParameterList();
    if (m_searchText != STRING_EMPTY) {
        if (m_searchText == STRING_SEARCH_PARAMETER) {
            sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        } else {
            sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
        }
    }
}
void IGSxGUI::HistorypopupView::onSearchTextEditFinished()
{
    sui->btnSearchClear->setVisible(true);
    if (m_searchText == STRING_EMPTY) {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    }
}
void IGSxGUI::HistorypopupView::onSearchClearPressed()
{
    showSearchEntriesParameter(false);
    sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    sui->lneSearchParameterText->clearText();
    refreshParameterList();
}

void IGSxGUI::HistorypopupView::onSearchClearHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::HistorypopupView::onSearchClearHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_BLUE_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::HistorypopupView::showSearchEntriesParameter(bool bShow)
{
    sui->btnSearchClear->setVisible(bShow);
    sui->lblHistoryEntriesFound->setVisible(bShow);
    sui->btnSearchParameter->setVisible(!bShow);
}

int IGSxGUI::HistorypopupView::searchForParameters(const std::string& textToSearch, std::vector<ParameterHistory>&  matchedparameters)
{
    matchedparameters.clear();
    if (textToSearch.empty()) {
        return 0;
    }
    int count = 0;
    int historyDataSize = static_cast<int>(m_historyData.size());
    for (int i = 0; i < historyDataSize; ++i) {
        std::string parametername = m_historyData[i].parameter_name();
        if (contains_substr(parametername, textToSearch)) {
            ++count;
            ParameterHistory temp(m_historyData[i].parameter_name(), m_historyData[i].time_of_change(),
                                  m_historyData[i].changed_by(), m_historyData[i].reason(), m_historyData[i].old_value(),
                                  m_historyData[i].new_value(), m_historyData[i].isSelected());
            matchedparameters.push_back(temp);
        }
    }
    return count;
}
void IGSxGUI::HistorypopupView::refreshParameterList()
{
    if (m_searchText.empty()) {
        showSearchEntriesParameter(false);
        sui->scbHistoryTable->setMinValue(0);
        arrangeTableData(m_historyData, m_currentSortedColumn, m_currentOrder);
    } else {
        showSearchEntriesParameter(true);
        IGSxGUI::Util::setAwesome(sui->btnSearchClear, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
        int entriesfound = searchForParameters(m_searchText, m_matchedparameters);
        switch (m_currentSortedColumn) {
        case IGSxGUI::SortedByColumn::ParameterName:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ParameterName, m_paramNameOrder);
            break;
        case IGSxGUI::SortedByColumn::ChangedOn:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ChangedOn, m_changedOnOrder);
            break;
        case IGSxGUI::SortedByColumn::ChangedBy:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ChangedBy, m_changedByOrder);
            break;
        case IGSxGUI::SortedByColumn::Reason:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::Reason, m_reasonOrder);
            break;
        default:
            initializeTableRows(m_matchedparameters);
            break;
        }
        sui->lblHistoryEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND);
    }
}

void IGSxGUI::HistorypopupView::applyDataAndStyles(int rowIndex)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(rowIndex, 0);
    IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&HistorypopupView::onParameterHistoryClicked, this, rowIndex);
    usercontrol->hoverEntered = boost::bind(&HistorypopupView::onParameterHistoryHoverEntered, this, rowIndex);
    usercontrol->hoverLeft = boost::bind(&HistorypopupView::onParameterHistoryHovLeft, this, rowIndex);
}

void IGSxGUI::HistorypopupView::extractSubStr(std::size_t found,  int& num_of_rows, std::string& retname, std::string& tmpname)
{
    if (retname == STRING_EMPTY) {
        retname = tmpname.substr(0, found);
    } else {
        retname = retname + STRING_NEWLINE + tmpname.substr(0, found);
    }
    num_of_rows++;
    tmpname = tmpname.substr(found, tmpname.size());
}

int IGSxGUI::HistorypopupView::UpperCasePosition(const std::string& name)
{
    int i = MAX_CHARS_OF_PARAMS_PER_LINE;
    for (; i > 0; --i) {
        if (::isupper(name[i]) && !::isupper(name[i - 1])) {
            return i;
        }
    }
    return i;
}

void IGSxGUI::HistorypopupView::populateData(std::vector<ParameterHistory>::iterator it, int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    if (widget) {
        applyDataAndStyles(row);
        std::string adjustedParameterName = STRING_EMPTY;
        if ((*it).parameter_name().length() > MAX_CHARS_OF_PARAMS_PER_LINE) {
            std::pair <std::string, int> formattedText = getFormattedsParamNameAndCalculateLineCount((*it).parameter_name());
            IGSxGUI::Util::setRowHeight(sui->tawParametersHistory, row, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            adjustedParameterName += formattedText.first;
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawParametersHistory, row, ROW_HEIGHT);
            adjustedParameterName += (*it).parameter_name();
        }
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 0, adjustedParameterName);
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 1, (*it).old_value());
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 2, (*it).new_value());
        std::string str = IGSxGUI::SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, (*it).time_of_change());
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 3, str);
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 4, (*it).changed_by());
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 5, (*it).reason());
        bool selected = isParameterHistoryDataSelected(row);
        if (selected == true) {
            IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
        } else {
            IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
        }
    }
}

void IGSxGUI::HistorypopupView::calculateTotalRowHeight(std::vector<ParameterHistory> collection, int &totalRowHeight, int &max_rows)
{
    int collectionSize = static_cast<int>(collection.size());
    for (int i = 0; i < collectionSize;  ++i) {
        calculateTotalRowHeightUtility(collection, totalRowHeight, max_rows, i);
    }
}
void IGSxGUI::HistorypopupView::calculateTotalRowHeightUtility(std::vector<ParameterHistory> collection, int &totalRowHeight, int &max_rows, int i)
{
    if (collection[i].parameter_name().length() > MAX_CHARS_OF_PARAMS_PER_LINE) {
        std::pair <std::string, int> formattedText = getFormattedsParamNameAndCalculateLineCount(collection[i].parameter_name());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    } else {
        totalRowHeight = totalRowHeight + ROW_HEIGHT;
    }
    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        return;
    } else {
        ++max_rows;
    }
}

void IGSxGUI::HistorypopupView::calculateTotalRowHeightReverse(int nextIndexToStart, std::vector<ParameterHistory> collection, int &totalRowHeight, int &max_rows)
{
    for (int i = nextIndexToStart; i >= 0;  --i) {
        calculateTotalRowHeightUtility(collection, totalRowHeight, max_rows, i);
    }
}

void IGSxGUI::HistorypopupView::setDataReverse(int endIndex, std::vector<ParameterHistory> collection)
{
    std::vector<ParameterHistory>::iterator beg_it = collection.begin() + endIndex;
    std::vector<ParameterHistory>::iterator it = collection.end();
    it = beg_it;
    int rowsVisible = numberOfRowsVisisble(sui->tawParametersHistory);
    for (int row = rowsVisible - 1; row >= 0; --row) {
        populateData(it, row);
        std::advance(it, - 1);
    }
}

void IGSxGUI::HistorypopupView::setValuesToScrollbar(bool visibility, int minValue, int maxValue, int actualValue)
{
    sui->scbHistoryTable->setVisible(visibility);
    sui->scbHistoryTable->setMinValue(minValue);
    sui->scbHistoryTable->setMaxValue(maxValue);
    sui->scbHistoryTable->setValue(actualValue);
}

void IGSxGUI::HistorypopupView::initializeTableRows(IGSxGUI::ParameterHistoryVector collection)
{
    int collectionSize = static_cast<int>(collection.size());
    if (collectionSize <= 0) {
        sui->tawParametersHistory->setVisible(false);
        sui->scbHistoryTable->setVisible(false);
    } else {
        sui->tawParametersHistory->showGrid(false);
        sui->tawParametersHistory->setVisible(true);
        sui->scbHistoryTable->setVisible(false);
        int totalRowHeight = 0;
        int maxRowsCanFit = 0;
        calculateTotalRowHeight(collection, totalRowHeight, maxRowsCanFit);
        if (maxRowsCanFit < collectionSize) {
            setValuesToScrollbar(true, 0, static_cast<int>(collection.size()) - maxRowsCanFit, 0);
        } else {
            sui->scbHistoryTable->setVisible(false);
        }
        adjustTableRowVisibility(sui->tawParametersHistory, maxRowsCanFit);
        setData(0, maxRowsCanFit, collection);
        m_lastIndex = maxRowsCanFit - 1;
    }
}


void IGSxGUI::HistorypopupView::setData(int value, int rows, std::vector<ParameterHistory> collection)
{
    std::vector<ParameterHistory>::iterator beg_it = collection.begin();
    std::vector<ParameterHistory>::iterator it = collection.end();
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
    }
}
void IGSxGUI::HistorypopupView::setTableRows(int value, std::vector<ParameterHistory> collection)
{
    int totalRowHeight = 0;
    int maxRowsCanFit = 0;
    calculateTotalRowHeightReverse(m_lastIndex + value, collection, totalRowHeight, maxRowsCanFit);
    adjustTableRowVisibility(sui->tawParametersHistory, maxRowsCanFit);
    setDataReverse(m_lastIndex + value, collection);
}

void IGSxGUI::HistorypopupView::onValueChanged()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(sui->scbHistoryTable->getValue(), m_historyData);
    } else {
        setTableRows(sui->scbHistoryTable->getValue(), m_matchedparameters);
    }
}

void IGSxGUI::HistorypopupView::getData()
{
    m_historyData.clear();
    m_machineConstantsManager->getHistory(m_historyData);
    sui->tawParametersHistory->setVisible(true);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryClicked()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_ASML_COLORORANGE, AWESOME_CLOSE_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    sui->lblCloseImage->setBGColor(SUI::ColorEnum::White);
    sui->dialog->close();
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryHoverOn()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryHoverOff()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryPressed()
{
    std::string color = "#FF7F45";
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, color, AWESOME_CLOSE_SIZE);
}


void IGSxGUI::HistorypopupView::createSortingMap()
{
    std::vector<FPTR> paramNameFunctions;
    paramNameFunctions.push_back(&compareByParameterNameAsc);
    paramNameFunctions.push_back(&compareByParameterNameDesc);
    std::vector<FPTR> changedOnFunctions;
    changedOnFunctions.push_back(&compareByChangedOnAsc);
    changedOnFunctions.push_back(&compareByChangedOnDesc);
    std::vector<FPTR> changedByFunctions;
    changedByFunctions.push_back(&compareByChangedByAsc);
    changedByFunctions.push_back(&compareByChangedByDesc);
    std::vector<FPTR> reasonFunctions;
    reasonFunctions.push_back(&compareByReasonAsc);
    reasonFunctions.push_back(&compareByReasonDesc);
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ParameterName] = paramNameFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ChangedOn] =  changedOnFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ChangedBy] =  changedByFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::Reason] =  reasonFunctions;
}

void IGSxGUI::HistorypopupView::sortCollection(IGSxGUI::ParameterHistoryVector& tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder, SUI::Label* label)
{
    if (sortOrder == IGSxGUI::SortOrder::Ascending) {
        std::sort(tableData.begin(), tableData.end(), m_sortFunctionMap[sortColumn][0]);
        IGSxGUI::Util::setAwesome(label, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    } else {
        IGSxGUI::Util::setAwesome(label, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, STRING_BLUE_HEADER, SORT_ICON_SIZE);
        std::sort(tableData.begin(), tableData.end(), m_sortFunctionMap[sortColumn][1]);
    }
}

void IGSxGUI::HistorypopupView::arrangeTableData(IGSxGUI::ParameterHistoryVector& tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder)
{
    IGSxGUI::Util::setAwesome(sui->lblParameterNameHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblChangedOnHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblChangedByHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblReasonHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    sui->lblParameterNameHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblParameterNameHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, PARAMNAME_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblParameterNameHistoryHeaderButtonImage->setGeometry(PARAMNAME_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblChangedOnHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblChangedOnHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDON_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblChangedOnHistoryHeaderButtonImage->setGeometry(CHANGEDON_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblChangedByHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblChangedByHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDBY_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblChangedByHistoryHeaderButtonImage->setGeometry(CHANGEDBY_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblReasonHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblReasonHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, REASON_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblReasonHistoryHeaderButtonImage->setGeometry(REASON_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    switch (sortColumn) {
    case IGSxGUI::SortedByColumn::ParameterName:
        sui->lblParameterNameHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblParameterNameHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, PARAMNAME_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblParameterNameHistoryHeaderButtonImage->setGeometry(PARAMNAME_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblParameterNameHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::ChangedOn:
        sui->lblChangedOnHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblChangedOnHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDON_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblChangedOnHistoryHeaderButtonImage->setGeometry(CHANGEDON_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblChangedOnHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::ChangedBy:
        sui->lblChangedByHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblChangedByHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDBY_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblChangedByHistoryHeaderButtonImage->setGeometry(CHANGEDBY_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblChangedByHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::Reason:
        sui->lblReasonHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblReasonHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, REASON_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblReasonHistoryHeaderButtonImage->setGeometry(REASON_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblReasonHistoryHeaderButtonImage);
        break;
    default:
        break;
    }
    initializeTableRows(tableData);
}

void IGSxGUI::HistorypopupView::selectAllRows()
{
    std::vector<ParameterHistory>::iterator it;
    std::vector<ParameterHistory>::iterator it_end = m_historyData.end();
    for (size_t i = 0; i < m_historyData.size(); ++i) {
        m_historyData[i].setState(true);
    }
}

void IGSxGUI::HistorypopupView::onParameterNameHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ParameterName;
    m_paramNameOrder = (m_paramNameOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_paramNameOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_paramNameOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_paramNameOrder);
    }
}

void IGSxGUI::HistorypopupView::onChangedOnHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedOn;
    m_changedOnOrder= (m_changedOnOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_changedOnOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_changedOnOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_changedOnOrder);
    }
}

void IGSxGUI::HistorypopupView::onChangedByHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedBy;
    m_changedByOrder= (m_changedByOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_changedByOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_changedByOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_changedByOrder);
    }
}

void IGSxGUI::HistorypopupView::onReasonHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::Reason;
    m_reasonOrder= (m_reasonOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_reasonOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_reasonOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_reasonOrder);
    }
}
void IGSxGUI::HistorypopupView::formatParamNameBack(std::string& name)
{
    while (true) {
        std::size_t pos = name.find(STRING_NEWLINE);
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            return;
        }
    }
}
std::string IGSxGUI::HistorypopupView::getFullReasonFromHistoryData(std::string& paramName, std::string& oldvalue,  std::string& newvalue,  std::string& changedby, \
        std::string& timeStr)
{
    const char *time_details = timeStr.c_str();
    struct tm tm;
    strptime(time_details, "%Y-%m-%d  %H:%M:%S", &tm);
    time_t timeOfChange = mktime(&tm);  // t is now your desired time_t
    formatParamNameBack(paramName);
    std::vector<IGSxGUI::ParameterHistory>::iterator it = std::find_if(m_historyData.begin(), m_historyData.end(), \
            find_historyData(paramName, oldvalue, newvalue, changedby, timeOfChange));
    std::string actualReason = (*it).reason();
    return actualReason;
}

void IGSxGUI::HistorypopupView::onParameterHistoryHoverEntered(int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    std::string paramName = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string oldvalue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    std::string newvalue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
    std::string changedby = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
    std::string stubStr = "ParameterPath";  // To ignore default value search in m_historyData (will lead to crash)
    if (!contains_substr(paramName, stubStr)) {
        std::string timeStr = IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
        std::string tableReason = IGSxGUI::Util::getTextFromParameterUserControl(widget, 5);
        std::string actualReason = getFullReasonFromHistoryData(paramName, oldvalue, newvalue, changedby, timeStr);
        if (tableReason.compare(actualReason) != 0) {
            std::string formattedReason =  formatToolTipText(actualReason, TOOLTIP_WIDTH);
            sui->tawParametersHistory->setToolTip(formattedReason);
        }
    }
    bool selected = isParameterHistoryDataSelected(row);
    if (selected == true) {
        IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
    } else {
        IGSxGUI::Util::setParameterHistoryHoverEnteredStyle(widget);
    }
}

void IGSxGUI::HistorypopupView::onParameterHistoryHovLeft(int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    bool selected = isParameterHistoryDataSelected(row);
    if (selected == true) {
        IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
    } else {
        IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
        sui->tawParametersHistory->setToolTip(STRING_EMPTY);
    }
}

void IGSxGUI::HistorypopupView::onParameterHistoryClicked(int row)
{
    if (!m_isCtrlKeyPressed) {
        int totalRows = sui->tawParametersHistory->rowCount();
        for (int i = 0; i < totalRows; ++i) {
            SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(i, 0);
            IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
            std::vector<IGSxGUI::ParameterHistory>::iterator it = getParameterHistorySelectionForRow(i);
            it->setState(false);
        }
        SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(row, 0);
        IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
        std::vector<IGSxGUI::ParameterHistory>::iterator it = getParameterHistorySelectionForRow(row);
        it->setState(true);
    } else {
        SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(row, 0);
        bool rowSelected = isParameterHistoryDataSelected(row);
        if ( rowSelected) {
            IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
            std::vector<IGSxGUI::ParameterHistory>::iterator it = getParameterHistorySelectionForRow(row);
            it->setState(false);
        } else {
            IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
            std::vector<IGSxGUI::ParameterHistory>::iterator it = getParameterHistorySelectionForRow(row);
            it->setState(true);
        }
    }
}

std::vector<IGSxGUI::ParameterHistory>::iterator IGSxGUI::HistorypopupView::getParameterHistorySelectionForRow(int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    std::string paramName  = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string oldValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    std::string newValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
    std::string timeOfChangeStr = IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
    std::string changedBy = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
    std::string reason = IGSxGUI::Util::getTextFromParameterUserControl(widget, 5);
    const char *time_details = timeOfChangeStr.c_str();
    struct tm tm;
    strptime(time_details, "%Y-%m-%d  %H:%M:%S", &tm);
    time_t timeOfChange = mktime(&tm);  // t is now your desired time_t
    formatParamNameBack(paramName);
    ParameterHistory t_ParameterHistory(paramName, timeOfChange, changedBy, reason, oldValue, newValue, true);
    std::vector<IGSxGUI::ParameterHistory>::iterator it =  findParameterHistory(t_ParameterHistory);
    return it;
}
std::vector<IGSxGUI::ParameterHistory>::iterator  IGSxGUI::HistorypopupView::findParameterHistory(IGSxGUI::ParameterHistory t_ParameterHistory)
{
    std::string name =  t_ParameterHistory.parameter_name();
    std::string oldvalue = t_ParameterHistory.old_value();
    std::string newvalue = t_ParameterHistory.new_value();
    std::string changedby = t_ParameterHistory.changed_by();
    formatParamNameBack(name);
    std::vector<IGSxGUI::ParameterHistory>::iterator it = std::find_if(m_historyData.begin(), \
            m_historyData.end(), \
            find_historyData(name, oldvalue, newvalue, changedby, t_ParameterHistory.time_of_change()));
    return it;
}
bool IGSxGUI::HistorypopupView::isParameterHistoryDataSelected(int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    std::string paramName  = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string oldValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    std::string newValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
    std::string timeOfChangeStr = IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
    std::string changedBy = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
    std::string reason = IGSxGUI::Util::getTextFromParameterUserControl(widget, 5);
    const char *time_details = timeOfChangeStr.c_str();
    struct tm tm;
    strptime(time_details, "%Y-%m-%d  %H:%M:%S", &tm);
    time_t timeOfChange = mktime(&tm);  // t is now your desired time_t
    formatParamNameBack(paramName);
    std::vector<IGSxGUI::ParameterHistory>::iterator it = std::find_if(m_historyData.begin(), \
            m_historyData.end(), \
            find_historyData(paramName, oldValue, newValue, changedBy, timeOfChange));
    bool result = it->isSelected();
    return  (result);
}

bool IGSxGUI::HistorypopupView::isRowSelected(int row)
{
    std::vector<int> selectedRows = IGSxGUI::Util::getSelectedRowIndexes(sui->tawParametersHistory);
    return std::find(selectedRows.begin(), selectedRows.end(), row) != selectedRows.end();
}

void IGSxGUI::HistorypopupView::setParent(SUI::Widget *parent)
{
    IGSxGUI::Util::setParent(sui->dialog, parent);
}
void IGSxGUI::HistorypopupView::adjustTableRowVisibility(SUI::TableWidget *tablewidget, int numberOfRows)
{
    if (tablewidget) {
        int rowCount = tablewidget->rowCount();
        for (int i = 0; i < rowCount; ++i) {
            tablewidget->setRowVisible(i, false);
        }
        if (numberOfRows <= rowCount) {
            for (int i = 0; i < numberOfRows; ++i) {
                tablewidget->setRowVisible(i, true);
            }
        }
    }
}
int IGSxGUI::HistorypopupView::numberOfRowsVisisble(SUI::TableWidget *tablewidget)
{
    int  count = 0;
    if (tablewidget) {
        int rowCount = tablewidget->rowCount();
        for (int i = 0; i < rowCount; ++i) {
            if (tablewidget->isRowVisible(i))
                ++count;
        }
    }
    return count;
}

std::string IGSxGUI::HistorypopupView::formatToolTipText(const std::string& inStr, int width)
{
    std::string formattedText = inStr;
    if (width > 0) {
        std::vector<std::string> tokens;
        boost::split(tokens, inStr, boost::algorithm::is_any_of(STRING_NEWLINE));
        size_t totalTokens = tokens.size();
        std::string resultString = STRING_EMPTY;
        std::string currentLine = tokens[0];
        for (size_t index = 0; index < totalTokens; ++index) {
            currentLine = tokens[index];
            if (currentLine == "") {
                resultString += STRING_NEWLINE;
            } else {
                int tempLength = static_cast<int>(currentLine.length());
                if (tempLength > width) {
                    // the line would be too long, so finish it and start a new line with this word
                    resultString += formatToolTipTextUtil(tokens[index], width) + STRING_NEWLINE;
                } else {
                    resultString += tokens[index] + STRING_NEWLINE;
                }
            }
        }
        formattedText = resultString;
    }
    return formattedText;
}

std::string IGSxGUI::HistorypopupView::formatToolTipTextUtil(const std::string& inStr, int width)
{
    std::string formattedText = inStr;
    if (width > 0) {
        std::vector<std::string> tokens;
        boost::split(tokens, inStr, boost::algorithm::is_space());
        size_t totalTokens = tokens.size();
        std::string resultString = STRING_EMPTY;
        std::string currentLine = tokens[0];
        for (size_t index = 1; index < totalTokens; ++index) {
            int tempLength = static_cast<int>(currentLine.length() + 1 + tokens[index].length());
            if (tempLength > width) {
                // the line would be too long, so finish it and start a new line with this word
                resultString += currentLine + STRING_NEWLINE;
                currentLine = tokens[index];
            } else {
                currentLine += " " + tokens[index];
            }
        }
        formattedText = resultString + currentLine;
    }
    return formattedText;
}

std::pair <std::string, int> IGSxGUI::HistorypopupView::getFormattedsParamNameAndCalculateLineCount(const std::string& name)
{
    SUI::Widget* widget = sui->tawParametersHistory->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 585;
    return formatNameAndCalculateLineCount(name, widget, columnWidth);
}
std::pair <std::string, int> IGSxGUI::HistorypopupView::formatNameAndCalculateLineCount(const std::string& name, SUI::Widget* widget, int width)
{
    size_t search_pos = getSplitPosition(name, widget, width);
    static std::string retname = "";
    static int num_of_rows = 1;
    std::string tmpname = name;
    if (search_pos == 0) {
        std::string ret = retname + '\n' + tmpname;
        if (retname == "") {
            ret = tmpname;
            num_of_rows = 1;
        }
        int rows = num_of_rows;
        retname = "";
        num_of_rows = 1;
        return std::make_pair(ret, rows);
    }
    std::size_t found = tmpname.rfind('/', search_pos);
    if (found == std::string::npos) {
        std::size_t found = tmpname.find_first_of('(');
        // found <= 3 is to avoid indefinite looping that may occur when we find the same character '(' repeatedly which is moved to tmpname
        // found > search_pos is found after search position which is consdered as not found
        if (found == std::string::npos || found > search_pos || found <= 3 ) {
            std::size_t found = tmpname.rfind('_', search_pos);
            if (found == std::string::npos) {
                int position = getPositionOfLastUpperCaseCharacter(tmpname, search_pos);
                // <= 3 is to avoid indefinite looping that may occur when we find the same UPPERCASE character repeatedly which is moved to tmpname
                if (position <= 3) {
                    extractSubStr(search_pos, num_of_rows, retname, tmpname);
                } else {
                    extractSubStr(position, num_of_rows, retname, tmpname);
                }
            } else {
                extractSubStr(found+1, num_of_rows, retname, tmpname);
            }
        } else {
            extractSubStr(found, num_of_rows, retname, tmpname);
        }
    } else {
        // we do not want the units of type "(x/y)" gets split at '/'
        // split at first '(' for units which have more than one '('
        std::size_t found2 = tmpname.find_first_of('(');
        if (found2 != std::string::npos && found2 < found) {
            found = found2;
            extractSubStr(found, num_of_rows, retname, tmpname);
        } else {
            extractSubStr(found+1, num_of_rows, retname, tmpname);
        }
    }
    return formatNameAndCalculateLineCount(tmpname, widget, width);
}

size_t IGSxGUI::HistorypopupView::getSplitPosition(const std::string& name, SUI::Widget* widget, int width)
{
    int total_chars_width = 0;
    for (size_t i = 0; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 0);
        if (total_chars_width > width) {
            return i-1;
        }
    }
    return 0;
}

int IGSxGUI::HistorypopupView::getPositionOfLastUpperCaseCharacter(const std::string& name, int fromPos)
{
    int i = fromPos;
    for (; i > 0; --i) {
        if (::isupper(name[i]) && !::isupper(name[i - 1])) {
            return i;
        }
    }
    return i;
}

