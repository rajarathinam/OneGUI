/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMManager.cpp
| Author       : Saket K
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxSSMManager.cpp
| ! \brief       SSM Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSSMManager.hpp"
#include "IGSxLOG.hpp"
#include <boost/bind.hpp>
#include <algorithm>

using namespace IGSxSSM;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

IGSxGUI::SSMManager::SSMManager()
    : m_Instance(),
      m_Functions(),
      m_Groups(),
      m_ReachableStates(),
      m_ActiveStates(),
      m_Transitions()
{

}

IGSxGUI::SSMManager::~SSMManager()
{
    for(int functionIndex = 0 ; functionIndex < getFunctionCount(); ++functionIndex)
    {
        m_Functions[functionIndex]->unsubscribeGetStateResult();
        m_Functions[functionIndex]->unsubscribeSetStateResult();
        m_Functions[functionIndex]->unsubscribeStateUpdated();
        m_Functions[functionIndex]->unsubscribeTransitionCompleted();
        m_Functions[functionIndex]->unsubscribeTransitionStarted();
    }
}

void IGSxGUI::SSMManager::initialize()
{
    m_Groups.clear();
    m_States.clear();
    m_Transitions.clear();
    m_ReachableStates.clear();
    m_ActiveStates.clear();

    m_Instance = IGSxSSM::SSM::GetInstance();
    m_Functions = m_Instance->functions();


    m_Transitions.assign(6, TransitionData());


    for(int functionIndex = 0 ; functionIndex < getFunctionCount(); ++functionIndex)
    {
        m_Functions[functionIndex]->subscribeGetStateResult(boost::bind(&IGSxGUI::SSMManager::onGetStateResultFunction, this, functionIndex, _1, _2, _3, _4));
        m_Functions[functionIndex]->subscribeSetStateResult(boost::bind(&IGSxGUI::SSMManager::onSetStateResultFunction, this, functionIndex, _1));
        m_Functions[functionIndex]->subscribeStateUpdated(boost::bind(&IGSxGUI::SSMManager::onSetStateUpdatedFunction, this, functionIndex));
        m_Functions[functionIndex]->subscribeTransitionCompleted(boost::bind(&IGSxGUI::SSMManager::onSetTransitionCompletedFunction, this, functionIndex, _1, _2, _3, _4));
        m_Functions[functionIndex]->subscribeTransitionStarted(boost::bind(&IGSxGUI::SSMManager::onSetTransitionStartedFunction, this, functionIndex, _1, _2, _3));

        GroupConfigList groups = m_Functions[functionIndex]->config().groups();
        m_Groups.push_back(groups);

        StatesList list;
        m_States.push_back(list);

        for(int groupIndex = 0 ; groupIndex < getGroupCount(functionIndex); ++groupIndex)
        {
            m_States[functionIndex].push_back(groups[groupIndex].states());
        }
    }
}

int IGSxGUI::SSMManager::getFunctionCount() const
{
    return static_cast<int>(m_Functions.size());
}

int IGSxGUI::SSMManager::getGroupCount(const int functionIndex) const
{
    return static_cast<int>(m_Groups[functionIndex].size());
}

int IGSxGUI::SSMManager::getStatesCount(const int functionIndex, const int groupIndex) const
{
    return static_cast<int>(m_States[functionIndex][groupIndex].size());
}

IGSxGUI::TransitionData IGSxGUI::SSMManager::getActiveTransitionData(const int functionIndex) const
{
    return  m_Transitions[functionIndex];
}

void IGSxGUI::SSMManager::getActiveTransition(const int functionIndex) const
{
    m_Functions[functionIndex]->get_state();
}

bool IGSxGUI::SSMManager::isTransitionAbortable(const int functionIndex, const int stateId) const
{
    bool abortable = false;
    TransitionData currentTransition = m_Transitions[functionIndex];
    IGSxSSM::ReachableStateList::const_iterator end = currentTransition.ReachableStates.end() ;

    for(IGSxSSM::ReachableStateList::const_iterator it= currentTransition.ReachableStates.begin(); it!= end ; ++it )
    {
        if ((*it).state() == StateIDType(stateId))
        {
            abortable = (*it).can_be_aborted();
            break;
        }
    }
    return abortable;

}

void IGSxGUI::SSMManager::setTransition(const int functionIndex, const int newStateId)
{
    SystemFunctionPtr functionType =  m_Functions[functionIndex];

    functionType->set_state(StateIDType(newStateId));
}

IGSxGUI::InnerState IGSxGUI::SSMManager::getInnerState(const int functionIndex, const int stateId) const
{
    IGSxGUI::InnerState currentState = DISABLED;
    TransitionData currentTransition = m_Transitions[functionIndex];
    if ( (currentTransition.From == currentTransition.To) && (currentTransition.To == stateId) ) //If both transition Ids (from, to) are same then it is an active state.
    {
        currentState = ACTIVE;
    }
    else if((currentTransition.From == stateId))
    {
        currentState = TRANSITION_START;
    }
    else if((currentTransition.To == stateId))
    {
        currentState = TRANSITION_END;
    }
    else if ( (currentTransition.From != currentTransition.To) && (currentTransition.To != stateId) && (currentTransition.From != stateId) ) //If both transition Ids (from, to) are same then it is an active state.
    {
        currentState = DISABLED;
    }
    else if(isStateReachable(functionIndex, stateId))
    {
         currentState = REACHABLE;
    }
    return currentState;
}

void IGSxGUI::SSMManager::stateChanged()
{
    update();
}

bool IGSxGUI::SSMManager::isStateReachable(int functionIndex, int stateId) const
{
    bool isReachable = false;
    TransitionData currentTransition = m_Transitions[functionIndex];
    IGSxSSM::ReachableStateList::const_iterator end = currentTransition.ReachableStates.end() ;
    for(IGSxSSM::ReachableStateList::const_iterator it= currentTransition.ReachableStates.begin(); it!= end ; ++it )
    {
        if ((*it).state() == (StateIDType(stateId)))
        {
            isReachable = true;
            break;
        }
    }
    return isReachable;
}

void IGSxGUI::SSMManager::onGetStateResultFunction(const int functionIndex, const FunctionResultType &result, const StateIDType &from, const StateIDType &to, const ReachableStateList &reachable_states)
{
    m_Transitions[functionIndex].FunctionResult = result;
    m_Transitions[functionIndex].From = from;
    m_Transitions[functionIndex].To = to;
    m_Transitions[functionIndex].ReachableStates = reachable_states;
}

void IGSxGUI::SSMManager::onSetStateResultFunction(const int functionIndex,const FunctionResultType &result)
{
    m_Transitions[functionIndex].FunctionResult = result;
}

void IGSxGUI::SSMManager::onSetStateUpdatedFunction(const int /*functionIndex*/)
{

}

void IGSxGUI::SSMManager::onSetTransitionStartedFunction(const int functionIndex, const StateIDType &from, const StateIDType &to, const unsigned int duration)
{
    m_Transitions[functionIndex].From = from;
    m_Transitions[functionIndex].To = to;
    m_Transitions[functionIndex].ExpectedDuration = duration;
}

void IGSxGUI::SSMManager::onSetTransitionCompletedFunction(const int functionIndex, const StateIDType &from, const StateIDType &to, const TransitionResultType &result, const ReachableStateList &reachable_states)
{
    m_Transitions[functionIndex].TransitionResult = result;
    m_Transitions[functionIndex].From = from;
    m_Transitions[functionIndex].To = to;
    m_Transitions[functionIndex].ReachableStates = reachable_states;
    update();
}


std::string IGSxGUI::SSMManager::getFunctionName(const int functionIndex) const
{
   SystemFunctionPtr functionType =  m_Functions[functionIndex];
   SystemFunctionConfigType configType = functionType->config();
   return configType.description();
}

std::string IGSxGUI::SSMManager::getGroupName(const int functionIndex, const int groupIndex) const
{
    GroupConfigList group = m_Groups[functionIndex];
    return group[groupIndex].description();
}


IGSxGUI::StateDescriptionType IGSxGUI::SSMManager::getStateDescription(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].description();
}

IGSxGUI::StateDescriptionType IGSxGUI::SSMManager::getStateDescriptionById(const int functionIndex, const StateIDType& stateIdType) const
{
    IGSxGUI::StateDescriptionType desc;
    for(int groupIndex = 0 ; groupIndex < getGroupCount(functionIndex); ++groupIndex)
    {
        StateConfigList state = m_States[functionIndex][groupIndex];
        for(size_t stateIndex = 0 ; stateIndex < state.size(); ++stateIndex)
        {
            StateConfigType currentStateType = state[stateIndex];
            if (stateIdType == currentStateType.id())
            {
               desc = currentStateType.description();
               break;
            }
        }
    }
    return desc;
}

int IGSxGUI::SSMManager::getStateId(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].id();
}
