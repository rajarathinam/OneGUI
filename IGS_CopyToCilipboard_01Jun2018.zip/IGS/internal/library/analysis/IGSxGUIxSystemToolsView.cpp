/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsView.cpp
| Author       : Venugopal S
| Description  : Implementation of SystemTools view
|
| ! \file        IGSxGUIxSystemToolsView.cpp
| ! \brief       Implementation of SystemTools view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemToolsView.hpp"
#include <string>
#include <vector>
#include "IGSxGUIxMoc_SystemToolsView.hpp"
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIUserControl.h>
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SystemToolsView::SYSTEMTOOLS_LOAD_FILE = "IGSxGUIxSystemTools.xml";
const std::string IGSxGUI::SystemToolsView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const std::string IGSxGUI::SystemToolsView::STRING_EMPTY = "";

IGSxGUI::SystemToolsView::SystemToolsView() :
    sui(new SUI::SystemToolsView),
    m_selectedSystemToolRowNum(-1)
{
}

IGSxGUI::SystemToolsView::~SystemToolsView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SystemToolsView::show(SUI::Container *MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(SYSTEMTOOLS_LOAD_FILE.c_str(), MainScreenContainer);
    }
    sui->tawSystemTool->showGrid(false);

    SUI::Widget *widget = sui->tawSystemTool->getWidgetItem(0, 0);
    IGSxGUI::Util::setSystemToolUCTNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&SystemToolsView::onTableSystemToolRowPressed, this, 0);
    usercontrol->hoverEntered = boost::bind(&SystemToolsView::onSystemToolUCTHoverEntered, this, 0);
    usercontrol->hoverLeft = boost::bind(&SystemToolsView::onSystemToolUCTHoverLeft, this, 0);

    IGSxGUI::Util::setTextToSystemToolUserControl(widget, 0, "MBDS");
    IGSxGUI::Util::setTextToSystemToolUserControl(widget, 1, STRING_EMPTY);
    IGSxGUI::Util::setSystemToolUCTClickedStyle(sui->tawSystemTool->getWidgetItem(0, 0));
    m_selectedSystemToolRowNum = 0;
    sui->btnOpenSystemTool->setVisible(true);
}

void IGSxGUI::SystemToolsView::setActive(bool /*bActive*/)
{    
}

void IGSxGUI::SystemToolsView::onSystemToolUCTHoverLeft(int index)
{
    if (m_selectedSystemToolRowNum != index) {
        SUI::Widget *widget = sui->tawSystemTool->getWidgetItem(index, 0);
        IGSxGUI::Util::setSystemToolUCTHoverOffStyle(widget);
    }
}

void IGSxGUI::SystemToolsView::onSystemToolUCTHoverEntered(int index)
{
    if (m_selectedSystemToolRowNum != index) {
        SUI::Widget *widget = sui->tawSystemTool->getWidgetItem(index, 0);
        IGSxGUI::Util::setSystemToolUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::SystemToolsView::onTableSystemToolRowPressed(int rowindex)
{
    if (m_selectedSystemToolRowNum == rowindex)
    {
        m_selectedSystemToolRowNum = -1;
        IGSxGUI::Util::setSystemToolUCTNormalStyle(sui->tawSystemTool->getWidgetItem(rowindex, 0));

        sui->btnOpenSystemTool->setVisible(false);
    } else {
        m_selectedSystemToolRowNum = rowindex;
        IGSxGUI::Util::setSystemToolUCTClickedStyle(sui->tawSystemTool->getWidgetItem(rowindex, 0));

        sui->btnOpenSystemTool->setVisible(true);
    }
}

