/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of Dashboard Presenter test
|
| ! \file        IGSxGUIxDashboardPresenterTest.cpp
| ! \brief       Implementation of Dashboard Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxDashboardPresenterTest.hpp"
#include "IGSxGUIxKPIManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                |
|----------------------------------------------------------------------------*/
const string DashboardPresenterTest::KPI_WHITELIST_FILE = "IGSxGUIxKPIWhitelist.xml";
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(DashboardPresenterTest, GetKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    size_t noofKPIs = kpiMgr->getKPIs().size();
    size_t noofKPIsDP = dashboardPresenter.getKPIs().size();
    EXPECT_EQ(noofKPIs, noofKPIsDP);

    vector<IGSxGUI::KPI*> kpiMangerKPIs = kpiMgr->getKPIs();
    vector<IGSxGUI::KPI*> dashboardPresenterKPIs = dashboardPresenter.getKPIs();

    for (size_t index = 0; index < noofKPIs; ++index)
    {
        EXPECT_STRCASEEQ(kpiMangerKPIs[index]->getName().c_str(), dashboardPresenterKPIs[index]->getName().c_str());
    }
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetSystemKPIsTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    size_t noofKPIs = kpiMgr->getSystemKPIs().size();
    size_t noofKPIsDP = dashboardPresenter.getSystemKPIs().size();
    EXPECT_EQ(noofKPIs, noofKPIsDP);

    vector<IGSxGUI::KPI*> kpiMangerKPIs = kpiMgr->getSystemKPIs();
    vector<IGSxGUI::KPI*> dashboardPresenterKPIs = dashboardPresenter.getSystemKPIs();

    for (size_t index = 0; index < noofKPIs; ++index)
    {
        EXPECT_STRCASEEQ(kpiMangerKPIs[index]->getName().c_str(), dashboardPresenterKPIs[index]->getName().c_str());
    }
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetConsumablesTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    size_t noofKPIs = kpiMgr->getConsumables().size();
    size_t noofKPIsDP = dashboardPresenter.getConsumables().size();
    EXPECT_EQ(noofKPIs, noofKPIsDP);

    vector<IGSxGUI::KPI*> kpiMangerKPIs = kpiMgr->getConsumables();
    vector<IGSxGUI::KPI*> dashboardPresenterKPIs = dashboardPresenter.getConsumables();

    for (size_t index = 0; index < noofKPIs; ++index)
    {
        EXPECT_STRCASEEQ(kpiMangerKPIs[index]->getName().c_str(), dashboardPresenterKPIs[index]->getName().c_str());
    }
    delete kpiMgr;
}


TEST_F(DashboardPresenterTest, GetKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getKPI("AMP_PA0in_MpPpPower_On");
    IGSxGUI::KPI *kpiFromDashboardPresenter = dashboardPresenter.getKPI("AMP_PA0in_MpPpPower_On");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter != NULL);
    EXPECT_STRCASEEQ(kpiFromKPIManager->getName().c_str(), kpiFromDashboardPresenter->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    kpiFromDashboardPresenter = dashboardPresenter.getKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    kpiFromDashboardPresenter = dashboardPresenter.getKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetSystemKPITest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getSystemKPI("Closed_Loop_EUV_Power_at_IF");
    IGSxGUI::KPI *kpiFromDashboardPresenter = dashboardPresenter.getSystemKPI("Closed_Loop_EUV_Power_at_IF");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter != NULL);
    EXPECT_STRCASEEQ(kpiFromKPIManager->getName().c_str(), kpiFromDashboardPresenter->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    kpiFromDashboardPresenter = dashboardPresenter.getSystemKPI("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    kpiFromDashboardPresenter = dashboardPresenter.getSystemKPI(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetConsumableTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getConsumable("EUV_Pulse_Energy_Internal");
    IGSxGUI::KPI *kpiFromDashboardPresenter = dashboardPresenter.getConsumable("EUV_Pulse_Energy_Internal");
    ASSERT_TRUE(kpiFromKPIManager != NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter != NULL);
    EXPECT_STRCASEEQ(kpiFromKPIManager->getName().c_str(), kpiFromDashboardPresenter->getName().c_str());

    kpiFromKPIManager = kpiMgr->getKPI("");
    kpiFromDashboardPresenter = dashboardPresenter.getConsumable("");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);

    kpiFromKPIManager = kpiMgr->getKPI(" ");
    kpiFromDashboardPresenter = dashboardPresenter.getConsumable(" ");
    ASSERT_TRUE(kpiFromKPIManager == NULL);
    ASSERT_TRUE(kpiFromDashboardPresenter == NULL);
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetKPIValueSetsTestInvalid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getKPIValueSets("INVALID");
    EXPECT_EQ(0, kpivaluesets.size());
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetKPIValueSetsTestIValid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getKPI("AMP_PA0in_MpPpPower_On");
    std::vector<IGSxGUI::KPIValueSet*>  kpvaluesetsFromKPIManager = kpiFromKPIManager->getValueSets();

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getKPIValueSets("AMP_PA0in_MpPpPower_On");
    EXPECT_EQ(kpvaluesetsFromKPIManager.size(), kpivaluesets.size());

    for (size_t index = 0; index < kpvaluesetsFromKPIManager.size(); ++index)
    {
        EXPECT_STRCASEEQ(kpvaluesetsFromKPIManager[index]->getName().c_str(), kpivaluesets[index]->getName().c_str());
    }
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetSystemKPIValueSetsTestInvalid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getSystemKPIValueSets("INVALID");
    EXPECT_EQ(0, kpivaluesets.size());
    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetSystemKPIValueSetsTestIValid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getSystemKPI("Closed_Loop_EUV_Power_at_IF");
    std::vector<IGSxGUI::KPIValueSet*>  kpvaluesetsFromKPIManager = kpiFromKPIManager->getValueSets();

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getSystemKPIValueSets("Closed_Loop_EUV_Power_at_IF");
    EXPECT_EQ(kpvaluesetsFromKPIManager.size(), kpivaluesets.size());

    for (size_t index = 0; index < kpvaluesetsFromKPIManager.size(); ++index)
    {
        EXPECT_STRCASEEQ(kpvaluesetsFromKPIManager[index]->getName().c_str(), kpivaluesets[index]->getName().c_str());
    }
    delete kpiMgr;
}


TEST_F(DashboardPresenterTest, GetConsumableValueSetsTestInvalid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getConsumableValueSets("INVALID");
    EXPECT_EQ(0, kpivaluesets.size());

    delete kpiMgr;
}

TEST_F(DashboardPresenterTest, GetConsumableValueSetsTestIValid)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    IGSxGUI::DashboardPresenter dashboardPresenter(NULL, kpiMgr);

    IGSxGUI::KPI *kpiFromKPIManager = kpiMgr->getConsumable("EUV_Pulse_Energy_Internal");
    std::vector<IGSxGUI::KPIValueSet*>  kpvaluesetsFromKPIManager = kpiFromKPIManager->getValueSets();

    vector<IGSxGUI::KPIValueSet*> kpivaluesets = dashboardPresenter.getConsumableValueSets("EUV_Pulse_Energy_Internal");
    EXPECT_EQ(kpvaluesetsFromKPIManager.size(), kpivaluesets.size());

    for (size_t index = 0; index < kpvaluesetsFromKPIManager.size(); ++index)
    {
        EXPECT_STRCASEEQ(kpvaluesetsFromKPIManager[index]->getName().c_str(), kpivaluesets[index]->getName().c_str());
    }
    delete kpiMgr;
}


TEST_F(DashboardPresenterTest, SubscribeUnSubscribeForEventsOnKPIdataUpdatedTest)
{
    IGSxGUI::KPIManager* kpiMgr = new IGSxGUI::KPIManager();
    kpiMgr->initialize(KPI_WHITELIST_FILE);
    vector<IGSxGUI::KPI*> normalkpis = kpiMgr->getKPIs();
    vector<IGSxGUI::KPI*> systemkpis = kpiMgr->getSystemKPIs();
    vector<IGSxGUI::KPI*> consumables = kpiMgr->getConsumables();
    std::string expectedKPIName = normalkpis[0]->getName();
    std::string expectedSystemKPIName = systemkpis[0]->getName();
    std::string expectedConsumableName = consumables[0]->getName();
    typedef std::vector<double> KPIValueSet;



    KPIValueSet testvalueset;
    testvalueset.push_back(10.0);
    testvalueset.push_back(30.0);
    testvalueset.push_back(20.0);

    time_t testtime = time(0);
    IGSxKPI::KPIData testkpidata1("kpidata1", testtime, testvalueset);


    StubDashboardView *view = new StubDashboardView;
    view->setKPIName("NOTHING");
    view->setSystemKPIName("NOTHING");
    view->setConsumableName("NOTHING");
    IGSxGUI::DashboardPresenter dashboardPresenter(view, kpiMgr);
    EXPECT_STRCASEEQ("NOTHING", view->KPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->systemKPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->consumableName().c_str());

    dashboardPresenter.subscribeForEvents();
    normalkpis[0]->updateValue(testkpidata1, true);
    systemkpis[0]->updateValue(testkpidata1, true);
    consumables[0]->updateValue(testkpidata1, true);

    EXPECT_STRCASEEQ(expectedKPIName.c_str(), view->KPIName().c_str());
    EXPECT_STRCASEEQ(expectedSystemKPIName.c_str(), view->systemKPIName().c_str());
    EXPECT_STRCASEEQ(expectedConsumableName.c_str(), view->consumableName().c_str());

    view->setKPIName("NOTHING");
    view->setSystemKPIName("NOTHING");
    view->setConsumableName("NOTHING");

    EXPECT_STRCASEEQ("NOTHING", view->KPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->systemKPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->consumableName().c_str());

    dashboardPresenter.unsubscribeForEvents();
    normalkpis[0]->updateValue(testkpidata1, true);
    systemkpis[0]->updateValue(testkpidata1, true);
    consumables[0]->updateValue(testkpidata1, true);

    EXPECT_STRCASENE(expectedKPIName.c_str(), view->KPIName().c_str());
    EXPECT_STRCASENE(expectedSystemKPIName.c_str(), view->systemKPIName().c_str());
    EXPECT_STRCASENE(expectedConsumableName.c_str(), view->consumableName().c_str());

    EXPECT_STRCASEEQ("NOTHING", view->KPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->systemKPIName().c_str());
    EXPECT_STRCASEEQ("NOTHING", view->consumableName().c_str());

    delete kpiMgr;
    delete view;
}





