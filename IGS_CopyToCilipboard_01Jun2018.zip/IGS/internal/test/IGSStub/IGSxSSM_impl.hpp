/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxSSM stub
|
| ! \file        IGSxSSM_impl.hpp
| ! \brief       Header file for IGSxSSM stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXSSM_IMPL_HPP
#define IGSXSSM_IMPL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <map>
#include <FWQxUtils/SUITimer.h>
#include "IGSxSSM.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxSSM {

typedef std::map<StateIDType, std::vector<ReachableStateType> > ReachableStatesMapType;


class SSM_Stub :public SSM
{
 public:
//    virtual ~SSM_Stub();
    virtual SystemFunctionPtrList functions();
    static SSMPtr GetInstance();
 protected:
    SSM_Stub();

 private:
    void initialize();
    SystemFunctionPtrList functionTypes;
    static const std::string STRING_RESOURCE;
    static const std::string DATA_FILE_NAME;
};


class SystemFunction : public SystemFunctionType
{
public:
    explicit SystemFunction( const SystemFunctionConfigType & config, const ReachableStatesMapType& reachableStatesMap );
    //member functions
    const SystemFunctionConfigType& config() const;
    //set the state
    virtual void set_state( const StateIDType& target );
    //set the state
    virtual void get_state()const;
    //subscribe/un-subscribe to/from events
    //Transition started
    virtual void subscribeTransitionStarted(TransitionStartedCallback cb) ;
    virtual void unsubscribeTransitionStarted();
    //Transition completed
     virtual void subscribeTransitionCompleted(TransitionCompletedCallback cb);
    virtual void unsubscribeTransitionCompleted();
    //State changed
    virtual void subscribeStateUpdated(StateUpdatedCallback cb);
    virtual void unsubscribeStateUpdated();
    //Set state result
    virtual void subscribeSetStateResult(SetStateResultCallback cb);
    virtual void unsubscribeSetStateResult();
    //Get state result
    virtual void subscribeGetStateResult(GetStateResultCallback cb);
    virtual void unsubscribeGetStateResult();


private:
    void onTransitionCompleted();
    void onTransitionAborted();

    TransitionStartedCallback cb_transitionStarted;
    TransitionCompletedCallback cb_transitionCompleted;
    StateUpdatedCallback cb_stateUpdated;
    SetStateResultCallback cb_setStateResult;
    GetStateResultCallback cb_getStateResult;
    StateIDType mPreviousState;
    StateIDType mCurrentState;
    boost::shared_ptr<SUI::Timer> mTimer;
    ReachableStatesMapType mReachableStatesMap;
    int mTransitionResult;
    bool mIsTransitionAborted;
};



}  // namespace IGSxSSM
#endif  // IGSXSSM_IMPL_HPP
