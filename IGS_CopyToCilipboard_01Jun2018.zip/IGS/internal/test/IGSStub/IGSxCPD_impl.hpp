/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPD_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxCPD stub
|
| ! \file        IGSxCPD_impl.hpp
| ! \brief       Header file for IGSxCPD stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCPD_IMPL_HPP
#define IGSXCPD_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Timer;
}

namespace IGSxCPD {

class CPD_Stub :public CPD
{
public:
    static CPD* getInstance();

    // get all CPDs
    virtual void getCpds(MetaDescriptions& cpds);

    // start a CPD
    virtual void startCpd(const std::string& cpdName);

    // get the current active CPD
    virtual std::string getCurrentCpd();

    // query test results
    virtual void getLatestTestResults(const std::string& cpdName, const int maxNrOfResults, TestResultList& testResults);

    // CPD test finished event
    virtual void registerCpdFinishedCallback(const CpdFinishedCallback& cb);
    virtual void unregisterCpdFinishedCallback();

    // CPD started/stopped event. (In the near future) CPD's can be started from without OneGUI
    virtual void subscribeToTestManagerStateChanged(const TestManagerStateChangedCallback& cb);
    virtual void unsubscribeToTestManagerStateChanged();

protected:
    CPD_Stub();
    virtual ~CPD_Stub() {}

private:
    void on_timeout();

    std::string m_strCurrentTest;
    boost::shared_ptr<SUI::Timer> m_timer;  // timer for firing stopped event
    std::vector<std::string> m_listCPDReports;
    CpdFinishedCallback m_testStoppedCallback;
    TestManagerStateChangedCallback m_testManagerStateChangedCallback;

    static const int TASK_STOPPING_TIMER_INTERVAL;

    int m_OpenCPDTester;
};
}  // namespace IGSxCPD
#endif  // IGSXCPD_IMPL_HPP
