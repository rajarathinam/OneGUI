/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.cpp
| Author       : Saket k
| Description  : Stub impementation of IGSxSSM interface
|
| ! \file        IGSxSSM_impl.cpp
| ! \brief       Stub impementation of IGSxSSM interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxSSM.hpp"
#include "IGSxSSM_impl.hpp"
#include <boost/bind.hpp>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

using namespace IGSxSSM;

const int TIMER_INTERVAL = 5000;
const int NO_STATE = -1;

IGSxSSM::SystemFunction::SystemFunction(const SystemFunctionConfigType &config , const ReachableStatesMapType& reachableStatesMap): SystemFunctionType(config),
    mPreviousState(10),
    mCurrentState(10),
    mTimer(SUI::Timer::createTimer()),
    mReachableStatesMap(reachableStatesMap),
    mTransitionResult(0),
    mIsTransitionAborted(false)
{
    mTimer->timeout = boost::bind(&SystemFunction::onTransitionCompleted, this);
}

void IGSxSSM::SystemFunction::set_state(const IGSxSSM::StateIDType &target)
{
        if(NO_STATE == mPreviousState)
            mPreviousState = mCurrentState = target;

        if(mPreviousState == target ) //Transition is aborted
        {
            mIsTransitionAborted = true;
            IGSxSSM::StateIDType oldState = mCurrentState;
            mPreviousState = mCurrentState;
            mCurrentState = target;
            onTransitionAborted();

            mCurrentState = target;
            mPreviousState = oldState;
            cb_transitionStarted(StateIDType(mPreviousState), StateIDType(mCurrentState), TIMER_INTERVAL);
            mTimer->start(TIMER_INTERVAL);
         }
        else
        {
            mPreviousState = mCurrentState;
            mCurrentState = target;
            cb_transitionStarted(StateIDType(mPreviousState), StateIDType(mCurrentState), TIMER_INTERVAL);
            mTimer->start(TIMER_INTERVAL);
        }
 }

void IGSxSSM::SystemFunction::get_state() const
{
    if(!cb_getStateResult.empty())
    {
        ReachableStateList reachableStateList;
        ReachableStatesMapType::const_iterator it = mReachableStatesMap.find(StateIDType((mIsTransitionAborted) ? mPreviousState: mCurrentState));
        if(it != mReachableStatesMap.end() )
        {
            reachableStateList = it->second;
        }

        cb_getStateResult(FunctionResultType(FUNCTION_OK), StateIDType(mPreviousState), StateIDType(mCurrentState), reachableStateList);
    }
}

void IGSxSSM::SystemFunction::subscribeTransitionStarted(IGSxSSM::TransitionStartedCallback cb)
{
    cb_transitionStarted = cb;
}

void IGSxSSM::SystemFunction::unsubscribeTransitionStarted()
{
    if (cb_transitionStarted)
    {
        cb_transitionStarted = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeTransitionCompleted()
{
    if (cb_transitionCompleted)
    {
        cb_transitionCompleted = NULL;
    }
}

void IGSxSSM::SystemFunction::subscribeStateUpdated(IGSxSSM::StateUpdatedCallback cb)
{
    cb_stateUpdated = cb;
}

void IGSxSSM::SystemFunction::subscribeSetStateResult(IGSxSSM::SetStateResultCallback cb)
{
    cb_setStateResult = cb;
}

void IGSxSSM::SystemFunction::subscribeGetStateResult(IGSxSSM::GetStateResultCallback cb)
{
    cb_getStateResult = cb;
}

void IGSxSSM::SystemFunction::unsubscribeGetStateResult()
{
    if (cb_getStateResult)
    {
        cb_getStateResult = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeSetStateResult()
{
    if (cb_setStateResult)
    {
        cb_setStateResult = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeStateUpdated()
{
    if (cb_stateUpdated)
    {
        cb_stateUpdated = NULL;
    }
}

void IGSxSSM::SystemFunction::subscribeTransitionCompleted(IGSxSSM::TransitionCompletedCallback cb)
{
    cb_transitionCompleted = cb;
}


void SystemFunction::onTransitionCompleted()
{
    mTimer->stop();

    mPreviousState = mCurrentState;
    // transition completed.
    cb_setStateResult(FUNCTION_OK);

    ReachableStateList reachableStateList;
    ReachableStatesMapType::iterator it = mReachableStatesMap.find(StateIDType(mCurrentState));
    if(it != mReachableStatesMap.end() ) reachableStateList = it->second;

    mIsTransitionAborted = false;
    cb_transitionCompleted(StateIDType(mPreviousState), StateIDType(mCurrentState), TransitionResultType(OK), reachableStateList);
}

void SystemFunction::onTransitionAborted()
{
    mTimer->stop();

    // transition completed.
    cb_setStateResult(FUNCTION_OK);

    ReachableStateList reachableStateList;
    ReachableStatesMapType::iterator it = mReachableStatesMap.find(StateIDType(mPreviousState));
    if(it != mReachableStatesMap.end() ) reachableStateList = it->second;

    cb_transitionCompleted(StateIDType(mPreviousState), StateIDType(mCurrentState), TransitionResultType(ABORTED), reachableStateList);
}


