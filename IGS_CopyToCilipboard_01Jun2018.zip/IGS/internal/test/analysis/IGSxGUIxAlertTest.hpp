/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertTest.hpp
| Author       : Venugopal S
| Description  : Header file for Alert test
|
| ! \file        IGSxGUIxAlertTest.hpp
| ! \brief       Header file for Alert test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTTEST_HPP
#define IGSXGUIXALERTTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class AlertTest : public ::testing::Test
{
 public:
    AlertTest(){}
    virtual ~AlertTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXALERTTEST_HPP
