/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysis.cpp
| Author       : Venugopal S
| Description  : Implementation of Analysis plugin
|
| ! \file        IGSxGUIxAnalysis.cpp
| ! \brief       Implementation of Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxAnalysisView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Analysis::Analysis():
    m_adtManager(new ADTManager())
{
    m_adtManager->initialize();
    m_analysisView = new IGSxGUI::AnalysisView();
    m_adtView = new IGSxGUI::ADTView(m_adtManager);
}

IGSxGUI::Analysis::~Analysis()
{
    delete m_analysisView;
    delete m_adtManager;
    delete m_adtView;

}
void IGSxGUI::Analysis::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_analysisView->show(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::Analysis::showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_analysisView->setActive(true);
    m_adtView->show(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::Analysis::setActive(bool bActive)
{
    m_analysisView->setActive(bActive);
}
