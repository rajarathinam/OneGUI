/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <SUIApplication.h>
#include <SUIIOException.h>
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxGUIxIStandAloneView.hpp"
#include "IGSxGUIxStandAloneView.hpp"
#include "IGSxIStubView.hpp"
#include "IGSxStubView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    int result;
    // instantiate the application
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc, argv);

    if (argc == 1)
    {
        IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
        mainView->show();
        result = app->exec();
        delete mainView;
    } else {
        std::string strPluginName(argv[1]);

        if (strPluginName.compare("simulation") == 0)
        {
           IGSxGUI::IStubView *stubView;
           stubView = new IGSxGUI::StubView();
           stubView->show();

           IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
           mainView->show();

           result = app->exec();
           delete mainView;
           delete stubView;
        } else {
            IGSxGUI::IStandAloneView *standAloneView;
            standAloneView = new IGSxGUI::StandAloneView();
            standAloneView->show(strPluginName);

            result = app->exec();
            delete standAloneView;
        }
    }
    // execute the application (main eventloop)
    return result;
}

