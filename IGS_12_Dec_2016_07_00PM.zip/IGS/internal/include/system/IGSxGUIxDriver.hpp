/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriver.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver
|
| ! \file        IGSxGUIxDriver.hpp
| ! \brief       Header file for Driver
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef DRIVER_HPP
#define DRIVER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <string>
#include "IGSxITS.hpp"

using IGSxITS::MetaDescription;
using IGSxITS::DriverState;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class Driver
{
 public:
    Driver(const MetaDescription& metaDescription, DriverState::DriverStateEnum driverState);
    virtual ~Driver();

    void updateDriverState(DriverState::DriverStateEnum driverState);
    DriverState::DriverStateEnum getState();
    std::string getName() const;
    std::string getDisplayName() const;
    bool isImplemented();
    typedef boost::function<void(DriverState::DriverStateEnum, std::string)> stateDriverChanged;
    void registerToDriverStateChanged(const stateDriverChanged& cb, bool bIsFromSysFun = false);

 private:
    std::string m_name;
    std::string m_displayName;
    DriverState::DriverStateEnum m_driverState;

    stateDriverChanged m_stateDriverChanged;
    stateDriverChanged m_stateChanged;
    bool m_isImplemented;
    static const char* NOT_IMPLEMENTED_TAG;
};

struct compareDriver
{
    bool operator()(const IGSxGUI::Driver* lhs, const IGSxGUI::Driver* rhs) const
    {
        return lhs->getDisplayName() < rhs->getDisplayName();
    }
};
}  // namespace IGSxGUI

#endif  // DRIVER_HPP
