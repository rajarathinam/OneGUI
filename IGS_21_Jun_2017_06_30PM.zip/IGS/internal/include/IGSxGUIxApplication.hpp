#ifndef IGSXGUIXAPPLICATION_H
#define IGSXGUIXAPPLICATION_H
#include <string>

class IGSxGUIxApplication
{
 public:
    explicit IGSxGUIxApplication(const std::string& resourcePath);
    int exec();
 private:
    std::string m_resourcePath;
};

#endif  // IGSXGUIXAPPLICATION_H
