/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application view
|
| ! \file        IGSxGUIxMainView.cpp
| ! \brief       Implementation of Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxMoc_SplashView.hpp"
#include "IGSxGUIxUtil.hpp"
#include <SUIDialog.h>
#include <SUIProgressBar.h>
#include <SUIGraphicsView.h>
#include <SUILabel.h>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SplashView::SPLASHVIEW_LOAD_FILE = "IGSxGUIxSplashView.xml";


IGSxGUI::SplashView::SplashView():
    sui(new SUI::SplashView)
{
    if (sui != NULL)
    {
        sui->setupSUI(SPLASHVIEW_LOAD_FILE.c_str());
    }
    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::setAwesome(sui->lblCopyrightImage, IGSxGUI::AwesomeIcon::AI_fa_copyright, SUI::ColorEnum::Gray);
}
IGSxGUI::SplashView::~SplashView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SplashView::show()
{
    sui->dialog->show();
}

