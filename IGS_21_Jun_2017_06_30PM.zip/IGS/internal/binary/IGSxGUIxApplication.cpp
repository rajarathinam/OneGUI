
#include <string>
#include <SUIApplication.h>
#include <SUIResourcePath.h>
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxIStubView.hpp"
#include "IGSxStubView.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxApplication.hpp"

IGSxGUIxApplication::IGSxGUIxApplication(const std::string &resourcePath):m_resourcePath(resourcePath)
{
}

int IGSxGUIxApplication::exec()
{
    char **argv = NULL;
    int argc = 0;

    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc, &argv[0]);
    SUI::ResourcePath::getInstance()->setResourcePath(m_resourcePath);

    IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
    splashView->show();

    IGSxGUI::PluginFactory::getInstance().initialize();
    delete splashView;
    splashView = NULL;
    // IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
    // mainView->show();

    int result = app->exec();
    // delete mainView;
    // mainView = NULL;
    return result;
}

