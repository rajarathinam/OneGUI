/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxStubView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Stub View
|
| ! \file        IGSxStubView.hpp
| ! \brief       Header file for Stub View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXSTUBVIEW_HPP
#define IGSXSTUBVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxIStubView.hpp"
#include "IGSxStubPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class StubView;
}  // namespace SUI

namespace IGSxGUI{

class StubView : public IStubView
{
 public:
    StubView();
    ~StubView();

    void show();
    void showStatus(const std::string& strStatus);
    void updateKPI(const std::string& kpiName, const std::string&, const vector<double>& values);

 private:
    void onInitializeButtonPressed();
    void onTerminateButtonPressed();
    void onSetButtonPressed();
    void onKPIValueSetButtonPressed();
    void onSystemFunctionSelected();
    void onddbKPIValueChanged();

    void onSetAllInitializedPressed();
    void onSetAllInitializingPressed();
    void onSetAllTerminatedPressed();
    void onSetAllTerminatingPressed();
    void onSetAllRecRequiredPressed();

    void onCheckBoxStateChanged(bool checked);
    void onCheckBoxcbxGenerateKpiDataChanged(bool checked);

    void onRaiseAlertsStateChanged(bool checked);
    void onRaiseAlertClicked();

    SUI::StubView *sui;
    StubPresenter *m_presenter;
    static std::string STUBVIEW_LOAD_FILE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMVIEW_HPP
