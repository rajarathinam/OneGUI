/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIStubTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for IGSxKPI Stub test
|
| ! \file        IGSxKPIStubTest.hpp
| ! \brief       Header file for IGSxKPI Stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPISTUBTEST_HPP
#define IGSXKPISTUBTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include "IGSxKPI.hpp"
#include "IGSxKPIParser.hpp"
using IGSxKPI::KPI;
using IGSxKPI::KPIParser;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class IGSxKPIStubTest : public ::testing::Test
{
 public:
  IGSxKPIStubTest(){}
  virtual ~IGSxKPIStubTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXKPISTUBTEST_HPP
