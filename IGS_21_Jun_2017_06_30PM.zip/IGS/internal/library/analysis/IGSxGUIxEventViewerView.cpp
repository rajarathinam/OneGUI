/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerView.cpp
| Author       : Surya Tiwari
| Description  : Implementation of Event Viewer view
|
| ! \file        IGSxGUIxEventViewerView.cpp
| ! \brief       Implementation of Event Viewer view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <fstream>
#include "IGSxGUIxEventViewerView.hpp"
#include "IGSxGUIxMoc_EventViewerView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxCOMMON.hpp"
#include <SUIButton.h>
#include <SUILabel.h>
#include <SUITextArea.h>
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::EventViewerView::LOAD_FILE_EVENT_VIEWER = "IGSxGUIxEventViewer.xml";
const std::string IGSxGUI::EventViewerView::STRING_LAST_UPDATED = "Last Updated: ";
const std::string IGSxGUI::EventViewerView::STRING_NO_FILE = "No File";
const std::string IGSxGUI::EventViewerView::STRING_EVENTVIEWER_SHOWN = "EventViewer is shown.";
const int IGSxGUI::EventViewerView::READ_NUM_LINES = 1000;

IGSxGUI::EventViewerView::EventViewerView() :
    sui(new SUI::EventViewerView)
{
    m_presenter = new EventViewerPresenter(this);

    m_cirbufMostRecentFile.set_capacity(READ_NUM_LINES);
    m_cirbufPrevRecentFile.set_capacity(0);
}
IGSxGUI::EventViewerView::~EventViewerView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }

    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::EventViewerView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(LOAD_FILE_EVENT_VIEWER.c_str(), MainScreenContainer);
        sui->textAreaEventViewerLog->setAutoScroll(true);
    }

    sui->buttonUpdateLog->clicked = boost::bind(&EventViewerView::onUpdateLogButtonPressed, this);

    if (bIsFirstTimeDisplay)
    {
        onUpdateLogButtonPressed();
    } else {
        std::string fulltext = "";
        sui->lblLastUpdatedDate->setText(m_lastupdateddate);
       if (!m_cirbufPrevRecentFile.empty())
       {
           boost::circular_buffer<std::string>::iterator it;
           boost::circular_buffer<std::string>::iterator end_it = m_cirbufPrevRecentFile.end();
           for (it = m_cirbufPrevRecentFile.begin(); it != end_it; ++it)
           {
            fulltext += (*it);
           }
       }
       if (!m_cirbufMostRecentFile.empty())
       {
           boost::circular_buffer<std::string>::iterator it;
           boost::circular_buffer<std::string>::iterator end_it = m_cirbufMostRecentFile.end();
           for (it = m_cirbufMostRecentFile.begin(); it != end_it; ++it)
           {
               fulltext += (*it);
           }
       }
       sui->textAreaEventViewerLog->clearText();
       sui->textAreaEventViewerLog->setText(fulltext);
    }

    IGS_INFO(STRING_EVENTVIEWER_SHOWN);
}

void IGSxGUI::EventViewerView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::EventViewerView::onUpdateLogButtonPressed()
{
    m_cirbufMostRecentFile.clear();
    m_cirbufPrevRecentFile.clear();
    UpdateLastUpdatedDateTime();

    sui->textAreaEventViewerLog->clearText();
    std::string currentfilename;
    std::string prevfilename;
    m_presenter->getEventLog(currentfilename, prevfilename);
    std::fstream curreventlog;
    curreventlog.open(currentfilename.c_str(), std::fstream::in);
    std::string gline;
    bool fileReadactive = false;
    if (curreventlog.is_open())
    {
        while (NULL != std::getline(curreventlog, gline))
        {
            m_cirbufMostRecentFile.push_back(gline + "<br />");
        }
        fileReadactive = true;
        curreventlog.close();
    }


    int mostrecentlogfilesize = static_cast<int>(m_cirbufMostRecentFile.size());
    if (mostrecentlogfilesize < READ_NUM_LINES)  // Less Lines in latest file, Read second latest file
    {
        m_cirbufPrevRecentFile.set_capacity(READ_NUM_LINES - mostrecentlogfilesize);
        std::fstream preveventlog;

        preveventlog.open(prevfilename.c_str(), std::fstream::in);
        if (preveventlog.is_open())
        {
            while (NULL != std::getline(preveventlog, gline))
            {
                m_cirbufPrevRecentFile.push_back(gline + "<br />");
            }
            fileReadactive = true;
            preveventlog.close();
        }
    }

    if (fileReadactive)
    {
        std::string fulltext;
        boost::circular_buffer<std::string>::iterator it;
        boost::circular_buffer<std::string>::iterator end_it = m_cirbufPrevRecentFile.end();
        for (it = m_cirbufPrevRecentFile.begin(); it != end_it; ++it)
        {
            fulltext += (*it);
        }
        end_it = m_cirbufMostRecentFile.end();
        for (it = m_cirbufMostRecentFile.begin(); it != end_it; ++it)
        {
            fulltext += (*it);
        }
        sui->textAreaEventViewerLog->setText(fulltext);
    } else {
        sui->textAreaEventViewerLog->setText(STRING_NO_FILE);
    }
}

void IGSxGUI::EventViewerView::UpdateLastUpdatedDateTime()
{
    m_lastupdateddate = STRING_LAST_UPDATED + SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME);
    sui->lblLastUpdatedDate->setText(m_lastupdateddate);
}
