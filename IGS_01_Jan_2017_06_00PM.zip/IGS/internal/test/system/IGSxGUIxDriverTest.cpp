/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver test
|
| ! \file        IGSxGUIxDriverTest.cpp
| ! \brief       Implementation of Driver test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDriverTest.hpp"
#include <string>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        SystemDriverTestParam,
                        ::testing::Values("SF Environmental Mgt"));

TEST_P(SystemDriverTestParam, Test2)
{
    MetaDescription obj("SF Environmental Mgt", "SF Environmental Mgt");
    IGSxGUI::Driver* sys = new IGSxGUI::Driver(obj, DriverState::DS_INITIALIZED);
    std::string name = sys->getName();
    EXPECT_STRCASEEQ(name.c_str(), "SF Environmental Mgt");

    delete sys;
}

TEST_P(SystemDriverTestParam, Test3)
{
    MetaDescription obj("SF Environmental Mgt", "SF Environmental Mgt");
    IGSxGUI::Driver* sys = new IGSxGUI::Driver(obj, DriverState::DS_INITIALIZED);

    DriverState::DriverStateEnum drvstate = sys->getState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_INITIALIZED");

    delete sys;
}

TEST_P(SystemDriverTestParam, Test4)
{
    MetaDescription obj("SF Environmental Mgt", "SF Environmental Mgt");
    IGSxGUI::Driver* sys = new IGSxGUI::Driver(obj, DriverState::DS_TERMINATED);

    DriverState::DriverStateEnum drvstate = sys->getState();
    EXPECT_STRCASEEQ(DriverState::toString(drvstate).c_str(), "DS_TERMINATED");

    delete sys;
}
