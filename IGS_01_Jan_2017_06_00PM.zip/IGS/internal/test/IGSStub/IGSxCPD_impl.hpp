/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPD_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxCPD stub
|
| ! \file        IGSxCPD_impl.hpp
| ! \brief       Header file for IGSxCPD stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCPD_IMPL_HPP
#define IGSXCPD_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Timer;
}

namespace IGSxCPD {

class CPD_Stub :public CPD
{
 public:
    static CPD* getInstance();

    // get all tests
    virtual void getTests(MetaDescriptions& tests);

    // start a test
    virtual void startTest(const std::string& testName);

    // get the current active test
    // returns the name of the current active test
    // returns an empty string when no test is active
    virtual std::string getCurrentTest();

    // test stopped event
    virtual void subscribeToTestStopped(const TestStoppedCallback& cb);
    virtual void unsubscribeToTestStopped();
 protected:
    CPD_Stub();
    virtual ~CPD_Stub() {}

 private:
    void on_timeout();

    std::string m_strCurrentTest;
    boost::shared_ptr<SUI::Timer> m_timer;  // timer for firing stopped event
    TestStoppedCallback m_testStoppedCallback;
    static const int TASK_STOPPING_TIMER_INTERVAL;
};
}  // namespace IGSxCPD
#endif  // IGSXCPD_IMPL_HPP
