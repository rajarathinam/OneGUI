/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Analysis Presenter
|
| ! \file        IGSxGUIxAnalysisPresenter.cpp
| ! \brief       Implementation of Analysis Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxAnalysisPresenter.hpp"
#include "IGSxGUIxADT.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::AnalysisPresenter::AnalysisPresenter(IAnalysisView* view):
    m_view(view)
{
}

IGSxGUI::AnalysisPresenter::~AnalysisPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::ADT *> IGSxGUI::AnalysisPresenter::getADTs()
{
    return m_pADTManager->retrieveAll();
}


bool IGSxGUI::AnalysisPresenter::startADT(std::string adtName)
{
    IGSxGUI::ADT* adt = m_pADTManager->getADT(adtName);
    return adt->start();
}




