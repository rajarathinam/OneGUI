/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerView.hpp
| Author       : Surya Tiwari
| Description  : Header file for EventViewer view
|
| ! \file        IGSxGUIxEventViewerView.hpp
| ! \brief       Header file for EventViewer view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXEVENTVIEWERVIEW_HPP
#define IGSXGUIXEVENTVIEWERVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/circular_buffer.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxIEventViewerView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class EventViewerView;
}

namespace IGSxGUI{
class EventViewerView : public IEventViewerView
{
 public:
    EventViewerView();
    virtual ~EventViewerView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    EventViewerView(const EventViewerView&);
    EventViewerView& operator=(const EventViewerView&);

    void onUpdateLogButtonPressed();
    void UpdateLastUpdatedDateTime();
    const std::string currentDateTime();

    SUI::EventViewerView *sui;

    static const std::string LOAD_FILE_EVENT_VEIWER;
    static const int READ_NUM_LINES;
    boost::circular_buffer<std::string> cirbuf;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXEVENTVIEWERVIEW_HPP
