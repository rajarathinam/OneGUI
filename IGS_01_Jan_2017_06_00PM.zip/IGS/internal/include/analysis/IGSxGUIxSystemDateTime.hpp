/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxSystemDateTime.hpp
| Author       : Surya Tiwari
| Description  : Header file for System Date and Time
|
| ! \file        IGSxGUIxSystemDateTime.hpp
| ! \brief       Header file for System Date and Time
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMDATETIME_HPP
#define IGSXGUIXSYSTEMDATETIME_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxCOMMON.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class SystemDateTime
{
 public:
    typedef enum
    {
        STR_DATE,
        STR_TIME
    }eSystemDateTime;

    const std::string SystemCurrentDateTime(SystemDateTime::eSystemDateTime strname)
    {
        time_t     now = time(0);
        struct tm  tstruct;
        char       buf[80];
        tstruct = *localtime_r(&now, &tstruct);
        if (strname == STR_TIME)
        {
            strftime(buf, sizeof(buf), "%l:%M%p", &tstruct);
        } else {
            strftime(buf, sizeof(buf), "%Y-%m-%d", &tstruct);
        }
        return (std::string)buf;
    }
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMDATETIME_HPP
