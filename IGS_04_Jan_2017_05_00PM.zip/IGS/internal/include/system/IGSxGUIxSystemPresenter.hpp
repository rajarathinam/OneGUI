/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System plugin presenter
|
| ! \file        IGSxGUIxSystemPresenter.hpp
| ! \brief       Header file for System plugin presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMPRESENTER_HPP
#define IGSXGUIXSYSTEMPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxISystemView.hpp"
#include "IGSxITS.hpp"
#include "IGSxGUIxDriverManager.hpp"

using IGSxITS::DriverStatus;
using IGSxITS::InitTerminate;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SystemPresenter
{
 public:
    explicit SystemPresenter(ISystemView* view, DriverManager* pDriverManager);
    virtual ~SystemPresenter();

    void Initialize();
    void Terminate();
    void Resolve();
    std::vector<SystemFunction*> getSystemFunctions() const;
    std::vector<Driver*> getDrivers(const std::string systemFunction) const;
    int getInitializedDriverCount() const;
    SystemState::SystemStateEnum getSystemState() const;

 private:
    SystemPresenter(const SystemPresenter& sysPresenter);
    SystemPresenter& operator=(const SystemPresenter& sysPresenter);
    DriverManager* m_pDriverManager;
    ISystemView *m_view;
    void handleException(const std::string& eMsg);
    void onInitializeComplete(IGS::Result result) const;
    void onTerminateComplete(IGS::Result result) const;

    void onSysFunStateChanged(DriverState::DriverStateEnum state, std::string strSysFunction, int nInitializedDriverCount, int nTerminatedDriverCount) const;
    void onDriverStateChanged(DriverState::DriverStateEnum state, std::string strDriver) const;
    void onSystemStateChanged(SystemState::SystemStateEnum state) const;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMPRESENTER_HPP
