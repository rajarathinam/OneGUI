/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemFunction.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System Function
|
| ! \file        IGSxGUIxSystemFunction.hpp
| ! \brief       Header file for System Function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMFUNCTION_HPP
#define IGSXGUIXSYSTEMFUNCTION_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <vector>
#include <string>
#include "IGSxITS.hpp"
#include "IGSxGUIxDriver.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class SystemFunction
{
 public:
    explicit SystemFunction(const MetaDescription& metaDescription);
    virtual ~SystemFunction();

    void addDriver(const IGSxITS::MetaDescription metaDescription, const DriverState::DriverStateEnum driverState);
    void updateDriverState(const std::string driverName, const DriverState::DriverStateEnum driverState);
    Driver* getDriver(const std::string& name) const;
    bool isManagingDriver(const std::string& name) const;
    std::vector<Driver*> getDrivers() const;
    int getDriverCount() const;
    std::string getName() const;
    std::string getDescription() const;
    DriverState::DriverStateEnum getState() const;

    typedef boost::function<void(DriverState::DriverStateEnum, std::string, int, int)> stateSysFunChanged;
    typedef boost::function<void()> stateMainDetermine;
    void registerToDetermineMainState(const stateMainDetermine& cb);
    void registerToSysFunStateChanged(const stateSysFunChanged& cb);
 private:
    void onDriverStateChanged(DriverState::DriverStateEnum state, std::string strDriver);
    void determineState();

    std::vector<Driver*> m_drivers;
    int m_driverCount;
    MetaDescription m_metaDescription;
    DriverState::DriverStateEnum m_SysFunState;
    stateSysFunChanged m_stateSysFunChanged;
    stateMainDetermine m_stateMainDetermine;
};

struct compareSystemFunction
{
    bool operator()(const IGSxGUI::SystemFunction* lhs, const IGSxGUI::SystemFunction* rhs) const
    {
        return lhs->getDescription() < rhs->getDescription();
    }
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXSYSTEMFUNCTION_HPP
