/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.cpp
| ! \brief       Implementation of KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::KPIValueSet::KPIValueSet(const IGSxKPI::KPIValueSetDefinition &kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description()),
    m_unit(kpiDefinition.unit()),
    m_time(0),
    m_valueList(0, 0)
{
}

IGSxGUI::KPIValueSet::~KPIValueSet()
{
}

string IGSxGUI::KPIValueSet::getName() const
{
    return m_name;
}

string IGSxGUI::KPIValueSet::getDescription() const
{
    return m_desc;
}

string IGSxGUI::KPIValueSet::getUnit() const
{
    return m_unit;
}

void IGSxGUI::KPIValueSet::addValue(const vector<double>* valueList)
{
    m_valueList.clear();
    for (size_t i = 0; i < valueList->size(); i++)
    {
        m_valueList.push_back(valueList->at(i));
    }
}

void IGSxGUI::KPIValueSet::addTime(const time_t time)
{
    m_time = time;
}

vector<double> IGSxGUI::KPIValueSet::getValue() const
{
    return m_valueList;
}

time_t IGSxGUI::KPIValueSet::getTime() const
{
    return m_time;
}
