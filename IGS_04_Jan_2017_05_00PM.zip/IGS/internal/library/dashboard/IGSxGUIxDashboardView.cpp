/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <sstream>
#include <iomanip>
#include <vector>
#include <utility>
#include <string>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUITableWidget.h>
#include <SUIPlotWidget.h>
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIPlotAxisEnum.h>
#include <SUIUserControl.h>
#include <SUILabel.h>
#include <SUIGroupBox.h>
#include <SUIScrollBar.h>




/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");
const std::string IGSxGUI::DashboardView::STRING_TIME = "Time";
const int IGSxGUI::DashboardView::SYSTEMKPIS_COUNT = 5;
const int IGSxGUI::DashboardView::CONSUMABLES_COUNT = 9;

const int IGSxGUI::DashboardView::NO_OF_PLOTITEM_VALUES = 20;

const float IGSxGUI::DashboardView::HISTOGRAM_BAR_START_VALUE = 0.6;
const float IGSxGUI::DashboardView::HISTOGRAM_BAR_END_VALUE = 1.4;

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView), m_firstTimeDashboardDisplay(true)
{
    m_presenter = new DashboardPresenter(this, pKpiManager);
    m_circularBuffer1.set_capacity(NO_OF_PLOTITEM_VALUES);
    m_circularBuffer2.set_capacity(NO_OF_PLOTITEM_VALUES);
    m_circularBuffer3.set_capacity(NO_OF_PLOTITEM_VALUES);
    m_circularBuffer4.set_capacity(NO_OF_PLOTITEM_VALUES);
    m_circularBuffer5.set_capacity(NO_OF_PLOTITEM_VALUES);

    for (int index = 0; index < NO_OF_PLOTITEM_VALUES; ++index)
    {
        m_circularBuffer1.push_back(0.0);
        m_circularBuffer2.push_back(0.0);
        m_circularBuffer3.push_back(0.0);
        m_circularBuffer4.push_back(0.0);
        m_circularBuffer5.push_back(0.0);
    }
}
IGSxGUI::DashboardView::~DashboardView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
    if (histogram1 != NULL)
    {
        delete histogram1;
        histogram1 = NULL;
    }
    if (histogram2 != NULL)
    {
        delete histogram2;
        histogram2 = NULL;
    }
    if (histogram3 != NULL)
    {
        delete histogram3;
        histogram3 = NULL;
    }
    if (histogram4 != NULL)
    {
        delete histogram4;
        histogram4 = NULL;
    }
    if (histogram5 != NULL)
    {
        delete histogram5;
        histogram5 = NULL;
    }
}
const std::string IGSxGUI::DashboardView::currentDateTime(const std::string& dateTime) const
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%02l:%02M", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}
void IGSxGUI::DashboardView::buildHistogramGraphs()
{
    // KPI <-> Histogram Map
    histogram1 = new SUI::PlotHistogramItem("Histogram1");
    if (histogram1 != NULL)
    {
        histogram1->setBrushColor(SUI::ColorEnum::Blue);
        histogram1->attach(sui->plwSystemKPIGraph1);
    }

    histogram2 = new SUI::PlotHistogramItem("Histogram2");
    if (histogram2 != NULL)
    {
        histogram2->setBrushColor(SUI::ColorEnum::Blue);
        histogram2->attach(sui->plwSystemKPIGraph2);
    }

    histogram3 = new SUI::PlotHistogramItem("Histogram3");
    if (histogram3 != NULL)
    {
        histogram3->setBrushColor(SUI::ColorEnum::Blue);
        histogram3->attach(sui->plwSystemKPIGraph3);
    }

    histogram4 = new SUI::PlotHistogramItem("Histogram4");
    if (histogram4 != NULL)
    {
        histogram4->setBrushColor(SUI::ColorEnum::Blue);
        histogram4->attach(sui->plwSystemKPIGraph4);
    }

    histogram5 = new SUI::PlotHistogramItem("Histogram5");
    if (histogram5 != NULL)
    {
        histogram5->setBrushColor(SUI::ColorEnum::Blue);
        histogram5->attach(sui->plwSystemKPIGraph5);
    }

    sui->plwSystemKPIGraph1->setYGrid(SUI::GridStyleEnum::Normal);
    sui->plwSystemKPIGraph2->setYGrid(SUI::GridStyleEnum::Normal);
    sui->plwSystemKPIGraph3->setYGrid(SUI::GridStyleEnum::Normal);
    sui->plwSystemKPIGraph4->setYGrid(SUI::GridStyleEnum::Normal);
    sui->plwSystemKPIGraph5->setYGrid(SUI::GridStyleEnum::Normal);

    sui->plwSystemKPIGraph1->setXScale(0.0, NO_OF_PLOTITEM_VALUES);
    sui->plwSystemKPIGraph2->setXScale(0.0, NO_OF_PLOTITEM_VALUES);
    sui->plwSystemKPIGraph3->setXScale(0.0, NO_OF_PLOTITEM_VALUES);
    sui->plwSystemKPIGraph4->setXScale(0.0, NO_OF_PLOTITEM_VALUES);
    sui->plwSystemKPIGraph5->setXScale(0.0, NO_OF_PLOTITEM_VALUES);

    m_listSystemKPIs.clear();
    m_listSystemKPIs = m_presenter->getSystemKPIs();

    m_mapKPIHistogram.clear();
    m_mapKPIPlots.clear();
    m_mapKPIGraphValueLabel.clear();



    KPI* kpi = m_listSystemKPIs[0];
    if (kpi != NULL)
    {
        sui->lblSystemKPIGraph1KPIName->setText(kpi->getName());
        sui->lblSystemKPIGraph1KPIValue->setText("0");
        sui->lblSystemKPIGraph1KPIUnit->setText(kpi->getDisplayName());
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getName(), sui->lblSystemKPIGraph1KPIValue));
        m_mapKPIHistogram.insert(std::make_pair(kpi->getName(), histogram1));
        m_mapKPIPlots.insert(std::make_pair(kpi->getName(), sui->plwSystemKPIGraph1));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getName(), m_circularBuffer1)));
    }

    kpi = m_listSystemKPIs[1];
    if (kpi != NULL)
    {
        sui->lblSystemKPIGraph2KPIName->setText(kpi->getName());
        sui->lblSystemKPIGraph2KPIValue->setText("0");
        sui->lblSystemKPIGraph2KPIUnit->setText(kpi->getDisplayName());
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getName(), sui->lblSystemKPIGraph2KPIValue));
        m_mapKPIHistogram.insert(std::make_pair(kpi->getName(), histogram2));
        m_mapKPIPlots.insert(std::make_pair(kpi->getName(), sui->plwSystemKPIGraph2));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getName(), m_circularBuffer2)));
    }

    kpi = m_listSystemKPIs[2];
    if (kpi != NULL)
    {
        sui->lblSystemKPIGraph3KPIName->setText(kpi->getName());
        sui->lblSystemKPIGraph3KPIValue->setText("0");
        sui->lblSystemKPIGraph3KPIUnit->setText(kpi->getDisplayName());
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getName(), sui->lblSystemKPIGraph3KPIValue));
        m_mapKPIHistogram.insert(std::make_pair(kpi->getName(), histogram3));
        m_mapKPIPlots.insert(std::make_pair(kpi->getName(), sui->plwSystemKPIGraph3));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getName(), m_circularBuffer3)));
    }

    kpi = m_listSystemKPIs[3];
    if (kpi != NULL)
    {
        sui->lblSystemKPIGraph4KPIName->setText(kpi->getName());
        sui->lblSystemKPIGraph4KPIValue->setText("0");
        sui->lblSystemKPIGraph4KPIUnit->setText(kpi->getDisplayName());
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getName(), sui->lblSystemKPIGraph4KPIValue));
        m_mapKPIHistogram.insert(std::make_pair(kpi->getName(), histogram4));
        m_mapKPIPlots.insert(std::make_pair(kpi->getName(), sui->plwSystemKPIGraph4));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getName(), m_circularBuffer4)));
    }

    kpi = m_listSystemKPIs[4];
    if (kpi != NULL)
    {
        sui->lblSystemKPIGraph5KPIName->setText(kpi->getName());
        sui->lblSystemKPIGraph5KPIValue->setText("0");
        sui->lblSystemKPIGraph5KPIUnit->setText(kpi->getDisplayName());
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getName(), sui->lblSystemKPIGraph5KPIValue));
        m_mapKPIHistogram.insert(std::make_pair(kpi->getName(), histogram5));
        m_mapKPIPlots.insert(std::make_pair(kpi->getName(), sui->plwSystemKPIGraph5));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getName(), m_circularBuffer5)));
    }
}
void IGSxGUI::DashboardView::buildNormalKPITable()
{
     m_listKPIs.clear();
     m_listKPIs = m_presenter->getKPIs();
     size_t t_vec_size1 = m_listKPIs.size();
     size_t t_vec_size2 = m_listNormalKPINames.size();

        for (size_t i = 0; i < t_vec_size1; ++i)
        {
                KPI* kpi = m_listKPIs[i];
                if (kpi != NULL)
                {
                    m_listNormalKPINames[i]->setText(kpi->getName());
                    m_listNormalKPICategories[i]->setText(kpi->getValueSets()[0]->getName());
                    m_listNormalKPITimes[i]->setText(currentDateTime(STRING_TIME));
                    m_listNormalKPIValues[i]->setText(boost::lexical_cast<std::string>(kpi->getValueSets()[0]->getValue().back()));
                    m_listNormalKPIUnits[i]->setText(kpi->getDisplayName());
                }
        }

        // To fill the table with default values
        for (size_t i = t_vec_size1; i < t_vec_size2; ++i)
        {
            m_listNormalKPINames[i]->setText("KPI " + boost::lexical_cast<std::string>(i+1));
            m_listNormalKPICategories[i]->setText("Vessel");
            m_listNormalKPITimes[i]->setText("Time");
            m_listNormalKPIValues[i]->setText("");
            m_listNormalKPIUnits[i]->setText("");
        }
}
void IGSxGUI::DashboardView::buildSystemKPITable()
{
      m_listKPIs.clear();
      m_listKPIs = m_presenter->getSystemKPIs();

      size_t t_vec_size1 = m_listKPIs.size();
      size_t t_vec_size2 = m_listSystemKPINames.size();

        for (size_t i = 0; i < t_vec_size1; ++i)
        {
                KPI* kpi = m_listKPIs[i];
                if (kpi != NULL)
                {
                    m_listSystemKPINames[i]->setText(kpi->getName());
                    m_listSystemKPICategories[i]->setText(kpi->getValueSets()[0]->getName());
                    m_listSystemKPITimes[i]->setText(currentDateTime(STRING_TIME));
                    m_listSystemKPIValues[i]->setText(boost::lexical_cast<std::string>(kpi->getValueSets()[0]->getValue().back()));
                    m_listSystemKPIUnits[i]->setText(kpi->getDisplayName());
                }
        }
        for (size_t i = t_vec_size1; i < t_vec_size2 ; ++i)
        {
                m_listSystemKPINames[i]->setText("KPI " + boost::lexical_cast<std::string>(i+1));
                m_listSystemKPICategories[i]->setText("Vessel");
                m_listSystemKPITimes[i]->setText("");
                m_listSystemKPIValues[i]->setText("");
                m_listSystemKPIUnits[i]->setText("");
        }
}
void IGSxGUI::DashboardView::buildConsumableTable()
{
    m_listKPIs.clear();
    m_listKPIs = m_presenter->getConsumables();

    for (size_t i = 0; i < CONSUMABLES_COUNT; i++)
    {
        KPI* kpi = m_listKPIs[i];
        if (kpi != NULL)
        {
            m_listConsumableNames[i]->setText(kpi->getName());
            m_listConsumableTimes[i]->setText(currentDateTime(STRING_TIME));

            double t_kpiValue = kpi->getValueSets()[0]->getValue().back();
            double max = boost::lexical_cast<double>(kpi->getMax());
            double min = boost::lexical_cast<double>(kpi->getMin());
            double t_kpiValuePercentage = ((t_kpiValue - min) * 100)/(max - min);
            m_listConsumableValues[i]->setText(boost::lexical_cast<std::string>(t_kpiValue));
            m_listConsumableUnits[i]->setText(kpi->getDisplayName());
            m_listConsumableProgressbars[i]->setValue(t_kpiValuePercentage);
        }
    }
}
void IGSxGUI::DashboardView::restoreDashboard()
{
    int v_size = m_listSystemKPIs.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        KPI *kpi = m_listSystemKPIs[index];
        std::string temp_systemKPIName = kpi->getName();
        std::ostringstream ss;
        double value = m_mapKPICircBuffPlotItemValues[temp_systemKPIName].back();
        ss << boost::numeric_cast<int>(value);
        m_mapKPIGraphValueLabel[temp_systemKPIName]->setText(ss.str());
        boost::circular_buffer<double>::const_iterator end_it = m_mapKPICircBuffPlotItemValues[temp_systemKPIName].end();
        boost::circular_buffer<double>::const_iterator it;
        plotsamples[temp_systemKPIName].clear();

        m_mapKPIMinValue[temp_systemKPIName] = HISTOGRAM_BAR_START_VALUE;
        m_mapKPIMaxValue[temp_systemKPIName] = HISTOGRAM_BAR_END_VALUE;
        for (it = m_mapKPICircBuffPlotItemValues[temp_systemKPIName].begin(); it != end_it; ++it)
        {
            plotsamples[temp_systemKPIName].push_back(SUI::PlotIntervalSample(*it, m_mapKPIMinValue[temp_systemKPIName], m_mapKPIMaxValue[temp_systemKPIName]));
            m_mapKPIMinValue[temp_systemKPIName]  = m_mapKPIMinValue[temp_systemKPIName] + 1;
            m_mapKPIMaxValue[temp_systemKPIName]  = m_mapKPIMaxValue[temp_systemKPIName] + 1;
        }
        m_mapKPIHistogram[temp_systemKPIName]->setSamples(plotsamples[temp_systemKPIName]);
        m_mapKPIPlots[temp_systemKPIName]->replot();
    }
}

void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
    if (bIsFirstTimeDisplay == false)
    {
        restoreDashboard();
    }
}
void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();

        if (histogram1 != NULL)
        {
            histogram1->detach();
            delete histogram1;
            histogram1 = NULL;
        }
        if (histogram2 != NULL)
        {
            histogram2->detach();
            delete histogram2;
            histogram2 = NULL;
        }
        if (histogram3 != NULL)
        {
            histogram3->detach();
            delete histogram3;
            histogram3 = NULL;
        }
        if (histogram4 != NULL)
        {
            histogram4->detach();
            delete histogram4;
            histogram4 = NULL;
        }
        if (histogram5 != NULL)
        {
            histogram5->detach();
            delete histogram5;
            histogram5 = NULL;
        }
    }
}
void IGSxGUI::DashboardView::updateKPI(const std::string kpiName, const std::string p_displayName, const std::string p_factor, const std::string p_valueSetName, const vector<double> p_values)
{
    int v_size = m_listNormalKPINames.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        if (m_listNormalKPINames[index]->getText() == kpiName)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);
            double x = p_values.back() * boost::lexical_cast<double>(p_factor);
            ss << x;
            m_listNormalKPICategories[index]->setText(p_valueSetName);
            m_listNormalKPITimes[index]->setText(currentDateTime(STRING_TIME));
            m_listNormalKPIValues[index]->setText(ss.str());
            m_listNormalKPIUnits[index]->setText(p_displayName);
            break;
        }
    }
}
void IGSxGUI::DashboardView::updateSystemKPI(const std::string p_systemKPIName, const std::string p_displayName, const std::string p_factor, const std::string p_valueSetName, const vector<double> p_values)
{
    if (m_mapKPIHistogram.find(p_systemKPIName) != m_mapKPIHistogram.end())
    {
        m_mapKPIHistogram[p_systemKPIName]->clearSamples();
        double value = p_values.back() * boost::lexical_cast<double>(p_factor);
        std::ostringstream ss;
        ss << boost::numeric_cast<int>(value);
        m_mapKPIGraphValueLabel[p_systemKPIName]->setText(ss.str());
        m_mapKPICircBuffPlotItemValues[p_systemKPIName].push_back(value);

        boost::circular_buffer<double>::const_iterator end_it = m_mapKPICircBuffPlotItemValues[p_systemKPIName].end();
        boost::circular_buffer<double>::const_iterator it;
         plotsamples[p_systemKPIName].clear();

         m_mapKPIMinValue[p_systemKPIName] = HISTOGRAM_BAR_START_VALUE;
         m_mapKPIMaxValue[p_systemKPIName] = HISTOGRAM_BAR_END_VALUE;


        for (it = m_mapKPICircBuffPlotItemValues[p_systemKPIName].begin(); it != end_it; ++it)
        {
            plotsamples[p_systemKPIName].push_back(SUI::PlotIntervalSample(*it, m_mapKPIMinValue[p_systemKPIName], m_mapKPIMaxValue[p_systemKPIName]));
            m_mapKPIMinValue[p_systemKPIName]  = m_mapKPIMinValue[p_systemKPIName] + 1;
            m_mapKPIMaxValue[p_systemKPIName]  = m_mapKPIMaxValue[p_systemKPIName] + 1;
        }
        m_mapKPIHistogram[p_systemKPIName]->setSamples(plotsamples[p_systemKPIName]);
        m_mapKPIPlots[p_systemKPIName]->replot();
    }
    int v_size = m_listSystemKPINames.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        if ( m_listSystemKPINames[index]->getText() == p_systemKPIName)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);
            double x = p_values.back() * boost::lexical_cast<double>(p_factor);
            ss << x;

            m_listSystemKPICategories[index]->setText(p_valueSetName);
            m_listSystemKPITimes[index]->setText(currentDateTime(STRING_TIME));
            m_listSystemKPIValues[index]->setText(ss.str());
            m_listSystemKPIUnits[index]->setText(p_displayName);
            break;
        }
    }
}
void IGSxGUI::DashboardView::updateConsumable(const std::string p_consumableName, const std::string p_displayName, const std::string p_factor,  const vector<double> p_values, const std::string min, const std::string max)
{
    int v_size = m_listConsumableNames.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        if (m_listConsumableNames[index]->getText() == p_consumableName)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);
            double x = p_values.back() * boost::lexical_cast<double>(p_factor);
            ss << x;

            // Calculate Percentage Value
            double t_kpiValue = p_values.back();
            double t_kpiValuePercentage = ((t_kpiValue - boost::lexical_cast<double>(min)) * 100)/(boost::lexical_cast<double>(max) - boost::lexical_cast<double>(min));

            m_listConsumableTimes[index]->setText(currentDateTime(STRING_TIME));
            m_listConsumableValues[index]->setText(ss.str());
            m_listConsumableUnits[index]->setText(p_displayName);
            m_listConsumableProgressbars[index]->setValue(boost::numeric_cast<int>(t_kpiValuePercentage));
            break;
        }
    }
}
void IGSxGUI::DashboardView::loadContainers()
{
    m_listNormalKPIUCTs.clear();
    m_listNormalKPINames.clear();
    m_listNormalKPICategories.clear();
    m_listNormalKPITimes.clear();
    m_listNormalKPIValues.clear();
    m_listNormalKPIUnits.clear();
    m_listNormalKPIGroupBoxes.clear();

    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI1);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI2);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI3);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI4);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI5);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI6);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI7);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI8);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI9);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI10);

    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI1);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI2);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI3);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI4);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI5);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI6);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI7);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI8);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI9);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI10);

    m_listNormalKPINames.push_back(sui->lblNormalKPI1Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI2Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI3Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI4Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI5Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI6Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI7Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI8Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI9Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI10Name);

    m_listNormalKPICategories.push_back(sui->lblNormalKPI1Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI2Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI3Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI4Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI5Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI6Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI7Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI8Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI9Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI10Category);

    m_listNormalKPITimes.push_back(sui->lblNormalKPI1Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI2Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI3Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI4Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI5Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI6Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI7Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI8Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI9Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI10Time);

    m_listNormalKPIValues.push_back(sui->lblNormalKPI1Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI2Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI3Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI4Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI5Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI6Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI7Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI8Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI9Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI10Value);

    m_listNormalKPIUnits.push_back(sui->lblNormalKPI1Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI2Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI3Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI4Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI5Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI6Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI7Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI8Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI9Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI10Unit);

    m_listSystemKPIUCTs.clear();
    m_listSystemKPINames.clear();
    m_listSystemKPICategories.clear();
    m_listSystemKPITimes.clear();
    m_listSystemKPIValues.clear();
    m_listSystemKPIUnits.clear();
    m_listSystemKPIGroupBoxes.clear();

    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI1);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI2);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI3);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI4);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI5);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI6);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI7);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI8);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI9);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI10);

    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI1);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI2);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI3);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI4);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI5);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI6);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI7);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI8);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI9);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI10);

    m_listSystemKPINames.push_back(sui->lblSystemKPI1Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI2Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI3Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI4Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI5Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI6Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI7Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI8Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI9Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI10Name);

    m_listSystemKPICategories.push_back(sui->lblSystemKPI1Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI2Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI3Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI4Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI5Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI6Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI7Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI8Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI9Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI10Category);

    m_listSystemKPITimes.push_back(sui->lblSystemKPI1Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI2Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI3Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI4Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI5Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI6Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI7Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI8Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI9Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI10Time);

    m_listSystemKPIValues.push_back(sui->lblSystemKPI1Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI2Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI3Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI4Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI5Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI6Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI7Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI8Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI9Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI10Value);

    m_listSystemKPIUnits.push_back(sui->lblSystemKPI1Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI2Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI3Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI4Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI5Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI6Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI7Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI8Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI9Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI10Unit);

    m_listConsumableUCTs.clear();
    m_listConsumableGroupBoxes.clear();
    m_listConsumableNames.clear();
    m_listConsumableCategories.clear();
    m_listConsumableTimes.clear();
    m_listConsumableValues.clear();
    m_listConsumableUnits.clear();
    m_listConsumableProgressbars.clear();

    m_listConsumableUCTs.push_back(sui->uctConsumable1);
    m_listConsumableUCTs.push_back(sui->uctConsumable2);
    m_listConsumableUCTs.push_back(sui->uctConsumable3);
    m_listConsumableUCTs.push_back(sui->uctConsumable4);
    m_listConsumableUCTs.push_back(sui->uctConsumable5);
    m_listConsumableUCTs.push_back(sui->uctConsumable6);
    m_listConsumableUCTs.push_back(sui->uctConsumable7);
    m_listConsumableUCTs.push_back(sui->uctConsumable8);
    m_listConsumableUCTs.push_back(sui->uctConsumable9);

    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable1);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable2);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable3);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable4);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable5);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable6);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable7);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable8);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable9);

    m_listConsumableNames.push_back(sui->lblConsumable1Name);
    m_listConsumableNames.push_back(sui->lblConsumable2Name);
    m_listConsumableNames.push_back(sui->lblConsumable3Name);
    m_listConsumableNames.push_back(sui->lblConsumable4Name);
    m_listConsumableNames.push_back(sui->lblConsumable5Name);
    m_listConsumableNames.push_back(sui->lblConsumable6Name);
    m_listConsumableNames.push_back(sui->lblConsumable7Name);
    m_listConsumableNames.push_back(sui->lblConsumable8Name);
    m_listConsumableNames.push_back(sui->lblConsumable9Name);

    m_listConsumableTimes.push_back(sui->lblConsumable1Time);
    m_listConsumableTimes.push_back(sui->lblConsumable2Time);
    m_listConsumableTimes.push_back(sui->lblConsumable3Time);
    m_listConsumableTimes.push_back(sui->lblConsumable4Time);
    m_listConsumableTimes.push_back(sui->lblConsumable5Time);
    m_listConsumableTimes.push_back(sui->lblConsumable6Time);
    m_listConsumableTimes.push_back(sui->lblConsumable7Time);
    m_listConsumableTimes.push_back(sui->lblConsumable8Time);
    m_listConsumableTimes.push_back(sui->lblConsumable9Time);

    m_listConsumableValues.push_back(sui->lblConsumable1Value);
    m_listConsumableValues.push_back(sui->lblConsumable2Value);
    m_listConsumableValues.push_back(sui->lblConsumable3Value);
    m_listConsumableValues.push_back(sui->lblConsumable4Value);
    m_listConsumableValues.push_back(sui->lblConsumable5Value);
    m_listConsumableValues.push_back(sui->lblConsumable6Value);
    m_listConsumableValues.push_back(sui->lblConsumable7Value);
    m_listConsumableValues.push_back(sui->lblConsumable8Value);
    m_listConsumableValues.push_back(sui->lblConsumable9Value);

    m_listConsumableUnits.push_back(sui->lblConsumable1Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable2Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable3Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable4Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable5Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable6Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable7Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable8Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable9Unit);

    m_listConsumableProgressbars.push_back(sui->pgbConsumable1);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable2);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable3);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable4);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable5);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable6);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable7);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable8);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable9);
}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctNormalKPI1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI1HoverOn, this);
    sui->uctNormalKPI1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI1HoverOff, this);

    sui->uctNormalKPI2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI2HoverOn, this);
    sui->uctNormalKPI2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI2HoverOff, this);

    sui->uctNormalKPI3->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI3HoverOn, this);
    sui->uctNormalKPI3->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI3HoverOff, this);

    sui->uctNormalKPI4->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI4HoverOn, this);
    sui->uctNormalKPI4->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI4HoverOff, this);

    sui->uctNormalKPI5->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI5HoverOn, this);
    sui->uctNormalKPI5->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI5HoverOff, this);

    sui->uctNormalKPI6->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI6HoverOn, this);
    sui->uctNormalKPI6->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI6HoverOff, this);

    sui->uctNormalKPI7->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI7HoverOn, this);
    sui->uctNormalKPI7->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI7HoverOff, this);

    sui->uctNormalKPI8->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI8HoverOn, this);
    sui->uctNormalKPI8->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI8HoverOff, this);

    sui->uctNormalKPI9->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI9HoverOn, this);
    sui->uctNormalKPI9->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI9HoverOff, this);

    sui->uctNormalKPI10->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI10HoverOn, this);
    sui->uctNormalKPI10->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI10HoverOff, this);

    sui->uctSystemKPI1->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI1HoverOn, this);
    sui->uctSystemKPI1->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI1HoverOff, this);

    sui->uctSystemKPI2->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI2HoverOn, this);
    sui->uctSystemKPI2->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI2HoverOff, this);

    sui->uctSystemKPI3->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI3HoverOn, this);
    sui->uctSystemKPI3->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI3HoverOff, this);

    sui->uctSystemKPI4->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI4HoverOn, this);
    sui->uctSystemKPI4->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI4HoverOff, this);

    sui->uctSystemKPI5->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI5HoverOn, this);
    sui->uctSystemKPI5->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI5HoverOff, this);

    sui->uctSystemKPI6->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI6HoverOn, this);
    sui->uctSystemKPI6->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI6HoverOff, this);

    sui->uctSystemKPI7->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI7HoverOn, this);
    sui->uctSystemKPI7->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI7HoverOff, this);

    sui->uctSystemKPI8->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI8HoverOn, this);
    sui->uctSystemKPI8->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI8HoverOff, this);

    sui->uctSystemKPI9->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI9HoverOn, this);
    sui->uctSystemKPI9->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI9HoverOff, this);

    sui->uctSystemKPI10->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI10HoverOn, this);
    sui->uctSystemKPI10->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI10HoverOff, this);

    sui->uctConsumable1->hoverEntered = boost::bind(&DashboardView::onConsumable1HoverOn, this);
    sui->uctConsumable1->hoverLeft = boost::bind(&DashboardView::onConsumable1HoverOff, this);

    sui->uctConsumable2->hoverEntered = boost::bind(&DashboardView::onConsumable2HoverOn, this);
    sui->uctConsumable2->hoverLeft = boost::bind(&DashboardView::onConsumable2HoverOff, this);

    sui->uctConsumable3->hoverEntered = boost::bind(&DashboardView::onConsumable3HoverOn, this);
    sui->uctConsumable3->hoverLeft = boost::bind(&DashboardView::onConsumable3HoverOff, this);

    sui->uctConsumable4->hoverEntered = boost::bind(&DashboardView::onConsumable4HoverOn, this);
    sui->uctConsumable4->hoverLeft = boost::bind(&DashboardView::onConsumable4HoverOff, this);

    sui->uctConsumable5->hoverEntered = boost::bind(&DashboardView::onConsumable5HoverOn, this);
    sui->uctConsumable5->hoverLeft = boost::bind(&DashboardView::onConsumable5HoverOff, this);

    sui->uctConsumable6->hoverEntered = boost::bind(&DashboardView::onConsumable6HoverOn, this);
    sui->uctConsumable6->hoverLeft = boost::bind(&DashboardView::onConsumable6HoverOff, this);

    sui->uctConsumable7->hoverEntered = boost::bind(&DashboardView::onConsumable7HoverOn, this);
    sui->uctConsumable7->hoverLeft = boost::bind(&DashboardView::onConsumable7HoverOff, this);

    sui->uctConsumable8->hoverEntered = boost::bind(&DashboardView::onConsumable8HoverOn, this);
    sui->uctConsumable8->hoverLeft = boost::bind(&DashboardView::onConsumable8HoverOff, this);

    sui->uctConsumable9->hoverEntered = boost::bind(&DashboardView::onConsumable9HoverOn, this);
    sui->uctConsumable9->hoverLeft = boost::bind(&DashboardView::onConsumable9HoverOff, this);
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOnStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctnormalkpihoveron");
    p_name->setStyleSheetClass("uctnormalkpihoveron");
    p_category->setStyleSheetClass("uctnormalkpihoveron");
    p_time->setStyleSheetClass("uctnormalkpihoveron");
    p_value->setStyleSheetClass("uctnormalkpihoveron");
    p_unit->setStyleSheetClass("uctnormalkpihoveron");
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctnormalkpihoveroff");
    p_name->setStyleSheetClass("uctnormalkpiplaintext");
    p_category->setStyleSheetClass("uctnormalkpicategorygraytext");
    p_time->setStyleSheetClass("uctnormalkpicategorygraytext");
    p_value->setStyleSheetClass("uctnormalkpiplaintext");
    p_unit->setStyleSheetClass("uctnormalkpicategorygraytext");
}
void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI1, sui->lblNormalKPI1Name, sui->lblNormalKPI1Category, sui->lblNormalKPI1Time, sui->lblNormalKPI1Value, sui->lblNormalKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI1, sui->lblNormalKPI1Name, sui->lblNormalKPI1Category, sui->lblNormalKPI1Time, sui->lblNormalKPI1Value, sui->lblNormalKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI2, sui->lblNormalKPI2Name, sui->lblNormalKPI2Category, sui->lblNormalKPI2Time, sui->lblNormalKPI2Value, sui->lblNormalKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI2, sui->lblNormalKPI2Name, sui->lblNormalKPI2Category, sui->lblNormalKPI2Time, sui->lblNormalKPI2Value, sui->lblNormalKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI3, sui->lblNormalKPI3Name, sui->lblNormalKPI3Category, sui->lblNormalKPI3Time, sui->lblNormalKPI3Value, sui->lblNormalKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI3, sui->lblNormalKPI3Name, sui->lblNormalKPI3Category, sui->lblNormalKPI3Time, sui->lblNormalKPI3Value, sui->lblNormalKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI4, sui->lblNormalKPI4Name, sui->lblNormalKPI4Category, sui->lblNormalKPI4Time, sui->lblNormalKPI4Value, sui->lblNormalKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI4, sui->lblNormalKPI4Name, sui->lblNormalKPI4Category, sui->lblNormalKPI4Time, sui->lblNormalKPI4Value, sui->lblNormalKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI5, sui->lblNormalKPI5Name, sui->lblNormalKPI5Category, sui->lblNormalKPI5Time, sui->lblNormalKPI5Value, sui->lblNormalKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI5, sui->lblNormalKPI5Name, sui->lblNormalKPI5Category, sui->lblNormalKPI5Time, sui->lblNormalKPI5Value, sui->lblNormalKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI6, sui->lblNormalKPI6Name, sui->lblNormalKPI6Category, sui->lblNormalKPI6Time, sui->lblNormalKPI6Value, sui->lblNormalKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI6, sui->lblNormalKPI6Name, sui->lblNormalKPI6Category, sui->lblNormalKPI6Time, sui->lblNormalKPI6Value, sui->lblNormalKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI7, sui->lblNormalKPI7Name, sui->lblNormalKPI7Category, sui->lblNormalKPI7Time, sui->lblNormalKPI7Value, sui->lblNormalKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI7, sui->lblNormalKPI7Name, sui->lblNormalKPI7Category, sui->lblNormalKPI7Time, sui->lblNormalKPI7Value, sui->lblNormalKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI8, sui->lblNormalKPI8Name, sui->lblNormalKPI8Category, sui->lblNormalKPI8Time, sui->lblNormalKPI8Value, sui->lblNormalKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI8, sui->lblNormalKPI8Name, sui->lblNormalKPI8Category, sui->lblNormalKPI8Time, sui->lblNormalKPI8Value, sui->lblNormalKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI9, sui->lblNormalKPI9Name, sui->lblNormalKPI9Category, sui->lblNormalKPI9Time, sui->lblNormalKPI9Value, sui->lblNormalKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI9, sui->lblNormalKPI9Name, sui->lblNormalKPI9Category, sui->lblNormalKPI9Time, sui->lblNormalKPI9Value, sui->lblNormalKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI10, sui->lblNormalKPI10Name, sui->lblNormalKPI10Category, sui->lblNormalKPI10Time, sui->lblNormalKPI10Value, sui->lblNormalKPI10Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI10, sui->lblNormalKPI10Name, sui->lblNormalKPI10Category, sui->lblNormalKPI10Time, sui->lblNormalKPI10Value, sui->lblNormalKPI10Unit);
}
void IGSxGUI::DashboardView::setSystemKPIUCTHoverOnStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctsystemkpihoveron");
    p_name->setStyleSheetClass("uctsystemkpihoveron");
    p_category->setStyleSheetClass("uctsystemkpihoveron");
    p_time->setStyleSheetClass("uctsystemkpihoveron");
    p_value->setStyleSheetClass("uctsystemkpihoveron");
    p_unit->setStyleSheetClass("uctsystemkpihoveron");
}
void IGSxGUI::DashboardView::setSystemKPIUCTHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctsystemkpihoveroff");
    p_name->setStyleSheetClass("uctsystemkpiplaintext");
    p_category->setStyleSheetClass("uctsystemkpicategorygraytext");
    p_time->setStyleSheetClass("uctsystemkpicategorygraytext");
    p_value->setStyleSheetClass("uctsystemkpiplaintext");
    p_unit->setStyleSheetClass("uctsystemkpicategorygraytext");
}
void IGSxGUI::DashboardView::onUCTSystemKPI1HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI1, sui->lblSystemKPI1Name, sui->lblSystemKPI1Category, sui->lblSystemKPI1Time, sui->lblSystemKPI1Value, sui->lblSystemKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI1HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI1, sui->lblSystemKPI1Name, sui->lblSystemKPI1Category, sui->lblSystemKPI1Time, sui->lblSystemKPI1Value, sui->lblSystemKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI2HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI2, sui->lblSystemKPI2Name, sui->lblSystemKPI2Category, sui->lblSystemKPI2Time, sui->lblSystemKPI2Value, sui->lblSystemKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI2HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI2, sui->lblSystemKPI2Name, sui->lblSystemKPI2Category, sui->lblSystemKPI2Time, sui->lblSystemKPI2Value, sui->lblSystemKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI3HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI3, sui->lblSystemKPI3Name, sui->lblSystemKPI3Category, sui->lblSystemKPI3Time, sui->lblSystemKPI3Value, sui->lblSystemKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI3HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI3, sui->lblSystemKPI3Name, sui->lblSystemKPI3Category, sui->lblSystemKPI3Time, sui->lblSystemKPI3Value, sui->lblSystemKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI4HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI4, sui->lblSystemKPI4Name, sui->lblSystemKPI4Category, sui->lblSystemKPI4Time, sui->lblSystemKPI4Value, sui->lblSystemKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI4HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI4, sui->lblSystemKPI4Name, sui->lblSystemKPI4Category, sui->lblSystemKPI4Time, sui->lblSystemKPI4Value, sui->lblSystemKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI5HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI5, sui->lblSystemKPI5Name, sui->lblSystemKPI5Category, sui->lblSystemKPI5Time, sui->lblSystemKPI5Value, sui->lblSystemKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI5HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI5, sui->lblSystemKPI5Name, sui->lblSystemKPI5Category, sui->lblSystemKPI5Time, sui->lblSystemKPI5Value, sui->lblSystemKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI6HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI6, sui->lblSystemKPI6Name, sui->lblSystemKPI6Category, sui->lblSystemKPI6Time, sui->lblSystemKPI6Value, sui->lblSystemKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI6HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI6, sui->lblSystemKPI6Name, sui->lblSystemKPI6Category, sui->lblSystemKPI6Time, sui->lblSystemKPI6Value, sui->lblSystemKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI7HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI7, sui->lblSystemKPI7Name, sui->lblSystemKPI7Category, sui->lblSystemKPI7Time, sui->lblSystemKPI7Value, sui->lblSystemKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI7HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI7, sui->lblSystemKPI7Name, sui->lblSystemKPI7Category, sui->lblSystemKPI7Time, sui->lblSystemKPI7Value, sui->lblSystemKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI8HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI8, sui->lblSystemKPI8Name, sui->lblSystemKPI8Category, sui->lblSystemKPI8Time, sui->lblSystemKPI8Value, sui->lblSystemKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI8HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI8, sui->lblSystemKPI8Name, sui->lblSystemKPI8Category, sui->lblSystemKPI8Time, sui->lblSystemKPI8Value, sui->lblSystemKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI9HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI9, sui->lblSystemKPI9Name, sui->lblSystemKPI9Category, sui->lblSystemKPI9Time, sui->lblSystemKPI9Value, sui->lblSystemKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI9HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI9, sui->lblSystemKPI9Name, sui->lblSystemKPI9Category, sui->lblSystemKPI9Time, sui->lblSystemKPI9Value, sui->lblSystemKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI10HoverOn()
{
    setSystemKPIUCTHoverOnStyle(sui->gbxSystemKPI10, sui->lblSystemKPI10Name, sui->lblSystemKPI10Category, sui->lblSystemKPI10Time, sui->lblSystemKPI10Value, sui->lblSystemKPI10Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI10HoverOff()
{
    setSystemKPIUCTHoverOffStyle(sui->gbxSystemKPI10, sui->lblSystemKPI10Name, sui->lblSystemKPI10Category, sui->lblSystemKPI10Time, sui->lblSystemKPI10Value, sui->lblSystemKPI10Unit);
}
void IGSxGUI::DashboardView::setConsumableHoverOnStyle(SUI::GroupBox* p_GroupBox,  SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctconsumablehoveron");
    p_name->setStyleSheetClass("uctconsumablehoveron");
    p_time->setStyleSheetClass("uctconsumablehoveron");
    p_value->setStyleSheetClass("uctconsumablehoveron");
    p_unit->setStyleSheetClass("uctconsumablehoveron");
}

void IGSxGUI::DashboardView::setConsumableHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass("uctconsumablehoveroff");
    p_name->setStyleSheetClass("uctconsumableplaintext");
    p_time->setStyleSheetClass("uctconsumablegraytext");
    p_value->setStyleSheetClass("uctconsumableplaintext");
    p_unit->setStyleSheetClass("uctconsumablegraytext");
}
void IGSxGUI::DashboardView::onConsumable1HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable1HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::init()
{
    buildHistogramGraphs();
    buildNormalKPITable();
    buildSystemKPITable();
    buildConsumableTable();
}
