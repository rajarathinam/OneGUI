/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysis.cpp
| Author       : Venugopal S
| Description  : Implementation of Analysis plugin
|
| ! \file        IGSxGUIxAnalysis.cpp
| ! \brief       Implementation of Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxAnalysisView.hpp"
#include "IGSxGUIxEventViewerView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Analysis::Analysis():
    m_adtManager(new ADTManager())
{
    if (m_adtManager != NULL)
    {
        m_adtManager->initialize();
    }
    m_adtView = new IGSxGUI::ADTView(m_adtManager);
    m_analysisView = new IGSxGUI::AnalysisView();
    m_eventviewer = new  IGSxGUI::EventViewerView();
}

IGSxGUI::Analysis::~Analysis()
{
    if (m_eventviewer != NULL)
    {
        delete m_eventviewer;
        m_eventviewer = NULL;
    }
    if (m_analysisView != NULL)
    {
        delete m_analysisView;
        m_analysisView = NULL;
    }
    if (m_adtManager != NULL)
    {
        delete m_adtManager;
        m_adtManager = NULL;
    }
    if (m_adtView != NULL)
    {
        delete m_adtView;
        m_adtView = NULL;
    }
}

void IGSxGUI::Analysis::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_adtView != NULL)
    {
        m_adtView->setActive(false);
    }
    if (m_analysisView != NULL)
    {
        m_analysisView->setActive(true);
        m_analysisView->show(MainScreenContainer, bIsFirstTimeDisplay);
    }
}
void IGSxGUI::Analysis::showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_analysisView != NULL)
    {
        m_analysisView->setActive(false);
    }
    if (m_adtView != NULL)
    {
        m_adtView->setActive(true);
        m_adtView->show(MainScreenContainer, bIsFirstTimeDisplay);
    }
}
void IGSxGUI::Analysis::setActive(bool bActive)
{
    if (bActive)
    {
        if (m_adtView != NULL)
        {
            m_adtView->setActive(bActive);
        }
        if (m_analysisView != NULL)
        {
            m_analysisView->setActive(false);
        }
        if (m_eventviewer != NULL)
        {
           m_eventviewer->setActive(false);
        }
       // It is a specific case, as per the current design,m_analysisView->setActive(false);
       // false - Analysis button click displays ADT Page by default.
    } else {
        if (m_analysisView != NULL)
        {
            m_analysisView->setActive(bActive);
        }
        if (m_adtView != NULL)
        {
            m_adtView->setActive(bActive);
        }
        if (m_eventviewer != NULL)
        {
            m_eventviewer->setActive(bActive);
        }
    }
}

void IGSxGUI::Analysis::showEventViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_analysisView != NULL)
    {
        m_analysisView->setActive(false);
    }
    if (m_adtView != NULL)
    {
        m_adtView->setActive(false);
    }
    if (m_eventviewer != NULL)
    {
        m_eventviewer->show(MainScreenContainer, bIsFirstTimeDisplay);
    }
}
