/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsView.cpp
| Author       : Venugopal S
| Description  : Implementation of Analysis view
|
| ! \file        IGSxGUIxAnalysisView.cpp
| ! \brief       Implementation of Analysis view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <string>
#include "IGSxGUIxAnalysisView.hpp"
#include "IGSxGUIxMoc_AnalysisView.hpp"
#include "IGSxCOMMON.hpp"
#include <SUILabel.h>
#include <SUIButton.h>
#include <SUITableWidget.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AnalysisView::LOAD_FILE_ADVANCED_DIAGNOSTICS = IGS::Resource::path("IGSxGUIxAnalysisView.xml");
const std::string IGSxGUI::AnalysisView::STR_STOPPED = "STOPPED : ";
const std::string IGSxGUI::AnalysisView::STR_STARTED = "Started : ";
const std::string IGSxGUI::AnalysisView::STR_ADT_LIST = "ADT List";
const std::string IGSxGUI::AnalysisView::STR_INCORRECT_SELECTION = "Selection not correct";

IGSxGUI::AnalysisView::AnalysisView() :
    sui(new SUI::AnalysisView)
{
    m_presenter = new AnalysisPresenter(this);
}
IGSxGUI::AnalysisView::~AnalysisView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::AnalysisView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(LOAD_FILE_ADVANCED_DIAGNOSTICS.c_str(), MainScreenContainer);
    }
}

void IGSxGUI::AnalysisView::setActive(bool bActive)
{
    m_bAnalysisViewActive = bActive;
}
