/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDManagerTest.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD Manager test
|
| ! \file        IGSxGUIxCPDManagerTest.cpp
| ! \brief       Implementation of CPD Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxCPDManagerTest.hpp"
#include "IGSxGUIxCPDManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(CPDManagerTest, Test1)
{
  IGSxGUI::CPDManager cpdMgr;
  cpdMgr.initialize();

  std::vector<IGSxGUI::CPD*> cpds = cpdMgr.retrieveAll();
  EXPECT_EQ(cpds.size(), 51);

  IGSxGUI::CPD* cpd = new IGSxGUI::CPD(IGSxCPD::MetaDescription("TestName", "TestType", "TestDescription", "TestDescriptionFile", "TestSubSystem"));

  if (cpd != NULL)
  {
    cpdMgr.add(cpd);
  }

  cpds = cpdMgr.retrieveAll();
  EXPECT_EQ(cpds.size(), 52);

  IGSxGUI::CPD* requiredCpd = cpdMgr.getCPD("TestName");

  if (requiredCpd != NULL)
  {
    EXPECT_EQ(requiredCpd, cpd);
  }

  cpdMgr.remove(cpd);

  cpds = cpdMgr.retrieveAll();
  EXPECT_EQ(cpds.size(), 51);

  cpds[0]->start();
  IGSxGUI::CPD* runningCPD = cpdMgr.retrieveRunningCPD();

  if (runningCPD != NULL)
  {
    EXPECT_EQ(cpds[0], runningCPD);
  }
}


