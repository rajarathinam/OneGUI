/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIMainView.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface file for Main application view
|
| ! \file        IGSxGUIxIMainView.hpp
| ! \brief       Interface file for Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIMAINVIEW_HPP
#define IGSXGUIXIMAINVIEW_HPP
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class IMainView
{
 public:
    IMainView() {}
    virtual ~IMainView() {}
    virtual void show() = 0;
    virtual void onInitializeEnd() = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIMAINVIEW_HPP
