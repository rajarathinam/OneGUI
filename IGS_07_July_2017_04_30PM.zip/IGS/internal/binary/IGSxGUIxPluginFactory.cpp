/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPluginFactory.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Plugin Factory
|
| ! \file        IGSxGUIxPluginFactory.cpp
| ! \brief       Implementation of Plugin Factory
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxDashboard.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::PluginFactory::PluginFactory():
    m_systemPlugin(NULL),
    m_analysisPlugin(NULL),
    m_dashboardPlugin(NULL)
{
}

IGSxGUI::PluginFactory::~PluginFactory()
{
    if (m_systemPlugin != NULL)
    {
        delete m_systemPlugin;
        m_systemPlugin = NULL;
    }
    if (m_analysisPlugin != NULL)
    {
        delete m_analysisPlugin;
        m_analysisPlugin = NULL;
    }
    if (m_dashboardPlugin != NULL)
    {
        delete m_dashboardPlugin;
        m_dashboardPlugin = NULL;
    }
}

void IGSxGUI::PluginFactory::initialize()
{
    sleep(3);
    getDashboardPlugin()->initialize();
    getSystemPlugin();
    getAnalysisPlugin();
}

IGSxGUI::ISystem* IGSxGUI::PluginFactory::getSystemPlugin()
{
    if (m_systemPlugin == NULL)
    {
        m_systemPlugin = new IGSxGUI::System();
    }
    return m_systemPlugin;
}

IGSxGUI::IAnalysis* IGSxGUI::PluginFactory::getAnalysisPlugin()
{
    if (m_analysisPlugin == NULL)
    {
        m_analysisPlugin = new IGSxGUI::Analysis();
    }
    return m_analysisPlugin;
}

IGSxGUI::IDashboard* IGSxGUI::PluginFactory::getDashboardPlugin()
{
    if (m_dashboardPlugin == NULL)
    {
        m_dashboardPlugin = new IGSxGUI::Dashboard();
    }
    return m_dashboardPlugin;
}

