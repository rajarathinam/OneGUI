/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <sstream>
#include <iomanip>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUITableWidget.h>
#include <SUIPlotWidget.h>
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIPlotAxisEnum.h>
#include <SUIUserControl.h>
#include <SUILabel.h>
#include <SUIGroupBox.h>



/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE1 = "Collector Reflection";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE2 = "Droplet Generator";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE3 = "Tin catch remanining";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE4 = "Tin vanes level";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE5 = "Vanes Temperature";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE6 = "Vessel Pressure";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE7 = "Vessel Delta Pressure";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE8 = "Disc Space";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE9 = "Network Load";

const std::string IGSxGUI::DashboardView::STRING_TIME = "Time";
const std::string IGSxGUI::DashboardView::STRING_DATE = "Date";

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView)
{
    m_presenter = new DashboardPresenter(this,pKpiManager);
}

IGSxGUI::DashboardView::~DashboardView()
{    
    delete m_presenter;
    delete sui;
}
const std::string IGSxGUI::DashboardView::currentDateTime(const std::string& dateTime)
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), "%02l:%02M", &tstruct);
    } else {
        strftime(buf, sizeof(buf), "%d/%m/%Y", &tstruct);
    }
    return buf;
}
void IGSxGUI::DashboardView::constructGraphs()
{
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("MyHistogram");
    histogram->attach(sui->plwgraph);
    mapPlotHistogram.insert(std::pair<std::string, SUI::PlotHistogramItem*>("MyHistogram", histogram));
    histogram->setBrushColor(SUI::ColorEnum::Blue);

     //Add samples
     SUI::PlotIntervalSample sample1(10,2,3);
     SUI::PlotIntervalSample sample2(20,4,5);
     SUI::PlotIntervalSample sample3(5,6,7);
     SUI::PlotIntervalSample sample4(11,8,9);
     SUI::PlotIntervalSample sample5(18,10,11);
     SUI::PlotIntervalSample sample6(100,12,13);
     histogram->setSample(sample1);
     histogram->setSample(sample2);
     histogram->setSample(sample3);
     histogram->setSample(sample4);
     histogram->setSample(sample5);
     histogram->setSample(sample6);

    sui->plwgraph->replot();


}
void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
  }

void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else
    {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::DashboardView::updateKPI(std::string kpiName, std::string p_displayName, std::string p_factor, std::string p_valueSetName, vector<double> p_values)
{

    int v_size = m_listNormalKPINames.size();
    for(int index = 0 ; index < v_size;++index)
    {
        if(m_listNormalKPINames[index]->getText() == kpiName)
        {

            m_listNormalKPICategories[index]->setText(p_valueSetName);
            m_listNormalKPITimes[index]->setText(currentDateTime(STRING_TIME));
            /*
             std::ostringstream ss;
             ss << std::fixed << std::setprecision(2);
             double x = p_values[0] * p_factor;
             ss << x;
             */
            m_listNormalKPIValues[index]->setText(boost::lexical_cast<string>(p_values[0])/*ss.str()*/);
            m_listNormalKPIUnits[index]->setText(p_displayName);
            break;
        }
    }




}

void IGSxGUI::DashboardView::updateSystemKPI(std::string p_systemKPIName, std::string p_displayName, std::string p_factor, std::string p_valueSetName, vector<double> p_values)
{

    int v_size = m_listSystemKPINames.size();
    for(int index = 0 ; index < v_size;++index)
    {
        if(m_listSystemKPINames[index]->getText() == p_systemKPIName)
        {

            m_listSystemKPICategories[index]->setText(p_valueSetName);
            m_listSystemKPITimes[index]->setText(currentDateTime(STRING_TIME));
            /*
             std::ostringstream ss;
             ss << std::fixed << std::setprecision(2);
             double x = p_values[0] * p_factor;
             ss << x;
             */
            m_listSystemKPIValues[index]->setText(boost::lexical_cast<string>(p_values[0])/*ss.str()*/);
            m_listSystemKPIUnits[index]->setText(p_displayName);
            break;
        }
    }
}

void IGSxGUI::DashboardView::updateConsumable(std::string p_consumableName, std::string p_displayName, std::string p_factor, std::string p_valueSetName, vector<double> p_values)
{
    int v_size = m_listConsumableNames.size();
    for(int index = 0 ; index < v_size;++index)
    {
        if(m_listConsumableNames[index]->getText() == p_consumableName)
        {


            m_listConsumableTimes[index]->setText(currentDateTime(STRING_TIME));
            /*
             std::ostringstream ss;
             ss << std::fixed << std::setprecision(2);
             double x = p_values[0] * p_factor;
             ss << x;
             */
            m_listConsumableValues[index]->setText(boost::lexical_cast<string>(p_values[0])/*ss.str()*/);
            m_listConsumableUnits[index]->setText(p_displayName);
            break;
        }
    }
}
void IGSxGUI::DashboardView::loadContainers()
{
    m_listNormalKPIUCTs.clear();
    m_listNormalKPINames.clear();
    m_listNormalKPICategories.clear();
    m_listNormalKPITimes.clear();
    m_listNormalKPIValues.clear();
    m_listNormalKPIUnits.clear();

    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI1);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI2);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI3);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI4);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI5);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI6);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI7);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI8);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI9);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI10);

    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI1);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI2);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI3);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI4);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI5);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI6);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI7);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI8);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI9);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI10);


    m_listNormalKPINames.push_back(sui->lblNormalKPI1Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI2Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI3Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI4Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI5Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI6Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI7Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI8Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI9Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI10Name);

    m_listNormalKPICategories.push_back(sui->lblNormalKPI1Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI2Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI3Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI4Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI5Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI6Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI7Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI8Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI9Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI10Category);

    m_listNormalKPITimes.push_back(sui->lblNormalKPI1Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI2Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI3Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI4Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI5Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI6Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI7Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI8Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI9Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI10Time);

    m_listNormalKPIValues.push_back(sui->lblNormalKPI1Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI2Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI3Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI4Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI5Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI6Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI7Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI8Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI9Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI10Value);

    m_listNormalKPIUnits.push_back(sui->lblNormalKPI1Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI2Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI3Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI4Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI5Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI6Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI7Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI8Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI9Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI10Unit);


    m_listSystemKPIUCTs.clear();
    m_listSystemKPINames.clear();
    m_listSystemKPICategories.clear();
    m_listSystemKPITimes.clear();
    m_listSystemKPIValues.clear();
    m_listSystemKPIUnits.clear();

    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI1);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI2);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI3);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI4);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI5);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI6);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI7);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI8);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI9);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI10);

    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI1);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI2);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI3);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI4);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI5);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI6);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI7);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI8);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI9);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI10);


    m_listSystemKPINames.push_back(sui->lblSystemKPI1Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI2Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI3Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI4Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI5Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI6Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI7Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI8Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI9Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI10Name);

    m_listSystemKPICategories.push_back(sui->lblSystemKPI1Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI2Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI3Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI4Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI5Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI6Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI7Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI8Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI9Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI10Category);

    m_listSystemKPITimes.push_back(sui->lblSystemKPI1Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI2Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI3Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI4Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI5Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI6Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI7Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI8Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI9Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI10Time);

    m_listSystemKPIValues.push_back(sui->lblSystemKPI1Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI2Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI3Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI4Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI5Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI6Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI7Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI8Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI9Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI10Value);

    m_listSystemKPIUnits.push_back(sui->lblSystemKPI1Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI2Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI3Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI4Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI5Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI6Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI7Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI8Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI9Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI10Unit);

    m_listConsumableUCTs.clear();
    m_listConsumableGroupBoxes.clear();
    m_listConsumableNames.clear();
    m_listConsumableCategories.clear();
    m_listConsumableTimes.clear();
    m_listConsumableValues.clear();
    m_listConsumableUnits.clear();
    m_listConsumableProgressbars.clear();

    m_listConsumableUCTs.push_back(sui->uctConsumable1);
    m_listConsumableUCTs.push_back(sui->uctConsumable2);
    m_listConsumableUCTs.push_back(sui->uctConsumable3);
    m_listConsumableUCTs.push_back(sui->uctConsumable4);
    m_listConsumableUCTs.push_back(sui->uctConsumable5);
    m_listConsumableUCTs.push_back(sui->uctConsumable6);
    m_listConsumableUCTs.push_back(sui->uctConsumable7);
    m_listConsumableUCTs.push_back(sui->uctConsumable8);
    m_listConsumableUCTs.push_back(sui->uctConsumable9);

    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable1);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable2);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable3);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable4);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable5);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable6);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable7);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable8);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable9);



    m_listConsumableNames.push_back(sui->lblConsumable1Name);
    m_listConsumableNames.push_back(sui->lblConsumable2Name);
    m_listConsumableNames.push_back(sui->lblConsumable3Name);
    m_listConsumableNames.push_back(sui->lblConsumable4Name);
    m_listConsumableNames.push_back(sui->lblConsumable5Name);
    m_listConsumableNames.push_back(sui->lblConsumable6Name);
    m_listConsumableNames.push_back(sui->lblConsumable7Name);
    m_listConsumableNames.push_back(sui->lblConsumable8Name);
    m_listConsumableNames.push_back(sui->lblConsumable9Name);

    m_listConsumableTimes.push_back(sui->lblConsumable1Time);
    m_listConsumableTimes.push_back(sui->lblConsumable2Time);
    m_listConsumableTimes.push_back(sui->lblConsumable3Time);
    m_listConsumableTimes.push_back(sui->lblConsumable4Time);
    m_listConsumableTimes.push_back(sui->lblConsumable5Time);
    m_listConsumableTimes.push_back(sui->lblConsumable6Time);
    m_listConsumableTimes.push_back(sui->lblConsumable7Time);
    m_listConsumableTimes.push_back(sui->lblConsumable8Time);
    m_listConsumableTimes.push_back(sui->lblConsumable9Time);


    m_listConsumableValues.push_back(sui->lblConsumable1Value);
    m_listConsumableValues.push_back(sui->lblConsumable2Value);
    m_listConsumableValues.push_back(sui->lblConsumable3Value);
    m_listConsumableValues.push_back(sui->lblConsumable4Value);
    m_listConsumableValues.push_back(sui->lblConsumable5Value);
    m_listConsumableValues.push_back(sui->lblConsumable6Value);
    m_listConsumableValues.push_back(sui->lblConsumable7Value);
    m_listConsumableValues.push_back(sui->lblConsumable8Value);
    m_listConsumableValues.push_back(sui->lblConsumable9Value);


    m_listConsumableUnits.push_back(sui->lblConsumable1Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable2Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable3Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable4Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable5Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable6Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable7Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable8Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable9Unit);

    m_listConsumableProgressbars.push_back(sui->pgbConsumable1);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable2);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable3);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable4);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable5);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable6);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable7);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable8);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable9);




}
void IGSxGUI::DashboardView::constructKPItable1()
{
     m_listKPIs.clear();
    m_listKPIs = m_presenter->getKPIs();

        for (size_t i = 0; i < 10; i++)
        {
            KPI* kpi = m_listKPIs[i];
                m_listNormalKPINames[i]->setText(kpi->getName());
                m_listNormalKPICategories[i]->setText(kpi->getValueSets()[0]->getName());
                m_listNormalKPITimes[i]->setText(currentDateTime(STRING_TIME));
                m_listNormalKPIValues[i]->setText("0");
                m_listNormalKPIUnits[i]->setText(kpi->getDisplayName());
        }
}
void IGSxGUI::DashboardView::constructKPItable2()
{

      m_listKPIs.clear();
      m_listKPIs = m_presenter->getSystemKPIs();

     for (size_t i = 0; i < 10; i++)
        {
            KPI* kpi = m_listKPIs[i];
                m_listSystemKPINames[i]->setText(kpi->getName());
                m_listSystemKPICategories[i]->setText(kpi->getValueSets()[0]->getName());
                m_listSystemKPITimes[i]->setText(currentDateTime(STRING_TIME));
                m_listSystemKPIValues[i]->setText("0");
                m_listSystemKPIUnits[i]->setText(kpi->getDisplayName());
        }

}
void IGSxGUI::DashboardView::constructConsumableTable()
{

    m_listKPIs.clear();
    m_listKPIs = m_presenter->getConsumables();

   for (size_t i = 0; i < 9; i++)
      {
          KPI* kpi = m_listKPIs[i];
              m_listConsumableNames[i]->setText(kpi->getName());
              m_listConsumableTimes[i]->setText(currentDateTime(STRING_TIME));
              m_listConsumableValues[i]->setText("0");
              m_listConsumableUnits[i]->setText(kpi->getDisplayName());
      }

    /*
    sui->lblConsumable1Name->setText(STRING_CONSUMABLE1);
    sui->lblConsumable2Name->setText(STRING_CONSUMABLE2);
    sui->lblConsumable3Name->setText(STRING_CONSUMABLE3);
    sui->lblConsumable4Name->setText(STRING_CONSUMABLE4);
    sui->lblConsumable5Name->setText(STRING_CONSUMABLE5);
    sui->lblConsumable6Name->setText(STRING_CONSUMABLE6);
    sui->lblConsumable7Name->setText(STRING_CONSUMABLE7);
    sui->lblConsumable8Name->setText(STRING_CONSUMABLE8);
    sui->lblConsumable9Name->setText(STRING_CONSUMABLE9);

    sui->lblConsumable1Value->setText("80");
    sui->lblConsumable2Value->setText("80");
    sui->lblConsumable3Value->setText("80");
    sui->lblConsumable4Value->setText("80");
    sui->lblConsumable5Value->setText("300");
    sui->lblConsumable6Value->setText("20");
    sui->lblConsumable7Value->setText("20");
    sui->lblConsumable8Value->setText("50");
    sui->lblConsumable9Value->setText("50");

    sui->lblConsumable1Unit->setText("%");
    sui->lblConsumable2Unit->setText("%");
    sui->lblConsumable3Unit->setText("%");
    sui->lblConsumable4Unit->setText("%");
    sui->lblConsumable5Unit->setText("C");
    sui->lblConsumable6Unit->setText("mBar");
    sui->lblConsumable7Unit->setText("mBar");
    sui->lblConsumable8Unit->setText("%");
    sui->lblConsumable9Unit->setText("%");
    */


}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctNormalKPI1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI1HoverOn, this);
    sui->uctNormalKPI1->hoverLeft= boost::bind(&DashboardView::onUCTNormalKPI1HoverOff, this);

    sui->uctNormalKPI2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI2HoverOn, this);
    sui->uctNormalKPI2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI2HoverOff, this);

    sui->uctNormalKPI3->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI3HoverOn, this);
    sui->uctNormalKPI3->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI3HoverOff, this);

    sui->uctNormalKPI4->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI4HoverOn, this);
    sui->uctNormalKPI4->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI4HoverOff, this);

    sui->uctNormalKPI5->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI5HoverOn, this);
    sui->uctNormalKPI5->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI5HoverOff, this);


    sui->uctNormalKPI6->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI6HoverOn, this);
    sui->uctNormalKPI6->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI6HoverOff, this);


    sui->uctNormalKPI7->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI7HoverOn, this);
    sui->uctNormalKPI7->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI7HoverOff, this);

    sui->uctNormalKPI8->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI8HoverOn, this);
    sui->uctNormalKPI8->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI8HoverOff, this);

    sui->uctNormalKPI9->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI9HoverOn, this);
    sui->uctNormalKPI9->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI9HoverOff, this);

    sui->uctNormalKPI10->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI10HoverOn, this);
    sui->uctNormalKPI10->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI10HoverOff, this);

    /*

    sui->uctConsumable1->hoverEntered = boost::bind(&DashboardView::onConsumable1HoverOn, this);
    sui->uctConsumable1->hoverLeft= boost::bind(&DashboardView::onConsumable1HoverOff, this);

    sui->uctConsumable2->hoverEntered = boost::bind(&DashboardView::onConsumable2HoverOn, this);
    sui->uctConsumable2->hoverLeft= boost::bind(&DashboardView::onConsumable2HoverOff, this);

    sui->uctConsumable3->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable3->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable4->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable4->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable5->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable5->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable6->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable6->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable7->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable7->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable8->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable8->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable9->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable9->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);
    */



}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOnStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value,SUI::Label* p_unit)
{
   p_GroupBox->setStyleSheetClass("uctnormalkpihoveron");
   p_name->setStyleSheetClass("uctnormalkpihoveron");
   p_category->setStyleSheetClass("uctnormalkpihoveron");
   p_time->setStyleSheetClass("uctnormalkpihoveron");
   p_value->setStyleSheetClass("uctnormalkpihoveron");
   p_unit->setStyleSheetClass("uctnormalkpihoveron");
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value,SUI::Label* p_unit)
{
   p_GroupBox->setStyleSheetClass("uctnormalkpihoveroff");
   p_name->setStyleSheetClass("uctnormalkpihoveroff");
   p_category->setStyleSheetClass("uctnormalkpihoveroff");
   p_time->setStyleSheetClass("uctnormalkpihoveroff");
   p_value->setStyleSheetClass("uctnormalkpihoveroff");
   p_unit->setStyleSheetClass("uctnormalkpihoveroff");
}


void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI1,sui->lblNormalKPI1Name,sui->lblNormalKPI1Category,sui->lblNormalKPI1Time,sui->lblNormalKPI1Value,sui->lblNormalKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI1,sui->lblNormalKPI1Name,sui->lblNormalKPI1Category,sui->lblNormalKPI1Time,sui->lblNormalKPI1Value,sui->lblNormalKPI1Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI2,sui->lblNormalKPI2Name,sui->lblNormalKPI2Category,sui->lblNormalKPI2Time,sui->lblNormalKPI2Value,sui->lblNormalKPI2Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI2,sui->lblNormalKPI2Name,sui->lblNormalKPI2Category,sui->lblNormalKPI2Time,sui->lblNormalKPI2Value,sui->lblNormalKPI2Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI3,sui->lblNormalKPI3Name,sui->lblNormalKPI3Category,sui->lblNormalKPI3Time,sui->lblNormalKPI3Value,sui->lblNormalKPI3Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI3,sui->lblNormalKPI3Name,sui->lblNormalKPI3Category,sui->lblNormalKPI3Time,sui->lblNormalKPI3Value,sui->lblNormalKPI3Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI4,sui->lblNormalKPI4Name,sui->lblNormalKPI4Category,sui->lblNormalKPI4Time,sui->lblNormalKPI4Value,sui->lblNormalKPI4Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI4,sui->lblNormalKPI4Name,sui->lblNormalKPI4Category,sui->lblNormalKPI4Time,sui->lblNormalKPI4Value,sui->lblNormalKPI4Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI5,sui->lblNormalKPI5Name,sui->lblNormalKPI5Category,sui->lblNormalKPI5Time,sui->lblNormalKPI5Value,sui->lblNormalKPI5Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI5,sui->lblNormalKPI5Name,sui->lblNormalKPI5Category,sui->lblNormalKPI5Time,sui->lblNormalKPI5Value,sui->lblNormalKPI5Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI6,sui->lblNormalKPI6Name,sui->lblNormalKPI6Category,sui->lblNormalKPI6Time,sui->lblNormalKPI6Value,sui->lblNormalKPI6Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI6,sui->lblNormalKPI6Name,sui->lblNormalKPI6Category,sui->lblNormalKPI6Time,sui->lblNormalKPI6Value,sui->lblNormalKPI6Unit);

}

void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI7,sui->lblNormalKPI7Name,sui->lblNormalKPI7Category,sui->lblNormalKPI7Time,sui->lblNormalKPI7Value,sui->lblNormalKPI7Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI7,sui->lblNormalKPI7Name,sui->lblNormalKPI7Category,sui->lblNormalKPI7Time,sui->lblNormalKPI7Value,sui->lblNormalKPI7Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI8,sui->lblNormalKPI8Name,sui->lblNormalKPI8Category,sui->lblNormalKPI8Time,sui->lblNormalKPI8Value,sui->lblNormalKPI8Unit);
   }

void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI8,sui->lblNormalKPI8Name,sui->lblNormalKPI8Category,sui->lblNormalKPI8Time,sui->lblNormalKPI8Value,sui->lblNormalKPI8Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI9,sui->lblNormalKPI9Name,sui->lblNormalKPI9Category,sui->lblNormalKPI9Time,sui->lblNormalKPI9Value,sui->lblNormalKPI9Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI9,sui->lblNormalKPI9Name,sui->lblNormalKPI9Category,sui->lblNormalKPI9Time,sui->lblNormalKPI9Value,sui->lblNormalKPI9Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI10,sui->lblNormalKPI10Name,sui->lblNormalKPI10Category,sui->lblNormalKPI10Time,sui->lblNormalKPI10Value,sui->lblNormalKPI10Unit);
}

void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI10,sui->lblNormalKPI10Name,sui->lblNormalKPI10Category,sui->lblNormalKPI10Time,sui->lblNormalKPI10Value,sui->lblNormalKPI10Unit);
}


void IGSxGUI::DashboardView::onConsumable1HoverOn()
{

     sui->gbxConsumable1->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Name->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Time->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Value->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Unit->setStyleSheetClass("uctconsumablehoveron");

}

void IGSxGUI::DashboardView::onConsumable1HoverOff()
{
    sui->gbxConsumable1->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Name->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Time->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Value->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Unit->setStyleSheetClass("uctconsumablehoveroff");


}
void IGSxGUI::DashboardView::onConsumable2HoverOn()
{

     sui->gbxConsumable2->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Name->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Time->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Value->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Unit->setStyleSheetClass("uctconsumablehoveron");

}

void IGSxGUI::DashboardView::onConsumable2HoverOff()
{
    sui->gbxConsumable2->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Name->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Time->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Value->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Unit->setStyleSheetClass("uctconsumablehoveroff");


}

void IGSxGUI::DashboardView::init()
{


    //Construct Graphs
    constructGraphs();
    constructKPItable1();
    constructKPItable2();
    constructConsumableTable();

}
