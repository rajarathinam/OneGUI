/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystem.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin
|
| ! \file        IGSxGUIxSystem.cpp
| ! \brief       Implementation of System plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxSystemView.hpp"
#include "IGSxGUIxCPDView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::System::System():m_driverManager(new DriverManager()),
    m_cpdManager(new CPDManager())
{
    m_driverManager->initialize();
    m_cpdManager->initialize();
    m_systemView = new IGSxGUI::SystemView(m_driverManager);
    m_cpdView = new IGSxGUI::CPDView(m_cpdManager);
}

IGSxGUI::System::~System()
{
    delete m_driverManager;
    delete m_cpdManager;
    delete m_systemView;
    delete m_cpdView;
}

void IGSxGUI::System:: show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_cpdView->setActive(false);
    m_systemView->show(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::System:: showCPD(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_systemView->setActive(false);
    m_cpdView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::System:: setActive(bool bActive)
{
    m_systemView->setActive(bActive);
    m_cpdView->setActive(bActive);
}

void IGSxGUI::System::subscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->registerToSystemStateChanged(cb);
}

void IGSxGUI::System::unsubscribeForSystemState(const SystemStateChangedCallback& cb)
{
    m_driverManager->unregisterToSystemStateChanged(cb);
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::System::retrieveSystemState()
{
    return m_driverManager->getSystemState();
}
