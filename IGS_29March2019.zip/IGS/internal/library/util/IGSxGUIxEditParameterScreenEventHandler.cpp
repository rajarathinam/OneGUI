/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
| Ident        : IGSxGUIxEditParameterScreenEventHandler.cpp                  |
| Author       : Venugopal S                                                  |
| Description  : Source file for editing parameter screen event handling      |
|                                                                             |
| ! \file        IGSxGUIxEditNormalParameterScreenEventHandler.cpp            |
| ! \brief       Source file for editing parameter screen event handling      |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <QLineEdit>
#include <QPushButton>
#include <FWQxCore/SUIResourcePath.h>
#include <sstream>
#include <vector>
#include <string>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxEditParameterScreenEventHandler.hpp"

const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_normal = "radiobutton_12px_normal.png";
const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_normal_fill = "radiobutton_12px_normal_fill.png";
const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_hover = "radiobutton_12px_hover.png";
const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_hover_fill = "radiobutton_12px_hover_fill.png";
const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_pressed = "radiobutton_12px_pressed.png";
const std::string IGSxGUIxEditParameterScreenEventHandler::radiobutton_12px_pressed_fill = "radiobutton_12px_pressed_fill.png";

const QString IGSxGUIxEditParameterScreenEventHandler::STYLE_GREY_BORDER = "border-color:#AAAAAA";
const QString IGSxGUIxEditParameterScreenEventHandler::STYLE_BLUE_BORDER = "border-color:#0AA8FB";
const QString IGSxGUIxEditParameterScreenEventHandler::STYLE_DOTTED_BORDER = "border: 2px dotted #1B3E93";
const QString IGSxGUIxEditParameterScreenEventHandler::STYLE_LE_BLUE_BORDER = "border:1px solid #0AA8FB;selection-background-color: #0AA8FB;padding-left:20px;";

const std::string IGSxGUIxEditParameterScreenEventHandler::STYLE_RADIO_CHECKED_OPENING = "QRadioButton::indicator:checked {image: url(";
const std::string IGSxGUIxEditParameterScreenEventHandler::STYLE_RADIO_UNCHECKED_OPENING = "QRadioButton::indicator:unchecked {image: url(";
const std::string IGSxGUIxEditParameterScreenEventHandler::STYLE_RADIO_BLUE_CLOSING = ")} QRadioButton{color:#1b3e93;}";
const std::string IGSxGUIxEditParameterScreenEventHandler::STYLE_RADIO_BLACK_CLOSING = ")} QRadioButton{color:#000000;}";

const std::string IGSxGUIxEditParameterScreenEventHandler::OBJNAME_LINEEDIT = "lneValue";
const std::string IGSxGUIxEditParameterScreenEventHandler::OBJNAME_RADIOFALSE = "rbtnParamFalse";
const std::string IGSxGUIxEditParameterScreenEventHandler::OBJNAME_RADIOTRUE = "rbtnParamTrue";

IGSxGUIxEditParameterScreenEventHandler::IGSxGUIxEditParameterScreenEventHandler(QObject *parent) :
    QObject(parent),
    m_leValue(NULL),
    m_rbTrue(NULL),
    m_rbFalse(NULL),
    m_btnUpdate(NULL),
    m_btnCancel(NULL),
    m_btnReset(NULL),
    m_editParameterScreenCallBack(NULL)
{
}

void IGSxGUIxEditParameterScreenEventHandler::setEditParameterScreenCallBack(IGSxGUI::IEditParameterScreenCallBack *editParameterScreenCallBack)
{
    if (editParameterScreenCallBack != NULL) {
        m_editParameterScreenCallBack = editParameterScreenCallBack;
    }
}

void IGSxGUIxEditParameterScreenEventHandler::installEvents(std::vector<SUI::Widget *> widgetVector)
{
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(widgetVector[3]);
    SUI::BaseWidget* baseWidget5 = dynamic_cast<SUI::BaseWidget*>(widgetVector[4]);
    SUI::BaseWidget* baseWidget6 = dynamic_cast<SUI::BaseWidget*>(widgetVector[5]);

    if (NULL != baseWidget1) {
        m_leValue = dynamic_cast<QLineEdit*>(baseWidget1->getWidget());
    }
    if (NULL != baseWidget2) {
        m_rbTrue = dynamic_cast<QRadioButton*>(baseWidget2->getWidget());
    }
    if (NULL != baseWidget3) {
        m_rbFalse = dynamic_cast<QRadioButton*>(baseWidget3->getWidget());
    }
    if (NULL != baseWidget4) {
        m_btnUpdate = dynamic_cast<QPushButton*>(baseWidget4->getWidget());
    }
    if (NULL != baseWidget5) {
        m_btnCancel = dynamic_cast<QPushButton*>(baseWidget5->getWidget());
    }
    if (NULL != baseWidget6) {
        m_btnReset = dynamic_cast<QPushButton*>(baseWidget6->getWidget());
    }

    if (NULL != m_leValue) {
        m_leValue->installEventFilter(this);
    }
    if (NULL != m_rbTrue) {
        m_rbTrue->installEventFilter(this);
    }
    if (NULL != m_rbFalse) {
        m_rbFalse->installEventFilter(this);
    }
    if (NULL != m_btnUpdate) {
        m_btnUpdate->installEventFilter(this);
    }
    if (NULL != m_btnCancel) {
        m_btnCancel->installEventFilter(this);
    }
    if (NULL != m_btnReset) {
        m_btnReset->installEventFilter(this);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::focusPreviousWidget()
{
    if (m_leValue->isVisible()){
        if (m_leValue->hasFocus()) {
            clearFocusSetGreyBorder(m_leValue);
            setFocusSetDottedBorder(m_btnReset);

        } else if (m_btnReset->hasFocus()) {
            clearFocusSetBlueBorder(m_btnReset);
            setFocusSetDottedBorder(m_btnCancel);

        } else if (m_btnCancel->hasFocus()) {
            clearFocusSetBlueBorder(m_btnCancel);
            if (m_btnUpdate->isEnabled()){
                setFocusSetDottedBorder(m_btnUpdate);
            } else {
                setFocusSetBlueBorder(m_leValue);
                m_leValue->selectAll();
            }

        } else if (m_btnUpdate->hasFocus()) {
            setFocusSetBlueBorder(m_leValue);
            m_leValue->selectAll();
        }
    } else if (m_rbTrue->isVisible()) {
        if (m_rbTrue->hasFocus()){
            m_rbTrue->clearFocus();
            setNormalStyle(m_rbTrue);
            setFocusSetDottedBorder(m_btnReset);

        } else if (m_btnReset->hasFocus()) {
            clearFocusSetBlueBorder(m_btnReset);
            setFocusSetDottedBorder(m_btnCancel);

        } else if (m_btnCancel->hasFocus()) {
            clearFocusSetBlueBorder(m_btnCancel);
            if (m_btnUpdate->isEnabled()) {
                setFocusSetDottedBorder(m_btnUpdate);
            } else {
                m_rbFalse->setFocus();
                setHoverStyle(m_rbFalse);
            }

        } else if (m_btnUpdate->hasFocus()) {
            clearFocusSetBlueBorder(m_btnUpdate);
            m_rbFalse->setFocus();
            setHoverStyle(m_rbFalse);

        } else if (m_rbFalse->hasFocus()) {
            m_rbFalse->clearFocus();
            setNormalStyle(m_rbFalse);
            m_rbTrue->setFocus();
            setHoverStyle(m_rbTrue);
        }
    }
}

void IGSxGUIxEditParameterScreenEventHandler::clearFocusSetButtonBlueBorder()
{
    m_btnUpdate->clearFocus();
    m_btnCancel->clearFocus();
    m_btnReset->clearFocus();

    m_btnUpdate->setStyleSheet(STYLE_BLUE_BORDER);
    m_btnCancel->setStyleSheet(STYLE_BLUE_BORDER);
    m_btnReset->setStyleSheet(STYLE_BLUE_BORDER);
}

void IGSxGUIxEditParameterScreenEventHandler::focusNextWidget()
{
    if (m_leValue->isVisible()){
        if (m_leValue->hasFocus()) {
            clearFocusSetGreyBorder(m_leValue);
            if (m_btnUpdate->isEnabled()) {
                setFocusSetDottedBorder(m_btnUpdate);
            } else {
                setFocusSetDottedBorder(m_btnCancel);
            }

        } else if (m_btnUpdate->hasFocus()) {
            clearFocusSetBlueBorder(m_btnUpdate);
            setFocusSetDottedBorder(m_btnCancel);

        } else if (m_btnCancel->hasFocus()) {
            clearFocusSetBlueBorder(m_btnCancel);
            setFocusSetDottedBorder(m_btnReset);

        } else if (m_btnReset->hasFocus()) {
            clearFocusSetBlueBorder(m_btnReset);
            setFocusSetBlueBorder(m_leValue);
            m_leValue->selectAll();
        }
    } else if (m_rbTrue->isVisible()) {
        if (m_rbTrue->hasFocus()){
            m_rbTrue->clearFocus();
            setNormalStyle(m_rbTrue);
            m_rbFalse->setFocus();
            setHoverStyle(m_rbFalse);

        } else if (m_rbFalse->hasFocus()) {
            m_rbFalse->clearFocus();
            setNormalStyle(m_rbFalse);
            if (m_btnUpdate->isEnabled()) {
                setFocusSetDottedBorder(m_btnUpdate);
            } else {
                setFocusSetDottedBorder(m_btnCancel);
            }

        } else if (m_btnUpdate->hasFocus()) {
            clearFocusSetBlueBorder(m_btnUpdate);
            setFocusSetDottedBorder(m_btnCancel);
        } else if (m_btnCancel->hasFocus()) {
            clearFocusSetBlueBorder(m_btnCancel);
            setFocusSetDottedBorder(m_btnReset);

        } else if (m_btnReset->hasFocus()) {
            clearFocusSetBlueBorder(m_btnReset);
            setHoverStyle(m_rbTrue);
            m_rbTrue->setFocus();
        }
    }
}

void IGSxGUIxEditParameterScreenEventHandler::clearFocusSetBlueBorder(QLineEdit *lne)
{
    if (lne != NULL) {
        lne->clearFocus();
        lne->setStyleSheet(STYLE_BLUE_BORDER);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::clearFocusSetBlueBorder(QPushButton *btn)
{
    if (btn != NULL) {
        btn->clearFocus();
        btn->setStyleSheet(STYLE_BLUE_BORDER);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::setFocusSetBlueBorder(QLineEdit *lne)
{
    if (lne != NULL) {
        lne->setFocus();
        lne->setStyleSheet(STYLE_BLUE_BORDER);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::setFocusSetDottedBorder(QPushButton *btn)
{
    if (btn != NULL) {
        btn->setFocus();
        btn->setStyleSheet(STYLE_DOTTED_BORDER);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::clearFocusSetGreyBorder(QLineEdit *lne)
{
    if (lne != NULL) {
        lne->clearFocus();
        lne->setStyleSheet(STYLE_GREY_BORDER);
    }
}

void IGSxGUIxEditParameterScreenEventHandler::setHoverStyle(QRadioButton *btn)
{
    if (btn != NULL) {
        std::ostringstream oss;
        if (btn->isChecked()) {
            oss << STYLE_RADIO_CHECKED_OPENING << SUI::ResourcePath::getResourceFile(radiobutton_12px_hover_fill) << STYLE_RADIO_BLUE_CLOSING;
        } else {
            oss << STYLE_RADIO_UNCHECKED_OPENING << SUI::ResourcePath::getResourceFile(radiobutton_12px_hover) << STYLE_RADIO_BLUE_CLOSING;
        }
        std::string style = oss.str();
        btn->setStyleSheet(style.c_str());
    }
}

void IGSxGUIxEditParameterScreenEventHandler::setNormalStyle(QRadioButton* btn)
{
    if (btn != NULL) {
        std::ostringstream oss;
        if (btn->isChecked()) {
            oss << STYLE_RADIO_CHECKED_OPENING << SUI::ResourcePath::getResourceFile(radiobutton_12px_normal_fill) << STYLE_RADIO_BLACK_CLOSING;
        } else {
            oss << STYLE_RADIO_UNCHECKED_OPENING << SUI::ResourcePath::getResourceFile(radiobutton_12px_normal) << STYLE_RADIO_BLACK_CLOSING;
        }
        std::string style = oss.str();
        btn->setStyleSheet(style.c_str());
    }
}

bool IGSxGUIxEditParameterScreenEventHandler::eventFilter(QObject *object, QEvent *event)
{
    QString objname = object->objectName();
    std::string objName = objname.toStdString();

    if (event->type() == QEvent::KeyPress) {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        int key = keyEvent->key();
        switch (key) {
        case Qt::Key_Backtab:
            focusPreviousWidget();
            return true;
        case Qt::Key_Tab:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                focusPreviousWidget();
            } else {
                focusNextWidget();
            }
            return true;

        case Qt::Key_Return:
        case Qt::Key_Enter:
            processEnterKey();
            return true;        
        default:
            return object->eventFilter(object, event);
        }
    } else if ((event->type() == QEvent::FocusIn) && (objName == OBJNAME_LINEEDIT)){
        if (m_leValue->hasFocus()) {
            clearFocusSetButtonBlueBorder();
            m_leValue->setStyleSheet(STYLE_LE_BLUE_BORDER);
        }

    } else if ((event->type() == QEvent::FocusIn) && (objName == OBJNAME_RADIOTRUE)){
        if (m_rbTrue->hasFocus()) {
            clearFocusSetButtonBlueBorder();
        }

    } else if ((event->type() == QEvent::FocusIn) && (objName == OBJNAME_RADIOFALSE)){
        if (m_rbFalse->hasFocus()) {
            clearFocusSetButtonBlueBorder();
        }
    }
    return object->eventFilter(object, event);
}

void IGSxGUIxEditParameterScreenEventHandler::processEnterKey() const
{
    if (m_editParameterScreenCallBack != NULL) {
        if (m_rbTrue->hasFocus()) {
            m_editParameterScreenCallBack->onPopupRadioTrueButtonPressed();

        } else if (m_rbFalse->hasFocus()) {
            m_editParameterScreenCallBack->onPopupRadioFalseButtonPressed();

        } else if (m_btnUpdate->hasFocus()) {
            m_editParameterScreenCallBack->onPopupUpdateButtonPressed();

        } else if (m_btnCancel->hasFocus()) {
            m_editParameterScreenCallBack->onPopupCancelButtonPressed();

        } else if (m_btnReset->hasFocus()) {
            m_editParameterScreenCallBack->onPopupResetButtonPressed();
        }
    }
}

