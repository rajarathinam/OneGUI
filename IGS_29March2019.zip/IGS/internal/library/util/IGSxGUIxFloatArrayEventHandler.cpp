#include <vector>
#include <string>
#include "IGSxGUIxFloatArrayEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

const std::string IGSxGUIxFloatArrayEventHandler::LINE_EDIT_NAME = "LineEdit:";

IGSxGUIxFloatArrayEventHandler* IGSxGUIxFloatArrayEventHandler::obj = NULL;

IGSxGUIxFloatArrayEventHandler* IGSxGUIxFloatArrayEventHandler::getInstance(IGSxGUI::IFloatArrayCallBack *ptrFloatArrayCallBack)
{
    if (NULL == obj)
    {
        obj = new IGSxGUIxFloatArrayEventHandler();
        obj->setFloatArrayCallBack(ptrFloatArrayCallBack);
    }
    return obj;
}

IGSxGUIxFloatArrayEventHandler::IGSxGUIxFloatArrayEventHandler(QObject *parent) :
    QObject(parent),
    m_ptrFloatArrayCallBack(NULL),
    mTextSelected(false)
{
}

void IGSxGUIxFloatArrayEventHandler::setFloatArrayCallBack(IGSxGUI::IFloatArrayCallBack *ptrFloatArrayCallBack)
{
    m_ptrFloatArrayCallBack = ptrFloatArrayCallBack;
}

int IGSxGUIxFloatArrayEventHandler::extractLineEditNumFromObjName(const std::string &objName)
{
    size_t pos1 = objName.find(":");
    std::string subString = objName.substr(pos1 + 1, objName.size());
    int lineEditNUm = atoi(subString.c_str());
    return lineEditNUm;
}

bool IGSxGUIxFloatArrayEventHandler::eventFilter(QObject *object, QEvent *event)
{
   QString objname = object->objectName();
   std::string objName = objname.toStdString();
   bool result = false;
   if((objName.find(LINE_EDIT_NAME) == std::string::npos))
   {
      result = object->eventFilter(object, event);
   }
   else
   {
      result = processEvent(event, object);
   }
   return result;
}

bool IGSxGUIxFloatArrayEventHandler::processEvent(QEvent *eventObj, QObject* object)
{
   QString objname = object->objectName();
   std::string objName = objname.toStdString();
   QEvent::Type event = eventObj->type();
   bool result = false;
   switch(event)
   {
   case QEvent::MouseButtonDblClick:
   {
      QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
      if (qedit != NULL) {
         qedit->selectAll();
      }
      result = true;
   }
   break;
   case QEvent::MouseButtonRelease:
   {
      QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
      if (qedit != NULL && mTextSelected == true) {
         qedit->selectAll();
         mTextSelected = false;
      }
      result = true;
   }
   break;
   case QEvent::FocusIn:
   {
      QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
      if (qedit != NULL && qedit->selectionStart() != 0) {
         m_ptrFloatArrayCallBack->setFACurrentLineEditIndex(extractLineEditNumFromObjName(objName));
         // hide the clearbutton of previous line edit, only active line edit should have clearbutton when there is text in line edit
         m_ptrFloatArrayCallBack->setFALineEditClearButtonVisibility(m_ptrFloatArrayCallBack->getFAPreviousLineEditIndex(), false);
         // if line edit is empty, the clearbutton should not be visible
         if (qedit->text() == "") {
            m_ptrFloatArrayCallBack->setFALineEditClearButtonVisibility(m_ptrFloatArrayCallBack->getFACurrentLineEditIndex(), false);
         } else {
            m_ptrFloatArrayCallBack->setFALineEditClearButtonVisibility(m_ptrFloatArrayCallBack->getFACurrentLineEditIndex(), true);
         }
         QTimer::singleShot(0,qedit,SLOT(selectAll()));
      }
      mTextSelected = true;
      result = true;
   }
   break;
   case QEvent::FocusOut:
   { 
      QLineEdit* qedit = dynamic_cast<QLineEdit*>(object);
      if (qedit != NULL) {
         m_ptrFloatArrayCallBack->setFAPreviousLineEditIndex(extractLineEditNumFromObjName(objName));
         qedit->deselect();
      }
      mTextSelected = true;
      result = false;

   }
   break;
   default:
   {
      result = object->eventFilter(object, eventObj);
   }
   break;
   }
   return result;
}
