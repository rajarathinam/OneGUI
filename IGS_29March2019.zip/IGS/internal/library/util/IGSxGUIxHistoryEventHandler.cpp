#include "IGSxGUIxHistoryEventHandler.hpp"
#include <QApplication>
#include <QClipboard>
#include <QLineEdit>
#include <string>
#include "IGSxGUIxSystemDateTime.hpp"

const std::string IGSxGUIxHistoryEventHandler::HISTORY_ROWS_NAME = "uct-tawParametersHistory:";
const QString IGSxGUIxHistoryEventHandler::STRING_SEARCH_BUTTON = "btnSearchClear";
const QString IGSxGUIxHistoryEventHandler::STRING_SEARCH_LINEEDIT = "lneSearchParameterText";
const QString IGSxGUIxHistoryEventHandler::STRING_SEARCH_ONFOCUS_STYLESHEET = "border:1px solid #0AA8FB";
const QString IGSxGUIxHistoryEventHandler::STRING_SEARCH_OFFFOCUS_STYLESHEET = "border:1px solid #AAAAAA";
const QString IGSxGUIxHistoryEventHandler::STRING_SEARCH_PARAMETER = "Search parameter";
const QString IGSxGUIxHistoryEventHandler::STRING_LABEL_OLDVALUE="lblParameterOldValue";
const QString IGSxGUIxHistoryEventHandler::STRING_LABEL_NEWVALUE="lblParameterNewValue";
const QString IGSxGUIxHistoryEventHandler::STRING_LABEL_CHANGEDBY="lblChangedBy";
const QString IGSxGUIxHistoryEventHandler::STRING_LABEL_REASON ="lblReason";
const QString IGSxGUIxHistoryEventHandler::STRING_HISTORY_SCROLLBAR_NAME = "scbHistoryTable";
IGSxGUIxHistoryEventHandler* IGSxGUIxHistoryEventHandler::obj = NULL;

IGSxGUIxHistoryEventHandler* IGSxGUIxHistoryEventHandler::getInstance()
{
    if (NULL == obj) {
        obj = new IGSxGUIxHistoryEventHandler();
    }
    return obj;
}

IGSxGUIxHistoryEventHandler::IGSxGUIxHistoryEventHandler(QObject *parent) :
    QObject(parent), m_dialog(NULL), m_tableWidget(NULL), m_lineEdit(NULL), m_HistoryCallBack(NULL), m_LineEditFocus(false)
{
}

IGSxGUIxHistoryEventHandler::~IGSxGUIxHistoryEventHandler()
{
}

void IGSxGUIxHistoryEventHandler::setDialog(SUI::Dialog *dialog)
{
    m_dialog = dialog;
}

void IGSxGUIxHistoryEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
}
void IGSxGUIxHistoryEventHandler::setLineEdit(SUI::LineEdit *lineEdit)
{
    m_lineEdit = lineEdit;
}

void IGSxGUIxHistoryEventHandler::setHistoryCallBack(IGSxGUI::IHistoryCallBack  *historyCallBack)
{
    m_HistoryCallBack  = historyCallBack;
}

void IGSxGUIxHistoryEventHandler::selectAllRows()
{
    for (int row = 0; row < m_tableWidget->rowCount(); ++row) {
        IGSxGUI::Util::selectHistoryRow(m_tableWidget, row);
        SUI::Widget *widget = m_tableWidget->getWidgetItem(row, 0);
        bool selected = false;
        bool isParamInlist = false;
        m_HistoryCallBack->getParameterHistoryDataInformation(row, selected, isParamInlist);

        if (isParamInlist) {
            IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
        } else {
            IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(widget);
        }
    }
    m_HistoryCallBack->selectAllRows();
}

void IGSxGUIxHistoryEventHandler::copySelectedRows()
{
    std::string completCopiedText = m_HistoryCallBack->getParameterHistoryData();
    QClipboard *clipboard = QApplication::clipboard();
    clipboard->setText("");
    clipboard->setText(QString(completCopiedText.c_str()));
}

void IGSxGUIxHistoryEventHandler::selectUpRows()
{
    m_HistoryCallBack->selectUpRow();
    int currentRow = m_HistoryCallBack->getCurrentRow();
    if (currentRow > 0) {
        m_HistoryCallBack->setCurrentRow(currentRow - 1);
    }
}

void IGSxGUIxHistoryEventHandler::selectDownRows()
{
    m_HistoryCallBack->selectDownRow();
    int visibleRows = m_HistoryCallBack->getVisibleRowsCount();
    int currentRow = m_HistoryCallBack->getCurrentRow();
    if (currentRow != -1 && currentRow < visibleRows - 1) {
        m_HistoryCallBack->setCurrentRow(currentRow + 1);
    } else if (currentRow != -1 && currentRow > visibleRows - 1) {
        m_HistoryCallBack->setCurrentRow(currentRow - 1);
    }
}

bool IGSxGUIxHistoryEventHandler::processMousePressEvent(QObject *object)
{
    QString objname = object->objectName();
    SUI::BaseWidget* baseWidget = dynamic_cast<SUI::BaseWidget*>(m_lineEdit);
    QLineEdit* lineEdit = dynamic_cast<QLineEdit*>(baseWidget->getWidget());

    if (objname.contains(STRING_SEARCH_LINEEDIT) == true) {
        m_LineEditFocus = true;
        lineEdit->setStyleSheet(STRING_SEARCH_ONFOCUS_STYLESHEET);
        lineEdit->setPlaceholderText("");
        lineEdit->setFocus();
        return true;
    }  else if (objname.contains(STRING_SEARCH_BUTTON) == true) {
        lineEdit->setStyleSheet(STRING_SEARCH_ONFOCUS_STYLESHEET);
        lineEdit->setPlaceholderText("");
        lineEdit->clear();
        lineEdit->setFocus();
        return true;
    } else if(m_LineEditFocus != true){
        lineEdit->setStyleSheet(STRING_SEARCH_OFFFOCUS_STYLESHEET);
        lineEdit->setPlaceholderText(STRING_SEARCH_PARAMETER);
        return true;
    }
    return false;
}

bool IGSxGUIxHistoryEventHandler::processMouseMoveEvent(QObject *object)
{
    QString objname = object->objectName();
    int currentRow = -1;
    std::string objName = objname.toStdString();
    if (objName.find(HISTORY_ROWS_NAME) != std::string::npos) {
        size_t pos1 = objName.find(":");
        size_t pos2 = objName.find("-", pos1);
        std::string subString = objName.substr(pos1 + 1, pos2 - pos1 - 1);
        // setting current row to mouse hovered(moved) row
        currentRow = atoi(subString.c_str());
    }
    if (objname.contains(STRING_LABEL_OLDVALUE) == true) {
        m_HistoryCallBack->showToolTipForColumn(currentRow, 1);
    } else if (objname.contains(STRING_LABEL_NEWVALUE) == true) {
        m_HistoryCallBack->showToolTipForColumn(currentRow, 2);
    } else if (objname.contains(STRING_LABEL_CHANGEDBY) == true) {
        m_HistoryCallBack->showToolTipForColumn(currentRow, 4);
    } else if (objname.contains(STRING_LABEL_REASON) == true) {
        m_HistoryCallBack->showToolTipForColumn(currentRow, 5);
    } else {
        m_HistoryCallBack->showToolTipForColumn(currentRow, 0);
    }
    return true;
}

bool IGSxGUIxHistoryEventHandler::eventFilter(QObject *object, QEvent *event)
{
    switch (event->type()) {
    case QEvent::KeyPress: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        switch (keyEvent->key()) {
        case Qt::Key_Control:
            m_HistoryCallBack->setCtrlKeyPressed(true);
            return true;
        case Qt::Key_Shift:
            m_HistoryCallBack->setShiftKeyPressed(true);
            return true;
        case Qt::Key_A:
            if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
                selectAllRows();
                // setting current row to -1 so that after selecting all the rows,
                // shift should not work untill selecting a row by clicking it
                m_HistoryCallBack->invalidateCurrentRow();
                return true;
            } else {
                // When ctrl is not pressed, user should able to type alphabet A/a in history dialog currently in search field
                return false;
            }
        case Qt::Key_C:
            if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
                copySelectedRows();
                return true;
            } else {
                // When ctrl is not pressed, user should able to type alphabet C/c in history dialog currently in search field
                return false;
            }
        case Qt::Key_Up:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                selectUpRows();
                return true;
            }
            break;
        case Qt::Key_Down:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                selectDownRows();
                return true;
            }
            break;
        default:
            return QObject::eventFilter(object, event);
        }
    }
    case QEvent::MouseMove: {
        if (STRING_HISTORY_SCROLLBAR_NAME != object->objectName()) {
            processMouseMoveEvent(object);
        }
        break;
    }
    case QEvent::KeyRelease: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        if (keyEvent->key() == Qt::Key_Control) {
            m_HistoryCallBack->setCtrlKeyPressed(false);
        } else if (keyEvent->key() == Qt::Key_Shift) {
            m_HistoryCallBack->setShiftKeyPressed(false);
        }
        return true;
    }
    case QEvent::MouseButtonRelease:{
        if (object->objectName().contains(STRING_SEARCH_LINEEDIT) == true) {
             m_LineEditFocus = false;
        }
        break;
    }
    case QEvent::MouseButtonPress: {
        if (STRING_HISTORY_SCROLLBAR_NAME != object->objectName()) {
             processMousePressEvent(object);
        }
        break;
    }
    default:
        return QObject::eventFilter(object, event);
    }
    return QObject::eventFilter(object, event);
}

