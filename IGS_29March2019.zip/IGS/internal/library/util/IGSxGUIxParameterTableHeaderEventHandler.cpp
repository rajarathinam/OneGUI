#include "IGSxGUIxParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"

const std::string IGSxGUIxParameterTableHeaderEventHandler::MOUSE_ENTERED_COLOR_CODE = "#B3E2FF";
const std::string IGSxGUIxParameterTableHeaderEventHandler::MOUSE_RELEASED_COLOR_CODE= "#1B3E93";
const std::string IGSxGUIxParameterTableHeaderEventHandler::MOUSE_PRESSED_COLOR_CODE = "#FF7F45";
const int IGSxGUIxParameterTableHeaderEventHandler::PARAMETER_HISTORY_BUTTON_FONT_SIZE = 11;

const QString IGSxGUIxParameterTableHeaderEventHandler::BUTTON_PARAMETERNAME = "btnParameterName";
const QString IGSxGUIxParameterTableHeaderEventHandler::BUTTON_UPARROW = "btnParameterNameUpArrow";
const QString IGSxGUIxParameterTableHeaderEventHandler::BUTTON_DOWNARROW = "btnParameterNameDownArrow";
const QString IGSxGUIxParameterTableHeaderEventHandler::BUTTON_PARAMETERNAME2 = "btnParameterName2";

IGSxGUIxParameterTableHeaderEventHandler::IGSxGUIxParameterTableHeaderEventHandler():
    parameterNameAsc(NULL),
    parameterNameDes(NULL),
    upArrow(NULL),
    downArrow(NULL),
    m_scrollBar(NULL),
    m_parameterValue(NULL),
    m_parameterNameGroupBox(NULL),
    m_tableView(NULL),
    upArrowBtn(NULL),
    downArrowBtn(NULL)
{
}

void IGSxGUIxParameterTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);
    SUI::BaseWidget* baseWidget5 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[4]);
    SUI::BaseWidget* baseWidget6 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[5]);
    SUI::BaseWidget* baseWidget7 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[6]);
    SUI::BaseWidget* baseWidget8 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[7]);

    parameterNameAsc = dynamic_cast<QPushButton*>(baseWidget1->getWidget());
    parameterNameDes = dynamic_cast<QPushButton*>(baseWidget2->getWidget());
    upArrow = dynamic_cast<QPushButton*>(baseWidget3->getWidget());
    downArrow = dynamic_cast<QPushButton*>(baseWidget4->getWidget());
    m_scrollBar = dynamic_cast<QScrollBar*>(baseWidget5->getWidget());
    m_parameterValue = dynamic_cast<QPushButton*>(baseWidget6->getWidget());
    m_parameterNameGroupBox = dynamic_cast<QGroupBox*>(baseWidget7->getWidget());
    m_tableView = dynamic_cast<QTableView*>(baseWidget8->getWidget());

    parameterNameAsc->installEventFilter(this);
    parameterNameDes->installEventFilter(this);
    upArrow->installEventFilter(this);
    downArrow->installEventFilter(this);
    m_parameterValue->installEventFilter(this);
    m_parameterNameGroupBox->installEventFilter(this);
    m_tableView->installEventFilter(this);

    upArrowBtn = m_widgetVector[2];
    downArrowBtn = m_widgetVector[3];
}

void IGSxGUIxParameterTableHeaderEventHandler::mousePressed()
{
    parameterNameAsc->setStyleSheet("color:#FF7F45");
    parameterNameDes->setStyleSheet("color:#FF7F45");
    IGSxGUI::Util::setAwesome(upArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, MOUSE_PRESSED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);
    IGSxGUI::Util::setAwesome(downArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_desc,MOUSE_PRESSED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);

}

void IGSxGUIxParameterTableHeaderEventHandler::mouseReleased()
{
    parameterNameAsc->setStyleSheet("color:#1B3E93");
    parameterNameDes->setStyleSheet("color:#1B3E93");
    IGSxGUI::Util::setAwesome(upArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, MOUSE_RELEASED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);
    IGSxGUI::Util::setAwesome(downArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, MOUSE_RELEASED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);

}

void IGSxGUIxParameterTableHeaderEventHandler::mouseEnter()
{
    parameterNameAsc->setStyleSheet("color:#B3E2FF");
    parameterNameDes->setStyleSheet("color:#B3E2FF");
    IGSxGUI::Util::setAwesome(upArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, MOUSE_ENTERED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);
    IGSxGUI::Util::setAwesome(downArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, MOUSE_ENTERED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);

}

void IGSxGUIxParameterTableHeaderEventHandler::mouseLeft()
{
    parameterNameAsc->setStyleSheet("color:#1B3E93");
    parameterNameDes->setStyleSheet("color:#1B3E93");
    IGSxGUI::Util::setAwesome(upArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, MOUSE_RELEASED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);
    IGSxGUI::Util::setAwesome(downArrowBtn, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, MOUSE_RELEASED_COLOR_CODE, PARAMETER_HISTORY_BUTTON_FONT_SIZE);

}

