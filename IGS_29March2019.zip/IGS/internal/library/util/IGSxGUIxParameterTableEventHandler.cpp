/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterTableEventHandler.cpp
| Author       : Raja A
| Description  : Implementation for ParameterTable Event Handler
|
| ! \file        IGSxGUIxCommonEventHandler.hpp
| ! \brief       Implementation for ParameterTable Event Handler
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#include <QClipboard>
#include <QApplication>
#include <QScrollBar>
#include"IGSxGUIxParameterTableEventHandler.hpp"

IGSxGUIxParameterTableEventHandler::IGSxGUIxParameterTableEventHandler(QObject *parent):m_groupBox(NULL),
  m_tableWidget(NULL), m_scrollBar(NULL),
  m_viewCallBack(NULL)
{
}


IGSxGUIxParameterTableEventHandler::~IGSxGUIxParameterTableEventHandler()
{
}


void IGSxGUIxParameterTableEventHandler::setGroupBox(SUI::GroupBox *groupBox)
{
    m_groupBox = groupBox;
}


void IGSxGUIxParameterTableEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget = tableWidget;
}

void IGSxGUIxParameterTableEventHandler::setScrollBar(SUI::ScrollBar *scrollBar)
{
    m_scrollBar = scrollBar;
    SUI::BaseWidget* scbBAseWidget = dynamic_cast<SUI::BaseWidget*>(m_scrollBar);
    QScrollBar* qScrollbar = dynamic_cast<QScrollBar*>(scbBAseWidget->getWidget());
    qScrollbar->installEventFilter(this);
}


void IGSxGUIxParameterTableEventHandler::setViewCallBack(IGSxGUI::IMachineconstantsCallback *viewCallBack)
{
    m_viewCallBack = viewCallBack;
}

void IGSxGUIxParameterTableEventHandler::selectUpRows()
{
    m_viewCallBack->selectUpRow();
}

void IGSxGUIxParameterTableEventHandler::selectDownRows()
{
    m_viewCallBack->selectDownRow();
}

bool IGSxGUIxParameterTableEventHandler::eventFilter(QObject *object, QEvent *event)
{
    switch (event->type()) {
    case QEvent::KeyPress: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);
        switch (keyEvent->key()) {
        case Qt::Key_Control:
            if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
                m_viewCallBack->setCtrlKeyPressed(true);
            }
            return true;
        case Qt::Key_Shift:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                m_viewCallBack->setShiftKeyPressed(true);
            }
            return true;
        case Qt::Key_A:
            if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
                m_viewCallBack->selectAllRows();
                // setting current row to -1 so that after selecting all the rows, shift should not work untill selecting a row by clicking it
                m_viewCallBack->invalidateCurrentRow();
                return true;
            }
        case Qt::Key_C:
            if (keyEvent->modifiers().testFlag(Qt::ControlModifier)) {
                copySelectedRows();
                return true;
            }
        case Qt::Key_Up:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                selectUpRows();
                return true;
            }
            break;
        case Qt::Key_Down:
            if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                selectDownRows();
                return true;
            }
            break;
        default:
            break;
        }
        break;
    }
    case QEvent::KeyRelease: {
        QKeyEvent *keyEvent = dynamic_cast<QKeyEvent*>(event);

        if (keyEvent->key() == Qt::Key_Control) {
            m_viewCallBack->setCtrlKeyPressed(false);
        } else if (keyEvent->key() == Qt::Key_Shift) {
            m_viewCallBack->setShiftKeyPressed(false);
            return true;
        }
        return true;
    }
    case QEvent::Wheel: {
        QString objectName = object->objectName();
        if (("scbParametersTable" == objectName) ||
                ("tawParameters" == objectName) ||
                ("qt_scrollarea_viewport" == objectName)) {
            QWheelEvent *wheelEvent = dynamic_cast<QWheelEvent*>(event);
            int numDegrees = wheelEvent->delta() / 8;
            int numSteps = numDegrees / 15;
            if ((wheelEvent->orientation() == Qt::Vertical) &&
                    m_scrollBar->isVisible() && m_scrollBar->isEnabled()) {
                m_scrollBar->setValue(m_scrollBar->getValue() - numSteps);
            }
            wheelEvent->accept();
            m_viewCallBack->setFocusToParamTable();
        }
        return true;
    }
    default:
        break;
    }
    return QObject::eventFilter(object, event);
}

void IGSxGUIxParameterTableEventHandler::copySelectedRows()
{
    std::string completCopiedText = m_viewCallBack->getFomatedParameterDataToCopy();
    QClipboard *clipboard = QApplication::clipboard();
    clipboard->setText("");
    clipboard->setText(QString(completCopiedText.c_str()));
}
