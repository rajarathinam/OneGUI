#include "IGSxGUIxPendingParameterTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"
#include <QScrollBar>

const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_ENTERED_COLOR_CODE = "color:#B3E2FF";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_RELEASED_COLOR_CODE = "color:#1B3E93";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_PRESSED_COLOR_CODE = "color:#FF7F45";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_ENTERED_STYLE = "font-family: FontAwesome;font-size:11px;color:#B3E2FF";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_RELEASED_STYLE= "font-family: FontAwesome;font-size:11px;color:#1B3E93";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::MOUSE_PRESSED_STYLE = "font-family: FontAwesome;font-size:11px;color:#FF7F45";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::BUTTON_PARAMETERNAME = "btnPendingParameterName";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::BUTTON_UPARROW = "btnPendingParameterNameUpArrow";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::BUTTON_DOWNARROW = "btnPendingParameterNameDownArrow";
const QString IGSxGUIxPendingParameterTableHeaderEventHandler::BUTTON_UPDOWNARROW = "btnPendingParameterNameUpDownArrow";

IGSxGUIxPendingParameterTableHeaderEventHandler::IGSxGUIxPendingParameterTableHeaderEventHandler():
    parameterName(NULL), upArrow(NULL), downArrow(NULL), upDownArrow(NULL), pendingValue(NULL), m_tableView(NULL),
    m_parameterNameGroupBox(NULL)
{
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);
    SUI::BaseWidget* baseWidget5 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[4]);
    SUI::BaseWidget* baseWidget6 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[5]);
    SUI::BaseWidget* baseWidget7 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[6]);
    parameterName = dynamic_cast<QPushButton*>(baseWidget1->getWidget());
    upArrow = dynamic_cast<QPushButton*>(baseWidget2->getWidget());
    downArrow = dynamic_cast<QPushButton*>(baseWidget3->getWidget());
    upDownArrow = dynamic_cast<QPushButton*>(baseWidget4->getWidget());
    pendingValue = dynamic_cast<QPushButton*>(baseWidget5->getWidget());
    m_tableView= dynamic_cast<QTableView*>(baseWidget6->getWidget());
    m_parameterNameGroupBox= dynamic_cast<QGroupBox*>(baseWidget7->getWidget());
    parameterName->installEventFilter(this);
    upArrow->installEventFilter(this);
    downArrow->installEventFilter(this);
    upDownArrow->installEventFilter(this);
    pendingValue->installEventFilter(this);
    m_parameterNameGroupBox->installEventFilter(this);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mousePressed()
{
    parameterName->setStyleSheet(MOUSE_PRESSED_COLOR_CODE);
    upArrow->setStyleSheet(MOUSE_PRESSED_STYLE);
    downArrow->setStyleSheet(MOUSE_PRESSED_STYLE);
    upDownArrow->setStyleSheet(MOUSE_PRESSED_STYLE);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseReleased()
{
    parameterName->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    upArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
    downArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
    upDownArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseEnter()
{
    parameterName->setStyleSheet(MOUSE_ENTERED_COLOR_CODE);
    upArrow->setStyleSheet(MOUSE_ENTERED_STYLE);
    downArrow->setStyleSheet(MOUSE_ENTERED_STYLE);
    upDownArrow->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::mouseLeft()
{
    parameterName->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    upArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
    downArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
    upDownArrow->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxPendingParameterTableHeaderEventHandler::processMouseWheel(QEvent *event)
{
    QWheelEvent *wheelEvent = dynamic_cast<QWheelEvent*>(event);
    int numDegrees = wheelEvent->delta() / 8;
    int numSteps = numDegrees / 15;
    if (wheelEvent->orientation() == Qt::Vertical) {
        QScrollBar *scrollBar =  m_tableView->verticalScrollBar();
        if (scrollBar->isVisible() && scrollBar->isEnabled()) {
            scrollBar->setValue(scrollBar->value() - numSteps);
        }
    }
    wheelEvent->accept();
}
