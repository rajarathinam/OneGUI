#include "IGSxGUIxHistoryTableHeaderEventHandler.hpp"
#include "IGSxGUIxUtil.hpp"
#include <vector>

const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_ENTERED_COLOR_CODE = "color:#B3E2FF";
const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_RELEASED_COLOR_CODE = "color:#1B3E93";
const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_PRESSED_COLOR_CODE = "color:#FF7F45";
const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_ENTERED_STYLE = "font-family: FontAwesome;font-size:11px;color:#B3E2FF";
const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_RELEASED_STYLE = "font-family: FontAwesome;font-size:11px;color:#1B3E93";
const QString IGSxGUIxHistoryTableHeaderEventHandler::MOUSE_PRESSED_STYLE = "font-family: FontAwesome;font-size:11px;color:#FF7F45";

IGSxGUIxHistoryTableHeaderEventHandler::IGSxGUIxHistoryTableHeaderEventHandler():
    m_parameterNameHistoryHeaderButtonText(NULL),
    m_parameterNameHistoryHeaderButtonImage(NULL),
    m_changedOnHistoryHeaderButtonText(NULL),
    m_changedOnHistoryHeaderButtonImage(NULL),
    m_changedByHistoryHeaderButtonText(NULL),
    m_changedByHistoryHeaderButtonImage(NULL),
    m_reasonHistoryHeaderButtonText(NULL),
    m_reasonHistoryHeaderButtonImage(NULL),
    m_oldValueHistoryHeader(NULL),
    m_newValueHistoryHeader(NULL),
    m_gbxParamNameHistoryHeader(NULL),
    m_gbxChangedOnHistoryHeader(NULL),
    m_gbxChangedByHistoryHeader(NULL),
    m_gbxReasonHistoryHeader(NULL),
    m_parameterNameHistoryHeaderImgBtn(NULL),
    m_changedOnHistoryHeaderImgBtn(NULL),
    m_changedByHistoryHeaderImgBtn(NULL),
    m_reasonHistoryHeaderImgBtn(NULL),
    m_tableWidget(NULL),
    m_scrollBar(NULL)
{
}

void IGSxGUIxHistoryTableHeaderEventHandler::installEvents(std::vector<SUI::Widget*> widgetVector)
{
    m_widgetVector = widgetVector;
    SUI::BaseWidget* baseWidget1 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[0]);
    SUI::BaseWidget* baseWidget2 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[1]);
    SUI::BaseWidget* baseWidget3 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[2]);
    SUI::BaseWidget* baseWidget4 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[3]);
    SUI::BaseWidget* baseWidget5 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[4]);
    SUI::BaseWidget* baseWidget6 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[5]);
    SUI::BaseWidget* baseWidget7 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[6]);
    SUI::BaseWidget* baseWidget8 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[7]);
    SUI::BaseWidget* baseWidget9 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[8]);
    SUI::BaseWidget* baseWidget10 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[9]);
    SUI::BaseWidget* baseWidget11 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[10]);
    SUI::BaseWidget* baseWidget12 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[11]);
    SUI::BaseWidget* baseWidget13 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[12]);
    SUI::BaseWidget* baseWidget14 = dynamic_cast<SUI::BaseWidget*>(m_widgetVector[13]);
    m_parameterNameHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget1->getWidget());
    m_parameterNameHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget2->getWidget());
    m_changedOnHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget3->getWidget());
    m_changedOnHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget4->getWidget());
    m_changedByHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget5->getWidget());
    m_changedByHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget6->getWidget());
    m_reasonHistoryHeaderButtonText = dynamic_cast<QLabel*>(baseWidget7->getWidget());
    m_reasonHistoryHeaderButtonImage = dynamic_cast<QLabel*>(baseWidget8->getWidget());
    m_oldValueHistoryHeader= dynamic_cast<QPushButton*>(baseWidget9->getWidget());
    m_newValueHistoryHeader = dynamic_cast<QPushButton*>(baseWidget10->getWidget());
    m_gbxParamNameHistoryHeader= dynamic_cast<QGroupBox*>(baseWidget11->getWidget());
    m_gbxChangedOnHistoryHeader = dynamic_cast<QGroupBox*>(baseWidget12->getWidget());
    m_gbxChangedByHistoryHeader= dynamic_cast<QGroupBox*>(baseWidget13->getWidget());
    m_gbxReasonHistoryHeader = dynamic_cast<QGroupBox*>(baseWidget14->getWidget());
    m_parameterNameHistoryHeaderButtonText->installEventFilter(this);
    m_parameterNameHistoryHeaderButtonImage->installEventFilter(this);
    m_changedOnHistoryHeaderButtonText->installEventFilter(this);
    m_changedOnHistoryHeaderButtonImage->installEventFilter(this);
    m_changedByHistoryHeaderButtonText->installEventFilter(this);
    m_changedByHistoryHeaderButtonImage->installEventFilter(this);
    m_reasonHistoryHeaderButtonText->installEventFilter(this);
    m_reasonHistoryHeaderButtonImage->installEventFilter(this);
    m_oldValueHistoryHeader->installEventFilter(this);
    m_newValueHistoryHeader->installEventFilter(this);
    m_gbxParamNameHistoryHeader->installEventFilter(this);
    m_gbxChangedOnHistoryHeader->installEventFilter(this);
    m_gbxChangedByHistoryHeader->installEventFilter(this);
    m_gbxReasonHistoryHeader ->installEventFilter(this);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet(MOUSE_PRESSED_COLOR_CODE);
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet(MOUSE_PRESSED_COLOR_CODE);
    m_changedOnHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet(MOUSE_PRESSED_COLOR_CODE);
    m_changedByHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mousePressReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet(MOUSE_PRESSED_COLOR_CODE);
    m_reasonHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_changedOnHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_changedByHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseReleaseReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_reasonHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet(MOUSE_ENTERED_COLOR_CODE);
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet(MOUSE_ENTERED_COLOR_CODE);
    m_changedOnHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet(MOUSE_ENTERED_COLOR_CODE);
    m_changedByHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseEnterReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet(MOUSE_ENTERED_COLOR_CODE);
    m_reasonHistoryHeaderButtonImage->setStyleSheet(MOUSE_ENTERED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftNameHeader()
{
    m_parameterNameHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_parameterNameHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftChangeOnHeader()
{
    m_changedOnHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_changedOnHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftChangeByHeader()
{
    m_changedByHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_changedByHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::mouseLeftReasonHeader()
{
    m_reasonHistoryHeaderButtonText->setStyleSheet(MOUSE_RELEASED_COLOR_CODE);
    m_reasonHistoryHeaderButtonImage->setStyleSheet(MOUSE_RELEASED_STYLE);
}

void IGSxGUIxHistoryTableHeaderEventHandler::setScrollBar(SUI::ScrollBar *scrollBar)
{
    m_scrollBar = scrollBar;
}

void IGSxGUIxHistoryTableHeaderEventHandler::setTableWidget(SUI::TableWidget *tableWidget)
{
    m_tableWidget= tableWidget;
}
