/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysis.cpp
| Author       : Venugopal S
| Description  : Implementation of Analysis plugin
|
| ! \file        IGSxGUIxAnalysis.cpp
| ! \brief       Implementation of Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxAnalysisView.hpp"
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxAlertView.hpp"
#include "IGSxGUIxEventViewerView.hpp"
#include "IGSxGUIxSystemToolsView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Analysis::Analysis():
    m_adtView(NULL),
    m_alertView(NULL),
    m_eventviewer(NULL),
    m_systemToolsView(NULL),
    m_adtManager(new ADTManager()),
    m_alertManager(new AlertManager()),
    m_sysToolManager(new SystemToolsManager())
{
}

IGSxGUI::Analysis::~Analysis()
{
    if (m_adtManager != NULL)
    {
        delete m_adtManager;
        m_adtManager = NULL;
    }
    if (m_alertManager != NULL)
    {
        delete m_alertManager;
        m_alertManager = NULL;
    }
    if (m_sysToolManager != NULL)
    {
        delete m_sysToolManager;
        m_sysToolManager = NULL;
    }
    if (m_eventviewer != NULL)
    {
        delete m_eventviewer;
        m_eventviewer = NULL;
    }
    if (m_adtView != NULL)
    {
        delete m_adtView;
        m_adtView = NULL;
    }
    if (m_alertView != NULL)
    {
        delete m_alertView;
        m_alertView = NULL;
    }
    if (m_systemToolsView != NULL)
    {
        delete m_systemToolsView;
        m_systemToolsView = NULL;
    }
}

void IGSxGUI::Analysis::initialize()
{
    if (m_adtManager != NULL)
    {
        m_adtManager->initialize();
    }
    if (m_alertManager != NULL)
    {
        m_alertManager->initialize();
    }
    if (m_sysToolManager != NULL)
    {
        m_sysToolManager->initialize();
    }
}

void IGSxGUI::Analysis::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    showADT(MainScreenContainer, bIsFirstTimeDisplay);
}
void IGSxGUI::Analysis::showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_alertView != NULL)
    {
        m_alertView->setActive(false);
    }
    if (m_systemToolsView != NULL)
    {
        m_systemToolsView->setActive(false);
    }
    if (m_adtView == NULL)
    {
        m_adtView = new IGSxGUI::ADTView(m_adtManager);
    }

    m_adtView->setActive(true);
    m_adtView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Analysis::showAlert(SUI::Container *MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_adtView != NULL)
    {
        m_adtView->setActive(false);
    }
    if (m_systemToolsView != NULL)
    {
        m_systemToolsView->setActive(false);
    }
    if (m_alertView == NULL)
    {
        m_alertView = new IGSxGUI::AlertView(m_alertManager);
    }

    m_alertView->setActive(true);
    m_alertView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Analysis::setActive(bool bActive)
{
    if (bActive)
    {
        if (m_adtView != NULL)
        {
            m_adtView->setActive(bActive);
        }
        if (m_eventviewer != NULL)
        {
           m_eventviewer->setActive(false);
        }
        if (m_alertView != NULL)
        {
            m_alertView->setActive(false);
        }
        if (m_systemToolsView != NULL)
        {
            m_systemToolsView->setActive(false);
        }
       // It is a specific case, as per the current design,m_analysisView->setActive(false);
       // false - Analysis button click displays ADT Page by default.
    } else {
        if (m_adtView != NULL)
        {
            m_adtView->setActive(bActive);
        }
        if (m_eventviewer != NULL)
        {
            m_eventviewer->setActive(bActive);
        }
        if (m_alertView != NULL)
        {
            m_alertView->setActive(bActive);
        }
        if (m_systemToolsView != NULL)
        {
            m_systemToolsView->setActive(bActive);
        }
    }
}

void IGSxGUI::Analysis::showEventViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_adtView != NULL)
    {
        m_adtView->setActive(false);
    }
    if (m_alertView != NULL)
    {
        m_alertView->setActive(false);
    }
    if (m_eventviewer == NULL)
    {
        m_eventviewer = new  IGSxGUI::EventViewerView();
    }

    m_eventviewer->setActive(true);
    m_eventviewer->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Analysis::showSystemTools(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (m_adtView != NULL)
    {
        m_adtView->setActive(false);
    }
    if (m_alertView != NULL)
    {
        m_alertView->setActive(false);
    }
    if (m_eventviewer != NULL)
    {
        m_eventviewer->setActive(false);
    }
    if (m_systemToolsView == NULL)
    {
        m_systemToolsView = new  IGSxGUI::SystemToolsView(m_sysToolManager);
    }

    m_systemToolsView->setActive(true);
    m_systemToolsView->show(MainScreenContainer, bIsFirstTimeDisplay);
}

void IGSxGUI::Analysis::subscribeForAlertChange(const IGSxGUI::alertUpdatedCallback &cb)
{
    m_connection = m_alertManager->registerToAlertUpdated(cb);
}

void IGSxGUI::Analysis::unsubscribeForAlertChange()
{
    m_connection.disconnect();
}

int IGSxGUI::Analysis::getAlertCount()
{
    return static_cast<int>(m_alertManager->getActiveAlerts().size());
}
