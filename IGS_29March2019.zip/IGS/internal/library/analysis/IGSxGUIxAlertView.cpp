/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert view
|
| ! \file        IGSxGUIxAlertView.cpp
| ! \brief       Implementation of Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxAlertView.hpp"
#include <boost/lexical_cast.hpp>
#include <boost/foreach.hpp>
#include <algorithm>
#include <string>
#include <vector>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUITableWidgetItem.h>
#include <FWQxUtils/SUITimer.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIUserControl.h>
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxMoc_AlertView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AlertView::ALERTVIEW_LOAD_FILE = "IGSxGUIxAlert.xml";
const std::string IGSxGUI::AlertView::STRING_HEADER = "Active alerts";
const std::string IGSxGUI::AlertView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::AlertView::STRING_CLOSE_BRACKET = ")";

const std::string IGSxGUI::AlertView::STRING_ALARM = "Alarm";
const std::string IGSxGUI::AlertView::STRING_ERROR = "Error";
const std::string IGSxGUI::AlertView::STRING_WARNING = "Warning";

const std::string IGSxGUI::AlertView::STRING_SEVERITY = "SEVERITY";
const std::string IGSxGUI::AlertView::STRING_TIMEREPORTED = "TIME REPORTED";
const std::string IGSxGUI::AlertView::STRING_CODE = "CODE";

const std::string IGSxGUI::AlertView::STRING_ALARMS = "Alarms";
const std::string IGSxGUI::AlertView::STRING_ERRORS = "Errors";
const std::string IGSxGUI::AlertView::STRING_WARNINGS = "Warnings";

const std::string IGSxGUI::AlertView::STRING_NEW = "   NEW   ";
const std::string IGSxGUI::AlertView::STRING_NEWLABEL = "newLabel";

const std::string IGSxGUI::AlertView::STYLE_DEFAULT_HEADER = "DefaultHeader";
const std::string IGSxGUI::AlertView::STYLE_SELECTED_HEADER = "SelectedHeader";
const std::string IGSxGUI::AlertView::STRING_ALERTVIEW_SHOWN = "AlertView is shown.";

const int IGSxGUI::AlertView::COLUMN_IMAGE = 0;
const int IGSxGUI::AlertView::COLUMN_SEVERITY = 1;
const int IGSxGUI::AlertView::COLUMN_TIME = 2;
const int IGSxGUI::AlertView::COLUMN_LOGCODE = 3;
const int IGSxGUI::AlertView::COLUMN_MESSAGE = 4;
const int IGSxGUI::AlertView::COLUMN_NEW = 5;
const int IGSxGUI::AlertView::COLUMN_LOGID = 6;

IGSxGUI::AlertView::AlertView(IGSxGUI::AlertManager *pAlertManager) :
    sui(new SUI::AlertView), m_blinktimer(SUI::Timer::createTimer()), m_order(SortOrder::Descending),
    m_column(COLUMN_SEVERITY), alarmcount(0), errorcount(0), warningcount(0)
{
    m_presenter = new AlertPresenter(this, pAlertManager);
}

IGSxGUI::AlertView::~AlertView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::AlertView::show(SUI::Container *MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        const int xposSeverityImage = 68, yposImage = 0, widthImage = 20, heightImage = 30;
        const int xposCodeImage = 40;

        sui->setupSUIContainer(ALERTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
        m_blinktimer->start(1000);

        sui->lblSeverity->setText(STRING_SEVERITY);
        sui->lblTimeReported->setText(STRING_TIMEREPORTED);
        sui->lblCode->setText(STRING_CODE);

        sui->lblSeverityImage->setGeometry(xposSeverityImage, yposImage, widthImage, heightImage);
        sui->lblCodeImage->setGeometry(xposCodeImage, yposImage, widthImage, heightImage);

        sui->uctSeverity->clicked = boost::bind(&AlertView::onSeverityBtnClicked, this);
        sui->uctTimeReported->clicked = boost::bind(&AlertView::onTimeReportedBtnClicked, this);
        sui->uctCode->clicked = boost::bind(&AlertView::onCodeBtnClicked, this);
        m_blinktimer->timeout = boost::bind(&AlertView::onTimeoutBlinkAlarm, this);

        sui->tawAlert->insertRows(sui->tawAlert->rowCount(), 1);
        sui->tawAlert->removeRow(0);
        sui->tawAlert->showGrid(false);

        IGSxGUI::Util::setAwesome(sui->lblalarmsimage, IGSxGUI::AwesomeIcon::AI_fa_exclamation, SUI::ColorEnum::White, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblerrorsimage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::White, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblwarningsimage, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::White, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblTimeReportedImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblCodeImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);

        sui->lblSeverityImage->setVisible(true);
        sui->lblTimeReportedImage->setVisible(true);
        sui->lblCodeImage->setVisible(true);

        IGSxGUI::Util::setScalable(sui->tawAlert);

        std::vector<Alert*> alerts = m_presenter->getActiveAlerts();
        addAlerts(alerts);

        IGSxGUI::Util::sort(COLUMN_TIME, sui->tawAlert, SortOrder::Descending);
        m_order = SortOrder::Ascending;
        sortColumn(COLUMN_SEVERITY, true);
        updateCounts();
        IGS_INFO(STRING_ALERTVIEW_SHOWN);
    }
}

void IGSxGUI::AlertView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
        m_blinktimer->stop();
    }
}

void IGSxGUI::AlertView::updateAlerts(int /*nAlertCount*/, AlertInfo alertInfo)
{
    if (alertInfo.bIsAlertAdded)
    {
        Alert* alert = m_presenter->getAlert(alertInfo.alertId);

        addAlert(alert, addRow());

        if (m_column != COLUMN_TIME)
        {
            IGSxGUI::Util::sort(COLUMN_TIME, sui->tawAlert, SortOrder::Descending);
        }
        // Try to resume the sorting
        sortColumn(m_column, false);
        sortColumn(m_column, false);
        // ToDo fix this, this will probably not perform
    } else {
        removeAlert(alertInfo.alertId);
    }
    updateCounts();
}

int IGSxGUI::AlertView::addRow()
{
    int rowNumber;
    if ((sui->tawAlert->rowCount() == 1) && (!sui->tawAlert->isRowVisible(0)))
    {
        sui->tawAlert->setRowVisible(0, true);
        setNoAlertVisible(false);
        rowNumber = 0;
    } else {
        sui->tawAlert->insertRows(sui->tawAlert->rowCount(), 1);
        rowNumber = (m_order == SortOrder::Descending) ? sui->tawAlert->rowCount() - 1 : 0;
    }
    return rowNumber;
}

void IGSxGUI::AlertView::addAlerts(std::vector<IGSxGUI::Alert *> alerts)
{
    if (alerts.size() <= 0)
    {
        sui->tawAlert->setRowVisible(0, false);
        setNoAlertVisible(true);
    } else {
        sui->tawAlert->setRowVisible(0, true);
        setNoAlertVisible(false);

        if (alerts.size() > 1)
        {
            sui->tawAlert->insertRows(1, static_cast<int>(alerts.size() - 1));
        }

        int rowNumber = 0;
        BOOST_FOREACH(Alert* alert, alerts)
        {
            addAlert(alert, rowNumber);
            ++rowNumber;
        }
    }
}

void IGSxGUI::AlertView::addAlert(Alert *alert, int rowNumber)
{
    if ( (alert != NULL)  &&  (rowNumber >= 0))
    {
        configureRow(alert, rowNumber);

        switch (alert->getSeverity())
        {
            case IGSxERR::AlertSeverity::ALARM:
            {
                IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_exclamation, SUI::ColorEnum::Red, NO_SIZE);
                dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ALARM);
                break;
            }
            case IGSxERR::AlertSeverity::ERROR:
            {
                IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::Red, NO_SIZE);
                dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_ERROR);
                break;
            }
            case IGSxERR::AlertSeverity::WARNING:
            {
                IGSxGUI::Util::setAwesome(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_IMAGE), IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::Yellow, NO_SIZE);
                dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_SEVERITY))->setText(STRING_WARNING);
                break;
            }
            case IGSxERR::AlertSeverity::EVENT:
            default:
            {
                // Ignore events and not known severtities
                break;
            }
        }

        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGCODE))->setText(alert->getLogCode());
        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_MESSAGE))->setText(alert->getDeveloperText());
        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_TIME))->setText(SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, alert->getTime()));

        if (alert->isNew())
        {
            alert->setNew(false);  // It has been shown, so put it to false
            dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setText(STRING_NEW);
            dynamic_cast<SUI::Label*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_NEW))->setStyleSheetClass(STRING_NEWLABEL);
        }

        dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->setText(boost::lexical_cast<std::string>(alert->getLogId()));
    }
}

void IGSxGUI::AlertView::removeAlert(int nAlertId)
{
    if (sui->tawAlert->rowCount() == 1)
    {
        sui->tawAlert->setRowVisible(0, false);
        setNoAlertVisible(true);

    } else {
        for (int rowNumber = 0; rowNumber < sui->tawAlert->rowCount(); rowNumber++)
        {
            if (dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(rowNumber, COLUMN_LOGID))->getText() == boost::lexical_cast<std::string>(nAlertId))
            {
                sui->tawAlert->removeRow(rowNumber);
            }
        }
    }
}

void IGSxGUI::AlertView::onSeverityBtnClicked()
{
    IGSxGUI::Util::sort(COLUMN_TIME, sui->tawAlert, SortOrder::Descending);
    sortColumn(COLUMN_SEVERITY, false);
}

void IGSxGUI::AlertView::onCodeBtnClicked()
{
    IGSxGUI::Util::sort(COLUMN_TIME, sui->tawAlert, SortOrder::Descending);
    sortColumn(COLUMN_LOGCODE, false);
}

void IGSxGUI::AlertView::onTimeReportedBtnClicked()
{
    sortColumn(COLUMN_TIME, false);
}

void IGSxGUI::AlertView::sortColumn(int columnId, bool bIsPageRefreshed)
{
    if (!bIsPageRefreshed)
    {
        if (m_column == columnId)
        {
            m_order = (m_order == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
        } else {
            m_order = SortOrder::Descending;
        }
    }
    m_column = columnId;

    switch (m_column)
    {
        case COLUMN_SEVERITY:
        {
            setTableHeaderStyles(true, false, false, sui->lblSeverityImage);
            break;
        }
        case COLUMN_TIME:
        {
            setTableHeaderStyles(false, true, false, sui->lblTimeReportedImage);
            break;
        }
        case COLUMN_LOGCODE:
        {
            setTableHeaderStyles(false, false, true, sui->lblCodeImage);
            break;
        }
        default:
        {
            break;
        }
    }

    IGSxGUI::Util::sort(m_column, sui->tawAlert, m_order);
}

void IGSxGUI::AlertView::setTableHeaderStyles(bool bSeverityImageVisibility,
                                              bool bTimeImageVisibility,
                                              bool bCodeImageVisibility,
                                              SUI::Widget *widget) const
{
    SortOrder::SortOrderEnum order = m_order;
    if (bSeverityImageVisibility)
    {
        sui->lblSeverity->setStyleSheetClass(STYLE_SELECTED_HEADER);
        sui->lblTimeReported->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        sui->lblCode->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        IGSxGUI::Util::setAwesome(sui->lblTimeReportedImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblCodeImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);

        // For severity the icon should be the other way around
        order = (order == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;

    } else if (bTimeImageVisibility) {
        sui->lblSeverity->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        sui->lblTimeReported->setStyleSheetClass(STYLE_SELECTED_HEADER);
        sui->lblCode->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        IGSxGUI::Util::setAwesome(sui->lblSeverityImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblCodeImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);

    } else if (bCodeImageVisibility) {
        sui->lblSeverity->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        sui->lblTimeReported->setStyleSheetClass(STYLE_DEFAULT_HEADER);
        sui->lblCode->setStyleSheetClass(STYLE_SELECTED_HEADER);
        IGSxGUI::Util::setAwesome(sui->lblSeverityImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblTimeReportedImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, SUI::ColorEnum::Gray, NO_SIZE);
    }

    if (order == SortOrder::Descending) {
        IGSxGUI::Util::setAwesome(widget, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, SUI::ColorEnum::White, NO_SIZE);
    } else {
        IGSxGUI::Util::setAwesome(widget, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, SUI::ColorEnum::White, NO_SIZE);
    }
}

void IGSxGUI::AlertView::updateCounts()
{
    std::vector<Alert*> vec_alerts = m_presenter->getActiveAlerts();
    int vec_size = static_cast<int>(vec_alerts.size());
    sui->lblAlertHeader->setText(STRING_HEADER + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(vec_size) + STRING_CLOSE_BRACKET);
    alarmcount = 0;
    errorcount = 0;
    warningcount = 0;
    for (int i = 0; i < vec_size; ++i)
    {
        switch (vec_alerts[i]->getSeverity())
        {
        case  IGSxERR::AlertSeverity::ALARM:
            ++alarmcount;
            break;
        case   IGSxERR::AlertSeverity::ERROR:
            ++errorcount;
            break;
        case IGSxERR::AlertSeverity::WARNING:
            ++warningcount;
            break;
        default:
            break;
        }
    }
    sui->lblalarms->setText(STRING_ALARMS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(alarmcount) + STRING_CLOSE_BRACKET);
    sui->lblerrors->setText(STRING_ERRORS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(errorcount) + STRING_CLOSE_BRACKET);
    sui->lblwarnings->setText(STRING_WARNINGS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(warningcount) + STRING_CLOSE_BRACKET);
}


void IGSxGUI::AlertView::configureRow(Alert *alert, int row)
{
    for (int i = 0; i < sui->tawAlert->columnCount(); i++)
    {
        if (i != COLUMN_NEW)
        {
           IGSxGUI::Util::setColor(sui->tawAlert->getWidgetItem(row, i), SUI::ColorEnum::White, sui->tawAlert);
        }
    }
    IGSxGUI::Util::addLabel(sui->tawAlert, row, COLUMN_IMAGE);

    if ((alert != NULL)  && alert->isNew())
    {
        IGSxGUI::Util::addLabel(sui->tawAlert, row, COLUMN_NEW);
    }
}

void IGSxGUI::AlertView::setNoAlertVisible(bool visible)
{
    sui->tawAlert->setVisible(!visible);
    sui->lblHeaderBottom->setVisible(!visible);
    sui->uctSeverity->setVisible(!visible);
    sui->uctCode->setVisible(!visible);
    sui->btnMessage->setVisible(!visible);
    sui->uctTimeReported->setVisible(!visible);
    sui->btnNoAlerts->setVisible(visible);
}
void IGSxGUI::AlertView::onTimeoutBlinkAlarm()
{
    if (!m_alarmcolorflag)
    {
        for (int i = 0; i < sui->tawAlert->rowCount(); i++)
        {
            if (dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(i, COLUMN_SEVERITY))->getText() == "Alarm")
            {
                IGSxGUI::Util::setColor(sui->tawAlert->getWidgetItem(i, COLUMN_IMAGE), SUI::ColorEnum::Red, sui->tawAlert);
                IGSxGUI::Util::setColor(sui->tawAlert->getWidgetItem(i, COLUMN_SEVERITY), SUI::ColorEnum::Red, sui->tawAlert);
            }
        }
        m_alarmcolorflag = true;
    } else {
        for (int i = 0; i < sui->tawAlert->rowCount(); i++)
        {
            if (dynamic_cast<SUI::TableWidgetItem*>(sui->tawAlert->getWidgetItem(i, COLUMN_SEVERITY))->getText() == "Alarm")
            {
                IGSxGUI::Util::setColor(sui->tawAlert->getWidgetItem(i, COLUMN_IMAGE), SUI::ColorEnum::White, sui->tawAlert);
                IGSxGUI::Util::setColor(sui->tawAlert->getWidgetItem(i, COLUMN_SEVERITY), SUI::ColorEnum::White, sui->tawAlert);
            }
        }
        m_alarmcolorflag = false;
    }
}

