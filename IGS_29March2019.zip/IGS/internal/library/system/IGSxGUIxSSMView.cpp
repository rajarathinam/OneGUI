/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMView.cpp
| Author       : Saket K
| Description  : Implementation of SSM view
|
| ! \file        IGSxGUIxSSMView.cpp
| ! \brief       Implementation of SSM view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIDialog.h>

#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/regex.hpp>
#include <string>
#include "IGSxGUIxISSMView.hpp"
#include "IGSxGUIxSSMView.hpp"
#include "IGSxGUIxSSMTabView.hpp"

#include "IGSxGUIxMoc_SSMView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUITabPage.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxCore/SUIResourcePath.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const std::string CONSTANT_AMPERRSAND = "&";
const std::string CONSTANT_DOUBLE_AMPERRSAND = "&&";

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::SSMView::SYSTEMSTATEMANAGER_VIEW_LOAD_FILE = "IGSxGUIxSSMBase.xml";

IGSxGUI::SSMView::SSMView(SSMManager& ssmManager):
    sui(new SUI::SSMView),
    m_SSMManager(ssmManager),
    currentContainer(NULL),
    m_Tab1(new IGSxGUI::SSMTabView(ssmManager, TAB_1)),
    m_Tab2(new IGSxGUI::SSMTabView(ssmManager, TAB_2)),
    m_Tab3(new IGSxGUI::SSMTabView(ssmManager, TAB_3)),
    m_Tab4(new IGSxGUI::SSMTabView(ssmManager, TAB_4)),
    m_Tab5(new IGSxGUI::SSMTabView(ssmManager, TAB_5)),
    m_Tab6(new IGSxGUI::SSMTabView(ssmManager, TAB_6)),
    m_currentTab(TAB_1),
    m_IsSSMScreenDisplayed(false)
{
    m_SSMManager.registerToUpdate(boost::bind(&IGSxGUI::SSMView::update, this, _1));
    m_SSMManager.registerToUpdateTabIcon(boost::bind(&IGSxGUI::SSMView::setTabIcon, this));
    m_SSMManager.registerToStartTransition(boost::bind(&IGSxGUI::SSMView::startTransition, this, _1));
}

void IGSxGUI::SSMView::setActive(bool bActive)
{
    m_Active = bActive;
}

void IGSxGUI::SSMView::indexChanged(int index)
{
    TabType currentTab = static_cast<TabType>(index);
    m_currentTab = currentTab;
    getStateOnTab(m_currentTab);
    showTab(m_currentTab);
}

void IGSxGUI::SSMView::showTab(TabType tab)
{
    m_currentTab = tab;
    switch(tab)
    {
    case TAB_1:
        m_Tab1->show(containers[m_currentTab], true);
        break;
    case TAB_2:
        m_Tab2->show(containers[m_currentTab], true);
        break;
    case TAB_3:
        m_Tab3->show(containers[m_currentTab], true);
        break;
    case TAB_4:
        m_Tab4->show(containers[m_currentTab], true);
        break;
    case TAB_5:
        m_Tab5->show(containers[m_currentTab], true);
        break;
    case TAB_6:
        m_Tab6->show(containers[m_currentTab], true);
        break;
    default:
        break;
    }
}

void IGSxGUI::SSMView::getStateOnTab(TabType tab)
{
    switch (tab) {
    case TAB_1:
        m_Tab1->getState();
        break;
    case TAB_2:
        m_Tab2->getState();
        break;
    case TAB_3:
        m_Tab3->getState();
        break;
    case TAB_4:
        m_Tab4->getState();
        break;
    case TAB_5:
        m_Tab5->getState();
        break;
    case TAB_6:
        m_Tab6->getState();
        break;
    default:
        break;
    }
}

IGSxGUI::SSMView::~SSMView()
{
    delete m_Tab6;
    m_Tab6 = NULL;

    delete m_Tab5;
    m_Tab5 = NULL;

    delete m_Tab4;
    m_Tab4 = NULL;

    delete m_Tab3;
    m_Tab3 = NULL;

    delete m_Tab2;
    m_Tab2 = NULL;

    delete m_Tab1;
    m_Tab1 = NULL;
}
void IGSxGUI::SSMView::init()
{
    getStateOnTab(TAB_1);
    showTab(TAB_6);
    showTab(TAB_5);
    showTab(TAB_4);
    showTab(TAB_3);
    showTab(TAB_2);
    showTab(TAB_1);
}

void IGSxGUI::SSMView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (bIsFirstTimeDisplay){
        sui->setupSUIContainer(SYSTEMSTATEMANAGER_VIEW_LOAD_FILE.c_str(), MainScreenContainer);

        for(int functionIndex = 0 ; functionIndex < m_SSMManager.getFunctionCount(); ++functionIndex)
        {
            std::string strFunctionName = m_SSMManager.getFunctionName(functionIndex);
            boost::replace_all(strFunctionName, CONSTANT_AMPERRSAND, CONSTANT_DOUBLE_AMPERRSAND);
            sui->tabWidget->getTabPage(functionIndex)->setTabText(strFunctionName);
        }

        sui->tabWidget->currentIndexChanged = boost::bind(&SSMView::indexChanged, this, _1);
        refreshContainers();
        setTabIcon();
        init();

        m_IsSSMScreenDisplayed = true;
    }
}

void IGSxGUI::SSMView::refreshContainers()
{
    containers.clear();
    containers.push_back(sui->container1);
    containers.push_back(sui->container2);
    containers.push_back(sui->container3);
    containers.push_back(sui->container4);
    containers.push_back(sui->container5);
    containers.push_back(sui->container6);
}

void IGSxGUI::SSMView::update(int functionIndex)
{
    if (m_IsSSMScreenDisplayed)
    {
        setTabIcon();
        showTab(static_cast<TabType>(functionIndex));
    }
}

void IGSxGUI::SSMView::setTabIcon()
{
    for(int functionIndex = 0 ; functionIndex < m_SSMManager.getFunctionCount(); ++functionIndex)
    {
        SUI::TabPage* page = sui->tabWidget->getTabPage(functionIndex);
        std::string iconPath;

        if(m_SSMManager.isTransitionActive(functionIndex))
        {
            iconPath = ":/new/icons/transitionAnimation.gif";
        }
        else if(m_SSMManager.isFunctionResultOk(functionIndex) == true)
        {
            iconPath = ":/new/icons/empty.png";
        }
        else
        {
            iconPath = ":/new/icons/transitionError.gif";
        }

        page->setTabIcon(iconPath, true);
    }
}

void IGSxGUI::SSMView::startTransition(const int functionIndex)
{
    if (m_IsSSMScreenDisplayed){
        switch (functionIndex) {
        case TAB_1:
            m_Tab1->startTransition();
            break;
        case TAB_2:
            m_Tab2->startTransition();
            break;
        case TAB_3:
            m_Tab3->startTransition();
            break;
        case TAB_4:
            m_Tab4->startTransition();
            break;
        case TAB_5:
           m_Tab5->startTransition();
            break;
        case TAB_6:
            m_Tab6->startTransition();
            break;
        default:
            break;
        }
    }
}
