/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMManager.cpp
| Author       : Saket K
| Description  : CPD manager Implementation
|
| ! \file        IGSxGUIxSSMManager.cpp
| ! \brief       SSM Manager Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSSMManager.hpp"
#include "IGSxLOG.hpp"
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <algorithm>

using namespace IGSxSSM;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int CONSTANT_ZERO = 0;
const std::string IGSxGUI::SSMManager::SSM_STATE_TRANSITIONING = "TRANSITIONING";
const std::string IGSxGUI::SSMManager::SSM_STATE_UNKNOWN = "UNKNOWN";
const std::string IGSxGUI::SSMManager::SSM_STATE_SERVICE = "SERVICE";

IGSxGUI::SSMManager::SSMManager()
    : m_Functions(),
      m_Groups(),
      m_Transitions(),
      m_TransitionCount(CONSTANT_ZERO),
      m_activeSystemStateName(SSM_STATE_SERVICE)
{
}

IGSxGUI::SSMManager::~SSMManager()
{
    if (allowStateManagement())
    {
        for(int functionIndex = 0 ; functionIndex < getFunctionCount(); ++functionIndex)
        {
            m_Functions[functionIndex]->unsubscribeGetStateResult();
            m_Functions[functionIndex]->unsubscribeSetStateResult();
            m_Functions[functionIndex]->unsubscribeStateUpdated();
            m_Functions[functionIndex]->unsubscribeTransitionCompleted();
            m_Functions[functionIndex]->unsubscribeTransitionStarted();
        }
    }
}

void IGSxGUI::SSMManager::initialize()
{
    m_Groups.clear();
    m_States.clear();
    m_Transitions.clear();

    m_Functions = m_Instance->functions();


    m_Transitions.assign(6, TransitionData());


    for(int functionIndex = 0 ; functionIndex < getFunctionCount(); ++functionIndex)
    {
      m_Functions[functionIndex]->subscribeGetStateResult(boost::bind(&IGSxGUI::SSMManager::onGetStateResultFunction, this, _1, _2, _3, _4, functionIndex));
      m_Functions[functionIndex]->subscribeSetStateResult(boost::bind(&IGSxGUI::SSMManager::onSetStateResultFunction, this, _1, functionIndex));
      m_Functions[functionIndex]->subscribeStateUpdated(boost::bind(&IGSxGUI::SSMManager::onSetStateUpdatedFunction, this, functionIndex));
      m_Functions[functionIndex]->subscribeTransitionStarted(boost::bind(&IGSxGUI::SSMManager::onSetTransitionStartedFunction, this, _1, _2, _3, functionIndex));
      m_Functions[functionIndex]->subscribeTransitionCompleted(boost::bind(&IGSxGUI::SSMManager::onSetTransitionCompletedFunction, this, _1, _2, _3, _4, functionIndex));

      GroupConfigList groups = m_Functions[functionIndex]->config().groups();
      m_Groups.push_back(groups);
      
      StatesList list;
      m_States.push_back(list);
      
      for(int groupIndex = 0 ; groupIndex < getGroupCount(functionIndex); ++groupIndex)
      {
         m_States[functionIndex].push_back(groups[groupIndex].states());
      }
    }
}

int IGSxGUI::SSMManager::getFunctionCount() const
{
    return static_cast<int>(m_Functions.size());
}

int IGSxGUI::SSMManager::getGroupCount(const int functionIndex) const
{
    return static_cast<int>(m_Groups[functionIndex].size());
}

int IGSxGUI::SSMManager::getStatesCount(const int functionIndex, const int groupIndex) const
{
    return static_cast<int>(m_States[functionIndex][groupIndex].size());
}

IGSxGUI::TransitionData IGSxGUI::SSMManager::getActiveTransitionData(const int functionIndex) const
{
    return  m_Transitions[functionIndex];
}

void IGSxGUI::SSMManager::getActiveTransition(const int functionIndex) const
{
    m_Functions[functionIndex]->get_state();
    IGS_INFO("get_state() - " + boost::lexical_cast<std::string>(functionIndex));
}

bool IGSxGUI::SSMManager::isTransitionAbortable(const int functionIndex, const int stateId) const
{
    bool abortable = false;
    TransitionData currentTransition = m_Transitions[functionIndex];
    IGSxSSM::ReachableStateList::const_iterator end = currentTransition.ReachableStates.end() ;

    for(IGSxSSM::ReachableStateList::const_iterator it= currentTransition.ReachableStates.begin(); it!= end ; ++it )
    {
        if ((*it).state() == static_cast<StateIDType>(stateId))
        {
            abortable = (*it).can_be_aborted();
            break;
        }
    }
    return abortable;

}

void IGSxGUI::SSMManager::setTransition(const int functionIndex, const int newStateId)
{
    SystemFunctionPtr functionType =  m_Functions[functionIndex];

    functionType->set_state(static_cast<StateIDType>(newStateId));
    IGS_INFO("set_state() - " + boost::lexical_cast<std::string>(functionIndex) + boost::lexical_cast<std::string>(newStateId));
}

IGSxGUI::InnerState IGSxGUI::SSMManager::getInnerState(const int functionIndex, const int stateId) const
{
    IGSxGUI::InnerState currentState = DISABLED;
    TransitionData currentTransition = m_Transitions[functionIndex];

    if(currentTransition.FunctionResult == FUNCTION_ERROR || currentTransition.TransitionResult == TRANSITION_ERROR)
    {
        // Current state will be disabled.
    }
    else if ( (currentTransition.From == currentTransition.To) && (currentTransition.To == stateId) ) //If both transition Ids (from, to) are same then it is an active state.
    {
        currentState = ACTIVE;
    }
    else if((currentTransition.From == stateId))
    {
        currentState = TRANSITION_START;
    }
    else if((currentTransition.To == stateId))
    {
        currentState = TRANSITION_END;
    }
    else if ( (currentTransition.From != currentTransition.To) && (currentTransition.To != stateId) && (currentTransition.From != stateId) ) //If both transition Ids (from, to) are same then it is an active state.
    {
        currentState = DISABLED;
    }
    else if(isStateReachable(functionIndex, stateId))
    {
         currentState = REACHABLE;
    }
    return currentState;
}

bool IGSxGUI::SSMManager::isStateReachable(int functionIndex, int stateId) const
{
    bool isReachable = false;
    TransitionData currentTransition = m_Transitions[functionIndex];
    IGSxSSM::ReachableStateList::const_iterator end = currentTransition.ReachableStates.end() ;
    for(IGSxSSM::ReachableStateList::const_iterator it= currentTransition.ReachableStates.begin(); it!= end ; ++it )
    {
        if ((*it).state() == (static_cast<StateIDType>(stateId)))
        {
            isReachable = true;
            break;
        }
    }
    return isReachable;
}

bool IGSxGUI::SSMManager::isTransitionActive(const int functionIndex) const
{
    return m_Transitions[functionIndex].From != m_Transitions[functionIndex].To;
}

void IGSxGUI::SSMManager::onGetStateResultFunction(const FunctionResultType &result, const StateIDType &from, const StateIDType &to, const ReachableStateList &reachable_states , const int functionIndex)
{
   IGS_INFO("onGetStateResultFunction. From: " + boost::lexical_cast<std::string>(from) + " To: " + boost::lexical_cast<std::string>(to));
   m_Transitions[functionIndex].From = from;
   m_Transitions[functionIndex].To = to;
   if (!isTransitionActive(functionIndex)){
      m_Transitions[functionIndex].ReachableStates = reachable_states;
      m_Transitions[functionIndex].FunctionResult = result;
      callbackUpdate(functionIndex);
   
      // callback to top bar START
      if (functionIndex == CONSTANT_ZERO) {
           if (m_Transitions[functionIndex].FunctionResult == FUNCTION_ERROR) {
               m_activeSystemStateName = SSM_STATE_UNKNOWN;
               m_ssmStateChanged(SSM_STATE_UNKNOWN);
           } else {
               StateDescriptionType StateDescription = getStateDescriptionById(functionIndex, to);
               std::string stateName = StateDescription.at(0);
               for (size_t i = 1; i < StateDescription.size(); ++i) {
                   if (!StateDescription.at(i).empty()) {
                       stateName = stateName + " " + StateDescription.at(i);
                   }
               }
               m_activeSystemStateName = stateName;
               m_ssmStateChanged(stateName);
           }
      }
      // callback to top bar END
          
      //Logging Reachable and abortable states - Start
       std::string stateinfo = "functionIndex: ";
       stateinfo += boost::lexical_cast<std::string>(functionIndex);
       if(m_Transitions[functionIndex].FunctionResult == FUNCTION_ERROR){
          stateinfo += " FUNCTION_ERROR ";
       }else{
          stateinfo += " FUNCTION_OK ";
       }
       stateinfo += " Reachable States: ";
       IGSxSSM::ReachableStateList::const_iterator end = m_Transitions[functionIndex].ReachableStates.end() ;
       for(IGSxSSM::ReachableStateList::const_iterator it= m_Transitions[functionIndex].ReachableStates.begin(); it!= end ; ++it )
       {
           stateinfo += boost::lexical_cast<std::string>((*it).state());
           stateinfo += ":" ;
           if ((*it).can_be_aborted() == true){
               stateinfo += "A, " ;
           }
           else
           {
               stateinfo += "NA, " ;
           }
       }
       IGS_INFO("onGetStateResultFunction - " + stateinfo);
       //Logging Reachable and abortable states - End
   }
}

void IGSxGUI::SSMManager::onSetStateResultFunction(const FunctionResultType &result, const int functionIndex)
{
    IGS_INFO("onSetStateResultFunction");
    m_Transitions[functionIndex].FunctionResult = result;
    callbackUpdate(functionIndex);
}

void IGSxGUI::SSMManager::onSetStateUpdatedFunction(const int functionIndex)
{
   IGS_INFO("onSetStateUpdatedFunction. Index: " + boost::lexical_cast<std::string>(functionIndex));
   getActiveTransition(functionIndex);      
   callbackUpdate(functionIndex);
}

void IGSxGUI::SSMManager::onSetTransitionStartedFunction(const StateIDType &from, const StateIDType &to, const unsigned int duration, const int functionIndex)
{
    IGS_INFO("onSetTransitionStartedFunction");

    m_Transitions[functionIndex].From = from;
    m_Transitions[functionIndex].To = to;
    m_Transitions[functionIndex].ExpectedDuration = duration*1000;
    m_enableInitButton(false);//Disable the INIT button if the state transition is getting started
    ++m_TransitionCount;
    m_StartTransition(functionIndex);
    callbackUpdate(functionIndex);
    // MSL needs to be updated whenever an SFC sends a transitionStarted or -Completed event
    if(functionIndex != CONSTANT_ZERO)
    {
       // State update event is sent by an SFC. Update Source Machine Control also.
       getActiveTransition(CONSTANT_ZERO);
       callbackUpdate(CONSTANT_ZERO);
    }

    // callback to top bar START
    if (functionIndex == CONSTANT_ZERO) {
        m_ssmStateChanged(SSM_STATE_TRANSITIONING);
    }
    // callback to top bar END
}

void IGSxGUI::SSMManager::onSetTransitionCompletedFunction(const StateIDType &from, const StateIDType &to, const TransitionResultType &result, const ReachableStateList &reachable_states, const int functionIndex)
{
   IGS_INFO("onSetTransitionCompletedFunction. From: " + boost::lexical_cast<std::string>(from) + " To: " + boost::lexical_cast<std::string>(to));
    m_Transitions[functionIndex].TransitionResult = result;
    m_Transitions[functionIndex].From = from;
    m_Transitions[functionIndex].To = to;
    m_Transitions[functionIndex].ReachableStates = reachable_states;
    callbackUpdate(functionIndex);
    --m_TransitionCount;
    if (m_TransitionCount <= CONSTANT_ZERO)
    {
        m_enableInitButton(true);
        m_TransitionCount = CONSTANT_ZERO;
    }
    getActiveTransition(functionIndex);
    // MSL needs to be updated whenever an SFC sends a transitionStarted or -Completed event
    if(functionIndex != CONSTANT_ZERO)
    {
       // State update event is sent by an SFC. Update Source Machine Control also.
       getActiveTransition(CONSTANT_ZERO);
       callbackUpdate(CONSTANT_ZERO);
    }

    // callback to top bar START
    if (functionIndex == CONSTANT_ZERO) {
        if (m_Transitions[functionIndex].TransitionResult == TRANSITION_ERROR) {
            m_activeSystemStateName = SSM_STATE_UNKNOWN;
            m_ssmStateChanged(SSM_STATE_UNKNOWN);
        } else {
            StateDescriptionType StateDescription = getStateDescriptionById(functionIndex, to);
            std::string stateName = StateDescription.at(0);
            for (size_t i = 1; i < StateDescription.size(); ++i) {
                if (!StateDescription.at(i).empty()) {
                    stateName = stateName + " " + StateDescription.at(i);
                }
            }
            m_activeSystemStateName = stateName;
            m_ssmStateChanged(stateName);
        }
    }
    // callback to top bar END

    //Logging Reachable and abortable states - Start
    std::string stateinfo = "functionIndex: ";
    stateinfo += boost::lexical_cast<std::string>(functionIndex);
    stateinfo += " Reachable States: ";
    IGSxSSM::ReachableStateList::const_iterator end = m_Transitions[functionIndex].ReachableStates.end() ;
    for(IGSxSSM::ReachableStateList::const_iterator it= m_Transitions[functionIndex].ReachableStates.begin(); it!= end ; ++it )
    {
        stateinfo += boost::lexical_cast<std::string>((*it).state());
        stateinfo += ":" ;
        if ((*it).can_be_aborted() == true){
            stateinfo += "A, " ;
        }
        else
        {
            stateinfo += "NA, " ;
        }
    }
    IGS_INFO("onGetStateResultFunction - " + stateinfo);
    //Logging Reachable and abortable states - End
}

void IGSxGUI::SSMManager::registerToSSMStateChanged(const ssmStateChangedCallback& cb)
{
    m_ssmStateChanged.connect(cb);
}

void IGSxGUI::SSMManager::unregisterToSSMStateChanged(const ssmStateChangedCallback& cb)
{
    m_ssmStateChanged.disconnect(&cb);
}

std::string IGSxGUI::SSMManager::getActiveStateName()
{
    return m_activeSystemStateName;
}

bool IGSxGUI::SSMManager::isFunctionResultOk(const int functionIndex) const
{
    bool result = true;
    if(m_Transitions[functionIndex].TransitionResult == IGSxSSM::TRANSITION_ERROR || m_Transitions[functionIndex].FunctionResult == IGSxSSM::FUNCTION_ERROR)
    {
        result = false;
    }
    return result;
}

std::string IGSxGUI::SSMManager::getFunctionName(const int functionIndex) const
{
   SystemFunctionPtr functionType =  m_Functions[functionIndex];
   SystemFunctionConfigType configType = functionType->config();
   return configType.description();
}

std::string IGSxGUI::SSMManager::getGroupName(const int functionIndex, const int groupIndex) const
{
    GroupConfigList group = m_Groups[functionIndex];
    return group[groupIndex].description();
}

IGSxGUI::StateDescriptionType IGSxGUI::SSMManager::getStateDescription(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].description();
}

IGSxGUI::StateDescriptionType IGSxGUI::SSMManager::getStateDescriptionById(const int functionIndex, const StateIDType& stateIdType) const
{
    IGSxGUI::StateDescriptionType desc;
    for(int groupIndex = 0 ; groupIndex < getGroupCount(functionIndex); ++groupIndex)
    {
        StateConfigList state = m_States[functionIndex][groupIndex];
        for(size_t stateIndex = 0 ; stateIndex < state.size(); ++stateIndex)
        {
            StateConfigType currentStateType = state[stateIndex];
            if (stateIdType == currentStateType.id())
            {
               desc = currentStateType.description();
               break;
            }
        }
    }
    return desc;
}

int IGSxGUI::SSMManager::getStateId(const int functionIndex, const int groupIndex, const int stateIndex) const
{
    StateConfigList state = m_States[functionIndex][groupIndex];
    return state[stateIndex].id();
}

bool IGSxGUI::SSMManager::allowStateManagement()
{
   bool allow = IGSxSSM::SSM::showStateManagement();
   if(allow) 
   {
      m_Instance = IGSxSSM::SSM::GetInstance();
   }
   return allow;
}

void IGSxGUI::SSMManager::registerToUpdate(const signalUpdateCallback& cb)
{
    m_Update.connect(cb);
}

void IGSxGUI::SSMManager::callbackUpdate(int functionIndex)
{
    if (!m_Update.empty())
    {
        m_Update(functionIndex);
    }
}

void IGSxGUI::SSMManager::registerToUpdateTabIcon(const controlSignalCallback& cb)
{
    m_UpdateTabIcon.connect(cb);
}

void IGSxGUI::SSMManager::callbackUpdateTabIcon()
{
    if (!m_UpdateTabIcon.empty())
    {
        m_UpdateTabIcon();
    }
}

void IGSxGUI::SSMManager::registerInitForEnable(const enableButtonSignalCallback& cb)
{
    m_enableInitButton.connect(cb);
}

void IGSxGUI::SSMManager::registerToStartTransition(const signalStartTransitionCallback& cb)
{
    m_StartTransition.connect(cb);
}
