/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin view
|
| ! \file        IGSxGUIxSystemView.cpp
| ! \brief       Implementation of System plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemView.hpp"
#include <boost/lexical_cast.hpp>
#include <boost/assign.hpp>
#include <string>
#include <algorithm>
#include <map>
#include <utility>
#include <vector>
#include <functional>
#include "IGSxGUIxMoc_SystemView.hpp"
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIProgressBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUITreeWidget.h>
#include <FWQxUtils/SUITimer.h>
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SystemView::SYSTEMVIEW_LOAD_FILE = "IGSxGUIxSystemView.xml";
const std::string IGSxGUI::SystemView::POPUP_LOAD_FILE = "IGSxGUIxPopup.xml";

const std::string IGSxGUI::SystemView::STRING_DRIVERS = " DRIVERS";
const std::string IGSxGUI::SystemView::STRING_INFORMATION = " INFORMATION";
const std::string IGSxGUI::SystemView::STRING_SEPERATOR = ">>  ";
const std::string IGSxGUI::SystemView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::SystemView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::SystemView::STRING_SLASH = "/";
const std::string IGSxGUI::SystemView::STRING_SINGLE_SPACE = " ";
const std::string IGSxGUI::SystemView::STRING_COLON = ":";
const std::string IGSxGUI::SystemView::STRING_ZERO = "0";
const std::string IGSxGUI::SystemView::STRING_EMPTY = "";
const std::string IGSxGUI::SystemView::STRING_INIT_PRESSED = "Initialize button pressed.";
const std::string IGSxGUI::SystemView::STRING_TERMINATE_PRESSED = "Terminate button pressed.";
const std::string IGSxGUI::SystemView::STRING_SYSTEMVIEW_SHOWN = "SystemView is shown.";
const std::string IGSxGUI::SystemView::STRING_CPD_ACTIVE = "CPD active";
const std::string IGSxGUI::SystemView::STRING_SCANNER_INCONTROL = "Scanner in control";

const std::string IGSxGUI::SystemView::STYLECLASS_DEFAULT = "default";
const std::string IGSxGUI::SystemView::STYLECLASS_DEFAULT_SMALL = "defaultSmall";
const std::string IGSxGUI::SystemView::STYLECLASS_SELECTED = "selected";
const std::string IGSxGUI::SystemView::STYLECLASS_SELECTED_SMALL = "selectedSmall";
const std::string IGSxGUI::SystemView::NORMALSTYLE = "normal";
const std::string IGSxGUI::SystemView::DRIVERNAME_DEFAULT = "default";
const std::string IGSxGUI::SystemView::DRIVERSTATUS_DEFAULT_SMALL = "defaultSmall";

const std::string IGSxGUI::SystemView::DIALOG_TITLE_INITIALIZE = "Initialize all drivers?";
const std::string IGSxGUI::SystemView::DIALOG_TITLE_TERMINATE = "Terminate all drivers?";
const std::string IGSxGUI::SystemView::DIALOG_MESSAGE_INITIALIZE = "";
const std::string IGSxGUI::SystemView::DIALOG_MESSAGE_TERMINATE = "";
const std::string IGSxGUI::SystemView::DIALOG_OKBUTTON_INITIALIZE = "Initialize";
const std::string IGSxGUI::SystemView::DIALOG_OKBUTTON_TERMINATE = "Terminate";
const std::string IGSxGUI::SystemView::DIALOG_CANCELBUTTON = "Cancel";

const std::string IGSxGUI::SystemView::DIALOG_ID_TITLE = "lblTitle";
const std::string IGSxGUI::SystemView::DIALOG_ID_MESSAGE = "lblMessage";
const std::string IGSxGUI::SystemView::DIALOG_ID_OKBUTTON = "btnOk";
const std::string IGSxGUI::SystemView::DIALOG_ID_CANCELBUTTON = "btnCancel";

const std::string IGSxGUI::SystemView::COLOR_ASML_GREEN = "#38B14A";
const std::string IGSxGUI::SystemView::COLOR_ASML_RED = "#FF0000";
const std::string IGSxGUI::SystemView::COLOR_ASML_WHITE = "#FFFFFF";
const int IGSxGUI::SystemView::SYSTEM_STATUS_ICON_SIZE = 18;

const std::string IGSxGUI::SystemView::DRIVER_HOVER_ON = "gbxDriverHoverOn";
const std::string IGSxGUI::SystemView::DRIVER_HOVER_OFF = "gbxDriverHoverOff";
const std::string IGSxGUI::SystemView::LAST_DRIVER_HOVER_OFF = "gbxLastDriverHoverOff";
const std::string IGSxGUI::SystemView::LAST_DRIVER_HOVER_ON = "gbxLastDriverHoverOn";
const std::string IGSxGUI::SystemView::LAST_SYSFUN_LAST_DRIVER_HOVER_OFF = "gbxLastSysFunLastDriverHoverOff";
const std::string IGSxGUI::SystemView::LAST_SYSFUN_LAST_DRIVER_HOVER_ON = "gbxLastSysFunLastDriverHoverOn";

const std::string IGSxGUI::SystemView::SYSFUN_HOVER_ON = "gbxHoverOnSysFun";
const std::string IGSxGUI::SystemView::SYSFUN_HOVER_OFF = "gbxHoverOffSysFun";
const std::string IGSxGUI::SystemView::SYSFUN_HOVER_ON_EXPANDED = "gbxSysFunHoverOnExpanded";
const std::string IGSxGUI::SystemView::SYSFUN_HOVER_OFF_EXPANDED = "gbxSysFunHoverOffExpanded";
const std::string IGSxGUI::SystemView::SYSFUN_EXPANDED_SELECTED = "gbxSysFunExpandedSelected";

const std::string IGSxGUI::SystemView::SYSFUN_COLLAPSED_BRANCH_ICON_COLOR = "#FFFFFF";
const std::string IGSxGUI::SystemView::SYSFUN_EXPANDED_BRANCH_ICON_COLOR_UNSELECTED = "#FFFFFF";
const std::string IGSxGUI::SystemView::SYSFUN_EXPANDED_BRANCH_ICON_COLOR_SELECTED = "#1B3E93";
const int IGSxGUI::SystemView::SYSFUN_BRANCH_ICON_SIZE = 18;

const int IGSxGUI::SystemView::DIALOG_X = 0;
const int IGSxGUI::SystemView::DIALOG_Y = 65;
const int IGSxGUI::SystemView::DIALOG_ALERT_Y = 114;
const int IGSxGUI::SystemView::DIALOG_WIDTH = 1920;
const int IGSxGUI::SystemView::DIALOG_HEIGHT = 130;

const int IGSxGUI::SystemView::SYSTEM_TIMER_INTERVAL = 1000;
const unsigned int IGSxGUI::SystemView::CONSTANT_ZERO = 0;
const unsigned int IGSxGUI::SystemView::CONSTANT_ONE = 1;
const unsigned int IGSxGUI::SystemView::CONSTANT_TWO = 2;
const unsigned int IGSxGUI::SystemView::CONSTANT_THREE = 3;
const unsigned int IGSxGUI::SystemView::CONSTANT_FOUR = 4;
const unsigned int IGSxGUI::SystemView::CONSTANT_FIVE = 5;
const unsigned int IGSxGUI::SystemView::CONSTANT_SIX = 6;
const unsigned int IGSxGUI::SystemView::CONSTANT_SEVEN = 7;
const int IGSxGUI::SystemView::CONSTANT_TWENTY = 20;
const int IGSxGUI::SystemView::CONSTANT_SIXTY = 60;
const std::string IGSxGUI::SystemView::STYLE_DISABLE_BUTTON = "disableInitButton";
std::vector<std::string> IGSxGUI::SystemView::m_sysFunStates = boost::assign::list_of("Terminating...")("Terminated")("Initializing...")("Initialized")("Recovery required")("Partially Initialized");
std::vector<std::string> IGSxGUI::SystemView::m_driverStates = boost::assign::list_of("Terminating...")("Terminated")("Initializing...")("Initialized")("Recovery required");

IGSxGUI::SystemView::SystemView(DriverManager* pDriverManager) :
    sui(new SUI::SystemView),
    m_lastClickedSysFunIndex(-1),
    m_lastClickedDriverIndex(-1),
    m_sysFunIndexForLastClickedDriver(-1),
    m_timer(SUI::Timer::createTimer()),
    m_startTime(time(NULL)),
    m_totaldrivercount(0),
    m_bSystemViewActive(false),
    m_displayStates(true),
    m_bAlertPopupRaised(false),
    m_whoIsInControl(IGSxCTRL::Who::NONE)
{
    m_presenter = new SystemPresenter(this, pDriverManager);

    m_timer->setSingleShot(true);
    m_timer->setInterval(SYSTEM_TIMER_INTERVAL);

    m_timer->timeout = boost::bind(&SystemView::onTimerTimeout, this);
    m_dialog = SUI::UILoader::loadUI(POPUP_LOAD_FILE.c_str());
    m_bEnableInitButton = true;
}

IGSxGUI::SystemView::~SystemView()
{
    m_timer->stop();

    // Do not delete the content, we are not the owner:
    m_listSysFunctions.clear();
    m_listDrivers.clear();
    m_listSystemFunctionUCT.clear();
    m_listSystemFunctionGroupBox.clear();

    m_listSystemFunctionNameLabels.clear();
    m_listSystemFunctionSignalIcons.clear();
    m_listSystemFunctionSimButtons.clear();
    m_listSystemFunctionBranchIcons.clear();
    m_listSystemFunctionStatusLabels.clear();
    m_listSystemFunctionProgressBar.clear();

    driverUC.clear();
    driverGroupBox.clear();
    driverName.clear();
    driverSignalIcon.clear();
    driverStatus.clear();
    driverBIProgress.clear();
    driverBIRegress.clear();

    driverSim.clear();

    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }

    // Do not delete:
    // m_lastDriverPressed
    // m_lastSysFunctionPressed
}

void IGSxGUI::SystemView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (bIsFirstTimeDisplay) {
        m_listSysFunctions = m_presenter->getSystemFunctions();

        sui->setupSUIContainer(SYSTEMVIEW_LOAD_FILE.c_str(), MainScreenContainer);
        loadSysFunContainers();
        loadDriverContainers();

        sui->sysFunctionsTree->setHeaderVisible(false);
        sui->sysFunctionsTree->setRootIsDecorated(false);
        IGSxGUI::Util::disableTreeItemsFocusAndSelection(sui->sysFunctionsTree);
        setBranchIconsVisibility();

        init();
        loadDrivers();
        setHandlers();
        setTreeItemsDefaultStyle();
        showSimMode();

        IGSxGUI::Util::setAwesome(sui->lblMainStatusImage, IGSxGUI::AwesomeIcon::AI_fa_cog, SUI::ColorEnum::White, CONSTANT_TWENTY);
        IGSxGUI::Util::setAwesome(sui->lblClockIcon, IGSxGUI::AwesomeIcon::AI_fa_clock, SUI::ColorEnum::White, CONSTANT_TWENTY);

        for (size_t i = 0; i < m_listSysFunctions.size(); ++i)
        {
            m_listSysFunctions[i]->determineState();
        }
        IGS_INFO(STRING_SYSTEMVIEW_SHOWN);
    }
}

void IGSxGUI::SystemView::loadDriverContainers()
{
    driverUC.clear();
    driverBIProgress.clear();
    driverBIRegress.clear();
    driverSim.clear();
    driverGroupBox.clear();
    driverName.clear();
    driverSignalIcon.clear();
    driverStatus.clear();

    for (size_t i = 0; i < m_listSysFunctions.size(); ++i) {
        driverUC.push_back(vector<SUI::UserControl*>());
        driverBIProgress.push_back(vector<SUI::BusyIndicator*>());
        driverBIRegress.push_back(vector<SUI::BusyIndicator*>());
        driverSim.push_back(vector<SUI::Button*>());
        driverGroupBox.push_back(vector<SUI::GroupBox*>());
        driverName.push_back(vector<SUI::Label*>());
        driverSignalIcon.push_back(vector<SUI::Label*>());
        driverStatus.push_back(vector<SUI::Label*>());
    }

    // load driver[0][0] widgtes
    driverUC[0].push_back(sui->uctSysFun0Driver0);

    std::vector<std::pair<SUI::Widget *, SUI::ObjectType::Type> > objs =
            sui->sysFunctionsTree->getSubWidgets(dynamic_cast<SUI::Widget*>(driverUC[0][0]));

    driverBIProgress[0].push_back(dynamic_cast<SUI::BusyIndicator*>(objs[0].first));
    driverBIRegress[0].push_back(dynamic_cast<SUI::BusyIndicator*>(objs[1].first));
    driverSim[0].push_back(dynamic_cast<SUI::Button*>(objs[2].first));
    driverGroupBox[0].push_back(dynamic_cast<SUI::GroupBox*>(objs[3].first));
    driverName[0].push_back(dynamic_cast<SUI::Label*>(objs[4].first));
    driverSignalIcon[0].push_back(dynamic_cast<SUI::Label*>(objs[5].first));
    driverStatus[0].push_back(dynamic_cast<SUI::Label*>(objs[6].first));

    // load remaining driver widgets other than driver[0][0] widgtes
    for (size_t i = 0; i < m_listSysFunctions.size(); ++i) {
        std::vector<Driver *> drivers = m_presenter->getDrivers(m_listSysFunctions[i]->getName());
        for (std::size_t j = 0; j < drivers.size(); ++j)
        {
            if ((i == 0) && (j == 0)) {
                continue;
            }

            SUI::Widget *child = sui->sysFunctionsTree->appendChildItem(m_listSystemFunctionUCT[i]);
            driverUC[i].push_back(dynamic_cast<SUI::UserControl*>(child));

            std::vector<std::pair<SUI::Widget *, SUI::ObjectType::Type> > objs =
                    sui->sysFunctionsTree->getSubWidgets(child);

            driverBIProgress[i].push_back(dynamic_cast<SUI::BusyIndicator*>(objs[0].first));
            driverBIRegress[i].push_back(dynamic_cast<SUI::BusyIndicator*>(objs[1].first));
            driverSim[i].push_back(dynamic_cast<SUI::Button*>(objs[2].first));
            driverGroupBox[i].push_back(dynamic_cast<SUI::GroupBox*>(objs[3].first));
            driverName[i].push_back(dynamic_cast<SUI::Label*>(objs[4].first));
            driverSignalIcon[i].push_back(dynamic_cast<SUI::Label*>(objs[5].first));
            driverStatus[i].push_back(dynamic_cast<SUI::Label*>(objs[6].first));
        }
    }
}

void IGSxGUI::SystemView::showSimMode()
{
    for (size_t i = 0; i < m_listSysFunctions.size(); ++i) {
        std::vector<Driver *> drivers = m_presenter->getDrivers(m_listSysFunctions[i]->getName());

        m_listSystemFunctionSimButtons[i]->setVisible(false);

        for (std::size_t j = 0; j < drivers.size(); j++)
        {
            if (drivers[j]->getMode() == DriverMode::DM_SIM1) {
                driverSim[i][j]->setVisible(true);
                if (!m_listSystemFunctionSimButtons[i]->isVisible()) {
                    m_listSystemFunctionSimButtons[i]->setVisible(true);
                }
            } else {
                driverSim[i][j]->setVisible(false);
            }
        }
    }
}

void IGSxGUI::SystemView::setBranchIconsVisibility() {
    for (size_t i = 0; i < m_listSystemFunctionUCT.size(); ++i) {
        if (sui->sysFunctionsTree->hasChildren(m_listSystemFunctionUCT[i])) {
            IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[i], IGSxGUI::AwesomeIcon::AI_fa_angle_right,
                                      SYSFUN_COLLAPSED_BRANCH_ICON_COLOR, SYSFUN_BRANCH_ICON_SIZE);
            m_listSystemFunctionBranchIcons[i]->setVisible(true);
        } else {
            m_listSystemFunctionBranchIcons[i]->setVisible(false);
        }
    }
}

void IGSxGUI::SystemView:: setActive(bool bActive)
{
    m_bSystemViewActive = bActive;
}

void IGSxGUI::SystemView::onInitializeButtonPressed()
{
    createPopup(DIALOG_TITLE_INITIALIZE, DIALOG_MESSAGE_INITIALIZE, DIALOG_OKBUTTON_INITIALIZE, DIALOG_CANCELBUTTON);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_OKBUTTON)->clicked = boost::bind(&SystemView::initalizeSystem, this);
    m_dialog->show();
}

void IGSxGUI::SystemView::onTerminateButtonPressed()
{
    createPopup(DIALOG_TITLE_TERMINATE, DIALOG_MESSAGE_TERMINATE, DIALOG_OKBUTTON_TERMINATE, DIALOG_CANCELBUTTON);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_OKBUTTON)->clicked = boost::bind(&SystemView::terminateSystem, this);
    m_dialog->show();
}

void IGSxGUI::SystemView::onResolveButtonPressed()
{
    createPopup(DIALOG_TITLE_INITIALIZE, DIALOG_MESSAGE_INITIALIZE, DIALOG_OKBUTTON_INITIALIZE, DIALOG_CANCELBUTTON);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_OKBUTTON)->clicked = boost::bind(&SystemView::initalizeSystem, this);
    m_dialog->show();
}

void IGSxGUI::SystemView::createPopup(const std::string& title, const std::string& message, const std::string& okButtonText, const std::string& cancelButtonText)
{
    m_dialog->setWindowTitle(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_TITLE)->setText(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_MESSAGE)->setText(message);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_OKBUTTON)->setText(okButtonText);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_CANCELBUTTON)->setText(cancelButtonText);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_CANCELBUTTON)->clicked = boost::bind(&SUI::Dialog::close, m_dialog);
    m_dialog->setModal(true);

    IGSxGUI::Util::setParent(m_dialog, sui->sysFunctionsTree);
    IGSxGUI::Util::disableScrollbars(m_dialog);    

    if (m_bAlertPopupRaised)
    {
        IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_ALERT_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
    } else {
        IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
    }

    IGSxGUI::Util::setWindowFrame(m_dialog, false);
}

void IGSxGUI::SystemView::initalizeSystem()
{
    IGS_INFO(STRING_INIT_PRESSED);
    m_dialog->close();
    updateMainStatus(SystemState::SS_INITIALIZING);
    startTimer();
    m_presenter->Resolve();
}

void IGSxGUI::SystemView::terminateSystem()
{
    IGS_INFO(STRING_TERMINATE_PRESSED);
    m_dialog->close();
    updateMainStatus(SystemState::SS_TERMINATING);
    startTimer();
    m_presenter->Terminate();
}

void IGSxGUI::SystemView::startTimer()
{
    m_startTime = time(NULL);
    m_timer->start();

    showElapsedTime();
}

void IGSxGUI::SystemView::showElapsedTime() const
{
    int elapsedSeconds = static_cast<int>(difftime(time(NULL), m_startTime));
    int seconds, minutes;
    minutes = elapsedSeconds / CONSTANT_SIXTY;
    seconds = elapsedSeconds % CONSTANT_SIXTY;
    minutes = minutes % CONSTANT_SIXTY;

    std::stringstream time;
    time << minutes << STRING_COLON;
    if (seconds < 10) time << STRING_ZERO;
    time << seconds;
    sui->lblTimer->setText(time.str());
}

void IGSxGUI::SystemView::onSysFunHoverOn(const size_t index)
{
    if (m_listSystemFunctionGroupBox[index]->getStyleSheetClass() != SYSFUN_EXPANDED_SELECTED) {
        if (std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index) != m_expandedSysFunIndex.end()) {
            m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_ON_EXPANDED);
        } else {
            if (static_cast<size_t>(m_lastSysFunIndex) == index) {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_ON_EXPANDED);
            } else {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_ON);
            }
        }
    }
}

void IGSxGUI::SystemView::onSysFunHoverOff(const size_t index)
{
    if (m_listSystemFunctionGroupBox[index]->getStyleSheetClass() != SYSFUN_EXPANDED_SELECTED) {
        if (std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index) != m_expandedSysFunIndex.end()) {
            m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
        } else {
            if (static_cast<size_t>(m_lastSysFunIndex) == index) {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
            } else {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF);
            }
        }
    }
}

void IGSxGUI::SystemView::onSysFunPressed(const size_t index)
{
    std::vector<size_t>::iterator itSysExpanded = std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index);

    //If multiple system function are in expanded state and user clicks on non-selected Sys Funcion
    //Then that System function should be collapsed
    if ((m_listSystemFunctionGroupBox[index]->getStyleSheetClass() != SYSFUN_EXPANDED_SELECTED) &&
        (itSysExpanded != m_expandedSysFunIndex.end()))
    {
        sui->sysFunctionsTree->setExpanded(m_listSystemFunctionUCT[index], false);
        IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[index], IGSxGUI::AwesomeIcon::AI_fa_angle_right,
                                  SYSFUN_COLLAPSED_BRANCH_ICON_COLOR, SYSFUN_BRANCH_ICON_SIZE);

        //remove the sysfun index from the vector if it is present already
        std::vector<size_t>::iterator it = std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index);
        if ((!m_expandedSysFunIndex.empty()) && (it != m_expandedSysFunIndex.end())) {
            m_expandedSysFunIndex.erase(it);
        }

        manipulateSysFunSelection(index, SysFunctionSelection::NOT_SELECTED_CLICKED);
    }
    else
    {
        hideDriverInfo();
        //If the System function is expanded and selected, then collapse system function
        if (m_listSystemFunctionGroupBox[index]->getStyleSheetClass() == SYSFUN_EXPANDED_SELECTED)
        {
            sui->sysFunctionsTree->setExpanded(m_listSystemFunctionUCT[index], false);
            IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[index], IGSxGUI::AwesomeIcon::AI_fa_angle_right,
                                      SYSFUN_COLLAPSED_BRANCH_ICON_COLOR, SYSFUN_BRANCH_ICON_SIZE);

            //remove the sysfun index from the vector if it is present already
            std::vector<size_t>::iterator it = std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index);
            if ((!m_expandedSysFunIndex.empty()) && (it != m_expandedSysFunIndex.end())) {
                m_expandedSysFunIndex.erase(it);
            }
            manipulateSysFunSelection(index, SysFunctionSelection::SELECTED);
        } else {
            //If the System function is not expanded and selected, then Expand the system function
            sui->sysFunctionsTree->setExpanded(m_listSystemFunctionUCT[index], true);
            IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[index], IGSxGUI::AwesomeIcon::AI_fa_angle_down,
                                      SYSFUN_EXPANDED_BRANCH_ICON_COLOR_SELECTED, SYSFUN_BRANCH_ICON_SIZE);

            // push the sysfun index into the vector if it is not present already
            if (std::find(m_expandedSysFunIndex.begin(), m_expandedSysFunIndex.end(), index) == m_expandedSysFunIndex.end()) {
                m_expandedSysFunIndex.push_back(index);
            }
            manipulateSysFunSelection(index, SysFunctionSelection::NOT_SELECTED);
        }
        m_lastClickedSysFunIndex = boost::lexical_cast<int>(index);
        m_lastClickedDriverIndex = -1;
        m_sysFunIndexForLastClickedDriver = -1;
    }
}

void IGSxGUI::SystemView::onDriverHoverOn(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() != STYLECLASS_SELECTED) {
        driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(DRIVER_HOVER_ON);
    }
}

void IGSxGUI::SystemView::onDriverHoverOff(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() != STYLECLASS_SELECTED) {
        driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(DRIVER_HOVER_OFF);
    }
}

void IGSxGUI::SystemView::onDriverPressed(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() == STYLECLASS_SELECTED)
    {
        manipulateDriverSelection(sysFunIndex, driverIndex, false);
        hideDriverInfo();
        m_lastClickedDriverIndex = -1;
        m_sysFunIndexForLastClickedDriver = -1;
    } else {
        manipulateDriverSelection(sysFunIndex, driverIndex, true);
        showDriverInfo(sysFunIndex, driverIndex);
        m_lastClickedSysFunIndex = -1;
        m_lastClickedDriverIndex = static_cast<int>(driverIndex);
        m_sysFunIndexForLastClickedDriver = static_cast<int>(sysFunIndex);
    }
}

void IGSxGUI::SystemView::onLastDriverHoverOn(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() != STYLECLASS_SELECTED) {
        if (sysFunIndex == static_cast<size_t>(m_lastSysFunIndex)) {
            driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_ON);
        } else {
            driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_ON);
        }
    }
}

void IGSxGUI::SystemView::onLastDriverHoverOff(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() != STYLECLASS_SELECTED) {
        if (sysFunIndex == static_cast<size_t>(m_lastSysFunIndex)) {
            driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
        } else {
            driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
        }
    }
}

void IGSxGUI::SystemView::onLastDriverPressed(const size_t sysFunIndex, const size_t driverIndex)
{
    if (driverGroupBox[sysFunIndex][driverIndex]->getStyleSheetClass() == STYLECLASS_SELECTED)
    {
        manipulateDriverSelection(sysFunIndex, driverIndex, false);
        hideDriverInfo();
        m_lastClickedDriverIndex = -1;
        m_sysFunIndexForLastClickedDriver = -1;
    } else {
        manipulateDriverSelection(sysFunIndex, driverIndex, true);
        showDriverInfo(sysFunIndex, driverIndex);
        m_lastClickedSysFunIndex = -1;
        m_lastClickedDriverIndex = static_cast<int>(driverIndex);
        m_sysFunIndexForLastClickedDriver = static_cast<int>(sysFunIndex);
    }
}

void IGSxGUI::SystemView::showDriverInfo(const size_t sysFunIndex, const size_t driverIndex)
{
    std::vector<Driver*> drivers  = m_presenter->getDrivers(m_listSysFunctions[sysFunIndex]->getName());
    std::string strDriverName = drivers[driverIndex]->getDisplayName();
    std::transform(strDriverName.begin(), strDriverName.end(), strDriverName.begin(), std::ptr_fun<int, int>(toupper));

    //The description of the driver is not available so set to empty
    //Currently hard coded to STRING_EMPTY, we will get this from Glue code once the interface is implemented
    std::string strDriverDescription = STRING_EMPTY;

    //Simulation or Real (Sim/Real) mode
    std::string strDriverMode = DriverMode::toString(drivers[driverIndex]->getMode());

    sui->lblDriverInformation->setVisible(true);
    sui->lblDriverModeText->setVisible(true);
    sui->lblDriverMode->setVisible(true);
    sui->lblDriverInformation->setText(std::string(STRING_SEPERATOR + strDriverName));
    sui->lblDriverMode->setText(strDriverMode);

    sui->lblDriverDescription->setVisible(false);
    sui->txaDriverDescription->setVisible(false);
    sui->txaDriverDescription->clearText();
    sui->txaDriverDescription->setText(strDriverDescription);
    sui->txaDriverDescription->setScrollPosition(CONSTANT_ZERO);
}

void IGSxGUI::SystemView::manipulateSysFunSelection(const int index, SysFunctionSelection::Selection selectionValue)
{
    switch (selectionValue) {
        case SysFunctionSelection::SELECTED:
        {
            if (m_lastSysFunIndex == index) {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
            } else {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF);
            }
            m_listSystemFunctionNameLabels[index]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listSystemFunctionStatusLabels[index]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);
        }
        break;
        case SysFunctionSelection::NOT_SELECTED:
        {
            //clear sys function selection
            if ((m_lastClickedSysFunIndex != -1) &&
                (m_listSystemFunctionGroupBox[m_lastClickedSysFunIndex]->getStyleSheetClass() == SYSFUN_EXPANDED_SELECTED))
            {
                m_listSystemFunctionGroupBox[m_lastClickedSysFunIndex]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
                m_listSystemFunctionNameLabels[m_lastClickedSysFunIndex]->setStyleSheetClass(STYLECLASS_DEFAULT);
                m_listSystemFunctionStatusLabels[m_lastClickedSysFunIndex]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);

                IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[m_lastClickedSysFunIndex],
                                          IGSxGUI::AwesomeIcon::AI_fa_angle_down, SYSFUN_EXPANDED_BRANCH_ICON_COLOR_UNSELECTED,
                                          SYSFUN_BRANCH_ICON_SIZE);
            }

            // clear the driver selection
            if ((m_lastClickedDriverIndex != -1) && (m_sysFunIndexForLastClickedDriver != -1) &&
                (driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->getStyleSheetClass() == STYLECLASS_SELECTED))
            {
                if (m_lastDriverIndex[m_sysFunIndexForLastClickedDriver] == m_lastClickedDriverIndex) {
                    if (m_sysFunIndexForLastClickedDriver == m_lastSysFunIndex) {
                        driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
                    } else {
                        driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
                    }
                } else {
                    driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(NORMALSTYLE);
                }
                driverName[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERNAME_DEFAULT);
                driverStatus[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERSTATUS_DEFAULT_SMALL);
            }

            // select the sys function with index "index"
            m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_EXPANDED_SELECTED);

            m_listSystemFunctionNameLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED);
            m_listSystemFunctionStatusLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED_SMALL);
        }
        break;
        case SysFunctionSelection::NOT_SELECTED_CLICKED:
        {
            // clear the driver selection
            if ((m_lastClickedDriverIndex != -1) && (m_sysFunIndexForLastClickedDriver != -1) && (m_sysFunIndexForLastClickedDriver == index) &&
                (driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->getStyleSheetClass() == STYLECLASS_SELECTED))
            {
                if (m_lastDriverIndex[m_sysFunIndexForLastClickedDriver] == m_lastClickedDriverIndex) {
                    if (m_sysFunIndexForLastClickedDriver == m_lastSysFunIndex) {
                        driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
                    } else {
                        driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
                    }
                } else {
                    driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(NORMALSTYLE);
                }
                driverName[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERNAME_DEFAULT);
                driverStatus[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERSTATUS_DEFAULT_SMALL);
                hideDriverInfo();
            }

            if (m_lastSysFunIndex == index) {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
            } else {
                m_listSystemFunctionGroupBox[index]->setStyleSheetClass(SYSFUN_HOVER_OFF);
            }
            m_listSystemFunctionNameLabels[index]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listSystemFunctionStatusLabels[index]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);
        }
        break;
    }
}

void IGSxGUI::SystemView::manipulateDriverSelection(const size_t sysFunIndex, const size_t driverIndex, const bool bShow)
{
    if (!bShow)
    {
        if (static_cast<size_t>(m_lastDriverIndex[sysFunIndex]) == driverIndex) {
            if (sysFunIndex == static_cast<size_t>(m_lastSysFunIndex)) {
                driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
            } else {
                driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
            }
        } else {
            driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(NORMALSTYLE);
        }
        driverName[sysFunIndex][driverIndex]->setStyleSheetClass(DRIVERNAME_DEFAULT);
        driverStatus[sysFunIndex][driverIndex]->setStyleSheetClass(DRIVERSTATUS_DEFAULT_SMALL);
    } else {
        //clear sys function selection
        if ((m_lastClickedSysFunIndex != -1) &&
            (m_listSystemFunctionGroupBox[m_lastClickedSysFunIndex]->getStyleSheetClass() == SYSFUN_EXPANDED_SELECTED))
        {
            m_listSystemFunctionGroupBox[m_lastClickedSysFunIndex]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
            m_listSystemFunctionNameLabels[m_lastClickedSysFunIndex]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listSystemFunctionStatusLabels[m_lastClickedSysFunIndex]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);

            IGSxGUI::Util::setAwesome(m_listSystemFunctionBranchIcons[m_lastClickedSysFunIndex],
                                      IGSxGUI::AwesomeIcon::AI_fa_angle_down, SYSFUN_EXPANDED_BRANCH_ICON_COLOR_UNSELECTED,
                                      SYSFUN_BRANCH_ICON_SIZE);
        }

        // clear the driver selection
        if ((m_lastClickedDriverIndex != -1) && (m_sysFunIndexForLastClickedDriver != -1) &&
            (driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->getStyleSheetClass() == STYLECLASS_SELECTED))
        {
            if (m_lastDriverIndex[m_sysFunIndexForLastClickedDriver] == m_lastClickedDriverIndex) {
                if (m_sysFunIndexForLastClickedDriver == m_lastSysFunIndex) {
                    driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
                } else {
                    driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
                }
            } else {
                driverGroupBox[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(NORMALSTYLE);
            }
            driverName[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERNAME_DEFAULT);
            driverStatus[m_sysFunIndexForLastClickedDriver][m_lastClickedDriverIndex]->setStyleSheetClass(DRIVERSTATUS_DEFAULT_SMALL);
        }

        // select the driver with index "[sysFunIndex][driverIndex]"
        driverGroupBox[sysFunIndex][driverIndex]->setStyleSheetClass(STYLECLASS_SELECTED);
        driverName[sysFunIndex][driverIndex]->setStyleSheetClass(STYLECLASS_SELECTED);
        driverStatus[sysFunIndex][driverIndex]->setStyleSheetClass(STYLECLASS_SELECTED_SMALL);
    }
}

void IGSxGUI::SystemView::setTreeItemsDefaultStyle()
{
    for (size_t i = 0; i < m_listSystemFunctionUCT.size(); ++i) {
        if (static_cast<size_t>(m_lastSysFunIndex) == i) {
            m_listSystemFunctionGroupBox[i]->setStyleSheetClass(SYSFUN_HOVER_OFF_EXPANDED);
        } else {
            m_listSystemFunctionGroupBox[i]->setStyleSheetClass(SYSFUN_HOVER_OFF);
        }
        std::vector<Driver*> drivers  = m_presenter->getDrivers(m_listSysFunctions[i]->getName());
        for (std::size_t j = 0; j < drivers.size(); ++j)
        {
            if (j == (drivers.size() - 1)) {
                driverGroupBox[i][j]->setStyleSheetClass(LAST_DRIVER_HOVER_OFF);
            } else {
                driverGroupBox[i][j]->setStyleSheetClass(NORMALSTYLE);
            }

            if (i == static_cast<size_t>(m_lastSysFunIndex)) {
                driverGroupBox[i][j]->setStyleSheetClass(LAST_SYSFUN_LAST_DRIVER_HOVER_OFF);
            }
        }
    }
}

void IGSxGUI::SystemView::hideDriverInfo()
{
    sui->lblDriverInformation->setVisible(false);
    sui->lblDriverModeText->setVisible(false);
    sui->lblDriverMode->setVisible(false);
    sui->lblDriverDescription->setVisible(false);
    sui->txaDriverDescription->setVisible(false);
    sui->btnAdvancedDashboard->setVisible(false);
}

void IGSxGUI::SystemView::updateStatus(const SUI::ColorEnum::Color &color,
                                              const std::string &message,
                                              bool bBtnInitVisibility,
                                              bool bBtnTerminateVisibility,
                                              bool bBtnResolveVisibility,
                                              bool bClockVisibility,
                                              bool bLblTimerVisibility,
                                              bool bPartlyInitialized,
                                              bool bIconVisibility)
{
    m_mainStatus.color = color;
    m_mainStatus.strMessage = message;
    m_mainStatus.bBtnInitVisibility = bBtnInitVisibility;
    m_mainStatus.bBtnTerminateVisibility = bBtnTerminateVisibility;
    m_mainStatus.bBtnResolveVisibility = bBtnResolveVisibility;
    m_mainStatus.bClockVisibility = bClockVisibility;
    m_mainStatus.bLblTimerVisibility = bLblTimerVisibility;

    sui->lblSystemStatusSignalIcon->setVisible(bIconVisibility);

    sui->gbxSystem->setBGColor(m_mainStatus.color);
    if (bPartlyInitialized)
    {
        std::string strMsg;
        int initializedDriverCount = m_presenter->getInitializedDriverCount();
        strMsg.append(m_mainStatus.strMessage).append(STRING_OPEN_BRACKET).append(boost::lexical_cast<std::string>(initializedDriverCount)).append(STRING_SLASH).append(boost::lexical_cast<std::string>(m_totaldrivercount).append(STRING_CLOSE_BRACKET));
        sui->lblMainStatus->setText(strMsg);
    } else {
        sui->lblMainStatus->setText(m_mainStatus.strMessage);
    }

    sui->btnInit->setVisible(m_mainStatus.bBtnInitVisibility);
    sui->btnTerminate->setVisible(m_mainStatus.bBtnTerminateVisibility);
    sui->btnResolve->setVisible(m_mainStatus.bBtnResolveVisibility);
    sui->lblClockIcon->setVisible(m_mainStatus.bClockVisibility);
    sui->lblTimer->setVisible(m_mainStatus.bLblTimerVisibility);

    if (m_mainStatus.bBtnTerminateVisibility)  // This is to make the "Terminate" button colour depends on the system state.
    {
        sui->btnTerminate->setStyleSheetClass(SUI::ColorEnum::toString(color));
    }
    if (m_mainStatus.bBtnResolveVisibility)
    {
        sui->btnResolve->setStyleSheetClass(SUI::ColorEnum::toString(color));
    }
    if (color == SUI::ColorEnum::Gray)
    {
        sui->btnInit->setStyleSheetClass(SUI::ColorEnum::toString(color));
    } else {
        sui->btnInit->setStyleSheetClass(STRING_EMPTY);
    }

    sui->btnInit->setEnabled(m_bEnableInitButton);
    sui->btnResolve->setEnabled(m_bEnableInitButton);
    sui->btnTerminate->setEnabled(m_bEnableInitButton);

    if (!m_bEnableInitButton)
    {
        //set the style of disable
        sui->btnInit->setStyleSheetClass(STYLE_DISABLE_BUTTON);
        sui->btnResolve->setStyleSheetClass(STYLE_DISABLE_BUTTON);
        sui->btnTerminate->setStyleSheetClass(STYLE_DISABLE_BUTTON);
    }
}

void IGSxGUI::SystemView::setHandlers()
{
    sui->btnInit->clicked = boost::bind(&SystemView::onInitializeButtonPressed, this);
    sui->btnTerminate->clicked = boost::bind(&SystemView::onTerminateButtonPressed, this);
    sui->btnResolve->clicked = boost::bind(&SystemView::onResolveButtonPressed, this);

    m_lastSysFunIndex = static_cast<int>(m_listSystemFunctionUCT.size()) - 1;
    for (size_t i = 0; i < m_listSystemFunctionUCT.size(); ++i) {
        m_lastDriverIndex.push_back(0);
        m_listSystemFunctionUCT[i]->hoverEntered = boost::bind(&SystemView::onSysFunHoverOn, this, i);
        m_listSystemFunctionUCT[i]->hoverLeft = boost::bind(&SystemView::onSysFunHoverOff, this, i);
        m_listSystemFunctionUCT[i]->clicked = boost::bind(&SystemView::onSysFunPressed, this, i);

        std::vector<Driver*> drivers  = m_presenter->getDrivers(m_listSysFunctions[i]->getName());
        for (std::size_t j = 0; j < drivers.size(); ++j)
        {
            if (j == (drivers.size() - 1)) {
                m_lastDriverIndex.at(i) = j;
                driverUC[i][j]->clicked = boost::bind(&SystemView::onLastDriverPressed, this, i, j);
                driverUC[i][j]->hoverEntered = boost::bind(&SystemView::onLastDriverHoverOn, this, i, j);
                driverUC[i][j]->hoverLeft = boost::bind(&SystemView::onLastDriverHoverOff, this, i, j);
            } else {
                driverUC[i][j]->clicked = boost::bind(&SystemView::onDriverPressed, this, i, j);
                driverUC[i][j]->hoverEntered = boost::bind(&SystemView::onDriverHoverOn, this, i, j);
                driverUC[i][j]->hoverLeft = boost::bind(&SystemView::onDriverHoverOff, this, i, j);
            }
        }
    }
}

void IGSxGUI::SystemView::loadSysFunContainers()
{
    m_listSystemFunctionUCT.clear();
    m_listSystemFunctionSimButtons.clear();
    m_listSystemFunctionGroupBox.clear();
    m_listSystemFunctionBranchIcons.clear();
    m_listSystemFunctionNameLabels.clear();
    m_listSystemFunctionSignalIcons.clear();
    m_listSystemFunctionStatusLabels.clear();
    m_listSystemFunctionProgressBar.clear();

    // load sysfuns[0] widgtes
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction0);

    std::vector<std::pair<SUI::Widget *, SUI::ObjectType::Type> > objs =
            sui->sysFunctionsTree->getSubWidgets(dynamic_cast<SUI::Widget*>(m_listSystemFunctionUCT[0]));

    m_listSystemFunctionSimButtons.push_back(dynamic_cast<SUI::Button*>(objs[0].first));
    m_listSystemFunctionGroupBox.push_back(dynamic_cast<SUI::GroupBox*>(objs[1].first));
    m_listSystemFunctionBranchIcons.push_back(dynamic_cast<SUI::Label*>(objs[2].first));
    m_listSystemFunctionSignalIcons.push_back(dynamic_cast<SUI::Label*>(objs[3].first));
    m_listSystemFunctionStatusLabels.push_back(dynamic_cast<SUI::Label*>(objs[4].first));
    m_listSystemFunctionNameLabels.push_back(dynamic_cast<SUI::Label*>(objs[5].first));
    m_listSystemFunctionProgressBar.push_back(dynamic_cast<SUI::ProgressBar*>(objs[6].first));

    // load remaining sysfuns widgets other than sysfuns[0] widgtes
    for (size_t i = 1; i < m_listSysFunctions.size(); ++i) {
        SUI::Widget *treeItem = sui->sysFunctionsTree->appendTopLevelItem();
        m_listSystemFunctionUCT.push_back(dynamic_cast<SUI::UserControl*>(treeItem));

        std::vector<std::pair<SUI::Widget *, SUI::ObjectType::Type> > objs =
                sui->sysFunctionsTree->getSubWidgets(dynamic_cast<SUI::Widget*>(m_listSystemFunctionUCT[i]));

        m_listSystemFunctionSimButtons.push_back(dynamic_cast<SUI::Button*>(objs[0].first));
        m_listSystemFunctionGroupBox.push_back(dynamic_cast<SUI::GroupBox*>(objs[1].first));
        m_listSystemFunctionBranchIcons.push_back(dynamic_cast<SUI::Label*>(objs[2].first));
        m_listSystemFunctionSignalIcons.push_back(dynamic_cast<SUI::Label*>(objs[3].first));
        m_listSystemFunctionStatusLabels.push_back(dynamic_cast<SUI::Label*>(objs[4].first));
        m_listSystemFunctionNameLabels.push_back(dynamic_cast<SUI::Label*>(objs[5].first));
        m_listSystemFunctionProgressBar.push_back(dynamic_cast<SUI::ProgressBar*>(objs[6].first));
    }
}

void IGSxGUI::SystemView::init()
{
    m_mapSystemFunctions.clear();
    m_mapDrivers.clear();

    for (size_t i = 0; i < m_listSysFunctions.size(); i++)
    {
        m_listSystemFunctionUCT[i]->setVisible(true);
        m_listSystemFunctionNameLabels[i]->setText(m_listSysFunctions[i]->getDescription());

        std::string sysFunName = m_listSysFunctions[i]->getName();
        std::pair<std::string, IGSxSysFunction::SysFunInfo> sysfunPair;

        sysfunPair.first = sysFunName;
        sysfunPair.second.UiID.UCT = m_listSystemFunctionUCT[i];
        sysfunPair.second.UiID.lblSignalIcon = m_listSystemFunctionSignalIcons[i];
        sysfunPair.second.UiID.btnSim = m_listSystemFunctionSimButtons[i];
        sysfunPair.second.UiID.lblName = m_listSystemFunctionNameLabels[i];
        sysfunPair.second.UiID.lblStatus = m_listSystemFunctionStatusLabels[i];
        sysfunPair.second.UiID.pgbProgress = m_listSystemFunctionProgressBar[i];
        sysfunPair.second.UiValues.NameText = m_listSysFunctions[i]->getDescription();
        sysfunPair.second.UiValues.StatusText = STRING_EMPTY;
        sysfunPair.second.UiValues.ProgressbarValue = 0;

        std::vector<Driver*> drivers = m_presenter->getDrivers(sysFunName);

        for (size_t j = 0; j < drivers.size(); j++)
        {
            std::pair<std::string, IGSxSysFunction::DriverInfo> driverPair;

            if (!drivers[j]->isImplemented())
            {
                driverPair.second.UiValues.isImplemented = false;
            } else {
                driverPair.second.UiValues.isImplemented = true;
                ++m_totaldrivercount;
            }
            driverPair.first = drivers[j]->getName();
            driverPair.second.UiValues.NameText = drivers[j]->getDisplayName();
            driverPair.second.UiValues.StatusText = m_driverStates[drivers[j]->getState()];
            driverPair.second.UiValues.SysFunctionName = sysFunName;

            m_mapDrivers.insert(driverPair);
            updateDriver(drivers[j]->getState(), drivers[j]->getName());
        }
        sysfunPair.second.UiValues.TotalDriverCount = static_cast<int>(m_listSysFunctions[i]->getDriverCount());
        sysfunPair.second.UiValues.InitializedDriverCount = 0;
        sysfunPair.second.UiValues.TerminatedDriverCount = 0;
        if (m_listSysFunctions[i]->getDriverCount() > 0)
        {
            sysfunPair.second.UiValues.ProgressValueToBeIncreased = ((100 / static_cast<int>(m_listSysFunctions[i]->getDriverCount()))+ 1);
            sysfunPair.second.UiValues.StatusText = m_sysFunStates[m_listSysFunctions[i]->getState()];
        }

        sysfunPair.second.UiID.lblStatus->setText(sysfunPair.second.UiValues.StatusText);
        m_mapSystemFunctions.insert(sysfunPair);
        if (m_listSysFunctions[i]->getDriverCount() > 0)
        {
            updateSysFunction(m_listSysFunctions[i]->getState(), m_listSysFunctions[i]->getName(), 0, 0);
        }
    }
    if (m_displayStates)
    {
        updateMainStatus(m_presenter->getSystemState());
    }
}

void IGSxGUI::SystemView::hideProgressbar()
{
    for (std::map<std::string, IGSxSysFunction::SysFunInfo>::iterator it = m_mapSystemFunctions.begin(); it != m_mapSystemFunctions.end(); ++it)
    {
        if ( it->second.UiValues.progressbarVisibility )
        {
            it->second.UiValues.progressbarVisibility = false;
            it->second.UiID.pgbProgress->setVisible(it->second.UiValues.progressbarVisibility);
        }
    }
}

void IGSxGUI::SystemView::updateSysFunction(const SystemState::SystemStateEnum &state, const std::string &strSysFunction, const int& nInitializedDriverCount, const int& nTerminatedDriverCount)
{
    std::map<std::string, IGSxSysFunction::SysFunInfo>::iterator it = m_mapSystemFunctions.find(strSysFunction);
    if (it != m_mapSystemFunctions.end())
    {
        switch (state)
        {
            case SystemState::SS_INITIALIZED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.iconVisibility = true;
                it->second.UiValues.icon = IGSxGUI::AwesomeIcon::AI_fa_check;
                it->second.UiValues.iconColor = COLOR_ASML_GREEN;
                it->second.UiValues.InitializedDriverCount = it->second.UiValues.TotalDriverCount;
                it->second.UiValues.TerminatedDriverCount = 0;
                it->second.UiValues.ProgressbarValue = it->second.UiValues.ProgressValueToBeIncreased * it->second.UiValues.TotalDriverCount;
                if(it->second.UiValues.ProgressbarValue > 100)
                {
                    it->second.UiValues.ProgressbarValue = 100;
                }
                break;
            }
            case SystemState::SS_TERMINATED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.iconVisibility = false;
                it->second.UiValues.TerminatedDriverCount = it->second.UiValues.TotalDriverCount;
                it->second.UiValues.InitializedDriverCount = 0;
                if (it->second.UiValues.progressbarVisibility)
                {
                    it->second.UiValues.ProgressbarValue = 0;
                }
                break;
            }
            case SystemState::SS_INITIALIZING:
            {
                std::string temp;
                it->second.UiValues.InitializedDriverCount = nInitializedDriverCount;
                temp.append(boost::lexical_cast<std::string>(it->second.UiValues.InitializedDriverCount)).append(STRING_SINGLE_SPACE + STRING_SLASH + STRING_SINGLE_SPACE).append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount));

                it->second.UiValues.ProgressbarValue = it->second.UiValues.ProgressValueToBeIncreased * it->second.UiValues.InitializedDriverCount;
                IGS_INFO("updateSysFunction() - " + it->second.UiValues.NameText + " InitializedDriverCount " + boost::lexical_cast<std::string>(it->second.UiValues.InitializedDriverCount) + " it->second.UiValues.ProgressbarValue:" + boost::lexical_cast<std::string>(it->second.UiValues.ProgressbarValue));

                it->second.UiValues.StatusText = temp;
                it->second.UiValues.iconVisibility = false;
                it->second.UiValues.progressbarVisibility = true;
                break;
            }
            case SystemState::SS_TERMINATING:
            {
                std::string temp;
                it->second.UiValues.TerminatedDriverCount = nTerminatedDriverCount;
                temp.append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount - nTerminatedDriverCount)).append(STRING_SINGLE_SPACE + STRING_SLASH + STRING_SINGLE_SPACE).append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount));

                int progressValue = it->second.UiValues.ProgressValueToBeIncreased * (it->second.UiValues.TotalDriverCount - nTerminatedDriverCount);
                it->second.UiValues.ProgressbarValue = progressValue > 100 ? 100:progressValue;

                it->second.UiValues.StatusText = temp;
                it->second.UiValues.iconVisibility = false;
                it->second.UiValues.progressbarVisibility = true;

                break;
            }
            case SystemState::SS_PARTIALLY_INITIALIZED:
            {
                std::string temp;
                it->second.UiValues.TerminatedDriverCount = nTerminatedDriverCount;
                it->second.UiValues.InitializedDriverCount = nInitializedDriverCount;
                it->second.UiValues.ProgressbarValue = it->second.UiValues.ProgressValueToBeIncreased * (it->second.UiValues.TotalDriverCount - nTerminatedDriverCount);
                IGS_INFO("updateSysFunction() - " + it->second.UiValues.NameText + " InitializedDriverCount " + boost::lexical_cast<std::string>((nInitializedDriverCount)) + " it->second.UiValues.ProgressbarValue:" + boost::lexical_cast<std::string>(it->second.UiValues.ProgressbarValue));

                temp.append(boost::lexical_cast<std::string>(nInitializedDriverCount)).append(STRING_SINGLE_SPACE + STRING_SLASH + STRING_SINGLE_SPACE).append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount));

                it->second.UiValues.StatusText = temp;
                it->second.UiValues.iconVisibility = false;
                break;
            }
            case SystemState::SS_RECOVERY_REQUIRED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.iconVisibility = true;
                it->second.UiValues.icon = IGSxGUI::AwesomeIcon::AI_fa_times_circle;
                it->second.UiValues.iconColor = COLOR_ASML_RED;
                it->second.UiValues.InitializedDriverCount = nInitializedDriverCount;
                it->second.UiValues.TerminatedDriverCount = nTerminatedDriverCount;
                break;
            }
            default:
                // ToDo, log this case.
                break;
        }

        it->second.UiID.pgbProgress->setValue(it->second.UiValues.ProgressbarValue);
        it->second.UiID.lblStatus->setText(it->second.UiValues.StatusText);
        IGSxGUI::Util::setAwesome(it->second.UiID.lblSignalIcon, it->second.UiValues.icon, it->second.UiValues.iconColor, NO_SIZE);

        it->second.UiID.pgbProgress->setVisible(it->second.UiValues.progressbarVisibility);
        it->second.UiID.lblSignalIcon->setVisible(it->second.UiValues.iconVisibility);
        it->second.UiID.lblStatus->setVisible(true);
    }
}

void IGSxGUI::SystemView::updateDriver(const DriverState::DriverStateEnum &state, const std::string &strDriver)
{
    std::map<std::string, IGSxSysFunction::DriverInfo>::iterator itDriver = m_mapDrivers.find(strDriver);

    if (itDriver != m_mapDrivers.end())
    {
        itDriver->second.UiValues.StatusText = m_driverStates[state];

        switch (state)
        {
            case DriverState::DS_INITIALIZED:
            {
                itDriver->second.UiValues.iconVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.icon = IGSxGUI::AwesomeIcon::AI_fa_check;
                itDriver->second.UiValues.iconColor = COLOR_ASML_GREEN;

                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICProgressVisibility = false;
                itDriver->second.UiValues.statusBICRegressVisibility = false;
                break;
            }
            case DriverState::DS_TERMINATED:
            {
                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICProgressVisibility = false;
                itDriver->second.UiValues.statusBICRegressVisibility = false;
                itDriver->second.UiValues.iconVisibility = false;
                break;
            }
            case DriverState::DS_INITIALIZING:
            {
            itDriver->second.UiValues.iconVisibility = false;
            itDriver->second.UiValues.statusTextVisibility = false;
            itDriver->second.UiValues.statusBICProgressVisibility = (true && itDriver->second.UiValues.isImplemented);
            itDriver->second.UiValues.statusBICRegressVisibility = (false && itDriver->second.UiValues.isImplemented);
            break;

            }
            case DriverState::DS_TERMINATING:
            {
                itDriver->second.UiValues.iconVisibility = false;
                itDriver->second.UiValues.statusTextVisibility = false;
                itDriver->second.UiValues.statusBICProgressVisibility = (false && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICRegressVisibility = (true && itDriver->second.UiValues.isImplemented);
                break;
            }
            case DriverState::DS_RECOVERY_REQUIRED:
            {
                itDriver->second.UiValues.iconVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.icon = IGSxGUI::AwesomeIcon::AI_fa_times_circle;
                itDriver->second.UiValues.iconColor = COLOR_ASML_RED;

                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICProgressVisibility = false;
                itDriver->second.UiValues.statusBICRegressVisibility = false;
                break;
            }
            default:
                // ToDo, log this case.
                break;
        }

        if (itDriver->second.UiID.UCT != NULL) {
            itDriver->second.UiID.bicProgress->setVisible(itDriver->second.UiValues.statusBICProgressVisibility);
            itDriver->second.UiID.bicRegress->setVisible(itDriver->second.UiValues.statusBICRegressVisibility);
            itDriver->second.UiID.lblStatus->setText(itDriver->second.UiValues.StatusText);
            IGSxGUI::Util::setAwesome(itDriver->second.UiID.lblSignalIcon, itDriver->second.UiValues.icon, itDriver->second.UiValues.iconColor, NO_SIZE);

            itDriver->second.UiID.lblSignalIcon->setVisible(itDriver->second.UiValues.iconVisibility);
            itDriver->second.UiID.lblStatus->setVisible(itDriver->second.UiValues.statusTextVisibility);
            itDriver->second.UiID.bicProgress->setVisible(itDriver->second.UiValues.statusBICProgressVisibility);
            itDriver->second.UiID.bicRegress->setVisible(itDriver->second.UiValues.statusBICRegressVisibility);
        }
    }
}

void IGSxGUI::SystemView::loadDrivers()
{
    for (size_t index = 0; index < m_listSysFunctions.size(); ++index) {
        m_listDrivers.clear();
        m_listDrivers = m_presenter->getDrivers(m_listSysFunctions[index]->getName());

        for (std::size_t i = 0; i < m_listDrivers.size(); ++i)
        {
            std::map<std::string, IGSxSysFunction::DriverInfo>::iterator it = m_mapDrivers.find(m_listDrivers[i]->getName());

            if (it != m_mapDrivers.end())
            {
                it->second.UiID.UCT = driverUC[index][i];
                it->second.UiID.lblSignalIcon = driverSignalIcon[index][i];
                it->second.UiID.lblName = driverName[index][i];
                it->second.UiID.lblStatus = driverStatus[index][i];
                it->second.UiID.bicProgress = driverBIProgress[index][i];
                it->second.UiID.bicRegress = driverBIRegress[index][i];

                it->second.UiID.UCT->setVisible(true);
                it->second.UiID.lblName->setEnabled(it->second.UiValues.isImplemented);

                it->second.UiID.lblSignalIcon->setVisible(it->second.UiValues.iconVisibility);
                it->second.UiID.lblStatus->setVisible(it->second.UiValues.statusTextVisibility);
                it->second.UiID.bicProgress->setVisible(it->second.UiValues.statusBICProgressVisibility);
                it->second.UiID.bicRegress->setVisible(it->second.UiValues.statusBICRegressVisibility);

                it->second.UiID.lblName->setText(m_listDrivers[i]->getDisplayName());
                IGSxGUI::Util::setAwesome(it->second.UiID.lblSignalIcon, it->second.UiValues.icon, it->second.UiValues.iconColor, NO_SIZE);
                it->second.UiID.lblStatus->setText(it->second.UiValues.StatusText);
            }
        }
    }
}

void IGSxGUI::SystemView::termintationCompleted()
{
    IGS_INFO("Terminate call returned.");
    m_timer->stop();
    updateMainStatus(m_presenter->getSystemState());
}

void IGSxGUI::SystemView::initializationCompleted()
{
    IGS_INFO("Initialize call returned.");
    m_timer->stop();
    updateMainStatus(m_presenter->getSystemState());
}

void IGSxGUI::SystemView::onTimerTimeout()
{
    showElapsedTime();
    m_timer->start();
}

void IGSxGUI::SystemView::updateMainStatus(const SystemState::SystemStateEnum &state)
{
    if ((m_whoIsInControl == IGSxCTRL::Who::GUI) || (m_whoIsInControl == IGSxCTRL::Who::NONE))
    {
        sui->lblMainStatusImage->setVisible(false);
        sui->lblSystemStatusSignalIcon->setVisible(false);
        m_displayStates = true;

        switch (state)
        {
            case SystemState::SS_INITIALIZED:
            {

                updateStatus(SUI::ColorEnum::Green, m_sysFunStates.at(state), false, true, true, false, false, false, true);
                hideProgressbar();
                sui->btnInit->setVisible(false);
                sui->btnTerminate->setVisible(true);
                sui->btnResolve->setVisible(false);
                IGSxGUI::Util::setAwesome(sui->lblSystemStatusSignalIcon,
                                          IGSxGUI::AwesomeIcon::AI_fa_check,
                                          COLOR_ASML_WHITE,
                                          SYSTEM_STATUS_ICON_SIZE);
                break;
            }
            case SystemState::SS_TERMINATED:
            {

                updateStatus(SUI::ColorEnum::Standard, m_sysFunStates.at(state), false, true, true, false, false, false, false);
                sui->btnInit->setVisible(true);
                sui->btnTerminate->setVisible(false);
                sui->btnResolve->setVisible(false);
                hideProgressbar();
                break;
            }
            case SystemState::SS_INITIALIZING:
            case SystemState::SS_TERMINATING:
            {
                updateStatus(SUI::ColorEnum::Blue, m_sysFunStates.at(state), false, false, false, true, true, false, false);
                break;
            }
            case SystemState::SS_PARTIALLY_INITIALIZED:
            {
                updateStatus(SUI::ColorEnum::Yellow, m_sysFunStates.at(state), false, true, true, false, false, true, false);
                hideProgressbar();
                break;
            }
            case SystemState::SS_RECOVERY_REQUIRED:
            {
                updateStatus(SUI::ColorEnum::Red, m_sysFunStates.at(state), false, true, true, false, false, false, true);
                hideProgressbar();
                IGSxGUI::Util::setAwesome(sui->lblSystemStatusSignalIcon,
                                          IGSxGUI::AwesomeIcon::AI_fa_times_circle,
                                          COLOR_ASML_WHITE,
                                          SYSTEM_STATUS_ICON_SIZE);
                break;
            }
            default:
                // ToDo, log this case.
                break;
        }
    } else {
        m_displayStates = false;
        if (m_whoIsInControl == IGSxCTRL::Who::TESTMANAGER)
        {
            sui->lblMainStatusImage->setVisible(true);
            updateStatus(SUI::ColorEnum::Blue, STRING_CPD_ACTIVE, false, false, false, false, false, false, false);
        }
        if (m_whoIsInControl == IGSxCTRL::Who::SCANNER)
        {
            sui->lblMainStatusImage->setVisible(false);
            updateStatus(SUI::ColorEnum::Blue, STRING_SCANNER_INCONTROL, false, false, false, false, false, false, false);
        }
    }
}

void IGSxGUI::SystemView::notifyAlertPopup(bool bAlertPopupRaised)
{
    m_bAlertPopupRaised = bAlertPopupRaised;

    if ((bAlertPopupRaised) && (m_dialog != NULL) && (m_dialog->isVisible()))
    {
       IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_ALERT_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
    }
}

void IGSxGUI::SystemView::controlChanged(const IGSxCTRL::Who::WhoEnum &who)
{
    m_whoIsInControl = who;
    updateMainStatus(m_presenter->getSystemState());
}

//Make INIT/Terminate button enable/disable with respect to SSM screen state transition
// - Enable - NO SSM screen state transition is going on
// - Disalbe - SSM screen state transition is in progress
void IGSxGUI::SystemView::enableInitButton(bool bEnable)
{
    m_bEnableInitButton = bEnable;
    updateMainStatus(m_presenter->getSystemState());
}
