

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_SystemStateManagerView.cpp
| Author       : Raja
| Description  : Implementation of Moc SystemStateManagerView
|
| ! \file        SystemStateManagerView.cpp
| ! \brief       Implementation of Moc SystemStateManagerView
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP
#define IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_SSMTabView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITabWidget.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <boost/bind.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::SSMTabView::SSMTabView():
    state11(NULL),
    state12(NULL),
    state13(NULL),
    state14(NULL),
    state15(NULL),
    state16(NULL),
    state17(NULL),
    state18(NULL),
    state19(NULL),
    state11Btn(NULL),
    state12Btn(NULL),
    state13Btn(NULL),
    state14Btn(NULL),
    state15Btn(NULL),
    state16Btn(NULL),
    state17Btn(NULL),
    state18Btn(NULL),
    state19Btn(NULL),
    state11Bic(NULL),
    state12Bic(NULL),
    state13Bic(NULL),
    state14Bic(NULL),
    state15Bic(NULL),
    state16Bic(NULL),
    state17Bic(NULL),
    state18Bic(NULL),
    state19Bic(NULL),
    state11OverlayLabel(NULL),
    state12OverlayLabel(NULL),
    state13OverlayLabel(NULL),
    state14OverlayLabel(NULL),
    state15OverlayLabel(NULL),
    state16OverlayLabel(NULL),
    state17OverlayLabel(NULL),
    state18OverlayLabel(NULL),
    state19OverlayLabel(NULL),
    state21(NULL),
    state22(NULL),
    state23(NULL),
    state24(NULL),
    state25(NULL),
    state26(NULL),
    state27(NULL),
    state28(NULL),
    state29(NULL),
    state21Btn(NULL),
    state22Btn(NULL),
    state23Btn(NULL),
    state24Btn(NULL),
    state25Btn(NULL),
    state26Btn(NULL),
    state27Btn(NULL),
    state28Btn(NULL),
    state29Btn(NULL),
    state21Bic(NULL),
    state22Bic(NULL),
    state23Bic(NULL),
    state24Bic(NULL),
    state25Bic(NULL),
    state26Bic(NULL),
    state27Bic(NULL),
    state28Bic(NULL),
    state29Bic(NULL),
    state21OverlayLabel(NULL),
    state22OverlayLabel(NULL),
    state23OverlayLabel(NULL),
    state24OverlayLabel(NULL),
    state25OverlayLabel(NULL),
    state26OverlayLabel(NULL),
    state27OverlayLabel(NULL),
    state28OverlayLabel(NULL),
    state29OverlayLabel(NULL),
    state31(NULL),
    state32(NULL),
    state33(NULL),
    state34(NULL),
    state35(NULL),
    state36(NULL),
    state37(NULL),
    state38(NULL),
    state39(NULL),
    state31Btn(NULL),
    state32Btn(NULL),
    state33Btn(NULL),
    state34Btn(NULL),
    state35Btn(NULL),
    state36Btn(NULL),
    state37Btn(NULL),
    state38Btn(NULL),
    state39Btn(NULL),
    state31Bic(NULL),
    state32Bic(NULL),
    state33Bic(NULL),
    state34Bic(NULL),
    state35Bic(NULL),
    state36Bic(NULL),
    state37Bic(NULL),
    state38Bic(NULL),
    state39Bic(NULL),
    state31OverlayLabel(NULL),
    state32OverlayLabel(NULL),
    state33OverlayLabel(NULL),
    state34OverlayLabel(NULL),
    state35OverlayLabel(NULL),
    state36OverlayLabel(NULL),
    state37OverlayLabel(NULL),
    state38OverlayLabel(NULL),
    state39OverlayLabel(NULL),
    row1(NULL),
    row2(NULL),
    row3(NULL),
    groupLabel1(NULL),
    groupLabel2(NULL),
    groupLabel3(NULL),
    row1Container(NULL),
    row2Container(NULL),
    row3Container(NULL),
    gbxCurrentState(NULL),
    gbxTransitionState(NULL),
    lblCurrentStateText(NULL),
    lblFromText(NULL),
    lblToText(NULL),
    lblStartTimeText(NULL),
    lblExpectedDurationText(NULL),
    lblElapsedTimeText(NULL)
{
}

void SUI::SSMTabView::setupSUI(const char* /*xmlFileName*/) {
}


void SUI::SSMTabView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadObjects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup1Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup1Objects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup2Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup2Objects(container->getObjectList());
}

void SUI::SSMTabView::setupGroup3Container(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadGroup3Objects(container->getObjectList());
}

void SUI::SSMTabView::loadGroup1Objects(SUI::ObjectList* objectList) {


    state11 = objectList->getObject<SUI::UserControl>("uctState11");
    state12 = objectList->getObject<SUI::UserControl>("uctState12");
    state13 = objectList->getObject<SUI::UserControl>("uctState13");
    state14 = objectList->getObject<SUI::UserControl>("uctState14");
    state15 = objectList->getObject<SUI::UserControl>("uctState15");
    state16 = objectList->getObject<SUI::UserControl>("uctState16");
    state17 = objectList->getObject<SUI::UserControl>("uctState17");
    state18 = objectList->getObject<SUI::UserControl>("uctState18");
    state19 = objectList->getObject<SUI::UserControl>("uctState19");

    state11Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
    state12Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
    state13Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
    state14Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
    state15Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
    state16Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
    state17Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
    state18Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
    state19Btn = objectList->getObject<SUI::Button>("uctState19:btnState");

    state11Bic = objectList->getObject<SUI::BusyIndicator>("uctState11:bic");
    state12Bic = objectList->getObject<SUI::BusyIndicator>("uctState12:bic");
    state13Bic = objectList->getObject<SUI::BusyIndicator>("uctState13:bic");
    state14Bic = objectList->getObject<SUI::BusyIndicator>("uctState14:bic");
    state15Bic = objectList->getObject<SUI::BusyIndicator>("uctState15:bic");
    state16Bic = objectList->getObject<SUI::BusyIndicator>("uctState16:bic");
    state17Bic = objectList->getObject<SUI::BusyIndicator>("uctState17:bic");
    state18Bic = objectList->getObject<SUI::BusyIndicator>("uctState18:bic");
    state19Bic = objectList->getObject<SUI::BusyIndicator>("uctState19:bic");

    state11OverlayLabel = objectList->getObject<SUI::Label>("uctState11:lblOverlay");
    state12OverlayLabel = objectList->getObject<SUI::Label>("uctState12:lblOverlay");
    state13OverlayLabel = objectList->getObject<SUI::Label>("uctState13:lblOverlay");
    state14OverlayLabel = objectList->getObject<SUI::Label>("uctState14:lblOverlay");
    state15OverlayLabel = objectList->getObject<SUI::Label>("uctState15:lblOverlay");
    state16OverlayLabel = objectList->getObject<SUI::Label>("uctState16:lblOverlay");
    state17OverlayLabel = objectList->getObject<SUI::Label>("uctState17:lblOverlay");
    state18OverlayLabel = objectList->getObject<SUI::Label>("uctState18:lblOverlay");
    state19OverlayLabel = objectList->getObject<SUI::Label>("uctState19:lblOverlay");


}

void SUI::SSMTabView::loadGroup2Objects(SUI::ObjectList* objectList) {


       state21 = objectList->getObject<SUI::UserControl>("uctState11");
       state22 = objectList->getObject<SUI::UserControl>("uctState12");
       state23 = objectList->getObject<SUI::UserControl>("uctState13");
       state24 = objectList->getObject<SUI::UserControl>("uctState14");
       state25 = objectList->getObject<SUI::UserControl>("uctState15");
       state26 = objectList->getObject<SUI::UserControl>("uctState16");
       state27 = objectList->getObject<SUI::UserControl>("uctState17");
       state28 = objectList->getObject<SUI::UserControl>("uctState18");
       state29 = objectList->getObject<SUI::UserControl>("uctState19");

       state21Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
       state22Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
       state23Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
       state24Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
       state25Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
       state26Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
       state27Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
       state28Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
       state29Btn = objectList->getObject<SUI::Button>("uctState19:btnState");

       state21Bic = objectList->getObject<SUI::BusyIndicator>("uctState11:bic");
       state22Bic = objectList->getObject<SUI::BusyIndicator>("uctState12:bic");
       state23Bic = objectList->getObject<SUI::BusyIndicator>("uctState13:bic");
       state24Bic = objectList->getObject<SUI::BusyIndicator>("uctState14:bic");
       state25Bic = objectList->getObject<SUI::BusyIndicator>("uctState15:bic");
       state26Bic = objectList->getObject<SUI::BusyIndicator>("uctState16:bic");
       state27Bic = objectList->getObject<SUI::BusyIndicator>("uctState17:bic");
       state28Bic = objectList->getObject<SUI::BusyIndicator>("uctState18:bic");
       state29Bic = objectList->getObject<SUI::BusyIndicator>("uctState19:bic");

       state21OverlayLabel = objectList->getObject<SUI::Label>("uctState11:lblOverlay");
       state22OverlayLabel = objectList->getObject<SUI::Label>("uctState12:lblOverlay");
       state23OverlayLabel = objectList->getObject<SUI::Label>("uctState13:lblOverlay");
       state24OverlayLabel = objectList->getObject<SUI::Label>("uctState14:lblOverlay");
       state25OverlayLabel = objectList->getObject<SUI::Label>("uctState15:lblOverlay");
       state26OverlayLabel = objectList->getObject<SUI::Label>("uctState16:lblOverlay");
       state27OverlayLabel = objectList->getObject<SUI::Label>("uctState17:lblOverlay");
       state28OverlayLabel = objectList->getObject<SUI::Label>("uctState18:lblOverlay");
       state29OverlayLabel = objectList->getObject<SUI::Label>("uctState19:lblOverlay");

}

void SUI::SSMTabView::loadGroup3Objects(SUI::ObjectList* objectList) {

       state31 = objectList->getObject<SUI::UserControl>("uctState11");
       state32 = objectList->getObject<SUI::UserControl>("uctState12");
       state33 = objectList->getObject<SUI::UserControl>("uctState13");
       state34 = objectList->getObject<SUI::UserControl>("uctState14");
       state35 = objectList->getObject<SUI::UserControl>("uctState15");
       state36 = objectList->getObject<SUI::UserControl>("uctState16");
       state37 = objectList->getObject<SUI::UserControl>("uctState17");
       state38 = objectList->getObject<SUI::UserControl>("uctState18");
       state39 = objectList->getObject<SUI::UserControl>("uctState19");

       state31Btn = objectList->getObject<SUI::Button>("uctState11:btnState");
       state32Btn = objectList->getObject<SUI::Button>("uctState12:btnState");
       state33Btn = objectList->getObject<SUI::Button>("uctState13:btnState");
       state34Btn = objectList->getObject<SUI::Button>("uctState14:btnState");
       state35Btn = objectList->getObject<SUI::Button>("uctState15:btnState");
       state36Btn = objectList->getObject<SUI::Button>("uctState16:btnState");
       state37Btn = objectList->getObject<SUI::Button>("uctState17:btnState");
       state38Btn = objectList->getObject<SUI::Button>("uctState18:btnState");
       state39Btn = objectList->getObject<SUI::Button>("uctState19:btnState");

       state31Bic = objectList->getObject<SUI::BusyIndicator>("uctState11:bic");
       state32Bic = objectList->getObject<SUI::BusyIndicator>("uctState12:bic");
       state33Bic = objectList->getObject<SUI::BusyIndicator>("uctState13:bic");
       state34Bic = objectList->getObject<SUI::BusyIndicator>("uctState14:bic");
       state35Bic = objectList->getObject<SUI::BusyIndicator>("uctState15:bic");
       state36Bic = objectList->getObject<SUI::BusyIndicator>("uctState16:bic");
       state37Bic = objectList->getObject<SUI::BusyIndicator>("uctState17:bic");
       state38Bic = objectList->getObject<SUI::BusyIndicator>("uctState18:bic");
       state39Bic = objectList->getObject<SUI::BusyIndicator>("uctState19:bic");

       state31OverlayLabel = objectList->getObject<SUI::Label>("uctState11:lblOverlay");
       state32OverlayLabel = objectList->getObject<SUI::Label>("uctState12:lblOverlay");
       state33OverlayLabel = objectList->getObject<SUI::Label>("uctState13:lblOverlay");
       state34OverlayLabel = objectList->getObject<SUI::Label>("uctState14:lblOverlay");
       state35OverlayLabel = objectList->getObject<SUI::Label>("uctState15:lblOverlay");
       state36OverlayLabel = objectList->getObject<SUI::Label>("uctState16:lblOverlay");
       state37OverlayLabel = objectList->getObject<SUI::Label>("uctState17:lblOverlay");
       state38OverlayLabel = objectList->getObject<SUI::Label>("uctState18:lblOverlay");
       state39OverlayLabel = objectList->getObject<SUI::Label>("uctState19:lblOverlay");
}


void SUI::SSMTabView::loadObjects(SUI::ObjectList* objectList) {


   row1Container = objectList->getObject<SUI::Container>("row1Container");
   row2Container = objectList->getObject<SUI::Container>("row2Container");
   row3Container = objectList->getObject<SUI::Container>("row3Container");

   row1 = objectList->getObject<SUI::GroupBox>("gbxRow1");
   row2 = objectList->getObject<SUI::GroupBox>("gbxRow2");
   row3 = objectList->getObject<SUI::GroupBox>("gbxRow3");

   groupLabel1 = objectList->getObject<SUI::Label>("lblTitleGroup1");
   groupLabel2 = objectList->getObject<SUI::Label>("lblTitleGroup2");
   groupLabel3 = objectList->getObject<SUI::Label>("lblTitleGroup3");

   gbxCurrentState = objectList->getObject<SUI::GroupBox>("gbxTransitionCompleted");
   gbxTransitionState = objectList->getObject<SUI::GroupBox>("gbxTransition");

   lblCurrentStateText = objectList->getObject<SUI::Label>("lblCurrentStateText");
   lblFromText = objectList->getObject<SUI::Label>("lblFromText");
   lblToText = objectList->getObject<SUI::Label>("lblToText");
   lblStartTimeText = objectList->getObject<SUI::Label>("lblStartTimeText");
   lblExpectedDurationText = objectList->getObject<SUI::Label>("lblExpectedTimeText");
   lblElapsedTimeText = objectList->getObject<SUI::Label>("lblElapsedTimeText");

}


#endif // IGSXGUIXSUI_MOC_SYSTEMSTATEMANAGERTABVIEW_CPP

