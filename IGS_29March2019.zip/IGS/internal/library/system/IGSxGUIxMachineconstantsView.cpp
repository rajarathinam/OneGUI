/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.cpp
| Author       : Raja
| Description  : Implementation of Machineconstants view
|
| ! \file        IGSxGUIxMachineconstantsView.cpp
| ! \brief       Implementation of Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITextArea.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/predicate.hpp>
#include <boost/regex.hpp>
#include <boost/range/algorithm/count.hpp>
#include <string>
#include <vector>
#include <utility>
#include <iomanip>
#include <algorithm>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMachineconstantsView.hpp"
#include "IGSxGUIxMoc_MachineconstantsView.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_TITLE = "lblTitle";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_NOBUTTON = "btnNo";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_YESBUTTON = "btnYes";
const std::string IGSxGUI::MachineconstantsView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::MachineconstantsView::DIALOG_ID_MESSAGE = "lblMessage";
const std::string IGSxGUI::MachineconstantsView::COLOR_LINEEDIT_CANCEL = "#8c8c8c";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR = "#AAAAAA";
const std::string IGSxGUI::MachineconstantsView::DIALOG_TITLE = "Cancel pending changes?";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETER_FOUND = "parameter found";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETER = "searchparameter";
const std::string IGSxGUI::MachineconstantsView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_BLUEBG = "BlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETERS_FOUND = "parameters found";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_ORANGEBG = "OrangeBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::STRING_PENDINGPARAMLABEL_STYLE = "pendingParameter";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCHPARAM_NOITALIC = "searchparameterNoItalic";
const std::string IGSxGUI::MachineconstantsView::STYLE_BUTTON_HOVERBLUEBG = "HoverBlueBackgroundButton";
const std::string IGSxGUI::MachineconstantsView::DIALOG_MESSAGE = "All changed values will be discarded";
const std::string IGSxGUI::MachineconstantsView::CANCELPOPUP_LOAD_FILE = "IGSxGUIxMachineConstantPopup.xml";
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEW_LOAD_FILE = "IGSxGUIxMachineconstants.xml";
const std::string IGSxGUI::MachineconstantsView::MACHINECONSTANTSVIEWMODAL_LOAD_FILE = "IGSxGUIxMachineConstantModalPopup.xml";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETERGREYBGITALIC = "searchparameterGreyBGItalic";
const std::string IGSxGUI::MachineconstantsView::STRING_MACHINECONSTANTSVIEW_SHOWN = "MachineconstantsView is Shown.";
const std::string IGSxGUI::MachineconstantsView::STRING_CLOSE_BUTTON_COLOR_CLICKED = "#FFFFFF";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_CLICKED = "PendingParameterCancelClicked";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERED = "PendingParameterCancelHovered";
const std::string IGSxGUI::MachineconstantsView::PENDINGPARAMCANCEL_HOVERLEFT = "PendingParameterCancelHoverLeft";
const std::string IGSxGUI::MachineconstantsView::COLOR_GREY_DARK = "#4d4d4d";
const std::string IGSxGUI::MachineconstantsView::STYLE_DISABLE_LABEL = "disableLabel";
const std::string IGSxGUI::MachineconstantsView::STYLE_DISABLE_BACKGROUND = "disableBackground";
const std::string IGSxGUI::MachineconstantsView::STYLE_AWESOME_ICONCOLOR = "#4d4d4d";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::MachineconstantsView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::MachineconstantsView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::MachineconstantsView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::MachineconstantsView::STYLE_SEARCH_PARAMETERGREYBGNONITALIC = "searchparameterGreyBGNonItalic";
const std::string IGSxGUI::MachineconstantsView::NOT_APPLICABLE_STR = "NA";
const std::string IGSxGUI::MachineconstantsView::FA_LINEEDIT_ERRORSTYLE = "floatArrayLeWarning";
const std::string IGSxGUI::MachineconstantsView::FLOAT_ARRAY_UI_FILE_NAME  = "IGSxGUIxFloatParameterPopup.xml";
const std::string IGSxGUI::MachineconstantsView::STRING_PARAMETERS = "Parameters";
const std::string IGSxGUI::MachineconstantsView::STRING_ALL_CATEGORIES = "ALL CATEGORIES";
const int IGSxGUI::MachineconstantsView::DIALOG_X = 0;
const int IGSxGUI::MachineconstantsView::DIALOG_Y = 60;
const int IGSxGUI::MachineconstantsView::ROW_HEIGHT = 40;
const int IGSxGUI::MachineconstantsView::MULTILINE_ROW_HEIGHT = 60;
const int IGSxGUI::MachineconstantsView::MULTILINE_ROW_HEIGHT_INCREASE = 20;
const int IGSxGUI::MachineconstantsView::BUTTON_SIZE = 24;
const int IGSxGUI::MachineconstantsView::SEARCH_BUTTON_SIZE = 18;
const int IGSxGUI::MachineconstantsView::DIALOG_WIDTH = 1920;
const int IGSxGUI::MachineconstantsView::DIALOG_HEIGHT = 130;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS = 18;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS_FLOAT_ARRAY = 16;
const int IGSxGUI::MachineconstantsView::MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 720;
const int IGSxGUI::MachineconstantsView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::MachineconstantsView::PENDINGPARAM_CLOSEBUTTON_SIZE = 20;
const int IGSxGUI::MachineconstantsView::PENDINGPARAM_BI_TIME = 10000;
const size_t IGSxGUI::MachineconstantsView::MAX_CHARS_OF_PARAMETERTREE_CELL = 20;
const int IGSxGUI::MachineconstantsView::MAX_CHARS_OF_PARAMS_PER_LINE = 40;
const int IGSxGUI::MachineconstantsView::BOOL_TYPE_DIALOG = 1;
const int IGSxGUI::MachineconstantsView::MAXIMUM_DOUBLE_PRECISION = 8;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 670;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_TABLE_YPOSITION = 75;
const int IGSxGUI::MachineconstantsView::PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE = 50;
const size_t IGSxGUI::MachineconstantsView::MAX_VISIBLE_CHARS_OF_PARAM_VALUE = 14;
const int IGSxGUI::MachineconstantsView::SEARCH_PARAMETER_TEXTEDIT_TIMEOUT_MS = 500;
const int IGSxGUI::MachineconstantsView::COLUMN_WIDTH = 173;
const int IGSxGUI::MachineconstantsView::COLUMN_HEIGHT = 161;

namespace IGSxGUI
{

class BreadCrum
{
  public:
    static const int CRUM_DISTANCE = 5;
    static const int CRUM_MARGIN = 17;
    static const int PIXELS_PER_CHARACTER = 12;
    static const int SLASH_WIDTH = 8;

  public:
    BreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum, SUI::Button* btnPrevious) :
        m_lblSlash(lblSlash), m_btnBreadCrum(btnBreadCrum), m_btnPrevious(btnPrevious)
    {
    }

    SUI::Button* getMainButton()
    {
        return m_btnBreadCrum;
    }

    void Reposition(std::string strCrum)
    {
        // hide the slash if the bread crum that follows is empty
        m_lblSlash->setVisible(!strCrum.empty());
        SUI::Rect rectSlash = m_lblSlash->getGeometry();
        rectSlash.setX(m_btnPrevious->getGeometry().getX() + m_btnPrevious->getGeometry().getWidth() + CRUM_DISTANCE);
        rectSlash.setWidth(SLASH_WIDTH);
        m_lblSlash->setGeometry(rectSlash);
        m_btnBreadCrum->setText(strCrum);
        SUI::Rect rectButton = m_btnBreadCrum->getGeometry();
        rectButton.setX(rectSlash.getX() + rectSlash.getWidth() + CRUM_DISTANCE);
        rectButton.setWidth(IGSxGUI::Util::getButtonTextWidth(m_btnBreadCrum, strCrum) + CRUM_MARGIN);
        m_btnBreadCrum->setGeometry(rectButton);
    }

  private:
    SUI::Label*  m_lblSlash;
    SUI::Button* m_btnBreadCrum;
    SUI::Button* m_btnPrevious;
};

class BreadCrumResizer
{
  public:
    explicit BreadCrumResizer(SUI::Button* btnStart) : m_btnStart(btnStart)
    {
    }

    void AddBreadCrum(SUI::Label* lblSlash, SUI::Button* btnBreadCrum)
    {
        m_breadCrums.push_back(new BreadCrum(lblSlash, btnBreadCrum,
                                             m_breadCrums.size() == 0 ? m_btnStart : m_breadCrums[m_breadCrums.size()-1]->getMainButton()));
    }

    void RepositionAll(const std::vector<std::string>& breadCrumTitles)
    {
        m_btnStart->setText(breadCrumTitles[0]);
        SUI::Rect rectButton = m_btnStart->getGeometry();
        int pixelsWide = IGSxGUI::Util::getButtonTextWidth(m_btnStart, breadCrumTitles[0]);
        rectButton.setWidth(pixelsWide + BreadCrum::CRUM_MARGIN);
        m_btnStart->setGeometry(rectButton);
        for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
            m_breadCrums[i]->Reposition(i < static_cast<int>(breadCrumTitles.size() - 1) ? breadCrumTitles[i + 1] : "");
        }
    }

    ~BreadCrumResizer()
    {
        for (int i = 0; i < static_cast<int>(m_breadCrums.size()); ++i) {
            delete m_breadCrums[i];
        }
    }

  private:
    SUI::Button*            m_btnStart;
    std::vector<BreadCrum*> m_breadCrums;
};

}  // namespace IGSxGUI

IGSxGUI::MachineconstantsView::MachineconstantsView(IGSxGUI::MachineconstantsManager* pMachineconstantsManager):
    sui(new SUI::MachineconstantsView),
    m_selectedParameterRowNum(-1),
    m_selectedPendingParameterRowNum(-1),
    m_resetButtonPressedFlag(false),
    m_parameterview(pMachineconstantsManager),
    m_historyview(pMachineconstantsManager),
    m_searchText(""),
    m_breadCrumResizer(NULL),
    m_isCtrlKeyPressed(false),
    m_SearchElapsedTime(SUI::Timer::createTimer()),
    m_previousScrollBarPosition(0),
    m_currentScrollBarPosition(0),
    m_currentRow(-1),
    m_shiftKeyPressed(false)
{
    m_pMachineconstantsManager = pMachineconstantsManager;
    m_dialog = SUI::UILoader::loadUI(CANCELPOPUP_LOAD_FILE.c_str());
    m_dialogModality = SUI::UILoader::loadUI(MACHINECONSTANTSVIEWMODAL_LOAD_FILE.c_str());
    m_dialogModalityForHistory = SUI::UILoader::loadUI(MACHINECONSTANTSVIEWMODAL_LOAD_FILE.c_str());
    doBasicFloatArrayLoad();
    m_floatArrayCurrentLineEditIndex = 0;
    m_floatArrayPreviousLineEditIndex = 0;
    m_SearchElapsedTime->timeout = boost::bind(&MachineconstantsView::onSearchTextTimeElapsed, this);
}

IGSxGUI::MachineconstantsView::~MachineconstantsView()
{

    m_SearchElapsedTime->stop();
    m_SearchElapsedTime->timeout = NULL;
    if (m_breadCrumResizer != NULL) {
        delete m_breadCrumResizer;
    }
}

void IGSxGUI::MachineconstantsView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (bIsFirstTimeDisplay)
    {
        sui->setupSUIContainer(MACHINECONSTANTSVIEW_LOAD_FILE.c_str(), MainScreenContainer);
        init();
        IGSxGUI::Util::setScrollbarWidthOfTable(sui->tawParameterTree, 20);
        IGSxGUI::Util::setScrollbarWidthOfTable(sui->tawMCPendingParam, 20);
        IGSxGUI::Util::setParameterTableEventHandler(sui->gbxPageOne, sui->tawParameters,sui->scbParametersTable, this);
        if (!m_searchText.empty()) {
            sui->lneSearchParameterText->setText(m_searchText);
        }
    }
    IGS_INFO(STRING_MACHINECONSTANTSVIEW_SHOWN);
}

void IGSxGUI::MachineconstantsView::disableParamsSaveButtons(bool enable)
{
    setPendingParamSaveBtnEnable(enable);
    setPendingParamFinalSaveBtnEnable(enable);
    sui->btnRetryPendingParamSave->setEnabled(enable);
}

void IGSxGUI::MachineconstantsView::setPendingParamSaveBtnEnable(bool enable)
{
    if (enable) {
        sui->uctSaveButton->clicked = boost::bind(&MachineconstantsView::onUCTSaveButtonClicked, this);
        sui->uctSaveButton->pressed = boost::bind(&MachineconstantsView::onUCTSaveButtonPressed, this);
        sui->uctSaveButton->hoverLeft = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOff, this);
        sui->uctSaveButton->hoverEntered = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOn, this);
        IGSxGUI::Util::setAwesome(sui->lblSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
        sui->lblSaveText->setStyleSheetClass("");
        sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
        sui->gbxSaveButton->setEnabled(true);
    } else {
        sui->uctSaveButton->clicked = NULL;
        sui->uctSaveButton->pressed = NULL;
        sui->uctSaveButton->hoverLeft = NULL;
        sui->uctSaveButton->hoverEntered = NULL;
        IGSxGUI::Util::setAwesome(sui->lblSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
        sui->lblSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
        sui->gbxSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
        sui->gbxSaveButton->setEnabled(false);
    }
}

void IGSxGUI::MachineconstantsView::setPendingParamFinalSaveBtnEnable(bool enable)
{
    std::string name = sui->lnePendingParamSaveName->getText();
    boost::trim(name);
    std::string reason = sui->txaPendingParamSaveChangeReason->getText();
    boost::trim(reason);
    if ((name.empty()) || (reason.empty()) || (!enable)) {
        sui->uctPendingParamFinalSave->clicked = NULL;
        sui->uctPendingParamFinalSave->hoverLeft = NULL;
        sui->uctPendingParamFinalSave->hoverEntered = NULL;
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
        sui->gbxPendingParamFinalSaveButton->setEnabled(false);
    } else {
        sui->uctPendingParamFinalSave->clicked = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveClicked, this);
        sui->uctPendingParamFinalSave->hoverLeft = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverLeft, this);
        sui->uctPendingParamFinalSave->hoverEntered = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverEntered, this);
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass("");
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
        sui->gbxPendingParamFinalSaveButton->setEnabled(true);
    }
}

void IGSxGUI::MachineconstantsView::init()
{
    IGSxGUI::MachineconstantsManager::registerToParameterUpdated(boost::bind(&IGSxGUI::MachineconstantsView::updateViewOnParamSaveEventReceive, this));
    IGSxGUI::MachineconstantsManager::registerToWriteFinished(boost::bind(&IGSxGUI::MachineconstantsView::onWriteFineshedEventReceive, this, _1));
    IGSxGUI::MachineconstantsManager::registerToParamsSaveEnablityChanged(boost::bind(&IGSxGUI::MachineconstantsView::disableParamsSaveButtons, this, _1));
    IGSxGUI::HistorypopupView::registerToHistoryRowPressed(boost::bind(&IGSxGUI::MachineconstantsView::historyRowPressed, this, _1));

    breadCrumpButtonList.clear();
    breadCrumpButtonList.push_back(sui->btnBC1);
    breadCrumpButtonList.push_back(sui->btnBC2);
    breadCrumpButtonList.push_back(sui->btnBC3);
    breadCrumpButtonList.push_back(sui->btnBC4);
    breadCrumpButtonList.push_back(sui->btnBC5);
    breadCrumpButtonList.push_back(sui->btnBC6);
    m_breadCrumResizer = new IGSxGUI::BreadCrumResizer(sui->btnBC1);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash1, sui->btnBC2);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash2, sui->btnBC3);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash3, sui->btnBC4);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash4, sui->btnBC5);
    m_breadCrumResizer->AddBreadCrum(sui->lblBackSlash5, sui->btnBC6);
    sui->lblAllCategories->setVisible(false);
    IGSxGUI::Util::setAwesome(sui->lblBackImage, IGSxGUI::AwesomeIcon::AI_fa_angle_left, SUI::ColorEnum::White, 30);
    sui->lblBackImage->setVisible(false);
    sui->btnBack->setText("BACK");
    sui->btnBack->setVisible(false);
    sui->txaPendingParamSaveChangeReason->clearText();
    IGSxGUI::Util::setTextEditPaletteColor(sui->txaPendingParamSaveChangeReason, "#0AA8FB", "#FFFFFF");
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
    IGSxGUI::Util::setAwesome(sui->lblSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->btnPendingParamSaveNameLnEditCancel, IGSxGUI::AwesomeIcon::AI_fa_close, COLOR_LINEEDIT_CANCEL, 15);
    IGSxGUI::Util::setAwesome(sui->lblPendingParamErrorCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblPendingParamErrorCrossImage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
    sui->tawMCPendingParam->showGrid(false);
    sui->tawMCPendingParam->setRowVisible(0, false);
    sui->tawMCPendingParam->setListViewMode(false);
    IGSxGUI::Util::hideTableDefaultVerticalScrollbar(sui->tawParameters);
    setHandlers();
    showFinalSaveScreenItems(false);
    showSearchEntriesParameter(false);
    if (m_pendingParameterList.size() > 0) {
        showNoPendingParameterScreen(false);
        showSaveCancelButtons(true);
    } else {
        showNoPendingParameterScreen(true);
        showSaveCancelButtons(false);
    }
    IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
    sui->lblPendingParamFinalSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
    sui->gbxPendingParamFinalSaveButton->setEnabled(false);
    initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
    sui->tawParameterTree->showGrid(false);
    IGSxGUI::Util::disableTableItemsSelection(sui->tawParameterTree);
    onParameterTreeItemPressed(0);
}

void IGSxGUI::MachineconstantsView::setHandlers()
{
    std::vector<SUI::Widget*> paramTableWidgetVector;
    paramTableWidgetVector.push_back(sui->btnParameterName);
    paramTableWidgetVector.push_back(sui->btnParameterName2);
    paramTableWidgetVector.push_back(sui->btnParameterNameUpArrow);
    paramTableWidgetVector.push_back(sui->btnParameterNameDownArrow);
    paramTableWidgetVector.push_back(sui->scbParametersTable);
    paramTableWidgetVector.push_back(sui->btnParameterValue);
    paramTableWidgetVector.push_back(sui->gbxParamName);
    paramTableWidgetVector.push_back(sui->tawParameters);
    IGSxGUI::Util::parameterTableHeaderInstallEventFilter(paramTableWidgetVector);
    std::vector<SUI::Widget*> pendingParamTableWidgetVector;
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterName);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameUpArrow);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameDownArrow);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterNameUpDownArrow);
    pendingParamTableWidgetVector.push_back(sui->btnPendingParameterValue);
    pendingParamTableWidgetVector.push_back(sui->tawMCPendingParam);
    pendingParamTableWidgetVector.push_back(sui->gbxPendingParamName);

    IGSxGUI::Util::pendingParameterTableHeaderInstallEventFilter(pendingParamTableWidgetVector);
    sui->btnCancel->clicked = boost::bind(&MachineconstantsView::onCancelButtonPressed, this);
    sui->btnHistory->hoverLeft = boost::bind(&MachineconstantsView::onHistoryHoverLeft, this);
    sui->uctSaveButton->clicked = boost::bind(&MachineconstantsView::onUCTSaveButtonClicked, this);
    sui->uctSaveButton->pressed = boost::bind(&MachineconstantsView::onUCTSaveButtonPressed, this);
    sui->btnHistory->hoverEntered = boost::bind(&MachineconstantsView::onHistoryHoverEntered, this);
    sui->btnHistory->clicked = boost::bind(&MachineconstantsView::onHistoryPressed, this);
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->uctSaveButton->hoverLeft = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOff, this);
    sui->uctSaveButton->hoverEntered = boost::bind(&MachineconstantsView::onUCTSaveButtonHoverOn, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnPendingParamCancelSave->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnFinalSave, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->lnePendingParamSaveName->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveTxtChanged, this, _1);
    sui->btnPendingParamSaveNameLnEditCancel->clicked = boost::bind(&MachineconstantsView::PendingParamSaveNameLnEditCancel, this);
    sui->txaPendingParamSaveChangeReason->textChanged = boost::bind(&MachineconstantsView::PendingParamSaveChangeReasonTxtChanged, this, _1);
    sui->tawParameterTree->rowClicked = boost::bind(&MachineconstantsView::onParameterTreeItemPressed, this, _1);
    sui->btnBack->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    sui->btnBack->hoverEntered = boost::bind(&MachineconstantsView::onBackHoverEntered, this);
    sui->btnBack->hoverLeft = boost::bind(&MachineconstantsView::onBackHoverLeft, this);
    sui->lblBackImage->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    m_parameterview.registerForValueChanged(boost::bind(&MachineconstantsView::onParameterValueChanged, this, _1, _2));
    sui->btnBC1->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump1HoverEntered, this);
    sui->btnBC2->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump2HoverEntered, this);
    sui->btnBC3->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump3HoverEntered, this);
    sui->btnBC4->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump4HoverEntered, this);
    sui->btnBC5->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump5HoverEntered, this);
    sui->btnBC6->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump6HoverEntered, this);
    sui->btnBC1->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump1HoverLeft, this);
    sui->btnBC2->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump2HoverLeft, this);
    sui->btnBC3->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump3HoverLeft, this);
    sui->btnBC4->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump4HoverLeft, this);
    sui->btnBC5->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump5HoverLeft, this);
    sui->btnBC6->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump6HoverLeft, this);
    sui->btnBC1->clicked = boost::bind(&MachineconstantsView::onBreadCrump1Clicked, this);
    sui->btnBC2->clicked = boost::bind(&MachineconstantsView::onBreadCrump2Clicked, this);
    sui->btnBC3->clicked = boost::bind(&MachineconstantsView::onBreadCrump3Clicked, this);
    sui->btnBC4->clicked = boost::bind(&MachineconstantsView::onBreadCrump4Clicked, this);
    sui->btnBC5->clicked = boost::bind(&MachineconstantsView::onBreadCrump5Clicked, this);
    sui->btnBC6->clicked = boost::bind(&MachineconstantsView::onBreadCrump6Clicked, this);
    sui->btnRetryPendingParamSave->clicked = boost::bind(&MachineconstantsView::pendingParamRetrySave, this);
    sui->btnCancelPendingParamSave->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage, this);
    sui->lblPendingParamErrorCloseImage->clicked = boost::bind(&MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage, this);
    sui->btnParameterName->clicked = boost::bind(&MachineconstantsView::sortParamsDescending, this);
    sui->btnParameterName2->clicked = boost::bind(&MachineconstantsView::sortParamsAscending, this);
    IGSxGUI::Util::setAwesome(sui->btnParameterNameUpArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnParameterNameDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, "#1B3E93", 11);
    sui->btnParameterNameUpArrow->clicked = boost::bind(&MachineconstantsView::sortParamsDescending, this);
    sui->btnParameterNameDownArrow->clicked = boost::bind(&MachineconstantsView::sortParamsAscending, this);
    sui->btnPendingParameterName->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameUpArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, "#1B3E93", 11);
    IGSxGUI::Util::setAwesome(sui->btnPendingParameterNameUpDownArrow, IGSxGUI::AwesomeIcon::AI_fa_sort_default, "#1B3E93", 11);
    sui->btnPendingParameterNameUpArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    sui->btnPendingParameterNameDownArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
    sui->btnPendingParameterNameUpDownArrow->clicked = boost::bind(&MachineconstantsView::sortPendingParams, this);
}

void IGSxGUI::MachineconstantsView::onCancelYesPressed()
{
    removePendingParamTableRows();
    showSaveCancelButtons(false);
    showNoPendingParameterScreen(true);
    m_pendingParameterList.clear();
    m_dialog->close();
    m_dialogModality->close();
}

void IGSxGUI::MachineconstantsView::updateViewOnParamSaveEventReceive()
{
    for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(paramname);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + paramname;
        } else {
            fullName = paramname;
        }
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (!parameterData->isFailed() && parameterData->getCurrentValue()->ToString() == parameterData->getPreviousValue()->ToString()) {
            std::string paramvalue = parameterData->getCurrentValue()->ToString();
            IGSxGUI::ITEMTYPE type = parameterData->getValueType();
            if (type == IGSxGUI::TYPE_double) {
                IGSxGUI::Util::adjustDoublePrecision(paramvalue);
            } else if (type == IGSxGUI::TYPE_floatarray) {
                std::vector<std::string> values;
                boost::split(values, paramvalue, boost::is_any_of(","));
                paramvalue = "";
                for (unsigned int i = 0; i < values.size(); ++i) {
                    std::string value = values[i];
                    IGSxGUI::Util::adjustDoublePrecision(value);
                    paramvalue = paramvalue + "," + value;
                }
                paramvalue.erase(0, 1);
            }
            formatParamValue(widget, paramvalue, COLUMN_WIDTH);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
            parameterData->resetUpdateFlag();
        }
        else if (parameterData->isFailed())
        {
           IGS_INFO("updateViewOnParamSaveEventReceive() - parameterData->isFailed() = TRUE for paramterName:" + parameterData->getName());
        }
        else
        {
           IGS_INFO("updateViewOnParamSaveEventReceive() - Currentvalue:" + parameterData->getCurrentValue()->ToString() + " PreviousValue:" + parameterData->getPreviousValue()->ToString());
        }
        if (parameterData->deviatesFromDefault()) {
            IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
        } else {
            IGSxGUI::Util::setParameterUCTGreyStyle(widget, 1);
        }
    }
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
    return;
}

void IGSxGUI::MachineconstantsView::setDefaultPropertiesWhenUpdatingParamTable()
{
    sui->scbParametersTable->valueChanged = boost::bind(&MachineconstantsView::onValueChanged, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&MachineconstantsView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&MachineconstantsView::onSearchTextEditFinished, this);
    sui->btnParameterName->setEnabled(true);
    sui->btnParameterName2->setEnabled(true);
    sui->btnParameterNameUpArrow->setEnabled(true);
    sui->btnParameterNameDownArrow->setEnabled(true);
    sui->tawParameterTree->rowClicked = boost::bind(&MachineconstantsView::onParameterTreeItemPressed, this, _1);
    sui->btnBack->clicked = boost::bind(&MachineconstantsView::onBackPressed, this);
    sui->btnBC1->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump1HoverEntered, this);
    sui->btnBC2->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump2HoverEntered, this);
    sui->btnBC3->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump3HoverEntered, this);
    sui->btnBC4->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump4HoverEntered, this);
    sui->btnBC5->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump5HoverEntered, this);
    sui->btnBC6->hoverEntered = boost::bind(&MachineconstantsView::onBreadCrump6HoverEntered, this);
    sui->btnBC1->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump1HoverLeft, this);
    sui->btnBC2->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump2HoverLeft, this);
    sui->btnBC3->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump3HoverLeft, this);
    sui->btnBC4->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump4HoverLeft, this);
    sui->btnBC5->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump5HoverLeft, this);
    sui->btnBC6->hoverLeft = boost::bind(&MachineconstantsView::onBreadCrump6HoverLeft, this);
    sui->btnBC1->clicked = boost::bind(&MachineconstantsView::onBreadCrump1Clicked, this);
    sui->btnBC2->clicked = boost::bind(&MachineconstantsView::onBreadCrump2Clicked, this);
    sui->btnBC3->clicked = boost::bind(&MachineconstantsView::onBreadCrump3Clicked, this);
    sui->btnBC4->clicked = boost::bind(&MachineconstantsView::onBreadCrump4Clicked, this);
    sui->btnBC5->clicked = boost::bind(&MachineconstantsView::onBreadCrump5Clicked, this);
    sui->btnBC6->clicked = boost::bind(&MachineconstantsView::onBreadCrump6Clicked, this);
}

void IGSxGUI::MachineconstantsView::saveButtonPressedOnPendingParamFinalSaveScreen()
{
    uctPendingParamFinalSaveClicked();
}

void IGSxGUI::MachineconstantsView::cancelButtonPressedOnPendingParamFinalSaveScreen()
{
    onCancelPressedOnFinalSave();
}

void IGSxGUI::MachineconstantsView::updateParameterTableOnCancelingFinalSave()
{
    setDefaultPropertiesWhenUpdatingParamTable();
    int value = 0;
    if (sui->scbParametersTable->isVisible()) {
        value = sui->scbParametersTable->getValue();
    }
    std::vector<ParameterData*> collection = m_pMachineconstantsManager->getParameterData();
    std::vector<ParameterData*>::iterator it = collection.begin();
    std::advance(it, value);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row, ++it) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        widget->setEnabled(true);
        setUCTHandlers(widget, row);
        if ((*it)->isReadOnly()) {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        } else {
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
            if ((*it)->getDefaultValue()->ToString() != (*it)->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::updateParameterTable()
{
    setDefaultPropertiesWhenUpdatingParamTable();
    int value = 0;
    if (sui->scbParametersTable->isVisible()) {
        value = sui->scbParametersTable->getValue();
    }
    std::vector<ParameterData*> collection = m_pMachineconstantsManager->getParameterData();
    std::vector<ParameterData*>::iterator it = collection.begin();
    if (!m_searchText.empty()) {
        m_pMachineconstantsManager->searchForParameters(m_searchText, &m_matchedparameters);
        collection = m_matchedparameters;
        it = collection.begin();
    }
    std::advance(it, value);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row, ++it) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        widget->setEnabled(true);
        setUCTHandlers(widget, row);
        if ((*it)->isReadOnly()) {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        } else {
            IGSxGUI::Util::setParameterUCTGroupBoxNormalStyle(widget);
        }
    }
}

void IGSxGUI::MachineconstantsView::onCancelButtonPressed()
{
    createPopup(DIALOG_TITLE, DIALOG_MESSAGE);
    m_dialogModality->show();
    m_dialog->show();
}

void IGSxGUI::MachineconstantsView::showSaveCancelButtons(bool bShow)
{
    sui->btnCancel->setVisible(bShow);
    sui->uctSaveButton->setVisible(bShow);
    setPendingParamSaveBtnEnable(m_pMachineconstantsManager->isParamSavingEnabled());
}

void IGSxGUI::MachineconstantsView::showPendingParamWidgets(bool bShow)
{
    sui->tawMCPendingParam->setVisible(bShow);
    sui->gbxPendingParamName->setVisible(bShow);
    sui->btnPendingParameterValue->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenItems(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamSaveNameLnEdit->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(bShow);
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::showSearchEntriesParameter(bool bShow)
{
    sui->lblEntriesFound->setVisible(bShow);
    if (bShow) {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
    }
}

void IGSxGUI::MachineconstantsView::showNoPendingParameterScreen(bool bShow)
{
    sui->btnNoPendingParameters->setVisible(bShow);
    sui->tawMCPendingParam->setVisible(!bShow);
    sui->gbxPendingParamName->setVisible(!bShow);
    sui->btnPendingParameterValue->setVisible(!bShow);
    if (bShow) {
        showFinalSaveScreenItems(false);
    }
}

void IGSxGUI::MachineconstantsView::createPopup(const std::string& title, const std::string& message)
{
    m_dialog->setWindowTitle(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_TITLE)->setText(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_ID_MESSAGE)->setText(message);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_YESBUTTON)->clicked = boost::bind(&MachineconstantsView::onCancelYesPressed, this);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_ID_NOBUTTON)->clicked = boost::bind(&MachineconstantsView::onCancelNoPressed, this);
    m_dialog->setModal(true);
    IGSxGUI::Util::setParent(m_dialog, sui->btnSearchAndClearIcon);
    IGSxGUI::Util::disableScrollbars(m_dialog);
    IGSxGUI::Util::setGeometry(m_dialog, DIALOG_X, DIALOG_Y, DIALOG_WIDTH, DIALOG_HEIGHT);
    IGSxGUI::Util::setWindowFrame(m_dialog, false);
}

void IGSxGUI::MachineconstantsView::onCancelNoPressed()
{
    m_dialog->close();
    m_dialogModality->close();
}

void IGSxGUI::MachineconstantsView::setUCTHandlers(SUI::Widget *widget, int row)
{
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&MachineconstantsView::onParameterRowPressed, this, row);
    usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onParameterUCTHoverEntered, this, row);
    usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onParameterUCTHoverLeft, this, row);
}

void IGSxGUI::MachineconstantsView::populateData(std::vector<ParameterData*>::iterator it, int row)
{
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string paramvalue = (*it)->getPreviousValue()->ToString();
    IGSxGUI::ITEMTYPE type = (*it)->getValueType();
    if (type == IGSxGUI::TYPE_double) {
        IGSxGUI::Util::adjustDoublePrecision(paramvalue);
    } else if (type == IGSxGUI::TYPE_floatarray) {
        std::vector<std::string> values;
        boost::split(values, paramvalue, boost::is_any_of(","));
        paramvalue = "";
        for (unsigned int i = 0; i < values.size(); ++i) {
            std::string value = values[i];
            IGSxGUI::Util::adjustDoublePrecision(value);
            paramvalue = paramvalue + "," + value;
        }
        paramvalue.erase(0, 1);
    }
    formatParamValue(widget, paramvalue, COLUMN_WIDTH);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
    std::pair <std::string, int> formattedText = formatParamName((*it)->getDisplayName());
    int rowHeight = ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    IGSxGUI::Util::setRowHeight(sui->tawParameters, row, rowHeight);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
    IGSxGUI::Util::setBottomBorderForUserControl(widget, rowHeight);
    setUCTHandlers(widget, row);
    // Commenting this line , as search box losing focus not implemented.
    // IGSxGUI::Util::setUserControlFocusPolicy(widget);


    if ((*it)->isSelected()) {
        if ((*it)->isReadOnly()) {
            IGSxGUI::Util::setParameterUCTReadOnlySelectedStyle(widget);
            if ((*it)->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
            }
        } else {
            IGSxGUI::Util::setParameterUCTClickedStyle(widget);
            if ((*it)->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
            }
        }
    } else {
        if ((*it)->isReadOnly()) {
            IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
            if ((*it)->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
            }
        } else {
            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
            if ((*it)->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::initializeTableRows(int rows, std::vector<ParameterData*> collection)
{
    if (rows <= 0) {
        sui->tawParameters->setVisible(false);
        sui->scbParametersTable->setVisible(false);
    } else {
        sui->tawParameters->showGrid(false);
        sui->tawParameters->setVisible(true);
        int noofrows = rows;
        if (rows > MAX_VISIBLE_ROWS) {
            noofrows = MAX_VISIBLE_ROWS;
            sui->scbParametersTable->setValue(0);
            sui->scbParametersTable->setVisible(true);
            sui->scbParametersTable->setMinValue(0);
            sui->scbParametersTable->setMaxValue(static_cast<int>(collection.size()) - MAX_VISIBLE_ROWS);
            sui->scbParametersTable->setPageStep(1);
        } else {
            sui->scbParametersTable->setVisible(false);
        }
        sui->tawParameters->removeRows(1, (sui->tawParameters->rowCount() - 1));
        for (int i = 0; i < (noofrows - 1); ++i) {
            sui->tawParameters->appendRow();
        }
    }
    if (rows > MAX_VISIBLE_ROWS) {
        rows  = MAX_VISIBLE_ROWS;
    }
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    int totalRowHeight = 0;
    int max_rows = 0;
    for (; max_rows < rows; ++max_rows, ++beg_it) {
        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            break;
        }
        std::pair <std::string, int> formattedText = formatParamName((*beg_it)->getDisplayName());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    }
    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        max_rows--;
        // display the scrollbar when number of items are <=MAX_VISIBLE_ROWS and all items do not fit in the visible space
        if ((static_cast<int>(collection.size()) <=  MAX_VISIBLE_ROWS) && (max_rows < static_cast<int>(collection.size()))) {
            sui->scbParametersTable->setValue(0);
            sui->scbParametersTable->setVisible(true);
            sui->scbParametersTable->setMinValue(0);
            sui->scbParametersTable->setMaxValue(static_cast<int>(collection.size()) - max_rows);
        }
    }
    if (max_rows < rows) {
        sui->tawParameters->removeRows(max_rows, rows - max_rows);
    }
    setData(0, max_rows, collection);
}

void IGSxGUI::MachineconstantsView::setData(int value, int rows, std::vector<ParameterData*> collection)
{
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    std::vector<ParameterData*>::iterator it = collection.end();
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
    }
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonClicked()
{
    std::vector<SUI::Widget*> pendingParamSaveScreenWidgetVector;
    pendingParamSaveScreenWidgetVector.push_back(sui->lnePendingParamSaveName);
    pendingParamSaveScreenWidgetVector.push_back(sui->txaPendingParamSaveChangeReason);
    pendingParamSaveScreenWidgetVector.push_back(sui->gbxPendingParamFinalSaveButton);
    pendingParamSaveScreenWidgetVector.push_back(sui->btnPendingParamCancelSave);
    IGSxGUI::Util::pendingParameterSaveScreenInstallEventFileter(pendingParamSaveScreenWidgetVector, this);
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
    for (int row = 0; row < sui->tawParameters->rowCount(); ++row) {
        SUI::Widget *widget = dynamic_cast<SUI::Widget*>(sui->tawParameters->getWidgetItem(row, 0));
        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + name;
        } else {
            fullName = name;
        }
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            if (parameterData->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
            parameterData->setSelected(false);
        }
        SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
        usercontrol->clicked = NULL;
        usercontrol->hoverLeft = NULL;
        usercontrol->hoverEntered = NULL;
    }
    sui->scbParametersTable->valueChanged = NULL;
    sui->lneSearchParameterText->textChanged = NULL;
    sui->lneSearchParameterText->editingFinished = NULL;
    sui->lneSearchParameterText->setEnabled(false);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETERGREYBGITALIC);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETERGREYBGNONITALIC);
    }
    sui->btnParameterName->setEnabled(false);
    sui->btnParameterName2->setEnabled(false);
    sui->btnParameterNameUpArrow->setEnabled(false);
    sui->btnParameterNameDownArrow->setEnabled(false);
    sui->tawParameterTree->rowClicked = NULL;
    sui->btnBack->clicked = NULL;
    sui->btnBC1->hoverEntered = NULL;
    sui->btnBC2->hoverEntered = NULL;
    sui->btnBC3->hoverEntered = NULL;
    sui->btnBC4->hoverEntered = NULL;
    sui->btnBC5->hoverEntered = NULL;
    sui->btnBC6->hoverEntered = NULL;
    sui->btnBC1->hoverLeft = NULL;
    sui->btnBC2->hoverLeft = NULL;
    sui->btnBC3->hoverLeft = NULL;
    sui->btnBC4->hoverLeft = NULL;
    sui->btnBC5->hoverLeft = NULL;
    sui->btnBC6->hoverLeft = NULL;
    sui->btnBC1->clicked = NULL;
    sui->btnBC2->clicked = NULL;
    sui->btnBC3->clicked = NULL;
    sui->btnBC4->clicked = NULL;
    sui->btnBC5->clicked = NULL;
    sui->btnBC6->clicked = NULL;
    if (sui->lnePendingParamSaveName->getText().empty()) {
        sui->lblPendingParamSaveNameLnEdit->setVisible(true);
        sui->btnPendingParamSaveNameLnEditCancel->setVisible(false);
    } else {
        sui->lblPendingParamSaveNameLnEdit->setVisible(false);
        sui->btnPendingParamSaveNameLnEditCancel->setVisible(true);
    }
    if (sui->txaPendingParamSaveChangeReason->getText().empty()) {
        sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(true);
    }
    sui->btnSearchAndClearIcon->clicked = NULL;
    sui->btnSearchAndClearIcon->hoverLeft = NULL;
    sui->btnSearchAndClearIcon->hoverEntered = NULL;
    showSaveCancelButtons(false);
    showPendingParamWidgets(false);
    showFinalSaveScreenPendingParams(true);
    sui->lnePendingParamSaveName->setFocus();
    IGSxGUI::Util::selectLineEditText(sui->lnePendingParamSaveName);
}

void IGSxGUI::MachineconstantsView::showFinalSaveScreenPendingParams(bool bShow)
{
    sui->lblPendingParamSaveName->setVisible(bShow);
    sui->lnePendingParamSaveName->setVisible(bShow);
    sui->uctPendingParamFinalSave->setVisible(bShow);
    sui->btnPendingParamCancelSave->setVisible(bShow);
    sui->lblPendingParamFinalSaveText->setVisible(bShow);
    sui->lblPendingParamFinalSaveImage->setVisible(bShow);
    sui->gbxPendingParamFinalSaveButton->setVisible(bShow);
    sui->lblPendingParamSaveChangeReason->setVisible(bShow);
    sui->txaPendingParamSaveChangeReason->setVisible(bShow);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonPressed()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOn()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::onUCTSaveButtonHoverOff()
{
    sui->gbxSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::setTableRows(int value, std::vector<ParameterData*> collection)
{
    int rows = static_cast<int>(collection.size()) - value;
    if (rows > MAX_VISIBLE_ROWS) {
        rows = MAX_VISIBLE_ROWS;
    }
    std::vector<ParameterData*>::iterator beg_it = collection.begin();
    std::advance(beg_it, value);
    int totalRowHeight = 0;
    int row = 0;
    for (; row < rows; ++row, ++beg_it) {
        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            break;
        }
        std::pair <std::string, int> formattedText = formatParamName((*beg_it)->getDisplayName());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    }
    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        row--;
    }
    // When the position of scrollbar reaches its maximum value but still there are few rows left to be displayed (which happens when number of rows that
    // can fit in table are less than MAX_VISIBLE_ROWS), change the maximum value and the current value of scrollbar as per number of rows left to be displayed
    // so that left out rows can also be displayed
    if (value == sui->scbParametersTable->getMaxValue() && row < MAX_VISIBLE_ROWS && beg_it != collection.end()) {
        sui->scbParametersTable->setMaxValue(value + MAX_VISIBLE_ROWS - row);
        sui->scbParametersTable->setValue(value);
    }
    if (row > sui->tawParameters->rowCount()) {
        int count = row - sui->tawParameters->rowCount();
        for (int i = 0; i < count; ++i) {
            sui->tawParameters->appendRow();
        }
    } else if (row < sui->tawParameters->rowCount()) {
        int count = sui->tawParameters->rowCount() - row;
        for (int i = 0; i < count; ++i) {
            sui->tawParameters->removeRow(sui->tawParameters->rowCount() -1);
        }
    }
    setData(value, row, collection);
}

void IGSxGUI::MachineconstantsView::onParameterValueChanged(const std::string& name, const std::string& value)
{
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    if (parameterData != NULL) {
        m_parameterview.close();
        parameterData->changeValue(value);
        std::string paramvalue = parameterData->getCurrentValue()->ToString();
        IGSxGUI::ITEMTYPE type = parameterData->getValueType();
        if (type == IGSxGUI::TYPE_double) {
            IGSxGUI::Util::adjustDoublePrecision(paramvalue);
        }
        std::pair<std::string, std::string> nameValuePair(searchname, paramvalue);
        m_pendingParameterList.push_back(nameValuePair);
        UpdatePendingParamTable(searchname, paramvalue);
    }
    showSaveCancelButtons(true);
    showNoPendingParameterScreen(false);
}


void IGSxGUI::MachineconstantsView::onFloatArrayParameterValueChanged(const std::string& name, const std::string& value)
{
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    if (parameterData != NULL) {
        parameterData->changeValue(value);
        std::string paramvalue = value;
        std::vector<std::string> values;
        boost::split(values, paramvalue, boost::is_any_of(","));
        paramvalue = "";
        for (unsigned int i = 0; i < values.size(); ++i) {
            std::string dblValue = values[i];
            IGSxGUI::Util::adjustDoublePrecision(dblValue);
            paramvalue = paramvalue + "," + dblValue;
        }
        paramvalue.erase(0, 1);
        std::pair<std::string, std::string> nameValuePair(searchname, paramvalue);
        m_pendingParameterList.push_back(nameValuePair);
        UpdatePendingParamTable(searchname, paramvalue);
    }
    showSaveCancelButtons(true);
    showNoPendingParameterScreen(false);
}

void IGSxGUI::MachineconstantsView::onParameterRowPressed(int row)
{
    m_selectedParameterRowNum = row;
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);

    if (parameterData != NULL)
    {
        if (m_shiftKeyPressed == true) {
            if (m_currentRow != -1) {
                selectShiftClickedRows(row);
                m_currentRow = row;
                m_currentScrollBarPosition = sui->scbParametersTable->getValue();
                m_previousScrollBarPosition = m_currentScrollBarPosition;
            }
        } else if (isCtrlKeyPressed()) {
            if (parameterData->isSelected()) {
                m_currentRow = -1;
                m_previousScrollBarPosition = m_currentScrollBarPosition;
                parameterData->setSelected(false);
                if (parameterData->isReadOnly()) {
                    IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
                }  else {
                    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                    if (parameterData->deviatesFromDefault()) {
                        IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                    }
                }
            } else {
                m_previousScrollBarPosition = m_currentScrollBarPosition;
                parameterData->setSelected(true);
                setCurrentRow(row);
                if (parameterData->isReadOnly()) {
                    IGSxGUI::Util::setParameterUCTReadOnlySelectedStyle(widget);
                }  else {
                    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
                    IGSxGUI::Util::processEvents();
                    if (parameterData->deviatesFromDefault()) {
                        IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
                    }
                }
            }
        } else {
            m_currentRow = -1;
            m_previousScrollBarPosition = m_currentScrollBarPosition;
            IGSxGUI::Util::createModalWindow(m_dialogModality, sui->btnSearchAndClearIcon);
            clearSelectionForAllParameterdata(m_pMachineconstantsManager->getAllParameterData());
            parameterData->setSelected(true);
            for (int rowNumber = 0; rowNumber < sui->tawParameters->rowCount(); ++rowNumber) {
                SUI::Widget *widget = sui->tawParameters->getWidgetItem(rowNumber, 0);
                std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
                formatParamNameBack(name);
                ParameterData* parameterData = getParameterDataForName(name);
                if (parameterData != NULL)
                {
                    if (parameterData->isReadOnly()) {
                        IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
                    } else {
                        if (parameterData->isSelected()) {
                            IGSxGUI::Util::setParameterUCTClickedStyle(widget);
                            IGSxGUI::Util::processEvents();
                            if (parameterData->deviatesFromDefault()) {
                                IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
                            }
                        } else {
                            IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                            if (parameterData->deviatesFromDefault()) {
                                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                            }
                        }
                    }
                }
            }
            if ((parameterData != NULL) && (!parameterData->isReadOnly())) {
                parameterData->setSelected(false);
                if (parameterData->getValueType() == IGSxGUI::TYPE_floatarray) {
                    loadFloatArrayDialog(fullName);
                    IGSxGUI::Util::executeDialog(m_dialogFloatArray);
                } else {
                    std::string def = parameterData->getDefaultValue()->ToString();
                    std::string paramvalue = parameterData->getCurrentValue()->ToString();

                    if (parameterData->getValueType() == IGSxGUI::TYPE_boolean) {
                        m_parameterview.show(true, sui->lneSearchParameterText, fullName, def, paramvalue);
                    } else {
                        IGSxGUI::ITEMTYPE type = parameterData->getValueType();
                        if (type == IGSxGUI::TYPE_double) {
                            IGSxGUI::Util::adjustDoublePrecision(paramvalue);
                            IGSxGUI::Util::adjustDoublePrecision(def);
                        }
                        m_parameterview.show(false, sui->lneSearchParameterText, fullName, def, paramvalue);
                    }
                }
                IGSxGUI::Util::setParameterUCTNormalStyle(widget);
            } else {
                IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
            }
            m_selectedParameterRowNum = -1;
            if (parameterData->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
            IGSxGUI::Util::closeModalWindow(m_dialogModality);
        }
    }
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverEntered(int row)
{
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);
    if ((parameterData != NULL) && (!parameterData->isSelected())) {
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            if (parameterData->isReadOnly()) {
                IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
            } else {
                IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawParameters->getWidgetItem(row, 0));
            }
            if (parameterData->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
            std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
            if (value.find("...") != std::string::npos) {
                std::string paramvalue = parameterData->getPreviousValue()->ToString();
                IGSxGUI::ITEMTYPE type = parameterData->getValueType();
                if (type == IGSxGUI::TYPE_double) {
                    IGSxGUI::Util::adjustDoublePrecision(paramvalue);
                } else if (type == IGSxGUI::TYPE_floatarray) {
                    std::vector<std::string> values;
                    boost::split(values, paramvalue, boost::is_any_of(","));
                    paramvalue = "";
                    for (unsigned int i = 0; i < values.size(); ++i) {
                        std::string value = values[i];
                        IGSxGUI::Util::adjustDoublePrecision(value);
                        paramvalue = paramvalue + "," + value;
                    }
                    paramvalue.erase(0, 1);
                    if (paramvalue.size() > 100) {
                        splitToMultilineToolTip(paramvalue, 100);
                    }
                }
                sui->tawParameters->setToolTip(paramvalue);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::onParameterUCTHoverLeft(int row)
{
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string fullName = getFullParameterName(name);
    if ((parameterData != NULL) && (!parameterData->isSelected())) {
        formatParamNameBack(fullName);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(fullName);
        if (parameterData != NULL) {
            if ((m_selectedParameterRowNum != row) || (m_currentRow == -1)) {
                if (parameterData->isReadOnly()) {
                    IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
                } else {
                    IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawParameters->getWidgetItem(row, 0));
                }
            }
            if (parameterData->getDefaultValue()->ToString() != parameterData->getPreviousValue()->ToString()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            }
        }
        sui->tawParameters->setToolTip("");
    }
}

void IGSxGUI::MachineconstantsView::onHistoryHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, true);
}

void IGSxGUI::MachineconstantsView::onHistoryHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnHistory, false);
}

void IGSxGUI::MachineconstantsView::onHistoryPressed()
{
    IGSxGUI::Util::createModalWindow(m_dialogModalityForHistory, sui->btnSearchAndClearIcon);
    m_historyview.setParent(sui->btnHistory);
    m_historyview.show();
    IGSxGUI::Util::closeModalWindow(m_dialogModalityForHistory);
    setFocusToParamTable();
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonHoverEntered()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_BLUE_REGULAR, SEARCH_BUTTON_SIZE);
        break;
    }
    default:
        break;
    }
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowClosePressed(int rowNumber)
{
    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR_CLICKED, PENDINGPARAM_CLOSEBUTTON_SIZE);
    tabwidget->setStyleSheetClass(PENDINGPARAMCANCEL_CLICKED);
    IGSxGUI::Util::processEvents();
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(name);
    if (parameterData != NULL) {
        parameterData->revertValue();
    }
    bool pendingParamTableScrollBarVisibleBefore = false;
    if (!isPendingParamTableScrollBarVisible()) {
        moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, rowNumber));
    } else {
        pendingParamTableScrollBarVisibleBefore = true;
    }
    for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(paramname);
        std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
        std::string fullName = "";
        if (vec.size() > 1) {
            vec.erase(vec.begin());
            std::string parameterCategory = boost::join(vec, "/");
            boost::trim(parameterCategory);
            fullName = parameterCategory + "/" + paramname;
        } else {
            fullName = paramname;
        }
        if (fullName == name) {
            if (parameterData->deviatesFromDefault()) {
                IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
            } else {
                IGSxGUI::Util::setParameterUCTGreyStyle(widget, 1);
            }
        }
    }
    if (sui->tawMCPendingParam->rowCount() == 1) {
        sui->tawMCPendingParam->setRowVisible(0, false);
        showSaveCancelButtons(false);
        showNoPendingParameterScreen(true);
        IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
        tabwidget->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERLEFT);
    } else {
        sui->tawMCPendingParam->removeRow(rowNumber);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            pendingParamApplyRowBehavior(row);
        }
    }
    updatePendingParameterList(name);
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonHoverLeft()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
        break;
    }
    default:
        break;
    }
}

void IGSxGUI::MachineconstantsView::onSearchTextEdited(const std::string &text)
{
   m_searchText = text;
   changeSearchTextStyleAndIcon();
   m_SearchElapsedTime->stop();
   m_SearchElapsedTime->start(SEARCH_PARAMETER_TEXTEDIT_TIMEOUT_MS);
}

void IGSxGUI::MachineconstantsView::changeSearchTextStyleAndIcon()
{
   if (m_searchText != "") {
        if( sui->lneSearchParameterText->getStyleSheetClass() != STYLE_SEARCHPARAM_NOITALIC)
        {
           sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
        }
        if(m_searchItemIcon != IGSxGUI::AwesomeIcon::AI_fa_close)
        {
           m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
           IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
        }
     }
     else {

        if(m_searchItemIcon != IGSxGUI::AwesomeIcon::AI_fa_search)
        {
           m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
           IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
        }
     }
}

void IGSxGUI::MachineconstantsView::onSearchTextTimeElapsed()
{
   m_SearchElapsedTime->stop();
   refreshParameterList(false);
}

void IGSxGUI::MachineconstantsView::refreshParameterList(bool sortFlag)
{
    m_currentRow = -1;
    if (m_searchText.empty()) {
        showSearchEntriesParameter(false);
        if (!sortFlag) {
            clearSelectionForAllParameterdata(m_pMachineconstantsManager->getParameterData());
        }
        initializeTableRows(m_pMachineconstantsManager->getParameterCount(), m_pMachineconstantsManager->getParameterData());
    } else {
        showSearchEntriesParameter(true);
        int entriesfound = m_pMachineconstantsManager->searchForParameters(m_searchText, &m_matchedparameters);
        if (!sortFlag) {
            clearSelectionForAllParameterdata(m_matchedparameters);
        }
        initializeTableRows(entriesfound, m_matchedparameters);
        std::string categoryName = m_pMachineconstantsManager->getCurrentNodeName();
        if(categoryName.compare(STRING_PARAMETERS) == 0)
        {
            categoryName = STRING_ALL_CATEGORIES;
        }
        sui->lblEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND \
                                      +" in " + categoryName);
    }
}


void IGSxGUI::MachineconstantsView::refreshPendingParameterList()
{
    if (m_pendingParameterList.size() > 0) {
        for (size_t i = 0; i < m_pendingParameterList.size(); i++) {
            UpdatePendingParamTable(m_pendingParameterList[i].first, m_pendingParameterList[i].second);
        }
    }
}

void IGSxGUI::MachineconstantsView::onValueChanged()
{
    m_currentScrollBarPosition = sui->scbParametersTable->getValue();
    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(sui->scbParametersTable->getValue(), m_pMachineconstantsManager->getParameterData());
    } else {
        setTableRows(sui->scbParametersTable->getValue(), m_matchedparameters);
    }
}

void IGSxGUI::MachineconstantsView::setFocusToParamTable()
{
   if(!sui->tawParameters->hasFocus())
   {
       sui->tawParameters->setFocus();
   }
}

void IGSxGUI::MachineconstantsView::onSearchTextEditFinished()
{
    if (m_searchText == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    } else {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
    }
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, SEARCH_BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::UpdatePendingParamTable(const std::string &name, const std::string &value)
{
    int rowNumber;
    if ((sui->tawMCPendingParam->rowCount() == 1) && (!sui->tawMCPendingParam->isRowVisible(0))) {
        rowNumber = 0;
        sui->tawMCPendingParam->setRowVisible(rowNumber, true);
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
        std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        // After pending parameters have been saved or cancelled or removed, adding a row only requires to update with new name and value
        // since we are not actually deleting the last row while performing saving or cancel or removing last row in pending parameters.
        if (!paramname.empty()) {
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            moveSaveCancelButtons(DOWN, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
            std::string paramvalue = value;
            formatParamValue(widget, paramvalue, COLUMN_HEIGHT);
            IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
            return;
        }
        std::pair <std::string, int> formattedText = formatPendingParamName(name);
        IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        moveSaveCancelButtons(DOWN, (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
    } else {
        for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            std::pair <std::string, int> tmpname = formatPendingParamName(name);
            std::string formattedText = tmpname.first;
            if (paramname == formattedText) {
                std::string paramvalue = value;
                formatParamValue(widget, paramvalue, COLUMN_HEIGHT);
                IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
                return;
            }
        }
        if (!isPendingParamTableScrollBarVisible()) {
            sui->tawMCPendingParam->appendRow();
            rowNumber = sui->tawMCPendingParam->rowCount() - 1;
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            if (!isPendingParamTableScrollBarVisible()) {
                moveSaveCancelButtons(DOWN, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            } else {
                adjustCancelSaveButtonGeometryDown();
            }
        } else {
            sui->tawMCPendingParam->appendRow();
            rowNumber = sui->tawMCPendingParam->rowCount() - 1;
            std::pair <std::string, int> formattedText = formatPendingParamName(name);
            IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, rowNumber, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        }
    }
    configurePendingParamTableRow(rowNumber, name, value);
}

void IGSxGUI::MachineconstantsView::configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value)
{
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(rowNumber, 0);
    std::pair <std::string, int> formattedText = formatPendingParamName(name);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
    std::string paramvalue = value;
    formatParamValue(widget, paramvalue, COLUMN_HEIGHT);
    IGSxGUI::Util::setTextToParameterUserControl(widget, 1, paramvalue);
    pendingParamApplyRowBehavior(rowNumber);
    sui->btnPendingParameterNameUpDownArrow->setVisible(true);
    sui->btnPendingParameterNameUpArrow->setVisible(false);
    sui->btnPendingParameterNameDownArrow->setVisible(false);
    IGSxGUI::Util::scrollToBottom(sui->tawMCPendingParam);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveClicked()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_ORANGEBG);
    IGSxGUI::Util::processEvents();
    showSaveCancelButtons(true);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(false);
    performPendingParamSaving();
    sui->lneSearchParameterText->setEnabled(true);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
    }
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverEntered()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_HOVERBLUEBG);
}

void IGSxGUI::MachineconstantsView::uctPendingParamFinalSaveHoverLeft()
{
    sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveChangeReasonTxtChanged(const std::string &text)
{
    sui->lblPendingParamSaveChangeReasonTxtArea->setVisible(text.empty());
    std::string name = sui->lnePendingParamSaveName->getText();
    boost::trim(name);
    std::string reason = sui->txaPendingParamSaveChangeReason->getText();
    boost::trim(reason);
    changeFinalSaveButtonStyle(name, reason);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveTxtChanged(const std::string &text)
{
    sui->btnPendingParamSaveNameLnEditCancel->setVisible(!text.empty());
    sui->lblPendingParamSaveNameLnEdit->setVisible(text.empty());
    std::string name = sui->lnePendingParamSaveName->getText();
    boost::trim(name);
    std::string reason = sui->txaPendingParamSaveChangeReason->getText();
    boost::trim(reason);
    changeFinalSaveButtonStyle(name, reason);
}

void IGSxGUI::MachineconstantsView::updatePendingParameterList(std::string pendingParamName)
{
    if (!pendingParamName.empty()) {
        for (size_t i = 0; i < m_pendingParameterList.size(); i++) {
            if (m_pendingParameterList[i].first == pendingParamName) {
                m_pendingParameterList.erase(std::remove(m_pendingParameterList.begin(), m_pendingParameterList.end(),
                                             m_pendingParameterList[i]), m_pendingParameterList.end());
                break;
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::changeFinalSaveButtonStyle(const std::string& name, const std::string& reason)
{
    if (name.empty() || reason.empty() || !m_pMachineconstantsManager->isParamSavingEnabled()) {
        sui->uctPendingParamFinalSave->clicked = NULL;
        sui->uctPendingParamFinalSave->hoverLeft = NULL;
        sui->uctPendingParamFinalSave->hoverEntered = NULL;
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, COLOR_GREY_DARK, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass(STYLE_DISABLE_LABEL);
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_DISABLE_BACKGROUND);
        sui->gbxPendingParamFinalSaveButton->setEnabled(false);
    } else {
        sui->uctPendingParamFinalSave->clicked = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveClicked, this);
        sui->uctPendingParamFinalSave->hoverLeft = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverLeft, this);
        sui->uctPendingParamFinalSave->hoverEntered = boost::bind(&MachineconstantsView::uctPendingParamFinalSaveHoverEntered, this);
        IGSxGUI::Util::setAwesome(sui->lblPendingParamFinalSaveImage, IGSxGUI::AwesomeIcon::AI_fa_save, SUI::ColorEnum::White, BUTTON_SIZE);
        sui->lblPendingParamFinalSaveText->setStyleSheetClass("");
        sui->gbxPendingParamFinalSaveButton->setStyleSheetClass(STYLE_BUTTON_BLUEBG);
        sui->gbxPendingParamFinalSaveButton->setEnabled(true);
    }
}

void IGSxGUI::MachineconstantsView::removePendingParamTableRows()
{
    int rowcount = sui->tawMCPendingParam->rowCount();
    for (int row = rowcount - 1; row >= 0; --row) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(pendingparamname);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(pendingparamname);
        if (parameterData != NULL) {
            parameterData->revertValue();
        }
        for (int paramrow = 0; paramrow < sui->tawParameters->rowCount(); ++paramrow) {
            SUI::Widget *widget = sui->tawParameters->getWidgetItem(paramrow, 0);
            std::string paramname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
            formatParamNameBack(paramname);
            std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
            std::string fullName = "";
            if (vec.size() > 1) {
                vec.erase(vec.begin());
                std::string parameterCategory = boost::join(vec, "/");
                boost::trim(parameterCategory);
                fullName = parameterCategory + "/" + paramname;
            } else {
                fullName = paramname;
            }
            if (fullName == pendingparamname) {
                if (parameterData->deviatesFromDefault()) {
                    IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                } else {
                    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                }
            }
        }
        if (row == 0) {
            continue;
        }
        bool pendingParamTableScrollBarVisibleBefore = false;
        if (!isPendingParamTableScrollBarVisible()) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row));
        } else {
            pendingParamTableScrollBarVisibleBefore = true;
        }
        sui->tawMCPendingParam->removeRow(row);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
    }
    moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, 0));
    sui->tawMCPendingParam->setRowVisible(0, false);
}

void IGSxGUI::MachineconstantsView::moveSaveCancelButtons(const moveDirection &dir, int pixels)
{
    int xCancel = sui->btnCancel->getGeometry().getX();
    int yCancel = sui->btnCancel->getGeometry().getY();
    int widthCancel = sui->btnCancel->getGeometry().getWidth();
    int heightCancel = sui->btnCancel->getGeometry().getHeight();
    int xSave = sui->uctSaveButton->getGeometry().getX();
    int ySave = sui->uctSaveButton->getGeometry().getY();
    int widthSave = sui->uctSaveButton->getGeometry().getWidth();
    int heightSave = sui->uctSaveButton->getGeometry().getHeight();
    switch (dir) {
    case UP: {
        yCancel -= pixels;
        ySave -= pixels;
        break;
    }
    case DOWN: {
        yCancel += pixels;
        ySave += pixels;
        break;
    }
    default:
        break;
    }
    sui->btnCancel->setGeometry(xCancel, yCancel, widthCancel, heightCancel);
    sui->uctSaveButton->setGeometry(xSave, ySave, widthSave, heightSave);
}

void IGSxGUI::MachineconstantsView::PendingParamSaveNameLnEditCancel()
{
    sui->lnePendingParamSaveName->clearText();
    sui->lnePendingParamSaveName->setFocus();
}

void IGSxGUI::MachineconstantsView::onCancelPressedOnFinalSave()
{
    showSaveCancelButtons(true);
    showFinalSaveScreenItems(false);
    showNoPendingParameterScreen(false);
    updateParameterTableOnCancelingFinalSave();
    setHandlers();
    sui->lneSearchParameterText->setEnabled(true);
    if (sui->lneSearchParameterText->getText() == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
    }
    sui->btnSearchAndClearIcon->clicked = boost::bind(&MachineconstantsView::onSearchAndClearButtonPressed, this);
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&MachineconstantsView::onSearchAndClearButtonHoverEntered, this);
    setPendingParamSaveBtnEnable(m_pMachineconstantsManager->isParamSavingEnabled());
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverEntered(int row)
{
    IGSxGUI::Util::setParameterUCTHoverOnStyle(sui->tawMCPendingParam->getWidgetItem(row, 0));
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    std::string value = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    if (value.find("...") != std::string::npos) {
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(pendingparamname);
        ParameterData* parameterData = m_pMachineconstantsManager->findParameter(pendingparamname);
        if (parameterData != NULL) {
            std::string paramvalue = parameterData->getCurrentValue()->ToString();
            IGSxGUI::ITEMTYPE type = parameterData->getValueType();
            if (type == IGSxGUI::TYPE_double) {
                IGSxGUI::Util::adjustDoublePrecision(paramvalue);
            } else if (type == IGSxGUI::TYPE_floatarray) {
                std::vector<std::string> values;
                boost::split(values, paramvalue, boost::is_any_of(","));
                paramvalue = "";
                for (unsigned int i = 0; i < values.size(); ++i) {
                    std::string value = values[i];
                    IGSxGUI::Util::adjustDoublePrecision(value);
                    paramvalue = paramvalue + "," + value;
                }
                paramvalue.erase(0, 1);
                if (paramvalue.size() > 100) {
                    splitToMultilineToolTip(paramvalue, 100);
                }
            }
            sui->tawMCPendingParam->setToolTip(paramvalue);
        }
    }
}

void IGSxGUI::MachineconstantsView::onPendingParameterHoverLeft(int row)
{
    // When popup window shows up after clicking the pending parameter table row, focus goes out of the clicked row
    // and onPendingParameterHoverLeft event gets generated which makes this method called and clicked row becomes
    // un-highlighted. Do not apply HoverOffStyle to the selected row, so that the selected row will be remain selected
    // even after popup window shows up.
    if (m_selectedPendingParameterRowNum != row) {
        IGSxGUI::Util::setParameterUCTHoverOffStyle(sui->tawMCPendingParam->getWidgetItem(row, 0));
    }
    sui->tawMCPendingParam->setToolTip("");
}

void IGSxGUI::MachineconstantsView::onPendingParameterClicked(int row)
{
    IGSxGUI::Util::createModalWindow(m_dialogModality, sui->btnSearchAndClearIcon);
    m_selectedPendingParameterRowNum = row;
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
    IGSxGUI::Util::processEvents();
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string searchname = name;
    formatParamNameBack(searchname);
    ParameterData* parameterData = m_pMachineconstantsManager->findParameter(searchname);
    std::string value = parameterData->getCurrentValue()->ToString(); // Getting the current Value from parameter Data
    if (parameterData != NULL) {
        if (parameterData->getValueType() == IGSxGUI::TYPE_floatarray) {
            loadFloatArrayDialog(searchname);
            IGSxGUI::Util::executeDialog(m_dialogFloatArray);
        } else {
            if (parameterData->getValueType() == IGSxGUI::TYPE_boolean) {
                m_parameterview.show(true, sui->lneSearchParameterText, searchname, parameterData->getDefaultValue()->ToString(), value);
            } else if (parameterData->getValueType() == IGSxGUI::TYPE_double) {
                IGSxGUI::Util::adjustDoublePrecision(value);
                 std::string def = parameterData->getDefaultValue()->ToString();
                 IGSxGUI::Util::adjustDoublePrecision(def);
                m_parameterview.show(false, sui->lneSearchParameterText, searchname, def, value);
            }
            else {
                std::string def = parameterData->getDefaultValue()->ToString();
                IGSxGUI::Util::adjustDoublePrecision(def);
                m_parameterview.show(false, sui->lneSearchParameterText, searchname, parameterData->getDefaultValue()->ToString(), value);
            }
        }
    }
    m_selectedPendingParameterRowNum = -1;
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    IGSxGUI::Util::closeModalWindow(m_dialogModality);
}

void IGSxGUI::MachineconstantsView::pendingParamApplyRowBehavior(int row)
{
    SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(row, 0);
    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&MachineconstantsView::onPendingParameterClicked, this, row);
    usercontrol->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterHoverEntered, this, row);
    usercontrol->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterHoverLeft, this, row);
    SUI::Widget *tabwidget = sui->tawMCPendingParam->getWidgetItem(row, 1);
    IGSxGUI::Util::setAwesome(tabwidget, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_CLOSE_BUTTON_COLOR, PENDINGPARAM_CLOSEBUTTON_SIZE);
    SUI::Button* button = dynamic_cast<SUI::Button*>(tabwidget);
    button->clicked = boost::bind(&MachineconstantsView::onPendingParameterRowClosePressed, this, row);
    button->hoverEntered = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHovered, this, row);
    button->hoverLeft = boost::bind(&MachineconstantsView::onPendingParameterRowCloseHoverLeft, this, row);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHovered(int row)
{
    sui->tawMCPendingParam->getWidgetItem(row, 1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERED);
}

void IGSxGUI::MachineconstantsView::onPendingParameterRowCloseHoverLeft(int row)
{
    sui->tawMCPendingParam->getWidgetItem(row, 1)->setStyleSheetClass(PENDINGPARAMCANCEL_HOVERLEFT);
}

void IGSxGUI::MachineconstantsView::onBackPressed()
{
    m_pMachineconstantsManager->navigateBack();
    if (sui->btnParameterName->isVisible()) {
        m_pMachineconstantsManager->sortParamsAscending();
    } else {
        m_pMachineconstantsManager->sortParamsDescending();

    }
    refreshTreeViewAndBreadCrums();
    refreshParameterList(false);
}


void IGSxGUI::MachineconstantsView::onParameterTreeItemPressed(int rowNumber)
{
    std::string text = sui->tawParameterTree->getItemText(rowNumber, 0);
    text.erase(std::remove(text.begin(), text.end(), '\n'), text.end());
    m_pMachineconstantsManager->navigateToChild(text);
    if (sui->btnParameterName->isVisible()) {
        m_pMachineconstantsManager->sortParamsAscending();
    } else {
        m_pMachineconstantsManager->sortParamsDescending();
    }
    refreshTreeViewAndBreadCrums();
    refreshParameterList(false);
    refreshPendingParameterList();
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, true);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC1, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC2, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC3, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC4, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC5, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6HoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBC6, false);
}

void IGSxGUI::MachineconstantsView::onBreadCrump1Clicked()
{
    onBreadCrumpClicked(0);
}

void IGSxGUI::MachineconstantsView::onBreadCrump2Clicked()
{
    onBreadCrumpClicked(1);
}

void IGSxGUI::MachineconstantsView::onBreadCrump3Clicked()
{
    onBreadCrumpClicked(2);
}

void IGSxGUI::MachineconstantsView::onBreadCrump4Clicked()
{
    onBreadCrumpClicked(3);
}

void IGSxGUI::MachineconstantsView::onBreadCrump5Clicked()
{
    onBreadCrumpClicked(4);
}

void IGSxGUI::MachineconstantsView::onBreadCrump6Clicked()
{
    onBreadCrumpClicked(5);
}

void IGSxGUI::MachineconstantsView::onBreadCrumpClicked(int index)
{
    if (m_pMachineconstantsManager->getCurrentNodeName() != breadCrumpButtonList[index]->getText()) {
        if (index == 0) {
            m_pMachineconstantsManager->navigateToBreadCrum("Parameters");
        } else {
            m_pMachineconstantsManager->navigateToBreadCrum(breadCrumpButtonList[index]->getText());
        }
        if (sui->btnParameterName->isVisible()) {
            m_pMachineconstantsManager->sortParamsAscending();
        } else {
            m_pMachineconstantsManager->sortParamsDescending();
        }
        refreshTreeViewAndBreadCrums();
        refreshParameterList(false);
    }
}

void IGSxGUI::MachineconstantsView::refreshTreeViewAndBreadCrums()
{
    const std::vector<std::string>& breadCrumList =  m_pMachineconstantsManager->getBreadCrumTitles();
    if (breadCrumList.size() == 1) {
        sui->lblAllCategories->setVisible(true);
        sui->lblBackImage->setVisible(false);
        sui->btnBack->setVisible(false);
    } else {
        sui->lblAllCategories->setVisible(false);
        sui->lblBackImage->setVisible(true);
        sui->btnBack->setVisible(true);
    }
    this->m_breadCrumResizer->RepositionAll(breadCrumList);
    std::vector<std::string> childNodeTitles;
    m_pMachineconstantsManager->getChildNodeTitles(&childNodeTitles);
    int childNodeCount = static_cast<int>(childNodeTitles.size());
    if (childNodeCount == 0) {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        sui->tawParameterTree->setItemText(0, 0, "No Subcategories");
        IGSxGUI::Util::setRowHeight(sui->tawParameterTree, 0, ROW_HEIGHT);
    } else {
        sui->tawParameterTree->removeRows(1, sui->tawParameterTree->rowCount() - 1);
        for (int row = 0 ; row < childNodeCount - 1; ++row) {
            sui->tawParameterTree->appendRow();
        }
        for (int row = 0 ; row < sui->tawParameterTree->rowCount(); ++row) {
            if (childNodeTitles[row].length() > MAX_CHARS_OF_PARAMETERTREE_CELL) {
                std::string formattedText = formatParamaterCatogoryName(childNodeTitles[row]);
                sui->tawParameterTree->setItemText(row, 0, formattedText);
                IGSxGUI::Util::setRowHeight(sui->tawParameterTree, row, MULTILINE_ROW_HEIGHT);
            } else {
                sui->tawParameterTree->setItemText(row, 0, childNodeTitles[row]);
                IGSxGUI::Util::setRowHeight(sui->tawParameterTree, row, ROW_HEIGHT);
            }
        }
    }
    IGSxGUI::Util::clearSelection(sui->tawParameterTree);
}

void IGSxGUI::MachineconstantsView::busyIndicatorWindowClose()
{
    sui->gbxPendingParamSaveError->setVisible(true);
}

void IGSxGUI::MachineconstantsView::pendingParamRetrySave()
{
    sui->gbxPendingParamSaveError->setVisible(false);
    performPendingParamSaving();
}

void IGSxGUI::MachineconstantsView::onSearchAndClearButtonPressed()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        showSearchEntriesParameter(false);
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        m_SearchElapsedTime->stop();
        sui->lneSearchParameterText->clearText();
        break;
    }
    default:
        break;
    }
    sui->lneSearchParameterText->setFocus();
}

void IGSxGUI::MachineconstantsView::onCancelPressedOnSaveErrorPopUpMessage()
{
    updateParameterTable();
    sui->gbxPendingParamSaveError->setVisible(false);
    sui->gbxBI->setVisible(false);
}

void IGSxGUI::MachineconstantsView::performPendingParamSaving()
{
    sui->gbxBI->setVisible(true);
    m_pMachineconstantsManager->saveUpdatedParameters(sui->lnePendingParamSaveName->getText(), sui->txaPendingParamSaveChangeReason->getText());
}

std::string IGSxGUI::MachineconstantsView::formatParamaterCatogoryName(const std::string& name)
{
    std::vector<int> vec;
    // Identify the individual word indices
    for (size_t i = 1; i < name.size(); ++i) {
        if (::isupper(name[i]) != 0 && ::isupper(name[i - 1]) == 0) {
            vec.push_back(i);
        }
    }
    // Extract the individual words
    int start = 0;
    std::vector<std::string> tokens;
    for (size_t i = 0, numberOfCharacters = 0; i < vec.size(); ++i) {
        numberOfCharacters = vec[i] - static_cast<size_t>(start);
        tokens.push_back(name.substr(start, static_cast<int>(numberOfCharacters)));
        start = vec[i];
    }
    tokens.push_back(name.substr(start));
    // Split the complete paramtername into two lines
    size_t totalTokens = tokens.size();
    std::string temp = "";
    std::string str1 = "";
    std::string str2 = "";
    bool flag = true;
    for (size_t index = 0; index < totalTokens ; ++index) {
        temp += tokens[index];
        if ((temp.length() < MAX_CHARS_OF_PARAMETERTREE_CELL) && (flag)) {
            str1 = str1 + tokens[index];
            temp = str1;
        } else {
            str2 = str2 + tokens[index];
            temp = str2;
            flag = false;
        }
    }
    std::string strMultiLine = str1 + '\n' + str2;
    return strMultiLine;
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatPendingParamName(const std::string& name)
{
    SUI::Widget* widget = sui->tawMCPendingParam->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 545;
    return formatName(name, widget, "table", columnWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatParamName(const std::string& name)
{
    SUI::Widget* widget = sui->tawParameters->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 585;
    return formatName(name, widget, "table", columnWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatDialogParamName(const std::string& name)
{
    SUI::Label* label = m_parameterview.getParameterNameType();
    int labelWidth = 500;
    return formatName(name, dynamic_cast<SUI::Widget*>(label), "label", labelWidth);
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatFloatArrayDialogParamName(const std::string& name)
{
    SUI::Label* label = m_dialogFloatArray->getObjectList()->getObject<SUI::Label>("lblParameterName");
    int labelWidth = 500;
    return formatName(name, dynamic_cast<SUI::Widget*>(label), "label", labelWidth);
}

size_t IGSxGUI::MachineconstantsView::getSplitPosition(const std::string& name, SUI::Widget* widget, const std::string& type, int width)
{
    int total_chars_width = 0;
    for (size_t i = 0; i < name.size(); ++i) {
        std::string str(1, name[i]);
        if (type == "table") {
            total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 0);
        } else if (type == "label") {
            total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLabel(str, widget);
        }
        if (total_chars_width > width) {
            return i-1;
        }
    }
    return 0;
}

void IGSxGUI::MachineconstantsView::extractSubStr(std::size_t found,  int& num_of_rows, std::string& retname, std::string& tmpname)
{
    if (retname == "") {
        retname = tmpname.substr(0, found);
    } else {
        retname = retname + '\n' + tmpname.substr(0, found);
    }
    num_of_rows++;
    tmpname = tmpname.substr(found, tmpname.size());
}

std::pair <std::string, int> IGSxGUI::MachineconstantsView::formatName(const std::string& name, SUI::Widget* widget, const std::string& type, int width)
{
    size_t search_pos = getSplitPosition(name, widget, type, width);
    static std::string retname = "";
    static int num_of_rows = 1;
    std::string tmpname = name;
    if (search_pos == 0) {
        std::string ret = retname + '\n' + tmpname;
        if (retname == "") {
            ret = tmpname;
            num_of_rows = 1;
        }
        int rows = num_of_rows;
        retname = "";
        num_of_rows = 1;
        return std::make_pair(ret, rows);
    }
    std::size_t found = tmpname.rfind('/', search_pos);
    if (found == std::string::npos) {
        std::size_t found = tmpname.find_first_of('(');
        // found <= 3 is to avoid indefinite looping that may occur when we find the same character '(' repeatedly which is moved to tmpname
        // found > search_pos is found after search position which is consdered as not found
        if (found == std::string::npos || found > search_pos || found <= 3) {
            std::size_t found = tmpname.rfind('_', search_pos);
            if (found == std::string::npos) {
                int position = UpperCasePositionBackwards(tmpname, search_pos);
                // <= 3 is to avoid indefinite looping that may occur when we find the same UPPERCASE character repeatedly which is moved to tmpname
                if (position <= 3) {
                    extractSubStr(search_pos, num_of_rows, retname, tmpname);
                } else {
                    extractSubStr(position, num_of_rows, retname, tmpname);
                }
            } else {
                extractSubStr(found+1, num_of_rows, retname, tmpname);
            }
        } else {
            extractSubStr(found, num_of_rows, retname, tmpname);
        }
    } else {
        // we do not want the units of type "(x/y)" gets split at '/'
        // split at first '(' for units which have more than one '('
        std::size_t found2 = tmpname.find_first_of('(');
        if (found2 != std::string::npos && found2 < found) {
            found = found2;
            extractSubStr(found, num_of_rows, retname, tmpname);
        } else {
            extractSubStr(found+1, num_of_rows, retname, tmpname);
        }
    }
    return formatName(tmpname, widget, type, width);
}

int IGSxGUI::MachineconstantsView::UpperCasePositionBackwards(const std::string& name, int fromPos)
{
    for (int i = fromPos; i > 0; --i) {
        if (::isupper(name[i]) != 0 && ::isupper(name[i - 1]) == 0) {
            return i;
        }
    }
    return 0;
}

void IGSxGUI::MachineconstantsView::formatParamNameBack(std::string& name)
{
    boost::replace_all(name, "\n","");
}


bool IGSxGUI::MachineconstantsView::isPendingParamTableScrollBarVisible()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    return (totalrowheight > PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT);
}

// adjusts the save and cancel buttons of pending parameter table by moving up when scroll bar gets removed due to removal of table rows
// so that the distance between buttons and table is maintained as per specs which is now 50
void IGSxGUI::MachineconstantsView::adjustCancelSaveButtonGeometryUp()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    SUI::Rect btnCancel = sui->btnCancel->getGeometry();
    SUI::Rect uctSaveButton = sui->uctSaveButton->getGeometry();
    int xCancel = btnCancel.getX();
    int widthCancel = btnCancel.getWidth();
    int heightCancel = btnCancel.getHeight();
    int xSave = uctSaveButton.getX();
    int widthSave = uctSaveButton.getWidth();
    int heightSave = uctSaveButton.getHeight();
    sui->btnCancel->setGeometry(xCancel, PENDING_PARAM_TABLE_YPOSITION+totalrowheight+PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE, widthCancel, heightCancel);
    sui->uctSaveButton->setGeometry(xSave, PENDING_PARAM_TABLE_YPOSITION+totalrowheight+PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE, widthSave, heightSave);
}

// adjusts the save and cancel buttons of pending parameter table by moving down when scroll bar gets added due to addition of table rows
// so that the distance between buttons and table is maintained as per specs which is now 50
void IGSxGUI::MachineconstantsView::adjustCancelSaveButtonGeometryDown()
{
    int totalrowheight = 0;
    for (int row = 0; row < sui->tawMCPendingParam->rowCount() - 1; ++row) {
        totalrowheight = totalrowheight + IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, row);
    }
    moveSaveCancelButtons(DOWN, PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT - totalrowheight);
}

void IGSxGUI::MachineconstantsView::sortParamsAscending()
{
    clearSelectionForAllParameterdata(m_pMachineconstantsManager->getAllParameterData());
    m_currentRow = -1;
    m_pMachineconstantsManager->sortParamsAscending();
    sui->btnParameterName2->setVisible(false);
    sui->btnParameterNameDownArrow->setVisible(false);
    sui->btnParameterName->setVisible(true);
    sui->btnParameterNameUpArrow->setVisible(true);
    refreshTreeViewAndBreadCrums();
    refreshParameterList(true);
}

void IGSxGUI::MachineconstantsView::sortParamsDescending()
{
    clearSelectionForAllParameterdata(m_pMachineconstantsManager->getAllParameterData());
    m_currentRow = -1;
    m_pMachineconstantsManager->sortParamsDescending();
    sui->btnParameterName2->setVisible(true);
    sui->btnParameterNameDownArrow->setVisible(true);
    sui->btnParameterName->setVisible(false);
    sui->btnParameterNameUpArrow->setVisible(false);
    refreshTreeViewAndBreadCrums();
    refreshParameterList(true);
}

void IGSxGUI::MachineconstantsView::onBackHoverEntered()
{
    IGSxGUI::Util::setUnderline(sui->btnBack, true);
}

void IGSxGUI::MachineconstantsView::onBackHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnBack, false);
}

void IGSxGUI::MachineconstantsView::sortPendingParams()
{
    int rowcount = sui->tawMCPendingParam->rowCount();
    std::vector<std::pair<std::string, std::string> > pendingParams;
    for (int i = 0; i < rowcount; ++i) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(i, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        pendingParams.push_back(std::make_pair(name, IGSxGUI::Util::getTextFromParameterUserControl(widget, 1)));
    }
    if (sui->btnPendingParameterNameUpArrow->isVisible()) {
        std::sort(pendingParams.begin(), pendingParams.end(), desOrderPendingParam());
        sui->btnPendingParameterNameDownArrow->setVisible(true);
        sui->btnPendingParameterNameUpArrow->setVisible(false);
    } else {
        std::sort(pendingParams.begin(), pendingParams.end(), ascOrderPendingParam());
        sui->btnPendingParameterNameDownArrow->setVisible(false);
        sui->btnPendingParameterNameUpArrow->setVisible(true);
    }
    sui->btnPendingParameterNameUpDownArrow->setVisible(false);
    m_pendingParameterList.clear();
    for (int i = 0; i < rowcount; ++i) {
        SUI::Widget *widget = sui->tawMCPendingParam->getWidgetItem(i, 0);
        std::pair <std::string, int> formattedText = formatPendingParamName(pendingParams.at(i).first);
        IGSxGUI::Util::setRowHeight(sui->tawMCPendingParam, i, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
        IGSxGUI::Util::setTextToParameterUserControl(widget, 0, formattedText.first);
        IGSxGUI::Util::setTextToParameterUserControl(widget, 1, pendingParams.at(i).second);
        std::pair<std::string, std::string> nameValuePair(pendingParams.at(i).first, pendingParams.at(i).second);
        m_pendingParameterList.push_back(nameValuePair);
    }
    IGSxGUI::Util::scrollToTop(sui->tawMCPendingParam);
}

void IGSxGUI::MachineconstantsView::formatParamValue(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        name.replace(i-1, name.size(), "...");
        while (formatParamValueAfterAddingDots(widget, name, columnWidth)) {}
    }
}

bool IGSxGUI::MachineconstantsView::formatParamValueAfterAddingDots(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        size_t pos = name.find("....");  // after adding 3 dots there is possibility that the value will have 4 dots as the values are double
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            size_t pos = name.find("...");
            name.erase(pos-1, 1);
        }
        return true;
    } else {
        size_t pos = name.find("....");
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        }
        return false;
    }
}

void IGSxGUI::MachineconstantsView::splitToMultilineToolTip(std::string& value, size_t charCount)
{
    std::string retname = "";
    std::string tempstr = value;
    while (tempstr.size() > charCount) {
        size_t pos = tempstr.rfind(',', charCount);
        retname = retname + "\n" + tempstr.substr(0, pos+1);
        tempstr = tempstr.substr(pos+1, tempstr.size());
    }
    retname.erase(0, 1);
    value = retname + "\n" + tempstr;
}

std::string IGSxGUI::MachineconstantsView::getFomatedParameterDataToCopy()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        return getParameterStr(m_pMachineconstantsManager->getParameterData());
    } else {
        return getParameterStr(m_matchedparameters);
    }
}

std::string IGSxGUI::MachineconstantsView::getParameterStr(std::vector<ParameterData*> t_parameterData)
{
    std::string text = "";
    for (size_t i = 0; i < t_parameterData.size(); ++i) {
        if (t_parameterData[i]->isSelected() == true) {
            std::string paramName = t_parameterData[i]->getDisplayName();
            text += "\""+ paramName + "\",";
            std::string value = t_parameterData[i]->getCurrentValue()->ToString();
            IGSxGUI::ITEMTYPE type = t_parameterData[i]->getValueType();
            if (type == IGSxGUI::TYPE_double) {
                IGSxGUI::Util::adjustDoublePrecision(value);
            }
            text += "\""+ value + "\"";
            text += "\n";
        }
    }
    return text;
}

void IGSxGUI::MachineconstantsView::replaceText(std::string &str, std::string from, std::string to)
{
    for (std::size_t index =0; (index = str.find(from, index))!= std::string::npos; index = index + 2) {
        str.replace(index, from.length(), to);
    }
}

void IGSxGUI::MachineconstantsView::selectAllRows()
{
    int rowCount = sui->tawParameters->rowCount();
    for (int row = 0; row < rowCount; ++row) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        ParameterData* parameterData = getParameterDataForName(name);
        if ((parameterData!= NULL) && (parameterData->isReadOnly())) {
            IGSxGUI::Util::setParameterUCTReadOnlySelectedStyle(widget);
        } else {
            IGSxGUI::Util::setParameterUCTClickedStyle(widget);
        }
    }
    std::vector<ParameterData*> parameterDataCollection = m_pMachineconstantsManager->getAllParameterData();
    if (sui->lneSearchParameterText->getText().empty()) {
        size_t parameterDataCount = parameterDataCollection.size();
        for (size_t i = 0; i < parameterDataCount; ++i) {
            parameterDataCollection[i]->setSelected(true);
        }
    } else {
        size_t matchedparameterDataCount = m_matchedparameters.size();
        for (size_t i = 0; i < matchedparameterDataCount; ++i) {
            m_matchedparameters[i]->setSelected(true);
        }
    }
}

void IGSxGUI::MachineconstantsView::setCtrlKeyPressed(bool isCtrlKeyPressed)
{
    m_isCtrlKeyPressed = isCtrlKeyPressed;
}

bool IGSxGUI::MachineconstantsView::isCtrlKeyPressed() const
{
    return m_isCtrlKeyPressed;
}

void IGSxGUI::MachineconstantsView::setShiftKeyPressed(bool isShiftKeyPressed)
{
    m_shiftKeyPressed = isShiftKeyPressed;
}

bool IGSxGUI::MachineconstantsView::isShiftKeyPressed() const
{
    return m_shiftKeyPressed;
}

void IGSxGUI::MachineconstantsView::setFACurrentLineEditIndex(int index)
{
    m_floatArrayCurrentLineEditIndex = index;
}

void IGSxGUI::MachineconstantsView::setFAPreviousLineEditIndex(int index)
{
    m_floatArrayPreviousLineEditIndex = index;
}

int IGSxGUI::MachineconstantsView::getFACurrentLineEditIndex()
{
    return m_floatArrayCurrentLineEditIndex;
}

int IGSxGUI::MachineconstantsView::getFAPreviousLineEditIndex()
{
    return m_floatArrayPreviousLineEditIndex;
}

std::string IGSxGUI::MachineconstantsView::getFullParameterName(const std::string& name)
{
    std::vector<std::string> vec = m_pMachineconstantsManager->getBreadCrumTitles();
    std::string fullName = "";
    if (vec.size() > 1) {
        vec.erase(vec.begin());
        std::string parameterCategory = boost::join(vec, "/");
        boost::trim(parameterCategory);
        fullName = parameterCategory + "/" + name;
    } else {
        fullName = name;
    }
    return fullName;
}

IGSxGUI::ParameterData* IGSxGUI::MachineconstantsView::getParameterDataForName(const std::string& name)
{
    std::string fullName = getFullParameterName(name);
    return (m_pMachineconstantsManager->findParameter(fullName));
}

void IGSxGUI::MachineconstantsView::clearSelectionForAllParameterdata(std::vector<IGSxGUI::ParameterData*> parameterDataVec)
{
    size_t totalSize = parameterDataVec.size();
    for (size_t i = 0; i < totalSize; ++i) {
        parameterDataVec.at(i)->setSelected(false);
    }
}

void IGSxGUI::MachineconstantsView::loadFloatArrayDialog(std::string floatParamName)
{
    initFloatArrayDialog(floatParamName);
    configureFloatArrayTable();
    int numFloatArray = m_parameterData->getMaxValueCount();
    m_tawFloatArray->insertRows(1, numFloatArray-1);
    m_tawFloatArrayXButton->insertRows(1, numFloatArray-1);
    configureFloatArrayScrollbar();
    int initialWidgetLoadCount = 0;
    if (m_tawFloatArray->rowCount() <= 16) {
        initialWidgetLoadCount = m_tawFloatArray->rowCount();
    } else {
        initialWidgetLoadCount = 16;
    }
    std::vector<SUI::Widget*> lineEditWidgetVector;
    for (int i = 0; i < initialWidgetLoadCount; ++i) {
        addWidgetsInEachRow(i);
        showVaulesInEachRow(i);
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        le->textChanged = boost::bind(&MachineconstantsView::onFloatArrayParamValueTextChanged, this, le, i, _1);
        le->editingFinished = boost::bind(&MachineconstantsView::onFloatArrayParamValueTextEditFinished, this, le, i);
        le->setAlignment(SUI::AlignmentEnum::Right);
        lineEditWidgetVector.push_back(le);
        SUI::Widget* widget2 = m_tawFloatArray->getWidgetItem(i, 2);
        SUI::Label* lblDefVal = dynamic_cast<SUI::Label*>(widget2);
        lblDefVal->setStyleSheetClass("popupDefaultValue");
        SUI::Widget* widget3 = m_tawFloatArray->getWidgetItem(i, 0);
        SUI::Button* lblParamValueName = dynamic_cast<SUI::Button*>(widget3);
        lblParamValueName->setStyleSheetClass("popupValue");
    }
    resizeDialog();
    IGSxGUI::Util::disableFloatArrayScrollbars(m_dialogFloatArray);
    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(0, 1));
    le->setFocus();
    SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(0, 0));
    btn->setVisible(true);
    IGSxGUI::Util::setEventFilterForFloatArray(lineEditWidgetVector, this);
}

int IGSxGUI::MachineconstantsView::getLastFilledEntryFA()
{
    int lastFilledEntry = -1;

    std::string currentValue = m_parameterData->getCurrentValue()->ToString();
    std::vector<std::string> currentValues;
    boost::split(currentValues, currentValue, boost::is_any_of(","));

    //Iterate through all the values till minimun count and
    //check whether the values are valid
    for (int i = m_parameterData->getMaxValueCount() - 1; i >= 0; --i) {
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        // line edit null means the line edit is not loaded yet and that line edit can be empty
        if (le == NULL) {
            std::string curVal = "";
            // Total number of line edits can be more than the current line edit vector size,
            // which means the line edits after current line edit vector size are empty
            if (static_cast<size_t>(i) < currentValues.size()) {
                curVal = currentValues.at(i);
            }
            if (curVal != "") {
                lastFilledEntry = i;
                break;
            }
        } else if (le->getText() != "") {
            lastFilledEntry = i;
            break;
        }
    }
    return lastFilledEntry;
}

bool IGSxGUI::MachineconstantsView::checkForUpdatedValuesFA()
{
    bool updatedValueValid = true;
    int  lastFilledEntry = getLastFilledEntryFA();
    int  minValue = m_parameterData->getMinValueCount();

    if (lastFilledEntry < minValue - 1){
        updatedValueValid = false;
    } else {
        for (int i = 0; i <= lastFilledEntry; i++) {
            SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
            SUI::LineEdit *letemp = dynamic_cast<SUI::LineEdit*>(widget);

            //If the line edit is NULL it means the line edit is not loaded
            //so the Value of such a line edit is valid value which can be empty since user has not changed it
            //Now in this scenario, the value can not be empty since we have alrady checked for last filled entry
            if ((letemp != NULL) && (false == isFloatArrayLineEditValueValid(letemp))){
                updatedValueValid = false;
                break;
            }
        }
    }
    return updatedValueValid;
}

void IGSxGUI::MachineconstantsView::onFAUpdatebuttonPressed()
{
    std::string name = getFAParameterName();
    std::string value = getFAParameterValue();
    bool updatedValueValid = false;
    int  minValue = m_parameterData->getMinValueCount();
    int lastFilledLineEdit = getLastFilledEntryFA();

    // minimum value count can be empty for some flaot array parameters, it means user should be able to update the empty float array.
    // There is a crash observed when user empties all the line edits and press update button, but as of now there is no clarity yet
    // on whether minvalue count can be 0 or not, we are aiming for crash prevention, for which we are not allowing update
    // when minValue is 0 and all the line edits empty
    if ((minValue == 0) && (lastFilledLineEdit == -1)) {
        updatedValueValid = false;
    } else {
        updatedValueValid = checkForUpdatedValuesFA();
    }

    if ((updatedValueValid == true) &&
        (!m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->isVisible())) {

        onFloatArrayParameterValueChanged(name, value);
        m_dialogFloatArray->close();
        doBasicFloatArrayLoad();
    }
    m_FAmodifiedLineEdits.clear();
}

std::string IGSxGUI::MachineconstantsView::getFAParameterName() const
{
    return m_lblParameterName->getText();
}

std::string IGSxGUI::MachineconstantsView::getFAParameterValue() const
{
    std::string currentValue = "";
    //If reset button pressed then return default value else current value.
    if (!isResetButtonPressed()) {
        currentValue = m_parameterData->getCurrentValue()->ToString();
    } else {
        currentValue =  m_parameterData->getDefaultValue()->ToString();
    }
    std::vector<std::string> currentValues;
    boost::split(currentValues, currentValue, boost::is_any_of(","));
    // form a string separated by ',' from all the filled line edits
    // the line edits after minimum count in float array can be empty
    std::string str = "";
    for (int i = 0; i < m_parameterData->getMaxValueCount(); ++i) {
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        if (le != NULL && le->getText() == "") {
            break;
        }
        // line edit null means the line edit is not loaded yet and that line edit can be empty
        if (le == NULL) {
            std::string curVal = "";
            // Total number of line edits can be more than the current line edit vector size,
            // which means the line edits after current line edit vector size are empty
            if (static_cast<size_t>(i) < currentValues.size()) {
                curVal = currentValues.at(i);
            }
            if (curVal != "") {
                str = str + "," + curVal;
            } else {
                break;
            }
        } else {
            str = str + "," + le->getText();
        }
    }
    return str.erase(0, 1);
}

void IGSxGUI::MachineconstantsView::enableOrDisableFAUpdateButton()
{

    SUI::Button *updateButton = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopUpdate");

    // minimum value count can be empty for some flaot array parameters, it means user should be able to update the empty float array.
    // There is a crash observed when user empties all the line edits and press update button, but as of now there is no clarity yet
    // on whether minvalue count can be 0 or not, we are aiming for crash prevention, for which we are not allowing update
    // when minValue is 0 and all the line edits empty, here we are disabling the update button
    int lastFilledLineEdit = getLastFilledEntryFA();
    int minValue = m_parameterData->getMinValueCount();

    if ((minValue == 0) && (lastFilledLineEdit == -1)) {
        updateButton->setEnabled(false);
        return;
    }

    std::string previousValue = m_parameterData->getPreviousValue()->ToString();
    std::string currentValue = m_parameterData->getCurrentValue()->ToString();
    std::vector<std::string> currentValues;
    boost::split(currentValues, currentValue, boost::is_any_of(","));
    std::vector<std::string> previousValues;
    boost::split(previousValues, previousValue, boost::is_any_of(","));
    // the line edits after minimum count in float array can be empty
    int lastFilledEntry = -1;
    for (int i = m_parameterData->getMaxValueCount() - 1; i >= 0; --i) {
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        // line edit null means the line edit is not loaded yet and that line edit can be empty
        if (le == NULL) {
            std::string curVal = "";
            // Total number of line edits can be more than the current line edit vector size,
            // which means the line edits after current line edit vector size are empty
            if (static_cast<size_t>(i) < currentValues.size()) {
                curVal = currentValues.at(i);
            }
            if (curVal != "") {
                lastFilledEntry = i;
                break;
            }
        } else if (le->getText() != "") {
            lastFilledEntry = i;
            break;
        }
    }
    if (lastFilledEntry == -1) {
        updateButton->setEnabled(true);
        return;
    }
    // form a string separated by ',' from all the filled line edits
    std::vector<std::string> paramValues;
    for (int i = 0; i <= lastFilledEntry; ++i) {
        if (dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(i, 1)) == NULL) {
            paramValues.push_back("na");
        } else {
            SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
            SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
            std::string val = le->getText();
            if (val == "") {
                paramValues.push_back("empty");
            } else {
                paramValues.push_back(val);
            }
        }
    }
    bool prevmatch = true;
    if (previousValues.size() != paramValues.size()) {
        prevmatch = false;
    } else {
        for (size_t i = 0; i < paramValues.size(); ++i) {
            if (paramValues.at(i) == "na") {
                continue;
            }

            double editedVal = 0.0;
            // the edited value can be very big value which can be beyond the capacity of double
            // so we need to first check to see if conversion from string to double is possible
            if (isConversionFromStringToDoublePossible(paramValues.at(i))) {
                editedVal = boost::lexical_cast<double>(paramValues.at(i));
            } else {
                prevmatch = false;
                break;
            }
            // here conversion possibility check is not required as the existing values are doubles in the form of string
            double previousVal = boost::lexical_cast<double>(previousValues.at(i));
            //to Check editedVal != currentVal
            if (std::fabs(editedVal - previousVal) > std::numeric_limits<double>::epsilon()) {
                prevmatch = false;
                break;
            }
        }
    }
    bool curmatch = true;
    if (currentValues.size() != paramValues.size()) {
        curmatch = false;
    } else {
        for (size_t i = 0; i < paramValues.size(); ++i) {
            if (paramValues.at(i) == "na") {
                continue;
            }

            double editedVal = 0.0;
            // the edited value can be very big value which can be beyond the capacity of double
            // so we need to first check to see if conversion from string to double is possible
            if (isConversionFromStringToDoublePossible(paramValues.at(i))) {
                editedVal = boost::lexical_cast<double>(paramValues.at(i));
            } else {
                curmatch = false;
                break;
            }
            // here conversion possibility check is not required as the existing values are doubles in the form of string
            double currentVal = boost::lexical_cast<double>(currentValues.at(i));

            //to Check editedVal != currentVal
            if (std::fabs(editedVal - currentVal) > std::numeric_limits<double>::epsilon()) {
                curmatch = false;
                break;
            }
        }
    }
    if (curmatch == true || prevmatch == true) {
        updateButton->setEnabled(false);
    } else {
        updateButton->setEnabled(true);
    }
}

void IGSxGUI::MachineconstantsView::setLineEditClearButtonVisibility(SUI::LineEdit * le, int row)
{
    SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(row, 0));
    if (le->hasFocus() && le->getText() != "")
    {
        btn->setVisible(true);
    } else {
        btn->setVisible(false);
    }
}

void IGSxGUI::MachineconstantsView::onFloatArrayParamValueTextChanged(SUI::LineEdit * le, int row, const std::string& value)
{
    enableOrDisableFAUpdateButton();
    setLineEditClearButtonVisibility(le, row);
    static size_t sizevar = 0;
    sizevar = value.size();
    bool textremoved = false;
    if (sizevar > value.size()) {
        textremoved = true;
    }
    sizevar = value.size();
    boost::regex dblregex("^[-+]?[0-9]*[.]?[0-9]{1, 8}([eE][-+]?[0-9]{1,2})?$");
    if (!boost::regex_match(value, dblregex)) {
        //sui->btnPopUpdate->setEnabled(false);
        std::string valuetmp = value;
        int x = IGSxGUI::Util::getLineEditCursorPosition(le);
        if (valuetmp.size() == 0) {
            // sui->btnPopUpdate->setEnabled(true);
            return;
        }
        // do not allow more than one '-' or '+' at start
        // also do not allow -+ and +- at start
        if (valuetmp.size() == 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+')) {
            return;
        } else if (valuetmp.size() > 1 && (valuetmp.at(0) == '-' || valuetmp.at(0) == '+') && (valuetmp.at(1) == '-' || valuetmp.at(1) == '+')) {
            eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
            return;
        }
        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            // do not allow 'e' or 'E'at 0th position
            if (valuetmp.size() == 1) {
                if (valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow any character other than comapred below
            if (valatcur != 'e' && valatcur != 'E' && valatcur != '-' && valatcur != '+' && valatcur != '.' && !textremoved) {
                eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                return;
            }
            // do not allow 'e' or 'E' before '.'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valuetmp.find('.', x) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow '.' after 'e' or 'E'
            if (valatcur == '.') {
                if (valuetmp.rfind('e', x-1) != std::string::npos || valuetmp.rfind('E', x-1) != std::string::npos) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
        }
        if (x > 1) {
            char valatcur = valuetmp.at(x-1);
            char valatprev = valuetmp.at(x-2);
            // do not allow more than one '-' after 'e' or 'E'
            // also do not allow -+ and +- after 'e' or 'E'
            if (valatcur == '-') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('-', x) != std::string::npos || valuetmp.find('+', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow more than one '+' after 'e' or 'E'
            // also do not allow -+ and +- after 'e' or 'E'
            if (valatcur == '+') {
                if ((valatprev != 'e' && valatprev != 'E') || (valuetmp.find('+', x) != std::string::npos || valuetmp.find('-', x) != std::string::npos)) {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow 'e' or 'E' immediately after after '-'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '-') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow 'e' or 'E' immediately after after '+'
            if (valatcur == 'e' || valatcur == 'E') {
                if (valatprev == '+') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
        }
        if (x > 0) {
            char valatcur = valuetmp.at(x-1);
            // do not allow more than 8 digits after '.'
            size_t pos1 = valuetmp.find('.');
            if (pos1 != std::string::npos) {
                size_t pos2 = valuetmp.find('e');
                size_t pos3 = valuetmp.find('E');
                if (pos2 != std::string::npos || pos3 != std::string::npos) {
                    std::string tmp = "";
                    if (pos2 != std::string::npos) {
                        tmp = valuetmp.substr(pos1+1, pos2-pos1-1);
                    } else {
                        tmp = valuetmp.substr(pos1+1, pos3-pos1-1);
                    }
                    if (tmp.size() > 8) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                        eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                        return;
                    } else if (tmp.size() == 0) {
                        int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                        if (valatcur == 'e' || valatcur == 'E') {
                            eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                            return;
                        }
                    }
                } else if (valuetmp.size() - pos1 > 8) {
                    int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow more than one 'e' or 'E'
            int count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == 'e' || valuetmp.at(i) == 'E') {
                    ++count;
                }
            }
            if (count > 1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                if (valatcur == 'e' || valatcur == 'E') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
            // do not allow more than one '.'
            count = 0;
            for (size_t i = 0; i < valuetmp.size(); ++i) {
                if (valuetmp.at(i) == '.') {
                    ++count;
                }
            }
            if (count > 1) {
                int x = IGSxGUI::Util::getLineEditCursorPosition(le);
                if (valatcur == '.') {
                    eraseEnteredCharFromLineEdit(le, valuetmp, x-1);
                    return;
                }
            }
        }
        return;
    }
}

void IGSxGUI::MachineconstantsView::eraseEnteredCharFromLineEdit(SUI::LineEdit *le, std::string& text,const int &pos)
{
    text.erase(pos, 1);
    le->setText(text);
    IGSxGUI::Util::setLineEditCursorPosition(le, pos);
}

void IGSxGUI::MachineconstantsView::removeEntryFromInvalidEntryListTillMinCountForFloatArray(int row)
{
    std::vector<int>::iterator it = std::find(m_floatArrayLineEditInvalidFieldsTillMinCount.begin(), m_floatArrayLineEditInvalidFieldsTillMinCount.end(), row);
    if (!m_floatArrayLineEditInvalidFieldsTillMinCount.empty() && it != m_floatArrayLineEditInvalidFieldsTillMinCount.end()) {
        m_floatArrayLineEditInvalidFieldsTillMinCount.erase(it);
    }
}

//The method will identify whether any value is present in lineedits
//with respect to current row and the remaining rows
bool IGSxGUI::MachineconstantsView::checkforvalidEntryInFloatArrayTable(int row)
{
    bool status = false;
    if (m_tawFloatArray != NULL){
        for (int i = row + 1; i < m_tawFloatArray->rowCount(); i++){
            SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(i, 1));
            if (lineEdit != NULL){
                if (lineEdit->getText() != ""){
                    status = true;
                    break;
                }
            }
        }
    }

    return status;
}

void IGSxGUI::MachineconstantsView::removeEntryFromInvalidEntryListAfterMinCountForFloatArray(int row)
{
    std::vector<int>::iterator it = std::find(m_floatArrayLineEditInvalidFieldsAfterMinCount.begin(), m_floatArrayLineEditInvalidFieldsAfterMinCount.end(), row);
    if (!m_floatArrayLineEditInvalidFieldsAfterMinCount.empty() && it != m_floatArrayLineEditInvalidFieldsAfterMinCount.end()) {
        m_floatArrayLineEditInvalidFieldsAfterMinCount.erase(it);
    }
}

void IGSxGUI::MachineconstantsView::addEntryToInvalidEntryListTillMinCountForFloatArray(int row)
{
    if (find(m_floatArrayLineEditInvalidFieldsTillMinCount.begin(), m_floatArrayLineEditInvalidFieldsTillMinCount.end(), row) == m_floatArrayLineEditInvalidFieldsTillMinCount.end()) {
        m_floatArrayLineEditInvalidFieldsTillMinCount.push_back(row);
    }
}

void IGSxGUI::MachineconstantsView::addEntryToInvalidEntryListAfterMinCountForFloatArray(int row)
{
    if (find(m_floatArrayLineEditInvalidFieldsAfterMinCount.begin(), m_floatArrayLineEditInvalidFieldsAfterMinCount.end(), row) == m_floatArrayLineEditInvalidFieldsAfterMinCount.end()) {
        m_floatArrayLineEditInvalidFieldsAfterMinCount.push_back(row);
    }
}

void IGSxGUI::MachineconstantsView::markEmptyFALineEditsInvalidFromCurrentRowTillMinCount(int currentRow)
{
    int i = currentRow - 1;
    for (; i >= m_parameterData->getMinValueCount(); --i) {
        // break if you encounter line edit which is not loaded yet, because if it not loaded, it is assumed to be filled with default value when loaded
        if (dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(i, 0)) == NULL) {
            break;
        }
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        if (le->getText() == "") {
            addEntryToInvalidEntryListAfterMinCountForFloatArray(i);
            showFloatArrayWarningForInvalidFields(le);
        }
    }
}

void IGSxGUI::MachineconstantsView::showFloatArrayWarningForInvalidFields(SUI::LineEdit* le)
{
    SUI::GroupBox *gb = m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue");
    if (!gb->isVisible()) {
        gb->setVisible(true);
    }
    le->setStyleSheetClass("floatArrayLeWarning");
    std::string min = m_parameterData->getMinValue()->ToString();
    IGSxGUI::Util::adjustDoublePrecision(min);
    std::string max = m_parameterData->getMaxValue()->ToString();
    IGSxGUI::Util::adjustDoublePrecision(max);
    std::string txt = "Please enter a value between " + min + " and " + max;
    m_dialogFloatArray->getObjectList()->getObject<SUI::Label>("lblUnrecommendedValueDesc")->setText(txt);
}

bool IGSxGUI::MachineconstantsView::areAllFloatArrayWidgetsLoadedAfterCurrentRow(int currentRow)
{
    bool loaded = true;
    for (int i = currentRow; i < m_parameterData->getMaxValueCount(); ++i) {
        if (dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(i, 0)) == NULL) {
            loaded = false;
            break;
        }
    }
    return loaded;
}

bool IGSxGUI::MachineconstantsView::isFloatArrayLineEditValueValid(SUI::LineEdit *le)
{
    std::string value = le->getText();
    if (value == "") {
        return false;
    }
    try {
        boost::lexical_cast<double>(value);
    } catch (boost::bad_lexical_cast &) {
        return false;
    }
    if (boost::lexical_cast<double>(value) < m_parameterData->getMinValue()->ToDouble() ||
            boost::lexical_cast<double>(value) > m_parameterData->getMaxValue()->ToDouble()) {
        return false;
    } else {
        return true;
    }
}

bool IGSxGUI::MachineconstantsView::areAllFALineEditsEmptyAfterCurrentRow(int currentRow)
{
    bool lineEditFilled = true;
    for (int i = currentRow + 1; i < m_parameterData->getMaxValueCount(); ++i) {
        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
        SUI::LineEdit *le = dynamic_cast<SUI::LineEdit*>(widget);
        if (le->getText() != "") {
            lineEditFilled = false;
            break;
        }
    }
    return lineEditFilled;
}

void IGSxGUI::MachineconstantsView::onFloatArrayParamValueTextEditFinished(SUI::LineEdit *le, int row)
{
    int minValueCount = m_parameterData->getMinValueCount();
    int maxValueCount = m_parameterData->getMaxValueCount();
    // user is allowed to leave the line edits empty after minValueCount, if user fills one line edit after minValueCount, then all the line edits
    // before the last filled line edit must be filled
    // basically the user is not allowed to leave any gaps between filled line edits
    // maxValueCount is the max number of line edits (values/entries)
    // the way the float array is implemented is, the widgets in the table (which includes line edits) will be loaded on demand for first time
    // the below validation is done as per the conditions above
    if (isFloatArrayLineEditValueValid(le)) {
        if (row < minValueCount) {
            removeEntryFromInvalidEntryListTillMinCountForFloatArray(row);
        } else {
            removeEntryFromInvalidEntryListAfterMinCountForFloatArray(row);
        }
        if (m_floatArrayLineEditInvalidFieldsTillMinCount.empty() && m_floatArrayLineEditInvalidFieldsAfterMinCount.empty()) {
            m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->setVisible(false);
        }
        le->setStyleSheetClass("floatArrayLe");
        if (row >= minValueCount) {
            // blank line edit before filled line edit is not valid
            // this scenario occurs when user clears (or already cleared) last "N" line edits
            // and then fills one of the line edits sucn that there are empty line edits before it
            markEmptyFALineEditsInvalidFromCurrentRowTillMinCount(row);
        }
    } else {
        if (row < minValueCount) {
            addEntryToInvalidEntryListTillMinCountForFloatArray(row);
            bool bLeHasFocus = le->hasFocus();
            showFloatArrayWarningForInvalidFields(le);
            if (bLeHasFocus)
            {
                le->setFocus();
            }
        } else {
            if (!areAllFloatArrayWidgetsLoadedAfterCurrentRow(row)) {
                if (le->getText() == "" && false == checkforvalidEntryInFloatArrayTable(row)){
                    for (int i = row; i >= minValueCount; i--) {
                        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
                        SUI::LineEdit *letemp = dynamic_cast<SUI::LineEdit*>(widget);
                        if (letemp->getText() == "") {
                            removeEntryFromInvalidEntryListAfterMinCountForFloatArray(i);
                            letemp->setStyleSheetClass("floatArrayLe");
                            if (m_floatArrayLineEditInvalidFieldsTillMinCount.empty() && m_floatArrayLineEditInvalidFieldsAfterMinCount.empty() &&
                                    m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->isVisible()) {
                                m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->setVisible(false);
                            }
                        } else {
                            break;
                        }
                    }
                } else {
                    addEntryToInvalidEntryListAfterMinCountForFloatArray(row);
                    bool bLeHasFocus = le->hasFocus();
                    showFloatArrayWarningForInvalidFields(le);
                    if (bLeHasFocus)
                    {
                        le->setFocus();
                    }
                }
            } else {
                if (!areAllFALineEditsEmptyAfterCurrentRow(row)) {
                    addEntryToInvalidEntryListAfterMinCountForFloatArray(row);
                    bool bLeHasFocus = le->hasFocus();
                    showFloatArrayWarningForInvalidFields(le);
                    if (bLeHasFocus)
                    {
                        le->setFocus();
                    }
                } else {
                    // here we handle two scenarios
                    // 1. few line edits which are at last are empty and now user fills any line edit with invalid value
                    //    in this case all the empty line edits before the not empty line edit must be marked as invalid
                    // 2. user keeps on clearing the line edits, at one point all the line edits from last till certain line edit becomes empty
                    //    in this case all the line edits till filled line edit from back which were marked invalid must be marked valid, because no gaps
                    int i = maxValueCount - 1;
                    for (; i >= minValueCount; --i) {
                        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
                        SUI::LineEdit *lineEdit = dynamic_cast<SUI::LineEdit*>(widget);
                        if (lineEdit->getText() == "") {
                            removeEntryFromInvalidEntryListAfterMinCountForFloatArray(i);
                            lineEdit->setStyleSheetClass("floatArrayLe");
                            if (m_floatArrayLineEditInvalidFieldsTillMinCount.empty() && m_floatArrayLineEditInvalidFieldsAfterMinCount.empty() &&
                                    m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->isVisible()) {
                                m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->setVisible(false);
                            }
                        } else {
                            if (!isFloatArrayLineEditValueValid(lineEdit)) {
                                addEntryToInvalidEntryListAfterMinCountForFloatArray(i);
                                showFloatArrayWarningForInvalidFields(lineEdit);
                            }
                            break;
                        }
                    }
                    // mark all the empty line edits before filled line edit till min count as invalid
                    for (; i >= minValueCount; --i) {
                        SUI::Widget* widget = m_tawFloatArray->getWidgetItem(i, 1);
                        SUI::LineEdit *minLineEdit = dynamic_cast<SUI::LineEdit*>(widget);
                        if (minLineEdit != NULL && minLineEdit->getText() == "") {
                            addEntryToInvalidEntryListAfterMinCountForFloatArray(i);
                            showFloatArrayWarningForInvalidFields(minLineEdit);
                        }
                    }
                }
            }
        }
    }
    if (m_resetButtonPressedFlag) {
        std::vector<int>::iterator it = std::find(m_FAmodifiedLineEdits.begin(), m_FAmodifiedLineEdits.end(), row);
        if (!m_FAmodifiedLineEdits.empty() && it != m_FAmodifiedLineEdits.end()) {
            if (row < static_cast<int>(m_floatArrayDefValues.size()))
            {
                if (le->getText() == m_floatArrayDefValues[row]) {
                     m_FAmodifiedLineEdits.erase(it);
                }
            } else {
                if (le->getText() == m_floatArrayValues[row]) {
                     m_FAmodifiedLineEdits.erase(it);
                }
            }
        } else {
            if (row < static_cast<int>(m_floatArrayDefValues.size())){
                if (le->getText() != m_floatArrayDefValues[row]) {
                     m_FAmodifiedLineEdits.push_back(row);
                }
            } else {
                if (le->getText() == m_floatArrayValues[row]) {
                     m_FAmodifiedLineEdits.push_back(row);
                }
            }
        }
    } else {
        std::vector<int>::iterator it = std::find(m_FAmodifiedLineEdits.begin(), m_FAmodifiedLineEdits.end(), row);

        if (!m_FAmodifiedLineEdits.empty() && it != m_FAmodifiedLineEdits.end()) {
            if (le->getText() == m_floatArrayValues[row]) {
                m_FAmodifiedLineEdits.erase(it);
            } else {
                m_floatArrayValues[row] = le->getText();
            }
        } else {
            if (le->getText() != m_floatArrayValues[row]) {
                 m_floatArrayValues[row] = le->getText();
                 m_FAmodifiedLineEdits.push_back(row);
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::initFloatArrayDialog(std::string floatParamName)
{
    m_floatArrayValues.clear();
    m_floatArrayNames.clear();
    m_floatArrayDefValues.clear();
    m_mapFAFormattedNames.clear();

    IGSxGUI::Util::setParent(m_dialogFloatArray, sui->lneSearchParameterText);
    IGSxGUI::Util::disableScrollbars(m_dialogFloatArray);
    IGSxGUI::Util::setDialogWidth(m_dialogFloatArray, 446);
    IGSxGUI::Util::setWindowFrame(m_dialogFloatArray, false);

    std::pair <std::string, int> formattedText = formatFloatArrayDialogParamName(floatParamName);
    m_lblParameterName->setText(formattedText.first);

    formatParamNameBack(floatParamName);
    m_parameterData = m_pMachineconstantsManager->findParameter(floatParamName);
    m_floatArrayNames = m_parameterData->getLabels();
    m_initialValues = m_parameterData->getCurrentValue()->ToString();
    std::vector<double>  floatArrayValues = m_parameterData->getCurrentValue()->ToFloatarray();
    std::vector<double> floatArrayDefaultValues = m_parameterData->getDefaultValue()->ToFloatarray();
    m_floatArrayValues.clear();
    m_floatArrayDefValues.clear();
    setResetButtonPressedFlag(false);
    for (size_t i=0; i < floatArrayValues.size(); i++) {
        std ::string val = boost::lexical_cast<std::string>(floatArrayValues.at(i));
        IGSxGUI::Util::adjustDoublePrecision(val);
        m_floatArrayValues.push_back(val);
    }
    for (int i= static_cast<int>(floatArrayValues.size()); i < m_parameterData->getMaxValueCount(); i++) {
        m_floatArrayValues.push_back("");
    }
    for (size_t i = 0; i < floatArrayDefaultValues.size(); ++i) {
        std ::string val = boost::lexical_cast<std::string>(floatArrayDefaultValues.at(i));
        IGSxGUI::Util::adjustDoublePrecision(val);
        m_floatArrayDefValues.push_back(val);
    }

    std::pair<std::string, std::string> pairFAFormattedNames;

    for (size_t i=0; i < m_floatArrayNames.size(); i++) {
        std::string valueText = m_floatArrayNames.at(i);
        pairFAFormattedNames.first = valueText;
        formatParamButtonName(m_btnFormat, valueText);
        pairFAFormattedNames.second = valueText;

        m_mapFAFormattedNames.insert(pairFAFormattedNames);
    }
}
void IGSxGUI::MachineconstantsView::resizeDialog()
{
    std::string name = m_lblParameterName->getText();
    int no_of_lines = boost::count(name, '\n') +1;
    int xParamName = m_lblParameterName->getGeometry().getX();
    int yParamName = m_lblParameterName->getGeometry().getY();
    int widthParamName = m_lblParameterName->getGeometry().getWidth();
    int hightParamName = 0;
    if (no_of_lines == 1) {
        hightParamName = 25;
    } else if (no_of_lines == 2) {
        hightParamName = 45;
    } else {
        hightParamName = 65;
    }
    m_lblParameterName->setGeometry(xParamName, yParamName, widthParamName, hightParamName);
    int row = m_tawFloatArray->rowCount();
    if (row > 16) {
        row = 16;
    }
    SUI::Rect rec = m_tawFloatArray->getGeometry();
    int xTable = rec.getX();
    int yTable = yParamName + hightParamName + 34;
    int widthTable = rec.getWidth();
    int heightTable = rec.getHeight();
    SUI::Rect rec2 = m_tawFloatArrayXButton->getGeometry();
    int xTableForXButton = rec2.getX();
    int widthTableForXButton = rec2.getWidth();
    int heightTableForXButton = rec2.getHeight();
    m_tawFloatArray->setGeometry(xTable, yTable, widthTable, heightTable);
    m_tawFloatArrayXButton->setGeometry(xTableForXButton, yTable, widthTableForXButton, heightTableForXButton);
    SUI::Label *defValLbl = m_dialogFloatArray->getObjectList()->getObject<SUI::Label>("lblDefaultValue");
    int xDefault =  defValLbl->getGeometry().getX();
    int widthDefault = defValLbl->getGeometry().getWidth();
    int hightDefault = defValLbl->getGeometry().getHeight();
    defValLbl->setGeometry(xDefault, yTable-9-13, widthDefault, hightDefault);
    int y = m_tawFloatArray->getGeometry().getY() + (row*42) + 54;
    int xUpdate = m_btnPopUpdate->getGeometry().getX();
    int widthUpdate = m_btnPopUpdate->getGeometry().getWidth();
    int hightUpdate = m_btnPopUpdate->getGeometry().getHeight();
    int xCancel = m_btnPopCancel->getGeometry().getX();
    int widthCancel = m_btnPopCancel->getGeometry().getWidth();
    int hightCancel = m_btnPopCancel->getGeometry().getHeight();
    int xReset = m_btnPopReset->getGeometry().getX();
    int widthReset  = m_btnPopReset->getGeometry().getWidth();
    int hightReset  = m_btnPopReset->getGeometry().getHeight();
    m_btnPopUpdate->setGeometry(xUpdate, y, widthUpdate, hightUpdate);
    m_btnPopCancel->setGeometry(xCancel, y, widthCancel, hightCancel);
    m_btnPopReset->setGeometry(xReset, y, widthReset, hightReset);
    int yReset = m_btnPopReset->getGeometry().getY();
    IGSxGUI::Util::setDialogHeight(m_dialogFloatArray, yReset+hightReset+20);
}

void IGSxGUI::MachineconstantsView::doBasicFloatArrayLoad()
{
    m_dialogFloatArray = SUI::UILoader::loadUI(FLOAT_ARRAY_UI_FILE_NAME.c_str());
    m_lblParameterName = m_dialogFloatArray->getObjectList()->getObject<SUI::Label>("lblParameterName");
    m_scbFloatArray = m_dialogFloatArray->getObjectList()->getObject<SUI::ScrollBar>("scbFloatArray");
    m_tawFloatArray = m_dialogFloatArray->getObjectList()->getObject<SUI::TableWidget>("tawFloatArray");
    m_tawFloatArrayXButton = m_dialogFloatArray->getObjectList()->getObject<SUI::TableWidget>("tawFloatArrayXButton");
    m_scbFloatArray->valueChanged = boost::bind(&MachineconstantsView::onFloatArrayDialogScrollbarValueChanged, this);
    m_btnUpdate = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopUpdate");
    m_btnUpdate->clicked = boost::bind(&MachineconstantsView::onFAUpdatebuttonPressed, this);
    SUI::Button *updateButton = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopUpdate");
    updateButton->setEnabled(false);
    getObjectsFromUIXml();
    m_dialogFloatArray->setModal(true);
    IGSxGUI::Util::setAwesome(m_btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::configureFloatArrayTable()
{
    m_tawFloatArray->showGrid(false);
    m_tawFloatArrayXButton->showGrid(false);
    IGSxGUI::Util::disableTableItemsSelection(m_tawFloatArray);
    IGSxGUI::Util::disableTableItemsSelection(m_tawFloatArrayXButton);
}

void IGSxGUI::MachineconstantsView::configureFloatArrayScrollbar()
{
    if (m_tawFloatArray->rowCount() <= 16) {
        IGSxGUI::Util::hideTableDefaultVerticalScrollbar(m_tawFloatArray);
    } else {
        IGSxGUI::Util::setVerticalScrollbar(m_tawFloatArray, m_scbFloatArray);
        IGSxGUI::Util::setScrollbarWidthOfTable(m_tawFloatArray, 20);
        IGSxGUI::Util::connectFloatArrayTablesScrollbars(m_tawFloatArray, m_tawFloatArrayXButton);
    }
}

void IGSxGUI::MachineconstantsView::onFloatArrayDialogScrollbarValueChanged()
{
    int pos = m_scbFloatArray->getValue();
    IGSxGUI::Util::processEvents();

    for (int i = pos; i < (pos+16); ++i) {
        if (i == m_tawFloatArray->rowCount()) {
            break;
        }
        if (dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(i, 0)) == NULL) {
            addWidgetsInEachRow(i);
        }
        showVaulesInEachRow(i);
    }
    refreshFloatArrayDialogSelection();
}

void IGSxGUI::MachineconstantsView::refreshFloatArrayDialogSelection()
{
   SUI::LineEdit* lineEdit2 = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(m_floatArrayPreviousLineEditIndex, 1));
   if (lineEdit2 != NULL)
   {
       lineEdit2->clearFocus();
       SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(m_floatArrayPreviousLineEditIndex, 0));
          if (btn != NULL)
          {
                  btn->setVisible(false);
          }
   }

   SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(m_floatArrayCurrentLineEditIndex, 1));
   if (lineEdit!= NULL)
   {
      lineEdit->setFocus();
      SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(m_floatArrayCurrentLineEditIndex, 0));
      if (btn != NULL)
      {
         if (lineEdit->getText() != "")
         {
            btn->setVisible(true);
         }
         else
         {
            btn->setVisible(false);
         }
      }
   }
}
void IGSxGUI::MachineconstantsView::addWidgetsInEachRow(int rowNum)
{
    std::vector<SUI::Widget*> lineEditWidgetVector;

    IGSxGUI::Util::addFAButton(m_tawFloatArray, rowNum, 0);
    IGSxGUI::Util::addLineEdit(m_tawFloatArray, rowNum, 1);
    IGSxGUI::Util::addFALabel(m_tawFloatArray, rowNum, 2);
    IGSxGUI::Util::addButton(m_tawFloatArrayXButton, rowNum, 0);

    IGSxGUI::Util::setRowHeight(m_tawFloatArray, rowNum, 42);
    IGSxGUI::Util::setRowHeight(m_tawFloatArrayXButton, rowNum, 42);

    SUI::Button *btnXTable = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(rowNum, 0));

    if(btnXTable != NULL) {
        IGSxGUI::Util::setAwesome(btnXTable, IGSxGUI::AwesomeIcon::AI_fa_close, "#AAAAAA", 18);
        btnXTable->clicked = boost::bind(&MachineconstantsView::clearLineEdit, this, rowNum);
        btnXTable->setVisible(false);
    }

    SUI::Button* btnParamName = dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(rowNum, 0));
    if(btnParamName != NULL) {
        btnParamName->hoverEntered = boost::bind(&MachineconstantsView::onParamNameButtonEntered, this, rowNum);
        btnParamName->hoverLeft = boost::bind(&MachineconstantsView::onParamNameButtonLeft, this, rowNum);
        btnParamName->setStyleSheetClass("popupValue");
    }

    SUI::LineEdit *leParamValue = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(rowNum, 1));
    if(leParamValue != NULL) {
        leParamValue->textChanged = boost::bind(&MachineconstantsView::onFloatArrayParamValueTextChanged, this, leParamValue, rowNum, _1);
        leParamValue->editingFinished = boost::bind(&MachineconstantsView::onFloatArrayParamValueTextEditFinished, this, leParamValue, rowNum);
        leParamValue->setAlignment(SUI::AlignmentEnum::Right);
        leParamValue->setStyleSheetClass("floatArrayLe");
        lineEditWidgetVector.push_back(leParamValue);
    }

    SUI::Label* lblParamDefVal = dynamic_cast<SUI::Label*>(m_tawFloatArray->getWidgetItem(rowNum, 2));
    if(lblParamDefVal != NULL) {
        lblParamDefVal->setStyleSheetClass("popupDefaultValue");
    }

    if (lineEditWidgetVector.size() > 0) {
        IGSxGUI::Util::setEventFilterForFloatArray(lineEditWidgetVector, this);
    }
}

void IGSxGUI::MachineconstantsView::showVaulesInEachRow(int index)
{
    std::string valueText = m_floatArrayNames.at(index);

    std::map<std::string, std::string>::iterator it = m_mapFAFormattedNames.find(valueText);
    if (it != m_mapFAFormattedNames.end())
    {
        dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(index, 0))->setText(it->second);
    }

    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(index, 1));
    if (le != NULL) {
        if(m_resetButtonPressedFlag) {
            std::vector<int>::iterator it = std::find(m_FAmodifiedLineEdits.begin(), m_FAmodifiedLineEdits.end(), index);

            if (it == m_FAmodifiedLineEdits.end()) {
                if (index < static_cast<int>(m_floatArrayDefValues.size())) {
                    le->setText(m_floatArrayDefValues.at(index));
                } else {
                    le->setText("");
                }
            }
        } else {
            if (index < static_cast<int>(m_floatArrayValues.size())) {
                le->setText(m_floatArrayValues.at(index));
            } else {
                le->setText("");
            }
        }
    }

    SUI::Label* label = dynamic_cast<SUI::Label*>(m_tawFloatArray->getWidgetItem(index, 2));
    if(label != NULL){
        if (index < static_cast<int>(m_floatArrayDefValues.size())) {
            label->setText(m_floatArrayDefValues.at(index));
        } else {
            label->setText("");
        }
    }
}

void IGSxGUI::MachineconstantsView::clearLineEdit(int row)
{
    // There is some jumping effect of scroll bar when we clear the line edit. Get the position of the scrollbar and set scroll bar position
    // back to where it was after clearing line edit
    int pos = m_scbFloatArray->getValue();
    SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(row, 1));
    le->clearText();
    le->setFocus();
    m_floatArrayValues[row] = "";
    m_scbFloatArray->setValue(pos);
}

void IGSxGUI::MachineconstantsView::getObjectsFromUIXml()
{
    m_gbxResetValues = m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxResetValues");
    m_btnPopReset = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopReset");
    m_btnPopCancel = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopCancel");
    m_btnPopCancel->clicked = boost::bind(&MachineconstantsView::onFloatArrayCancelButtonPressed, this);
    m_btnPopUpdate = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopUpdate");
    m_btnResetYes = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnResetYes");
    m_btnResetNo = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnResetNo");
    m_btnPopReset->clicked = boost::bind(&MachineconstantsView::onResetButtonPressed, this);
    m_btnResetYes->clicked = boost::bind(&MachineconstantsView::resetValuesYes, this);
    m_btnResetNo->clicked = boost::bind(&MachineconstantsView::resetValuesNo, this);
    m_btnClose = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnClose");
    m_btnClose->clicked = boost::bind(&MachineconstantsView::onFloatArrayCloseButtonPressed, this);
    m_btnClose->hoverEntered = boost::bind(&MachineconstantsView::onFloatArrayCloseButtonHoverEntered, this);
    m_btnClose->hoverLeft = boost::bind(&MachineconstantsView::onFloatArrayCloseButtonHoverLeft, this);
    m_gbxCancelValuesConfirm = m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxCancelValuesConfirm");
    m_btnCancelConfirmYes = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnCancelConfirmYes");
    m_btnCancelConfirmNo = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnCancelConfirmNo");
    m_btnCancelConfirmYes->clicked = boost::bind(&MachineconstantsView::onFloatArrayCancelYes, this);
    m_btnCancelConfirmNo->clicked = boost::bind(&MachineconstantsView::onFloatArrayCancelNo, this);
    m_btnFormat = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnFormat");
}
void IGSxGUI::MachineconstantsView::onResetButtonPressed()
{
    m_gbxResetValues->setVisible(true);
    setDialogEnable(false);
}

void IGSxGUI::MachineconstantsView::setResetButtonPressedFlag(bool flag)
{
    m_resetButtonPressedFlag = flag;
}
bool IGSxGUI::MachineconstantsView::isResetButtonPressed() const
{
    return m_resetButtonPressedFlag;
}

void IGSxGUI::MachineconstantsView::resetValuesYes()
{
    m_floatArrayLineEditInvalidFieldsTillMinCount.clear();
    m_floatArrayLineEditInvalidFieldsAfterMinCount.clear();
    m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->setVisible(false);

    setResetButtonPressedFlag(true);
    m_scbFloatArray->setValue(0);

    int i = 0;

    for (; i < static_cast<int>(m_floatArrayDefValues.size()); ++i) {
        SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(i, 1));
        if (lineEdit != NULL) {
            lineEdit->setText(m_floatArrayDefValues.at(i));
        }
    }

    for (int count = i; count < m_tawFloatArray->rowCount(); ++count) {
        SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(count, 1));
        if (lineEdit != NULL) {
            lineEdit->setText("");
        }
    }

    m_gbxResetValues->setVisible(false);
    setDialogEnable(true);
    enableOrDisableFAUpdateButton();
    setFALineEditClearButtonVisibility(m_floatArrayCurrentLineEditIndex, false);
    SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(0, 1));
    if (lineEdit != NULL) {
        lineEdit->setFocus();
    }
    m_FAmodifiedLineEdits.clear();
}

void IGSxGUI::MachineconstantsView::resetValuesNo()
{
    setDialogEnable(true);
    enableOrDisableFAUpdateButton();
    m_gbxResetValues->setVisible(false);
    // make invalid line edit border red
    for (size_t i = 0; i < m_floatArrayLineEditInvalidFieldsTillMinCount.size(); ++i) {
        setFALineEditErrorStyle(m_floatArrayLineEditInvalidFieldsTillMinCount.at(i));
    }
    for (size_t i = 0; i < m_floatArrayLineEditInvalidFieldsAfterMinCount.size(); ++i) {
        setFALineEditErrorStyle(m_floatArrayLineEditInvalidFieldsAfterMinCount.at(i));
    }
    // after reset no, the last focused line edit should get the focus, if the line edit has text the text should be selected and clear button "X" should be visibe
    // if line edit empty, the clear button should not be visible
    refreshFloatArrayDialogSelection();
}

void IGSxGUI::MachineconstantsView::setFALineEditErrorStyle(int row)
{
    SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(row, 1));
    if (lineEdit != NULL) {
        lineEdit->setStyleSheetClass(FA_LINEEDIT_ERRORSTYLE);
    }
}

void IGSxGUI::MachineconstantsView::setDialogEnable(bool enable)
{
    if (enable) {
        IGSxGUI::Util::enableTableScrollbar(m_tawFloatArray);
    } else {
        IGSxGUI::Util::disableTableScrollbar(m_tawFloatArray);
    }
    m_btnPopCancel->setEnabled(enable);
    m_btnPopReset->setEnabled(enable);
    m_btnPopUpdate->setEnabled(enable);
    for (int i = 0; i < m_tawFloatArray->rowCount(); ++i) {
        SUI::LineEdit* le = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(i, 1));
        if (le != NULL) {
            le->setEnabled(enable);
            if (enable) {
                le->setStyleSheetClass("floatArrayLe");
            } else {
                le->setStyleSheetClass("floatArrayLeDisable");
            }
        }
    }
    // at any time only one line edit will have clear button "X" visible, so enabling or disabling that clear button is sufficient
    SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(m_floatArrayCurrentLineEditIndex, 0));
    if (btn != NULL) {
        btn->setVisible(enable);
    }
}

void IGSxGUI::MachineconstantsView::onFloatArrayCloseButtonPressed()
{
    std::string onPressedColor = "#0AA8FB";
    IGSxGUI::Util::setAwesome(m_btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, onPressedColor, BUTTON_SIZE);
    IGSxGUI::Util::processEvents();
    onFloatArrayCancelButtonPressed();
}

void IGSxGUI::MachineconstantsView::onFloatArrayCloseButtonHoverEntered()
{
    std::string hoverOnColor = "#B3E2FF";
    IGSxGUI::Util::setAwesome(m_btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, hoverOnColor, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onFloatArrayCloseButtonHoverLeft()
{
    std::string hoverOffColor = "#AAAAAA";
    IGSxGUI::Util::setAwesome(m_btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, hoverOffColor, BUTTON_SIZE);
}

void IGSxGUI::MachineconstantsView::onFloatArrayCancelButtonPressed()
{
    SUI::Button *updateButton = m_dialogFloatArray->getObjectList()->getObject<SUI::Button>("btnPopUpdate");
    if (updateButton->isEnabled()) {
        m_gbxCancelValuesConfirm->setVisible(true);
        setDialogEnable(false);
    } else {
        onFloatArrayCancelYes();
    }
}

void IGSxGUI::MachineconstantsView::onFloatArrayCancelYes()
{
    m_floatArrayLineEditInvalidFieldsTillMinCount.clear();
    m_floatArrayLineEditInvalidFieldsAfterMinCount.clear();
    m_dialogFloatArray->getObjectList()->getObject<SUI::GroupBox>("gbxUnrecommendedValue")->setVisible(false);

    m_dialogFloatArray->close();
    doBasicFloatArrayLoad();
    m_FAmodifiedLineEdits.clear();
}

void IGSxGUI::MachineconstantsView::onFloatArrayCancelNo()
{
    setDialogEnable(true);
    m_gbxCancelValuesConfirm->setVisible(false);

    // make invalid line edit border red
    for (size_t i = 0; i < m_floatArrayLineEditInvalidFieldsTillMinCount.size(); ++i) {
        setFALineEditErrorStyle(m_floatArrayLineEditInvalidFieldsTillMinCount.at(i));
    }

    for (size_t i = 0; i < m_floatArrayLineEditInvalidFieldsAfterMinCount.size(); ++i) {
        setFALineEditErrorStyle(m_floatArrayLineEditInvalidFieldsAfterMinCount.at(i));
    }

    // after cancel no, the last focused line edit should get the focus, if the line edit has text the text should be selected and clear button "X" should be visibe
    // if line edit empty, the clear button should not be visible
	refreshFloatArrayDialogSelection();
}

void IGSxGUI::MachineconstantsView::setFALineEditClearButtonVisibility(int row, bool visibility) {
    SUI::LineEdit* lineEdit = dynamic_cast<SUI::LineEdit*>(m_tawFloatArray->getWidgetItem(row, 1));
    if (lineEdit != NULL) {
        SUI::Button *btn = dynamic_cast<SUI::Button*>(m_tawFloatArrayXButton->getWidgetItem(row, 0));
        if (btn != NULL) {
            btn->setVisible(visibility);
        }
    }
}

void IGSxGUI::MachineconstantsView::onParamNameButtonEntered(int row)
{
    const std::vector<std::string>& labels = m_parameterData->getLabels();
    SUI::Button* btn = dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(row, 0));
    std::string str = btn->getText();
    if (str.find("...") != std::string::npos) {
        btn->setToolTip(labels[row]);
    }
}

void IGSxGUI::MachineconstantsView::onParamNameButtonLeft(int row)
{
    SUI::Button* btn = dynamic_cast<SUI::Button*>(m_tawFloatArray->getWidgetItem(row, 0));
    btn->setToolTip("");
}

void IGSxGUI::MachineconstantsView::formatParamButtonName(SUI::Widget* widget, std::string& name)
{
    int columnWidth = 175;
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfButton(str, widget);
        if (total_chars_width > columnWidth)
        {
            break;
        }
    }
    if (i != name.size()) {
        name.replace(i-1, name.size(), "...");
        while (formatParamButtonNameAfterAddingDots(widget, name)) {}
    }
}

bool IGSxGUI::MachineconstantsView::formatParamButtonNameAfterAddingDots(SUI::Widget* widget, std::string& name)
{
    int columnWidth = 175;
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfButton(str, widget);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        int pos = static_cast<int>(name.find("..."));
        name.erase(pos-1, 1);
        return true;
    } else {
        return false;
    }
}

bool IGSxGUI::MachineconstantsView::isParameterDataSelected(int row) {
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    bool state = false;
    if (parameterData != NULL) {
        state = parameterData->isSelected();
    }
    return state;
}

void IGSxGUI::MachineconstantsView::setParameterDataSelected(int row, bool state) {
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    if (parameterData != NULL) {
        parameterData->setSelected(state);
        if (state) {
            if (parameterData->isReadOnly()) {
                IGSxGUI::Util::setParameterUCTReadOnlySelectedStyle(widget);
            }  else {
                IGSxGUI::Util::setParameterUCTClickedStyle(widget);
                if (parameterData->deviatesFromDefault()) {
                    IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
                }
            }
        } else {
            if (parameterData->isReadOnly()) {
                IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
            }  else {
                IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                if (parameterData->deviatesFromDefault()) {
                    IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                }
            }
        }
    }
}

void IGSxGUI::MachineconstantsView::selectUpRow()
{
    // after selecting some rows using shift + up, when user scroll down/up and does shift + up, then the selection should continue from last position
    if (m_currentRow != -1 && m_currentScrollBarPosition != m_previousScrollBarPosition) {
        sui->scbParametersTable->setValue(m_previousScrollBarPosition);
    }

    int currentRow = m_currentRow;
    int newRow = currentRow - 1;

    if (currentRow > 0) {
        if (isParameterDataSelected(newRow)) {
            setParameterDataSelected(currentRow, false);
        } else {
            setParameterDataSelected(newRow, true);
        }
        m_currentRow = m_currentRow - 1;
    }
    // currentRow = 0 means top visible row is seleced/unselected and next row to be selected/unselected is row before that
    // which means scrollbar value need to be changed if it exists
    else if (currentRow == 0 && sui->scbParametersTable->isVisible() && sui->scbParametersTable->getValue() != 0) {
        int visibleRowsBefore = numberOfRowsVisible(sui->tawParameters);
        sui->scbParametersTable->setValue(sui->scbParametersTable->getValue() - 1);
        int visibleRowsAfter = numberOfRowsVisible(sui->tawParameters);
        // after scrolling by one value, the number of visible rows may be equal to beofre, or greater than before or less than before
        if (visibleRowsAfter > visibleRowsBefore) {
            if (isParameterDataSelected(currentRow + 1) && isParameterDataSelected(currentRow)) {
                setParameterDataSelected(currentRow + 1, false);
            } else if (isParameterDataSelected(currentRow + 1) && !isParameterDataSelected(currentRow)) {
                m_currentRow = m_currentRow + 1;
            } else {
                setParameterDataSelected(currentRow + 1, true);
            }
        } else if (visibleRowsAfter == visibleRowsBefore) {
            if (isParameterDataSelected(currentRow)) {
                setParameterDataSelected(currentRow + 1, false);
            } else {
                setParameterDataSelected(currentRow, true);
            }
        } else if (visibleRowsAfter < visibleRowsBefore){
            if (isParameterDataSelected(currentRow + 1) && isParameterDataSelected(currentRow)) {
                setParameterDataSelected(currentRow + 1, false);
            } else if (isParameterDataSelected(currentRow + 1) && !isParameterDataSelected(currentRow)) {
                setParameterDataSelected(currentRow, true);
            } else {
                setParameterDataSelected(currentRow, true);
            }
        }
    }
    m_previousScrollBarPosition = sui->scbParametersTable->getValue();
    m_currentScrollBarPosition = sui->scbParametersTable->getValue();
}

void IGSxGUI::MachineconstantsView::selectDownRow()
{
    // after selecting some rows using shift + down, when user scroll down/up and does shift + down, then the selection should continue from last position
    if (m_currentRow != -1 && m_currentScrollBarPosition != m_previousScrollBarPosition) {
        sui->scbParametersTable->setValue(m_previousScrollBarPosition);
    }

    int currentRow = m_currentRow;
    int newRow = currentRow + 1;
    int visibleRows = numberOfRowsVisible(sui->tawParameters);

    if (currentRow != -1) {
        if (currentRow < visibleRows - 1) {
            if (isParameterDataSelected(newRow)) {
                setParameterDataSelected(currentRow, false);
            } else {
                setParameterDataSelected(newRow, true);
            }
            m_currentRow = m_currentRow + 1;
        }
        // currentRow = visibleRows - 1 means bottom most visible row is seleced/unselected and next row to be selected/unselected is row after that
        // which means scrollbar value need to be changed if it exists
        else if ((currentRow == visibleRows - 1) && sui->scbParametersTable->isVisible() &&
                    sui->scbParametersTable->getValue() != sui->scbParametersTable->getMaxValue()) {
            int visibleRowsBefore = numberOfRowsVisible(sui->tawParameters);
            sui->scbParametersTable->setValue(sui->scbParametersTable->getValue() + 1);
            int visibleRowsAfter = numberOfRowsVisible(sui->tawParameters);
            // after scrolling by one value, the number of visible rows may be equal to beofre, or greater than before, or less than before
            if (visibleRowsAfter > visibleRowsBefore) {
                if (isParameterDataSelected(currentRow - 1) && isParameterDataSelected(currentRow)) {
                    setParameterDataSelected(currentRow - 1, false);
                } else if (isParameterDataSelected(currentRow - 1) && !isParameterDataSelected(currentRow)) {
                    setParameterDataSelected(currentRow, true);
                } else {
                    setParameterDataSelected(currentRow, true);
                }
             } else if (visibleRowsAfter == visibleRowsBefore){
                if (isParameterDataSelected(currentRow)) {
                    setParameterDataSelected(currentRow -1, false);
                } else {
                    setParameterDataSelected(currentRow, true);
                }
            } else if (visibleRowsAfter < visibleRowsBefore){
                m_currentRow = m_currentRow - 1;
            }
        }
    }
    m_previousScrollBarPosition = sui->scbParametersTable->getValue();
    m_currentScrollBarPosition = sui->scbParametersTable->getValue();
}

int IGSxGUI::MachineconstantsView::numberOfRowsVisible(SUI::TableWidget *tablewidget)
{
    int  count = 0;
    if (tablewidget != NULL) {
        int rowCount = tablewidget->rowCount();
        for (int i = 0; i < rowCount; ++i) {
            if (tablewidget->isRowVisible(i)) {
                ++count;
            }
        }
    }
    return count;
}

void IGSxGUI::MachineconstantsView::invalidateCurrentRow()
{
    m_currentRow = -1;
}

void IGSxGUI::MachineconstantsView::setCurrentRow(int row)
{
    // current row is set only if the row is either first or last of the selected block
    // if there are multiple selected block, then current selected row is set to -1, which means shift up/down will not work
    if (gapInSelection(row)) {
        m_currentRow = -1;
    } else {
        m_currentRow = row;
    }

    if (m_currentRow != -1) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(m_currentRow, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        ParameterData* parameterData = getParameterDataForName(name);
        if (parameterData != NULL) {
            m_currentRowParamName = parameterData->getName();
        }
    }
}

bool IGSxGUI::MachineconstantsView::gapInSelection(int row)
{
    bool gapInSelection = false;
    std::vector<IGSxGUI::ParameterData*> parameterDataVec = m_pMachineconstantsManager->getParameterData();
    size_t totalSize = parameterDataVec.size();

    if (row != 0 && static_cast<size_t>(row) != totalSize - 1 && parameterDataVec.at(row - 1)->isSelected() && parameterDataVec.at(row + 1)->isSelected()) {
        gapInSelection = true;
    } else {
        bool start = false;
        bool stop = false;
        for (size_t i = 0; i < totalSize; ++i) {
            if (parameterDataVec.at(i)->isSelected()) {
                if (stop) {
                    gapInSelection = true;
                    break;
                }
                start = true;
            } else {
                if (start) {
                    stop = true;
                }
            }
        }
    }
    return gapInSelection;
}

void IGSxGUI::MachineconstantsView::selectShiftClickedRows(int row)
{
    SUI::Widget *widget = sui->tawParameters->getWidgetItem(row, 0);
    std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    formatParamNameBack(name);
    ParameterData* parameterData = getParameterDataForName(name);
    std::string lastParamNameToSelect = "";
    if (parameterData != NULL) {
        lastParamNameToSelect = parameterData->getName();
    }

    if (m_currentRowParamName == lastParamNameToSelect) {
        return;
    }

    std::vector<IGSxGUI::ParameterData*> parameterDataVec = m_pMachineconstantsManager->getParameterData();
    size_t totalSize = parameterDataVec.size();
    std::string paramName = "";
    bool start = false;
    bool stop = false;
    // select rows between m_currentRowParamName and lastParamNameToSelect, lastParamNameToSelect can be before m_currentRowParamName
    for (size_t i = 0; i < totalSize; ++i) {
        paramName = parameterDataVec.at(i)->getName();
        // identify the first row to select
        if (!start && (paramName == m_currentRowParamName || paramName == lastParamNameToSelect)) {
            start = true;
            parameterDataVec.at(i)->setSelected(true);
        }
        // identify the last row to select
        else if (start && (paramName == m_currentRowParamName || paramName == lastParamNameToSelect)) {
            stop = true;
            parameterDataVec.at(i)->setSelected(true);
        }
        // select all the rows between first and last to be selected
        else if (start && !stop) {
            parameterDataVec.at(i)->setSelected(true);
        }
        // unselect rows other than between first and last to be selected
        else {
            parameterDataVec.at(i)->setSelected(false);
        }
    }

    // after marking the rows as selected or unselected, refresh the visible rows to reflect the style
    // other row's style will be reflected as user scrolls
    refreshParamTableVisibleRowsForStyleUpdate();
}

void IGSxGUI::MachineconstantsView::refreshParamTableVisibleRowsForStyleUpdate()
{
    for (int i = 0; i < sui->tawParameters->rowCount(); ++i) {
        SUI::Widget *widget = sui->tawParameters->getWidgetItem(i, 0);
        std::string name = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        formatParamNameBack(name);
        ParameterData* parameterData = getParameterDataForName(name);
        bool state = false;
        if (parameterData != NULL) {
            state = parameterData->isSelected();

            if (state) {
                if (parameterData->isReadOnly()) {
                    IGSxGUI::Util::setParameterUCTReadOnlySelectedStyle(widget);
                }  else {
                    IGSxGUI::Util::setParameterUCTClickedStyle(widget);
                    IGSxGUI::Util::processEvents();
                    if (parameterData->deviatesFromDefault()) {
                        IGSxGUI::Util::setParameterUCTValueBoldWhiteStyle(widget, 1);
                    }
                }
            } else {
                if (parameterData->isReadOnly()) {
                    IGSxGUI::Util::setParameterUCTReadOnlyStyle(widget);
                }  else {
                    IGSxGUI::Util::setParameterUCTNormalStyle(widget);
                    if (parameterData->deviatesFromDefault()) {
                        IGSxGUI::Util::setParameterUCTBoldStyle(widget, 1);
                    }
                }
            }
        }
    }
}

bool IGSxGUI::MachineconstantsView::isConversionFromStringToDoublePossible(const std::string &value)
{
    try {
        boost::lexical_cast<double>(value);
        return true;
    } catch (boost::bad_lexical_cast &) {
        return false;
    }
}

int IGSxGUI::MachineconstantsView::getCurrentRow()
{
   return m_currentRow;
}

void IGSxGUI::MachineconstantsView::onWriteFineshedEventReceive(StringVectorType failedParameterNames)
{
    std::vector<int> pendingParamIndexesToBeRemoved;
    for (int rowcount = 0; rowcount < sui->tawMCPendingParam->rowCount(); ++rowcount) {
        SUI::Widget *pendingparamwidget = sui->tawMCPendingParam->getWidgetItem(rowcount, 0);
        std::string pendingparamname = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 0);
        formatParamNameBack(pendingparamname);
        size_t pos = pendingparamname.find('(');
        if (pos != std::string::npos) {
            pendingparamname.erase(pos - 1, pendingparamname.size());
        }
        if (std::find(failedParameterNames.begin(), failedParameterNames.end(), pendingparamname) == failedParameterNames.end()) {
            pendingParamIndexesToBeRemoved.push_back(rowcount);
        }
    }
    for (int i = static_cast<int>(pendingParamIndexesToBeRemoved.size()) - 1; i > 0; --i) {
        bool pendingParamTableScrollBarVisibleBefore = false;
        if (!isPendingParamTableScrollBarVisible()) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[i]));
        } else {
            pendingParamTableScrollBarVisibleBefore = true;
        }
        sui->tawMCPendingParam->removeRows(pendingParamIndexesToBeRemoved[i], 1);
        if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
            adjustCancelSaveButtonGeometryUp();
        }
    }
    if (static_cast<int>(pendingParamIndexesToBeRemoved.size()) > 0) {
        m_pendingParameterList.clear();
        if (sui->tawMCPendingParam->rowCount() == 1) {
            moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[0]));
            sui->tawMCPendingParam->setRowVisible(0, false);
            sui->lnePendingParamSaveName->clearText();
            sui->txaPendingParamSaveChangeReason->clearText();
            showSaveCancelButtons(false);
            showFinalSaveScreenItems(false);
            showNoPendingParameterScreen(true);
            sui->gbxPendingParamSaveError->setVisible(false);
            sui->gbxBI->setVisible(false);
            updateParameterTable();
        } else {
            bool pendingParamTableScrollBarVisibleBefore = false;
            if (!isPendingParamTableScrollBarVisible()) {
                moveSaveCancelButtons(UP, IGSxGUI::Util::getRowHeight(sui->tawMCPendingParam, pendingParamIndexesToBeRemoved[0]));
            } else {
                pendingParamTableScrollBarVisibleBefore = true;
            }
            sui->tawMCPendingParam->removeRows(pendingParamIndexesToBeRemoved[0], 1);
            if (pendingParamTableScrollBarVisibleBefore && !isPendingParamTableScrollBarVisible()) {
                adjustCancelSaveButtonGeometryUp();
            }
            for (int row = 0; row < sui->tawMCPendingParam->rowCount(); ++row) {
                pendingParamApplyRowBehavior(row);
                SUI::Widget *pendingparamwidget = sui->tawMCPendingParam->getWidgetItem(row, 0);
                std::string pendingparamName = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 0);
                std::string pendingparamValue = IGSxGUI::Util::getTextFromParameterUserControl(pendingparamwidget, 1);
                formatParamNameBack(pendingparamName);
                std::pair<std::string, std::string> nameValuePair(pendingparamName, pendingparamValue);
                m_pendingParameterList.push_back(nameValuePair);
            }
        }
    }
    sui->gbxPendingParamSaveError->setVisible(sui->tawMCPendingParam->isRowVisible(0));
}

void IGSxGUI::MachineconstantsView::historyRowPressed(const std::string &param)
{
    ParameterData* parameterData = getParameterDataForFullName(param);

    if ((parameterData != NULL) && (!parameterData->isReadOnly())) {
        IGSxGUI::Util::createModalWindow(m_dialogModality, sui->btnSearchAndClearIcon);
        if (parameterData->getValueType() == IGSxGUI::TYPE_floatarray) {
            loadFloatArrayDialog(param);
            IGSxGUI::Util::executeDialog(m_dialogFloatArray);
        } else {
            std::string def = parameterData->getDefaultValue()->ToString();
            std::string paramvalue = parameterData->getCurrentValue()->ToString();

            if (parameterData->getValueType() == IGSxGUI::TYPE_boolean) {
                m_parameterview.show(true, sui->lneSearchParameterText, param, def, paramvalue);
            } else {
                IGSxGUI::ITEMTYPE type = parameterData->getValueType();
                if (type == IGSxGUI::TYPE_double) {
                    IGSxGUI::Util::adjustDoublePrecision(paramvalue);
                    IGSxGUI::Util::adjustDoublePrecision(def);
                }
                m_parameterview.show(false, sui->lneSearchParameterText, param, def, paramvalue);
            }
        }
        IGSxGUI::Util::closeModalWindow(m_dialogModality);
    }
}

IGSxGUI::ParameterData* IGSxGUI::MachineconstantsView::getParameterDataForFullName(const std::string& name)
{
    return (m_pMachineconstantsManager->findParameter(name));
}
