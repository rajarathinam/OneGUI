/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManager.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver Manager
|
| ! \file        IGSxGUIxDriverManager.cpp
| ! \brief       Implementation of Driver Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxDriverManager.hpp"
#include <string>
#include <vector>
#include <algorithm>
#include <boost/lexical_cast.hpp>
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DriverManager::ERROR_ADDING_SYSFUN = "Error While Adding System Function";
const char* IGSxGUI::DriverManager::STRING_NEW_SYSTEM_STATE = "New system state: ";

IGSxGUI::DriverManager::DriverManager():
    m_systemState(SystemState::SS_RECOVERY_REQUIRED),
    m_Initializing(false),
    m_Terminating(false),
    m_driverState(DriverMode::DM_REAL)
{
}

IGSxGUI::DriverManager::~DriverManager()
{
    try
    {
        InitTerminate::getInstance()->unsubscribeToDriverStatusChanged();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (std::vector<SystemFunction*>::iterator it = m_systemFunctions.begin() ; it != m_systemFunctions.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
        }
    }
    m_systemFunctions.clear();
}

void IGSxGUI::DriverManager::addSystemFunctions(const MetaDescriptions& metaDescriptions)
{
    if (metaDescriptions.size() >0)
    {
        for (size_t i = 0; i < metaDescriptions.size(); i++)
        {
            IGSxGUI::SystemFunction* systemFunction = new SystemFunction(metaDescriptions[i]);
            if (systemFunction != NULL)
            {
                systemFunction->registerToDetermineMainState(boost::bind(&IGSxGUI::DriverManager::determineSystemState, this, _1));
                m_systemFunctions.push_back(systemFunction);
            } else {
                throw IGS::Exception(ERROR_ADDING_SYSFUN);
            }
        }
    } else {
        throw IGS::Exception(ERROR_ADDING_SYSFUN);
    }
    sort(m_systemFunctions.begin(), m_systemFunctions.end(), compareSystemFunction());
}

IGSxGUI::SystemFunction* IGSxGUI::DriverManager::getSystemFunction(const std::string &name) const
{
    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        if (m_systemFunctions[i]->getName() == name)
        {
            return m_systemFunctions[i];
        }
    }
    return NULL;
}

std::vector<IGSxGUI::SystemFunction*> IGSxGUI::DriverManager::getSystemFunctions() const
{
    return m_systemFunctions;
}

IGSxGUI::Driver* IGSxGUI::DriverManager::getDriver(const std::string& name) const
{
    Driver* driver = NULL;
    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        if (m_systemFunctions[i]->isManagingDriver(name))
        {
            driver = m_systemFunctions[i]->getDriver(name);
        }
    }
    return driver;
}

IGSxGUI::SystemState::SystemStateEnum IGSxGUI::DriverManager::getSystemState() const
{
    return m_systemState;
}

// If Initialize/Terminate button is clicked
// - determineSystemState(true) should not update the main status using setSystemState()
// - The onTerminateComplete()/onInitializeComplete() should perfrom the following
//   - The determineSystemState() should be called to know the final state of the system
//   - Then update the main status using setSystemState()
// --------------------------------------------------------------------------------------------------------------------
//     State            | Button        | Intermediate    | Final              | Calculation
// ---------------------------------------------------------------------------------------------------------------------
// Terminated           | Initialize    | Initializing    | Initialized        | All drivers initialized
// Terminated           | Initialize    | Initializing    | Recovery required  | At least one driver recovery required
// Recovery required    | Initialize    | Initializing    | Initialized        | All drivers initialized
// Recovery required    | Initialize    | Initializing    | Recovery required  | At least one driver recovery required
// Recovery required    | Terminate     | Terminating     | Terminated         | All drivers terminated
// Recovery required    | Terminate     | Terminating     | Recovery required  | At least one driver recovery required
// Initialized          | Terminate     | Terminating     | Recovery required  | At least one driver recovery required
// Initialized          | Terminate     | Terminating     | Terminated         | All drivers terminated
// Partially Initialized| Initialize    | Initializing    | Initialized        | All drivers initialized
// Partially Initialized| Initialize    | Initializing    | Recovery required  | At least one driver recovery required
// Partially Initialized| Terminate     | Terminating     | Terminated         | All drivers terminated
// Partially Initialized| Terminate     | Terminating     | Recovery required  | At least one driver recovery required
// ---------------------------------------------------------------------------------------------------------------------
//
// If Initialize/Terminate button is not clicked
// - The drivers are Initialized/Terminated not using OneGUI
// - Then determineSystemState(false) should update the main status using setSystemState() only for the following final state
// - SystemState::SS_INITIALIZED, SystemState::SS_TERMINATED, SystemState::SS_RECOVERY_REQUIRED, SystemState::SS_PARTIALLY_INITIALIZED
IGSxGUI::SystemState::SystemStateEnum IGSxGUI::DriverManager::determineSystemState(bool bSetState)
{
    SystemState::SystemStateEnum worstState = SystemState::SS_INITIALIZED;
    SystemState::SystemStateEnum newState = SystemState::SS_RECOVERY_REQUIRED;
    bool allInitialized = true;
    bool allTerminated = true;
    bool oneInitializing = false;
    bool oneTerminating = false;
    bool oneInitialized = false;
    bool oneTerminated = false;

    for (size_t i = 0; i < m_systemFunctions.size(); i++)
    {
        std::vector<Driver*> drivers = m_systemFunctions[i]->getDrivers();
        for (size_t j = 0; j < drivers.size(); j++)
        {
            if (drivers[j]->isImplemented())
            {
                DriverState::DriverStateEnum driverState = drivers[j]->getState();

                if (driverState != DriverState::DS_INITIALIZED) allInitialized = false;
                if (driverState != DriverState::DS_TERMINATED) allTerminated = false;
                if (driverState == DriverState::DS_INITIALIZING) oneInitializing = true;
                if (driverState == DriverState::DS_TERMINATING) oneTerminating = true;
                if (driverState == DriverState::DS_INITIALIZED) oneInitialized = true;
                if (driverState == DriverState::DS_TERMINATED) oneTerminated = true;
                if (driverState == DriverState::DS_RECOVERY_REQUIRED) worstState = SystemState::SS_RECOVERY_REQUIRED;
            }
        }
    }

    if (!bSetState)
    {
        if (oneInitializing)
        {
            newState = SystemState::SS_INITIALIZING;
        } else if (oneTerminating) {
            newState = SystemState::SS_TERMINATING;
        }
    }

    if (newState == SystemState::SS_RECOVERY_REQUIRED)
    {
        if (worstState == SystemState::SS_RECOVERY_REQUIRED){
            newState = worstState;
        }else if (allInitialized) {
            newState = SystemState::SS_INITIALIZED;
        } else if (allTerminated) {
            newState = SystemState::SS_TERMINATED;
        } else if ((!allInitialized) && (!allTerminated) && oneInitialized && oneTerminated) {
            newState = SystemState::SS_PARTIALLY_INITIALIZED;
        } else if ((worstState != SystemState::SS_INITIALIZED) && oneTerminated) {
            newState = SystemState::SS_TERMINATED;
        } else if ((worstState != SystemState::SS_INITIALIZED) && oneInitialized){
            newState = worstState;
        }
    }

    if (!bSetState)
    {
        setSystemState(newState);
    }
    return newState;
}
void IGSxGUI::DriverManager::registerToSystemStateChanged(const SystemStateChangedCallback& cb)
{
    m_systemStateChanged.connect(cb);
}

void IGSxGUI::DriverManager::unregisterToSystemStateChanged(const SystemStateChangedCallback& cb)
{
    m_systemStateChanged.disconnect(&cb);
}

void IGSxGUI::DriverManager::registerToInitializeCompleted(const initializeCompletedCallback &cb)
{
    m_initializeCompleted.connect(cb);
}

void IGSxGUI::DriverManager::unregisterToInitializeCompleted(const initializeCompletedCallback &cb)
{
    m_initializeCompleted.disconnect(&cb);
}

void IGSxGUI::DriverManager::registerToTerminateCompleted(const terminateCompletedCallback &cb)
{
    m_terminateCompleted.connect(cb);
}

void IGSxGUI::DriverManager::unregisterToTerminateCompleted(const terminateCompletedCallback &cb)
{
    m_terminateCompleted.disconnect(&cb);
}

// If Initialize/Terminate button is not clicked
// - The drivers are Initialized/Terminated not using OneGUI
// - Then determineSystemState(false) should update the main status using setSystemState(false) only for the following final state
// - SystemState::SS_INITIALIZED, SystemState::SS_TERMINATED, SystemState::SS_RECOVERY_REQUIRED, SystemState::SS_PARTIALLY_INITIALIZED
void IGSxGUI::DriverManager::setSystemState(const SystemState::SystemStateEnum &state)
{
    if ((!m_Initializing && !m_Terminating))
    {
        if ((state == SystemState::SS_INITIALIZED) || (state == SystemState::SS_TERMINATED) ||
             (state == SystemState::SS_RECOVERY_REQUIRED) || (state == SystemState::SS_PARTIALLY_INITIALIZED))
        {
            IGS_INFO(STRING_NEW_SYSTEM_STATE + SystemState::toString(state));
            m_systemState = state;
            m_systemStateChanged(state);
        }
    }
}

void IGSxGUI::DriverManager::setMainSystemState(const SystemState::SystemStateEnum &state)
{
    IGS_INFO(STRING_NEW_SYSTEM_STATE + SystemState::toString(state));
    m_systemState = state;
    m_systemStateChanged(state);
}

void IGSxGUI::DriverManager::initialize()
{
    try
    {
        addSystemFunctions(InitTerminate::getInstance()->getSysfuns());
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
        setMainSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }

    for (size_t i = 0; i < m_systemFunctions.size(); ++i)
    {
        MetaDescriptions drivers;
        try
        {
            drivers = InitTerminate::getInstance()->getDrivers(m_systemFunctions[i]->getName());
        } catch (IGS::Exception& ex)
        {
            IGS_ERROR(ex.what());
            setMainSystemState(SystemState::SS_RECOVERY_REQUIRED);
        }

        for (size_t j = 0; j < drivers.size(); j++ )
        {
            DriverStatus locDriverStatus(DriverState::DS_RECOVERY_REQUIRED);
            try
            {
                locDriverStatus = InitTerminate::getInstance()->getDriverStatus(drivers[j].name());
            } catch (IGS::Exception& ex)
            {
                IGS_ERROR(ex.what());
                setMainSystemState(SystemState::SS_RECOVERY_REQUIRED);
            }
            DriverMode::DriverModeEnum locDrivermode = InitTerminate::getInstance()->getDriverMode(drivers[j].name());

            m_systemFunctions[i]->addDriver(drivers[j], locDriverStatus.driverState(), locDrivermode);
            if (locDrivermode != DriverMode::DM_REAL) {
                m_driverState = locDrivermode;
            }
        }
    }

    try
    {
        InitTerminate::getInstance()->subscribeToDriverStatusChanged(boost::bind(&IGSxGUI::DriverManager::onDriverStatusChanged, this, _1, _2));
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
        setMainSystemState(SystemState::SS_RECOVERY_REQUIRED);
    }

    SystemState::SystemStateEnum newState = determineSystemState(true);
    setMainSystemState(newState);
}

std::string IGSxGUI::DriverManager::getDriverState()
{
    return DriverMode::toString(m_driverState);
}

void IGSxGUI::DriverManager::initializeSystem()
{
    try
    {
        m_Initializing = true;
        setMainSystemState(SystemState::SS_INITIALIZING);
        InitTerminate::getInstance()->initializeSystem(boost::bind(&IGSxGUI::DriverManager::onInitializeComplete, this, _1));
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }
}

void IGSxGUI::DriverManager::terminateSystem()
{
    try
    {
        m_Terminating = true;
        setMainSystemState(SystemState::SS_TERMINATING);
        InitTerminate::getInstance()->terminateSystem(boost::bind(&IGSxGUI::DriverManager::onTerminateComplete, this, _1));
    } catch (IGS::Exception& ex)
    {
        IGS_ERROR(ex.what());
    }
}

void IGSxGUI::DriverManager::onInitializeComplete(const IGS::Result &result)
{
    m_Initializing = false;
    IGS_INFO("onInitializeComplete() - result - " + boost::lexical_cast<std::string>(result));

    SystemState::SystemStateEnum newState = determineSystemState(true);
    setMainSystemState(newState);

    m_initializeCompleted();
}

void IGSxGUI::DriverManager::onTerminateComplete(const IGS::Result &result)
{
    m_Terminating = false;
    IGS_INFO("onTerminateComplete() - result - " + boost::lexical_cast<std::string>(result));

    SystemState::SystemStateEnum newState = determineSystemState(true);
    setMainSystemState(newState);

    m_terminateCompleted();
}

void IGSxGUI::DriverManager::onDriverStatusChanged(const std::string& driverName, const DriverStatus& status) const
{
    Driver* driver = getDriver(driverName);

    if (driver != NULL)
    {
        driver->updateDriverState(status.driverState());
    }
}
