

/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_SystemStateManagerView.cpp
| Author       : Saket K
| Description  : Implementation of Moc SystemStateManagerView
|
| ! \file        SystemStateManagerView.cpp
| ! \brief       Implementation of Moc SystemStateManagerView
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_SYSTEMSTATEMANAGER_CPP
#define IGSXGUIXMOC_SYSTEMSTATEMANAGER_CPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include "IGSxGUIxMoc_SSMView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIContainer.h>
#include <FWQxWidgets/SUITabWidget.h>
#include <boost/bind.hpp>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::SSMView::SSMView():
    container1(NULL),
    container2(NULL),
    container3(NULL),
    container4(NULL),
    container5(NULL),
    container6(NULL),
    tabWidget(NULL)
{
}

void SUI::SSMView::setupSUI(const char* /*xmlFileName*/) {
}


void SUI::SSMView::setupSUIContainer(const char* xmlFileName, SUI::Container* container) {
     container->setUiFilename(xmlFileName);
     loadObjects(container->getObjectList());
}


void SUI::SSMView::loadObjects(SUI::ObjectList* objectList) {
    tabWidget = objectList->getObject<SUI::TabWidget>("tbw4");

    container1 = objectList->getObject<SUI::Container>("cnt1");
    container2 = objectList->getObject<SUI::Container>("cnt2");
    container3 = objectList->getObject<SUI::Container>("cnt3");
    container4 = objectList->getObject<SUI::Container>("cnt4");
    container5 = objectList->getObject<SUI::Container>("cnt5");
    container6 = objectList->getObject<SUI::Container>("cnt6");
}



#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_CPP

