/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMStatusBarManager.cpp
| Author       : Saket K
| Description  : Implementation of SSM Statusbar manager
|
| ! \file        IGSxGUIxSSMStatusBarManager.cpp
| ! \brief       Implementation of Statusbar manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUILabel.h>
#include <IGSxGUIxSSMStatusBarManager.hpp>
#include <boost/bind.hpp>
#include <boost/algorithm/string.hpp>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include "IGSxLOG.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string UNKNOWN_TEXT = "UNKNOWN";
const std::string UNKNOWN_TIME = "<Unknown>";
const std::string ELAPSED_TIME_TEXT = "00 : 00 : 00";


IGSxGUI::SSMStatusBarManager::SSMStatusBarManager(StateList &states) :
    mStates(states),
    mTransitionTimer(SUI::Timer::createTimer())
{
    mTransitionTimer->timeout = boost::bind(&SSMStatusBarManager::onTransitionTimeout, this);
}

void IGSxGUI::SSMStatusBarManager::initWidgets(SUI::GroupBox* gbxCurrentState,
        SUI::GroupBox* gbxTransitionState,
        SUI::Label* lblCurrentStateText,
        SUI::Label* lblFromText,
        SUI::Label* lblToText,
        SUI::Label* lblStartTimeText,
        SUI::Label* lblExpectedDurationText,
        SUI::Label* lblElapsedTimeText)
{
    mGbxCurrentState = gbxCurrentState;
    mGbxTransitionState = gbxTransitionState;
    mlblCurrentStateText = lblCurrentStateText;
    mlblFromText = lblFromText;
    mlblToText = lblToText;
    mlblStartTimeText = lblStartTimeText;
    mlblExpectedDurationText = lblExpectedDurationText;
    mlblElapsedTimeText = lblElapsedTimeText;
}

void IGSxGUI::SSMStatusBarManager::startTimer()
{
   mElapsedTimeText = ELAPSED_TIME_TEXT;
   mTransitionTimer->start(1000);
}

void IGSxGUI::SSMStatusBarManager::setStartTime()
{
    mTransitionStartTime = SUI::Time::createTime();
}

IGSxGUI::SSMStatusBarManager::~SSMStatusBarManager()
{
}

void IGSxGUI::SSMStatusBarManager::show(IGSxGUI::TransitionData &activeTransition)
{
    if (activeTransition.FunctionResult == IGSxSSM::FUNCTION_ERROR) {
        mlblCurrentStateText->setText(UNKNOWN_TEXT);
        mTransitionTimer->stop();
        mGbxTransitionState->hide();
        mGbxCurrentState->show();
    } else if (activeTransition.From == activeTransition.To) {
        if (activeTransition.TransitionResult == IGSxSSM::TRANSITION_ERROR) {
            mlblCurrentStateText->setText(UNKNOWN_TEXT);
        } else {
            mlblCurrentStateText->setText(getStateText(activeTransition.From));
        }
        mTransitionTimer->stop();
        mGbxTransitionState->hide();
        mGbxCurrentState->show();
    } else {
        mlblFromText->setText(getStateText(activeTransition.From));
        mlblToText->setText(getStateText(activeTransition.To));
        std::string startText = "";
        if (mTransitionStartTime != NULL)
        {
            startText = mTransitionStartTime->toString("hh : mm : ss");
        }
        mlblStartTimeText->setText(startText);
        mlblElapsedTimeText->setText(mElapsedTimeText);
        mElapsedDurationSeconds = 0;
        mExpectedDurationSeconds = static_cast<int>(activeTransition.ExpectedDuration / 1000);
        updateExpectedDuration(activeTransition.ExpectedDuration);
        mGbxTransitionState->show();
        mGbxCurrentState->hide();
    }
}

void IGSxGUI::SSMStatusBarManager::updateExpectedDuration(const int expectedDuration)
{
    boost::shared_ptr<SUI::Time> expectedTime(SUI::Time::createTime());
    expectedTime->addMSecs(expectedDuration);
    boost::shared_ptr<SUI::Time> currentTime(SUI::Time::createTime());
    boost::shared_ptr<SUI::Time> remainingTime(SUI::Time::createTime());

    computeTimeDifference (expectedTime, currentTime, remainingTime);

    std::string expectedDurationText = remainingTime->toString("hh : mm : ss");
    if(expectedDurationText == "") {
        expectedDurationText = UNKNOWN_TIME;
    }

    mlblExpectedDurationText->setText(expectedDurationText);
}

void IGSxGUI::SSMStatusBarManager::onTransitionTimeout()
{
    boost::shared_ptr<SUI::Time> currentTime(SUI::Time::createTime());
    boost::shared_ptr<SUI::Time> remainingTime(SUI::Time::createTime());
    computeTimeDifference (currentTime, mTransitionStartTime, remainingTime);
    mElapsedTimeText = remainingTime->toString("hh : mm : ss");
    if (mElapsedTimeText == "") {
        mElapsedTimeText = UNKNOWN_TIME;
    }
    mlblElapsedTimeText->setText(mElapsedTimeText);
    ++mElapsedDurationSeconds;
}

void IGSxGUI::SSMStatusBarManager::computeTimeDifference(boost::shared_ptr<SUI::Time> t1,
                                                          boost::shared_ptr<SUI::Time> t2,
                                                          boost::shared_ptr<SUI::Time> difftime)
{

    boost::shared_ptr<SUI::DateTime> currentDateTime(SUI::DateTime::createDateTime());
    boost::shared_ptr<SUI::DateTime> transitionDateTime(SUI::DateTime::createDateTime());
    boost::shared_ptr<SUI::DateTime> remainingDateTime(SUI::DateTime::createDateTime());

    currentDateTime->setTime(t1);
    transitionDateTime->setTime(t2);

    difftime->setHMS(0,0,0);
    remainingDateTime->setTime(difftime);

    int64_t timeDiff = currentDateTime->toMSecsSinceEpoch() - transitionDateTime->toMSecsSinceEpoch();
    remainingDateTime->addMSecs(timeDiff);


    difftime->setHMS(remainingDateTime->getTime()->getHour(),
                     remainingDateTime->getTime()->getMinute(),
                     remainingDateTime->getTime()->getSecond());
}

std::string IGSxGUI::SSMStatusBarManager::getStateText(const IGSxSSM::StateIDType& stateId) const
{
    std::string stateName;
    for(size_t index = 0; index < mStates.size(); ++index)
    {
        if (mStates[index]->getId() == stateId)
        {
           stateName = mStates[index]->getStateName();
           std::replace(stateName.begin(), stateName.end(), '\n', ' ' );
           break;
        }
    }
    return stateName;
}
