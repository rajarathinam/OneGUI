/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMState.cpp
| Author       : Saket K
| Description  : Implementation of SSM State
|
| ! \file        IGSxGUIxSSMState.cpp
| ! \brief       Implementation of SSMState view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/

#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <FWQxWidgets/SUILabel.h>
#include <IGSxGUIxSSMState.hpp>
#include <boost/bind.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const SUI::Rect IGSxGUI::State::NON_TRANSITION_STATE_RECT = SUI::Rect(0,10,120,60);
const SUI::Rect IGSxGUI::State::TRANSITION_STATE_RECT = SUI::Rect(0,0,120,80);

IGSxGUI::State::State(SUI::UserControl *control, SUI::Button *button, SUI::BusyIndicator* bic, SUI::Label* lbl,  InnerState innerState, const int id, const bool abortable, const int index) :
    mUsercontrol(control), mButton(button), mBusyIndicator(bic), mOverlayLabel(lbl), mCurrentState(innerState), mId(id),mAbortable(abortable), mIndex(index)
{
    mButton->clicked = boost::bind(&State::buttonClicked, this);
}

void IGSxGUI::State::buttonClicked()
{
     clicked(mCurrentState, mId, mIndex);
}

SUI::UserControl *IGSxGUI::State::getUserControl()
{
    return mUsercontrol;
}

void IGSxGUI::State::show()
{
    mUsercontrol->show();
}

void IGSxGUI::State::hide()
{
    mUsercontrol->hide();
}

void IGSxGUI::State::setInnerState(IGSxGUI::InnerState innerState)
{
    mCurrentState = innerState;
}

IGSxGUI::InnerState IGSxGUI::State::getInnerState() const
{
    return mCurrentState;
}

void IGSxGUI::State::initButton(IGSxGUI::InnerState innerState)
{
    switch(innerState)
    {
    case REACHABLE:
    {
        mButton->setText(mName);
        mButton->setStyleSheetClass("StateReachable");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case ACTIVE:
    {
        mButton->setText(mName);
        mButton->setStyleSheetClass("StateActive");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case DISABLED:
    {
        mButton->setText(mName);
        mButton->setStyleSheetClass("StateDisabled");
        mButton->setGeometry(NON_TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case TRANSITION_START:
    {
        mButton->setText(mName);
        (mAbortable) ? mButton->setStyleSheetClass("StateTransitionStartAbortable") :
                       mButton->setStyleSheetClass("StateTransitionStartNonAbortable");
        mButton->setGeometry(TRANSITION_STATE_RECT);
        mBusyIndicator->hide();
        mOverlayLabel->hide();
        break;
    }
    case TRANSITION_END:
    {
        mButton->setText("");
        mButton->setStyleSheetClass("StateTransitionEnd");
        mButton->setGeometry(TRANSITION_STATE_RECT);
        mOverlayLabel->setText(mName);
        mOverlayLabel->setStyleSheetClass("StateOverlayLabel");
        mBusyIndicator->show();
        mOverlayLabel->show();
        break;
    }
    }
}

void IGSxGUI::State::setAbortable(bool abortable)
{
    mAbortable = abortable;
}

bool IGSxGUI::State::getAbortable() const
{
    return mAbortable;
}

int IGSxGUI::State::getId() const
{
    return mId;
}

std::string IGSxGUI::State::getStateName() const
{
    return mName;
}

void IGSxGUI::State::setStateName(const std::string& stateName)
{
    mName = stateName;
    mButton->setText(mName);
}
void IGSxGUI::State::registerToclicked(const clickedSignalCallback& cb)
{
     clicked.connect(cb);
}

void IGSxGUI::State::setState(InnerState innerState)
{
    mCurrentState = innerState;
}
