/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxHistorypopupView.cpp
| Author       : Venu
| Description  : Implementation of Historypopup view
|
| ! \file        IGSxGUIxHistorypopupView.cpp
| ! \brief       Implementation of Historypopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxCore/SUIUILoader.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUILineEdit.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIScrollBar.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <string>
#include <utility>
#include <vector>
#include <algorithm>
#include "IGSxGUIxHistorypopupView.hpp"
#include "IGSxGUIxMoc_HistorypopupView.hpp"
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include <boost/algorithm/string.hpp>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxGUI::HistorypopupView::BUTTON_SIZE = 18;
const int IGSxGUI::HistorypopupView::SORT_ICON_SIZE = 11;
const std::string IGSxGUI::HistorypopupView::HISTORYPOPUPVIEW_LOAD_FILE = "IGSxGUIxHistoryPopup.xml";
const std::string IGSxGUI::HistorypopupView::STRING_HISTORYPOPUPVIEW_SHOWN = "HistoryPopupView is Shown.";
const std::string IGSxGUI::HistorypopupView::STRING_SEARCH_PARAMETER = "Search parameter";
const std::string IGSxGUI::HistorypopupView::STRING_PARAMETERS_FOUND = "result(s) found";
const std::string IGSxGUI::HistorypopupView::STRING_PARAMETERNAME = "PARAMETER NAME";
const std::string IGSxGUI::HistorypopupView::STRING_CHANGEDON = " CHANGED ON";
const std::string IGSxGUI::HistorypopupView::STRING_CHANGEDBY = " CHANGED BY";
const std::string IGSxGUI::HistorypopupView::STRING_REASON = " REASON";

const std::string IGSxGUI::HistorypopupView::STYLE_HISTORY_SELECTED_HEADER = "historyselectedheader";
const std::string IGSxGUI::HistorypopupView::STYLE_HISTORY_NORMAL_HEADER = "historyparametername";
const std::string IGSxGUI::HistorypopupView::STRING_GREY_REGULAR = "#AAAAAA";
const std::string IGSxGUI::HistorypopupView::STRING_BLUE_REGULAR = "#B3E2FF";
const std::string IGSxGUI::HistorypopupView::STRING_BLUE_HEADER = "#1B3E93";
const std::string IGSxGUI::HistorypopupView::STYLE_AWESOME_ICONCOLOR = "#AAAAAA";
const std::string IGSxGUI::HistorypopupView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::HistorypopupView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::HistorypopupView::STYLE_SEARCH_PARAMETER = "searchparameter";
const std::string IGSxGUI::HistorypopupView::STYLE_SEARCHPARAM_NOITALIC = "searchparameterNoItalic";
const std::string IGSxGUI::HistorypopupView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::HistorypopupView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::HistorypopupView::STRING_EMPTY = "";
const int IGSxGUI::HistorypopupView::AWESOME_CLOSE_SIZE = 24;
const int IGSxGUI::HistorypopupView::ROW_HEIGHT = 40;
const size_t IGSxGUI::HistorypopupView::MAX_CHARS_OF_PARAMS_PER_LINE = 45;
const int IGSxGUI::HistorypopupView::MULTILINE_ROW_HEIGHT_INCREASE = 20;
const int IGSxGUI::HistorypopupView::MAX_VISIBLE_ROWS = 13;
const int IGSxGUI::HistorypopupView::MAX_VISIBLE_ROWS_TOTAL_HEIGHT = 520;

const int IGSxGUI::HistorypopupView::CONSTANT_ZERO = 0;
const int IGSxGUI::HistorypopupView::IMAGE_WIDTH = 20;
const int IGSxGUI::HistorypopupView::WIDGET_HEIGHT = 30;
const int IGSxGUI::HistorypopupView::PARAMNAME_WIDTH_BEFORE_SORTING = 127;
const int IGSxGUI::HistorypopupView::PARAMNAME_WIDTH_AFTER_SORTING = 140;
const int IGSxGUI::HistorypopupView::CHANGEDON_WIDTH_BEFORE_SORTING = 94;
const int IGSxGUI::HistorypopupView::CHANGEDON_WIDTH_AFTER_SORTING = 102;
const int IGSxGUI::HistorypopupView::CHANGEDBY_WIDTH_BEFORE_SORTING = 90;
const int IGSxGUI::HistorypopupView::CHANGEDBY_WIDTH_AFTER_SORTING = 98;
const int IGSxGUI::HistorypopupView::REASON_WIDTH_BEFORE_SORTING = 60;
const int IGSxGUI::HistorypopupView::REASON_WIDTH_AFTER_SORTING = 68;
const int IGSxGUI::HistorypopupView::OLDVALUE_WIDTH = 200;
const int IGSxGUI::HistorypopupView::NEWVALUE_WIDTH = 180;
const int IGSxGUI::HistorypopupView::TOOLTIP_WIDTH = 60;
const int IGSxGUI::HistorypopupView::SEARCH_TIMEOUT_MS = 500;
const int IGSxGUI::HistorypopupView::SCROLL_TIMEOUT_MS = 100;

const std::string IGSxGUI::HistorypopupView::STRING_NEWLINE = "\n";
const std::string IGSxGUI::HistorypopupView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string STRING_FALSE = "False (0)";
const std::string STRING_TRUE = "True (1)";

const std::string IGSxGUI::HistorypopupView::MODAL_DIALOG_LOAD_FILE = "IGSxGUIxMachineConstantModalPopup.xml";

IGSxGUI::HistroyRowPressedCallback IGSxGUI::HistorypopupView::m_histroyRowPressedCallback = NULL;

// https://stackoverflow.com/questions/3152241/case-insensitive-stdstring-find
template<typename charT>
struct my_equal {
    explicit my_equal(const std::locale& loc) : loc_(loc) {}
    bool operator()(charT ch1, charT ch2)
    {
        return std::toupper(ch1, loc_) == std::toupper(ch2, loc_);
    }
  private:
    const std::locale& loc_;
};

// contains substring (case insensitive)
template<typename T>
bool contains_substr(const T& strTarget, const T& strToSearch)
{
    const std::locale& loc = std::locale();
    typename T::const_iterator it = std::search(strTarget.begin(), strTarget.end(),
                                    strToSearch.begin(), strToSearch.end(), my_equal<typename T::value_type>(loc) );
    return  it != strTarget.end();
}

struct find_historyData {
    std::string m_name;
    std::string m_oldvalue;
    std::string m_newvalue;
    std::string m_author;
    std::string m_timeStr;
    find_historyData(std::string& name, std::string& oldvalue, std::string& newvalue, std::string& author, std::string& timeStr) : \
        m_name(name), m_oldvalue(oldvalue), m_newvalue(newvalue), m_author(author), m_timeStr(timeStr) {}
    bool operator()(const IGSxGUI::ParameterHistory& data) const
    {
        std::string tempTimeStr = IGSxGUI::SystemDateTime::formatDateTime(IGSxGUI::SystemDateTime::STR_DATE_TIME_SEC, data.time_of_change());
        bool result = (data.parameter_name().compare(m_name) == 0) && (tempTimeStr.compare(m_timeStr) ==0);
        return result;
    }
};
bool compareByParameterNameAsc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.parameter_name() < rhs.parameter_name();
}

bool compareByParameterNameDesc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.parameter_name() > rhs.parameter_name();
}
bool compareByChangedOnAsc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.time_of_change() < rhs.time_of_change();
}

bool compareByChangedOnDesc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.time_of_change() > rhs.time_of_change();
}
bool compareByChangedByAsc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.changed_by() < rhs.changed_by();
}

bool compareByChangedByDesc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.changed_by() > rhs.changed_by();
}

bool compareByReasonAsc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.reason() < rhs.reason();
}

bool compareByReasonDesc(const IGSxGUI::ParameterHistory& lhs, const IGSxGUI::ParameterHistory& rhs)
{
    return lhs.reason() > rhs.reason();
}

IGSxGUI::HistorypopupView::HistorypopupView(IGSxGUI::MachineconstantsManager* machineConstantsManager):
    sui(new SUI::HistorypopupView), m_isCtrlKeyPressed(false), m_currentRow(-1), m_shiftKeyPressed(false),
    m_searchText(STRING_EMPTY), m_previousScrollBarPosition(0), m_currentScrollBarPosition(0),
    m_SearchElapsedTime(SUI::Timer::createTimer()),
    m_ScrollElapsedTime(SUI::Timer::createTimer())
{
    sui->setupSUI(HISTORYPOPUPVIEW_LOAD_FILE.c_str());
    m_dialogModality = SUI::UILoader::loadUI(MODAL_DIALOG_LOAD_FILE.c_str());
    m_machineConstantsManager = machineConstantsManager;
    m_currentRow = -1;
    m_shiftKeyPressed = false;

    for (int i = 0; i < MAX_VISIBLE_ROWS; ++i) {
        m_previousSelectionList[i] = false;
    }

    m_SearchElapsedTime->timeout = boost::bind(&HistorypopupView::onSearchTextTimeElapsed, this);
    m_ScrollElapsedTime->timeout = boost::bind(&HistorypopupView::onScrollTimeElapsed, this);
}


IGSxGUI::HistorypopupView::~HistorypopupView()
{
    m_SearchElapsedTime->stop();
    m_SearchElapsedTime->timeout = NULL;

    m_ScrollElapsedTime->stop();
    m_ScrollElapsedTime->timeout = NULL;
    if (sui != NULL) {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::HistorypopupView::show()
{
    IGSxGUI::Util::setDialogWidth(sui->dialog, 1440);
    IGSxGUI::Util::setDialogHeight(sui->dialog, 700);
    init();
    setHandlers();
    getData();
    m_changedOnOrder = IGSxGUI::SortOrder::Descending;
    m_currentOrder = m_changedOnOrder;
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedOn;
    arrangeTableData(m_historyData, m_currentSortedColumn, m_changedOnOrder);
    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::setEventFilterForHistory(sui->dialog, sui->tawParametersHistory, sui->lneSearchParameterText, this);
    IGSxGUI::Util::executeDialog(sui->dialog);
    IGS_INFO(STRING_HISTORYPOPUPVIEW_SHOWN);
}

void IGSxGUI::HistorypopupView::init()
{
    m_selectedHistoryRowNum =  -1;
    m_paramNameOrder = IGSxGUI::SortOrder::Ascending;
    m_changedOnOrder = IGSxGUI::SortOrder::Ascending;
    m_changedByOrder = IGSxGUI::SortOrder::Ascending;
    m_reasonOrder = IGSxGUI::SortOrder::Ascending;
    m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    sui->lneSearchParameterText->setText(STRING_EMPTY);
    sui->lneSearchParameterText->setPlaceHolderText(STRING_SEARCH_PARAMETER);
    sui->btnSearchAndClearIcon->setVisible(true);
    sui->lblHistoryEntriesFound->setVisible(false);
    sui->lblParameterNameHistoryHeaderButtonText->setText(STRING_PARAMETERNAME);
    sui->lblChangedOnHistoryHeaderButtonText->setText(STRING_CHANGEDON);
    sui->lblChangedByHistoryHeaderButtonText->setText(STRING_CHANGEDBY);
    sui->lblReasonHistoryHeaderButtonText->setText(STRING_REASON);
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, IGSxGUI::AwesomeIcon::AI_fa_search, STRING_GREY_REGULAR, BUTTON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    createMaxVisibleRows(sui->tawParametersHistory, MAX_VISIBLE_ROWS);
    createSortingMap();

}
void IGSxGUI::HistorypopupView::createMaxVisibleRows(SUI::TableWidget *tableWidget, int numberOfRows)
{
    if (tableWidget != NULL) {
        tableWidget->removeRows(1, sui->tawParametersHistory->rowCount() - 1);
        for (int i = 0; i < (numberOfRows - 1); ++i) {
            tableWidget->appendRow();
            SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(i, 0);
            IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
    }
}
}

void IGSxGUI::HistorypopupView::setHandlers()
{
    std::vector<SUI::Widget*> historyTableHeaderWidgetVector;
    historyTableHeaderWidgetVector.push_back(sui->lblParameterNameHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblParameterNameHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedOnHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedOnHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedByHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblChangedByHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->lblReasonHistoryHeaderButtonText);
    historyTableHeaderWidgetVector.push_back(sui->lblReasonHistoryHeaderButtonImage);
    historyTableHeaderWidgetVector.push_back(sui->btnParameterOldValue);
    historyTableHeaderWidgetVector.push_back(sui->btnParameterNewValue);
    historyTableHeaderWidgetVector.push_back(sui->gbxParameterName);
    historyTableHeaderWidgetVector.push_back(sui->gbxChangedOn);
    historyTableHeaderWidgetVector.push_back(sui->gbxChangedBy);
    historyTableHeaderWidgetVector.push_back(sui->gbxReason);


    IGSxGUI::Util::historyTableHeaderInstallEventFilter(historyTableHeaderWidgetVector, sui->tawParametersHistory, sui->scbHistoryTable);
    sui->uctCloseHistory->clicked = boost::bind(&HistorypopupView::onUCTCloseHistoryClicked, this);
    sui->uctCloseHistory->hoverEntered = boost::bind(&HistorypopupView::onUCTCloseHistoryHoverOn, this);
    sui->uctCloseHistory->hoverLeft = boost::bind(&HistorypopupView::onUCTCloseHistoryHoverOff, this);
    sui->uctCloseHistory->pressed = boost::bind(&HistorypopupView::onUCTCloseHistoryPressed, this);
    sui->uctParameterName->clicked = boost::bind(&HistorypopupView::onParameterNameHeaderClicked, this);
    sui->uctChangedOn->clicked = boost::bind(&HistorypopupView::onChangedOnHeaderClicked, this);
    sui->uctChangedBy->clicked = boost::bind(&HistorypopupView::onChangedByHeaderClicked, this);
    sui->uctReason->clicked = boost::bind(&HistorypopupView::onReasonHeaderClicked, this);
    sui->scbHistoryTable->valueChanged = boost::bind(&HistorypopupView::onValueChanged, this);
    sui->lneSearchParameterText->textChanged = boost::bind(&HistorypopupView::onSearchTextEdited, this, _1);
    sui->lneSearchParameterText->editingFinished = boost::bind(&HistorypopupView::onSearchTextEditFinished, this);
    sui->btnSearchAndClearIcon->clicked = NULL;
    sui->btnSearchAndClearIcon->hoverLeft = boost::bind(&HistorypopupView::onSearchClearHoverLeft, this);
    sui->btnSearchAndClearIcon->hoverEntered = boost::bind(&HistorypopupView::onSearchClearHoverEntered, this);
}

void IGSxGUI::HistorypopupView::onSearchTextEdited(const std::string &text)
{
    m_searchText = text;
    if (m_searchText != "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCHPARAM_NOITALIC);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
    } else {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    }
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
    m_SearchElapsedTime->stop();
    m_SearchElapsedTime->start(SEARCH_TIMEOUT_MS);
}

void IGSxGUI::HistorypopupView::onSearchTextTimeElapsed()
{
    m_SearchElapsedTime->stop();
    refreshParameterList();
}

void IGSxGUI::HistorypopupView::onSearchTextEditFinished()
{
    if (m_searchText == "") {
        sui->lneSearchParameterText->setStyleSheetClass(STYLE_SEARCH_PARAMETER);
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_search;
    } else {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
    }
    IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
}

void IGSxGUI::HistorypopupView::onSearchClearHoverLeft()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
        break;
    }
    default:
        break;
    }
}

void IGSxGUI::HistorypopupView::onSearchClearHoverEntered()
{
    switch (m_searchItemIcon) {
    case IGSxGUI::AwesomeIcon::AI_fa_close: {
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_BLUE_REGULAR, BUTTON_SIZE);
        break;
    }
    default:
        break;
    }
}

void IGSxGUI::HistorypopupView::showSearchEntriesParameter(bool bShow)
{
    sui->lblHistoryEntriesFound->setVisible(bShow);
    if (bShow) {
        m_searchItemIcon = IGSxGUI::AwesomeIcon::AI_fa_close;
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, m_searchItemIcon, STRING_GREY_REGULAR, BUTTON_SIZE);
    }
}

int IGSxGUI::HistorypopupView::searchForParameters(const std::string& textToSearch, std::vector<ParameterHistory>&  matchedparameters)
{
    matchedparameters.clear();
    if (textToSearch.empty()) {
        return 0;
    }
    std::string searchText = textToSearch;
    IGSxGUI::Util::squeezSpaces(searchText);
    if (searchText == " ") {
        return 0;
    }
    boost::to_upper(searchText);

    int count = 0;
    size_t historyDataSize = m_historyData.size();
    for (size_t i = 0; i < historyDataSize; ++i) {
        const ParameterHistory& historyData = m_historyData[i];

        const std::vector<std::string>& paramEntries = historyData.getSearchString();
        bool found = false;
        for (std::vector<std::string>::const_iterator it = paramEntries.begin();
               it !=  paramEntries.end() && !found;
               ++it)
        {
             found = (*it).find(searchText ) != std::string::npos;
        }

        if (found)
        {
            ++count;
            ParameterHistory temp(m_historyData[i].parameter_name(), m_historyData[i].time_of_change(),
                                  m_historyData[i].changed_by(), m_historyData[i].reason(), m_historyData[i].old_value(),
                                  m_historyData[i].new_value(), false, false, m_historyData[i].isParamterInList());
            matchedparameters.push_back(temp);
        }
     }
    return count;
}

void IGSxGUI::HistorypopupView::refreshParameterList()
{
    if (m_searchText.empty()) {
        showSearchEntriesParameter(false);
        sui->scbHistoryTable->setMinValue(0);
        for (size_t i = 0; i < m_historyData.size(); ++i) {
            m_historyData[i].setState(false);
        }
        arrangeTableData(m_historyData, m_currentSortedColumn, m_currentOrder);
    } else {
        showSearchEntriesParameter(true);
        IGSxGUI::Util::setAwesome(sui->btnSearchAndClearIcon, IGSxGUI::AwesomeIcon::AI_fa_close, STRING_GREY_REGULAR, BUTTON_SIZE);
        int entriesfound = searchForParameters(m_searchText, m_matchedparameters);
        switch (m_currentSortedColumn) {
        case IGSxGUI::SortedByColumn::ParameterName:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ParameterName, m_paramNameOrder);
            break;
        case IGSxGUI::SortedByColumn::ChangedOn:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ChangedOn, m_changedOnOrder);
            break;
        case IGSxGUI::SortedByColumn::ChangedBy:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::ChangedBy, m_changedByOrder);
            break;
        case IGSxGUI::SortedByColumn::Reason:
            arrangeTableData(m_matchedparameters, IGSxGUI::SortedByColumn::Reason, m_reasonOrder);
            break;
        default:
            initializeTableRows(m_matchedparameters);
            break;
        }
        sui->lblHistoryEntriesFound->setText(boost::lexical_cast<std::string>(entriesfound) + " " + STRING_PARAMETERS_FOUND);
    }
}

void IGSxGUI::HistorypopupView::applyDataAndStyles(int rowIndex)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(rowIndex, 0);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&HistorypopupView::onParameterHistoryClicked, this, rowIndex);
    usercontrol->hoverEntered = boost::bind(&HistorypopupView::onParameterHistoryHoverEntered, this, rowIndex);
    usercontrol->hoverLeft = boost::bind(&HistorypopupView::onParameterHistoryHovLeft, this, rowIndex);
}

void IGSxGUI::HistorypopupView::extractSubStr(std::size_t found,  int& num_of_rows, std::string& retname, std::string& tmpname)
{
    if (retname == STRING_EMPTY) {
        retname = tmpname.substr(0, found);
    } else {
        retname = retname + STRING_NEWLINE + tmpname.substr(0, found);
    }
    num_of_rows++;
    tmpname = tmpname.substr(found, tmpname.size());
}

int IGSxGUI::HistorypopupView::UpperCasePosition(const std::string& name)
{
    size_t i = MAX_CHARS_OF_PARAMS_PER_LINE;
    for (; i > 0; --i) {
        if ((::isupper(name[i]) == 1) && (::isupper(name[i - 1]) != 1)) {
            return i;
        }
    }
    return i;
}
void IGSxGUI::HistorypopupView::formatParamValue(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        name.replace(i-1, name.size(), "...");
        while (formatParamValueAfterAddingDots(widget, name, columnWidth)) {}
    }
}

bool IGSxGUI::HistorypopupView::formatParamValueAfterAddingDots(SUI::Widget* widget, std::string& name, int columnWidth)
{
    int total_chars_width = 0;
    size_t i = 0;
    for (; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 1);
        if (total_chars_width > columnWidth) {
            break;
        }
    }
    if (i != name.size()) {
        size_t pos = name.find("....");  // after adding 3 dots there is possibility that the value will have 4 dots as the values are double
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        } else {
            size_t pos = name.find("...");
            name.erase(pos-1, 1);
        }
        return true;
    } else {
        size_t pos = name.find("....");
        if (pos != std::string::npos) {
            name.erase(pos, 1);
        }
        return false;
    }
}
void IGSxGUI::HistorypopupView::populateData(std::vector<ParameterHistory>::iterator it, int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    if (widget != NULL) {
        applyDataAndStyles(row);

        bool isSelected = (*it).isSelected();
        m_TableRows[row] = RowParameterHistoryType(isSelected, &(*it));

        std::string adjustedParameterName = STRING_EMPTY;
        if ((*it).parameter_name().length() > MAX_CHARS_OF_PARAMS_PER_LINE) {
            std::pair <std::string, int> formattedText = getFormattedsParamNameAndCalculateLineCount((*it).parameter_name());
            IGSxGUI::Util::setRowHeight(sui->tawParametersHistory, row, ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE);
            adjustedParameterName += formattedText.first;
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawParametersHistory, row, ROW_HEIGHT);
            adjustedParameterName += (*it).parameter_name();
        }
        IGSxGUI::Util::setUserControlFocusPolicy(widget);
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 0, adjustedParameterName);
        std::string oldValue = (*it).old_value();
        formatParamValue(widget, oldValue, OLDVALUE_WIDTH);
        std::string newValue = (*it).new_value();
        formatParamValue(widget, newValue, NEWVALUE_WIDTH);
        //Check if Boolean type and display value as "True (1)" or "False (0)" for old and new value
        IGSxGUI::ParameterData* parameterData = m_machineConstantsManager->findParameter((*it).parameter_name());
        if (parameterData != NULL)
        {
            if (IGSxGUI::TYPE_boolean == parameterData->getValueType())
            {
                if (oldValue == "0")
                {
                    oldValue = STRING_FALSE;
                    newValue = STRING_TRUE;
                }
                else
                {
                    oldValue = STRING_TRUE;
                    newValue = STRING_FALSE;
                }
            }
        }

        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 1, oldValue);
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 2, newValue);
        std::string str = IGSxGUI::SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, (*it).time_of_change());
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 3, str);

        std::string name = (*it).changed_by();
        std::string reason = (*it).reason();

        IGSxGUI::Util::replaceAmpersand(name, false);
        IGSxGUI::Util::replaceAmpersand(reason, false);

        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 4, name);
        IGSxGUI::Util::setTextToHistoryParameterUserControl(widget, 5, reason);
    }
}

void IGSxGUI::HistorypopupView::setDataReverse(int endIndex, std::vector<ParameterHistory> &collection)
{
    std::vector<ParameterHistory>::iterator beg_it = collection.begin() + endIndex;
    int rowsVisible = numberOfRowsVisible(sui->tawParametersHistory);
    m_TableRows.clear();

    m_TableRows.reserve(rowsVisible);
    for(int i=0; i<rowsVisible; ++i)
    {
         m_TableRows.push_back(RowParameterHistoryType(false, NULL));
    }
    for (int row = rowsVisible - 1; row >= 0; --row) {
        populateData(beg_it, row);
        std::advance(beg_it, - 1);
    }
}

void IGSxGUI::HistorypopupView::setValuesToScrollbar(bool visibility, int minValue, int maxValue, int actualValue)
{
    sui->scbHistoryTable->setVisible(visibility);
    sui->scbHistoryTable->setMinValue(minValue);
    sui->scbHistoryTable->setMaxValue(maxValue);
    sui->scbHistoryTable->setValue(actualValue);
}

void IGSxGUI::HistorypopupView::initializeTableRows(ParameterHistoryVector &collection)
{

    int collectionSize = static_cast<int>(collection.size());
    if (collectionSize <= 0) {
        sui->tawParametersHistory->setVisible(false);
        sui->scbHistoryTable->setVisible(false);
    } else {
        sui->tawParametersHistory->showGrid(false);
        sui->tawParametersHistory->setVisible(true);
        sui->scbHistoryTable->setVisible(false);
        int totalRowHeight = 0;
        size_t maxRowsCanFit = 0;

        std::vector<ParameterHistory>::iterator beg_it = collection.begin();
        for (; maxRowsCanFit < collection.size(); ++maxRowsCanFit, ++beg_it) {
            if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
                break;
            }
            std::pair <std::string, int> formattedText = getFormattedsParamNameAndCalculateLineCount(collection[maxRowsCanFit].parameter_name());
            totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
        }

        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            maxRowsCanFit--;
            setValuesToScrollbar(true, 0, collection.size() - maxRowsCanFit, 0);
        } else {
            sui->scbHistoryTable->setVisible(false);
        }
        adjustTableRowVisibility(sui->tawParametersHistory, maxRowsCanFit);
        setData(0, maxRowsCanFit, collection);
        m_lastIndex = static_cast<int>(maxRowsCanFit - 1);
    }
}

void IGSxGUI::HistorypopupView::setData(int value, int rows, std::vector<ParameterHistory> &collection)
{
    std::vector<ParameterHistory>::iterator beg_it = collection.begin();
    std::vector<ParameterHistory>::iterator it = collection.end();
    m_TableRows.clear();
    m_TableRows.reserve(rows);
    for(int i=0; i<rows; ++i)
    {
        m_TableRows.push_back(RowParameterHistoryType(false, NULL));
    }
    for (int row = 0; row < rows; ++row) {
        it = beg_it;
        std::advance(it, row + value);
        populateData(it, row);
        bool isSelected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(row, isSelected, isParamInlist);
        applyStyleSheetToRow(row, isSelected, isParamInlist);
    }
}
void IGSxGUI::HistorypopupView::setTableRows(int value, std::vector<ParameterHistory> &collection)
{
    int totalRowHeight = 0;
    int maxRowsCanFit = 0;

    std::vector<ParameterHistory>::iterator beg_it = collection.begin() + (m_lastIndex + value);
    for (; beg_it >= collection.begin(); ++maxRowsCanFit, --beg_it) {
        if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
            break;
        }
        std::pair <std::string, int> formattedText = getFormattedsParamNameAndCalculateLineCount(beg_it->parameter_name());
        totalRowHeight = totalRowHeight + ROW_HEIGHT + (formattedText.second - 1) * MULTILINE_ROW_HEIGHT_INCREASE;
    }

    if (totalRowHeight > MAX_VISIBLE_ROWS_TOTAL_HEIGHT) {
        maxRowsCanFit--;
    }

    adjustTableRowVisibility(sui->tawParametersHistory, maxRowsCanFit);
    setDataReverse(m_lastIndex + value, collection);
}

void IGSxGUI::HistorypopupView::onValueChanged()
{

    m_currentScrollBarPosition = sui->scbHistoryTable->getValue();
    if (sui->lneSearchParameterText->getText().empty()) {
        setTableRows(sui->scbHistoryTable->getValue(), m_historyData);
    } else {
        setTableRows(sui->scbHistoryTable->getValue(), m_matchedparameters);
    }

    updateSelectionChangedRowsOnScroll();
}

void IGSxGUI::HistorypopupView::onScrollTimeElapsed()
{
    m_ScrollElapsedTime->stop();
    for(int i=0 ; i< static_cast<int>(m_TableRows.size()); ++i)
    {
        bool isSelected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(i, isSelected, isParamInlist);
        applyStyleSheetToRow(i, isSelected, isParamInlist);
    }
}

void IGSxGUI::HistorypopupView::updateSelectionChangedRowsOnScroll()
{
    for(int i=0 ; i< static_cast<int>(m_TableRows.size()); ++i)
    {
        bool prevSelection = m_previousSelectionList[i];
        bool isSelected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(i, isSelected, isParamInlist);
        if(prevSelection != isSelected)
        {
            m_previousSelectionList[i] = isSelected;
        }
    }

    m_ScrollElapsedTime->stop();
    m_ScrollElapsedTime->start(SCROLL_TIMEOUT_MS);
}

void IGSxGUI::HistorypopupView::applyStyleSheetToRow(const int rowNumber, const bool bSelect, const bool bParamInList)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(rowNumber, 0);
    if (widget != NULL) {

        if (bParamInList)
        {
            if (bSelect == true) {
                IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
            }
        }
        else
        {
            //Grayed style - same as parameter list
            if (bSelect == true) {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(widget);
            }
        }
    }
}

void IGSxGUI::HistorypopupView::getData()
{
    m_historyData.clear();
    m_machineConstantsManager->getHistory(m_historyData);
    sui->tawParametersHistory->setVisible(true);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryClicked()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_ASML_COLORORANGE, AWESOME_CLOSE_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
    sui->lblCloseImage->setBGColor(SUI::ColorEnum::White);
    IGSxGUI::Util::removeEventFilterForHistory(sui->dialog);
    sui->dialog->close();
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryHoverOn()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryHoverOff()
{
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::HistorypopupView::onUCTCloseHistoryPressed()
{
    std::string color = "#FF7F45";
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, color, AWESOME_CLOSE_SIZE);
}


void IGSxGUI::HistorypopupView::createSortingMap()
{
    std::vector<FPTR> paramNameFunctions;
    paramNameFunctions.push_back(&compareByParameterNameAsc);
    paramNameFunctions.push_back(&compareByParameterNameDesc);
    std::vector<FPTR> changedOnFunctions;
    changedOnFunctions.push_back(&compareByChangedOnAsc);
    changedOnFunctions.push_back(&compareByChangedOnDesc);
    std::vector<FPTR> changedByFunctions;
    changedByFunctions.push_back(&compareByChangedByAsc);
    changedByFunctions.push_back(&compareByChangedByDesc);
    std::vector<FPTR> reasonFunctions;
    reasonFunctions.push_back(&compareByReasonAsc);
    reasonFunctions.push_back(&compareByReasonDesc);
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ParameterName] = paramNameFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ChangedOn] =  changedOnFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::ChangedBy] =  changedByFunctions;
    m_sortFunctionMap[IGSxGUI::SortedByColumn::Reason] =  reasonFunctions;
}

void IGSxGUI::HistorypopupView::sortCollection(IGSxGUI::ParameterHistoryVector& tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder, SUI::Label* label)
{
    if (sortOrder == IGSxGUI::SortOrder::Ascending) {
        std::sort(tableData.begin(), tableData.end(), m_sortFunctionMap[sortColumn][0]);
        IGSxGUI::Util::setAwesome(label, IGSxGUI::AwesomeIcon::AI_fa_sort_asc, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    } else {
        IGSxGUI::Util::setAwesome(label, IGSxGUI::AwesomeIcon::AI_fa_sort_desc, STRING_BLUE_HEADER, SORT_ICON_SIZE);
        std::sort(tableData.begin(), tableData.end(), m_sortFunctionMap[sortColumn][1]);
    }
}

void IGSxGUI::HistorypopupView::arrangeTableData(IGSxGUI::ParameterHistoryVector& tableData, IGSxGUI::SortedByColumn::SortedColumEnum sortColumn, IGSxGUI::SortOrder::SortOrderEnum sortOrder)
{

    // setting current row to -1 so that after sorting the rows, shift should not work untill selecting a row by clicking it
    m_currentRow = -1;

    IGSxGUI::Util::setAwesome(sui->lblParameterNameHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblChangedOnHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblChangedByHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblReasonHistoryHeaderButtonImage, IGSxGUI::AwesomeIcon::AI_fa_sort_default, STRING_BLUE_HEADER, SORT_ICON_SIZE);
    sui->lblParameterNameHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblParameterNameHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, PARAMNAME_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblParameterNameHistoryHeaderButtonImage->setGeometry(PARAMNAME_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblChangedOnHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblChangedOnHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDON_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblChangedOnHistoryHeaderButtonImage->setGeometry(CHANGEDON_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblChangedByHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblChangedByHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDBY_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblChangedByHistoryHeaderButtonImage->setGeometry(CHANGEDBY_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    sui->lblReasonHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_NORMAL_HEADER);
    sui->lblReasonHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, REASON_WIDTH_BEFORE_SORTING, WIDGET_HEIGHT);
    sui->lblReasonHistoryHeaderButtonImage->setGeometry(REASON_WIDTH_BEFORE_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
    switch (sortColumn) {
    case IGSxGUI::SortedByColumn::ParameterName:
        sui->lblParameterNameHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblParameterNameHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, PARAMNAME_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblParameterNameHistoryHeaderButtonImage->setGeometry(PARAMNAME_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblParameterNameHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::ChangedOn:
        sui->lblChangedOnHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblChangedOnHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDON_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblChangedOnHistoryHeaderButtonImage->setGeometry(CHANGEDON_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblChangedOnHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::ChangedBy:
        sui->lblChangedByHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblChangedByHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, CHANGEDBY_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblChangedByHistoryHeaderButtonImage->setGeometry(CHANGEDBY_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblChangedByHistoryHeaderButtonImage);
        break;
    case IGSxGUI::SortedByColumn::Reason:
        sui->lblReasonHistoryHeaderButtonText->setStyleSheetClass(STYLE_HISTORY_SELECTED_HEADER);
        sui->lblReasonHistoryHeaderButtonText->setGeometry(CONSTANT_ZERO, CONSTANT_ZERO, REASON_WIDTH_AFTER_SORTING, WIDGET_HEIGHT);
        sui->lblReasonHistoryHeaderButtonImage->setGeometry(REASON_WIDTH_AFTER_SORTING, CONSTANT_ZERO, IMAGE_WIDTH, WIDGET_HEIGHT);
        sortCollection(tableData, sortColumn, sortOrder, sui->lblReasonHistoryHeaderButtonImage);
        break;
    default:
        break;
    }

    initializeTableRows(tableData);
    resetSelection();
}

void IGSxGUI::HistorypopupView::selectAllRows()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        for (size_t i = 0; i < m_historyData.size(); ++i) {
            m_historyData[i].setState(true);
        }
    } else {
        for (size_t i = 0; i < m_matchedparameters.size(); ++i) {
            m_matchedparameters[i].setState(true);
        }
    }
}

void IGSxGUI::HistorypopupView::selectUpRow()
{
    // after selecting some rows using shift + up, when user scroll down/up and does shift + up, then the selection should continue from last position
    if (m_currentRow != -1 && m_currentScrollBarPosition != m_previousScrollBarPosition) {
        sui->scbHistoryTable->setValue(m_previousScrollBarPosition);
    }

    int currentRow = m_currentRow;
    int newRow = currentRow - 1;

    if (currentRow > 0) {
        bool isSelected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(newRow, isSelected, isParamInlist);

        if (isSelected) {
            SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow, 0);
            getParameterHistoryDataInformation(currentRow, isSelected, isParamInlist);
            if (isParamInlist) {
                IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
            }
            setParameterHistoryDataSelected(currentRow, false);
        } else {
            SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(newRow, 0);
            if (isParamInlist) {
                IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
            }
            setParameterHistoryDataSelected(newRow, true);
        }
    } else if (currentRow == 0 && sui->scbHistoryTable->getValue() != 0) {
        int visibleRowsBefore = numberOfRowsVisible(sui->tawParametersHistory);
        sui->scbHistoryTable->setValue(sui->scbHistoryTable->getValue() - 1);
        int visibleRowsAfter = numberOfRowsVisible(sui->tawParametersHistory);
        if (visibleRowsAfter > visibleRowsBefore) {
            bool isSelected = false;
            bool isParamInlist = false;
            getParameterHistoryDataInformation(currentRow + 1, isSelected, isParamInlist);

            if (isSelected) {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow + 2, 0);
                getParameterHistoryDataInformation(currentRow + 2, isSelected, isParamInlist);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(currentRow + 2, false);
            } else {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow + 1, 0);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(currentRow + 1, true);
            }
            m_currentRow = m_currentRow + 2;
        } else if (visibleRowsAfter == visibleRowsBefore) {
            bool isSelected = false;
            bool isParamInlist = false;
            getParameterHistoryDataInformation(currentRow, isSelected, isParamInlist);
            if (isSelected) {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow + 1, 0);
                getParameterHistoryDataInformation(currentRow + 1, isSelected, isParamInlist);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(currentRow + 1, false);
            } else {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow, 0);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(currentRow, true);
            }
        }
    }
    m_previousScrollBarPosition = sui->scbHistoryTable->getValue();
    m_currentScrollBarPosition = sui->scbHistoryTable->getValue();
}

void IGSxGUI::HistorypopupView::selectDownRow()
{
    // after selecting some rows using shift + down, when user scroll down/up and does shift + down, then the selection should continue from last position
    if (m_currentRow != -1 && m_currentScrollBarPosition != m_previousScrollBarPosition) {
        sui->scbHistoryTable->setValue(m_previousScrollBarPosition);
    }

    int currentRow = m_currentRow;
    int newRow = currentRow + 1;
    int visibleRows = numberOfRowsVisible(sui->tawParametersHistory);
    if (currentRow != -1) {
        if (currentRow < visibleRows - 1) {
            bool isSelected = false;
            bool isParamInlist = false;
            getParameterHistoryDataInformation(newRow, isSelected, isParamInlist);

            if (isSelected) {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow, 0);
                getParameterHistoryDataInformation(currentRow, isSelected, isParamInlist);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(currentRow, false);
            } else {
                SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(newRow, 0);
                if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                } else {
                    IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                }
                setParameterHistoryDataSelected(newRow, true);
            }
        } else if ((currentRow == visibleRows - 1) && sui->scbHistoryTable->isVisible() && sui->scbHistoryTable->getValue() != sui->scbHistoryTable->getMaxValue()) {
            int visibleRowsBefore = numberOfRowsVisible(sui->tawParametersHistory);
            sui->scbHistoryTable->setValue(sui->scbHistoryTable->getValue() + 1);
            int visibleRowsAfter = numberOfRowsVisible(sui->tawParametersHistory);
            if (visibleRowsAfter > visibleRowsBefore) {
                bool isSelected = false;
                bool isParamInlist = false;
                getParameterHistoryDataInformation(currentRow + 1, isSelected, isParamInlist);
                if (isSelected) {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow, 0);
                    getParameterHistoryDataInformation(currentRow, isSelected, isParamInlist);
                    if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow, false);
                } else {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow + 1, 0);
                    if (isParamInlist) {
                    IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow + 1, true);
                }
             } else if (visibleRowsAfter == visibleRowsBefore){
                bool isSelected = false;
                bool isParamInlist = false;
                getParameterHistoryDataInformation(currentRow, isSelected, isParamInlist);
                if (isSelected) {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow - 1, 0);
                    getParameterHistoryDataInformation(currentRow - 1, isSelected, isParamInlist);
                    if (isParamInlist) {
                        IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow -1, false);
                } else {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow, 0);
                    if (isParamInlist) {
                        IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow, true);
                }
            } else if (visibleRowsAfter < visibleRowsBefore){
                bool isSelected = false;
                bool isParamInlist = false;
                getParameterHistoryDataInformation(currentRow - 1, isSelected, isParamInlist);
                if (isSelected) {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow - 1, 0);
                    if (isParamInlist) {
                        IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow - 1, false);
                } else {
                    SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(currentRow - 1, 0);
                    if (isParamInlist) {
                        IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
                    } else {
                        IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
                    }
                    setParameterHistoryDataSelected(currentRow - 1, true);
                }
            }
        }
    }
    m_previousScrollBarPosition = sui->scbHistoryTable->getValue();
    m_currentScrollBarPosition = sui->scbHistoryTable->getValue();
}

int IGSxGUI::HistorypopupView::getVisibleRowsCount()
{
    return numberOfRowsVisible(sui->tawParametersHistory);
}

void IGSxGUI::HistorypopupView::showToolTipForColumn(int row, int columnIndex)
{
    sui->tawParametersHistory->setToolTip("");
    if (row != -1) {
        SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
        std::string paramName = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
        std::string oldvalue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
        std::string newvalue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
        std::string timeStr =  IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
        std::string changedby = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
        std::string reason = IGSxGUI::Util::getTextFromParameterUserControl(widget, 5);
        std::vector<IGSxGUI::ParameterHistory>::iterator it = m_historyData.end();
        it = getHistoryRowData(paramName, oldvalue, \
                newvalue, changedby, timeStr);
        if ( it != m_historyData.end()) {
            std::string actualText = STRING_EMPTY;
            std::string tableText = STRING_EMPTY;
            switch (columnIndex) {
            case 1:
                actualText = it->old_value();
                tableText = oldvalue;
                break;
            case 2:
                actualText = it->new_value();
                tableText = newvalue;
                break;
            case 4:
                actualText = it->changed_by();
                tableText = changedby;
                break;
            case 5:
                actualText = it->reason();
                tableText =  reason;
                break;
            default :
                break;
            }
            std::string formattedText = STRING_EMPTY;
            if (tableText.compare(actualText) != 0) {
               std::string  tempFormattedText =  formatToolTipText(actualText, TOOLTIP_WIDTH);
               formattedText = boost::erase_last_copy(tempFormattedText, STRING_NEWLINE);
                if (((columnIndex == 1) || (columnIndex == 2)) && (formattedText.size() > 100)) {
                    splitToMultilineToolTip(formattedText, 100);
                }
                sui->tawParametersHistory->setToolTip(formattedText);
            }
        }
    }
}

void IGSxGUI::HistorypopupView::setCurrentRow(int currentRow)
{
    m_currentRow = currentRow;
}

void IGSxGUI::HistorypopupView::setShiftKeyPressed(bool isShiftKeyPressed)
{
    m_shiftKeyPressed = isShiftKeyPressed;
}

int IGSxGUI::HistorypopupView::getCurrentRow()
{
    return m_currentRow;
}
void IGSxGUI::HistorypopupView::splitToMultilineToolTip(std::string& value, size_t charCount)
{
    std::string retname = "";
    std::string tempstr = value;
    while (tempstr.size() > charCount) {
        size_t pos = tempstr.rfind(',', charCount);
        retname = retname + "\n" + tempstr.substr(0, pos+1);
        tempstr = tempstr.substr(pos+1, tempstr.size());
    }
    retname.erase(0, 1);
    value = retname + "\n" + tempstr;
}
void IGSxGUI::HistorypopupView::setCtrlKeyPressed(bool isCtrlKeyPressed)
{
    m_isCtrlKeyPressed = isCtrlKeyPressed;
}

std::string IGSxGUI::HistorypopupView::getParameterHistoryData()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        return getParameterHistoryStr(m_historyData);
    } else {
        return getParameterHistoryStr(m_matchedparameters);
    }
}

std::string IGSxGUI::HistorypopupView::getParameterHistoryStr(IGSxGUI::ParameterHistoryVector& t_historyData)
{
    std::string text = "";
    for (size_t i = 0; i < t_historyData.size(); ++i) {
        if (t_historyData[i].isSelected()) {
            std::string paramName = t_historyData[i].parameter_name();
            text += "\""+ paramName + "\",";
            std::string oldValue = t_historyData[i].old_value();
            text += "\""+ oldValue + "\",";
            std::string newValue = t_historyData[i].new_value();
            text += "\""+ newValue + "\",";

            std::string changedTime = IGSxGUI::SystemDateTime::formatDateTime(IGSxGUI::SystemDateTime::STR_DATE_TIME_SEC, t_historyData[i].time_of_change());
            text += "\""+ changedTime + "\",";

            std::string changedBy = t_historyData[i].changed_by();
            replaceText(changedBy, std::string("\""), std::string("\"\""));
            text += "\""+ changedBy + "\",";

            std::string reason = t_historyData[i].reason();
            replaceText(reason, std::string("\""), std::string("\"\""));
            text += "\""+ reason + "\"";
            text += "\n";
        }
    }
    return text;
}

void IGSxGUI::HistorypopupView::replaceText(std::string &str, std::string from, std::string to)
{
    for (std::size_t index = 0; (index = str.find(from, index))!= std::string::npos; index = index + 2) {
        str.replace(index, from.length(), to);
    }
}

void IGSxGUI::HistorypopupView::onParameterNameHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ParameterName;
    m_paramNameOrder = (m_paramNameOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_paramNameOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_paramNameOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_paramNameOrder);
    }
}

void IGSxGUI::HistorypopupView::onChangedOnHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedOn;
    m_changedOnOrder= (m_changedOnOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_changedOnOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_changedOnOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_changedOnOrder);
    }
}

void IGSxGUI::HistorypopupView::onChangedByHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::ChangedBy;
    m_changedByOrder= (m_changedByOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_changedByOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_changedByOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_changedByOrder);
    }
}

void IGSxGUI::HistorypopupView::onReasonHeaderClicked()
{
    m_currentSortedColumn = IGSxGUI::SortedByColumn::Reason;
    m_reasonOrder= (m_reasonOrder == SortOrder::Descending) ? SortOrder::Ascending : SortOrder::Descending;
    m_currentOrder = m_reasonOrder;
    if (sui->lneSearchParameterText->getText().empty()) {
        arrangeTableData(m_historyData, m_currentSortedColumn, m_reasonOrder);
    } else {
        arrangeTableData(m_matchedparameters, m_currentSortedColumn, m_reasonOrder);
    }
}
void IGSxGUI::HistorypopupView::formatParamNameBack(std::string& name)
{
    boost::replace_all(name, "\n","");
}
std::vector<IGSxGUI::ParameterHistory>::iterator IGSxGUI::HistorypopupView::getHistoryRowData(std::string& paramName, std::string& oldvalue,  std::string& newvalue,  std::string& changedby, \
        std::string& timeStr)
{

    IGSxGUI::Util::replaceAmpersand(changedby, true);
    formatParamNameBack(paramName);
    std::vector<IGSxGUI::ParameterHistory>::iterator it = std::find_if(m_historyData.begin(), m_historyData.end(), \
            find_historyData(paramName, oldvalue, newvalue, changedby, timeStr));
    return it;
}

void IGSxGUI::HistorypopupView::onParameterHistoryHoverEntered(int row)
{
        SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
        bool selected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(row, selected, isParamInlist);

        if (isParamInlist)
        {
            if (selected) {
                IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryHoverEnteredStyle(widget);
            }
        }
        else
        {
            //Grayed style - same as parameter list
            if (selected) {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(widget);
            }
        }
}

void IGSxGUI::HistorypopupView::onParameterHistoryHovLeft(int row)
{
        SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
        bool selected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(row, selected, isParamInlist);

        if (isParamInlist)
        {
            if (selected) {
                IGSxGUI::Util::setParameterHistoryClickedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryNormalStyle(widget);
            }
        }
        else
        {
            //Grayed style - same as parameter list
            if (selected) {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(widget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(widget);
            }
        }
}

void IGSxGUI::HistorypopupView::onParameterHistoryClicked(int row)
{
    if (m_shiftKeyPressed == true) {
        if (m_currentRow != -1) {
            selectShiftClickedRows(row);
            m_currentRow = row;
            m_currentScrollBarPosition = sui->scbHistoryTable->getValue();
            m_previousScrollBarPosition = m_currentScrollBarPosition;
        }
    } else if (m_isCtrlKeyPressed == true) {
        SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(row, 0);
        bool rowSelected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(row, rowSelected, isParamInlist);

        if (rowSelected == true) {
            if (isParamInlist){
                IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
            }
            setParameterHistoryDataSelected(row, false);
            m_currentRow = -1;
        } else {
            if (isParamInlist){
                IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
            }
            setParameterHistoryDataSelected(row, true);
            m_currentRow = row;
            m_currentRowIter = getParameterHistorySelectionForRow(m_currentRow);
            resetCurrentRowIfGapInSelection(row);
        }
    } else {
        resetSelection();
        m_previousScrollBarPosition = sui->scbHistoryTable->getValue();
        m_currentScrollBarPosition = sui->scbHistoryTable->getValue();
        m_currentRow = -1;
        if (m_histroyRowPressedCallback != NULL) {
            bool isSelected = false;
            bool isParamInlist = false;
            getParameterHistoryDataInformation(row, isSelected, isParamInlist);
            if (isParamInlist) {
                SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
                std::string paramName  = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
                formatParamNameBack(paramName);
                IGSxGUI::Util::createModalWindow(m_dialogModality, sui->lneSearchParameterText);
                m_histroyRowPressedCallback(paramName);
                IGSxGUI::Util::closeModalWindow(m_dialogModality);
            }
        }
    }
}

std::vector<IGSxGUI::ParameterHistory>::iterator IGSxGUI::HistorypopupView::getParameterHistorySelectionForRow(int row)
{
    SUI::Widget *widget = sui->tawParametersHistory->getWidgetItem(row, 0);
    std::string paramName  = IGSxGUI::Util::getTextFromParameterUserControl(widget, 0);
    std::string oldValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 1);
    std::string newValue = IGSxGUI::Util::getTextFromParameterUserControl(widget, 2);
    std::string timeOfChangeStr = IGSxGUI::Util::getTextFromParameterUserControl(widget, 3);
    std::string changedBy = IGSxGUI::Util::getTextFromParameterUserControl(widget, 4);
    formatParamNameBack(paramName);

    std::vector<IGSxGUI::ParameterHistory>::iterator it;
    if (sui->lneSearchParameterText->getText().empty()) {
        it = std::find_if(m_historyData.begin(), \
                          m_historyData.end(), \
                          find_historyData(paramName, oldValue, newValue, changedBy, timeOfChangeStr));
    } else {
        it = std::find_if(m_matchedparameters.begin(), \
                          m_matchedparameters.end(), \
                          find_historyData(paramName, oldValue, newValue, changedBy, timeOfChangeStr));
    }
    return it;
}
void IGSxGUI::HistorypopupView::getParameterHistoryDataInformation(int row, bool& bSelect, bool& bParamInList)
{
    bSelect = false;
    bParamInList = false;
    if (row < static_cast<int>(m_TableRows.size())){
        RowParameterHistoryType& history = m_TableRows[row];
        bSelect =   (*history.second).isSelected();
        bParamInList =   (*history.second).isParamterInList();
    }
}

void IGSxGUI::HistorypopupView::setParameterHistoryDataSelected(int row, bool state)
{
    m_previousSelectionList[row] = state;
    if (row < static_cast<int>(m_TableRows.size())){
        RowParameterHistoryType& history = m_TableRows[row];
        history.first = state;
        (*history.second).setState(state);
    }
}

void IGSxGUI::HistorypopupView::setParent(SUI::Widget *parent)
{
    IGSxGUI::Util::setParent(sui->dialog, parent);
}
void IGSxGUI::HistorypopupView::adjustTableRowVisibility(SUI::TableWidget *tablewidget, int numberOfRows)
{
    if (tablewidget != NULL) {
        int rowCount = tablewidget->rowCount();
        for (int i = 0; i < rowCount; ++i) {
            tablewidget->setRowVisible(i, false);
        }
        if (numberOfRows <= rowCount) {
            for (int i = 0; i < numberOfRows; ++i) {
                tablewidget->setRowVisible(i, true);
            }
        }
    }
}
int IGSxGUI::HistorypopupView::numberOfRowsVisible(SUI::TableWidget *tablewidget)
{
    int  count = 0;
    if (tablewidget != NULL) {
        int rowCount = tablewidget->rowCount();
        for (int i = 0; i < rowCount; ++i) {
            if (tablewidget->isRowVisible(i)) {
                ++count;
            }
        }
    }
    return count;
}

std::string IGSxGUI::HistorypopupView::formatToolTipText(const std::string& inStr, int width)
{
    std::string formattedText = inStr;
    if (width > 0) {
        std::vector<std::string> tokens;
        boost::split(tokens, inStr, boost::algorithm::is_any_of(STRING_NEWLINE));
        size_t totalTokens = tokens.size();
        std::string resultString = STRING_EMPTY;
        std::string currentLine = tokens[0];
        for (size_t index = 0; index < totalTokens; ++index) {
            currentLine = tokens[index];
            if (currentLine == "") {
                resultString += STRING_NEWLINE;
            } else {
                int tempLength = static_cast<int>(currentLine.length());
                if (tempLength > width) {
                    // the line would be too long, so finish it and start a new line with this word
                    resultString += formatToolTipTextUtil(tokens[index], width) + STRING_NEWLINE;
                } else {
                    resultString += tokens[index] + STRING_NEWLINE;
                }
            }
        }
        formattedText = resultString;
    }
    IGSxGUI::Util::replaceAmpersand(formattedText, false);
    return formattedText;
}

std::string IGSxGUI::HistorypopupView::formatToolTipTextUtil(const std::string& inStr, int width)
{
    std::string formattedText = inStr;
    if (width > 0) {
        std::vector<std::string> tokens;
        boost::split(tokens, inStr, boost::algorithm::is_space());
        size_t totalTokens = tokens.size();
        std::string resultString = STRING_EMPTY;
        std::string currentLine = tokens[0];
        for (size_t index = 1; index < totalTokens; ++index) {
            int tempLength = static_cast<int>(currentLine.length() + 1 + tokens[index].length());
            if (tempLength > width) {
                // the line would be too long, so finish it and start a new line with this word
                resultString += currentLine + STRING_NEWLINE;
                currentLine = tokens[index];
            } else {
                currentLine += " " + tokens[index];
            }
        }
        formattedText = resultString + currentLine;
    }
    return formattedText;
}

std::pair <std::string, int> IGSxGUI::HistorypopupView::getFormattedsParamNameAndCalculateLineCount(const std::string& name)
{
    SUI::Widget* widget = sui->tawParametersHistory->getWidgetItem(0, 0);
    // columnWidth set according to width of the column and the styles applied on column
    int columnWidth = 585;
    return formatNameAndCalculateLineCount(name, widget, columnWidth);
}
std::pair <std::string, int> IGSxGUI::HistorypopupView::formatNameAndCalculateLineCount(const std::string& name, SUI::Widget* widget, int width)
{
    size_t search_pos = getSplitPosition(name, widget, width);
    static std::string retname = "";
    static int num_of_rows = 1;
    std::string tmpname = name;
    if (search_pos == 0) {
        std::string ret = retname + '\n' + tmpname;
        if (retname == "") {
            ret = tmpname;
            num_of_rows = 1;
        }
        int rows = num_of_rows;
        retname = "";
        num_of_rows = 1;
        return std::make_pair(ret, rows);
    }
    std::size_t found = tmpname.rfind('/', search_pos);
    if (found == std::string::npos) {
        std::size_t found = tmpname.find_first_of('(');
        // found <= 3 is to avoid indefinite looping that may occur when we find the same character '(' repeatedly which is moved to tmpname
        // found > search_pos is found after search position which is consdered as not found
        if (found == std::string::npos || found > search_pos || found <= 3 ) {
            std::size_t found = tmpname.rfind('_', search_pos);
            if (found == std::string::npos) {
                int position = getPositionOfLastUpperCaseCharacter(tmpname, search_pos);
                // <= 3 is to avoid indefinite looping that may occur when we find the same UPPERCASE character repeatedly which is moved to tmpname
                if (position <= 3) {
                    extractSubStr(search_pos, num_of_rows, retname, tmpname);
                } else {
                    extractSubStr(position, num_of_rows, retname, tmpname);
                }
            } else {
                extractSubStr(found+1, num_of_rows, retname, tmpname);
            }
        } else {
            extractSubStr(found, num_of_rows, retname, tmpname);
        }
    } else {
        // we do not want the units of type "(x/y)" gets split at '/'
        // split at first '(' for units which have more than one '('
        std::size_t found2 = tmpname.find_first_of('(');
        if (found2 != std::string::npos && found2 < found) {
            found = found2;
            extractSubStr(found, num_of_rows, retname, tmpname);
        } else {
            extractSubStr(found+1, num_of_rows, retname, tmpname);
        }
    }
    return formatNameAndCalculateLineCount(tmpname, widget, width);
}

size_t IGSxGUI::HistorypopupView::getSplitPosition(const std::string& name, SUI::Widget* widget, int width)
{
    int total_chars_width = 0;
    for (size_t i = 0; i < name.size(); ++i) {
        std::string str(1, name[i]);
        total_chars_width = total_chars_width + IGSxGUI::Util::getCharWidthOfLableInTableColumn(str, widget, 0);
        if (total_chars_width > width) {
            return i-1;
        }
    }
    return 0;
}

int IGSxGUI::HistorypopupView::getPositionOfLastUpperCaseCharacter(const std::string& name, int fromPos)
{
    int i = fromPos;
    for (; i > 0; --i) {
        if ((::isupper(name[i]) != 0) && (::isupper(name[i - 1]) == 0)) {
            return i;
        }
    }
    return i;
}

void IGSxGUI::HistorypopupView::resetCurrentRowIfGapInSelection(int row)
{
    // current row is set only if the row is either first or last of the selected block
    // if there are multiple selected block, then current selected row is set to -1, which means shift up/down/click will not work
    if (gapInSelection(row) == true) {
        m_currentRow = -1;
    }
}

bool IGSxGUI::HistorypopupView::gapInSelection(int row)
{
    bool gapInSelection = false;
    std::vector<IGSxGUI::ParameterHistory>::iterator iterator_start;
    std::vector<IGSxGUI::ParameterHistory>::iterator iterator_end;

    if (sui->lneSearchParameterText->getText().empty()) {
        iterator_start = m_historyData.begin();
        iterator_end = m_historyData.end();
    } else {
        iterator_start = m_matchedparameters.begin();
        iterator_end = m_matchedparameters.end();
    }

    std::vector<IGSxGUI::ParameterHistory>::iterator cur = getParameterHistorySelectionForRow(row);
    std::vector<IGSxGUI::ParameterHistory>::iterator prev = cur - 1;
    std::vector<IGSxGUI::ParameterHistory>::iterator nxt = cur + 1;

    // check to see if the gap between the two selection is filled by selecting the row,
    // which is considered as gap in selection
    if (cur != iterator_start && cur != (iterator_end - 1) && prev->isSelected() && nxt->isSelected()) {
        gapInSelection = true;
        return gapInSelection;
    }

    bool start = false;
    bool stop = false;
    for (; iterator_start != iterator_end; ++iterator_start) {
        if (iterator_start->isSelected()) {
            if (stop) {
                gapInSelection = true;
                break;
            }
            start = true;
        } else {
            if (start) {
                stop = true;
            }
        }
    }
    return gapInSelection;
}

void IGSxGUI::HistorypopupView::selectShiftClickedRows(int row)
{
    std::vector<IGSxGUI::ParameterHistory>::iterator firstParamNameToSelectIt = m_currentRowIter;
    std::vector<IGSxGUI::ParameterHistory>::iterator lastParamNameToSelectIt = getParameterHistorySelectionForRow(row);

    int distance = static_cast<int>(std::distance(firstParamNameToSelectIt, lastParamNameToSelectIt));
    if (distance == 0) {
        return;
    }

    if (sui->lneSearchParameterText->getText().empty()) {
        for (size_t i = 0; i < m_historyData.size(); ++i) {
            m_historyData[i].setState(false);
        }
    } else {
        for (size_t i = 0; i < m_matchedparameters.size(); ++i) {
            m_matchedparameters[i].setState(false);
        }
    }

    if (distance > 0) {
        for (int i = 0; i <= distance; ++i, ++firstParamNameToSelectIt) {
            firstParamNameToSelectIt->setState(true);
        }
    } else {
        for (int i = distance; i <= 0; ++i, ++lastParamNameToSelectIt) {
            lastParamNameToSelectIt->setState(true);
        }
    }

    // after marking the rows as selected or unselected, refresh the visible rows to reflect the style
    // other row's style will be reflected as user scrolls
    refreshTableVisibleRowsForStyleUpdate();
}

void IGSxGUI::HistorypopupView::refreshTableVisibleRowsForStyleUpdate()
{
    if(sui->tawParametersHistory->isVisible())
    {
    for (int i = 0; i < static_cast<int>(m_TableRows.size()); ++i) {
        SUI::Widget *selectedWidget = sui->tawParametersHistory->getWidgetItem(i, 0);
        bool selected = false;
        bool isParamInlist = false;
        getParameterHistoryDataInformation(i, selected, isParamInlist);


        if (isParamInlist)
        {
            if (selected == true) {
                IGSxGUI::Util::setParameterHistoryClickedStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryNormalStyle(selectedWidget);
            }
        }
        else
        {
            //Grayed style - same as parameter list
            if (selected) {
                IGSxGUI::Util::setParameterHistoryReadOnlySelectedStyle(selectedWidget);
            } else {
                IGSxGUI::Util::setParameterHistoryReadOnlyStyle(selectedWidget);
            }
        }
    }
    }
}

void IGSxGUI::HistorypopupView::resetSelection()
{
    if (sui->lneSearchParameterText->getText().empty()) {
        for (size_t i = 0; i < m_historyData.size(); ++i) {
            m_historyData[i].setState(false);
        }
    } else {
        for (size_t i = 0; i < m_matchedparameters.size(); ++i) {
            m_matchedparameters[i].setState(false);
        }
    }
    refreshTableVisibleRowsForStyleUpdate();
}

void IGSxGUI::HistorypopupView::invalidateCurrentRow()
{
    m_currentRow = -1;
}

void IGSxGUI::HistorypopupView::registerToHistoryRowPressed(IGSxGUI::HistroyRowPressedCallback cb)
{
    IGSxGUI::HistorypopupView::m_histroyRowPressedCallback = cb;
}
