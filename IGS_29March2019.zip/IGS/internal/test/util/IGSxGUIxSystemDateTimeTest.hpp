/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemDateTimeTest.hpp
| Author       : Raja A
| Description  : Header file for System DateTime test
|
| ! \file        IGSxGUIxSystemDateTimeTest.hpp
| ! \brief       Header file for System DateTime test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMDATETIMETEST_HPP
#define IGSXGUIXSYSTEMDATETIMETEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class SystemDateTimeTest : public ::testing::Test
{
 public:
    SystemDateTimeTest(){}
    virtual ~SystemDateTimeTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIXSYSTEMDATETIMETEST_HPP
