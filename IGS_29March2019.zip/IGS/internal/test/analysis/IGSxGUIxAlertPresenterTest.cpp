/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertPresenterTest.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert Presenter test
|
| ! \file        IGSxGUIxAlertPresenterTest.cpp
| ! \brief       Implementation of Alert Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxAlertPresenterTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(AlertPresenterTest, Test1)
{
    AlertViewStub* stubView = new AlertViewStub();
    ASSERT_TRUE(stubView != NULL);

    IGSxGUI::AlertManager* alertMgr = new IGSxGUI::AlertManager();
    ASSERT_TRUE(alertMgr != NULL);

    IGSxGUI::AlertPresenter* presenter = new IGSxGUI::AlertPresenter(stubView, alertMgr);
    ASSERT_TRUE(presenter != NULL);

    std::vector<IGSxGUI::Alert*> AlertList = presenter->getActiveAlerts();
    EXPECT_EQ(0, AlertList.size());

    IGSxGUI::Alert* alert = presenter->getAlert(12);
    EXPECT_EQ(NULL, alert);

    delete presenter;
    presenter = NULL;

    delete alertMgr;
    alertMgr = NULL;

    delete stubView;
    stubView = NULL;

    // COULD NOT COVER OTHER CASES AS THEY ARE EVENT BASED AND STUB TO BE STUBBED - BASED IN ALERT MANAGER
}
