/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.cpp
| Author       : Saket k
| Description  : Stub impementation of IGSxSSM interface
|
| ! \file        IGSxSSM_impl.cpp
| ! \brief       Stub impementation of IGSxSSM interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxSSM.hpp"
#include "IGSxSSM_impl.hpp"
#include <boost/bind.hpp>
#include "IGSxERR_impl.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

using namespace IGSxSSM;

const int TIMER_INTERVAL = 15000;
const int NO_STATE = -1;
const int INITIAL_STATE = 10;
const int ERROR_STATE = 15;
const std::string LOGCODE_PREFIX = "ABC-0";

IGSxSSM::SystemFunction::SystemFunction(const SystemFunctionConfigType &config , const ReachableStatesMapType& reachableStatesMap): SystemFunctionType(config),
    m_previousState(INITIAL_STATE),
    m_currentState(INITIAL_STATE),
    m_timer(SUI::Timer::createTimer()),
    m_reachableStatesMap(reachableStatesMap),
    m_errorTimer(SUI::Timer::createTimer()),
    m_transitionResult(0),
    m_isTransitionAborted(false)
{
    m_timer->timeout = boost::bind(&SystemFunction::onTransitionCompleted, this);
    m_errorTimer->timeout = boost::bind(&SystemFunction::onTransitionErrorResume, this);

}

void IGSxSSM::SystemFunction::set_state(const IGSxSSM::StateIDType &target)
{
    if(NO_STATE == m_previousState)
        m_previousState = m_currentState = target;

    if(m_previousState == target ) //Transition is aborted
    {
        m_isTransitionAborted = true;
        IGSxSSM::StateIDType oldState = m_currentState;
        m_previousState = m_currentState;
        m_currentState = target;
        onTransitionAborted();

        m_currentState = target;
        m_previousState = oldState;
        cb_transitionStarted(StateIDType(m_previousState), StateIDType(m_currentState), TIMER_INTERVAL/1000);
        m_timer->start(TIMER_INTERVAL);
    }
    else
    {
        m_previousState = m_currentState;
        m_currentState = target;
        cb_transitionStarted(StateIDType(m_previousState), StateIDType(m_currentState), TIMER_INTERVAL/1000);
        m_timer->start(TIMER_INTERVAL);
    }
 }

void IGSxSSM::SystemFunction::get_state() const
{
    if(!cb_getStateResult.empty())
    {
        ReachableStateList reachableStateList;
        ReachableStatesMapType::const_iterator it = m_reachableStatesMap.find(StateIDType((m_isTransitionAborted) ? m_previousState: m_currentState));
        if(it != m_reachableStatesMap.end() )
        {
            reachableStateList = it->second;
        }

        if (m_currentState == ERROR_STATE)
        {
            cb_getStateResult(FunctionResultType(FUNCTION_ERROR), StateIDType(m_previousState), StateIDType(m_currentState), reachableStateList);
            m_errorTimer->start(TIMER_INTERVAL *2); // After 10 seconds reset the system state to the initial state.

            std::string logCode = LOGCODE_PREFIX ;
            std::string userText("Error state ");
            static_cast<IGSxERR::Alert_Stub*>(IGSxERR::Alert_Stub::getInstance())->raiseAlert(logCode, userText, IGSxERR::AlertSeverity::ERROR);
        }
        else
        {
            cb_getStateResult(FunctionResultType(FUNCTION_OK), StateIDType(m_previousState), StateIDType(m_currentState), reachableStateList);
        }
    }
}

void IGSxSSM::SystemFunction::subscribeTransitionStarted(IGSxSSM::TransitionStartedCallback cb)
{
    cb_transitionStarted = cb;
}

void IGSxSSM::SystemFunction::unsubscribeTransitionStarted()
{
    if (cb_transitionStarted)
    {
        cb_transitionStarted = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeTransitionCompleted()
{
    if (cb_transitionCompleted)
    {
        cb_transitionCompleted = NULL;
    }
}

void IGSxSSM::SystemFunction::subscribeStateUpdated(IGSxSSM::StateUpdatedCallback cb)
{
    cb_stateUpdated = cb;
}

void IGSxSSM::SystemFunction::subscribeSetStateResult(IGSxSSM::SetStateResultCallback cb)
{
    cb_setStateResult = cb;
}

void IGSxSSM::SystemFunction::subscribeGetStateResult(IGSxSSM::GetStateResultCallback cb)
{
    cb_getStateResult = cb;
}

void IGSxSSM::SystemFunction::unsubscribeGetStateResult()
{
    if (cb_getStateResult)
    {
        cb_getStateResult = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeSetStateResult()
{
    if (cb_setStateResult)
    {
        cb_setStateResult = NULL;
    }
}

void IGSxSSM::SystemFunction::unsubscribeStateUpdated()
{
    if (cb_stateUpdated)
    {
        cb_stateUpdated = NULL;
    }
}

void IGSxSSM::SystemFunction::subscribeTransitionCompleted(IGSxSSM::TransitionCompletedCallback cb)
{
    cb_transitionCompleted = cb;
}


void SystemFunction::onTransitionCompleted()
{
    m_timer->stop();

    m_previousState = m_currentState;
    // transition completed.
    cb_setStateResult(FUNCTION_OK);

    ReachableStateList reachableStateList;
    ReachableStatesMapType::iterator it = m_reachableStatesMap.find(StateIDType(m_currentState));
    if(it != m_reachableStatesMap.end() ) reachableStateList = it->second;

    m_isTransitionAborted = false;

    if (m_currentState == ERROR_STATE)
    {
        cb_transitionCompleted(StateIDType(m_previousState), StateIDType(m_currentState), TransitionResultType(TRANSITION_ERROR), reachableStateList);
    }
    else
    {
        cb_transitionCompleted(StateIDType(m_previousState), StateIDType(m_currentState), TransitionResultType(TRANSITION_OK), reachableStateList);
    }
 }

void SystemFunction::onTransitionAborted()
{
    m_timer->stop();

    // transition completed.
    cb_setStateResult(FUNCTION_OK);

    ReachableStateList reachableStateList;
    ReachableStatesMapType::iterator it = m_reachableStatesMap.find(StateIDType(m_previousState));
    if(it != m_reachableStatesMap.end() ) reachableStateList = it->second;

    cb_transitionCompleted(StateIDType(m_previousState), StateIDType(m_currentState), TransitionResultType(TRANSITION_ABORTED), reachableStateList);
}

void SystemFunction::onTransitionErrorResume()
{
    m_errorTimer->stop();

    m_currentState = INITIAL_STATE;
    m_previousState = INITIAL_STATE;
    ReachableStateList reachableStateList;
    ReachableStatesMapType::const_iterator it = m_reachableStatesMap.find(StateIDType((m_isTransitionAborted) ? m_previousState: m_currentState));
    if(it != m_reachableStatesMap.end() )
    {
        reachableStateList = it->second;
    }
    cb_transitionCompleted(StateIDType(m_previousState), StateIDType(m_currentState), TransitionResultType(TRANSITION_OK), reachableStateList);
}

