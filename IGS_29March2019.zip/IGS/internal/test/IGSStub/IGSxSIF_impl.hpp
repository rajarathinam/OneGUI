/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSIF_impl.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxSIF stub
|
| ! \file        IGSxSIF_impl.hpp
| ! \brief       Header file for IGSxSIF stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXSIF_IMPL_HPP
#define IGSXSIF_IMPL_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxSIF.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Timer;
}

namespace IGSxSIF {

class SIF_Stub :public SIF
{
 public:
    static SIF* getInstance();

    virtual bool isMbdsViewerAvailable();
    virtual bool startMbdsViewer();

 protected:
    SIF_Stub();
    virtual ~SIF_Stub() {}
 private:
    int m_counter;
};
}  // namespace IGSxSIF
#endif  // IGSXSIF_IMPL_HPP
