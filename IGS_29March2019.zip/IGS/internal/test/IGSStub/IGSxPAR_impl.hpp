/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR_impl.hpp
| Author       : Jan-Pieter
| Description  : Header file for IGSxPAR stub
|
| ! \file        IGSxPAR_impl.hpp
| ! \brief       Header file for IGSxPAR stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXPAR_IMPL_HPP
#define IGSXPAR_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxPAR.hpp"
#include <FWQxUtils/SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxPAR {

class PAR_Stub : public PAR
{
public:
    static PAR* getInstance();

    PAR_Stub();
    virtual ~PAR_Stub();

    // meta data
    //functions
    virtual void read( const std::string& filter, ParameterTypePtrVector& parameters );
    //virtual void Write(const TransactionInfo&, const IValuePtrVector&, StringVectorType& failed_parameters);
    virtual void write( const TransactionInfo& transactionInfo, const IValuePtrVector& values);
    virtual void getChangeHistory(time_t, time_t, ParameterChangeHistoryVector&);

    // data update
    virtual void subscribeValuesChanged(ValuesChangedCallback);
    virtual void unsubscribeValuesChanged();

    //! \brief   Subscribe to an event that is sent if the write() method has finished
    //! \details The write() method is asynchronous. This is used to inform clients that
    //!          the write() method has been handled by FCBxPAR
    //! \return  Nothing
    //! \note    Throws an exception if subscribing fails
    virtual void subscribeWriteFinished(WriteFinishedCallback cb);
    virtual void unsubscribeWriteFinished();

    void onUpdateEventTimeOut();
    void onWriteEventTimeOut();

    boost::shared_ptr<SUI::Timer> m_UpdateEventTimer;
    boost::shared_ptr<SUI::Timer> m_WriteEventTimer;
    StringVectorType failed_parameters;
};
}  // namespace IGSxPAR
#endif  // IGSXPAR_IMPL_HPP
