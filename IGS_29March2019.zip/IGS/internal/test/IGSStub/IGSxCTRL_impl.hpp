/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCTRL_impl.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for IGSxCTRL stub
|
| ! \file        IGSxCTRL_impl.hpp
| ! \brief       Header file for IGSxCTRL stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCTRL_IMPL_HPP
#define IGSXCTRL_IMPL_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxCTRL.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxCTRL {

class CTRL_Stub :public Control
{
 public:
    static Control* getInstance();

    bool requestControl();
    void releaseControl();
    bool canIGetControl();
    Who::WhoEnum whoIsInControl();

    virtual void revokeScanner();

    // control changed event
    void subscribeToControlChanged(const ControlChangedCallback& cb);
    void unsubscribeToControlChanged();

    // stub manipulation functions
    void setWhoIsInControl(Who::WhoEnum who);

 private:
    CTRL_Stub();
    virtual ~CTRL_Stub() {}

    Who::WhoEnum m_who;
    ControlChangedCallback m_controlChangedCB;

};
}  // namespace IGSxCTRL
#endif  // IGSXCTRL_IMPL_HPP
