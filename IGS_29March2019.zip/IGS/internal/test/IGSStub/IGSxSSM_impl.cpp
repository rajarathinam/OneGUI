/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxSSM_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxSSM interface
|
| ! \file        IGSxSSM_impl.cpp
| ! \brief       Stub impementation of IGSxSSM interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxSSM.hpp"
#include "IGSxSSM_impl.hpp"
#include <QXmlStreamReader>
#include <QFile>
#include <QStringList>
#include <QDebug>
#include <iostream>
#include <FWQxCore/SUIResourcePath.h>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/


IGSxSSM::SSMPtr IGSxSSM::SSM::instance = IGSxSSM::SSM_Stub::GetInstance();
const char* STRING_RESOURCE = "/Resource";
const char* DATA_FILE_NAME = "SSMViewExtended.xml";

IGSxSSM::SSM_Stub::SSM_Stub() : functionTypes()
{
    std::string currentDir(get_current_dir_name());
    SUI::ResourcePath::getInstance()->setResourcePath(currentDir + std::string(STRING_RESOURCE));
    initialize();
}

void IGSxSSM::SSM_Stub::initialize()
{
        std::string fileName = SUI::ResourcePath::getInstance()->getResourceFile(std::string(DATA_FILE_NAME));
        QFile* xmlFile = new QFile(QString::fromStdString(fileName));
        if (!xmlFile->open(QIODevice::ReadOnly | QIODevice::Text)) {
            qDebug() << "Load XML File Problem coudnt open xml file for SSM." << QString(DATA_FILE_NAME);
            return;
        }
        QXmlStreamReader reader(xmlFile);

        ReachableStatesMapType ReachableStatesMap;
        ReachableStatesMap.clear();

        int functionIndex = 0;
        while(reader.readNextStartElement())
        {
            if(reader.name() == "StateManagerTabs")
            {

                while(reader.readNextStartElement())
                {
                    if(reader.name() == "Function" && reader.attributes().hasAttribute("name"))
                    {

                        GroupConfigList groups;
                        QString functionName = reader.attributes().value("name").toString();

                        while(reader.readNextStartElement())
                        {
                            if(reader.name() == "Group" && reader.attributes().hasAttribute("name"))
                            {
                                QString groupName = reader.attributes().value("name").toString();
                                StateConfigList states;

                                while(reader.readNextStartElement())
                                {
                                    if(reader.name() == "State" && reader.attributes().hasAttribute("id"))
                                    {
                                        QString stateId = reader.attributes().value("id").toString();
                                        std::string stateName = reader.readElementText().toStdString();
                                        StateDescriptionType stateDescription = parseDescription(stateName);
                                        StateConfigType state(stateDescription, stateId.toInt());
                                        states.push_back(state);
                                    }
                                    else
                                    {
                                        reader.skipCurrentElement();
                                    }

                                }
                                groups.push_back(GroupConfigType(groupName.toStdString(), states));
                            }
                            else if(reader.name() == "Transition" && reader.attributes().hasAttribute("state") && reader.attributes().hasAttribute("abortable"))
                           {
                               QString state = reader.attributes().value("state").toString();
                               QString abortable = reader.attributes().value("abortable").toString();
                               int abortableValue = abortable.toInt();
                               QString reachable = reader.attributes().value("reachable").toString();

                               QStringList reachableStates = reachable.split(":");
                               std::vector<ReachableStateType> reachableStateVec;

                               for(int index=0; index< reachableStates.size(); ++index)
                               {
                                   reachableStateVec.push_back(ReachableStateType(reachableStates[index].toInt(), abortableValue));
                               }

                               StateIDType fromState = StateIDType(state.toInt());
                               ReachableStatesMap.insert(std::pair<StateIDType, std::vector<ReachableStateType> >(fromState, reachableStateVec));

                               reader.skipCurrentElement();
                           }
                            else
                            {
                                reader.skipCurrentElement();
                            }
                        }

                    SystemFunctionConfigType configTypeSystemState(std::string(functionName.toStdString()), groups);
                    SystemFunction* systemFunction = new SystemFunction(configTypeSystemState, ReachableStatesMap);
                    functionTypes[functionIndex++] = SystemFunctionPtr(systemFunction);
                    }
                }
            }
        }

    //close reader and flush file
    reader.clear();
    xmlFile->close();
}

IGSxSSM::StateDescriptionType IGSxSSM::SSM_Stub::parseDescription(std::string &text)
{
    std::string str = text;
    std::string delimiter = "\\";
    std::string token;
    StateDescriptionType desc;
    size_t pos = 0;
    int index = 0;
    while((pos = str.find(delimiter)) != std::string::npos)
    {
        token = str.substr(0, pos);
        desc[index] = token;
        str.erase(0, pos + delimiter.length());
        ++index;
    }

    if(index == 0 || !str.empty()) // Did not find the delimiter.
    {
        desc[index] = str;
    }
    return desc;
}

IGSxSSM::SystemFunctionPtrList IGSxSSM::SSM_Stub::functions()
{
    return functionTypes;
}

IGSxSSM::SSMPtr IGSxSSM::SSM_Stub::GetInstance()
{
    static IGSxSSM::SSMPtr  _instance;
    if (_instance.get() == NULL)
    {
        _instance.reset(new IGSxSSM::SSM_Stub());
    }
    return _instance;
}

bool IGSxSSM::SSM_Stub::showStateManagement()
{
    return true;
}


// CA_SYSTEM_CONTROL_ARBITER = 1 (false) - Hide SSM screen and events
// CA_SYSTEM_CONTROL_ARBITER = 2 (true) - Show SSM screen
bool IGSxSSM::SSM::showStateManagement()
{
    return true;
}
