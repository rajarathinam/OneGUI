/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR_impl.cpp
| Author       : Jan-Pieter
| Description  : Stub impementation of IGSxPAR interface
|
| ! \file        IGSxPAR_impl.cpp
| ! \brief       Stub impementation of IGSxPAR interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/date_time.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/algorithm/string/find.hpp>
#include <boost/lexical_cast.hpp>
#include "IGSxPAR_impl.hpp"
#include "StubParameters.hpp"
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace
{
enum ITEMTYPE
{
    TYPE_int,
    TYPE_uint,
    TYPE_boolean,
    TYPE_double,
    TYPE_floatarray
};

typedef struct
{
    std::string name;
    std::string unit;
    ITEMTYPE itemType;

    int defaultIntValue;
    int currentIntValue;
    unsigned int defaultUintValue;
    unsigned int currentUintValue;
    double defaultDoubleValue;
    double currentDoubleValue;
    bool defaultBoolValue;
    bool currentBoolValue;
    std::vector<double> defaultFloatArrayValue;
    std::vector<double> currentFloatArrayValue;
}gParameterType;

std::vector<double> CreateDoubleArray(std::string doubleString)
{
    std::vector<std::string> values;
    boost::split(values, doubleString, boost::is_any_of(","));

    std::vector<double> doubles;
    try
    {
        for (int i = 0; i < static_cast<int>(values.size()); ++i)
        {
            std::string paramvalue = boost::trim_copy(values[i]);
            doubles.push_back(boost::lexical_cast<double>(paramvalue));
        }
    }
    catch(...)
    {
        IGS_INFO("CreateDoubleArray() - Not able to convert the doubleString \"" + doubleString + "\" using lexical_cast<double>" );
    }
    return doubles;
}


#define CREATEPARAMETERS_int(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_int, VALUE, VALUE, 0, 0, 0.0, 0.0, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_uint(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_uint, 0, 0, VALUE, VALUE, 0.0, 0.0, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_double(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_double, 0, 0, 0, 0, VALUE, VALUE, true, true, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_boolean(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_boolean, 0, 0, 0, 0, 0.0, 0.0, VALUE, VALUE, std::vector<double>(), std::vector<double>() }

#define CREATEPARAMETERS_floatarray(NAME, VALUE, UNIT)\
{ NAME, UNIT, TYPE_floatarray, 0, 0, 0, 0, 0.0, 0.0, true, true, CreateDoubleArray(VALUE), CreateDoubleArray(VALUE) }

#define CREATEPARAMETERS(NAME, VALUE, TYPE, UNIT)\
    CREATEPARAMETERS_##TYPE(NAME, VALUE, UNIT),

gParameterType gParameters[] = {
    PARAMETERS(CREATEPARAMETERS)
};

std::vector<IGSxPAR::ParameterChangeHistory*> gHistory;
IGSxPAR::ValuesChangedCallback gCallback;
IGSxPAR::WriteFinishedCallback gCallbackWriteFinished;
bool gCallbackSubscribed = false;
bool gCallbackWriteFinishedSubscribed = false;
IGSxPAR::IValuePtrVector gValuesForNextEvent;

int getParameterCount()
{
    return sizeof(gParameters)/sizeof(gParameters[0]);
}

int findParameterIndex(const std::string& str)
{
    for (int i = 0; i < getParameterCount(); ++i)
    {
        if (gParameters[i].name == str)
        {
            return i;
        }
    }
    return -1;
}

int getIntParameterValue(const std::string& str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentIntValue;
}


void setIntParameterValue(const std::string& str, int value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentIntValue = value;
}

int getUintParameterValue(const std::string& str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentUintValue;
}

void setUintParameterValue(const std::string& str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentUintValue = value;
}

double getFloatParameterValue(const std::string& str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentDoubleValue;
}

void setFloatParameterValue(const std::string& str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentDoubleValue = value;
}

int getBoolParameterValue(const std::string& str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentBoolValue;
}

void setBoolParameterValue(const std::string& str, double value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentBoolValue = value;
}

std::vector<double> getFloatArrayParameterValue(const std::string& parameterName)
{
    int index = findParameterIndex(parameterName);
    return index == -1 ? std::vector<double>() : gParameters[index].currentFloatArrayValue;
}

void setFloatArrayParameterValue(const std::string& str, const std::vector<double>& value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentFloatArrayValue.clear();
    for (int i = 0; i < static_cast<int>(value.size()); ++i)
    {
        gParameters[index].currentFloatArrayValue.push_back(value[i]);
    }
}

bool containsIgnoreCase(const std::string& targetText, const std::string& searchText)
{
    boost::iterator_range<std::string::const_iterator> iterator = boost::ifind_first(targetText, searchText);

    return iterator;
}

void adjustDoublePrecision(std::string& paramvalue) {
    std::ostringstream ss;
    double d = boost::lexical_cast<double>(paramvalue);
    std::string str = boost::lexical_cast<std::string>(d);
    if (str.find('e') != std::string::npos) {
        ss << std::setprecision(9);
        ss << d + 0.0;
        paramvalue = ss.str();
    } else {
        ss << std::fixed;
        ss << std::setprecision(8);
        ss << d + 0.0;
        paramvalue = ss.str();
        while (paramvalue.find('.') != std::string::npos && (paramvalue.at(paramvalue.size()-1) == '0' || paramvalue.at(paramvalue.size()-1) == '.')) {
            paramvalue.erase(paramvalue.size()-1,1);
        }
    }
}

// helper classes
class WriteValueVisitor : public IGSxPAR::IValueVisitor
{
private:
    std::string m_user;
    std::string m_reason;
    time_t      m_now;

public:
    explicit WriteValueVisitor(const std::string& user, const std::string& reason) :
        m_user(user), m_reason(reason), m_now(time(0))
    {
    }

    virtual void visit(const IGSxPAR::IntValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    boost::lexical_cast<std::string>(getIntParameterValue(type.name())),
                    boost::lexical_cast<std::string>(type.value()));

        gHistory.push_back(historyEntry);
        setIntParameterValue(type.name(), type.value());
        IGSxPAR::IntValue* value = new IGSxPAR::IntValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

    virtual void visit(const IGSxPAR::UIntValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    boost::lexical_cast<std::string>(getUintParameterValue(type.name())),
                    boost::lexical_cast<std::string>(type.value()));

        gHistory.push_back(historyEntry);
        setUintParameterValue(type.name(), type.value());
        IGSxPAR::UIntValue* value = new IGSxPAR::UIntValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }
    virtual void visit(const IGSxPAR::FloatValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        std::string oldVal = boost::lexical_cast<std::string>(getFloatParameterValue(type.name()));
        std::string newVal = boost::lexical_cast<std::string>(type.value());
        adjustDoublePrecision(oldVal);
        adjustDoublePrecision(newVal);
        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason, oldVal, newVal);
        gHistory.push_back(historyEntry);
        setFloatParameterValue(type.name(), type.value());
        IGSxPAR::FloatValue* value = new IGSxPAR::FloatValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }
    virtual void visit(const IGSxPAR::BoolValue& type )
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    getBoolParameterValue(type.name()) == 0 ? "0" : "1",
                    type.value() == 0 ? "0" : "1");

        gHistory.push_back(historyEntry);
        setBoolParameterValue(type.name(), type.value());
        IGSxPAR::BoolValue* value = new IGSxPAR::BoolValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

    virtual void visit(const IGSxPAR::FloatArrayValue& type)
    {
        int index = findParameterIndex(type.name());
        if (index == -1)
        {
            return;
        }

        IGSxPAR::ParameterChangeHistory* historyEntry = new IGSxPAR::ParameterChangeHistory(
                    ConstructName(type.name()), m_now, m_user, m_reason,
                    FloatArrayToString(getFloatArrayParameterValue(type.name())),
                    FloatArrayToString(type.value()));

        gHistory.push_back(historyEntry);
        setFloatArrayParameterValue(type.name(), type.value());
        IGSxPAR::FloatArrayValue* value = new IGSxPAR::FloatArrayValue(type);
        gValuesForNextEvent.push_back(boost::shared_ptr<IGSxPAR::IValue>(value));
    }

private:
    std::string ConstructName(std::string plainName)
    {
        std::string fullName = plainName;
//        int index  = findParameterIndex(plainName);
//        if( index >= 0  && !gParameters[index].unit.empty())
//        {
//            fullName += " (" + gParameters[index].unit + ")";
//        }

        return fullName;
    }

    std::string FloatArrayToString(const std::vector<double>& value)
    {
        if (value.empty())
            return "";

        std::string result = boost::lexical_cast<std::string>(value[0]);
        adjustDoublePrecision(result);
        for (int i = 1; i < static_cast<int>(value.size()); ++i)
        {
            std::string val = boost::lexical_cast<std::string>(value[i]);
            adjustDoublePrecision(val);
            result += "," + val;
        }
        return result;
    }

};

IGSxPAR::ParameterTypePtr createParameter(gParameterType& parameter, bool readOnly)
{
    if (parameter.itemType == TYPE_int)
    {
        IGSxPAR::IntConfig intConfig(parameter.defaultIntValue, 1000000, -1000000, parameter.unit);
        IGSxPAR::IntValue intValue(parameter.name , parameter.currentIntValue);
        boost::shared_ptr<IGSxPAR::IntType> intType(new IGSxPAR::IntType(IGSxPAR::DESIGN, readOnly, intConfig, intValue));

        return intType;
    }
    else if (parameter.itemType == TYPE_uint)
    {
        IGSxPAR::UIntConfig uintConfig(parameter.defaultUintValue, 1000000, 0, parameter.unit);
        IGSxPAR::UIntValue uintValue(parameter.name , parameter.currentUintValue);
        boost::shared_ptr<IGSxPAR::UIntType> uintType(new IGSxPAR::UIntType(IGSxPAR::DESIGN, readOnly, uintConfig, uintValue));

        return uintType;
    }
    else if (parameter.itemType == TYPE_double)
    {
        IGSxPAR::FloatConfig doubleConfig(parameter.defaultDoubleValue, 1000000000000.100, -5.00001, parameter.unit);
        IGSxPAR::FloatValue doubleValue(parameter.name , parameter.currentDoubleValue);
        boost::shared_ptr<IGSxPAR::FloatType> doubleType(new IGSxPAR::FloatType(IGSxPAR::DESIGN, readOnly, doubleConfig, doubleValue));

        return doubleType;
    }
    else if (parameter.itemType == TYPE_boolean)
    {
        IGSxPAR::BoolValue boolValue(parameter.name , parameter.currentBoolValue);
        boost::shared_ptr<IGSxPAR::BoolType> boolType(new IGSxPAR::BoolType(IGSxPAR::DESIGN, readOnly, parameter.defaultBoolValue, boolValue));

        return boolType;
    }
    else if (parameter.itemType == TYPE_floatarray)
    {
        std::vector<double> cur = parameter.currentFloatArrayValue;
        int no_of_elements = cur.size();
        std::vector<std::string> labels;
        int max_input_count = no_of_elements;

        int min_input_count = 0;
        if (no_of_elements < 20) {
            min_input_count = 1;
            max_input_count = no_of_elements * 10;
        } else {
            min_input_count = no_of_elements/2;
        }
        if (no_of_elements < 2) {
            readOnly = false;
        }

        for (int i = 0; i < max_input_count; ++i)
        {
            labels.push_back("Value " + boost::lexical_cast<std::string>(i + 1));
        }

        std::vector<double> defaultValues;
        for (int i = 0; i < no_of_elements; ++i)
        {
            defaultValues.push_back(i * 100.01);
        }
        IGSxPAR::FloatVectorConfig floatVectorConfig(defaultValues, 12345, -1000000.0, parameter.unit);
        IGSxPAR::FloatArrayConfig floatArrayConfig(floatVectorConfig, labels, min_input_count, max_input_count);
        IGSxPAR::FloatArrayValue floatArrayValue(parameter.name , parameter.currentFloatArrayValue);
        boost::shared_ptr<IGSxPAR::FloatArrayType> floatArrayType(new IGSxPAR::FloatArrayType(IGSxPAR::DESIGN, readOnly, floatArrayConfig, floatArrayValue));

        return floatArrayType;
    }
    return IGSxPAR::ParameterTypePtr();
}

void PopulateHistory()
{
    int oneDay = 24 * 60 * 60;
    int oneHour = 60 * 60;
    time_t      date = time(0) - (oneDay * 10);

    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("AmplificationChain/Configuration/PVP_CONNECT_SERVICE_LAPTOP_TO_DL", date, "user 1", "reason 1", "1", "0"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("AmplificationChain/Configuration/PVP_CONNECT_SERVICE_LAPTOP_TO_DL2", date, "user 1", "reason 1", "1", "0"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter2", date, "user 1", "reason 1", "1", "3"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter1", date, "user 1", "reason 1", "1.0", "2.0"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("AmplificationChain/Configuration/PVP_CONNECT_SERVICE_LAPTOP_TO_DL1", date, "user 1", "reason 1", "1,2,3", "3,4,5"));
    date = date + oneDay + oneHour;
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter1", date, "user 2", "reason 2", "2", "3"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath1/Parameter2", date, "user 2", "reason 2", "30000000000000000000000000", "1"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter1", date, "user 2", "reason 2", "2.000000000000000012", "12.02222"));
    gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath2/Parameter2", date, "user 2", "reason 2", "3,4,5", "3,4,6"));
    //for (int i = 0; i < 2000; ++i)
    {
        //date = date + oneDay + oneHour;
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath9/Parameter9/ParameterPath9/Parameter9/ParameterPath9/Parameter9", date+8, "user 2", "reason 9", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath10/Parameter10/ParameterPath10/Parameter10/ParameterPath10/Parameter10", date+9, "user 2", "reason 10", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath11/Parameter11/ParameterPath11/Parameter11/ParameterPath11/Parameter11", date+10, "user 2", "reason 11", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath12/Parameter12/ParameterPath12/Parameter12/ParameterPath12/Parameter12", date+11, "user 2", "reason 12", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath13/Parameter13/ParameterPath13/Parameter13/ParameterPath13/Parameter13", date+12, "user 2", "reason 13", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath14/Parameter14/ParameterPath14/Parameter14/ParameterPath14/Parameter14", date+13, "user 2", "reason 14", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath15/Parameter15/ParameterPath15/Parameter15/ParameterPath15/Parameter15", date+14, "user 2", "reason 15", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath16/Parameter16/ParameterPath16/Parameter16/ParameterPath16/Parameter16", date+15, "user 2", "reason 16", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath17/Parameter17/ParameterPath17/Parameter17/ParameterPath17/Parameter17", date+16, "user 2", "reason 17", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath18/Parameter18/ParameterPath18/Parameter18/ParameterPath18/Parameter18", date+17, "user 2", "reason 18", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath19/Parameter19/ParameterPath19/Parameter19/ParameterPath19/Parameter19", date+18, "user 2", "reason 19", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath20/Parameter20/ParameterPath20/Parameter20/ParameterPath20/Parameter20", date+19, "user 2", "reason 20", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath21/Parameter21/ParameterPath21/Parameter21/ParameterPath21/Parameter21", date+20, "user 2", "reason 21", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath22/Parameter22/ParameterPath22/Parameter22/ParameterPath22/Parameter22", date+21, "user 2", "reason 22", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath23/Parameter23/ParameterPath23/Parameter23/ParameterPath23/Parameter23", date+22, "user 2", "reason 23", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath24/Parameter24/ParameterPath24/Parameter24/ParameterPath24/Parameter24", date+23, "user 2", "reason 24", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath25/Parameter25/ParameterPath25/Parameter25/ParameterPath25/Parameter25", date+24, "user 2", "reason 25", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath26/Parameter26/ParameterPath26/Parameter26/ParameterPath26/Parameter26", date+25, "user 2", "reason 26", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath27/Parameter27/ParameterPath27/Parameter27/ParameterPath27/Parameter27", date+26, "user 2", "reason 27", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath28/Parameter28/ParameterPath28/Parameter28/ParameterPath28/Parameter28", date+27, "user 2", "reason 28", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath29/Parameter29/ParameterPath29/Parameter29/ParameterPath29/Parameter29", date+28, "user 2", "reason 29", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath30/Parameter30/ParameterPath30/Parameter30/ParameterPath30/Parameter30", date+29, "user 2", "reason 30", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath31/Parameter31/ParameterPath31/Parameter31/ParameterPath31/Parameter31", date+30, "user 2", "reason 31", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath32/Parameter32/ParameterPath32/Parameter32/ParameterPath32/Parameter32", date+31, "user 2", "reason 32", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath33/Parameter33/ParameterPath33/Parameter33/ParameterPath33/Parameter33", date+32, "user 2", "reason 33", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath34/Parameter34/ParameterPath34/Parameter34/ParameterPath34/Parameter34", date+33, "user 2", "reason 34", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath35/Parameter35/ParameterPath35/Parameter35/ParameterPath35/Parameter35", date+34, "user 2", "reason 35", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath36/Parameter36/ParameterPath36/Parameter36/ParameterPath36/Parameter36", date+35, "user 2", "reason 36", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath37/Parameter37/ParameterPath37/Parameter37/ParameterPath37/Parameter37", date+36, "user 2", "reason 37", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath38/Parameter38/ParameterPath38/Parameter38/ParameterPath38/Parameter38", date+37, "user 2", "reason 38", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath39/Parameter39/ParameterPath39/Parameter39/ParameterPath39/Parameter39", date+38, "user 2", "reason 40", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath40/Parameter40/ParameterPath40/Parameter40/ParameterPath40/Parameter40", date+39, "user 2", "reason 41", "3,4,5", "3,4,6"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath41/Parameter41/ParameterPath41/Parameter41/ParameterPath41/Parameter41", date+40, "user 2", "reason 42", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath42/Parameter42/ParameterPath42/Parameter42/ParameterPath42/Parameter42", date+41, "user 2", "reason 43", "3", "1"));
      gHistory.push_back(new IGSxPAR::ParameterChangeHistory("AmplificationChain/Configuration/PVP_CONNECT_SERVICE_LAPTOP_TO_DL3", date+42, "user 2", "reason 44", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath44/Parameter44", date+43, "user 2", "reason 45", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("BeamSteeringControl/Application/LocalMirrorControlLowPerfBeamFocusControlMode", date+44, "user 2", "reason 46", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath46/Parameter46", date+45, "user 2", "reason 47", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath47/Parameter47", date+46, "user 2", "reason 48", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath48/Parameter48", date+47, "user 2", "reason 49", "3,4,5", "3,4,6"));

        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("BeamSteeringControl/Application/HWConfig", date+48, "user 2", "reason 50", "2", "3"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("ParameterPath50/Parameter50", date+49, "user 2", "reason 51", "3", "1"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("AmplificationChain/Configuration/PVP_CONNECT_SERVICE_LAPTOP_TO_DL4", date+50, "user 2", "reason 52", "2.0", "12.0"));
        gHistory.push_back(new IGSxPAR::ParameterChangeHistory("CPDFramework/CPDDUMMY/ForceBoundMirror105", date+51, "user 2", "reason 53", "3,4,5", "3,4,6"));
    }
}

} // namespace

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxPAR::PAR* IGSxPAR::PAR_Stub::getInstance()
{
    static PAR_Stub _instance;
    return &_instance;
}
IGSxPAR::PAR* IGSxPAR::PAR::instance = IGSxPAR::PAR_Stub::getInstance();

IGSxPAR::PAR_Stub::PAR_Stub() :  m_UpdateEventTimer(SUI::Timer::createTimer()), m_WriteEventTimer(SUI::Timer::createTimer())
{
    m_UpdateEventTimer->timeout = boost::bind(&IGSxPAR::PAR_Stub::onUpdateEventTimeOut, this);
    m_WriteEventTimer->timeout = boost::bind(&IGSxPAR::PAR_Stub::onWriteEventTimeOut, this);
    PopulateHistory();
}

IGSxPAR::PAR_Stub::~PAR_Stub()
{
}

void IGSxPAR::PAR_Stub::onUpdateEventTimeOut()
{
    if( gCallbackSubscribed)
    {
        if(gValuesForNextEvent.empty()){
            m_UpdateEventTimer->stop();
            return;
        }else if(gValuesForNextEvent.size() == 1){
            gCallback(gValuesForNextEvent);
            gValuesForNextEvent.clear();
        }else{
            IGSxPAR::IValuePtrVector tempVector(2);
            std::copy(gValuesForNextEvent.begin(), gValuesForNextEvent.begin() + 2, tempVector.begin());
            gValuesForNextEvent.erase(gValuesForNextEvent.begin(), gValuesForNextEvent.begin() + 2);
            gCallback(tempVector);
        }
    } else {
        m_UpdateEventTimer->stop();
        gValuesForNextEvent.clear();
        return;
    }
}

void IGSxPAR::PAR_Stub::onWriteEventTimeOut()
{
    if(gCallbackWriteFinished)
    {
        gCallbackWriteFinished(failed_parameters);
    }
    failed_parameters.clear();
    m_WriteEventTimer->stop();
}

void IGSxPAR::PAR_Stub::subscribeValuesChanged(ValuesChangedCallback cb)
{
    gCallback = cb;
    gCallbackSubscribed = true;
}

void IGSxPAR::PAR_Stub::unsubscribeValuesChanged()
{
    gCallbackSubscribed = false;
}

void IGSxPAR::PAR_Stub::read( const std::string& /*filter*/, ParameterTypePtrVector& parameters )
{
    for (int i = 0; i < getParameterCount(); ++i)
    {
        ParameterTypePtr parameterType = createParameter(gParameters[i], (i % 7 != 0));
        if (parameterType != NULL)
        {
            parameters.push_back(parameterType);
        }
    }
}

void IGSxPAR::PAR_Stub::write(const TransactionInfo& transactionInfo, const IValuePtrVector& values)
{
    failed_parameters.clear();
    WriteValueVisitor writeValueVisitor(transactionInfo.userId(), transactionInfo.reason());

    for (size_t i = 0; i < values.size(); ++i)
    {
        std::cout << "IGSxPAR::PAR_Stub::Write()- Paramter name [" << i << "] = " << values[i]->name() << std::endl;
    }

    if (static_cast<int>(values.size()) == 4) {
        failed_parameters.push_back(values[0]->name());
        values[1]->accept(writeValueVisitor);
        values[2]->accept(writeValueVisitor);
        values[3]->accept(writeValueVisitor);

    }
    else if (static_cast<int>(values.size()) == 5) {
        values[0]->accept(writeValueVisitor);
        failed_parameters.push_back(values[1]->name());
        values[2]->accept(writeValueVisitor);
        values[3]->accept(writeValueVisitor);
        failed_parameters.push_back(values[4]->name());
    }
    else
    {
        for (int i = 0; i < static_cast<int>(values.size()); ++i)
        {
            values[i]->accept(writeValueVisitor);
        }
    }

    if (!m_UpdateEventTimer->isActive())
    {
        // the timer from the previous round may still be active
        m_UpdateEventTimer->start(2000);
    }

    if (!m_WriteEventTimer->isActive())
    {
        m_WriteEventTimer->start(1000);
    }
}
void IGSxPAR::PAR_Stub::getChangeHistory(time_t start, time_t end, ParameterChangeHistoryVector& history)
{
    for (int i = 0; i < static_cast<int>(gHistory.size()); ++i)
    {
        if (gHistory[i]->time_of_change() >= start && gHistory[i]->time_of_change() <= end)
        {
            history.push_back(*gHistory[i]);
        }
    }
}

void IGSxPAR::PAR_Stub::subscribeWriteFinished(WriteFinishedCallback cb)
{
    gCallbackWriteFinished = cb;
    gCallbackWriteFinishedSubscribed = true;
}

void IGSxPAR::PAR_Stub::unsubscribeWriteFinished()
{
    gCallbackWriteFinishedSubscribed = false;
}
