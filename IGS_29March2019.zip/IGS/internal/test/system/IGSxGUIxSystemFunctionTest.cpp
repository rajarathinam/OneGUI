/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemFunctionTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Function test
|
| ! \file        IGSxGUIxSystemFunctionTest.cpp
| ! \brief       Implementation of System Function test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxSystemFunction.hpp"
#include "IGSxGUIxSystemFunctionTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(SystemFunctionTest, Test1)
{
    MetaDescription obj("SF-04", "SF Environmental Mgt");
    IGSxGUI::SystemFunction sysfun(obj);

    EXPECT_STRCASEEQ(sysfun.getDescription().c_str(), "SF Environmental Mgt");
    EXPECT_STRCASEEQ(sysfun.getName().c_str(), "SF-04");
}

TEST_F(SystemFunctionTest, Test2)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta("FFA Driver", "FFA Driver Desc");

    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta, DriverState::DS_INITIALIZED, DriverMode::DM_REAL);

    IGSxGUI::Driver* drv = sysfun.getDriver("FFA Driver");
    std::string name = drv->getName();
    EXPECT_STRCASEEQ(name.c_str(), "FFA Driver");

    EXPECT_EQ(DriverState::DS_INITIALIZED, drv->getState());

    IGSxGUI::Driver* drv1 = sysfun.getDriver("UNKNOWN");
    ASSERT_TRUE(drv1 == NULL);
}

TEST_F(SystemFunctionTest, Test3)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_INITIALIZED, DriverMode::DM_REAL);
    ASSERT_TRUE(sysfun.isManagingDriver("FFA Driver"));

    sysfun.addDriver(drvMeta2, DriverState::DS_INITIALIZED, DriverMode::DM_REAL);
    ASSERT_TRUE(sysfun.isManagingDriver("Plasma Driver"));

    ASSERT_FALSE(sysfun.isManagingDriver("UNKNOWN"));

    EXPECT_EQ(2, sysfun.getDriverCount());
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZED, sysfun.getState());

    std::vector<IGSxGUI::Driver*> drivers = sysfun.getDrivers();
    EXPECT_EQ(2, drivers.size());

    IGSxGUI::Driver* drv = drivers[0];
    ASSERT_TRUE(drv != NULL);

    EXPECT_STRCASEEQ(drv->getDisplayName().c_str(), "FFA Driver Desc");
    EXPECT_STRCASEEQ(drv->getName().c_str(), "FFA Driver");
}

TEST_F(SystemFunctionTest, Test4)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_RECOVERY_REQUIRED, DriverMode::DM_REAL);
    sysfun.addDriver(drvMeta2, DriverState::DS_RECOVERY_REQUIRED, DriverMode::DM_REAL);

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, sysfun.getState());
}

TEST_F(SystemFunctionTest, Test5)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_INITIALIZED, DriverMode::DM_REAL);
    sysfun.addDriver(drvMeta2, DriverState::DS_INITIALIZED, DriverMode::DM_REAL);

    sysfun.updateDriverState("FFA Driver", DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED, sysfun.getState());
}

TEST_F(SystemFunctionTest, Test6)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_INITIALIZING, DriverMode::DM_REAL);
    sysfun.addDriver(drvMeta2, DriverState::DS_INITIALIZING, DriverMode::DM_REAL);

    sysfun.updateDriverState("FFA Driver", DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());
}

TEST_F(SystemFunctionTest, Test7)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_TERMINATED, DriverMode::DM_REAL);
    sysfun.addDriver(drvMeta2, DriverState::DS_TERMINATED, DriverMode::DM_REAL);

    sysfun.updateDriverState("FFA Driver", DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_RECOVERY_REQUIRED, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_PARTIALLY_INITIALIZED, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());
}

TEST_F(SystemFunctionTest, Test8)
{
    MetaDescription sysMeta("SF-04", "SF Environmental Mgt");
    MetaDescription drvMeta1("FFA Driver", "FFA Driver Desc");
    MetaDescription drvMeta2("Plasma Driver", "Plasma Driver Desc");
    IGSxGUI::SystemFunction sysfun(sysMeta);

    sysfun.addDriver(drvMeta1, DriverState::DS_TERMINATING, DriverMode::DM_REAL);
    sysfun.addDriver(drvMeta2, DriverState::DS_TERMINATING, DriverMode::DM_REAL);

    sysfun.updateDriverState("FFA Driver", DriverState::DS_RECOVERY_REQUIRED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_TERMINATED);
    EXPECT_EQ(IGSxGUI::SystemState::SS_TERMINATING, sysfun.getState());

    sysfun.updateDriverState("FFA Driver", DriverState::DS_INITIALIZING);
    EXPECT_EQ(IGSxGUI::SystemState::SS_INITIALIZING, sysfun.getState());
}

