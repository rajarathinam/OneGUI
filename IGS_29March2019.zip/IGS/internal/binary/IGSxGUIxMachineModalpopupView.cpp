/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineModalView.cpp
| Author       :
| Description  : Implementation of MachineModal PopUp view
|
| ! \file        IGSxGUIxMachineModalView.cpp
| ! \brief       Implementation of MachineModal PopUp view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2019, ASML  B.V.                                       |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxCore/SUIUILoader.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
#include <boost/bind.hpp>
#include <string>
#include "IGSxGUIxIMachineModalpopupView.hpp"
#include "IGSxGUIxMachineModalpopupView.hpp"
#include "IGSxGUIxMoc_MachineModalpopupView.hpp"
#include "IGSxGUIxUtil.hpp"

const int IGSxGUI::MachineModalView::CLOSE_BUTTON_SIZE = 24;
const std::string IGSxGUI::MachineModalView::MACHINEMODALVIEW_LOAD_FILE = "IGSxGUIxMachineModal.xml";
const std::string IGSxGUI::MachineModalView::TRANSPARENT_BG_MACHINEMODAL_LOAD_FILE = "IGSxGUIxtransparentBackgroundMachineModal.xml";
const std::string IGSxGUI::MachineModalView::CLOSEMARK_HOVERENTER = "#B3E2FF";
const std::string IGSxGUI::MachineModalView::CLOSEMARK_HOVERLEFT = "#AAAAAA";
const int IGSxGUI::MachineModalView::MODAL_DIALOG_WIDTH = 600;
const int IGSxGUI::MachineModalView::MODAL_DIALOG_HEIGHT = 400;

IGSxGUI::MachineModalView::MachineModalView(SUI::GroupBox *parentWidget,std::string machineID,std::string machineVersion):
    machineModalMoc(new SUI::MachineModalMocView),
    m_ParentWidget(parentWidget),
    m_MachineId(machineID),
    m_MachineVersion(machineVersion)
{
    machineModalMoc->setupSUI(MACHINEMODALVIEW_LOAD_FILE.c_str());
    m_dialogModality = SUI::UILoader::loadUI(TRANSPARENT_BG_MACHINEMODAL_LOAD_FILE.c_str());
    intilizeMachineModalData();
}

IGSxGUI::MachineModalView::~MachineModalView()
{
    if (machineModalMoc != NULL)
    {
        delete machineModalMoc;
        machineModalMoc = NULL;
    }
}

void IGSxGUI::MachineModalView::intilizeMachineModalData()
{
    setHandlers();
    IGSxGUI::Util::setParent(machineModalMoc->dialog, m_ParentWidget);
    IGSxGUI::Util::setWindowFrame(machineModalMoc->dialog, false);
    IGSxGUI::Util::setDialogHeight(machineModalMoc->dialog, MODAL_DIALOG_HEIGHT);
    IGSxGUI::Util::setDialogWidth(machineModalMoc->dialog, MODAL_DIALOG_WIDTH);
    IGSxGUI::Util::setAwesome(machineModalMoc->btnCrossMark, IGSxGUI::AwesomeIcon::AI_fa_close, CLOSEMARK_HOVERLEFT, CLOSE_BUTTON_SIZE);
    machineModalMoc->machinelabelValueNumber->setText(m_MachineId);
    machineModalMoc->versionLabelNumber->setText(m_MachineVersion);
    machineModalMoc->plcversionLabel->setVisible(false);
    machineModalMoc->patchLabel->setVisible(false);
}

void IGSxGUI::MachineModalView::show()
{
    IGSxGUI::Util::createModalWindow(m_dialogModality, m_ParentWidget);
    IGSxGUI::Util::executeDialog(machineModalMoc->dialog);
}

void IGSxGUI::MachineModalView::setHandlers()
{
    machineModalMoc->btnCrossMark->clicked = boost::bind(&MachineModalView::onCloseButtonPressed, this);
    machineModalMoc->buttonClose->clicked = boost::bind(&MachineModalView::onCloseButtonPressed, this);
    machineModalMoc->btnCrossMark->hoverEntered = boost::bind(&MachineModalView::onCloseButtonHoverEntered, this);
    machineModalMoc->btnCrossMark->hoverLeft = boost::bind(&MachineModalView::onCloseButtonHoverLeft, this);
}

void IGSxGUI::MachineModalView::onCloseButtonPressed()
{
    machineModalMoc->btnCrossMark->hoverLeft = NULL;
    machineModalMoc->dialog->close();
    IGSxGUI::Util::closeModalWindow(m_dialogModality);
}

void IGSxGUI::MachineModalView::onCloseButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(machineModalMoc->btnCrossMark, IGSxGUI::AwesomeIcon::AI_fa_close, CLOSEMARK_HOVERENTER, CLOSE_BUTTON_SIZE);
}

void IGSxGUI::MachineModalView::onCloseButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(machineModalMoc->btnCrossMark, IGSxGUI::AwesomeIcon::AI_fa_close, CLOSEMARK_HOVERLEFT, CLOSE_BUTTON_SIZE);
}
