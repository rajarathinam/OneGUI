/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineModalpopupView.cpp
| Author       :
| Description  : Implementation of Moc Machine Modal Popup view
|
| ! \file        IGSxGUIxMoc_MachineModalpopupView.cpp
| ! \brief       Implementation of Moc Machine Modal Popup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2019, ASML B.V.                                        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMoc_MachineModalpopupView.hpp"
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIButton.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::MachineModalMocView::MachineModalMocView() :
    dialog(NULL),
    lblAppName(NULL),
    btnCrossMark(NULL),
    machinelabelValue(NULL),
    machinelabelValueNumber(NULL),
    versionLabel(NULL),
    versionLabelNumber(NULL),
    plcversionLabel(NULL),
    plcversionLabelNumber(NULL),
    patchLabel(NULL),
    patchLabelNumber(NULL),
    buttonClose(NULL)
{

}

SUI::MachineModalMocView::~MachineModalMocView()
{
}

void SUI::MachineModalMocView::setupSUI(const char *XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    lblAppName = dialog->getObjectList()->getObject<SUI::Label>("lblHeaderName");
    btnCrossMark = dialog->getObjectList()->getObject<SUI::Button>("btnClose");
    machinelabelValue = dialog->getObjectList()->getObject<SUI::Label>("machinelblValue");
    machinelabelValueNumber = dialog->getObjectList()->getObject<SUI::Label>("machinelblValueNumber");
    versionLabel = dialog->getObjectList()->getObject<SUI::Label>("versionlabel");
    versionLabelNumber = dialog->getObjectList()->getObject<SUI::Label>("versionlblNumber");
    plcversionLabel = dialog->getObjectList()->getObject<SUI::Label>("plcversionlabel");
    plcversionLabelNumber = dialog->getObjectList()->getObject<SUI::Label>("plcversionlblNumber");
    patchLabel = dialog->getObjectList()->getObject<SUI::Label>("patchlabel");
    patchLabelNumber = dialog->getObjectList()->getObject<SUI::Label>("patchlblNumber");
    buttonClose = dialog->getObjectList()->getObject<SUI::Button>("closeButton");
}
