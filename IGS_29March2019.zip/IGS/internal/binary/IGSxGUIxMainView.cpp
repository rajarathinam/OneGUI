/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application view
|
| ! \file        IGSxGUIxMainView.cpp
| ! \brief       Implementation of Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMainView.hpp"
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/thread.hpp>
#include <string>
#include "IGSxGUIxMoc_MainView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxGUIxSplashView.hpp"
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxWidgets/SUIBusyIndicator.h>
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxUtils/SUITimer.h>
#include "IGSxERR.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxLOG.hpp"
#include <FWQxCore/SUIExternalEvent.h>
#include <FWQxCore/SUIExternalEventHandler.h>
#include <FWQxCore/SUIUILoader.h>
#include <FWQxCore/SUIObjectList.h>
#include "IGSxGUIxMachineModalpopupView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MainView::MAINVIEW_LOAD_FILE = "IGSxGUIxMainView.xml";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_SYSTEM = "System";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_DASHBOARD = "Dashboard";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ANALYSIS = "Analysis";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ERRORALARM = "ALARM";

const std::string IGSxGUI::MainView::STRING_MAINVIEW_SHOWN_LOG = "MainView is shown.";
const std::string IGSxGUI::MainView::STRING_INITIALIZED = "INITIALIZED";
const std::string IGSxGUI::MainView::STRING_TERMINATED = "TERMINATED";
const std::string IGSxGUI::MainView::STRING_PARTIALLY_INITIALIZED = "PARTIALLY INITIALIZED";
const std::string IGSxGUI::MainView::STRING_RECOVERY_REQUIRED = "RECOVERY REQUIRED";
const std::string IGSxGUI::MainView::STRING_TERMINATING = "TERMINATING";
const std::string IGSxGUI::MainView::STRING_INITIALIZING = "INITIALIZING";

const std::string IGSxGUI::MainView::STRING_ALARM = "Alarm";
const std::string IGSxGUI::MainView::STRING_ERROR = "Error";
const std::string IGSxGUI::MainView::STRING_WARNING = "Warning";

const std::string IGSxGUI::MainView::STRING_DATE_TIME = "Date & time";
const std::string IGSxGUI::MainView::STRING_ALERTS = "ALERTS";

const std::string IGSxGUI::MainView::STYLE_HOVER_ON = "hoverOn";
const std::string IGSxGUI::MainView::STYLE_HOVER_OFF = "hoverOff";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_ON = "hoverOnAlarmButton";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_OFF = "hoverOffAlarmButton";

const std::string IGSxGUI::MainView::STYLE_POPUP_RED = "popupred";
const std::string IGSxGUI::MainView::STYLE_POPUP_YELLOW = "popupyellow";
const std::string IGSxGUI::MainView::STYLE_BLACK = "black";
const std::string IGSxGUI::MainView::STYLE_WHITE = "white";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_BUTTON = "TopbarButton";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_BUTTON_HOVER = "TopbarButtonHover";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_LABEL_WHITE = "TopbarButtonWhiteLabel";
const std::string IGSxGUI::MainView::STYLE_STATUSBAR_LABEL = "TopbarStatusLabel";
const std::string IGSxGUI::MainView::STYLE_TOPBAR_STATUS_HOVER = "TopbarStatusHover";

const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU1_BUTTON = "System initialization";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU2_BUTTON = "System state manager";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU3_BUTTON = "Hardware reset";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU4_BUTTON = "Maintenance";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU5_BUTTON = "Service";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU6_BUTTON = "Machine constants";

const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU1_BUTTON  = "Data View";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU2_BUTTON  = "Alerts";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU3_BUTTON  = "Advanced diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU4_BUTTON  = "Event Log";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU5_BUTTON  = "System tools";

const std::string IGSxGUI::MainView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::MainView::STRING_CLOSE_BRACKET = ")";

const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_CLICKED  = "subSystemClciked";
const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_NORMAL  = "subSystemText";

const std::string IGSxGUI::MainView::COLOR_WHITE = "#FFFFFF";
const std::string IGSxGUI::MainView::COLOR_ASML_BLUE  = "#1B3E93";
const std::string IGSxGUI::MainView::COLOR_LIGHT_BLUE = "#0AA8FB";
const std::string IGSxGUI::MainView::COLOR_ASML_GREEN = "#38B14A";

const std::string IGSxGUI::MainView::STRING_MACHINEID = "MACHINE: ";
const std::string IGSxGUI::MainView::STRING_MACHINE_VERSION  = "VERSION: ";
const std::string IGSxGUI::MainView::STRING_CPD_ACTIVE = "CPD ACTIVE";
const std::string IGSxGUI::MainView::STRING_SCANNER_INCONTROL = "Scanner in control";
const std::string IGSxGUI::MainView::STRING_DRIVER_STATE_REAL = "REAL";

const std::string IGSxGUI::MainView::ASML_IMAGE_LOGO = "IGSxGUIxSystem_asml.png";

const int IGSxGUI::MainView::TIMER_INTERVAL = 1000;
const int IGSxGUI::MainView::ALERT_BLINKING_INTERVAL = 500;
const int IGSxGUI::MainView::POPUP_BLINKING_TIMER_INTERVAL = 500;
const int IGSxGUI::MainView::POPUP_TIMER_INTERVAL = 30000;
const int IGSxGUI::MainView::MESSAGE_TIMER_INTERVAL = 5000;
const int IGSxGUI::MainView::TIMER_RESTART_INTERVAL = 60000;
const int IGSxGUI::MainView::CONVERSION_BUFFER_SIZE = 80;
const int IGSxGUI::MainView::NAVIGATION_ICONSIZE = 25;
const int IGSxGUI::MainView::TOPBARSYSTEMSTATE_POSITION_X = 10;
const int IGSxGUI::MainView::TOPBARSYSTEMSTATE_ALTERATEPOSITION_X = 30;
const int IGSxGUI::MainView::TOPBARSSMSTATUS_POSITION_X = 10;
const int IGSxGUI::MainView::TOPBARSSMSTATUS_ALTERATEPOSITION_X = 30;
const int IGSxGUI::MainView::PIXELSPACE_AFTER_TEXT_X = 10;
const int IGSxGUI::MainView::TOPBARSSMSTATUS_GBX_MIN_WIDTH = 180;
const int IGSxGUI::MainView::TOPBARSSMSTATUS_GBX_WIDTH_TRANSITIONING = 200;

const std::string IGSxGUI::MainView::STRING_SCANNER = "SCANNER";
const std::string IGSxGUI::MainView::STRING_OPERATOR = "OPERATOR";
const std::string IGSxGUI::MainView::STRING_MAINTENANCE = "MAINTENANCE";
const std::string IGSxGUI::MainView::STRING_NONE = "NONE";
const std::string IGSxGUI::MainView::SSM_STATE_TRANSITIONING = "TRANSITIONING";
const std::string IGSxGUI::MainView::SSM_STATE_UNKNOWN = "UNKNOWN";

const std::string IGSxGUI::MainView::DIALOG_POPUP_ID_IMAGE  = "lblImage";
const std::string IGSxGUI::MainView::DIALOG_POPUP_ID_TITLE = "lblTitle";
const std::string IGSxGUI::MainView::DIALOG_POPUP_ID_MESSAGE = "lblMessage";
const std::string IGSxGUI::MainView::DIALOG_POPUP_ID_OKBUTTON = "btnOk";
const std::string IGSxGUI::MainView::DIALOG_POPUP_ID_CANCELBUTTON = "btnCancel";
const std::string IGSxGUI::MainView::DIALOG_SCANNER_TITLE_TEXT = "Source is remotely in control by scanner";
const std::string IGSxGUI::MainView::DIALOG_SCANNER_MESSAGE_TEXT = "Do you want to take over control?";
const std::string IGSxGUI::MainView::DIALOG_SCANNER_OKBUTTON_TEXT = "Take over";
const std::string IGSxGUI::MainView::DIALOG_SCANNER_CANCELBUTTON_TEXT = "Cancel";

const std::string IGSxGUI::MainView::POPUP_LOAD_FILE = "IGSxGUIxPopupWithIcon.xml";
const int IGSxGUI::MainView::DIALOG_POPUP_X = 0;
const int IGSxGUI::MainView::DIALOG_POPUP_Y = 65;
const int IGSxGUI::MainView::DIALOG_POPUP_WIDTH = 1920;
const int IGSxGUI::MainView::DIALOG_POPUP_HEIGHT = 130;

const int IGSxGUI::MainView::SYSTEM_STATE_EXCLAMATION_ICON_SIZE = 14;

const int CONSTANT_ZERO = 0;
const int CONSTANT_SIX = 6;

IGSxGUI::MainView::MainView() :
    NavigationButton(BTN_SYSTEM),
    sui(new SUI::MainView),
    m_iSystem(NULL),
    m_iDashboard(NULL),
    m_iAnalysis(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_popuptimer(SUI::Timer::createTimer()),
    m_messageTimer(SUI::Timer::createTimer()),
    m_alertBlinkingtimer(SUI::Timer::createTimer()),
    m_bInitializeEventLog(true),
    m_bIsAlertHoverOn(false),
    m_IsFirstVisitToSSMPage(true),
    m_IsFirstVisitSysInitPage(true),
    m_IsFirstVisitToCPDPage(true),
    m_IsFirstVisitToMachineConstantsPage(true),
    m_IsFirstVisitToADTPage(true),
    m_who(IGSxCTRL::Who::NONE)
{
    if (sui != NULL)
    {
        sui->setupSUI(MAINVIEW_LOAD_FILE.c_str());
    }

    sui->uctSystem->clicked = boost::bind(&MainView::onSystemButtonPressed, this);
    sui->uctDashboard->clicked = boost::bind(&MainView::onDashboardButtonPressed, this);
    sui->uctAnalysis->clicked = boost::bind(&MainView::onAnalysisButtonPressed, this);
    sui->uctTopBarAlarm->clicked = boost::bind(&MainView::onAlertsButtonPressed, this);

    sui->uctSystem->hoverEntered = boost::bind(&MainView::onSystemHoverOn, this);
    sui->uctSystem->hoverLeft = boost::bind(&MainView::onSystemHoverOff, this);
    sui->uctDashboard->hoverEntered = boost::bind(&MainView::onDashboardHoverOn, this);
    sui->uctDashboard->hoverLeft = boost::bind(&MainView::onDashboardHoverOff, this);
    sui->uctAnalysis->hoverEntered = boost::bind(&MainView::onAnalysisHoverOn, this);
    sui->uctAnalysis->hoverLeft = boost::bind(&MainView::onAnalysisHoverOff, this);

    sui->uctTopBarControlMode->hoverEntered = boost::bind(&MainView::onTopBarControlModeHoverOn, this);
    sui->uctTopBarControlMode->hoverLeft = boost::bind(&MainView::onTopBarControlModeHoverOff, this);
    sui->uctTopBarControlMode->clicked = boost::bind(&MainView::onTopBarControlModeButtonPressed, this);

    sui->uctTopBarAlarm->hoverEntered = boost::bind(&MainView::onAlertHoverOn, this);
    sui->uctTopBarAlarm->hoverLeft = boost::bind(&MainView::onAlertHoverOff, this);
    sui->uctMachineVersion->hoverEntered = boost::bind(&MainView::onMachineHoverOn, this);
    sui->uctMachineVersion->hoverLeft = boost::bind(&MainView::onMachineHoverOff, this);
    sui->uctMachineVersion->clicked = boost::bind(&MainView::onMachineVersionGroupBoxPressed, this);

    sui->btnSysInit->clicked = boost::bind(&MainView::onSubMenuSystemInitializationPressed, this);
    sui->btnSysStateMgr->clicked = boost::bind(&MainView::onSubMenuSystemStateManagerPressed, this);
    sui->btnSysHWReset->clicked = boost::bind(&MainView::onSubMenuHardwareResetPressed, this);
    sui->btnSysMaintenance->clicked = boost::bind(&MainView::onSubMenuMaintenancePressed, this);
    sui->btnMachineconstants->clicked = boost::bind(&MainView::onSubMenuMachineconstantsPressed, this);
    sui->btnSysService->clicked = boost::bind(&MainView::onSubMenuServicePressed, this);

    sui->btnAnalysisDataView->clicked = boost::bind(&MainView::onSubMenuDataViewPressed, this);
    sui->btnAnalysisSafetyDiagnostics->clicked = boost::bind(&MainView::onSubMenuAlertsPressed, this);
    sui->btnAnalysisADT->clicked = boost::bind(&MainView::onSubMenuAdvancedDiagnosticsPressed, this);
    sui->btnAnalysisEventLog->clicked = boost::bind(&MainView::onSubMenuEventLogPressed, this);
    sui->btnSystemTools->clicked = boost::bind(&MainView::onSubMenuSystemToolsPressed, this);
    sui->btnClose->clicked = boost::bind(&MainView::onAlertPopupClosed, this);

    sui->btnMessageClose->clicked = boost::bind(&MainView::onMessageCloseButtonPressed, this);

    m_systemChanged = boost::bind(&IGSxGUI::MainView::onSystemStateChanged, this, _1);
    m_alertUpdated = boost::bind(&IGSxGUI::MainView::onAlertUpdated, this, _1, _2);
    m_messageDisplay = boost::bind(&IGSxGUI::MainView::onMessageReceived, this, _1);
    m_timer->timeout = boost::bind(&MainView::onTimeout, this);
    m_messageTimer->timeout = boost::bind(&MainView::onMessageTimeout, this);
    m_popuptimer->timeout = boost::bind(&MainView::onPopupTimeout, this);
    m_alertBlinkingtimer->timeout = boost::bind(&MainView::onAlertBlinkTimeout, this);

    m_popuptimer->setSingleShot(true);
    m_messageTimer->setSingleShot(true);

    m_presenter = new IGSxGUI::MainPresenter(this);

    IGS_INFO("MainView() - MainPresenter()" );
    IGSxGUI::Util::setAwesome(sui->lblTopBarServiceEventsIcon, IGSxGUI::AwesomeIcon::AI_fa_cog, COLOR_LIGHT_BLUE, NO_SIZE);

    sui->uctTopBarSystemState->hoverEntered = boost::bind(&MainView::onTopBarSystemStateHoverOn, this);
    sui->uctTopBarSystemState->hoverLeft = boost::bind(&MainView::onTopBarSystemStateHoverOff, this);
    sui->uctTopBarSystemState->clicked = boost::bind(&MainView::onTopBarSystemStatePressed, this);

    sui->uctTopBarSSM->hoverEntered = boost::bind(&MainView::onTopBarSSMHoverOn, this);
    sui->uctTopBarSSM->hoverLeft = boost::bind(&MainView::onTopBarSSMHoverOff, this);
    sui->uctTopBarSSM->clicked = boost::bind(&MainView::onTopBarSSMPressed, this);
    m_ssmStateChanged = boost::bind(&IGSxGUI::MainView::onSSMStateChanged, this, _1);

    m_dialog = SUI::UILoader::loadUI(POPUP_LOAD_FILE.c_str());
    IGS_INFO("MainView() - end" );
}

IGSxGUI::MainView::~MainView()
{
    m_timer->stop();
    m_popuptimer->stop();
    m_messageTimer->stop();
    m_alertBlinkingtimer->stop();

    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }

    if (m_systemChanged != NULL)
    {
        m_iSystem->unsubscribeForSystemState(m_systemChanged);
        m_systemChanged = NULL;
    }
    if (m_alertUpdated != NULL)
    {
        m_iAnalysis->unsubscribeForAlertChange();
        m_alertUpdated = NULL;
    }
    if (m_messageDisplay != NULL)
    {
        m_iSystem->unsubscribeForMessageDisplay();
        m_messageDisplay = NULL;
    }

    if (m_ssmStateChanged != NULL)
    {
        m_iSystem->unsubscribeForSSMStateChange(m_ssmStateChanged);
        m_ssmStateChanged = NULL;
    }
    // Do not delete the plugins, they are maintained by the Factory
}

void IGSxGUI::MainView::show()
{
    sui->imvAsmlLogo->getGraphicsScene()->setBackgroundImageFile(ASML_IMAGE_LOGO);
    sui->dialog->show();
    m_timer->start(TIMER_INTERVAL);

    sui->uctSystem->setVisible(true);
    sui->uctDashboard->setVisible(true);
    sui->uctAnalysis->setVisible(true);

    sui->lblSystem->setText(NAVIGATION_BUTTON_SYSTEM);
    sui->lblDashboard->setText(NAVIGATION_BUTTON_DASHBOARD);
    sui->lblAnalysis->setText(NAVIGATION_BUTTON_ANALYSIS);

    IGSxGUI::Util::setAwesome(sui->lblAlertImageTopBar, IGSxGUI::AwesomeIcon::AI_fa_bell, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblSystemIcon, IGSxGUI::AwesomeIcon::AI_fa_sitemap, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblDashboardIcon, IGSxGUI::AwesomeIcon::AI_fa_dashboard, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblAnalysisIcon, IGSxGUI::AwesomeIcon::AI_fa_sliders, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblTopbarTimeClock, IGSxGUI::AwesomeIcon::AI_fa_clock, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->btnMessageClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::White, NO_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblMessageImage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::White, NO_SIZE);

    sui->lblAlertImageTopBar->setStyleSheetClass(STYLE_TOPBAR_LABEL_WHITE);
    sui->lblAlertTextTopBar->setText(STRING_ALERTS);
    sui->lblAlertTextTopBar->setStyleSheetClass(STYLE_TOPBAR_LABEL_WHITE);
    sui->gbxMachineVersion->setStyleSheetClass(STYLE_TOPBAR_BUTTON);

    setAlertButtonNormalStyle();
    onTopBarControlModeHoverOff();
    setTopBarTimeNormalStyle();

    sui->lblMachineId->setText(m_presenter->getMachineId());
    sui->lblVersion->setText(m_presenter->getReleaseId());

    sui->lbl_tit_info_DateTime->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME_SEC_MERIDIEM));
    sui->gbxTitleInfo_DateTime->setToolTip(STRING_DATE_TIME);

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }

    m_iAnalysis->subscribeForAlertChange(m_alertUpdated);
    int nAlertCount = m_iAnalysis->getAlertCount();
    if (nAlertCount == 0)
    {
        sui->lblAlertTextTopBar->setText(STRING_ALERTS);
    } else {
        std::string strAlarmCount = STRING_ALERTS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET;
        sui->lblAlertTextTopBar->setText(strAlarmCount);
    }

    m_AnalysisActivePage = SCREEN_EVENTLOG;
    m_SystemActivePage = SCREEN_SYSTEM_INIT;
    m_DashboardActivePage = SCREEN_DASHBOARD;
    onSystemButtonPressed();

    IGS_INFO(STRING_MAINVIEW_SHOWN_LOG);

    sui->gbxAlert->hide();
    if (m_iSystem == NULL)
    {
       m_iSystem = PluginFactory::getInstance().getSystemPlugin();
    }

    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
        if (m_ssmStateChanged != NULL)
        {
            m_iSystem->subscribeForSSMStateChange(m_ssmStateChanged);
        }

        if (m_iSystem->allowStateManagement())
        {
            onSSMStateChanged(m_iSystem->retrieveSSMActiveState());
            //get the state for all the SSM tabs for updating the status in SSM and Topbar
            for (int tabIndex = CONSTANT_ZERO; tabIndex < CONSTANT_SIX; ++tabIndex)
            {
                m_iSystem->requestSSMGetState(tabIndex);
            }
        }
        else
        {
            sui->uctTopBarSSM->setVisible(false);
        }
    }

    if (m_iSystem->retrieveDriverState() == STRING_DRIVER_STATE_REAL) {
        sui->btnTopBarDriverStateSim->setVisible(false);
    } else {
        sui->btnTopBarDriverStateSim->setVisible(true);
    }

    //Since screen is not created turn Service Events visibility to false
    sui->uctTopBarServiceEvents->setVisible(false);
}


void IGSxGUI::MainView::onTimeout()
{
    m_timer->stop();

    sui->lbl_tit_info_DateTime->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME_SEC_MERIDIEM));

    m_timer->start();
}

void IGSxGUI::MainView::onAlertPopupClosed()
{
    sui->gbxAlert->hide();
    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
    }
}

void IGSxGUI::MainView::onSystemButtonPressed()
{
    sui->imvAsmlLogo->setVisible(true);
    IGS_INFO("onSystemButtonPressed() - start");
    if (m_iSystem == NULL)
    {
       m_iSystem = PluginFactory::getInstance().getSystemPlugin();
       IGS_INFO("onSystemButtonPressed() - m_iSystem == NULL");
    }

    if (m_systemChanged == NULL)
    {
       m_systemChanged = boost::bind(&IGSxGUI::MainView::onSystemStateChanged, this, _1);
       IGS_INFO("onSystemButtonPressed() - m_systemChanged == NULL");
    }
    m_iSystem->subscribeForSystemState(m_systemChanged);
    m_iSystem->subscribeForMessageDisplay(m_messageDisplay);
   
    showAnalysisSubMenu(false);
    showSystemSubMenu(true);

    sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
    sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
    sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
    sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);
    sui->btnMachineconstants->setText(STRING_SYSTEM_SUBMENU6_BUTTON);


    NavigationButton = BTN_SYSTEM;

    onDashboardHoverOff();
    onAnalysisHoverOff();
    onSystemHoverOn();

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    showActiveContainer(NONE);
    switch (IGSxGUI::MainView::m_SystemActivePage)
    {
        case IGSxGUI::MainView::SCREEN_SYSTEM_INIT:
            onSubMenuSystemInitializationPressed();
            break;
        case IGSxGUI::MainView::SCREEN_MAINTENANCE:
            onSubMenuMaintenancePressed();
            break;
        case IGSxGUI::MainView::SCREEN_MACHINECONSTANTS:
            onSubMenuMachineconstantsPressed();
            break;
        case IGSxGUI::MainView::SCREEN_STATE_MANAGER:
            onSubMenuSystemStateManagerPressed();
            break;
        default:
            break;
    }
}

void IGSxGUI::MainView::showActiveContainer(const CONTAINERS& ActiveContainer)
{
    sui->cntSysInitScreen->setVisible(false);
    sui->cntChildScreens->setVisible(false);
    sui->cntSSMScreens->setVisible(false);
    sui->cntMachineConstantsScreen->setVisible(false);
    switch (ActiveContainer)
    {
        case SYS_INIT:
            sui->cntSysInitScreen->setVisible(true);
            break;
        case SSM:
            sui->cntSSMScreens->setVisible(true);
            break;
        case MACHINE_CONSTANT:
            sui->cntMachineConstantsScreen->setVisible(true);
            break;
        case OTHERS:
            sui->cntChildScreens->setVisible(true);
            break;
        default:
            break;
    }
}

void IGSxGUI::MainView::onDashboardButtonPressed()
{
    sui->imvAsmlLogo->setVisible(false);
    bool bIsFirstTimeDisplay = false;

    m_DashboardActivePage = SCREEN_DASHBOARD;
    m_Activepage = SCREEN_DASHBOARD;

    showAnalysisSubMenu(false);
    showSystemSubMenu(false);

    NavigationButton = BTN_DASHBOARD;
    onSystemHoverOff();
    onAnalysisHoverOff();
    onDashboardHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    if (m_iDashboard == NULL)
    {
        m_iDashboard = PluginFactory::getInstance().getDashboardPlugin();
        bIsFirstTimeDisplay = true;
    }

    showActiveContainer(OTHERS);
    m_iDashboard->show(sui->cntChildScreens, bIsFirstTimeDisplay);
}


void IGSxGUI::MainView::onAnalysisButtonPressed()
{
    sui->imvAsmlLogo->setVisible(true);
    showSystemSubMenu(false);
    showAnalysisSubMenu(true);

    sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
    sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
    sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);
    sui->btnSystemTools->setText(STRING_ANALYSIS_SUBMENU5_BUTTON);

    NavigationButton = BTN_ANALYSIS;

    onSystemHoverOff();
    onDashboardHoverOff();
    onAnalysisHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }

    showActiveContainer(OTHERS);
    switch (IGSxGUI::MainView::m_AnalysisActivePage)
    {
        case IGSxGUI::MainView::SCREEN_EVENTLOG:
            onSubMenuEventLogPressed();
            break;
        case IGSxGUI::MainView::SCREEN_ALERTS:
            onSubMenuAlertsPressed();
            break;
        case IGSxGUI::MainView::SCREEN_ADVANCED_DIAGNOSIS:
            onSubMenuAdvancedDiagnosticsPressed();
            break;
        case IGSxGUI::MainView::SCREEN_SYSTEMTOOLS:
            onSubMenuSystemToolsPressed();
            break;
        default:
            break;
    }
}

void IGSxGUI::MainView::onAlertsButtonPressed()
{
    if (m_Activepage != SCREEN_ALERTS)
    {
        setAlertButtonNormalStyle();

        showSystemSubMenu(false);
        showAnalysisSubMenu(true);

        sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
        sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
        sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
        sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);

        NavigationButton = BTN_ANALYSIS;

        onSystemHoverOff();
        onDashboardHoverOff();
        onAnalysisHoverOn();

        setAnalysisSubMenuButtonStyle(BTN_ALERTS);

        if (m_iSystem != NULL)
        {
            m_iSystem->setActive(false);
        }

        if (m_iDashboard != NULL)
        {
            m_iDashboard->setActive(false);
        }

        if (m_iAnalysis == NULL)
        {
            m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
        }

        showActiveContainer(OTHERS);
        onSubMenuAlertsPressed();
    }
}

void IGSxGUI::MainView::onSSMStateChanged(const std::string &state)
{
    SUI::Rect lblTopBarSSMStatusGeometry = sui->lblTopBarSSMStatus->getGeometry();
    SUI::Rect gbxTopBarSSMGeometry = sui->gbxTopBarSSM->getGeometry();
    SUI::Rect uctTopBarSSMGeometry = sui->uctTopBarSSM->getGeometry();

    if (state == SSM_STATE_TRANSITIONING) {
        sui->bicTopBarSSMProgressBlue->setVisible(true);
        sui->bicTopBarSSMProgressWhite->setVisible(false);
        sui->lblTopBarSSMIcon->setVisible(false);
        sui->lblTopBarSSMStatus->setText(state);

        // adjust the geometry of the items
        sui->lblTopBarSSMStatus->setGeometry(TOPBARSSMSTATUS_POSITION_X, lblTopBarSSMStatusGeometry.getY(),
                                             lblTopBarSSMStatusGeometry.getWidth(), lblTopBarSSMStatusGeometry.getHeight());
        sui->gbxTopBarSSM->setGeometry(gbxTopBarSSMGeometry.getX(), gbxTopBarSSMGeometry.getY(),
                                       TOPBARSSMSTATUS_GBX_WIDTH_TRANSITIONING , gbxTopBarSSMGeometry.getHeight());
        sui->uctTopBarSSM->setGeometry(uctTopBarSSMGeometry.getX(), uctTopBarSSMGeometry.getY(),
                                       TOPBARSSMSTATUS_GBX_WIDTH_TRANSITIONING , uctTopBarSSMGeometry.getHeight());

    } else if (state == SSM_STATE_UNKNOWN) {
        sui->bicTopBarSSMProgressBlue->setVisible(false);
        sui->bicTopBarSSMProgressWhite->setVisible(false);
        sui->lblTopBarSSMIcon->setVisible(true);
        IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle,
                                  SUI::ColorEnum::Red, SYSTEM_STATE_EXCLAMATION_ICON_SIZE);
        sui->lblTopBarSSMStatus->setText(state);

        // adjust the geometry of the items
        sui->lblTopBarSSMStatus->setGeometry(TOPBARSSMSTATUS_ALTERATEPOSITION_X, lblTopBarSSMStatusGeometry.getY(),
                                             lblTopBarSSMStatusGeometry.getWidth(), lblTopBarSSMStatusGeometry.getHeight());
        sui->gbxTopBarSSM->setGeometry(gbxTopBarSSMGeometry.getX(), gbxTopBarSSMGeometry.getY(), TOPBARSSMSTATUS_GBX_MIN_WIDTH,
                                       gbxTopBarSSMGeometry.getHeight());
        sui->uctTopBarSSM->setGeometry(uctTopBarSSMGeometry.getX(), uctTopBarSSMGeometry.getY(), TOPBARSSMSTATUS_GBX_MIN_WIDTH,
                                       uctTopBarSSMGeometry.getHeight());
    } else {
        sui->bicTopBarSSMProgressBlue->setVisible(false);
        sui->bicTopBarSSMProgressWhite->setVisible(false);
        sui->lblTopBarSSMIcon->setVisible(true);
        IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_ASML_GREEN, NO_SIZE);
        sui->lblTopBarSSMStatus->setText(state);

        // adjust the geometry of the items
        sui->lblTopBarSSMStatus->setGeometry(TOPBARSSMSTATUS_ALTERATEPOSITION_X, lblTopBarSSMStatusGeometry.getY(),
                                             lblTopBarSSMStatusGeometry.getWidth(), lblTopBarSSMStatusGeometry.getHeight());
        int labelWidth = IGSxGUI::Util::getLabelTextWidth(sui->lblTopBarSSMStatus, state);
        if ((TOPBARSSMSTATUS_ALTERATEPOSITION_X + labelWidth + PIXELSPACE_AFTER_TEXT_X) < (TOPBARSSMSTATUS_GBX_MIN_WIDTH)) {
            sui->gbxTopBarSSM->setGeometry(gbxTopBarSSMGeometry.getX(), gbxTopBarSSMGeometry.getY(), TOPBARSSMSTATUS_GBX_MIN_WIDTH,
                                           gbxTopBarSSMGeometry.getHeight());
            sui->uctTopBarSSM->setGeometry(uctTopBarSSMGeometry.getX(), uctTopBarSSMGeometry.getY(), TOPBARSSMSTATUS_GBX_MIN_WIDTH,
                                           uctTopBarSSMGeometry.getHeight());
        } else {
            sui->gbxTopBarSSM->setGeometry(gbxTopBarSSMGeometry.getX(), gbxTopBarSSMGeometry.getY(),
                                           TOPBARSSMSTATUS_ALTERATEPOSITION_X + labelWidth + PIXELSPACE_AFTER_TEXT_X,
                                           gbxTopBarSSMGeometry.getHeight());
            sui->uctTopBarSSM->setGeometry(uctTopBarSSMGeometry.getX(), uctTopBarSSMGeometry.getY(),
                                           TOPBARSSMSTATUS_ALTERATEPOSITION_X + labelWidth + PIXELSPACE_AFTER_TEXT_X,
                                           uctTopBarSSMGeometry.getHeight());
        }
    }
}

void IGSxGUI::MainView::onSystemStateChanged(const SystemState::SystemStateEnum &state)
{
    IGS_INFO("onSystemStateChanged() ") ;
    switch (state)
    {
        case SystemState::SS_INITIALIZED:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(true);
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_ASML_GREEN, NO_SIZE);
            sui->lblTopBarSystemState->setText(STRING_INITIALIZED);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_ALTERATEPOSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());
            break;
        }
        case SystemState::SS_TERMINATED:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(false);
            sui->lblTopBarSystemState->setText(STRING_TERMINATED);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_POSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());
            break;
        }
        case SystemState::SS_INITIALIZING:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(true);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(false);
            sui->lblTopBarSystemState->setText(STRING_INITIALIZING);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_POSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());
            break;
        }
        case SystemState::SS_TERMINATING:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(true);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(false);
            sui->lblTopBarSystemState->setText(STRING_TERMINATING);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_POSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());
            break;
        }
        case SystemState::SS_PARTIALLY_INITIALIZED:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(false);
            sui->lblTopBarSystemState->setText(STRING_PARTIALLY_INITIALIZED);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_POSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());

            break;
        }
        case SystemState::SS_RECOVERY_REQUIRED:
        {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
            sui->lblTopBarSystemStateIcon->setVisible(true);
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::Red, NO_SIZE);
            sui->lblTopBarSystemState->setText(STRING_RECOVERY_REQUIRED);
            SUI::Rect rect = sui->lblTopBarSystemState->getGeometry();
            sui->lblTopBarSystemState->setGeometry(TOPBARSYSTEMSTATE_ALTERATEPOSITION_X, rect.getY(), rect.getWidth(), rect.getHeight());
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::onAlertUpdated(int nAlertCount, AlertInfo alertInfo)
{
    sui->lblAlertTextTopBar->setText("");  // This code reduces flickering a little
    if (nAlertCount == 0)
    {
        sui->lblAlertTextTopBar->setText(STRING_ALERTS);
        m_alertBlinkingtimer->stop();
        setAlertButtonNormalStyle();
    } else {
        std::string strAlarmCount = STRING_ALERTS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(nAlertCount) + STRING_CLOSE_BRACKET;
        sui->lblAlertTextTopBar->setText(strAlarmCount);
    }

    if (alertInfo.bIsAlertAdded)
    {
        if (sui->gbxAlert->isVisible() && m_popuptimer->isActive())
        {
            sui->gbxAlert->hide();
            m_popuptimer->stop();

            if (m_iSystem != NULL)
            {
                m_iSystem->notifyAlertPopup(false);
            }
        }
        showPopup(alertInfo);
        m_popuptimer->start(POPUP_TIMER_INTERVAL);

        if (m_AnalysisActivePage != SCREEN_ALERTS)
        {
            m_alertBlinkingtimer->start(ALERT_BLINKING_INTERVAL);
        }
    }
}

void IGSxGUI::MainView::onMessageReceived(std::string message)
{
    sui->gbxMessage->setVisible(true);
    sui->lblMessageDesc->setText(message);
    m_messageTimer->start(MESSAGE_TIMER_INTERVAL);
}

void IGSxGUI::MainView::onPopupTimeout()
{
    sui->gbxAlert->hide();
    m_popuptimer->stop();

    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(false);
    }
}

void IGSxGUI::MainView::onMessageTimeout()
{
    sui->gbxMessage->setVisible(false);
    m_messageTimer->stop();
}

void IGSxGUI::MainView::onAlertBlinkTimeout()
{
    if (!m_bIsAlertHoverOn)
    {
        if (sui->gbxAlertTopBar->getStyleSheetClass() == STYLE_POPUP_RED)
        {
            setAlertButtonNormalStyle();
        } else {
            setAlertButtonBlinkingStyle();
        }
    }
}

void IGSxGUI::MainView::showPopup(const IGSxGUI::AlertInfo &alertInfo)
{
    switch (alertInfo.alertSeverity)
    {
        case IGSxERR::AlertSeverity::ALARM:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_exclamation, SUI::ColorEnum::White, NO_SIZE);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::White, NO_SIZE);
            sui->lblAlertSeverity->setText(STRING_ALARM);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_RED);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertCode->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_WHITE);
            break;
        }
        case IGSxERR::AlertSeverity::ERROR:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::White, NO_SIZE);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::White, NO_SIZE);
            sui->lblAlertSeverity->setText(STRING_ERROR);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_RED);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertCode->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_WHITE);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_WHITE);
            break;
        }
        case IGSxERR::AlertSeverity::WARNING:
        {
            IGSxGUI::Util::setAwesome(sui->lblAlertImage, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::Black, NO_SIZE);
            IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_times, SUI::ColorEnum::Black, NO_SIZE);
            sui->lblAlertSeverity->setText(STRING_WARNING);
            sui->gbxAlert->setStyleSheetClass(STYLE_POPUP_YELLOW);
            sui->lblAlertSeverity->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertCode->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertMessage->setStyleSheetClass(STYLE_BLACK);
            sui->lblAlertDateTime->setStyleSheetClass(STYLE_BLACK);
            break;
        }
        case IGSxERR::AlertSeverity::EVENT:
        default:
        {
            break;
        }
    }
    sui->lblAlertCode->setText(alertInfo.alertCode);
    sui->lblAlertMessage->setText(alertInfo.alertMessage);
    sui->lblAlertDateTime->setText(alertInfo.alertDateTime);

    sui->gbxAlert->show();

    if (m_iSystem != NULL)
    {
        m_iSystem->notifyAlertPopup(true);
    }
}

void IGSxGUI::MainView::setTopBarTimeNormalStyle()
{
    sui->lbl_tit_info_DateTime->setStyleSheetClass(STYLE_STATUSBAR_LABEL);
    sui->gbxTitleInfo_DateTime->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}

void IGSxGUI::MainView::setAlertButtonNormalStyle()
{
    sui->gbxAlertTopBar->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}

void IGSxGUI::MainView::setAlertButtonBlinkingStyle()
{
    sui->gbxAlertTopBar->setStyleSheetClass(STYLE_POPUP_RED);
}

void IGSxGUI::MainView::onSystemHoverOn()
{
    setMainNavigationButtonStyles(BTN_SYSTEM, COLOR_ASML_BLUE, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onDashboardHoverOn()
{
    setMainNavigationButtonStyles(BTN_DASHBOARD, COLOR_ASML_BLUE, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onAnalysisHoverOn()
{
    setMainNavigationButtonStyles(BTN_ANALYSIS, COLOR_ASML_BLUE, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onSystemHoverOff()
{
    if (NavigationButton != BTN_SYSTEM)
    {
        setMainNavigationButtonStyles(BTN_SYSTEM, COLOR_WHITE, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onDashboardHoverOff()
{
    if (NavigationButton != BTN_DASHBOARD)
    {
        setMainNavigationButtonStyles(BTN_DASHBOARD, COLOR_WHITE, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onAnalysisHoverOff()
{
    if (NavigationButton != BTN_ANALYSIS)
    {
        setMainNavigationButtonStyles(BTN_ANALYSIS, COLOR_WHITE, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onTopBarSystemStateHoverOn()
{
    if (m_Activepage != SCREEN_SYSTEM_INIT) {
        sui->gbxTopBarSystemState->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
        if (sui->lblTopBarSystemState->getText() == STRING_INITIALIZED) {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_WHITE, NO_SIZE);
        } else if (sui->lblTopBarSystemState->getText() == STRING_RECOVERY_REQUIRED) {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_times_circle, COLOR_WHITE, NO_SIZE);
        } else if (sui->lblTopBarSystemState->getText() == STRING_INITIALIZING) {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(true);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
        } else if (sui->lblTopBarSystemState->getText() == STRING_TERMINATING) {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(true);
        }
    }
}

void IGSxGUI::MainView::onTopBarSystemStateHoverOff()
{
    if (m_Activepage != SCREEN_SYSTEM_INIT) {
        sui->gbxTopBarSystemState->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
        if (sui->lblTopBarSystemState->getText() == STRING_INITIALIZED) {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_ASML_GREEN, NO_SIZE);
        } else if (sui->lblTopBarSystemState->getText() == STRING_RECOVERY_REQUIRED) {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSystemStateIcon, IGSxGUI::AwesomeIcon::AI_fa_times_circle, SUI::ColorEnum::Red, NO_SIZE);
        } else if (sui->lblTopBarSystemState->getText() == STRING_INITIALIZING) {
            sui->bicTopBarSystemStateProgressBlue->setVisible(true);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(false);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
        } else if (sui->lblTopBarSystemState->getText() == STRING_TERMINATING) {
            sui->bicTopBarSystemStateProgressBlue->setVisible(false);
            sui->bicTopBarSystemStateProgressWhite->setVisible(false);
            sui->bicTopBarSystemStateRegressBlue->setVisible(true);
            sui->bicTopBarSystemStateRegressWhite->setVisible(false);
        }
    }
}

void IGSxGUI::MainView::onTopBarSystemStatePressed()
{
    if (((m_who == IGSxCTRL::Who::GUI) || (m_who == IGSxCTRL::Who::NONE) ) &&
         (m_Activepage != SCREEN_SYSTEM_INIT)) {
        onTopBarSystemStateHoverOff();

        showAnalysisSubMenu(false);
        showSystemSubMenu(true);

        sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
        sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
        sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
        sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
        sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);
        sui->btnMachineconstants->setText(STRING_SYSTEM_SUBMENU6_BUTTON);

        NavigationButton = BTN_SYSTEM;

        onDashboardHoverOff();
        onAnalysisHoverOff();
        onSystemHoverOn();

        if (m_iDashboard != NULL)
        {
            m_iDashboard->setActive(false);
        }

        if (m_iAnalysis != NULL)
        {
            m_iAnalysis->setActive(false);
        }

        showActiveContainer(NONE);

        onSubMenuSystemInitializationPressed();
    }
}

void IGSxGUI::MainView::onTopBarSSMHoverOn()
{
    if (m_Activepage != SCREEN_STATE_MANAGER) {
        sui->gbxTopBarSSM->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
        if (sui->lblTopBarSSMStatus->getText() == "UNKNOWN") {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, COLOR_WHITE, SYSTEM_STATE_EXCLAMATION_ICON_SIZE);
        } else if (sui->lblTopBarSSMStatus->getText() != "TRANSITIONING") {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_WHITE, NO_SIZE);
        } else {
            sui->bicTopBarSSMProgressWhite->setVisible(true);
            sui->bicTopBarSSMProgressBlue->setVisible(false);
        }
    }
}

void IGSxGUI::MainView::onTopBarSSMHoverOff()
{
    if (m_Activepage != SCREEN_STATE_MANAGER) {
        sui->gbxTopBarSSM->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
        if (sui->lblTopBarSSMStatus->getText() == "UNKNOWN") {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::Red, SYSTEM_STATE_EXCLAMATION_ICON_SIZE);
        } else if (sui->lblTopBarSSMStatus->getText() != "TRANSITIONING") {
            IGSxGUI::Util::setAwesome(sui->lblTopBarSSMIcon, IGSxGUI::AwesomeIcon::AI_fa_checkcircle, COLOR_ASML_GREEN, NO_SIZE);
        } else {
            sui->bicTopBarSSMProgressWhite->setVisible(false);
            sui->bicTopBarSSMProgressBlue->setVisible(true);
        }
    }
}

void IGSxGUI::MainView::onTopBarSSMPressed()
{
    if (((m_who == IGSxCTRL::Who::GUI) || (m_who == IGSxCTRL::Who::NONE) ) &&
         (m_Activepage != SCREEN_STATE_MANAGER)) {
        onTopBarSSMHoverOff();

        showAnalysisSubMenu(false);
        showSystemSubMenu(true);

        sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
        sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
        sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
        sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
        sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);
        sui->btnMachineconstants->setText(STRING_SYSTEM_SUBMENU6_BUTTON);

        NavigationButton = BTN_SYSTEM;

        onDashboardHoverOff();
        onAnalysisHoverOff();
        onSystemHoverOn();

        if (m_iDashboard != NULL)
        {
            m_iDashboard->setActive(false);
        }

        if (m_iAnalysis != NULL)
        {
            m_iAnalysis->setActive(false);
        }

        showActiveContainer(NONE);

        onSubMenuSystemStateManagerPressed();
    }
}

void IGSxGUI::MainView::onTopBarControlModeHoverOn()
{
    //If oneGUI is in MAINTENANCE mode and the screen is not MAINTENANCE,
    //then only show the Hover On effect
    //Or, If the control mode is scanner, then also show the Hover On effect
    if (((m_who == IGSxCTRL::Who::TESTMANAGER) && (IGSxGUI::MainView::m_Activepage != IGSxGUI::MainView::SCREEN_MAINTENANCE)) ||
        (m_who == IGSxCTRL::Who::SCANNER))
    {
        sui->gbxTopControlMode->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
    }
    else
    {
        sui->gbxTopControlMode->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
    }
}

void IGSxGUI::MainView::onTopBarControlModeHoverOff()
{
    sui->gbxTopControlMode->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}

void IGSxGUI::MainView::onAlertHoverOn()
{
    if (m_Activepage != SCREEN_ALERTS)
    {
        m_bIsAlertHoverOn = true;
        sui->gbxAlertTopBar->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
    }
}

void IGSxGUI::MainView::onAlertHoverOff()
{
    m_bIsAlertHoverOn = false;
    setAlertButtonNormalStyle();
}

void IGSxGUI::MainView::onMachineHoverOn()
{
    sui->gbxMachineVersion->setStyleSheetClass(STYLE_TOPBAR_BUTTON_HOVER);
}

void IGSxGUI::MainView::onMachineHoverOff()
{
    sui->gbxMachineVersion->setStyleSheetClass(STYLE_TOPBAR_BUTTON);
}

void IGSxGUI::MainView::onMachineVersionGroupBoxPressed()
{
    IGSxGUI::MachineModalView machinemodal(sui->gbxMachineVersion,m_presenter->getMachineId(),m_presenter->getReleaseId());
    machinemodal.show();
}

void IGSxGUI::MainView::setMainNavigationButtonStyles(const BUTTON &button, const std::string &strColor, const std::string &strStyle) const
{
    switch (button)
    {
        case BTN_SYSTEM:
        {
            IGSxGUI::Util::setAwesome(sui->lblSystemIcon, IGSxGUI::AwesomeIcon::AI_fa_sitemap, strColor, NAVIGATION_ICONSIZE);
            sui->lblSystem->setStyleSheetClass(strStyle);
            sui->gbxSystem->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_DASHBOARD:
        {
            IGSxGUI::Util::setAwesome(sui->lblDashboardIcon, IGSxGUI::AwesomeIcon::AI_fa_dashboard, strColor, NAVIGATION_ICONSIZE);
            sui->lblDashboard->setStyleSheetClass(strStyle);
            sui->gbxDashboard->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ANALYSIS:
        {
            IGSxGUI::Util::setAwesome(sui->lblAnalysisIcon, IGSxGUI::AwesomeIcon::AI_fa_sliders, strColor, NAVIGATION_ICONSIZE);
            sui->lblAnalysis->setStyleSheetClass(strStyle);
            sui->gbxAnalysis->setStyleSheetClass(strStyle);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setSystemSubMenuButtonStyle(const SYSTEM_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_SYSTEM_INITIALIZATION:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEM_STATEMANAGER:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_HARDWARE_RESET:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_MAINTENANCE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_MACHINECONSTANTS:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        case BTN_SYSTEM_SERVICE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnMachineconstants->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setAnalysisSubMenuButtonStyle(const IGSxGUI::MainView::ANALYSIS_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_DATAVIEW:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSystemTools->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_ALERTS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSystemTools->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_ADVANCED_DIAGNOSTICS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSystemTools->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_EVENTLOG:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSystemTools->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEMTOOLS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSystemTools->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        default:
           // ToDo, log this case.
           break;
    }
}

void IGSxGUI::MainView::onSubMenuSystemInitializationPressed()
{
    m_SystemActivePage = SCREEN_SYSTEM_INIT;
    m_Activepage = SCREEN_SYSTEM_INIT;
    IGS_INFO("onSubMenuSystemInitializationPressed() - start");
    setSystemSubMenuButtonStyle(BTN_SYSTEM_INITIALIZATION);

    if (m_iSystem == NULL)
    {
        m_iSystem = PluginFactory::getInstance().getSystemPlugin();
    }
    onSystemStateChanged(m_iSystem->retrieveSystemState());
    showActiveContainer(SYS_INIT);
    m_iSystem->show(sui->cntSysInitScreen, m_IsFirstVisitSysInitPage);
    m_IsFirstVisitSysInitPage = false;
    sui->imvAsmlLogo->setVisible(true);
}
void IGSxGUI::MainView::onSubMenuSystemStateManagerPressed()
{
    showActiveContainer(SSM);
    m_SystemActivePage = SCREEN_STATE_MANAGER;
    m_Activepage = SCREEN_STATE_MANAGER;

    setSystemSubMenuButtonStyle(BTN_SYSTEM_STATEMANAGER);
    m_iSystem->showSystemStateManager(sui->cntSSMScreens, m_IsFirstVisitToSSMPage);
    m_IsFirstVisitToSSMPage = false;
    sui->imvAsmlLogo->setVisible(true);
}
void IGSxGUI::MainView::onSubMenuHardwareResetPressed()
{
    m_SystemActivePage = SCREEN_HARDWARE_RESET;
    m_Activepage = SCREEN_HARDWARE_RESET;
    setSystemSubMenuButtonStyle(BTN_HARDWARE_RESET);
}
void IGSxGUI::MainView::onSubMenuMaintenancePressed()
{
    m_SystemActivePage = SCREEN_MAINTENANCE;
    m_Activepage = SCREEN_MAINTENANCE;
    setSystemSubMenuButtonStyle(BTN_MAINTENANCE);
    m_iSystem->showCPD(sui->cntChildScreens, m_IsFirstVisitToCPDPage);
    m_IsFirstVisitToCPDPage = false;
    showActiveContainer(OTHERS);
}

void IGSxGUI::MainView::onSubMenuMachineconstantsPressed()
{
  m_SystemActivePage = SCREEN_MACHINECONSTANTS;
  m_Activepage = SCREEN_MACHINECONSTANTS;
  setSystemSubMenuButtonStyle(BTN_MACHINECONSTANTS);
  m_iSystem->showMachineconstants(sui->cntMachineConstantsScreen, m_IsFirstVisitToMachineConstantsPage);
  m_IsFirstVisitToMachineConstantsPage = false;
  showActiveContainer(MACHINE_CONSTANT);
}
void IGSxGUI::MainView::onSubMenuServicePressed()
{
    m_SystemActivePage = SCREEN_SYSTEM_SERVICE;
    m_Activepage = SCREEN_SYSTEM_SERVICE;
    setSystemSubMenuButtonStyle(BTN_SYSTEM_SERVICE);
}
void IGSxGUI::MainView::onSubMenuDataViewPressed()
{
    m_SystemActivePage = SCREEN_DATAVIEW;
    m_Activepage = SCREEN_DATAVIEW;
    setAnalysisSubMenuButtonStyle(BTN_DATAVIEW);
}
void IGSxGUI::MainView::onSubMenuAlertsPressed()
{
    m_alertBlinkingtimer->stop();
    setAlertButtonNormalStyle();

    m_AnalysisActivePage = SCREEN_ALERTS;
    m_Activepage = SCREEN_ALERTS;

    setAnalysisSubMenuButtonStyle(BTN_ALERTS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showAlert(sui->cntChildScreens, false);
    }
    sui->imvAsmlLogo->setVisible(true);
}

void IGSxGUI::MainView::onSubMenuSystemToolsPressed()
{
    m_AnalysisActivePage = SCREEN_SYSTEMTOOLS;
    m_Activepage = SCREEN_SYSTEMTOOLS;
    setAnalysisSubMenuButtonStyle(BTN_SYSTEMTOOLS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showSystemTools(sui->cntChildScreens, m_IsFirstVisitToADTPage);
    }
}
void IGSxGUI::MainView::onSubMenuAdvancedDiagnosticsPressed()
{
    m_AnalysisActivePage = SCREEN_ADVANCED_DIAGNOSIS;
    m_Activepage = SCREEN_ADVANCED_DIAGNOSIS;
    setAnalysisSubMenuButtonStyle(BTN_ADVANCED_DIAGNOSTICS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showADT(sui->cntChildScreens, m_IsFirstVisitToADTPage);
        m_IsFirstVisitToADTPage = false;
    }
}

void IGSxGUI::MainView::onSubMenuEventLogPressed()
{
    m_AnalysisActivePage = SCREEN_EVENTLOG;
    m_Activepage = SCREEN_EVENTLOG;
    setAnalysisSubMenuButtonStyle(BTN_EVENTLOG);
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showEventViewer(sui->cntChildScreens, m_bInitializeEventLog);
    }
    m_bInitializeEventLog = false;
}

void IGSxGUI::MainView::onMessageCloseButtonPressed()
{
    sui->gbxMessage->setVisible(false);
}

void IGSxGUI::MainView::showSystemSubMenu(bool bShow)
{
    sui->btnSysInit->setVisible(bShow);    
    if (m_iSystem == NULL)
    {
        m_iSystem = PluginFactory::getInstance().getSystemPlugin();
    }
    sui->btnSysStateMgr->setVisible(bShow ? m_iSystem->allowStateManagement() : false);
    sui->btnSysHWReset->setVisible(false);   // Screen not implemented yet
    sui->btnSysMaintenance->setVisible(bShow);
    sui->btnMachineconstants->setVisible(bShow);
    sui->btnSysService->setVisible(false);  // Screen not implemented yet
}

void IGSxGUI::MainView::showAnalysisSubMenu(bool bShow) const
{
    sui->btnAnalysisDataView->setVisible(false);  // Screen not implemented yet
    sui->btnAnalysisSafetyDiagnostics->setVisible(bShow);  // Screen not implemented yet
    sui->btnAnalysisADT->setVisible(bShow);
    sui->btnAnalysisEventLog->setVisible(bShow);
    sui->btnSystemTools->setVisible(bShow);
}

void IGSxGUI::MainView::controlChanged(const IGSxCTRL::Who::WhoEnum &who)
{
    m_who = who;
    onSystemStateChanged(m_iSystem->retrieveSystemState());

    if(sui->lblTopBarControlMode != NULL)
    {
        switch (m_who) {
        case IGSxCTRL::Who::TESTMANAGER: //Maintenance
            sui->lblTopBarControlMode->setText(STRING_MAINTENANCE);
            sui->uctTopBarControlMode->hoverEntered = boost::bind(&MainView::onTopBarControlModeHoverOn, this);
            sui->uctTopBarControlMode->hoverLeft = boost::bind(&MainView::onTopBarControlModeHoverOff, this);
            sui->uctTopBarControlMode->setEnabled(true);
            if ((IGSxGUI::MainView::m_SystemActivePage == IGSxGUI::MainView::SCREEN_STATE_MANAGER) ||
                (IGSxGUI::MainView::m_SystemActivePage == IGSxGUI::MainView::SCREEN_SYSTEM_INIT))
            {
                IGSxGUI::MainView::m_SystemActivePage = IGSxGUI::MainView::SCREEN_MAINTENANCE;
                setSystemSubMenuButtonStyle(BTN_MAINTENANCE);
            }

            //Activepage and m_SystemActivePage can have different values based on SYstem/Dashboard/Analysis
            if ((IGSxGUI::MainView::m_Activepage == IGSxGUI::MainView::SCREEN_STATE_MANAGER) ||
            (IGSxGUI::MainView::m_Activepage == IGSxGUI::MainView::SCREEN_SYSTEM_INIT))
            {
                onSystemButtonPressed();
            }

            sui->btnSysInit->setEnabled(false);
            sui->btnSysStateMgr->setEnabled(false);
            sui->uctTopBarSystemState->hoverEntered = NULL;
            sui->uctTopBarSSM->hoverEntered = NULL;
            break;
        case IGSxCTRL::Who::SCANNER:
            sui->lblTopBarControlMode->setText(STRING_SCANNER);
            sui->uctTopBarControlMode->hoverEntered = boost::bind(&MainView::onTopBarControlModeHoverOn, this);
            sui->uctTopBarControlMode->hoverLeft = boost::bind(&MainView::onTopBarControlModeHoverOff, this);
            sui->uctTopBarControlMode->setEnabled(true);
            if ((IGSxGUI::MainView::m_SystemActivePage == IGSxGUI::MainView::SCREEN_STATE_MANAGER) ||
                (IGSxGUI::MainView::m_SystemActivePage == IGSxGUI::MainView::SCREEN_SYSTEM_INIT))
            {
                IGSxGUI::MainView::m_SystemActivePage = IGSxGUI::MainView::SCREEN_MAINTENANCE;
                setSystemSubMenuButtonStyle(BTN_MAINTENANCE);
            }

            //Activepage and m_SystemActivePage can have different values based on SYstem/Dashboard/Analysis
            if ((IGSxGUI::MainView::m_Activepage == IGSxGUI::MainView::SCREEN_STATE_MANAGER) ||
                (IGSxGUI::MainView::m_Activepage == IGSxGUI::MainView::SCREEN_SYSTEM_INIT))
            {
                onDashboardButtonPressed();
            }

            sui->btnSysInit->setEnabled(false);
            sui->btnSysStateMgr->setEnabled(false);
            sui->uctTopBarSystemState->hoverEntered = NULL;
            sui->uctTopBarSSM->hoverEntered = NULL;
            break;
        case IGSxCTRL::Who::GUI: //Operator
        case IGSxCTRL::Who::NONE:
            sui->lblTopBarControlMode->setText(STRING_OPERATOR);
            sui->uctTopBarControlMode->hoverEntered = NULL;
            sui->uctTopBarControlMode->hoverLeft = NULL;
            sui->uctTopBarControlMode->setEnabled(false);
            sui->btnSysInit->setEnabled(true);
            sui->btnSysStateMgr->setEnabled(true);
            sui->uctTopBarSystemState->hoverEntered = boost::bind(&MainView::onTopBarSystemStateHoverOn, this);
            sui->uctTopBarSSM->hoverEntered = boost::bind(&MainView::onTopBarSSMHoverOn, this);
            break;
        default:
            break;
        }
    }
}

//User clicks on Control mode on TopBar
//If GUI - Operator - Nothing should happen
//if TESTMANAGER - Maintenance - on clicking on Control mode in topbar the Maintenance(CPD) screen should be displayed
//If SCANNER - Scanner is in control and on clicking, revoke dialog should be poped up
void IGSxGUI::MainView::onTopBarControlModeButtonPressed()
{
    switch (m_who) {
    case IGSxCTRL::Who::TESTMANAGER:
        if (IGSxGUI::MainView::m_Activepage != IGSxGUI::MainView::SCREEN_MAINTENANCE)
        {
            IGSxGUI::MainView::m_SystemActivePage = IGSxGUI::MainView::SCREEN_MAINTENANCE;
            onSystemButtonPressed();
        }
        break;
    case IGSxCTRL::Who::SCANNER:
        createPopup(DIALOG_SCANNER_TITLE_TEXT, DIALOG_SCANNER_MESSAGE_TEXT, DIALOG_SCANNER_OKBUTTON_TEXT, DIALOG_SCANNER_CANCELBUTTON_TEXT);
        m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_POPUP_ID_OKBUTTON)->clicked = boost::bind(&MainView::onOkButtonPressed, this);
        m_dialog->show();
        break;
    case IGSxCTRL::Who::GUI:
    case IGSxCTRL::Who::NONE:
    default:
        break;
    }
}

//Display the Revoke dialog to get the control back to the operator
void IGSxGUI::MainView::createPopup(const std::string& title, const std::string& message, const std::string& okButtonText, const std::string& cancelButtonText)
{
    m_dialog->setWindowTitle(DIALOG_POPUP_ID_TITLE);
    IGSxGUI::Util::setAwesome(m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_POPUP_ID_IMAGE),
                                IGSxGUI::AwesomeIcon::AI_fa_exclamation_triangle, SUI::ColorEnum::White, NO_SIZE);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_POPUP_ID_TITLE)->setText(title);
    m_dialog->getObjectList()->getObject<SUI::Label>(DIALOG_POPUP_ID_MESSAGE)->setText(message);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_POPUP_ID_OKBUTTON)->setText(okButtonText);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_POPUP_ID_CANCELBUTTON)->setText(cancelButtonText);
    m_dialog->getObjectList()->getObject<SUI::Button>(DIALOG_POPUP_ID_CANCELBUTTON)->clicked = boost::bind(&SUI::Dialog::close, m_dialog);
    m_dialog->setModal(true);

    IGSxGUI::Util::setParent(m_dialog, sui->uctTopBarControlMode);
    IGSxGUI::Util::disableScrollbars(m_dialog);
    IGSxGUI::Util::setGeometry(m_dialog, DIALOG_POPUP_X, DIALOG_POPUP_Y, DIALOG_POPUP_WIDTH, DIALOG_POPUP_HEIGHT);
    IGSxGUI::Util::setWindowFrame(m_dialog, false);
}

void IGSxGUI::MainView::onOkButtonPressed()
{
    m_dialog->close();
    IGSxCTRL::Control::getInstance()->revokeScanner();
}
