/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
| Ident        : IGSxGUIxEditParameterScreenEventHandler.hpp                  |
| Author       : Venugopal S                                                  |
| Description  : Header file for editing parameter screen event handling      |
|                                                                             |
| ! \file        IGSxGUIxEditParameterScreenEventHandler.hpp                  |
| ! \brief       Header file for editing parameter screen event handling      |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXEDITPARAMETERSCREENEVENTHANDLER_HPP
#define IGSXGUIXEDITPARAMETERSCREENEVENTHANDLER_HPP
#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QRadioButton>
#include <QGroupBox>
#include <SUIDialogImpl.h>
#include <vector>
#include <string>
#include "IGSxGUIxIEditParameterScreenCallBack.hpp"

class IGSxGUIxEditParameterScreenEventHandler : public QObject
{
    Q_OBJECT
 public:
    explicit IGSxGUIxEditParameterScreenEventHandler(QObject *parent = 0);
    void installEvents(std::vector<SUI::Widget*> widgetVector);
    void setEditParameterScreenCallBack(IGSxGUI::IEditParameterScreenCallBack *editParameterScreenCallBack);

 private:
    virtual bool eventFilter(QObject *object, QEvent *event);

    void focusNextWidget();
    void focusPreviousWidget();
    void clearFocusSetButtonBlueBorder();
    void setHoverStyle(QRadioButton* btn);
    void setNormalStyle(QRadioButton* btn);
    void setFocusSetBlueBorder(QLineEdit* lne);
    void clearFocusSetGreyBorder(QLineEdit* lne);
    void clearFocusSetBlueBorder(QLineEdit* lne);
    void clearFocusSetBlueBorder(QPushButton* btn);
    void setFocusSetDottedBorder(QPushButton* btn);

    void processEnterKey() const;

    QLineEdit* m_leValue;
    QRadioButton* m_rbTrue;
    QRadioButton* m_rbFalse;
    QPushButton* m_btnUpdate;
    QPushButton* m_btnCancel;
    QPushButton* m_btnReset;

    static const std::string radiobutton_12px_normal;
    static const std::string radiobutton_12px_normal_fill;
    static const std::string radiobutton_12px_hover;
    static const std::string radiobutton_12px_hover_fill;
    static const std::string radiobutton_12px_pressed;
    static const std::string radiobutton_12px_pressed_fill;

    static const QString STYLE_GREY_BORDER;
    static const QString STYLE_BLUE_BORDER;
    static const QString STYLE_LE_BLUE_BORDER;
    static const QString STYLE_DOTTED_BORDER;

    static const std::string STYLE_RADIO_CHECKED_OPENING;
    static const std::string STYLE_RADIO_UNCHECKED_OPENING;
    static const std::string STYLE_RADIO_BLUE_CLOSING;
    static const std::string STYLE_RADIO_BLACK_CLOSING;

    static const std::string OBJNAME_LINEEDIT;
    static const std::string OBJNAME_RADIOTRUE;
    static const std::string OBJNAME_RADIOFALSE;
    
    IGSxGUI::IEditParameterScreenCallBack* m_editParameterScreenCallBack;
};

#endif  // IGSXGUIXEDITPARAMETERSCREENEVENTHANDLER_HPP
