#ifndef IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP
#define IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QPushButton>
#include <QScrollBar>
#include <QGroupBox>
#include <QTableView>
#include <SUIBaseWidget.h>
#include <SUIButtonImpl.h>
#include <vector>
#include <string>

class IGSxGUIxParameterTableHeaderEventHandler : public QObject
{
    Q_OBJECT
  public:
    IGSxGUIxParameterTableHeaderEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void mousePressed();
    void mouseReleased();
    void mouseEnter();
    void mouseLeft();
  protected:
    virtual bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString str = object->objectName();
        if ( (str == BUTTON_PARAMETERNAME) || \
                (str == BUTTON_UPARROW) || \
                (str == BUTTON_DOWNARROW) ||
                (str == BUTTON_PARAMETERNAME2)) {
            if (mouseEvent->type() == QEvent::MouseButtonPress) {
                mousePressed();
            }
            if (mouseEvent->type() == QEvent::MouseButtonRelease) {
                mouseReleased();
            }
            if (mouseEvent->type() == QEvent::Enter) {
                mouseEnter();
            }
            if (mouseEvent->type() == QEvent::Leave) {
                mouseLeft();
            }
        }
        if (event->type() == QEvent::Wheel) {
            QWheelEvent *wheelEvent = dynamic_cast<QWheelEvent*>(event);
            int numDegrees = wheelEvent->delta() / 8;
            int numSteps = numDegrees / 15;
            if (wheelEvent->orientation() == Qt::Vertical) {
                if (m_scrollBar->isVisible() && m_scrollBar->isEnabled()) {
                    m_scrollBar->setValue(m_scrollBar->value() - numSteps);
                }
            }
            wheelEvent->accept();
        }
        return object->eventFilter(object, event);
    }
  private:
    std::vector<SUI::Widget *> m_widgetVector;
    QPushButton* parameterNameAsc;
    QPushButton* parameterNameDes;
    QPushButton* upArrow;
    QPushButton* downArrow;
    QScrollBar* m_scrollBar;
    QPushButton* m_parameterValue;
    QGroupBox* m_parameterNameGroupBox;
    QTableView* m_tableView;

    SUI::Widget* upArrowBtn;
    SUI::Widget* downArrowBtn;

    static const std::string MOUSE_ENTERED_COLOR_CODE;
    static const std::string MOUSE_RELEASED_COLOR_CODE;
    static const std::string MOUSE_PRESSED_COLOR_CODE;
    static const int PARAMETER_HISTORY_BUTTON_FONT_SIZE;

    static const QString BUTTON_PARAMETERNAME;
    static const QString BUTTON_UPARROW;
    static const QString BUTTON_DOWNARROW;
    static const QString BUTTON_PARAMETERNAME2;


};
#endif  // IGSXGUIXPARAMETERTABLEHEADEREVENTHANDLER_HPP
