#ifndef IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP
#define IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP

#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QPushButton>
#include <QTableView>
#include <QGroupBox>
#include <SUIButtonImpl.h>
#include <SUIBaseWidget.h>
#include <vector>
#include <string>

class IGSxGUIxPendingParameterTableHeaderEventHandler : public QObject
{
    Q_OBJECT
  public:
    IGSxGUIxPendingParameterTableHeaderEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void mousePressed();
    void mouseReleased();
    void mouseEnter();
    void mouseLeft();
    void processMouseWheel(QEvent *event);
  protected:
    virtual bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString str = object->objectName();
        if ( (str == BUTTON_PARAMETERNAME ) ||
                (str == BUTTON_UPARROW ) ||
                (str == BUTTON_DOWNARROW ) ||
                (str == BUTTON_UPDOWNARROW )) {
            if (mouseEvent->type() == QEvent::MouseButtonPress) {
                mousePressed();
            }
            if (mouseEvent->type() == QEvent::MouseButtonRelease) {
                mouseReleased();
            }
            if (mouseEvent->type() == QEvent::Enter) {
                mouseEnter();
            }
            if (mouseEvent->type() == QEvent::Leave) {
                mouseLeft();
            }
        }
        if (mouseEvent->type() ==  QEvent::Wheel) {
            processMouseWheel(event);
        }
        return object->eventFilter(object, event);
    }
  private:
    QPushButton* parameterName;
    std::vector<SUI::Widget *> m_widgetVector;
    QPushButton* upArrow;
    QPushButton* downArrow;
    QPushButton* upDownArrow;
    QPushButton* pendingValue;
    QTableView* m_tableView;
    QGroupBox* m_parameterNameGroupBox;

    static const QString MOUSE_ENTERED_COLOR_CODE;
    static const QString MOUSE_RELEASED_COLOR_CODE;
    static const QString MOUSE_PRESSED_COLOR_CODE;
    static const QString MOUSE_ENTERED_STYLE;
    static const QString MOUSE_RELEASED_STYLE;
    static const QString MOUSE_PRESSED_STYLE;

    static const QString BUTTON_PARAMETERNAME;
    static const QString BUTTON_UPARROW;
    static const QString BUTTON_DOWNARROW;
    static const QString BUTTON_UPDOWNARROW;




};
#endif  // IGSXGUIXPENDINGPARAMETERTABLEHEADEREVENTHANDLER_HPP
