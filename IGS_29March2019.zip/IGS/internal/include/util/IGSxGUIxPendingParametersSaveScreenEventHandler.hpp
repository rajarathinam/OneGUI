/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPendingParametersSaveScreenEventHandler.hpp
| Author       : Roopesh Thota
| Description  : Header file for pending parameter final save screen event
|                handling
|
| ! \file        IGSxGUIxPendingParametersSaveScreenEventHandler.hpp
| ! \brief       Header file for pending parameter final save screen event
|                handling
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXPENDINGPARAMETERSSAVESCREENEVENTHANDLER_HPP
#define IGSXGUIXPENDINGPARAMETERSSAVESCREENEVENTHANDLER_HPP
#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QGroupBox>
#include <SUIDialogImpl.h>
#include <vector>
#include <string>
#include "IGSxGUIxIPendingParametersSaveScreenCallBack.hpp"

class IGSxGUIxPendingParametersSaveScreenEventHandler : public QObject
{
    Q_OBJECT
 public:
    explicit IGSxGUIxPendingParametersSaveScreenEventHandler(QObject *parent = 0);
    void installEvents(std::vector<SUI::Widget*> widgetVector);
    void setPendingParametersSaveScreenCallBack(IGSxGUI::IPendingParametersSaveScreenCallBack* pendingParametersSaveScreenCallBack);

 private:
    virtual bool eventFilter(QObject *object, QEvent *event)
    {
        QString objname = object->objectName();
        std::string objName = objname.toStdString();
        if (event->type() == QEvent::KeyPress) {
            QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
            int key = keyEvent->key();
            switch (key) {
            case Qt::Key_Backtab:
                focusPreviousWidget();
                return true;
            case Qt::Key_Tab:
                if (keyEvent->modifiers().testFlag(Qt::ShiftModifier)) {
                    focusPreviousWidget();
                } else {
                    focusNextWidget();
                }
                return true;
            case Qt::Key_Return:
                handleReturnKeyPress();
                return false;
            default:
                return object->eventFilter(object, event);
            }
        } else if (event->type() == QEvent::MouseButtonPress) {
            if (objName == "lnePendingParamSaveName" || objName == "qt_scrollarea_viewport") {
                handleMouseClick();
                return false;
            }
        }
        return object->eventFilter(object, event);
    }
// private:
    void setTextEditPaletteColor(QTextEdit *TextArea, std::string highlightColor, std::string highlightedTextColor);
    void focusNextWidget();
    void focusPreviousWidget();
    void handleReturnKeyPress();
    void handleMouseClick();
    QLineEdit* m_leName;
    QTextEdit* m_txaReason;
    QWidget* m_txaReasonViewport;
    QGroupBox* m_gbxSave;
    QPushButton* m_btnCancel;
    IGSxGUI::IPendingParametersSaveScreenCallBack* m_pendingParametersSaveScreenCallBack;
};

#endif  // IGSXGUIXPENDINGPARAMETERSSAVESCREENEVENTHANDLER_HPP
