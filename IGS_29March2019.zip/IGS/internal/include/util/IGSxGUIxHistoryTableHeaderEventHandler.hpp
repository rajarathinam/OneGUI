#ifndef IGSXGUIXHISTORYTABLEHEADEREVENTHANDLER_HPP
#define IGSXGUIXHISTORYTABLEHEADEREVENTHANDLER_HPP
#include <QObject>
#include <QMouseEvent>
#include <QDebug>
#include <QLabel>
#include <QPushButton>
#include <QGroupBox>
#include <SUIBaseWidget.h>
#include <SUILabelImpl.h>
#include <SUITableWidgetImpl.h>
#include <SUIScrollBarImpl.h>
#include <SUIBaseWidget.h>
#include <vector>
#include <string>


class IGSxGUIxHistoryTableHeaderEventHandler : public QObject
{
    Q_OBJECT
 public:
    IGSxGUIxHistoryTableHeaderEventHandler();
    void installEvents(std::vector<SUI::Widget *> widgetVector);
    void mousePressNameHeader();
    void mousePressChangeOnHeader();
    void mousePressChangeByHeader();
    void mousePressReasonHeader();

    void mouseReleaseNameHeader();
    void mouseReleaseChangeOnHeader();
    void mouseReleaseChangeByHeader();
    void mouseReleaseReasonHeader();

    void mouseEnterNameHeader();
    void mouseEnterChangeOnHeader();
    void mouseEnterChangeByHeader();
    void mouseEnterReasonHeader();

    void mouseLeftNameHeader();
    void mouseLeftChangeOnHeader();
    void mouseLeftChangeByHeader();
    void mouseLeftReasonHeader();

    void setScrollBar(SUI::ScrollBar *scrollBar);
    void setTableWidget(SUI::TableWidget *tableWidget);

  protected:
    virtual bool eventFilter(QObject *object, QEvent *event)
    {
        QMouseEvent *mouseEvent = static_cast<QMouseEvent *>(event);
        QString rbtn = object->objectName();
        if (mouseEvent->type() == QEvent::MouseButtonPress) {
            if (rbtn == "uctParameterName:lblHistoryHeaderButtonText" || rbtn == "uctParameterName:lblHistoryHeaderButtonImage") {
                mousePressNameHeader();
            } else if (rbtn == "uctChangedOn:lblHistoryHeaderButtonText" || rbtn == "uctChangedOn:lblHistoryHeaderButtonImage") {
                mousePressChangeOnHeader();
            } else if (rbtn == "uctChangedBy:lblHistoryHeaderButtonText" || rbtn == "uctChangedBy:lblHistoryHeaderButtonImage") {
                mousePressChangeByHeader();
            } else if (rbtn == "uctReason:lblHistoryHeaderButtonText" || rbtn == "uctReason:lblHistoryHeaderButtonImage") {
                mousePressReasonHeader();
            }
        }
        if (mouseEvent->type() == QEvent::MouseButtonRelease) {
            if (rbtn == "uctParameterName:lblHistoryHeaderButtonText" || rbtn == "uctParameterName:lblHistoryHeaderButtonImage") {
                mouseReleaseNameHeader();
            } else if (rbtn == "uctChangedOn:lblHistoryHeaderButtonText" || rbtn == "uctChangedOn:lblHistoryHeaderButtonImage") {
                mouseReleaseChangeOnHeader();
            } else if (rbtn == "uctChangedBy:lblHistoryHeaderButtonText" || rbtn == "uctChangedBy:lblHistoryHeaderButtonImage") {
                mouseReleaseChangeByHeader();
            } else if (rbtn == "uctReason:lblHistoryHeaderButtonText" || rbtn == "uctReason:lblHistoryHeaderButtonImage") {
                mouseReleaseReasonHeader();
            }
        }
        if (mouseEvent->type() == QEvent::Enter) {
            if (rbtn == "uctParameterName:lblHistoryHeaderButtonText" || rbtn == "uctParameterName:lblHistoryHeaderButtonImage") {
                mouseEnterNameHeader();
            } else if (rbtn == "uctChangedOn:lblHistoryHeaderButtonText" || rbtn == "uctChangedOn:lblHistoryHeaderButtonImage") {
                mouseEnterChangeOnHeader();
            } else if (rbtn == "uctChangedBy:lblHistoryHeaderButtonText" || rbtn == "uctChangedBy:lblHistoryHeaderButtonImage") {
                mouseEnterChangeByHeader();
            } else if (rbtn == "uctReason:lblHistoryHeaderButtonText" || rbtn == "uctReason:lblHistoryHeaderButtonImage") {
                mouseEnterReasonHeader();
            }
        }
        if (mouseEvent->type() == QEvent::Leave) {
            if (rbtn == "uctParameterName:lblHistoryHeaderButtonText" || rbtn == "uctParameterName:lblHistoryHeaderButtonImage") {
                mouseLeftNameHeader();
            } else if (rbtn == "uctChangedOn:lblHistoryHeaderButtonText" || rbtn == "uctChangedOn:lblHistoryHeaderButtonImage") {
                mouseLeftChangeOnHeader();
            } else if (rbtn == "uctChangedBy:lblHistoryHeaderButtonText" || rbtn == "uctChangedBy:lblHistoryHeaderButtonImage") {
                mouseLeftChangeByHeader();
            } else if (rbtn == "uctReason:lblHistoryHeaderButtonText" || rbtn == "uctReason:lblHistoryHeaderButtonImage") {
                mouseLeftReasonHeader();
            }
        }
        if (event->type() == QEvent::Wheel) {
            QWheelEvent *wheelEvent = dynamic_cast<QWheelEvent*>(event);

                   if (wheelEvent->orientation() == Qt::Vertical) {
                       if (m_scrollBar->isVisible() && m_scrollBar->isEnabled()) {
                           QWheelEvent *wheelEvent = dynamic_cast<QWheelEvent*>(event);
                           int newScrollValue = m_scrollBar->getValue();
                           if(wheelEvent->delta() > 0)
                           {
                                --newScrollValue;
                           }
                           else
                           {
                               ++newScrollValue;
                           }
                            m_scrollBar->setValue(newScrollValue);
                       }
                   }
                   wheelEvent->accept();
        }
        return object->eventFilter(object, event);
    }
 private:
    std::vector<SUI::Widget *> m_widgetVector;
    QLabel* m_parameterNameHistoryHeaderButtonText;
    QLabel* m_parameterNameHistoryHeaderButtonImage;
    QLabel* m_changedOnHistoryHeaderButtonText;
    QLabel* m_changedOnHistoryHeaderButtonImage;
    QLabel* m_changedByHistoryHeaderButtonText;
    QLabel* m_changedByHistoryHeaderButtonImage;
    QLabel* m_reasonHistoryHeaderButtonText;
    QLabel* m_reasonHistoryHeaderButtonImage;

    QPushButton *m_oldValueHistoryHeader;
    QPushButton *m_newValueHistoryHeader;
    QGroupBox *m_gbxParamNameHistoryHeader;
    QGroupBox *m_gbxChangedOnHistoryHeader;
    QGroupBox *m_gbxChangedByHistoryHeader;
    QGroupBox *m_gbxReasonHistoryHeader;

    SUI::Widget * m_parameterNameHistoryHeaderImgBtn;
    SUI::Widget * m_changedOnHistoryHeaderImgBtn;
    SUI::Widget * m_changedByHistoryHeaderImgBtn;
    SUI::Widget * m_reasonHistoryHeaderImgBtn;

    SUI::TableWidget *m_tableWidget;
    SUI::ScrollBar *m_scrollBar;

    static const QString MOUSE_ENTERED_COLOR_CODE;
    static const QString MOUSE_RELEASED_COLOR_CODE;
    static const QString MOUSE_PRESSED_COLOR_CODE;
    static const QString MOUSE_ENTERED_STYLE;
    static const QString MOUSE_RELEASED_STYLE;
    static const QString MOUSE_PRESSED_STYLE;
};
#endif  // IGSXGUIXHISTORYTABLEHEADEREVENTHANDLER_HPP
