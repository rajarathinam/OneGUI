/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterTableEventHandler.hpp
| Author       : Raja A
| Description  : Header file for ParameterTable Event Handler
|
| ! \file        IGSxGUIxParameterTableEventHandler.hpp
| ! \brief       Header file for Parameter Table Event Handler
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCOMMONEVENTHANDLER_H
#define IGSXGUIXCOMMONEVENTHANDLER_H

#include <QObject>
#include <QTableView>
#include <QKeyEvent>
#include <QDebug>
#include <SUIGroupBoxImpl.h>
#include <SUITableWidgetImpl.h>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxIMachineconstantsCallback.hpp"

class IGSxGUIxParameterTableEventHandler : public QObject
{
    Q_OBJECT
  public:
    explicit IGSxGUIxParameterTableEventHandler(QObject *parent = 0);
    virtual ~IGSxGUIxParameterTableEventHandler();
    void setGroupBox(SUI::GroupBox *groupBox);
    void setTableWidget(SUI::TableWidget *tableWidget);
    void setScrollBar(SUI::ScrollBar *scrollBar);
    void setViewCallBack(IGSxGUI::IMachineconstantsCallback *viewCallBack);
    void selectAllRows();
    void copySelectedRows();
    virtual bool eventFilter(QObject *object, QEvent *event);
private:
    SUI::GroupBox *m_groupBox;
    SUI::TableWidget *m_tableWidget;
    SUI::ScrollBar *m_scrollBar;
    IGSxGUI::IMachineconstantsCallback *m_viewCallBack;

    void selectUpRows();
    void selectDownRows();
};
#endif // IGSXGUIXCOMMONEVENTHANDLER_H
