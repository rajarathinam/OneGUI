/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxIMachineconstantsCallBack.hpp
| Author       : Raja A
| Description  : Header file for IMachineconstantsCallBack
|
| ! \file        IGSxGUIxIMachineconstantsCallBack.hpp
| ! \brief       Header file for IMachineconstantsCallBack
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIMACHINECONSTANTSCALLBACK_HPP
#define IGSXGUIXIMACHINECONSTANTSCALLBACK_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
    class IMachineconstantsCallback
    {
    public:
        virtual std::string getFomatedParameterDataToCopy() = 0;
        virtual void selectAllRows() = 0;
        virtual void setCtrlKeyPressed(bool) = 0;
        virtual void selectUpRow() = 0;
        virtual void selectDownRow() = 0;
        virtual void setFocusToParamTable() = 0;
        virtual void setShiftKeyPressed(bool) = 0;
        virtual void invalidateCurrentRow() = 0;
        virtual int getCurrentRow() = 0;
    };
}  // namespace IGSxGUI
#endif // IGSXGUIXIMACHINECONSTANTSCALLBACK_HPP
