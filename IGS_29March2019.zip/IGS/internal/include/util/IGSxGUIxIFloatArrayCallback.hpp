#ifndef IGSXGUIXIFLOATARRAYCALLBACK_HPP
#define IGSXGUIXIFLOATARRAYCALLBACK_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
    class IFloatArrayCallBack
    {
    public:
        virtual void setFALineEditClearButtonVisibility(int row, bool visibility) = 0;
        virtual void setFACurrentLineEditIndex(int index) = 0;
        virtual void setFAPreviousLineEditIndex(int index) = 0;
        virtual int getFACurrentLineEditIndex() = 0;
        virtual int getFAPreviousLineEditIndex() = 0;
    };
}  // namespace IGSxGUI
#endif // IGSXGUIXIFLOATARRAYCALLBACK_HPP
