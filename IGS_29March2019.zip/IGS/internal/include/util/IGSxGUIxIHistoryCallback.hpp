/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxIHistoryCallback.hpp
| Author       : Raja A
| Description  : Header file for HistoryCallback
|
| ! \file        IGSxGUIxIHistoryCallback.hpp
| ! \brief       Header file for HistoryCallback
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIHISTORYCALLBACK_HPP
#define IGSXGUIXIHISTORYCALLBACK_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
    class IHistoryCallBack
    {
    public:
        virtual std::string getParameterHistoryData() = 0;
        virtual void selectAllRows() = 0;
        virtual void setCtrlKeyPressed(bool) = 0;
        virtual void selectUpRow() = 0;
        virtual void selectDownRow() = 0;
        virtual int getVisibleRowsCount() = 0;
        virtual void showToolTipForColumn(int row, int column) = 0;
        virtual void setCurrentRow(int) = 0;
        virtual void invalidateCurrentRow() = 0;
        virtual int getCurrentRow() =0;
        virtual void setShiftKeyPressed(bool) = 0;
        virtual void getParameterHistoryDataInformation(int row, bool& bSelect, bool& bParamInList) = 0;
    };
}  // namespace IGSxGUI
#endif  // IGSXGUIXIHISTORYCALLBACK_HPP
