/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxHistoryEventHandler.hpp
| Author       : Raja A
| Description  : Header file for HistoryEventHandler.
|
| ! \file        IGSxGUIxHistoryEventHandler.hpp
| ! \brief       Header file for HistoryEventHandler.
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/


#ifndef IGSXGUIXHISTORYEVENTHANDLER_HPP
#define IGSXGUIXHISTORYEVENTHANDLER_HPP

#include <QObject>
#include <QTableView>
#include <QKeyEvent>
#include <QDebug>
#include <SUIDialogImpl.h>
#include <SUITableWidgetImpl.h>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxIHistoryCallback.hpp"

class IGSxGUIxHistoryEventHandler : public QObject
{
    Q_OBJECT
  public:
    static IGSxGUIxHistoryEventHandler* getInstance();
    virtual ~IGSxGUIxHistoryEventHandler();
    void setDialog(SUI::Dialog *dialog);
    void setTableWidget(SUI::TableWidget *tableWidget);
    void setHistoryCallBack(IGSxGUI::IHistoryCallBack *historyCallBack);
    void selectAllRows();
    void copySelectedRows();
    void setLineEdit(SUI::LineEdit *lineEdit);
    bool processMousePressEvent(QObject *object);
    bool processMouseMoveEvent(QObject *object);
protected:
    virtual bool eventFilter(QObject *object, QEvent *event);

  private:
    explicit IGSxGUIxHistoryEventHandler(QObject *parent = NULL);
    void selectUpRows();
    void selectDownRows();

    static IGSxGUIxHistoryEventHandler* obj;
    static const std::string HISTORY_ROWS_NAME;
    static const QString STRING_SEARCH_LINEEDIT;
    static const QString STRING_SEARCH_BUTTON;
    static const QString STRING_SEARCH_ONFOCUS_STYLESHEET;
    static const QString STRING_SEARCH_OFFFOCUS_STYLESHEET;
    static const QString STRING_SEARCH_PARAMETER;
    static const QString STRING_LABEL_OLDVALUE;
    static const QString STRING_LABEL_NEWVALUE;
    static const QString STRING_LABEL_CHANGEDBY;
    static const QString STRING_LABEL_REASON;
    static const QString STRING_HISTORY_SCROLLBAR_NAME;

    SUI::Dialog *m_dialog;
    SUI::TableWidget *m_tableWidget;
    SUI::LineEdit *m_lineEdit;
    IGSxGUI::IHistoryCallBack *m_HistoryCallBack;
    size_t m_currentRow;
    bool m_LineEditFocus;
};


#endif // IGSXGUIXHISTORYEVENTHANDLER_HPP
