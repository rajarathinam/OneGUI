#ifndef IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
#define IGSXGUIXFLOATARRAYEVENTHANDLER_HPP

#include <QObject>
#include <QKeyEvent>
#include <QDebug>
#include <QLineEdit>
#include <QTimer>
#include <SUIDialogImpl.h>
#include <vector>
#include <string>
#include <IGSxGUIxIFloatArrayCallback.hpp>

class IGSxGUIxFloatArrayEventHandler : public QObject
{
    Q_OBJECT
 public:
    static IGSxGUIxFloatArrayEventHandler* getInstance(IGSxGUI::IFloatArrayCallBack *ptrFloatArrayCallBack);

 protected:
    virtual bool eventFilter(QObject *object, QEvent *event);
	bool processEvent(QEvent *event, QObject *object);
   
 private:
    static IGSxGUIxFloatArrayEventHandler *obj;
    explicit IGSxGUIxFloatArrayEventHandler(QObject *parent = 0);
    static const std::string LINE_EDIT_NAME;
    IGSxGUI::IFloatArrayCallBack *m_ptrFloatArrayCallBack;
    void setFloatArrayCallBack(IGSxGUI::IFloatArrayCallBack *ptrFloatArrayCallBack);
    int extractLineEditNumFromObjName(const std::string &objName);
	bool mTextSelected;
};
#endif  // IGSXGUIXFLOATARRAYEVENTHANDLER_HPP
