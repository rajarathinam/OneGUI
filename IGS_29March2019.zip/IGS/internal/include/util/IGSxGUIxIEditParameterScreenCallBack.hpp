/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
| Ident        : IGSxGUIxIEditParameterScreenCallback.hpp                     |
| Author       : Venugopal S                                                  |
| Description  : Interface file for callbacks of edit parameter screen        |
|                event handling                                               |
|                                                                             |
| ! \file        IGSxGUIxIEditParameterScreenCallback.hpp                     |
| ! \brief       Interface file for callbacks of edit parameter screen        |
|                event handling                                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIEDITPARAMETERSCREENCALLBACK_HPP
#define IGSXGUIXIEDITPARAMETERSCREENCALLBACK_HPP
namespace IGSxGUI{
class IEditParameterScreenCallBack
{
 public:    
    virtual void onPopupRadioTrueButtonPressed() const = 0;
    virtual void onPopupRadioFalseButtonPressed() const = 0;
    virtual void onPopupUpdateButtonPressed() = 0;
    virtual void onPopupCancelButtonPressed() = 0;
    virtual void onPopupResetButtonPressed() = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIEDITPARAMETERSCREENCALLBACK_HPP
