/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineModalpopupview.hpp
| Author       :
| Description  : Header file for Moc MachineModalpopup view
|
| ! \file        IGSxGUIxMoc_MachineModalpopupview.hpp
| ! \brief       Header file for Moc MachineModalpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2019, ASML B.V.                                        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINEMODALPOPUPVIEW_HPP
#define IGSXGUIXMOC_MACHINEMODALPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class MachineModalMocView;
class MachineModalView;
}  //namespace IGsxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Button;
class Label;
class MachineModalMocView
{
private:
    MachineModalMocView();
    ~MachineModalMocView();
    void setupSUI(const char* XMLFileName);
    SUI::Dialog *dialog;
    SUI::Label *lblAppName;
    SUI::Button *btnCrossMark;
    SUI::Label *machinelabelValue;
    SUI::Label *machinelabelValueNumber;
    SUI::Label *versionLabel;
    SUI::Label *versionLabelNumber;
    SUI::Label *plcversionLabel;
    SUI::Label *plcversionLabelNumber;
    SUI::Label *patchLabel;
    SUI::Label *patchLabelNumber;
    SUI::Button *buttonClose;
    friend class ::IGSxGUI::MachineModalView;

    MachineModalMocView(const MachineModalMocView &);
    MachineModalMocView& operator=(const MachineModalMocView &);
};
}  //namespace SUI
#endif // IGSXGUIXMOC_MACHINEMODALPOPUPVIEW_HPP
