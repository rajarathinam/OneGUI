/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemToolsView.hpp
| Author       : Venugopal S
| Description  : Header file for SystemTools view
|
| ! \file        IGSxGUIxSystemToolsView.hpp
| ! \brief       Header file for SystemTools view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMTOOLSVIEW_HPP
#define IGSXGUIXSYSTEMTOOLSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxISystemToolsView.hpp"
#include "IGSxGUIxSystemToolsManager.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class Timer;
}

namespace SUI {
class SystemToolsView;
class Label;
}
namespace IGSxGUI{

class SystemToolsView : public ISystemToolsView
{
 public:
    explicit SystemToolsView(SystemToolsManager *pSysToolManager);
    virtual ~SystemToolsView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    SystemToolsView(const SystemToolsView &);
    SystemToolsView& operator=(const SystemToolsView &);

    SUI::SystemToolsView *sui;
    SystemToolsManager *m_manager;

    void setHandlers();
    void init();
    void onOpenSystemToolClicked();
    void on_timeout();

    bool m_bActivePage;
    boost::shared_ptr<SUI::Timer> m_timer;

    static const int TIMER_INTERVAL;
    static const std::string STRING_EMPTY;
    static const std::string SYSTEMTOOL;
    static const std::string TOOL_NOT_AVAILABLE;
    static const std::string TOOL_STARTED;
    static const std::string SYSTEMTOOLS_LOAD_FILE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMTOOLSVIEW_HPP
