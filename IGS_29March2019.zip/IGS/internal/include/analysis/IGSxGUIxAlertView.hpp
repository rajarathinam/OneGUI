/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.hpp
| Author       : Venugopal S
| Description  : Header file for Alert view
|
| ! \file        IGSxGUIxAlertView.hpp
| ! \brief       Header file for Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTVIEW_HPP
#define IGSXGUIXALERTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxIAlertView.hpp"
#include "IGSxGUIxAlertPresenter.hpp"
#include "IGSxGUIxUtil.hpp"
#include <FWQxUtils/SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AlertView;
class Label;
}
namespace IGSxGUI{

class AlertView : public IAlertView
{
 public:
    explicit AlertView(AlertManager* pAlertManager);
    virtual ~AlertView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void updateAlerts(int nAlertCount, AlertInfo alertInfo);
    virtual void setActive(bool);

 private:
    AlertView(const AlertView &);
    AlertView& operator=(const AlertView &);

    int addRow();
    void addAlerts(std::vector<Alert *> alerts);
    void addAlert(Alert* alert, int rowNumber);
    void removeAlert(int nAlertId);

    void onSeverityBtnClicked();
    void onCodeBtnClicked();
    void onTimeReportedBtnClicked();

    void configureRow(Alert* alert, int row);
    void sortColumn(int column, bool bIsPageRefreshed);
    void setNoAlertVisible(bool);
    void setTableHeaderStyles(bool bSeverityImageVisibility, bool bTimeImageVisibility, bool bCodeImageVisibility, SUI::Widget *widget) const;
    void onTimeoutBlinkAlarm();
    void updateCounts();

    SUI::AlertView *sui;
    AlertPresenter *m_presenter;
    boost::shared_ptr<SUI::Timer> m_blinktimer;
    bool m_alarmcolorflag;
    IGSxGUI::SortOrder::SortOrderEnum m_order;
    int m_column;

    int alarmcount;
    int errorcount;
    int warningcount;

    static const std::string ALERTVIEW_LOAD_FILE;
    static const std::string STRING_HEADER;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;

    static const std::string STYLE_DEFAULT_HEADER;
    static const std::string STYLE_SELECTED_HEADER;

    static const std::string STRING_ALARM;
    static const std::string STRING_ERROR;
    static const std::string STRING_WARNING;

    static const std::string STRING_SEVERITY;
    static const std::string STRING_TIMEREPORTED;
    static const std::string STRING_CODE;

    static const std::string STRING_ALARMS;
    static const std::string STRING_ERRORS;
    static const std::string STRING_WARNINGS;
    static const std::string STRING_ALERTVIEW_SHOWN;

    static const std::string STRING_NEW;
    static const std::string STRING_NEWLABEL;

    static const int COLUMN_IMAGE;
    static const int COLUMN_SEVERITY;
    static const int COLUMN_LOGCODE;
    static const int COLUMN_MESSAGE;
    static const int COLUMN_TIME;
    static const int COLUMN_NEW;
    static const int COLUMN_SEVERITY_TEXT;
    static const int COLUMN_LOGID;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXALERTVIEW_HPP
