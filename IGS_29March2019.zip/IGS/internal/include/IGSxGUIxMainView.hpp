/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Main application view
|
| ! \file        IGSxGUIxMainView.hpp
| ! \brief       Header file for Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMAINVIEW_HPP
#define IGSXGUIXMAINVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include "IGSxGUIxMainPresenter.hpp"
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxSystemState.hpp"
#include "IGSxGUIxISystem.hpp"
#include "IGSxGUIxIDashboard.hpp"
#include "IGSxGUIxIAnalysis.hpp"
#include <FWQxCore/SUIColorEnum.h>
#include <FWQxWidgets/SUIDialog.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MainView;
class Timer;
}  // namespace SUI

namespace IGSxGUI {
class MainView: public IGSxGUI::IMainView
{
 public:
    MainView();
    virtual ~MainView();
    virtual void show();
    virtual void controlChanged(const IGSxCTRL::Who::WhoEnum& who);

    typedef boost::function<void(SystemState::SystemStateEnum)> systemStateChanged;
    typedef boost::function<void(int, AlertInfo)> alertUpdated;
    typedef boost::function<void(std::string)> messageDisplay;
    typedef boost::function<void(std::string)> SSMStateChanged;
 private:
    MainView(const MainView &);
    MainView& operator=(const MainView &);

    enum BUTTON
    {
        BTN_SYSTEM,
        BTN_DASHBOARD,
        BTN_ANALYSIS
    }NavigationButton;

    enum SYSTEM_SUBMENU_BUTTON
    {
        BTN_SYSTEM_INITIALIZATION,
        BTN_SYSTEM_STATEMANAGER,
        BTN_HARDWARE_RESET,
        BTN_MAINTENANCE,
        BTN_MACHINECONSTANTS,
        BTN_SYSTEM_SERVICE
    }SystemSubmenuButton;

    enum ANALYSIS_SUBMENU_BUTTON
    {
        BTN_DATAVIEW,
        BTN_ALERTS,
        BTN_ADVANCED_DIAGNOSTICS,
        BTN_EVENTLOG,
        BTN_SYSTEMTOOLS
    }AnalysisSubmenuButton;

    enum CONTAINERS
    {
        SYS_INIT,
        SSM,
        MACHINE_CONSTANT,
        OTHERS,
        NONE
    }Containers;

    enum SCREENS
    {
        SCREEN_SYSTEM_INIT,
        SCREEN_STATE_MANAGER,
        SCREEN_HARDWARE_RESET,
        SCREEN_MAINTENANCE,
        SCREEN_MACHINECONSTANTS,
        SCREEN_SYSTEM_SERVICE,
        SCREEN_DASHBOARD,
        SCREEN_DATAVIEW,
        SCREEN_SAFETY_DIAGNOSIS,
        SCREEN_ADVANCED_DIAGNOSIS,
        SCREEN_EVENTLOG,
        SCREEN_ALERTS,
        SCREEN_SYSTEMTOOLS
    }Screens;

    SCREENS m_SystemActivePage, m_DashboardActivePage, m_AnalysisActivePage, m_Activepage;

    void onSystemButtonPressed();
    void onSystemHoverOn();
    void onSystemHoverOff();
    void onDashboardButtonPressed();
    void onDashboardHoverOn();
    void onDashboardHoverOff();
    void onAnalysisButtonPressed();
    void onAnalysisHoverOn();
    void onAnalysisHoverOff();
    void onTopBarControlModeHoverOn();
    void onTopBarControlModeHoverOff();
    void onAlertHoverOn();
    void onAlertHoverOff();
    void onMachineHoverOn();
    void onMachineHoverOff();
    void onSubMenuSystemInitializationPressed();
    void onSubMenuSystemStateManagerPressed();
    void onSubMenuHardwareResetPressed();
    void onSubMenuMaintenancePressed();
    void onSubMenuMachineconstantsPressed();
    void onSubMenuServicePressed();
    void onSubMenuDataViewPressed();
    void onSubMenuAlertsPressed();
    void onSubMenuSystemToolsPressed();
    void onSubMenuAdvancedDiagnosticsPressed();
    void onSubMenuEventLogPressed();
    void onMessageCloseButtonPressed();
    void showSystemSubMenu(bool bShow);
    void showAnalysisSubMenu(bool bShow) const;
    void onAlertsButtonPressed();
    void onTopBarControlModeButtonPressed();
    void createPopup(const std::string& title,
                     const std::string& message,
                     const std::string& okButtonText,
                     const std::string& cancelButtonText);
    void onOkButtonPressed();

    void onSystemStateChanged(const SystemState::SystemStateEnum& state);
    void onAlertUpdated(int alertCOunt, AlertInfo alertInfo);
    void onMessageReceived(std::string message);
    void onTimeout();
    void onAlertPopupClosed();
    void onPopupTimeout();
    void onMessageTimeout();
    void onAlertBlinkTimeout();
    void showPopup(const AlertInfo& alertInfo);
    void setTopBarTimeNormalStyle();
    void setAlertButtonNormalStyle();
    void setAlertButtonBlinkingStyle();
    void setMainNavigationButtonStyles(const BUTTON& button, const std::string& strColor, const std::string& strStyle) const;
    void setSystemSubMenuButtonStyle(const SYSTEM_SUBMENU_BUTTON& button) const;
    void setAnalysisSubMenuButtonStyle(const ANALYSIS_SUBMENU_BUTTON& button) const;
    void showActiveContainer(const CONTAINERS &ActiveContainer);
    void onTopBarSystemStateHoverOn();
    void onTopBarSystemStateHoverOff();
    void onTopBarSystemStatePressed();
    void onTopBarSSMHoverOn();
    void onTopBarSSMHoverOff();
    void onTopBarSSMPressed();
    void onSSMStateChanged(const std::string &state);
    void onMachineVersionGroupBoxPressed();

    static const std::string MAINVIEW_LOAD_FILE;

    static const std::string NAVIGATION_BUTTON_SYSTEM;
    static const std::string NAVIGATION_BUTTON_DASHBOARD;
    static const std::string NAVIGATION_BUTTON_ANALYSIS;
    static const std::string NAVIGATION_BUTTON_ERRORALARM;

    static const std::string IMAGE_BLUE_ALARM;
    static const std::string IMAGE_BLUEDARK_ALARM;
    static const std::string IMAGE_RED_ALARM;

    static const std::string STRING_ALARM;
    static const std::string STRING_ERROR;
    static const std::string STRING_WARNING;

    static const std::string STRING_DATE_TIME;
    static const std::string STRING_ALERTS;

    static const std::string STRING_INITIALIZED;
    static const std::string STRING_TERMINATED;
    static const std::string STRING_PARTIALLY_INITIALIZED;
    static const std::string STRING_RECOVERY_REQUIRED;
    static const std::string STRING_TERMINATING;
    static const std::string STRING_INITIALIZING;

    static const std::string STYLE_HOVER_ON;
    static const std::string STYLE_HOVER_OFF;
    static const std::string STYLE_ERROR_ALARM_HOVER_ON;
    static const std::string STYLE_ERROR_ALARM_HOVER_OFF;

    static const std::string STYLE_POPUP_RED;
    static const std::string STYLE_POPUP_YELLOW;
    static const std::string STYLE_BLACK;
    static const std::string STYLE_WHITE;
    static const std::string STYLE_TOPBAR_LABEL_WHITE;
    static const std::string STYLE_TOPBAR_BUTTON;
    static const std::string STYLE_STATUSBAR_LABEL;
    static const std::string STYLE_TOPBAR_BUTTON_HOVER;
    static const std::string STYLE_TOPBAR_STATUS_HOVER;

    static const std::string STRING_MAINVIEW_SHOWN_LOG;
    static const std::string STRING_SYSTEM_SUBMENU1_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU2_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU3_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU4_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU5_BUTTON;
    static const std::string STRING_SYSTEM_SUBMENU6_BUTTON;

    static const std::string STRING_ANALYSIS_SUBMENU1_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU2_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU3_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU4_BUTTON;
    static const std::string STRING_ANALYSIS_SUBMENU5_BUTTON;

    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;

    static const std::string STYLE_MENU_BUTTON_CLICKED;
    static const std::string STYLE_MENU_BUTTON_NORMAL;

    static const std::string COLOR_LIGHT_BLUE;
    static const std::string COLOR_ASML_BLUE;
    static const std::string COLOR_WHITE;
    static const std::string COLOR_ASML_GREEN;

    static const std::string STRING_MACHINEID;
    static const std::string STRING_MACHINE_VERSION;
    static const std::string STRING_CPD_ACTIVE;
    static const std::string STRING_SCANNER_INCONTROL;
    static const std::string STRING_DRIVER_STATE_REAL;

    static const std::string ASML_IMAGE_LOGO;

    static const int TIMER_INTERVAL;
    static const int POPUP_TIMER_INTERVAL;
    static const int MESSAGE_TIMER_INTERVAL;
    static const int POPUP_BLINKING_TIMER_INTERVAL;
    static const int ALERT_BLINKING_INTERVAL;
    static const int TIMER_RESTART_INTERVAL;
    static const int CONVERSION_BUFFER_SIZE;
    static const int SPLASHSCREEN_TIMEOUT;
    static const int NAVIGATION_ICONSIZE;
    static const int TOPBARSYSTEMSTATE_POSITION_X;
    static const int TOPBARSYSTEMSTATE_ALTERATEPOSITION_X;
    static const int TOPBARSSMSTATUS_POSITION_X;
    static const int TOPBARSSMSTATUS_ALTERATEPOSITION_X;
    static const int PIXELSPACE_AFTER_TEXT_X;
    static const int TOPBARSSMSTATUS_GBX_MIN_WIDTH;
    static const int TOPBARSSMSTATUS_GBX_WIDTH_TRANSITIONING;

    static const std::string STRING_SCANNER;
    static const std::string STRING_OPERATOR;
    static const std::string STRING_MAINTENANCE;
    static const std::string STRING_NONE;
    static const std::string SSM_STATE_TRANSITIONING;
    static const std::string SSM_STATE_UNKNOWN;

    static const std::string DIALOG_POPUP_ID_IMAGE;
    static const std::string DIALOG_POPUP_ID_TITLE;
    static const std::string DIALOG_POPUP_ID_MESSAGE;
    static const std::string DIALOG_POPUP_ID_OKBUTTON;
    static const std::string DIALOG_POPUP_ID_CANCELBUTTON;

    static const std::string DIALOG_SCANNER_TITLE_TEXT;
    static const std::string DIALOG_SCANNER_MESSAGE_TEXT;
    static const std::string DIALOG_SCANNER_OKBUTTON_TEXT;
    static const std::string DIALOG_SCANNER_CANCELBUTTON_TEXT;

    static const std::string POPUP_LOAD_FILE;
    static const int DIALOG_POPUP_X;
    static const int DIALOG_POPUP_Y;
    static const int DIALOG_POPUP_WIDTH;
    static const int DIALOG_POPUP_HEIGHT;

    static const int SYSTEM_STATE_EXCLAMATION_ICON_SIZE;

    SUI::Dialog* m_dialog;

    SUI::MainView *sui;
    IGSxGUI::MainPresenter *m_presenter;
    ISystem *m_iSystem;
    IDashboard *m_iDashboard;
    IAnalysis *m_iAnalysis;
    boost::shared_ptr<SUI::Timer> m_timer;
    boost::shared_ptr<SUI::Timer> m_popuptimer;
    boost::shared_ptr<SUI::Timer> m_messageTimer;
    boost::shared_ptr<SUI::Timer> m_alertBlinkingtimer;
    systemStateChanged m_systemChanged;
    SSMStateChanged m_ssmStateChanged;
    alertUpdated m_alertUpdated;
    messageDisplay  m_messageDisplay;
    bool m_bInitializeEventLog;
    bool m_bIsAlertHoverOn;
    bool m_IsFirstVisitToSSMPage;
    bool m_IsFirstVisitSysInitPage;
    bool m_IsFirstVisitToCPDPage;
    bool m_IsFirstVisitToMachineConstantsPage;
    bool m_IsFirstVisitToADTPage;
    IGSxCTRL::Who::WhoEnum m_who;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMAINVIEW_HPP
