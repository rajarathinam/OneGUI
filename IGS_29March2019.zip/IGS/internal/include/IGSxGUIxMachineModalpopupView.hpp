/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineModalpopupView.hpp
| Author       :
| Description  : Header file for MachineModalpopup view
|
| ! \file        IGSxGUIxMachineModalpopupView.hpp
| ! \brief       Header file for MachineModalpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2019, ASML  B.V.                                       |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINEMODALPOPUPVIEW_HPP
#define IGSXGUIXMACHINEMODALPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIDialog.h>
#include <string>
#include "IGSxGUIxIMachineModalpopupView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineModalMocView;
}  //namespace SUI

namespace IGSxGUI {
class MachineModalView : public IGSxGUI::IMachineModalView
{
 public:
    MachineModalView(SUI::GroupBox *parentWidget,std::string machineID,std::string machineVersion);
    virtual ~MachineModalView();
    virtual void show();

 private:
    MachineModalView(const MachineModalView &);  //copy constructor
    MachineModalView& operator=(const MachineModalView &);

    SUI::MachineModalMocView *machineModalMoc;
    SUI::GroupBox *m_ParentWidget;
    std::string m_MachineId;
    std::string m_MachineVersion;
    SUI::Dialog* m_dialogModality;
    static const std::string MACHINEMODALVIEW_LOAD_FILE;
    static const std::string TRANSPARENT_BG_MACHINEMODAL_LOAD_FILE;
    static const std::string CLOSEMARK_HOVERENTER;
    static const std::string CLOSEMARK_HOVERLEFT;
    static const int CLOSE_BUTTON_SIZE;
    static const int MODAL_DIALOG_WIDTH;
    static const int MODAL_DIALOG_HEIGHT;
    void setHandlers();
    void onCloseButtonPressed();
    void onCloseButtonHoverEntered();
    void onCloseButtonHoverLeft();
    void intilizeMachineModalData();
};
}  //namespace IGSxGUI

#endif // IGSXGUIXMACHINEMODALPOPUPVIEW_HPP
