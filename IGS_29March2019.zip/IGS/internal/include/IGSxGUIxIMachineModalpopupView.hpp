/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIMachineModalpopupView.hpp
| Author       :
| Description  : Interface file for MachineModal Popupview
|
| ! \file        IGSxGUIxIMachineModalpopupView.hpp
| ! \brief       Interface file for MachineModal Popupview
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2019, ASML     B.V.                                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIMACHINEMODALPOPUPVIEW_HPP
#define IGSXGUIXIMACHINEMODALPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                    l            |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIGroupBox.h>
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class IMachineModalView
{
 public:
    IMachineModalView() {}
    virtual ~IMachineModalView() {}
    virtual void show() = 0;
};
}  //namespace IGSXGUI

#endif // IGSXGUIXIMACHINEMODALPOPUPVIEW_HPP
