/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Machineconstants View
|
| ! \file        IGSxGUIxMachineconstantsView.hpp
| ! \brief       Header file for Machineconstants View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxUtils/SUITimer.h>
#include <map>
#include <string>
#include <vector>
#include <utility>
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxHistorypopupView.hpp"
#include "IGSxGUIxIMachineconstantsView.hpp"
#include "IGSxGUIxIMachineconstantsCallback.hpp"
#include "IGSxGUIxMachineconstantsManager.hpp"
#include "IGSxGUIxIPendingParametersSaveScreenCallBack.hpp"
#include "IGSxGUIxIFloatArrayCallback.hpp"
#include <FWQxUtils/SUITime.h>
#include <FWQxUtils/SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class MachineconstantsView;
}  // namespace SUI

namespace IGSxGUI{
class Node;
class BreadCrumResizer;

struct ascOrderPendingParam {
    bool operator() (const std::pair<std::string, std::string> &data1, const std::pair<std::string, std::string> &data2) {
        return data1.first.compare(data2.first) <= 0;
    }
};

struct desOrderPendingParam {
    bool operator() (const std::pair<std::string, std::string> &data1, const std::pair<std::string, std::string> &data2) {
        return data1.first.compare(data2.first) > 0;
    }
};

class MachineconstantsView : public IMachineconstantsView, public IPendingParametersSaveScreenCallBack, public IMachineconstantsCallback, public IFloatArrayCallBack
{
 public:
    explicit MachineconstantsView(MachineconstantsManager*);
    virtual ~MachineconstantsView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void saveButtonPressedOnPendingParamFinalSaveScreen();
    virtual void cancelButtonPressedOnPendingParamFinalSaveScreen();
    void resetValuesYes();
    void resetValuesNo();
    void onResetButtonPressed();

    bool isResetButtonPressed() const;
    void setResetButtonPressedFlag(bool flag);
    void onFloatArrayCloseButtonPressed();
    void onFloatArrayCloseButtonHoverEntered();
    void onFloatArrayCloseButtonHoverLeft();
    void onFloatArrayCancelButtonPressed();

    void onFloatArrayCancelYes();
    void onFloatArrayCancelNo();
    void onParamNameButtonEntered(int row);
    void onParamNameButtonLeft(int row);
    void formatParamButtonName(SUI::Widget *widget, std::string &name);
    bool formatParamButtonNameAfterAddingDots(SUI::Widget *widget, std::string &name);
    virtual void setFALineEditClearButtonVisibility(int row, bool visibility);
    virtual void selectUpRow();
    virtual void selectDownRow();
    virtual void setFocusToParamTable();
    void disableParamsSaveButtons(bool enable);
    void setPendingParamSaveBtnEnable(bool enable);
    void setPendingParamFinalSaveBtnEnable(bool enable);
    void historyRowPressed(const std::string &param);
private:
    MachineconstantsView(const MachineconstantsView &);
    MachineconstantsView& operator=(const MachineconstantsView &);

    enum moveDirection
    {
       UP = 0,
       DOWN
    }Direction;

    void onHistoryHoverLeft();
    void onHistoryHoverEntered();

    void onUCTSaveButtonClicked();
    void onUCTSaveButtonPressed();
    void onUCTSaveButtonHoverOn();
    void onUCTSaveButtonHoverOff();

    void onSearchTextEditFinished();
    void onSearchAndClearButtonHoverLeft();
    void onSearchAndClearButtonHoverEntered();
    void onSearchTextEdited(const std::string &text);

    void onCancelPressedOnFinalSave();
    void uctPendingParamFinalSaveClicked();
    void PendingParamSaveNameLnEditCancel();
    void uctPendingParamFinalSaveHoverLeft();
    void updateViewOnParamSaveEventReceive();
    void onWriteFineshedEventReceive(StringVectorType failedParameterNames);
    void uctPendingParamFinalSaveHoverEntered();

    void init();
    void setHandlers();
    void onBackPressed();
    void onValueChanged();
    void onBackHoverLeft();
    void onHistoryPressed();
    void onBackHoverEntered();
    void onCancelYesPressed();
    void onCancelNoPressed();
    void updateParameterTable();
    void onCancelButtonPressed();
    void pendingParamRetrySave();
    void busyIndicatorWindowClose();
    void performPendingParamSaving();
    void onSearchAndClearButtonPressed();
    void onCancelPressedOnSaveErrorPopUpMessage();
    void updateParameterTableOnCancelingFinalSave();
    void setDefaultPropertiesWhenUpdatingParamTable();

    void onPendingParameterRowClosePressed(int rowNumber);
    void pendingParamApplyRowBehavior(int row);
    void onPendingParameterHoverEntered(int row);
    void onPendingParameterHoverLeft(int row);
    void onPendingParameterClicked(int row);
    void onPendingParameterRowCloseHovered(int row);
    void onPendingParameterRowCloseHoverLeft(int row);

    void onParameterRowPressed(int row);
    void onParameterUCTHoverLeft(int row);
    void onParameterUCTHoverEntered(int row);

    void onParameterTreeItemPressed(int rowNUmber);
    int searchForParameters(const std::string &textToSearch);
    void showSaveCancelButtons(bool bShow);
    void showPendingParamWidgets(bool bShow);
    void showFinalSaveScreenItems(bool bShow);
    void showSearchEntriesParameter(bool bShow);
    void configurePendingParamTableRow(size_t i);
    void showNoPendingParameterScreen(bool bShow);
    void showFinalSaveScreenPendingParams(bool bShow);
    void removePendingParamTableRows();
    void PendingParamSaveTxtChanged(const std::string &text);
    void updatePendingParameterList(std::string pendingParamName);
    void moveSaveCancelButtons(const moveDirection& dir, int pixels);
    void setUCTHandlers(SUI::Widget *widget, int row);
    void populateData(std::vector<ParameterData*>::iterator it, int row);
    void PendingParamSaveChangeReasonTxtChanged(const std::string &text);
    void setTableRows(int value, std::vector<ParameterData*> collection);
    void createPopup(const std::string& title, const std::string& message);
    void setData(int value, int rows, std::vector<ParameterData*> collection);
    void initializeTableRows(int rows, std::vector<ParameterData*> collection);
    void onParameterValueChanged(const std::string& name, const std::string& value);
    void UpdatePendingParamTable(const std::string& name, const std::string& value);
    void configurePendingParamTableRow(int rowNumber, const std::string& name, const std::string& value);
    void refreshTreeViewAndBreadCrums();
    void refreshParameterList(bool sortFlag);
    void refreshPendingParameterList();
    void onBreadCrump1HoverEntered();
    void onBreadCrump2HoverEntered();
    void onBreadCrump3HoverEntered();
    void onBreadCrump4HoverEntered();
    void onBreadCrump5HoverEntered();
    void onBreadCrump6HoverEntered();

    void onBreadCrump1HoverLeft();
    void onBreadCrump2HoverLeft();
    void onBreadCrump3HoverLeft();
    void onBreadCrump4HoverLeft();
    void onBreadCrump5HoverLeft();
    void onBreadCrump6HoverLeft();

    void onBreadCrump1Clicked();
    void onBreadCrump2Clicked();
    void onBreadCrump3Clicked();
    void onBreadCrump4Clicked();
    void onBreadCrump5Clicked();
    void onBreadCrump6Clicked();

    void onBreadCrumpClicked(int index);
    std::string formatParamaterCatogoryName(const std::string &name);
    void formatParamNameBack(std::string &name);
    int UpperCasePositionBackwards(const std::string& name, int fromPos);
    void changeFinalSaveButtonStyle(const std::string &name, const std::string &reason);
    bool isPendingParamTableScrollBarVisible();
    void adjustCancelSaveButtonGeometryUp();
    void adjustCancelSaveButtonGeometryDown();
    void sortParamsAscending();
    void sortParamsDescending();

    std::pair<std::string, int> formatPendingParamName(const std::string &name);
    std::pair<std::string, int> formatParamName(const std::string &name);
    std::pair<std::string, int> formatDialogParamName(const std::string &name);
    std::pair<std::string, int> formatName(const std::string &name, SUI::Widget *widget, const std::string &type, int width);
    size_t getSplitPosition(const std::string &name, SUI::Widget *widget, const std::string &type, int width);
    void extractSubStr(std::size_t found, int &num_of_rows, std::string &retname, std::string &tmpname);

    void sortPendingParams();
    void formatParamValue(SUI::Widget *widget, std::string &name, int columnWidth);
    bool formatParamValueAfterAddingDots(SUI::Widget *widget, std::string &name, int columnWidth);
    void splitToMultilineToolTip(std::string &value, size_t charCount);
    virtual std::string getFomatedParameterDataToCopy();
    virtual void selectAllRows();
    virtual void setCtrlKeyPressed(bool);
    virtual bool isCtrlKeyPressed() const;
    virtual void setShiftKeyPressed(bool);
    virtual bool isShiftKeyPressed() const;
    // it will set the current selected row which is used in selection of parameter rows in copy to clip board feature
    virtual void setCurrentRow(int);
    virtual int getCurrentRow();
    
    virtual void setFACurrentLineEditIndex(int index);
    virtual void setFAPreviousLineEditIndex(int index);
    virtual int getFACurrentLineEditIndex();
    virtual int getFAPreviousLineEditIndex();

    SUI::MachineconstantsView* sui;
    SUI::Dialog* m_dialog;
    SUI::Dialog* m_dialogModalityForHistory;
    SUI::Dialog* m_dialogModality;
    SUI::Dialog* m_dialogFloatArray;
    int m_selectedParameterRowNum;
    int m_selectedPendingParameterRowNum;
    bool m_resetButtonPressedFlag;
    std::vector<ParameterData> m_tabledata;
    IGSxGUI::ParameterpopupView m_parameterview;
    IGSxGUI::HistorypopupView m_historyview;

    std::vector<ParameterData*> m_matchedparameters;
    MachineconstantsManager* m_pMachineconstantsManager;
    std::string m_searchText;
    std::vector<SUI::Button*> breadCrumpButtonList;
    BreadCrumResizer* m_breadCrumResizer;
    std::vector<std::pair<std::string, std::string> > m_pendingParameterList;
    IGSxGUI::AwesomeIcon::AwesomeIconEnum m_searchItemIcon;
    bool m_isCtrlKeyPressed;
    int m_floatArrayCurrentLineEditIndex;
    int m_floatArrayPreviousLineEditIndex;
    std::string m_initialValues;
    std::map<std::string, std::string>  m_mapFAFormattedNames;

    static const int DIALOG_X;
    static const int DIALOG_Y;
    static const int ROW_HEIGHT;
    static const int MULTILINE_ROW_HEIGHT;
    static const int MULTILINE_ROW_HEIGHT_INCREASE;
    static const int BUTTON_SIZE;
    static const int SEARCH_BUTTON_SIZE;
    static const int DIALOG_WIDTH;
    static const int DIALOG_HEIGHT;
    static const int MAX_VISIBLE_ROWS;
    static const int MAX_VISIBLE_ROWS_FLOAT_ARRAY;
    static const int MAX_VISIBLE_ROWS_TOTAL_HEIGHT;
    static const int AWESOME_CLOSE_SIZE;
    static const int PENDINGPARAM_CLOSEBUTTON_SIZE;
    static const int PENDINGPARAM_BI_TIME;
    static const size_t MAX_CHARS_OF_PARAMETERTREE_CELL;
    static const int MAX_CHARS_OF_PARAMS_PER_LINE;
    static const int BOOL_TYPE_DIALOG;
    static const int MAXIMUM_DOUBLE_PRECISION;
    static const int PENDING_PARAM_MAX_VISIBLE_ROWS_TOTAL_HEIGHT;
    static const int PENDING_PARAM_TABLE_YPOSITION;
    static const int PENDING_PARAM_CANCELSAVE_BUTTON_YPOS_FROM_TABLE;
    static const size_t MAX_VISIBLE_CHARS_OF_PARAM_VALUE;
    static const int SEARCH_PARAMETER_TEXTEDIT_TIMEOUT_MS;
    static const int COLUMN_WIDTH;
    static const int COLUMN_HEIGHT;
    
    static const std::string DIALOG_TITLE;
    static const std::string DIALOG_MESSAGE;
    static const std::string DIALOG_ID_TITLE;
    static const std::string DIALOG_ID_MESSAGE;
    static const std::string DIALOG_ID_NOBUTTON;
    static const std::string DIALOG_ID_YESBUTTON;
    static const std::string STRING_GREY_REGULAR;
    static const std::string STRING_BLUE_REGULAR;
    static const std::string STYLE_BUTTON_BLUEBG;
    static const std::string COLOR_LINEEDIT_CANCEL;
    static const std::string STYLE_BUTTON_ORANGEBG;
    static const std::string CANCELPOPUP_LOAD_FILE;
    static const std::string STYLE_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETER_FOUND;
    static const std::string STRING_SEARCH_PARAMETER;
    static const std::string STRING_PARAMETERS_FOUND;
    static const std::string STYLE_BUTTON_HOVERBLUEBG;
    static const std::string STRING_CLOSE_BUTTON_COLOR;
    static const std::string STYLE_SEARCHPARAM_NOITALIC;
    static const std::string STRING_PENDINGPARAMLABEL_STYLE;
    static const std::string MACHINECONSTANTSVIEW_LOAD_FILE;
    static const std::string STRING_MACHINECONSTANTSVIEW_SHOWN;
    static const std::string STYLE_AWESOME_ICONCOLOR;
    static const std::string STYLE_ASML_ORANGELABEL;
    static const std::string STYLE_ACTIVE_CPDLABEL_BLACK;
    static const std::string STYLE_HOVERON;
    static const std::string STYLE_ASML_COLORORANGE;
    static const std::string STRING_CLOSE_BUTTON_COLOR_CLICKED;
    static const std::string PENDINGPARAMCANCEL_CLICKED;
    static const std::string PENDINGPARAMCANCEL_HOVERED;
    static const std::string PENDINGPARAMCANCEL_HOVERLEFT;
    static const std::string COLOR_GREY_DARK;
    static const std::string STYLE_DISABLE_LABEL;
    static const std::string STYLE_DISABLE_BACKGROUND;
    static const std::string STYLE_SEARCH_PARAMETERGREYBGITALIC;
    static const std::string STYLE_SEARCH_PARAMETERGREYBGNONITALIC;
    static const std::string MACHINECONSTANTSVIEWMODAL_LOAD_FILE;
    static const std::string NOT_APPLICABLE_STR;
    static const std::string FA_LINEEDIT_ERRORSTYLE;
    static const std::string FLOAT_ARRAY_UI_FILE_NAME;
    static const std::string STRING_PARAMETERS;
    static const std::string STRING_ALL_CATEGORIES;

    void onFloatArrayParameterValueChanged(const std::string &name, const std::string &value);
    std::pair<std::string, int> formatFloatArrayDialogParamName(const std::string &name);
    std::string getParameterStr(std::vector<ParameterData *> t_parameterData);
    void replaceText(std::string &str, std::string from, std::string to);
    IGSxGUI::ParameterData *getParameterDataForName(const std::string &name);
    std::string getFullParameterName(const std::string &name);
    void clearSelectionForAllParameterdata(std::vector<ParameterData *> parameterDataVec);

    std::vector<std::string> m_floatArrayNames;
    std::vector<std::string> m_floatArrayValues;
    std::vector<std::string> m_floatArrayDefValues;

    void clearLineEdit(int row);
    
    void configureFloatArrayTable();
    void configureFloatArrayScrollbar();    
    void showVaulesInEachRow(int index);
    void addWidgetsInEachRow(int rowNum);
    void onFloatArrayDialogScrollbarValueChanged();    
    void initFloatArrayDialog(std::string floatParamName);
    void loadFloatArrayDialog(std::string floatParamName);
    void doBasicFloatArrayLoad();
    void getObjectsFromUIXml();
    void onSearchTextTimeElapsed();
    void changeSearchTextStyleAndIcon();

    ParameterData* m_parameterData;
    SUI::Label *m_lblParameterName;
    SUI::ScrollBar *m_scbFloatArray;
    SUI::TableWidget *m_tawFloatArray;
    SUI::TableWidget *m_tawFloatArrayXButton;
    SUI::GroupBox *m_gbxResetValues;
    SUI::Button *m_btnPopUpdate;
    SUI::Button *m_btnPopCancel;
    SUI::Button *m_btnUpdate;
    SUI::Button *m_btnPopReset;
    SUI::Button *m_btnResetYes;
    SUI::Button *m_btnResetNo;
    SUI::Button *m_btnClose;
    SUI::Button *m_btnFormat;
    SUI::GroupBox *m_gbxCancelValuesConfirm;
    SUI::Button *m_btnCancelConfirmYes;
    SUI::Button *m_btnCancelConfirmNo;
    std::vector<int> m_FAmodifiedLineEdits;
    std::vector<int> m_floatArrayLineEditInvalidFieldsTillMinCount;
    std::vector<int> m_floatArrayLineEditInvalidFieldsAfterMinCount;
    
    boost::shared_ptr<SUI::Timer> m_SearchElapsedTime;
    
    void onFloatArrayParamValueTextEditFinished(SUI::LineEdit *le, int row);
    void onFloatArrayParamValueTextChanged(SUI::LineEdit * le, int row, const std::string &value);
    bool isFloatArrayLineEditValueValid(SUI::LineEdit *le);
    bool areAllFloatArrayWidgetsLoadedAfterCurrentRow(int currentRow);
    void eraseEnteredCharFromLineEdit(SUI::LineEdit *le, std::string &text, const int &pos);
    void showFloatArrayWarningForInvalidFields(SUI::LineEdit *le);
    bool checkforvalidEntryInFloatArrayTable(int row);
    void removeEntryFromInvalidEntryListTillMinCountForFloatArray(int row);
    void removeEntryFromInvalidEntryListAfterMinCountForFloatArray(int row);
    void addEntryToInvalidEntryListTillMinCountForFloatArray(int row);
    void addEntryToInvalidEntryListAfterMinCountForFloatArray(int row);
    void markEmptyFALineEditsInvalidFromCurrentRowTillMinCount(int currentRow);
    bool areAllFALineEditsEmptyAfterCurrentRow(int currentRow);
    void setDialogEnable(bool enable);
    void resizeDialog();
    void enableOrDisableFAUpdateButton();
    bool checkForUpdatedValuesFA();
    int  getLastFilledEntryFA();
    void onFAUpdatebuttonPressed();
    std::string getFAParameterName() const;
    std::string getFAParameterValue() const;
    void setFALineEditErrorStyle(int row);
    void setLineEditClearButtonVisibility(SUI::LineEdit *le, int row);
    void refreshFloatArrayDialogSelection();
    IGSxGUI::ParameterData *getParameterDataForFullName(const std::string &name);

    int m_previousScrollBarPosition;
    int m_currentScrollBarPosition;
    std::string m_currentRowParamName;
    // it returns number of visible rows in parameter table
    int numberOfRowsVisible(SUI::TableWidget *tablewidget);
    // it will return whether the parameter data/row is selected
    bool isParameterDataSelected(int row);
    // it will set the parameter data/row to selected or unselected state
    void setParameterDataSelected(int row, bool state);
    // in copy to clip board feature, it will select the rows when shift+click is used
    void selectShiftClickedRows(int row);
    // used to identify the gap in selection of parameter rows
    bool gapInSelection(int row);
    // refreshes the parameter table visible rows so the styles applied on them gets reflected
    void refreshParamTableVisibleRowsForStyleUpdate();
    // check to see if conversion from string to double is possible or not
    bool isConversionFromStringToDoublePossible(const std::string &value);
    // it will invalidates the current selected row, which means the current row is set to -1
    virtual void invalidateCurrentRow();

    int m_currentRow;
    bool m_shiftKeyPressed;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSVIEW_HPP
