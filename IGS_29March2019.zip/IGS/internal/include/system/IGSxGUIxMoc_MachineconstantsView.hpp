/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.hpp
| ! \brief       Header file for Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class MachineconstantsView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class Button;
class TableWidget;
class LineEdit;
class Label;
class ScrollBar;
class UserControl;
class GroupBox;
class TableWidget;
class TextArea;
class BusyIndicator;
class MachineconstantsView
{
 private:
    MachineconstantsView();

    void setupSUI(const char *XMLFileName);
    void setupSUIContainer(const char *XMLFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    Dialog *dialog;
    GroupBox *gbxPageOne;
    Button *btnParameterName;
    Button *btnParameterValue;
    Label *lblPendingParameters;
    Button *btnNoPendingParameters;
    Button *btnHistory;
    Button *btnPendingParameterName;
    Button *btnPendingParameterValue;
    Button *btnPendingParametersLine;
    TableWidget *tawParameters;
    LineEdit *lneSearchParameterText;
    Button *btnSearchAndClearIcon;
    Label *lblEntriesFound;
    Button *btnCancel;
    UserControl *uctSaveButton;
    Label *lblSaveImage;
    Label *lblSaveText;
    GroupBox *gbxSaveButton;
    ScrollBar *scbParametersTable;    
    TableWidget *tawMCPendingParam;
    Label *lblPendingParamSaveName;
    LineEdit *lnePendingParamSaveName;
    Label *lblPendingParamSaveChangeReason;
    TextArea *txaPendingParamSaveChangeReason;
    Button *btnPendingParamCancelSave;
    UserControl *uctPendingParamFinalSave;
    Label *lblPendingParamFinalSaveImage;
    Label *lblPendingParamFinalSaveText;
    GroupBox *gbxPendingParamFinalSaveButton;
    Label *lblPendingParamSaveChangeReasonTxtArea;
    Label *lblPendingParamSaveNameLnEdit;
    Button *btnPendingParamSaveNameLnEditCancel;
    TableWidget *tawParameterTree;
    Label *lblMachineConstantHeader;
    Label *lblAllCategories;
    Label *lblBackImage;
    Button *btnBack;

    Button *btnBC1;
    Button *btnBC2;
    Button *btnBC3;
    Button *btnBC4;
    Button *btnBC5;
    Button *btnBC6;

    Label *lblBackSlash1;
    Label *lblBackSlash2;
    Label *lblBackSlash3;
    Label *lblBackSlash4;
    Label *lblBackSlash5;

    GroupBox *gbxBI;
    GroupBox *gbxPendingParamSaveError;
    Label *lblPendingParamSaveErrorTitle;
    Label *lblPendingParamSaveErrorMessage;
    Label *lblPendingParamErrorCloseImage;
    Label *lblPendingParamErrorCrossImage;
    Button *btnCancelPendingParamSave;
    Button *btnRetryPendingParamSave;
    BusyIndicator *bicPendingParamFinalSave;

    Button *btnParameterName2;
    GroupBox *gbxParamName;
    Button *btnParameterNameDownArrow;
    Button *btnParameterNameUpArrow;
    GroupBox *gbxPendingParamName;
    Button *btnPendingParameterNameDownArrow;
    Button *btnPendingParameterNameUpArrow;
    Button *btnPendingParameterNameUpDownArrow;

    friend class ::IGSxGUI::MachineconstantsView;
};
}  // namespace SUI
#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
