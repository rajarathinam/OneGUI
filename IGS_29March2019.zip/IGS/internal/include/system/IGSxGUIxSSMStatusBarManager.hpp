/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerView.hpp
| Author       : Saket
| Description  : Header file for SSM Status bar manager
|
| ! \file        SSMStatusBarManager.hpp
| ! \brief       Header file for SSM STatus bar manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSSMSTATUSBARMANAGER_HPP
#define IGSXGUIXSSMSTATUSBARMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <IGSxGUIxSSMManager.hpp>
#include <FWQxUtils/SUITime.h>
#include <FWQxUtils/SUIDateTime.h>
#include <FWQxUtils/SUITimer.h>

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class GroupBox;
class Label;
}  // namespace SUI

namespace IGSxGUI{

class SSMStatusBarManager
{
   public:
    explicit SSMStatusBarManager(StateList& states);
    void show(TransitionData &activeTransition);
    void initWidgets(SUI::GroupBox *gbxCurrentState, SUI::GroupBox *gbxTransitionState, SUI::Label *lblCurrentStateText, SUI::Label *lblFromText, SUI::Label *lblToText, SUI::Label *lblStartTimeText, SUI::Label *lblExpectedDurationText, SUI::Label *lblElapsedTimeText);
    void startTimer();
    void setStartTime();
    ~SSMStatusBarManager();
private:
    void onTransitionTimeout();
    void updateExpectedDuration(const int expectedDuration);

    void computeTimeDifference  (boost::shared_ptr<SUI::Time> t1,
                                 boost::shared_ptr<SUI::Time> t2,
                                 boost::shared_ptr<SUI::Time> diffTime);
    std::string getStateText(const IGSxSSM::StateIDType &stateId) const;

    StateList& mStates;


    boost::shared_ptr<SUI::Timer> mTransitionTimer;
    boost::shared_ptr<SUI::Time> mTransitionStartTime;

    SUI::Label* mlblCurrentStateText;
    SUI::Label* mlblFromText;
    SUI::Label* mlblToText;
    SUI::Label* mlblStartTimeText;
    SUI::Label* mlblExpectedDurationText;
    SUI::Label* mlblElapsedTimeText;

    int mExpectedDurationSeconds;
    int mElapsedDurationSeconds;

    SUI::GroupBox* mGbxCurrentState;
    SUI::GroupBox* mGbxTransitionState;

    int m_currentTabIndex;
    std::string mElapsedTimeText;
};


} // IGSXGUIXSSMSTATUSBARMANAGER_HPP

#endif
