/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMachineconstantsManager.hpp
| Author       : Raja
| Description  : Header file for Machineconstants Manager
|
| ! \file        IGSxGUIxMachineconstantsManager.hpp
| ! \brief       Header file for Machinecontants Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMACHINECONSTANTSMANAGER_HPP
#define IGSXGUIXMACHINECONSTANTSMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <map>
#include <boost/shared_ptr.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef std::vector<std::string> StringVectorType;

// forwards references
namespace IGSxPAR { class ParameterChangeHistory; }

namespace IGSxGUI {

enum ITEMTYPE
{
    TYPE_int,
    TYPE_uint,
    TYPE_boolean,
    TYPE_double,
    TYPE_floatarray
};



class ParameterValue
{
public:
    virtual ~ParameterValue();
    virtual void FromString(std::string strValue) = 0;
    virtual std::string ToString() = 0;
    virtual ParameterValue* CreateCopy() = 0;

    virtual int ToInt() { return 0; }
    virtual unsigned int ToUint() { return 0; }
    virtual bool ToBool() { return false; }
    virtual double ToDouble() { return 0.0; }
    virtual std::vector<double> ToFloatarray() { return std::vector<double>(); }
    virtual int getItemCount() { return 1; }
};

typedef boost::shared_ptr<IGSxGUI::ParameterValue> ParameterValuePtr;

class ParameterData
{
private:
    std::string m_name;
    std::string m_unit;

    ParameterValuePtr m_defaultValue;
    ParameterValuePtr m_currentValue;
    ParameterValuePtr m_previousValue;
    ParameterValuePtr m_minValue;
    ParameterValuePtr m_maxValue;

    ITEMTYPE m_itemType;

    bool m_updated;
    bool m_selected;
    bool m_readOnly;
    bool m_failed;

    std::vector<int> m_componentIndexes;
    std::vector<std::string> m_labels;
    int m_minValueCount;
    int m_maxValueCount;

public:
    static int treeLevel;

public:
    ParameterData(const std::string& name, const std::string& unit, ParameterValuePtr currentValue, ParameterValuePtr defaultValue,
                  ParameterValuePtr minValue, ParameterValuePtr maxValue, bool readOnly, ITEMTYPE type);
    ParameterData(const std::string& name, const std::string& unit, ParameterValuePtr currentValue, ParameterValuePtr defaultValue,
                  ParameterValuePtr minValue, ParameterValuePtr maxValue, bool readOnly, ITEMTYPE type,
                  const std::vector<std::string>& labels, int minValueCount, int maxValueCount);

    const std::string& getName() const;
    const std::string& getUnit() const;
    bool hasUnit() const;
    std::string getDisplayName() const;
    std::string getComponent(int index) const;
    int getComponentCount() const;
    bool isReadOnly() const;

    ParameterValuePtr getCurrentValue() const;
    ParameterValuePtr getPreviousValue() const;
    ParameterValuePtr getDefaultValue() const;
    ParameterValuePtr getMinValue() const;
    ParameterValuePtr getMaxValue() const;
    const std::vector<std::string>& getLabels() const;
    int getMinValueCount() const;
    int getMaxValueCount() const;
    int getActualValueCount() const;
    bool isUpdated() const;
    bool isSelected() const;
    bool isFailed() const;

    void setSelected(bool flag);
    void setFailed(bool result);
    void changeValue(std::string newValue);
    void receiveChangeValue(std::string newValue);
    void revertValue();
    void resetPreviousValue();
    ParameterData* getPtr();
    IGSxGUI::ITEMTYPE getValueType();
    void resetUpdateFlag();
    bool deviatesFromDefault() const;

private:
    void ComputeComponentIndexes();
};

struct find_parameter {
    explicit find_parameter(const std::string& text):m_text(text)
    {
    }

    bool operator()(const ParameterData& data)
    {
        return ( data.getName() == m_text);
    }

    std::string m_text;
};

struct ascOrder {
    bool operator() (ParameterData* data1, ParameterData* data2) {
        return data1->getName().compare(data2->getName()) <= 0;
    }
};

struct desOrder {
    bool operator() (ParameterData* data1, ParameterData* data2) {
        return data1->getName().compare(data2->getName()) > 0;
    }
};

class Node {

public:
    Node(std::string name, int level, Node* parentNode);
    ~Node();

    const std::string getName() const;
    Node* getParentNode();
    Node* findChildNode(const std::string& name);
    Node* addChildNode(const std::string& name);
    void addParameter(IGSxGUI::ParameterData* parameter);
    std::vector<IGSxGUI::ParameterData*>& getParameters();
    void getChildNodeTitles(std::vector<std::string>* targetList );
    void sortasc();
    void sortdes();

private:
    std::string m_name;
    int m_level;
    Node* m_parentNode;
    std::map<std::string, Node*> m_childNodes;
    std::vector<IGSxGUI::ParameterData*> m_parameters;
};

typedef boost::function<void ()> ParametersChangedCallback;
typedef boost::function<void (StringVectorType failedParameterNames)> WriteFinishedCallback;
typedef boost::function<void (bool)> ParamsSaveEnablityChangedCallback;

class ParameterHistory
{
public:
    explicit ParameterHistory(
            const std::string& parameter_name,
            time_t             time_of_change,
            const std::string& changed_by,
            const std::string& reason,
            const std::string& old_value,
            const std::string& new_value,
            const bool selected,
            const bool SearchString,
            const bool parameterInList) :
        m_parameter_name(parameter_name),
        m_time_of_change(time_of_change),
        m_changed_by(changed_by),
        m_reason(reason),
        m_old_value(old_value),
        m_new_value(new_value),
        m_selected(selected),
        bSetSearchString(SearchString),
        m_isParamterInList(parameterInList) {
          if (bSetSearchString) {
             setSearchString();
          }
        }

    virtual ~ParameterHistory(){}

    void setState(bool state)
    {
            m_selected = state;
    }

    const std::string& parameter_name() const{ return m_parameter_name;}
    time_t             time_of_change() const{ return m_time_of_change;}
    const std::string& changed_by()     const{ return m_changed_by;}
    const std::string& reason()         const{ return m_reason;}
    const std::string& old_value()      const{ return m_old_value;}
    const std::string& new_value()      const{ return m_new_value;}
    const std::vector<std::string>& getSearchString() const{ return m_search_entries;}
    bool isSelected()                   const{ return m_selected;}
    bool isParamterInList()             const{ return m_isParamterInList;}
    void setSearchString();
    const std::string& formattedTimeOfChange();

private:
    std::string m_parameter_name;
    time_t      m_time_of_change;
    std::string m_changed_by;
    std::string m_reason;
    std::string m_old_value;
    std::string m_new_value;
    std::string m_formattedTimeOfChange;
    std::vector<std::string> m_search_entries;
    bool m_selected;
    bool bSetSearchString;
    bool m_isParamterInList;
};
typedef std::vector<ParameterHistory> ParameterHistoryVector;

class MachineconstantsManager
{
public:
    MachineconstantsManager();
    virtual ~MachineconstantsManager();

    void initialize();
    int getParameterCount();
    ParameterData* findParameter(const std::string& name);
    std::vector<ParameterData*> getParameterData();
    std::vector<ParameterData*> getAllParameterData();
    int searchForParameters(const std::string &textToSearch, std::vector<ParameterData*>*  matchedparameters);
    void saveUpdatedParameters(const std::string& userId, const std::string& reason);
    void updateSavedParameters(const StringVectorType& failedParameters);
    void cancelUpdatedParameters();

    void subscribeToParameterUpdated();
    void unSubscribeToParameterUpdated();
    void unSubscribeToWriteFinished();
    void subscribeToWriteFinished();

    void getChildNodeTitles(std::vector<std::string>* targetList);
    void navigateToChild(const std::string& childNodeTitle);
    void navigateBack();
    void navigateToBreadCrum(const std::string& breadCrumTitle);
    const std::vector<std::string>& getBreadCrumTitles();
    std::string getCurrentNodeName();
    void getHistory(ParameterHistoryVector& history);


    static void registerToParameterUpdated(IGSxGUI::ParametersChangedCallback cb);
    static void registerToWriteFinished(IGSxGUI::WriteFinishedCallback cb);

    static ParametersChangedCallback m_callback;
    static WriteFinishedCallback m_callbackWriteFinished;
    void sortParamsAscending();
    void sortParamsDescending();

    void truncateDoubleExtraDigits(std::string &oldValue);
    bool isParamSavingEnabled();
    void setParametersSavingEnable(bool enable);
    static void registerToParamsSaveEnablityChanged(IGSxGUI::ParamsSaveEnablityChangedCallback cb);
    static ParamsSaveEnablityChangedCallback m_paramsSaveEnablityChanged;
private:
    MachineconstantsManager(MachineconstantsManager const &);
    MachineconstantsManager& operator=(MachineconstantsManager const &);

    void createTableData();
    void fillInitialHistory();
    void registerNodes(ParameterData* parameter);
    std::string createFullParameterName(IGSxPAR::ParameterChangeHistory& temp);

    // data
    std::vector<ParameterData>      m_tabledata;
    StringVectorType                SavedParametertabledata;
    time_t                          m_lastHistoryUpdateTime;
    std::vector<ParameterHistory>   m_history;

    // bread crum path
    Node*                           m_rootNode;
    Node*                           m_currentNode;
    std::vector<std::string>        m_breadCrumPath;

    // constants
    static const int TOTAL_PARAMETERS_COUNT;
    static const int PARAMETER_DEFAULT_VALUE;
    static const int PARAMETER_CURRENT_VALUE;
    bool m_paramSavingEnabled;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMACHINECONSTANTSMANAGER_HPP
