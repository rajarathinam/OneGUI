/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManager.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver manager
|
| ! \file        IGSxGUIxDriverManager.hpp
| ! \brief       Header file for Driver manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVERMANAGER_HPP
#define IGSXGUIXDRIVERMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxSystemFunction.hpp"
#include "IGSxGUIxSystemState.hpp"
#include "IGSxITS.hpp"

using std::vector;
using IGSxITS::DriverStatus;
using IGSxITS::InitTerminate;
using IGSxITS::MetaDescriptions;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class DriverManager
{
 public:
    DriverManager();
    virtual ~DriverManager();

    void addSystemFunctions(const IGSxITS::MetaDescriptions &metaDescription);
    SystemFunction* getSystemFunction(const std::string& name) const;
    std::vector<SystemFunction*> getSystemFunctions() const;
    Driver* getDriver(const std::string &name) const;
    SystemState::SystemStateEnum getSystemState() const;

    void registerToSystemStateChanged(const SystemStateChangedCallback& cb);
    void unregisterToSystemStateChanged(const SystemStateChangedCallback& cb);

    typedef boost::signals2::signal<void ()> initializeCompleted;
    typedef initializeCompleted::slot_type initializeCompletedCallback;

    typedef boost::signals2::signal<void ()> terminateCompleted;
    typedef terminateCompleted::slot_type terminateCompletedCallback;

    void registerToInitializeCompleted(const initializeCompletedCallback& cb);
    void unregisterToInitializeCompleted(const initializeCompletedCallback& cb);

    void registerToTerminateCompleted(const terminateCompletedCallback& cb);
    void unregisterToTerminateCompleted(const terminateCompletedCallback& cb);

    void setSystemState(const SystemState::SystemStateEnum& state);
    void setMainSystemState(const SystemState::SystemStateEnum& state);
    void initialize();

    void initializeSystem();
    void terminateSystem();

    std::string getDriverState();
 private:
    SystemState::SystemStateEnum determineSystemState(bool bSetState = false);
    void onInitializeComplete(const IGS::Result& result);
    void onTerminateComplete(const IGS::Result& result);
    void onDriverStatusChanged(const std::string& driverName, const DriverStatus& status) const;
    vector<SystemFunction*> m_systemFunctions;
    systemStateChanged m_systemStateChanged;
    initializeCompleted m_initializeCompleted;
    terminateCompleted m_terminateCompleted;
    SystemState::SystemStateEnum m_systemState;
    static const std::string ERROR_ADDING_SYSFUN;
    static const char* STRING_NEW_SYSTEM_STATE;
    bool m_Initializing;
    bool m_Terminating;
    DriverMode::DriverModeEnum m_driverState;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDRIVERMANAGER_HPP
