/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemStateManagerView.hpp
| Author       : Saket
| Description  : Header file for System state manager View
|
| ! \file        IGSxGUIxSystemStateManagerView.hpp
| ! \brief       Header file for Parameterpopup View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSSMSTATE_HPP
#define IGSXGUIXSSMSTATE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/function.hpp>
#include <vector>
#include <FWQxCore/SUIRect.h>
#include <boost/signals2.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class UserControl;
class Button;
class BusyIndicator;
class Label;
}  // namespace SUI

namespace IGSxGUI{

enum InnerState{REACHABLE=0, ACTIVE, TRANSITION_START, TRANSITION_END,  DISABLED};

class State
{
public:
    State(SUI::UserControl* control, SUI::Button* button, SUI::BusyIndicator* bic, SUI::Label* lbl, InnerState innerState, const int id, const bool abortable,  const int index);
    SUI::UserControl* getUserControl();
    void show();
    void hide();
    void setInnerState(InnerState innerState);
    InnerState getInnerState() const;
    void initButton(IGSxGUI::InnerState innerState);
    typedef boost::signals2::signal<void (InnerState, int, int)> clickedSignal;
    typedef clickedSignal::slot_type clickedSignalCallback;
    void registerToclicked(const clickedSignalCallback& cb);

    int getId() const;
    void setStateName(const std::string &stateName);
    std::string getStateName() const;
    void setAbortable(bool abortable);
    bool getAbortable() const;
    void setState(InnerState innerState);

private:
    clickedSignal clicked;
    void buttonClicked();
    SUI::UserControl* mUsercontrol;
    SUI::Button* mButton;
    SUI::BusyIndicator* mBusyIndicator;
    SUI::Label* mOverlayLabel;
    InnerState mCurrentState;
    int mId;
    bool mAbortable;
    int mIndex;
    std::string mName;
    static const SUI::Rect NON_TRANSITION_STATE_RECT ;
    static const SUI::Rect TRANSITION_STATE_RECT;
};

typedef std::vector<IGSxGUI::State*> StateList;

} // IGSXGUIXSSMSTATE_HPP

#endif
