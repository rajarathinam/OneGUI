/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSSMManager.hpp
| Author       : Saket K
| Description  : Header file for SSM Manager
|
| ! \file        IGSxGUIxSSMManager.hpp
| ! \brief       Header file for SSM Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSSMMANAGER_HPP
#define IGSXGUIXSSMMANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <map>
#include <set>
#include <string>
#include <vector>
#include "IGSxSSM.hpp"
#include <boost/array.hpp>
#include <boost/signals2.hpp>
#include <IGSxGUIxSSMState.hpp>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {

typedef boost::array< std::string, IGSxSSM::STATE_NR_OF_LINES> StateDescriptionType;
typedef std::vector<IGSxSSM::StateConfigList> StatesList;
typedef std::vector<IGSxSSM::GroupConfigList> GroupsList;
typedef std::set<IGSxSSM::StateIDType> StateIds;
typedef boost::signals2::signal<void (std::string)> ssmStateChanged;
typedef ssmStateChanged::slot_type ssmStateChangedCallback;

struct TransitionData
{
    TransitionData() : FunctionResult(IGSxSSM::FUNCTION_OK), From(0), To(0), TransitionResult(IGSxSSM::TRANSITION_OK), ExpectedDuration(0){}
    IGSxSSM::FunctionResultType FunctionResult;
    IGSxSSM::StateIDType From;
    IGSxSSM::StateIDType To;
    IGSxSSM::ReachableStateList ReachableStates;
    IGSxSSM::TransitionResultType TransitionResult;
    unsigned int ExpectedDuration;
};

class SSMManager
{
 public:
    SSMManager();
    virtual ~SSMManager();
    void initialize();
    int getFunctionCount() const;
    std::string getFunctionName(const int functionIndex) const;
    std::string getGroupName(const int functionIndex, const int groupIndex) const;
    int getGroupCount(const int functionIndex) const;
    StateDescriptionType getStateDescription(const int functionIndex, const int groupIndex, const int stateIndex) const;
    StateDescriptionType getStateDescriptionById(const int functionIndex, const IGSxSSM::StateIDType& stateIdType) const;

    int getStateId(const int functionIndex, const int groupIndex, const int stateIndex) const;
    int getStatesCount(const int functionIndex, const int groupIndex) const;
    TransitionData getActiveTransitionData(const int functionIndex) const;
    void getActiveTransition(const int functionIndex) const;
    bool isTransitionAbortable(const int functionIndex,const int stateId) const;
    void setTransition(const int functionIndex, const int newStateId);
    IGSxGUI::InnerState getInnerState(const int functionIndex, const int stateId) const;
    bool allowStateManagement();

    typedef boost::signals2::signal<void()> controlSignal;
    typedef controlSignal::slot_type controlSignalCallback;
    void registerToUpdateTabIcon(const controlSignalCallback& cb);

    typedef boost::signals2::signal<void(int)> signalUpdate;
    typedef signalUpdate::slot_type signalUpdateCallback;
    void registerToUpdate(const signalUpdateCallback& cb);


    typedef boost::signals2::signal<void(int)> signalStartTransition;
    typedef signalStartTransition::slot_type signalStartTransitionCallback;
    void registerToStartTransition(const signalStartTransitionCallback& cb);

    void callbackUpdate(int functionIndex);
    void callbackUpdateTabIcon();
    typedef boost::signals2::signal<void(bool)> enableButtonSignal;
    typedef enableButtonSignal::slot_type enableButtonSignalCallback;
    void registerInitForEnable(const enableButtonSignalCallback& cb);

    bool isFunctionResultOk(const int functionIndex) const;
    bool isTransitionActive(const int functionIndex) const;
    void registerToSSMStateChanged(const ssmStateChangedCallback &cb);
    void unregisterToSSMStateChanged(const ssmStateChangedCallback &cb);
    std::string getActiveStateName();
private:
    void onGetStateResultFunction(const IGSxSSM::FunctionResultType& result, const IGSxSSM::StateIDType& from, const IGSxSSM::StateIDType& to, const IGSxSSM::ReachableStateList& reachable_states, const int functionIndex);
    void onSetStateResultFunction(const IGSxSSM::FunctionResultType& result, const int functionIndex);
    void onSetStateUpdatedFunction(const int);
    void onSetTransitionStartedFunction(const IGSxSSM::StateIDType& from,const IGSxSSM::StateIDType& to, const unsigned int duration, const int functionIndex);
    void onSetTransitionCompletedFunction(const IGSxSSM::StateIDType& from,const IGSxSSM::StateIDType& to , const IGSxSSM::TransitionResultType& result, const IGSxSSM::ReachableStateList& reachable_states, const int functionIndex);
    bool isStateReachable(int functionIndex, int stateId) const;

    SSMManager(SSMManager const &);
    SSMManager& operator=(SSMManager const &);
    IGSxSSM::SSMPtr m_Instance;
    IGSxSSM::SystemFunctionPtrList m_Functions;
    GroupsList m_Groups;
    std::vector<StatesList> m_States;
    std::vector<TransitionData> m_Transitions;

    signalUpdate m_Update;
    controlSignal m_UpdateTabIcon;
    enableButtonSignal m_enableInitButton;
    signalStartTransition m_StartTransition;

    int m_TransitionCount;
    ssmStateChanged m_ssmStateChanged;
    std::string m_activeSystemStateName;
    static const std::string SSM_STATE_TRANSITIONING;
    static const std::string SSM_STATE_UNKNOWN;
    static const std::string SSM_STATE_SERVICE;
};

}  // namespace IGSxGUI
#endif  // IGSXGUIXSSMMANAGER_HPP
