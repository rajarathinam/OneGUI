#ifndef IGSXGUIXMOC_HISTORYPOPUPVIEW_HPP
#define IGSXGUIXMOC_HISTORYPOPUPVIEW_HPP
/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_HistorypopupView.hpp
| Author       : Venu
| Description  : Header file for Moc Historypopup view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.hpp
| ! \brief       Header file for Moc Historyrpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2018, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

//----------------------------------------------------------------------------|
//                          Forward Declarations                              |
//----------------------------------------------------------------------------|
namespace IGSxGUI {
        class HistorypopupView;
} //namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class LineEdit;
class UserControl;
class Button;
class Label;
class TableWidget;
class ScrollBar;
class GroupBox;
class HistorypopupView
{
private:
        HistorypopupView();

    void setupSUI(const char *xmlFileName);
    void setupSUIContainer(const char *xmlFileName, SUI::Container *container);
    void loadObjects(SUI::ObjectList *objectList);

    SUI::Dialog *dialog;
    UserControl *uctCloseHistory;
    Label *lblCloseImage;
    Label  *lblHistory;
    LineEdit *lneSearchParameterText;
    Button *btnSearchAndClearIcon;
    Label *lblHistoryEntriesFound;
    UserControl *uctParameterName;
    GroupBox *gbxParameterName;
    Label *lblParameterNameHistoryHeaderButtonText;
    Label *lblParameterNameHistoryHeaderButtonImage;

    UserControl *uctChangedOn;
    GroupBox *gbxChangedOn;
    Label *lblChangedOnHistoryHeaderButtonText;
    Label *lblChangedOnHistoryHeaderButtonImage;

    UserControl *uctChangedBy;
    GroupBox *gbxChangedBy;
    Label *lblChangedByHistoryHeaderButtonText;
    Label *lblChangedByHistoryHeaderButtonImage;

    Button *btnParameterOldValue;
    Button *btnParameterNewValue;


    UserControl *uctReason;
    GroupBox *gbxReason;
    Label *lblReasonHistoryHeaderButtonText;
    Label *lblReasonHistoryHeaderButtonImage;

    TableWidget *tawParametersHistory;
    ScrollBar *scbHistoryTable;

    static const int MAX_VISIBLE_ROWS;


    friend class ::IGSxGUI::HistorypopupView;
};
} //namespace SUI


#endif // IGSXGUIXMOC_HISTORYPOPUPVIEW_HPP
