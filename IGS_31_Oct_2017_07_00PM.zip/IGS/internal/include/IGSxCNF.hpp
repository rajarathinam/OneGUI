/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCNF.hpp
| Author       : Thijs Jacobs
| Description  : Interface to retrieve configuration settings
|
| ! \file        IGSxCNF.hpp
| ! \brief       Interface to retrieve configuration settings
| ! \details     
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXCNF_HPP
#define IGSXCNF_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>


namespace IGSxCNF {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class Configuration
{
// functions throw IGS::exception
public:
    static Configuration* getInstance() {return instance;}

    virtual std::string getMachineId() = 0; // e.g. 62175
    virtual std::string getReleaseId() = 0; // e.g. 3.2.6 RC8800
    
protected:
    // instance
    virtual ~Configuration() {}
    static Configuration* instance;
};

} // namespace IGSxCNF

#endif // IGSXCNF_HPP

