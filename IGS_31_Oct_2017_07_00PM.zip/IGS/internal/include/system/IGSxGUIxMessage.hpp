/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMessage.hpp
| Author       : Venugopal S
| Description  : Defining the signal and slots of message being passed to
                 mainview
|
| ! \file        IGSxGUIxMessage.hpp
| ! \brief       Defining the signal and slots of message being passed to
                 mainview
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMESSAGE_HPP
#define IGSXGUIXMESSAGE_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
typedef boost::signals2::signal<void (std::string)> messageDisplay;
typedef messageDisplay::slot_type messageDisplayCallback;
}  // namespace IGSxGUI
#endif
