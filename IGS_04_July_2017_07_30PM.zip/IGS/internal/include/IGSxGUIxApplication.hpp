/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxApplication.hpp
| Author       : Raja A
| Description  : Header file for Application class
|
| ! \file        IGSxGUIxApplication.hpp
| ! \brief       Header file for Application class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXAPPLICATION_H
#define IGSXGUIXAPPLICATION_H
#include <string>

class IGSxGUIxApplication
{
 public:
    IGSxGUIxApplication(int argc, char *argv[], const std::string& resourcePath);
    int exec();
    void initialize();

 private:
    std::string m_resourcePath;
    int m_argc;
    char** m_argv;
    static const std::string  STRING_SIMULATION;
};

#endif  // IGSXGUIXAPPLICATION_H
