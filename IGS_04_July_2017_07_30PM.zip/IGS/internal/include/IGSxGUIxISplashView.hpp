/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxISplashView.hpp
| Author       : Raja A
| Description  : Interface file for Splashscreen view
|
| ! \file        IGSxGUIxISplashView.hpp
| ! \brief       Interface file for Splashscreen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISPLASHVIEW_HPP
#define IGSXGUIXISPLASHVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxMainView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ISplashView
{
 public:
    ISplashView() {}
    virtual ~ISplashView() {}
    virtual void show(IMainView*) = 0;
    virtual void showMessage(const std::string& text) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXISPLASHVIEW_HPP
