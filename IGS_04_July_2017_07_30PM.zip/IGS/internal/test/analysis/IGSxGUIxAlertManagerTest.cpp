/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertManagerTest.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert Manager test
|
| ! \file        IGSxGUIxAlertManagerTest.cpp
| ! \brief       Implementation of Alert Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxAlertManagerTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(AlertManagerTest, Test1)
{
  ASSERT_TRUE(m_AlertManager != NULL);

  std::vector<IGSxGUI::Alert*> AlertList = m_AlertManager->getActiveAlerts();
  EXPECT_EQ(0, AlertList.size());

  IGSxGUI::Alert* alert = m_AlertManager->getAlert(11);
  EXPECT_EQ(NULL, alert);

  // COULD NOT COVER OTHER CASES AS THEY ARE EVENT BASED AND STUB TO BE STUBBED
}
