#ifndef MYWIDGET_H
#define MYWIDGET_H

#include <QWidget>
#include <QProgressBar>
#include <QGridLayout>
#include <QLabel>

class MyWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MyWidget(QWidget *parent = 0);

signals:

public slots:
    void handleDashboard();
    void handleSystem();
    void handleAnalysis();
private:
    QGridLayout *layout;
    QProgressBar *progressbar;
    QLabel *label;

};

#endif // MYWIDGET_H
