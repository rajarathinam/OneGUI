/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include<boost/shared_ptr.hpp>
#include <string>
#include "IGSxGUIxApplication.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string STRING_RESOURCE = "/Resource/";

int main(int argc, char *argv[])
{
    int result = 1;
    // instantiate the application
    boost::shared_ptr<IGSxGUIxApplication> app(new IGSxGUIxApplication(argc, argv, get_current_dir_name() + STRING_RESOURCE));
    result = app->exec();
    return result;
}

