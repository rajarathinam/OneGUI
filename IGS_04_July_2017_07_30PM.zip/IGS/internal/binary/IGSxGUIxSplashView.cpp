/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashView.cpp
| Author       : Raja A
| Description  : Implementation of Splash screen view
|
| ! \file        IGSxGUIxSplashView.cpp
| ! \brief       Implementation of Splash screen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashView.hpp"
#include "IGSxGUIxMoc_SplashView.hpp"
#include "IGSxGUIxUtil.hpp"
#include <SUIDialog.h>
#include <SUIProgressBar.h>
#include <SUIGraphicsView.h>
#include <SUILabel.h>
#include "IGSxGUIxPluginFactory.hpp"
#include <QThread>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SplashView::SPLASHVIEW_LOAD_FILE = "IGSxGUIxSplashView.xml";


IGSxGUI::SplashView::SplashView():
    sui(new SUI::SplashView)
{
    if (sui != NULL)
    {
        sui->setupSUI(SPLASHVIEW_LOAD_FILE.c_str());
    }

    m_presenter = new IGSxGUI::SplashPresenter(this);

    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::setAwesome(sui->lblCopyrightImage, IGSxGUI::AwesomeIcon::AI_fa_copyright, SUI::ColorEnum::Gray);
    IGSxGUI::PluginFactory::getInstance().subscribeToInitStatusChanged(boost::bind(&IGSxGUI::SplashView::onInitStatusChanged, this, _1));
    sui->lblCopyright->setVisible(false);
    sui->lblCopyrightImage->setVisible(false);
    sui->lblCopyrightText->setVisible(false);
}
IGSxGUI::SplashView::~SplashView()
{
    IGSxGUI::PluginFactory::getInstance().unsubscribeToInitStatusChanged();

    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::SplashView::show(IMainView *mainView)
{
    sui->dialog->show();
    std::cout << "SplashView::show() " << QThread::currentThread() << std::endl;
    sui->lblMachineId->setText(m_presenter->getMachineId());
    sui->lblVersion->setText(m_presenter->getReleaseId());
    m_mainView = mainView;
}

void IGSxGUI::SplashView::showMessage(const std::string &text)
{
    sui->lblCurrentAct->setText(text);
}

#include <iostream>
void IGSxGUI::SplashView::onInitStatusChanged(const std::string &initStatus)
{
    std::cout << initStatus << std::endl;
   sui->lblCurrentAct->setText(initStatus);

    if ( initStatus == "Completed Initialization")
    {
       sui->dialog->hide();
        m_mainView->show();
    }

}

void IGSxGUI::SplashView::handleDashboard()
{
  sui->lblCurrentAct->setText("Loading dashboard...");
}

void IGSxGUI::SplashView::handleSystem()
{
sui->lblCurrentAct->setText("Loading System...");
}

void IGSxGUI::SplashView::handleAnalysis()
{
sui->lblCurrentAct->setText("Loading Analysis...");
}
