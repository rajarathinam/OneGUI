/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPluginFactory.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Plugin Factory
|
| ! \file        IGSxGUIxPluginFactory.cpp
| ! \brief       Implementation of Plugin Factory
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxDashboard.hpp"
#include <SUITimer.h>
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxUtil.hpp"
#include <QThread>

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/


IGSxGUI::PluginFactory::PluginFactory():
    m_systemPlugin(NULL),
    m_analysisPlugin(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_dashboardPlugin(NULL),
    m_value(0)
{
   // m_timer->timeout = boost::bind(&PluginFactory::onTimeout, this);
    m_timer->setSingleShot(true);
}

IGSxGUI::PluginFactory::~PluginFactory()
{
    if (m_systemPlugin != NULL)
    {
        delete m_systemPlugin;
        m_systemPlugin = NULL;
    }
    if (m_analysisPlugin != NULL)
    {
        delete m_analysisPlugin;
        m_analysisPlugin = NULL;
    }
    if (m_dashboardPlugin != NULL)
    {
        delete m_dashboardPlugin;
        m_dashboardPlugin = NULL;
    }
}

void IGSxGUI::PluginFactory::onTimeout()
{
    initialize();
}
#include <QCoreApplication>
#include <QApplication>
#include <QTime>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/



void IGSxGUI::PluginFactory::initialize()
{
    /*
    m_value++;
    if (m_initStatusCb)
    {
        if(m_value == 1)
        m_initStatusCb("Loading data1...");
    }
    if (m_initStatusCb)
    {
        if(m_value == 2)
        m_initStatusCb("Loading data2...");
    }
    if (m_initStatusCb)
    {
        if(m_value == 3)
        m_initStatusCb("Loading data3...");
    }
    if (m_initStatusCb)
    {
        if(m_value == 4)
        m_initStatusCb("Loading data4...");
    }
    if (m_initStatusCb)
    {
         if(m_value == 5)

        m_initStatusCb("Completed Initialization");
    }
    */

    /*
std::cout << "Initialize() " << QThread::currentThread() << std::endl;
  if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA1...");
    }

    getDashboardPlugin()->initialize();

   if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA2...");
    }

   // getSystemPlugin();
    if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA3...");
    }

    getAnalysisPlugin();

     if (m_initStatusCb)
    {
        m_initStatusCb("Finalizing Initialization");
        m_initStatusCb("Completed Initialization");
     }

*/


}

IGSxGUI::ISystem* IGSxGUI::PluginFactory::getSystemPlugin()
{
    sleep(5);
    if (m_systemPlugin == NULL)
    {
        m_systemPlugin = new IGSxGUI::System();
    }
    return m_systemPlugin;
}

IGSxGUI::IAnalysis* IGSxGUI::PluginFactory::getAnalysisPlugin()
{
    if (m_analysisPlugin == NULL)
    {
        m_analysisPlugin = new IGSxGUI::Analysis();
    }
    return m_analysisPlugin;
}

IGSxGUI::IDashboard* IGSxGUI::PluginFactory::getDashboardPlugin()
{
    sleep(5);
    if (m_dashboardPlugin == NULL)
    {
        m_dashboardPlugin = new IGSxGUI::Dashboard();
    }
    return m_dashboardPlugin;
}

void IGSxGUI::PluginFactory::subscribeToInitStatusChanged(const InitStatusCallback &cb)
{
    m_initStatusCb = cb;
    m_timer->start(1000);
}

void IGSxGUI::PluginFactory::unsubscribeToInitStatusChanged()
{
    if (m_initStatusCb)
    {
        m_initStatusCb = NULL;
    }
}

