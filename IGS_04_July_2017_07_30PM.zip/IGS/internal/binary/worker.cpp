#include "worker.h"
#include "IGSxGUIxPluginFactory.hpp"
#include <QThread>

Worker::Worker(QObject *parent) :
    QObject(parent)
{
}
void Worker::doWork()
{
   std::cout << "doWork() " << QThread::currentThread() << std::endl;
   /*
     * if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA1...");
    }
    delay();
    getDashboardPlugin()->initialize();
    if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA2...");
    }
    delay();
    getSystemPlugin();
    if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA3...");
    }

    getAnalysisPlugin();
     if (m_initStatusCb)
    {
        m_initStatusCb("Finalizing Initialization");
        m_initStatusCb("Completed Initialization");
     }
     */

    emit updateSystem();
    sleep(5);
    IGSxGUI::PluginFactory::getInstance().initialize();
    emit updateDashboard();
    sleep(5);
    IGSxGUI::PluginFactory::getInstance().initialize();
    emit updateAnalysis();
    sleep(5);
    IGSxGUI::PluginFactory::getInstance().initialize();


}
