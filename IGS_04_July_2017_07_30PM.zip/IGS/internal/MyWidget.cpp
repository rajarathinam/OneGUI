#include "MyWidget.h"

MyWidget::MyWidget(QWidget *parent) :
    QWidget(parent)
{
    progressbar = new QProgressBar;
    layout = new QGridLayout;
    label = new QLabel;
    label->setText("Raja.................");
    progressbar->setMaximum(0);
    progressbar->setMinimum(0);
    layout->addWidget(label,0,0);
    layout->addWidget(progressbar,1,0);
    setLayout(layout);

}
void MyWidget::handleDashboard()
{
  label->setText("Loading dashboard...");
}

void MyWidget::handleSystem()
{
label->setText("Loading System...");
}

void MyWidget::handleAnalysis()
{
label->setText("Loading Analysis...");
}
