/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManager.hpp
| Author       : Venugopal S
| Description  : Header file for ADT Manager
|
| ! \file        IGSxGUIxADTManager.hpp
| ! \brief       Header file for ADT Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXADT_MANAGER_HPP
#define IGSXADT_MANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ADTManager
{
 public:
    ADTManager();
    virtual ~ADTManager();

    void initialize();
    void add(ADT *adt);
    void remove(ADT *adt);
    ADT* getADT(const std::string& name) const;
    std::vector<ADT*> retrieveAll();

 private:
    ADTManager(ADTManager const &);
    ADTManager& operator=(ADTManager const &);

    std::vector<ADT*> m_ADTs;
};

}  // namespace IGSxGUI
#endif  // IGSXADT_MANAGER_HPP
