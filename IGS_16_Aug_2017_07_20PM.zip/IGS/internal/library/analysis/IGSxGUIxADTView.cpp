/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxADTView.cpp
| ! \brief       Implementation of ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <algorithm>
#include <string>
#include <list>
#include <vector>
#include "IGSxGUIxADTView.hpp"
#include "IGSxGUIxMoc_ADTView.hpp"
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUIDropDown.h>
#include <SUIWebView.h>
#include <SUIResourcePath.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::ADTView::ADTVIEW_LOAD_FILE = "IGSxGUIxADT.xml";
const std::string IGSxGUI::ADTView::IMAGE_CLOCK = "IGSxGUIxSystem_clock.png";

const std::string IGSxGUI::ADTView::STRING_EMPTY = "";
const std::string IGSxGUI::ADTView::STRING_ALL_ADTS = "All ADTs";
const std::string IGSxGUI::ADTView::STRING_NO_ACTIVE_ADT = "There is no active ADT";
const std::string IGSxGUI::ADTView::STRING_ADT_HPAC = "Monitor status of the HPAC driver and inititlize terminate it.\nMonitor status of Power amplifiers (from PA0 to PA3) and enable disable High Voltage (HV) on each amplifier.\\nMonitor readings on Power meters (measuring power from PA0-in and  PA0-out to PA3-out).";
const std::string IGSxGUI::ADTView::STRING_ADT_ATTENTION = "HPAC ADT runs on the Master System Controller (MSC) computer.A virtual Network Computing (VCN) connection to MSC can be used to control it.";
const std::string IGSxGUI::ADTView::STRING_TIME = "Time";
const std::string IGSxGUI::ADTView::STRING_DATE = "Date";
const std::string IGSxGUI::ADTView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::ADTView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::ADTView::STRING_DATETIME_FORMAT1 = "%l:%M%p";
const std::string IGSxGUI::ADTView::STRING_DATETIME_FORMAT2 = "%d/%m/%Y";
const std::string IGSxGUI::ADTView::STRING_ADTVIEW_SHOWN = "ADTView is shown.";
const char* IGSxGUI::ADTView::STRING_ADT_MESSAGE = "Start ADT button pressed, Adt Name: ";

const std::string IGSxGUI::ADTView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::ADTView::STYLE_ADTINFO = "infoDisplayButton";
const std::string IGSxGUI::ADTView::STYLE_CURRENTPAGE = "currentPage";
const std::string IGSxGUI::ADTView::STYLE_ACTIVE_ADT = "ActiveADT";
const std::string IGSxGUI::ADTView::STYLE_NO_ACTIVE_ADT = "NoActiveADT";
const std::string IGSxGUI::ADTView::STRING_SPACE = "  ";
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_ONE = 1;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_TWO = 2;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_THREE = 3;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_FOUR = 4;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_FIVE = 5;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_SIX = 6;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_SEVEN = 7;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_EIGHT = 8;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_NINE = 9;
const int IGSxGUI::ADTView::ADT_REPORT_PAGE_NUMBER_TEN = 10;

const int IGSxGUI::ADTView::CONVERSION_BUFFER_SIZE = 80;
const int IGSxGUI::ADTView::TIMER_INTERVAL = 4000;
const int IGSxGUI::ADTView::ITEMS_TO_REMOVE = 20;

IGSxGUI::ADTView::ADTView(ADTManager *pADTManager) :
    sui(new SUI::ADTView),
    m_numTotalPages(0),
    m_numLastPageItems(0),
    m_currentPageNo(0),
    m_nPreviousDetailItem(0),
    m_bRunningADT(false),
    m_selectedSubSystem(""),
    m_selectedADT("")
{
    m_presenter = new ADTPresenter(this, pADTManager);
}

IGSxGUI::ADTView::~ADTView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::ADTView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ADTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    setHandlers();
    loadContainers();
    init();
    IGS_INFO(STRING_ADTVIEW_SHOWN);
}

void IGSxGUI::ADTView::init()
{
    sui->lblAllADTs->setColor(SUI::ColorEnum::Gray);
    sui->gbxADT->setBGColor(SUI::ColorEnum::White);
    sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_ADT);
    sui->lblDescription->setText(STRING_NO_ACTIVE_ADT);

    sui->lblType->setVisible(false);
    sui->lblName->setVisible(false);
    sui->lblStatus->setVisible(false);
    sui->tawADTSubsystem->showGrid(false);

    m_listADT = m_presenter->getADTs();
    m_listSubsystemADTs = m_presenter->getADTs();

    loadTestTypes();
    loadSubSystems();
}

void IGSxGUI::ADTView::initNumberedButtons(const int& numTotalPages)
{
    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if (boost::lexical_cast<int>(m_listDisplayButtons[i]->getText()) <= numTotalPages)
        {
            m_listDisplayButtons[i]->setEnabled(true);
        } else {
            m_listDisplayButtons[i]->setEnabled(false);
        }
    }
}

void IGSxGUI::ADTView::fetchADTs(const int& nCurrentPageNumber)
{
    size_t j  = static_cast<size_t>(((nCurrentPageNumber - 1)*10));

    for (size_t i = 0 ; i < m_listADTUCT.size(); i++)
    {
        if (j < m_listADT.size())
        {
            m_listADTUCT[i]->setVisible(true);
            m_listADTNameLabels[i]->setText(m_listADT[j]->getName());
            IGSxGUI::Util::setAwesome(m_listADTTypeIcons[i], IGSxGUI::AwesomeIcon::AI_fa_crosshairs, SUI::ColorEnum::Gray, NO_SIZE);
            m_listADTDescriptionLabels[i]->setText(m_listADT[j]->getDescription());
            ++j;
        }else{
            m_listADTUCT[i]->setVisible(false);
        }
    }
}



void IGSxGUI::ADTView::onSubsystemPressed()
{
    sui->gbxPageOne->setVisible(true);
    sui->gbxPageTwo->setVisible(false);

    std::list<std::string> items = sui->tawADTSubsystem->getSelectedItems();
    std::string strSelectedRow = items.front();

    strSelectedRow.erase(0, ITEMS_TO_REMOVE);
    strSelectedRow.erase(strSelectedRow.size()-2, strSelectedRow.size());
    std::string selectedText = sui->tawADTSubsystem->getItemText((boost::lexical_cast<int>(strSelectedRow)-1), 0);

    size_t position = selectedText.find('(');
    selectedText.erase(position, selectedText.size());
    boost::trim(selectedText);
    m_selectedSubSystem = selectedText;

    std::vector<ADT*> listSubsystemADTs;

    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == selectedText))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    intersectADTs(getTestTypeADTs(), listSubsystemADTs);
}

void IGSxGUI::ADTView::onButtonShowReportsPressed()
{
    for (size_t i = 0 ; i < 4; i++)
    {
        m_listADTReportGroupBox[i]->setVisible(false);
        m_listADTReportNameLabels[i]->setText(STRING_EMPTY);
        m_listADTReportTypeLabels[i]->setText(STRING_EMPTY);
        m_listADTReportDescriptionLabels[i]->setText(STRING_EMPTY);
    }
    std::list<std::string> selectedItems = sui->ddbSubsystem->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::string selectedText = selectedItems.front();

        size_t position = selectedText.find('(');
        selectedText.erase(position, selectedText.size());
        boost::trim(selectedText);

        std::vector<ADT*> listSubsystemADTs;

        for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
        {
             container subsys = m_listSubsystems[i];

             std::size_t found = selectedText.find(STRING_ALL_ADTS);
             if ((found != std::string::npos) || (subsys.name == selectedText))
             {
                 listSubsystemADTs.push_back(subsys.adt);
             }
        }

        for (size_t i = 0 ; i < listSubsystemADTs.size(); i++)
        {
            if (i > 3)
            {
                break;
            }
            ADT* adt = listSubsystemADTs[i];

            if (adt != NULL)
            {
                m_listADTReportGroupBox[i]->setVisible(true);
                m_listADTReportNameLabels[i]->setText(adt->getName());
                m_listADTReportDescriptionLabels[i]->setText(adt->getDescription());
            }
        }
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getTestADTsByName(const std::string &testtypeName)
{
    std::vector<IGSxGUI::ADT*> listTestTypeADTs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++)
    {
         IGSxGUI::container testtype = m_listTestTypes[i];

         if (testtype.name == testtypeName)
         {
             listTestTypeADTs.push_back(testtype.adt);
         }
    }
    return listTestTypeADTs;
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getSelectedSubSystemADTs()
{
    std::vector<IGSxGUI::ADT*> listSubsystemADTs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_ADTS);
         if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
         {
             listSubsystemADTs.push_back(subsys.adt);
         }
    }
    return listSubsystemADTs;
}

void IGSxGUI::ADTView::intersectADTs(std::vector<ADT *> listTestTypeADTs, std::vector<ADT *> listSubSystemADTs)
{
    m_listADT.clear();

    std::sort(listSubSystemADTs.begin(),  listSubSystemADTs.end());
    std::sort(listTestTypeADTs.begin(),  listTestTypeADTs.end());

    std::set_intersection(listSubSystemADTs.begin(), listSubSystemADTs.end(), listTestTypeADTs.begin(), listTestTypeADTs.end(), std::back_inserter(m_listADT));

    if ((m_listADT.size() <= 0) && sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTView::getTestTypeADTs() const
{
    std::vector<IGSxGUI::ADT*> listTestTypeADTs;
    listTestTypeADTs = m_presenter->getADTs();
    return listTestTypeADTs;
}




void IGSxGUI::ADTView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::ADTView::updateStatus(const IGS::Result &result)
{
    if (result == IGS::OK)
    {
        m_bRunningADT = false;

        sui->gbxADT->setBGColor(SUI::ColorEnum::White);
        sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_ADT);
        sui->lblDescription->setText(STRING_NO_ACTIVE_ADT);
        sui->lblType->setVisible(false);
        sui->lblName->setVisible(false);
        sui->lblStatus->setVisible(false);
        sui->btnShowADT->setVisible(false);
        sui->btnADTDetail->setVisible(false);
    }
}

void IGSxGUI::ADTView::startADT(const std::string &adtName) const
{
    IGS_INFO(std::string(STRING_ADT_MESSAGE + adtName));
    m_presenter->startADT(adtName);
}


void IGSxGUI::ADTView::setInfoButtonStyles()
{
    for (size_t i=0; i < m_listInfoButtons.size(); i++)
    {
        m_listInfoButtons[i]->setStyleSheetClass(STYLE_ADTINFO);
    }
}

void IGSxGUI::ADTView::showADTReportPage(int nCurrentItem, SUI::Button* btnADTInfo, const std::string &adtDescription, const std::string &adtTestName, const std::string &adtTestType)
{
    if (m_nPreviousDetailItem == nCurrentItem)
    {
        if (sui->gbxReport->isVisible())
        {
            sui->gbxReport->setVisible(false);
            btnADTInfo->setStyleSheetClass(STYLE_ADTINFO);
        } else {
            sui->gbxReport->setVisible(true);
            btnADTInfo->setStyleSheetClass(STYLE_CURRENTPAGE);
        }
    } else {
        setInfoButtonStyles();
        btnADTInfo->setStyleSheetClass(STYLE_CURRENTPAGE);
        setTextArea(adtDescription, adtTestName, adtTestType);
        m_selectedADT = adtTestName;
        m_nPreviousDetailItem = nCurrentItem;
    }
}



void IGSxGUI::ADTView::loadContainers()
{
    m_listADTUCT.clear();
    m_listADTNameLabels.clear();
    m_listADTTypeLabels.clear();
    m_listADTTypeIcons.clear();
    m_listADTDescriptionLabels.clear();
    m_listADTTimeLabels.clear();
    m_listDisplayButtons.clear();
    m_listInfoButtons.clear();
    m_listADTReportGroupBox.clear();
    m_listADTReportNameLabels.clear();
    m_listADTReportTypeLabels.clear();
    m_listADTReportDescriptionLabels.clear();




}

void IGSxGUI::ADTView::loadTestTypes()
{
    container testtype;
    for (size_t i = 0 ; i < m_listADT.size(); i++)
    {
        testtype.adt = m_listADT[i];
        m_listTestTypes.push_back(testtype);
    }
}

void IGSxGUI::ADTView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0 ; i < m_listSubsystemADTs.size(); i++)
    {
        subsystem.name = m_listSubsystemADTs[i]->getSubsystem();
        subsystem.adt = m_listSubsystemADTs[i];
        listStringSubsystem.push_back(m_listSubsystemADTs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;
    std::string strAllADTs =  sui->tawADTSubsystem->getItemText(0, 0) + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_listSubsystemADTs.size()) + STRING_CLOSE_BRACKET;
    sui->tawADTSubsystem->setItemText(0, 0, strAllADTs);
    listTestReportSubSystemItems.push_back(strAllADTs);

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        subSystemCount subsyscount = m_listSubsystemCount[i];

        std::string subsys = subsyscount.nameSubsystem + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;

        listTestReportSubSystemItems.push_back(subsys);

        sui->tawADTSubsystem->insertRows(static_cast<int>(i)+1, 1);
        sui->tawADTSubsystem->setItemText(static_cast<int>(i)+1, 0, STRING_SPACE + subsys);
    }
    sui->ddbSubsystem->addItems(listTestReportSubSystemItems);
    sui->ddbSubsystem->selectItem(1);
    sui->tawADTSubsystem->selectItem(0);
}

void IGSxGUI::ADTView::setHandlers()
{
    //sui->btnADTDetail->clicked   = boost::bind(&ADTView::onActiveADTDetailButtonPressed, this);
    sui->tawADTSubsystem->rowClicked = boost::bind(&ADTView::onSubsystemPressed, this);
}

void IGSxGUI::ADTView::setTextArea(const std::string& /*adtDescription*/, const std::string & adtTestName, const std::string& /*adtTestType*/) const
{
    sui->gbxReport->setVisible(true);
    if (!m_listADT.empty())
    {
        std::string textADTHtmlFilePath = "";
        size_t noofADTs = m_listADT.size();
        for (size_t index = 0; index < noofADTs; ++index)
        {
            if (m_listADT[index]->getName() == adtTestName)
            {
                textADTHtmlFilePath =  m_listADT[index]->getHtmlFile();
                break;
            }
        }
        sui->wvwADTHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(textADTHtmlFilePath));
    }
}

void IGSxGUI::ADTView::onActiveADTDetailButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }else{
        sui->gbxReport->setVisible(true);
        sui->lblADTDescDescription->setText(sui->lblName->getText());
        sui->lblADTDescName1->setText(sui->lblName->getText());
        sui->lblADTDescType1->setText(sui->lblType->getText());

        IGSxGUI::ADT* adt = m_presenter->getADT(sui->lblName->getText());

        if (adt != NULL)
        {
            std::string textADTHtmlFilePath = adt->getHtmlFile();
            sui->wvwADTHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(textADTHtmlFilePath));
        }
    }
}


