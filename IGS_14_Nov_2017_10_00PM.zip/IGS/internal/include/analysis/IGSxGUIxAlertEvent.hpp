/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertEvent.hpp
| Author       : Venugopal S
| Description  : Alert Event and Event Handler definition
|
| ! \file        IGSxGUIxAlertEvent.hpp
| ! \brief       Enum file for Alert Event
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTEVENT_HPP
#define IGSXGUIXALERTEVENT_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include "IGSxERR.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

struct structAlertInfo
{
    int alertId;
    IGSxERR::AlertSeverity::AlertSeverityEnum alertSeverity;
    std::string alertCode;
    std::string alertMessage;
    std::string alertDateTime;
    bool bIsAlertAdded;

    structAlertInfo() :
        alertId(0),
        alertSeverity(IGSxERR::AlertSeverity::EVENT),
        alertCode(""),
        alertMessage(""),
        alertDateTime(""),
        bIsAlertAdded(false)
    {
    }
};
typedef structAlertInfo AlertInfo;

typedef boost::signals2::signal<void (int, AlertInfo)> alertUpdated;
typedef alertUpdated::slot_type alertUpdatedCallback;
}  // namespace IGSxGUI
#endif
