/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPD_impl.cpp
| Author       : Venugopal S
| Description  : Stub impementation of IGSxCPD interface
|
| ! \file        IGSxCPD_impl.cpp
| ! \brief       Stub impementation of IGSxCPD interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/date_time.hpp>
#include "IGSxCPD_impl.hpp"
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
typedef struct
{
    std::string name;
    std::string testType;
    std::string description;
    std::string descriptionFile;
    std::string subsystem;
} gMetaType;

gMetaType gCPD[] = {
    {"CPDFFMDFC","Calibration","CPD FFM Default Filter Calibration","GPD_GVCDDT_description.html","Final Focus Metrology"},
    {"CPD_CODMCL","Performance","Collector and Metrology Cleaning CPD","LDL_HPSLHC_description.html","Cleaning"},
    {"CPDDGSABC","Calibration","DGS Actuator Basis Calibration","LED_FFMQCC_description.html","Droplet Generator Steering"},
    {"LDN_HPSNLC","Diagnostics","LDN_HPSNLC test","LEG_FFMDIA_DARK_description.html","High Power Seed"},
    {"CPDDGSESI","Diagnostics","DGSS Encoder Loop System Identification","PML_PCLMFL_description.html","Droplet Generator Steering"},
    {"FDD_DUMREG","Calibration","FDD_DUMREG test","TCC_TECCIO_description.html","Final Focus Assembly"},

    {"LQR_LBQRUP","Calibration","LQR_LBQRUP test","GPD_GVCDDT_description.html","Laser Beam Quality"},
    {"CPDTEMPLATE","Calibration","CPDTEMPLATE","LDL_HPSLHC_description.html","Droplet Generator Steering"},
    {"CPDFFASOC","Calibration","M120 Sensor Calibration Offset","LED_FFMQCC_description.html","Final Focus Assembly"},
    {"CPDDGSEHO","Calibration","Encoder Home Offset Calibration","PML_PCLMFL_description.html","Droplet Generator Steering"},
    {"CPDDGSCSI","Diagnostics","Camera-loop System ID","LEG_FFMDIA_DARK_description.html","Droplet Generator Steering"},
    {"PMY_PCLYZM","Diagnostics","YZT-map Expert Version","TCC_TECCIO_description.html","Plasma Control"},

    {"CPDFFARMF","Performance","Range and Motor Force Verification","GPD_GVCDDT_description.html","Final Focus Assembly"},
    {"CPDFFMQCC","Calibration","FFM Quad Cell Calibration","LDL_HPSLHC_description.html","Final Focus Metrology"},
    {"CPDDUMMY","Calibration","CPDDUMMY test","LED_FFMQCC_description.html","Final Focus Assembly"},
    {"DDW_DGNWSC","Diagnostics","DG Swap CPD","LEG_FFMDIA_DARK_description.html","Droplet Generator Steering"},
    {"PML_PCLMFL","Calibration","Make First Light CPD","PML_PCLMFL_description.html","Plasma Control"},
    {"CPDFFASPM","Performance","CPDFFASPM","TCC_TECCIO_description.html","Final Focus Assembly"},

    {"CPDDGSCSP","Performance","Camera Settling Performance","GPD_GVCDDT_description.html","Droplet Generator Steering"},
    {"CPDDGSDST","Performance","DGSS Droplet Stability Test","LDL_HPSLHC_description.html","Droplet Generator Steering"},
    {"CPDFFARMF_LMC","Performance","Range and Motor Force LMC Verification","LED_FFMQCC_description.html","Final Focus Assembly"},
    {"ECE_ECAETI","Calibration","ESM EUV Timings Calibration","LEG_FFMDIA_DARK_description.html","Energy Control"},
    {"LCD_FFAFRF_LMC","Performance","Frequency Response Function","PML_PCLMFL_description.html","Final Focus Assembly"},
    {"LDH_HPSHCC","Calibration","LDH_HPSHCC test","TCC_TECCIO_description.html","High Power Seed"},

    {"LCF_FFAMDC","Calibration","FFA M120 Decoupling Calibration","GPD_GVCDDT_description.html","Final Focus Assembly"},
    {"PMS_PCLSPD","Calibration","PMS_PCLSPD","LDL_HPSLHC_description.html","Plasma Control"},
    {"LDL_HPSLHC","Diagnostics","LDL_HPSLHC test","LED_FFMQCC_description.html","High Power Seed"},
    {"FPX_BLUPRT","Calibration","FPX_BLUPRT test","LEG_FFMDIA_DARK_description.html","Final Focus Assembly"},
    {"LTA_LCCPEM","Calibration","LTA_LCCPEM test","PML_PCLMFL_description.html","Laser Chain Control"},
    {"LTS_LCCDLS","Calibration","LTS_LCCDLS test","TCC_TECCIO_description.html","Laser Chain Control"},

    {"CPDFFMPAR","Calibration","FFM Parameters","GPD_GVCDDT_description.html","Final Focus Metrology"},
    {"FPY_INTERA","Calibration","FPY_INTERA Interactive CPD Test","LDL_HPSLHC_description.html","Final Focus Assembly"},
    {"LEG_FFMDIA_LIGHT","Diagnostics","LEG_FFMDIA test","LED_FFMQCC_description.html","Final Focus Metrology"},
    {"LEG_FFMDIA_DARK","Diagnostics","LEG_FFMDIA test","LEG_FFMDIA_DARK_description.html","Final Focus Metrology"},
    {"CPDFFASPM_CO2","Performance","CPDFFASPM","PML_PCLMFL_description.html","Final Focus Assembly"},
    {"CPDFFACCT","Diagnostics","Cable Connection Test","TCC_TECCIO_description.html","Final Focus Assembly"},

    {"CPDFFAPCM","Performance","CPDFFAPCM","GPD_GVCDDT_description.html","Final Focus Assembly"},
    {"CPDDGSCOC","Calibration","Camera Offset Calibration","LDL_HPSLHC_description.html","Droplet Generator Steering"},
    {"CPDDGSHYS","Diagnostics","DGS Hysteresis","LED_FFMQCC_description.html","Droplet Generator Steering"},
    {"CPDDGSESP","Performance","DGSS Encoder Loop System Performance","LEG_FFMDIA_DARK_description.html","Droplet Generator Steering"},
    {"LQF_LBQFVM","Calibration","FVM performance test","PML_PCLMFL_description.html","Laser Beam Qualification"},
    {"LCE_FFABCT","Calibration","CPD FFA Beam Coordinate Transform","TCC_TECCIO_description.html","Final Focus Assembly"},

    {"CPDFFASPM_LMC","Performance","CPDFFASPM","GPD_GVCDDT_description.html","Final Focus Assembly"},
    {"CPDFFMRCC","Calibration","RBD Camera Calibration","LDL_HPSLHC_description.html","Final Focus Metrology"},
    {"LCD_FFAFRF_CO2","Performance","Frequency Response Function","LED_FFMQCC_description.html","Final Focus Assembly"},
    {"CPDFFARMF_CO2","Performance","Range and Motor Force Verification CO2","LEG_FFMDIA_DARK_description.html","Final Focus Assembly"},
    {"LEA_FFMBPC","Calibration","Beam Pointing Calibration","PML_PCLMFL_description.html","Final Focus Metrology"},
    {"GPO_GVCOTM","Diagnostics","O2 Measurement for H2 Release CPD","TCC_TECCIO_description.html","Gas Vacuum Control"},

    {"TCC_TECCIO","Diagnostics","TCC_TECCIO test","GPD_GVCDDT_description.html","Timing Control"},
    {"CPDFFAOAC","Calibration","Optical Alignment Calibration","LDL_HPSLHC_description.html","Final Focus Assembly"},
    {"ECS_ECASSM","Diagnostics","Local Controller State Management test","LED_FFMQCC_description.html","Energy Control"}
};
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxCPD::CPD_Stub::TASK_STOPPING_TIMER_INTERVAL = 5000;
struct TimeDescOrderComparator
{
 public:
    bool operator()(const IGSxCPD::TestResult& testresult1, const IGSxCPD::TestResult& testresult2)
    {
        if (testresult1.time() > testresult2.time())
        {
            return true;
        }else {
            return false;
        }
    }
};

// instance
IGSxCPD::CPD *IGSxCPD::CPD_Stub::getInstance()
{
    static CPD_Stub _instance;
    return &_instance;
}

IGSxCPD::CPD* IGSxCPD::CPD::instance = IGSxCPD::CPD_Stub::getInstance();

IGSxCPD::CPD_Stub::CPD_Stub():
    m_strCurrentTest(""),
    m_timer(SUI::Timer::createTimer()),
    m_testStoppedCallback(NULL)
{
    m_timer->setInterval(TASK_STOPPING_TIMER_INTERVAL);
    m_timer->timeout = boost::bind(&CPD_Stub::on_timeout, this);
    m_listCPDReports.clear();
    m_listCPDReports.push_back("/home/adt/CPDReports/CPDFFAPCM_report.html");
    m_listCPDReports.push_back("/home/adt/CPDReports/CPDFFASPM_report.html");
    m_listCPDReports.push_back("/home/adt/CPDReports/CPDFFASOC_report.html");
    m_listCPDReports.push_back("/home/adt/CPDReports/CPDFFASEM_report.html");
    m_listCPDReports.push_back("/home/adt/CPDReports/CPDFFACCT_report.html");
}

void IGSxCPD::CPD_Stub::getTests(IGSxCPD::MetaDescriptions &tests)
{
    for (size_t i = 0; i < sizeof(gCPD) / sizeof(*gCPD); i++)
    {
        gMetaType* CPD = &gCPD[i];
        tests.push_back(MetaDescription(CPD->name, CPD->testType, CPD->subsystem, CPD->description, CPD->descriptionFile));
    }
}

std::string IGSxCPD::CPD_Stub::getCurrentTest()
{
    return m_strCurrentTest;
}

void IGSxCPD::CPD_Stub::subscribeToTestStopped(const IGSxCPD::TestStoppedCallback &cb)
{
    m_testStoppedCallback = cb;
}

void IGSxCPD::CPD_Stub::unsubscribeToTestStopped()
{
    if (m_testStoppedCallback)
    {
        m_testStoppedCallback = NULL;
    }
}

void IGSxCPD::CPD_Stub::startTest(const std::string &testName)
{
    m_strCurrentTest = testName;

    std::cerr << "Test : " << m_strCurrentTest << " started" << std::endl;
    m_timer->start();
}

void IGSxCPD::CPD_Stub::on_timeout()
{
    m_timer->stop();

    std::cerr << "Test : " << getCurrentTest() << " stopped" << std::endl;

    m_strCurrentTest.clear();

    if(!m_testStoppedCallback.empty())
    {
        m_testStoppedCallback(IGS::OK);
    }
}
void IGSxCPD::CPD_Stub::getTestResults(const std::string &testName, time_t startTime, time_t stopTime, TestResultList &testResults)
{
    testResults.clear();
    if(startTime < stopTime )
    {
		for(int i = 0; i < 10; ++i)
		{
		    boost::posix_time::ptime time = boost::posix_time::microsec_clock::local_time();
		    boost::posix_time::time_duration duration( time.time_of_day() );
		    srand(duration.total_nanoseconds());
		    int time_duration = stopTime - startTime;
		    int index  = (rand() % 5) + 0;
		    std::string reportpath = m_listCPDReports[index];
		    TestResult testResult(testName,((rand() % time_duration) + startTime),reportpath);
		    testResults.push_back(testResult);
		}        
        std::sort(testResults.begin(), testResults.end(), TimeDescOrderComparator());
   }else if(startTime == stopTime){
        TestResult testResult(testName, startTime, m_listCPDReports[0]);
        testResults.push_back(testResult);
    }
}






