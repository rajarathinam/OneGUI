/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertManager.cpp
| Author       : Venugopal S
| Description  : Implementation of Alert Manager
|
| ! \file        IGSxGUIxAlertManager.cpp
| ! \brief       Implementation of Alert Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <vector>
#include "IGSxGUIxAlertManager.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxERR.hpp"
#include "IGSxLOG.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::AlertManager::AlertManager()
{
}

IGSxGUI::AlertManager::~AlertManager()
{
    try
    {
        IGSxERR::Alert::getInstance()->unsubscribeToAlertRaised();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }
    try
    {
        IGSxERR::Alert::getInstance()->unsubscribeToAlertDeactivated();
    } catch (IGS::Exception& ex) {
        IGS_ERROR(ex.what());
    }

    for (std::vector<Alert*>::iterator it = m_Alerts.begin() ; it != m_Alerts.end(); ++it)
    {
        if (*it != NULL)
        {
            delete (*it);
            *it = NULL;
        }
    }
    m_Alerts.clear();
}

void IGSxGUI::AlertManager::onAlertRaised(const IGSxERR::ActivatedAlert &alert)
{
    if (alert.severity() == IGSxERR::AlertSeverity::EVENT) return;   // we do not show events!

    Alert* newalert = new Alert(alert);

    if (newalert != NULL)
    {
       m_Alerts.push_back(newalert);

       if (!m_alertUpdated.empty())
       {
           AlertInfo alertInfo;

           alertInfo.bIsAlertAdded = true;
           alertInfo.alertId = newalert->getLogId();
           alertInfo.alertCode = newalert->getLogCode();
           alertInfo.alertSeverity = newalert->getSeverity();
           alertInfo.alertMessage = newalert->getUserText();
           alertInfo.alertDateTime = SystemDateTime::formatDateTime(SystemDateTime::STR_DATE_TIME_SEC, newalert->getTime());

           m_alertUpdated(static_cast<int>(m_Alerts.size()), alertInfo);
       }
    }
}

void IGSxGUI::AlertManager::onAlertRemoved(const IGSxERR::DeactivatedAlert &alert)
{
    for (size_t i = 0 ; i < m_Alerts.size(); i++)
    {
        if (m_Alerts[i]->getLogId() == alert.logId())
        {
            delete m_Alerts[i];
            m_Alerts[i] = NULL;

            m_Alerts.erase(m_Alerts.begin() + static_cast<int>(i));

            if (!m_alertUpdated.empty())
            {
                AlertInfo alertInfo;
                alertInfo.bIsAlertAdded = false;
                alertInfo.alertId = alert.logId();

                m_alertUpdated(static_cast<int>(m_Alerts.size()), alertInfo);
            }
        }
    }
}

std::vector<IGSxGUI::Alert *> IGSxGUI::AlertManager::getActiveAlerts() const
{
    return m_Alerts;
}

IGSxGUI::Alert *IGSxGUI::AlertManager::getAlert(int nAlertLogID) const
{
    for (size_t i = 0 ; i < m_Alerts.size(); i++)
    {
        if (m_Alerts[i]->getLogId() == nAlertLogID)
        {
            return m_Alerts[i];
        }
    }
    return NULL;
}

boost::signals2::connection IGSxGUI::AlertManager::registerToAlertUpdated(const IGSxGUI::alertUpdatedCallback &cb)
{
    return m_alertUpdated.connect(cb);
}

void IGSxGUI::AlertManager::initialize()
{
    IGSxERR::Alert::getInstance()->subscribeToAlertRaised(boost::bind(&IGSxGUI::AlertManager::onAlertRaised, this, _1));
    IGSxERR::Alert::getInstance()->subscribeToAlertDeactivated(boost::bind(&IGSxGUI::AlertManager::onAlertRemoved, this, _1));

    IGSxERR::ActiveAlertList alerts;
    IGSxERR::Alert::getInstance()->getActiveAlerts(alerts);

    for (size_t i = 0 ; i < alerts.size(); i++)
    {
        if (alerts[i].severity() != IGSxERR::AlertSeverity::EVENT)
        {   // we do not show events!
            Alert* newalert = new Alert(alerts[i]);

            if (newalert != NULL)
            {
                m_Alerts.push_back(newalert);
            }
        }
    }
}
