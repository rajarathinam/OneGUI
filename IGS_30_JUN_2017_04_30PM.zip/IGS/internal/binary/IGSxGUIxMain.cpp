/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <SUIApplication.h>
#include <SUIResourcePath.h>
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxIStubView.hpp"
#include "IGSxStubView.hpp"
#include "IGSxKPI_impl.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSplashView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string STRING_SIMULATION = "simulation";
const std::string STRING_RESOURCE = "/Resource/";

int main(int argc, char *argv[])
{
    int result = 1;
    // instantiate the application
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc, argv);

    SUI::ResourcePath::getInstance()->setResourcePath(get_current_dir_name() + STRING_RESOURCE);

    //Following implementation is temporary, will be changed by AI -218 (New Application class)
    if (argc == 1)
    {
        IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
        IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
        splashView->show(mainView);

        IGSxGUI::PluginFactory::getInstance().initialize();

        result = app->exec();
    } else {
        std::string strPluginName(argv[1]);

        if (strPluginName == STRING_SIMULATION)
        {
            // Start stub implementations
            dynamic_cast<IGSxKPI::KPI_Stub*>(IGSxKPI::KPI::getInstance())->enableKPIGeneration(true);

           IGSxGUI::IStubView *stubView;
           stubView = new IGSxGUI::StubView();

           if (stubView != NULL)
           {
              stubView->show();
           }
           //IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
           //splashView->show();
           IGSxGUI::PluginFactory::getInstance().initialize();
           //delete splashView;
           //splashView = NULL;
           IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();

           if (mainView != NULL)
           {
               mainView->show();
               result = app->exec();
               delete mainView;
               mainView = NULL;

              if (stubView != NULL)
              {
                 delete stubView;
                 stubView = NULL;
              }
           }
        }
    }
    // execute the application (main eventloop)
    return result;
}

