/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxPluginFactory.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Plugin Factory
|
| ! \file        IGSxGUIxPluginFactory.cpp
| ! \brief       Implementation of Plugin Factory
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxGUIxSystem.hpp"
#include "IGSxGUIxAnalysis.hpp"
#include "IGSxGUIxDashboard.hpp"
#include <SUITimer.h>
#include <boost/lexical_cast.hpp>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::PluginFactory::PluginFactory():
    m_systemPlugin(NULL),
    m_analysisPlugin(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_dashboardPlugin(NULL),
    m_value(0)
{
    m_timer->timeout = boost::bind(&PluginFactory::onTimeout, this);
    m_timer->setSingleShot(false);
}

IGSxGUI::PluginFactory::~PluginFactory()
{
    if (m_systemPlugin != NULL)
    {
        delete m_systemPlugin;
        m_systemPlugin = NULL;
    }
    if (m_analysisPlugin != NULL)
    {
        delete m_analysisPlugin;
        m_analysisPlugin = NULL;
    }
    if (m_dashboardPlugin != NULL)
    {
        delete m_dashboardPlugin;
        m_dashboardPlugin = NULL;
    }
}

void IGSxGUI::PluginFactory::onTimeout()
{
    m_value++;
    if (m_initStatusCb)
    {
        if(m_value == 1)
        m_initStatusCb("Loading data...");
    }

    if (m_initStatusCb)
    {
         if(m_value == 9)

        m_initStatusCb("Completed Initialization");
    }

}

void IGSxGUI::PluginFactory::initialize()
{

    /*if (m_initStatusCb)
    {
        m_initStatusCb("LOADING DATA...");
    }
    getDashboardPlugin()->initialize();
    getSystemPlugin();
    getAnalysisPlugin();
    if (m_initStatusCb)
    {
        m_initStatusCb("Finalizing Initialization");
        m_initStatusCb("Completed Initialization");
    }
    */
}

IGSxGUI::ISystem* IGSxGUI::PluginFactory::getSystemPlugin()
{
    if (m_systemPlugin == NULL)
    {
        m_systemPlugin = new IGSxGUI::System();
    }
    return m_systemPlugin;
}

IGSxGUI::IAnalysis* IGSxGUI::PluginFactory::getAnalysisPlugin()
{
    if (m_analysisPlugin == NULL)
    {
        m_analysisPlugin = new IGSxGUI::Analysis();
    }
    return m_analysisPlugin;
}

IGSxGUI::IDashboard* IGSxGUI::PluginFactory::getDashboardPlugin()
{
    if (m_dashboardPlugin == NULL)
    {
        m_dashboardPlugin = new IGSxGUI::Dashboard();
    }
    return m_dashboardPlugin;
}

void IGSxGUI::PluginFactory::subscribeToInitStatusChanged(const InitStatusCallback &cb)
{
    m_initStatusCb = cb;
    m_timer->start(1000);
}

void IGSxGUI::PluginFactory::unsubscribeToInitStatusChanged()
{
    if (m_initStatusCb)
    {
        m_initStatusCb = NULL;
    }
}

