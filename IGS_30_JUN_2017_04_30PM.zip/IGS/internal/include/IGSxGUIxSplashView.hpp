/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSplashView.hpp
| Author       : Raja A
| Description  : Header file for Splashscreen view
|
| ! \file        IGSxGUIxSplashView.hpp
| ! \brief       Header file for Splashscreen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXGUIXSPLASHVIEW_HPP
#define IGSXGUIXSPLASHVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxISplashView.hpp"
#include "IGSxGUIxSplashPresenter.hpp"
#include "IGSxGUIxSplashView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class SplashView;
}  // namespace SUI

namespace IGSxGUI {
class SplashView: public IGSxGUI::ISplashView
{
 public:
    SplashView();
    virtual ~SplashView();
    virtual void show(IMainView* mainView);
 private:
    void onInitStatusChanged(const std::string& initStatus);
    static const std::string SPLASHVIEW_LOAD_FILE;
    SUI::SplashView *sui;
    IGSxGUI::SplashPresenter *m_presenter;
    IMainView *m_mainView;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSPLASHVIEW_HPP
