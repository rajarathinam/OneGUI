/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxISplashView.hpp
| Author       : Raja A
| Description  : Interface file for Splashscreen view
|
| ! \file        IGSxGUIxMainView.hpp
| ! \brief       Interface file for Splashscreen view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISPLASHVIEW_HPP
#define IGSXGUIXISPLASHVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class ISplashView
{
 public:
    ISplashView() {}
    virtual ~ISplashView() {}
    virtual void show() = 0;
};
}  // namespace IGSxGUI
#endif // IGSXGUIXISPLASHVIEW_HPP
