/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard Presenter
|
| ! \file        IGSxGUIxDashboardPresenter.hpp
| ! \brief       Header file for Dashboard Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDASHBOARDPRESENTER_HPP
#define IGSXGUIXDASHBOARDPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include <string>
#include "IGSxGUIxIDashboardView.hpp"
#include "IGSxKPI.hpp"
#include "IGSxGUIxKPIManager.hpp"

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class DashboardPresenter
{
 public:
    explicit DashboardPresenter(IGSxGUI::IDashboardView* view, KPIManager* pKPIManager);
    virtual ~DashboardPresenter();

    IGSxGUI::KPI* getKPI(const std::string &kpiName) const;
    IGSxGUI::KPI* getSystemKPI(const std::string &kpiName) const;
    IGSxGUI::KPI* getConsumable(const std::string &kpiName) const;
    vector<KPI *> getKPIs() const;
    vector<KPI *> getSystemKPIs() const;
    vector<KPI *> getConsumables() const;

    vector<KPIValueSet*> getKPIValueSets(const std::string& kpiName) const;
    vector<KPIValueSet*> getSystemKPIValueSets(const std::string& kpiName) const;
    vector<KPIValueSet*> getConsumableValueSets(const std::string& kpiName) const;

    void subscribeForEvents();
    void unsubscribeForEvents();

 private:
    DashboardPresenter(const DashboardPresenter&);
    DashboardPresenter& operator=(const DashboardPresenter&);

    void onKPIDataUpdated(const std::string& kpiName, const std::string& type, const std::string& valueSetName);

    KPIManager* m_pKPIManager;
    IDashboardView *m_view;

    vector<boost::signals2::connection> m_KPIConnections;
    vector<boost::signals2::connection> m_SystemKPIConnections;
    vector<boost::signals2::connection> m_ConsumableConnections;

    static const string STRING_KPI;
    static const string STRING_SYSTEMKPI;
    static const string STRING_CONSUMABLE;
};
}  // namespace IGSxGUI

#endif  // IGSXGUIXDASHBOARDPRESENTER_HPP
