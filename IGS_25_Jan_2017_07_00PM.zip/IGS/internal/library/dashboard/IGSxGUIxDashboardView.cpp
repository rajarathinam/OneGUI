/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <sstream>
#include <iomanip>
#include <vector>
#include <utility>
#include <string>
#include <map>
#include <stack>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIUserControl.h>
#include <SUIGroupBox.h>
#include <SUIScrollBar.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");

const std::string IGSxGUI::DashboardView::STRING_EMPTY = "";
const std::string IGSxGUI::DashboardView::STRING_SINGLE_SPACE = " ";
const std::string IGSxGUI::DashboardView::STRING_KPI = "KPI";
const std::string IGSxGUI::DashboardView::STRING_VESSEL = "Vessel";
const std::string IGSxGUI::DashboardView::STRING_TIME = "Time";
const std::string IGSxGUI::DashboardView::STRING_ZERO = "0";
const int IGSxGUI::DashboardView::CONSUMABLES_COUNT = 10;
const int IGSxGUI::DashboardView::NO_OF_PLOTITEM_VALUES = 20;
const int IGSxGUI::DashboardView::NO_OF_MAJOR_TICKS = 4;
const int IGSxGUI::DashboardView::NO_OF_MINOR_TICKS = 0;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_START_VALUE = 0.13;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_END_VALUE = 0.27;
const double IGSxGUI::DashboardView::HISTOGRAM_BAR_SEPARATOR = 0.20;

const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME1 = "Histogram1";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME2 = "Histogram2";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME3 = "Histogram3";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME4 = "Histogram4";
const std::string IGSxGUI::DashboardView::STRING_HISTOGRAM_NAME5 = "Histogram5";
const std::string IGSxGUI::DashboardView::STRING_DATETIME_FORMAT1 = "%02l:%02M";
const std::string IGSxGUI::DashboardView::STRING_DATETIME_FORMAT2 = "%d/%m/%Y";

const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_HOVER_ON = "uctnormalkpihoveron";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_HOVER_OFF = "uctnormalkpihoveroff";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT = "uctnormalkpicategorygraytext";
const std::string IGSxGUI::DashboardView::STYLE_UCT_NORMAL_KPI_PLAIN_TEXT = "uctnormalkpiplaintext";

const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_HOVER_ON = "uctconsumablehoveron";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_HOVER_OFF = "uctconsumablehoveroff";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT = "uctconsumablekpigraytext";
const std::string IGSxGUI::DashboardView::STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT = "uctconsumablekpiplaintext";
struct IsEqual
{
 public:
    explicit IsEqual(std::string xx):m_x(xx){}
    bool operator()(const std::pair<std::string, int> pair)
    {
       if (pair.first ==  m_x)
       {
           return true;
       } else {
           return false;
       }
    }
 private:
    std::string m_x;
};

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView)
{
    m_presenter = new DashboardPresenter(this, pKpiManager);
    m_slider_move_past_values = false;
    m_slider_value_backup = 360;

    m_listSystemKPIs = m_presenter->getSystemKPIs();
    size_t noOfSystemKPIs =  m_listSystemKPIs.size();
    vectorPair temp_vecpair;

    for (size_t index = 0; index < noOfSystemKPIs; ++index)
    {
        std::string systemKPIName = m_listSystemKPIs[index]->getDescription();
        m_mapKPITimeValues.insert(std::make_pair(systemKPIName, temp_vecpair));
    }
}
IGSxGUI::DashboardView::~DashboardView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
    for (std::map<std::string, SUI::PlotHistogramItem*>::iterator it = m_mapKPIHistogram.begin(); it != m_mapKPIHistogram.end(); it++)
    {
        if (it->second != NULL)
        {
            it->second->detach();
            delete it->second;
        }
    }

    m_mapKPIHistogram.clear();
}
const std::string IGSxGUI::DashboardView::currentDateTime(const std::string& dateTime) const
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&now, &tstruct);
    if (dateTime == STRING_TIME)
    {
        strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT1.c_str(), &tstruct);
    } else {
        strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT2.c_str(), &tstruct);
    }
    return buf;
}
const std::string IGSxGUI::DashboardView::convertTime(const time_t &time) const
{
    struct tm  tstruct;
    char       buf[80];
    tstruct = *localtime_r(&time, &tstruct);
    strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT1.c_str(), &tstruct);
    return buf;
}

void IGSxGUI::DashboardView::buildHistogramGraphs()
{
    m_listSystemKPIs.clear();
    m_mapKPIHistogram.clear();
    m_mapKPIPlots.clear();
    m_mapKPIGraphValueLabel.clear();

    m_listSystemKPIs = m_presenter->getSystemKPIs();

    if (m_listSystemKPIs.size() >= 1) buildHistogramGraph(STRING_HISTOGRAM_NAME1, sui->plwSystemKPIGraph1, m_listSystemKPIs[0], sui->lblSystemKPIGraph1KPIName, sui->lblSystemKPIGraph1KPIUnit, sui->lblSystemKPIGraph1KPIValue, m_circularBuffer1);
    if (m_listSystemKPIs.size() >= 2) buildHistogramGraph(STRING_HISTOGRAM_NAME2, sui->plwSystemKPIGraph2, m_listSystemKPIs[1], sui->lblSystemKPIGraph2KPIName, sui->lblSystemKPIGraph2KPIUnit, sui->lblSystemKPIGraph2KPIValue, m_circularBuffer2);
    if (m_listSystemKPIs.size() >= 3) buildHistogramGraph(STRING_HISTOGRAM_NAME3, sui->plwSystemKPIGraph3, m_listSystemKPIs[2], sui->lblSystemKPIGraph3KPIName, sui->lblSystemKPIGraph3KPIUnit, sui->lblSystemKPIGraph3KPIValue, m_circularBuffer3);
    if (m_listSystemKPIs.size() >= 4) buildHistogramGraph(STRING_HISTOGRAM_NAME4, sui->plwSystemKPIGraph4, m_listSystemKPIs[3], sui->lblSystemKPIGraph4KPIName, sui->lblSystemKPIGraph4KPIUnit, sui->lblSystemKPIGraph4KPIValue, m_circularBuffer4);
    if (m_listSystemKPIs.size() >= 5) buildHistogramGraph(STRING_HISTOGRAM_NAME5, sui->plwSystemKPIGraph5, m_listSystemKPIs[4], sui->lblSystemKPIGraph5KPIName, sui->lblSystemKPIGraph5KPIUnit, sui->lblSystemKPIGraph5KPIValue, m_circularBuffer5);
}

void IGSxGUI::DashboardView::buildHistogramGraph(const std::string& name, SUI::PlotWidget* plot, IGSxGUI::KPI* kpi, SUI::Label *lblName, SUI::Label *lblDisplayName, SUI::Label *lblValue, const boost::circular_buffer<double>& buffer)
{
    SUI::PlotHistogramItem* histogram = new SUI::PlotHistogramItem(name);
    if (histogram != NULL)
    {
        plot->setYGrid(SUI::GridStyleEnum::Normal);

        plot->setXScale(0.0, 4.0);

        plot->setAxisMaxMajor(SUI::PlotAxisEnum::xBottom, 4);
        plot->setAxisMaxMinor(SUI::PlotAxisEnum::xBottom, 0);
        plot->setAxisMaxMinor(SUI::PlotAxisEnum::yLeft, 0);


        //SUI::PlotItemCustomColor penColor(10, 168, 251,179);
        SUI::PlotItemCustomColor penColor(83, 194, 252);
        histogram->setCustomBrushColor(penColor);
        histogram->setCustomPenColor(penColor);
        histogram->attach(plot);
    }

    if (kpi != NULL)
    {
        lblName->setText(kpi->getDescription());
        lblDisplayName->setText(kpi->getDisplayName());
        m_mapKPIHistogram.insert(std::make_pair(kpi->getDescription(), histogram));
        m_mapKPIGraphValueLabel.insert(std::make_pair(kpi->getDescription(), lblValue));
        m_mapKPIPlots.insert(std::make_pair(kpi->getDescription(), plot));
        m_mapKPICircBuffPlotItemValues.insert((std::make_pair(kpi->getDescription(), buffer)));
    }
}
void IGSxGUI::DashboardView::buildKPITable()
{
     m_listKPIs.clear();
     m_listKPIs = m_presenter->getKPIs();
     size_t numOfKpis = m_listKPIs.size();
     size_t numOfKpiNames = m_listNormalKPINames.size();

        for (size_t i = 0; i < numOfKpis; i++)
        {
                KPI* kpi = m_listKPIs[i];
                if (kpi != NULL)
                {
                    if (i % 2 == 0)
                    {
                        int index = i/2;
                        m_listNormalKPINames[index]->setText(kpi->getDescription());
                        m_listNormalKPITimes[index]->setText(currentDateTime(STRING_TIME));
                        m_listNormalKPIUnits[index]->setText(kpi->getDisplayName());
                        if (kpi->getValueSets().size() > 0)
                        {
                            boost::circular_buffer<KPITimeValue> cbKpiTimeValue = kpi->getValueSets()[0]->getValue();
                            KPITimeValue kpiTimeValue = cbKpiTimeValue.back();
                            double kpiValue = kpiTimeValue.kpiValue;

                            m_listNormalKPICategories[index]->setText(kpi->getValueSets()[0]->getDescription());
                            m_listNormalKPIValues[index]->setText(boost::lexical_cast<std::string>(kpiValue));
                        }
                    } else {
                        int index = i/2;
                        m_listSystemKPINames[index]->setText(kpi->getDescription());
                        m_listSystemKPITimes[index]->setText(currentDateTime(STRING_TIME));
                        m_listSystemKPIUnits[index]->setText(kpi->getDisplayName());
                        if (kpi->getValueSets().size() > 0)
                        {
                            boost::circular_buffer<KPITimeValue> cbKpiTimeValue = kpi->getValueSets()[0]->getValue();
                            KPITimeValue kpiTimeValue = cbKpiTimeValue.back();
                            double kpiValue = kpiTimeValue.kpiValue;

                            m_listSystemKPICategories[index]->setText(kpi->getValueSets()[0]->getDescription());
                            m_listSystemKPIValues[index]->setText(boost::lexical_cast<std::string>(kpiValue));
                        }
                    }
                }
        }

        // To fill the table with default values
        for (size_t i = numOfKpis; i < numOfKpiNames; i++)
        {
            m_listNormalKPINames[i]->setText(STRING_EMPTY);
            m_listNormalKPICategories[i]->setText(STRING_EMPTY);
            m_listNormalKPITimes[i]->setText(STRING_EMPTY);
            m_listNormalKPIValues[i]->setText(STRING_EMPTY);
            m_listNormalKPIUnits[i]->setText(STRING_EMPTY);
        }
}
void IGSxGUI::DashboardView::buildConsumableTable()
{
    double kpiValue = 0.0;

    m_listKPIs.clear();
    m_listKPIs = m_presenter->getConsumables();

    size_t t_vec_size1 = m_listConsumableNames.size();
    size_t t_vec_size2 = CONSUMABLES_COUNT;

    for (size_t i = 0; i < t_vec_size1; i++)
    {
        KPI* kpi = m_listKPIs[i];
        if (kpi != NULL)
        {
            m_listConsumableNames[i]->setText(kpi->getDescription());
            m_listConsumableTimes[i]->setText(currentDateTime(STRING_TIME));

            if (kpi->getValueSets().size() > 0)
            {
                boost::circular_buffer<KPITimeValue> cbKpiTimeValue = kpi->getValueSets()[0]->getValue();
                KPITimeValue kpiTimeValue = cbKpiTimeValue.back();
                kpiValue = kpiTimeValue.kpiValue;
            }
            double max = boost::lexical_cast<double>(kpi->getMax());
            double min = boost::lexical_cast<double>(kpi->getMin());
            double t_kpiValuePercentage = ((kpiValue - min) * 100)/(max - min);
            m_listConsumableValues[i]->setText(boost::lexical_cast<std::string>(kpiValue));
            m_listConsumableUnits[i]->setText(kpi->getDisplayName());
            m_listConsumableProgressbars[i]->setValue(t_kpiValuePercentage);
        }
    }
    for (size_t i = t_vec_size1; i < t_vec_size2 ; ++i)
    {
            m_listConsumableNames[i]->setText(STRING_EMPTY);
            m_listConsumableTimes[i]->setText(STRING_EMPTY);
            m_listConsumableValues[i]->setText(STRING_EMPTY);
            m_listConsumableUnits[i]->setText(STRING_EMPTY);
            m_listConsumableProgressbars[i]->setValue(0);
    }
}
void IGSxGUI::DashboardView::restoreDashboard()
{
    onSliderValueChanged();
}

void IGSxGUI::DashboardView::showHistograms()
{
    size_t noOfSysKPIs = m_listSystemKPIs.size();
    for (size_t outer_index = 0; outer_index < noOfSysKPIs; ++outer_index)
    {
        std::string sysKPIName = m_listSystemKPIs[outer_index]->getDescription();
        m_circularBufferToDraw[sysKPIName].set_capacity(NO_OF_PLOTITEM_VALUES);
        m_circularBufferToDraw[sysKPIName].clear();


        for (int inner_index = 0; inner_index < NO_OF_PLOTITEM_VALUES; ++inner_index)
        {
          m_circularBufferToDraw[sysKPIName].push_back(0.0);
        }
        std::vector <std::pair<std::string, double> > temp_vector = m_mapKPITimeValues[sysKPIName];
        std::vector <std::pair<std::string, double> >::iterator it;
        std::vector <int> y_axis_vec;


           for (it = temp_vector.begin(); it != temp_vector.end(); ++it)
           {
               m_circularBufferToDraw[sysKPIName].push_back(it->second);
               y_axis_vec.push_back(it->second);
           }
           /*
           // Get Min, Max Values to set Histogram Y-Axis
           int min = *(std::min_element(y_axis_vec.begin(),y_axis_vec.end()));
           int max = *(std::max_element(y_axis_vec.begin(),y_axis_vec.end()));
           double calc_min = min  - (0.1 * (max - min));
           double calc_max = max  + (0.1 * (max - min));


           m_mapKPIPlots[sysKPIName]->setYLeftScale(calc_min,calc_max);
           */

    m_mapKPIHistogram[sysKPIName]->clearSamples();
    boost::circular_buffer<double>::const_iterator end_it = m_circularBufferToDraw[sysKPIName].end();
    boost::circular_buffer<double>::const_iterator circ_it;
    plotsamples[sysKPIName].clear();

    m_mapKPIMinValue[sysKPIName] = HISTOGRAM_BAR_START_VALUE;
    m_mapKPIMaxValue[sysKPIName] = HISTOGRAM_BAR_END_VALUE;

    for (circ_it = m_circularBufferToDraw[sysKPIName].begin(); circ_it != end_it; ++circ_it)
    {
        plotsamples[sysKPIName].push_back(SUI::PlotIntervalSample(*circ_it, m_mapKPIMinValue[sysKPIName], m_mapKPIMaxValue[sysKPIName]));
        m_mapKPIMinValue[sysKPIName]  = m_mapKPIMinValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
        m_mapKPIMaxValue[sysKPIName]  = m_mapKPIMaxValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
    }
    m_mapKPIHistogram[sysKPIName]->setSamples(plotsamples[sysKPIName]);
    m_mapKPIPlots[sysKPIName]->replot();
    }
}

void IGSxGUI::DashboardView::showHistogramsForValue(const std::string& value)
{

    size_t noOfSysKPIs = m_listSystemKPIs.size();
    for (size_t outer_index = 0; outer_index < noOfSysKPIs; ++outer_index)
    {
        std::string sysKPIName = m_listSystemKPIs[outer_index]->getDescription();
        m_circularBufferToDraw[sysKPIName].set_capacity(NO_OF_PLOTITEM_VALUES);
        m_circularBufferToDraw[sysKPIName].clear();


        for (int inner_index = 0; inner_index < NO_OF_PLOTITEM_VALUES; ++inner_index)
        {
          m_circularBufferToDraw[sysKPIName].push_back(0.0);
        }

        if (m_slider_move_past_values == true)
        {
            std::vector <std::pair<std::string, double> > temp_vector = m_mapKPITimeValues[sysKPIName];
            std::vector<std::pair<std::string, double> >::iterator start_it = std::find_if(temp_vector.begin(), temp_vector.end(), IsEqual(value));
            std::vector<std::pair<std::string, double> >::iterator it;
            if (start_it != temp_vector.end() )
            {
               for (it = start_it; it != temp_vector.end(); ++it)
               {
                   m_circularBufferToDraw[sysKPIName].push_back(it->second);
               }
            }else {
                m_mapKPIHistogram[sysKPIName]->clearSamples();
                m_mapKPIPlots[sysKPIName]->replot();
                continue;
            }
        }else {
            std::vector <std::pair<std::string, double> > temp_vector = m_mapKPITimeValues[sysKPIName];
            std::vector<std::pair<std::string, double> >::reverse_iterator start_it = std::find_if(temp_vector.rbegin(), temp_vector.rend(), IsEqual(value));
            std::vector<std::pair<std::string, double> >::reverse_iterator it;
            std::stack<double> reverse_values;
            if (start_it != temp_vector.rend() )
            {
               for (it = start_it; it != temp_vector.rend(); ++it)
               {
                   reverse_values.push(it->second);
               }

               while (!reverse_values.empty())
               {
                   m_circularBufferToDraw[sysKPIName].push_back(reverse_values.top());
                   reverse_values.pop();
               }
             }else {
                m_mapKPIHistogram[sysKPIName]->clearSamples();
                m_mapKPIPlots[sysKPIName]->replot();
                continue;
            }
        }

           m_mapKPIHistogram[sysKPIName]->clearSamples();
           boost::circular_buffer<double>::const_iterator end_it = m_circularBufferToDraw[sysKPIName].end();
           boost::circular_buffer<double>::const_iterator circ_it;
           plotsamples[sysKPIName].clear();

           m_mapKPIMinValue[sysKPIName] = HISTOGRAM_BAR_START_VALUE;
           m_mapKPIMaxValue[sysKPIName] = HISTOGRAM_BAR_END_VALUE;

           for (circ_it = m_circularBufferToDraw[sysKPIName].begin(); circ_it != end_it; ++circ_it)
           {
               plotsamples[sysKPIName].push_back(SUI::PlotIntervalSample(*circ_it, m_mapKPIMinValue[sysKPIName], m_mapKPIMaxValue[sysKPIName]));
               m_mapKPIMinValue[sysKPIName]  = m_mapKPIMinValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
               m_mapKPIMaxValue[sysKPIName]  = m_mapKPIMaxValue[sysKPIName] + HISTOGRAM_BAR_SEPARATOR;
           }
           m_mapKPIHistogram[sysKPIName]->setSamples(plotsamples[sysKPIName]);
           m_mapKPIPlots[sysKPIName]->replot();
    }
}

void IGSxGUI::DashboardView::buildTmerDisplays()
{
    time_t currTime= time(NULL);
    sui->timeDisplay7->setText(convertTime(currTime));
    sui->timeDisplay6->setText(convertTime(currTime - (1 * 3600)));
    sui->timeDisplay5->setText(convertTime(currTime - (2 * 3600)));
    sui->timeDisplay4->setText(convertTime(currTime - (3 * 3600)));
    sui->timeDisplay3->setText(convertTime(currTime - (4 * 3600)));
    sui->timeDisplay2->setText(convertTime(currTime - (5 * 3600)));
    sui->timeDisplay1->setText(convertTime(currTime - (6 * 3600)));
}
void IGSxGUI::DashboardView::onSliderValueChanged()
{
    m_slider_value_backup = sui->scbTimeSlider->getValue();
    int current_value = sui->scbTimeSlider->getMaxValue() - m_slider_value_backup;
    time_t timetosearch = time(NULL) - (current_value * 60);
    if (m_slider_value_backup == 360)
    {
        m_slider_move_past_values = false;
        showHistograms();
    }else {
       m_slider_move_past_values = false;
       showHistogramsForValue(convertTime(timetosearch));
    }
}
void IGSxGUI::DashboardView::updateSystemKPI(const std::string &p_systemKPIName, const std::string &p_factor)
{
    KPITimeValue kpiTimeValue;
    std::vector<KPIValueSet*> valSets = m_presenter->getKPIValueSets(p_systemKPIName);
    std::string systemKPIName = m_presenter->getKPI(p_systemKPIName)->getDescription();

    if (valSets.size() > 0)
    {
        boost::circular_buffer<KPITimeValue> cbKpiTimeValue = valSets[0]->getValue();
        kpiTimeValue = cbKpiTimeValue.back();
    }
    static int countForFiveTimes = 0;
    ++countForFiveTimes;
    double value = kpiTimeValue.kpiValue * boost::lexical_cast<double>(p_factor);

    // std::ostringstream ss;
    int int_value = boost::numeric_cast<int>(value);
    // ss << int_value;


    m_mapKPITimeValues[systemKPIName].push_back(std::make_pair(convertTime(kpiTimeValue.kpiTime), value));
    m_mapKPIGraphValueLabel[systemKPIName]->setText(boost::lexical_cast<std::string>(int_value));
    if (sui->scbTimeSlider->getValue() == 360)
    {
        if ((countForFiveTimes % 5) == 0 )
        {
            showHistogramsForValue(convertTime(kpiTimeValue.kpiTime));
        }
    }
}
void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
    if (!bIsFirstTimeDisplay)
    {
        restoreDashboard();
    }
}
void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();

        for (std::map<std::string, SUI::PlotHistogramItem*>::iterator it = m_mapKPIHistogram.begin(); it != m_mapKPIHistogram.end(); it++)
        {
            if (it->second != NULL)
            {
                it->second->detach();
                delete it->second;
            }
        }
        m_mapKPIHistogram.clear();

    }
}
void IGSxGUI::DashboardView::updateKPI(const std::string &kpiName, const std::string &p_displayName, const std::string &p_factor, const std::string &p_valueSetName)
{
    buildTmerDisplays();
    KPITimeValue kpiTimeValue;
    std::vector<KPIValueSet*> valSets = m_presenter->getKPIValueSets(kpiName);
    std::string description = m_presenter->getKPI(kpiName)->getDescription();

    if (valSets.size())
    {
        boost::circular_buffer<KPITimeValue> cbKpiTimeValue = valSets[0]->getValue();
        kpiTimeValue = cbKpiTimeValue.back();
    }

    int v_size = m_listNormalKPINames.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        if (m_listNormalKPINames[index]->getText() == description)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);

            double x = kpiTimeValue.kpiValue * boost::lexical_cast<double>(p_factor);
            ss << x;
            m_listNormalKPICategories[index]->setText(p_valueSetName);
            m_listNormalKPITimes[index]->setText(convertTime(kpiTimeValue.kpiTime));
            m_listNormalKPIValues[index]->setText(ss.str());
            m_listNormalKPIUnits[index]->setText(p_displayName);
            break;
        }
    }

    for (int index = 0 ; index < v_size; ++index)
    {
        if (m_listSystemKPINames[index]->getText() == description)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);
            double x = kpiTimeValue.kpiValue * boost::lexical_cast<double>(p_factor);
            ss << x;
            m_listSystemKPICategories[index]->setText(p_valueSetName);
            m_listSystemKPITimes[index]->setText(convertTime(kpiTimeValue.kpiTime));
            m_listSystemKPIValues[index]->setText(ss.str());
            m_listSystemKPIUnits[index]->setText(p_displayName);
            break;
        }
    }
}
void IGSxGUI::DashboardView::updateConsumable(const std::string &p_consumableName, const std::string &p_displayName, const std::string &p_factor, const std::string &min, const std::string &max)
{
    KPITimeValue kpiTimeValue;
    std::vector<KPIValueSet*> valSets = m_presenter->getConsumableValueSets(p_consumableName);
    std::string description = m_presenter->getConsumable(p_consumableName)->getDescription();

    if (valSets.size() > 0)
    {
        boost::circular_buffer<KPITimeValue> cbKpiTimeValue = valSets[0]->getValue();
        kpiTimeValue = cbKpiTimeValue.back();
    }

    int v_size = m_listConsumableNames.size();
    for (int index = 0 ; index < v_size; ++index)
    {
        if (m_listConsumableNames[index]->getText() == description)
        {
            // Multiply by factor
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(2);

            double x = kpiTimeValue.kpiValue * boost::lexical_cast<double>(p_factor);
            ss << x;

            // Calculate Percentage Value
            double t_kpiValuePercentage = ((kpiTimeValue.kpiValue - boost::lexical_cast<double>(min)) * 100)/(boost::lexical_cast<double>(max) - boost::lexical_cast<double>(min));

            m_listConsumableTimes[index]->setText(convertTime(kpiTimeValue.kpiTime));
            m_listConsumableValues[index]->setText(ss.str());
            m_listConsumableUnits[index]->setText(p_displayName);
            m_listConsumableProgressbars[index]->setValue(boost::numeric_cast<int>(t_kpiValuePercentage));
            break;
        }
    }
}
void IGSxGUI::DashboardView::loadContainers()
{
    m_listNormalKPIUCTs.clear();
    m_listNormalKPINames.clear();
    m_listNormalKPICategories.clear();
    m_listNormalKPITimes.clear();
    m_listNormalKPIValues.clear();
    m_listNormalKPIUnits.clear();
    m_listNormalKPIGroupBoxes.clear();

    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI1);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI2);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI3);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI4);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI5);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI6);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI7);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI8);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI9);
    m_listNormalKPIUCTs.push_back(sui->uctNormalKPI10);

    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI1);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI2);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI3);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI4);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI5);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI6);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI7);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI8);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI9);
    m_listNormalKPIGroupBoxes.push_back(sui->gbxNormalKPI10);

    m_listNormalKPINames.push_back(sui->lblNormalKPI1Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI2Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI3Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI4Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI5Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI6Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI7Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI8Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI9Name);
    m_listNormalKPINames.push_back(sui->lblNormalKPI10Name);

    m_listNormalKPICategories.push_back(sui->lblNormalKPI1Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI2Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI3Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI4Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI5Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI6Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI7Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI8Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI9Category);
    m_listNormalKPICategories.push_back(sui->lblNormalKPI10Category);

    m_listNormalKPITimes.push_back(sui->lblNormalKPI1Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI2Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI3Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI4Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI5Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI6Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI7Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI8Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI9Time);
    m_listNormalKPITimes.push_back(sui->lblNormalKPI10Time);

    m_listNormalKPIValues.push_back(sui->lblNormalKPI1Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI2Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI3Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI4Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI5Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI6Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI7Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI8Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI9Value);
    m_listNormalKPIValues.push_back(sui->lblNormalKPI10Value);

    m_listNormalKPIUnits.push_back(sui->lblNormalKPI1Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI2Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI3Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI4Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI5Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI6Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI7Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI8Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI9Unit);
    m_listNormalKPIUnits.push_back(sui->lblNormalKPI10Unit);

    m_listSystemKPIUCTs.clear();
    m_listSystemKPINames.clear();
    m_listSystemKPICategories.clear();
    m_listSystemKPITimes.clear();
    m_listSystemKPIValues.clear();
    m_listSystemKPIUnits.clear();
    m_listSystemKPIGroupBoxes.clear();

    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI1);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI2);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI3);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI4);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI5);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI6);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI7);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI8);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI9);
    m_listSystemKPIUCTs.push_back(sui->uctSystemKPI10);

    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI1);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI2);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI3);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI4);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI5);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI6);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI7);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI8);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI9);
    m_listSystemKPIGroupBoxes.push_back(sui->gbxSystemKPI10);

    m_listSystemKPINames.push_back(sui->lblSystemKPI1Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI2Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI3Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI4Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI5Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI6Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI7Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI8Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI9Name);
    m_listSystemKPINames.push_back(sui->lblSystemKPI10Name);

    m_listSystemKPICategories.push_back(sui->lblSystemKPI1Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI2Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI3Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI4Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI5Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI6Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI7Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI8Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI9Category);
    m_listSystemKPICategories.push_back(sui->lblSystemKPI10Category);

    m_listSystemKPITimes.push_back(sui->lblSystemKPI1Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI2Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI3Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI4Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI5Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI6Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI7Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI8Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI9Time);
    m_listSystemKPITimes.push_back(sui->lblSystemKPI10Time);

    m_listSystemKPIValues.push_back(sui->lblSystemKPI1Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI2Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI3Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI4Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI5Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI6Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI7Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI8Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI9Value);
    m_listSystemKPIValues.push_back(sui->lblSystemKPI10Value);

    m_listSystemKPIUnits.push_back(sui->lblSystemKPI1Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI2Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI3Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI4Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI5Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI6Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI7Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI8Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI9Unit);
    m_listSystemKPIUnits.push_back(sui->lblSystemKPI10Unit);

    m_listConsumableUCTs.clear();
    m_listConsumableGroupBoxes.clear();
    m_listConsumableNames.clear();
    m_listConsumableCategories.clear();
    m_listConsumableTimes.clear();
    m_listConsumableValues.clear();
    m_listConsumableUnits.clear();
    m_listConsumableProgressbars.clear();

    m_listConsumableUCTs.push_back(sui->uctConsumable1);
    m_listConsumableUCTs.push_back(sui->uctConsumable2);
    m_listConsumableUCTs.push_back(sui->uctConsumable3);
    m_listConsumableUCTs.push_back(sui->uctConsumable4);
    m_listConsumableUCTs.push_back(sui->uctConsumable5);
    m_listConsumableUCTs.push_back(sui->uctConsumable6);
    m_listConsumableUCTs.push_back(sui->uctConsumable7);
    m_listConsumableUCTs.push_back(sui->uctConsumable8);
    m_listConsumableUCTs.push_back(sui->uctConsumable9);
    m_listConsumableUCTs.push_back(sui->uctConsumable10);

    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable1);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable2);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable3);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable4);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable5);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable6);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable7);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable8);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable9);
    m_listConsumableGroupBoxes.push_back(sui->gbxConsumable10);

    m_listConsumableNames.push_back(sui->lblConsumable1Name);
    m_listConsumableNames.push_back(sui->lblConsumable2Name);
    m_listConsumableNames.push_back(sui->lblConsumable3Name);
    m_listConsumableNames.push_back(sui->lblConsumable4Name);
    m_listConsumableNames.push_back(sui->lblConsumable5Name);
    m_listConsumableNames.push_back(sui->lblConsumable6Name);
    m_listConsumableNames.push_back(sui->lblConsumable7Name);
    m_listConsumableNames.push_back(sui->lblConsumable8Name);
    m_listConsumableNames.push_back(sui->lblConsumable9Name);
    m_listConsumableNames.push_back(sui->lblConsumable10Name);

    m_listConsumableTimes.push_back(sui->lblConsumable1Time);
    m_listConsumableTimes.push_back(sui->lblConsumable2Time);
    m_listConsumableTimes.push_back(sui->lblConsumable3Time);
    m_listConsumableTimes.push_back(sui->lblConsumable4Time);
    m_listConsumableTimes.push_back(sui->lblConsumable5Time);
    m_listConsumableTimes.push_back(sui->lblConsumable6Time);
    m_listConsumableTimes.push_back(sui->lblConsumable7Time);
    m_listConsumableTimes.push_back(sui->lblConsumable8Time);
    m_listConsumableTimes.push_back(sui->lblConsumable9Time);
    m_listConsumableTimes.push_back(sui->lblConsumable10Time);

    m_listConsumableValues.push_back(sui->lblConsumable1Value);
    m_listConsumableValues.push_back(sui->lblConsumable2Value);
    m_listConsumableValues.push_back(sui->lblConsumable3Value);
    m_listConsumableValues.push_back(sui->lblConsumable4Value);
    m_listConsumableValues.push_back(sui->lblConsumable5Value);
    m_listConsumableValues.push_back(sui->lblConsumable6Value);
    m_listConsumableValues.push_back(sui->lblConsumable7Value);
    m_listConsumableValues.push_back(sui->lblConsumable8Value);
    m_listConsumableValues.push_back(sui->lblConsumable9Value);
    m_listConsumableValues.push_back(sui->lblConsumable10Value);

    m_listConsumableUnits.push_back(sui->lblConsumable1Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable2Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable3Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable4Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable5Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable6Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable7Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable8Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable9Unit);
    m_listConsumableUnits.push_back(sui->lblConsumable10Unit);

    m_listConsumableProgressbars.push_back(sui->pgbConsumable1);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable2);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable3);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable4);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable5);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable6);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable7);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable8);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable9);
    m_listConsumableProgressbars.push_back(sui->pgbConsumable10);
}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctNormalKPI1->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI1HoverOn, this);
    sui->uctNormalKPI1->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI1HoverOff, this);

    sui->uctNormalKPI2->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI2HoverOn, this);
    sui->uctNormalKPI2->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI2HoverOff, this);

    sui->uctNormalKPI3->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI3HoverOn, this);
    sui->uctNormalKPI3->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI3HoverOff, this);

    sui->uctNormalKPI4->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI4HoverOn, this);
    sui->uctNormalKPI4->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI4HoverOff, this);

    sui->uctNormalKPI5->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI5HoverOn, this);
    sui->uctNormalKPI5->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI5HoverOff, this);

    sui->uctNormalKPI6->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI6HoverOn, this);
    sui->uctNormalKPI6->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI6HoverOff, this);

    sui->uctNormalKPI7->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI7HoverOn, this);
    sui->uctNormalKPI7->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI7HoverOff, this);

    sui->uctNormalKPI8->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI8HoverOn, this);
    sui->uctNormalKPI8->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI8HoverOff, this);

    sui->uctNormalKPI9->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI9HoverOn, this);
    sui->uctNormalKPI9->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI9HoverOff, this);

    sui->uctNormalKPI10->hoverEntered = boost::bind(&DashboardView::onUCTNormalKPI10HoverOn, this);
    sui->uctNormalKPI10->hoverLeft = boost::bind(&DashboardView::onUCTNormalKPI10HoverOff, this);

    sui->uctSystemKPI1->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI1HoverOn, this);
    sui->uctSystemKPI1->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI1HoverOff, this);

    sui->uctSystemKPI2->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI2HoverOn, this);
    sui->uctSystemKPI2->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI2HoverOff, this);

    sui->uctSystemKPI3->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI3HoverOn, this);
    sui->uctSystemKPI3->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI3HoverOff, this);

    sui->uctSystemKPI4->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI4HoverOn, this);
    sui->uctSystemKPI4->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI4HoverOff, this);

    sui->uctSystemKPI5->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI5HoverOn, this);
    sui->uctSystemKPI5->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI5HoverOff, this);

    sui->uctSystemKPI6->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI6HoverOn, this);
    sui->uctSystemKPI6->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI6HoverOff, this);

    sui->uctSystemKPI7->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI7HoverOn, this);
    sui->uctSystemKPI7->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI7HoverOff, this);

    sui->uctSystemKPI8->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI8HoverOn, this);
    sui->uctSystemKPI8->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI8HoverOff, this);

    sui->uctSystemKPI9->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI9HoverOn, this);
    sui->uctSystemKPI9->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI9HoverOff, this);

    sui->uctSystemKPI10->hoverEntered = boost::bind(&DashboardView::onUCTSystemKPI10HoverOn, this);
    sui->uctSystemKPI10->hoverLeft = boost::bind(&DashboardView::onUCTSystemKPI10HoverOff, this);

    sui->uctConsumable1->hoverEntered = boost::bind(&DashboardView::onConsumable1HoverOn, this);
    sui->uctConsumable1->hoverLeft = boost::bind(&DashboardView::onConsumable1HoverOff, this);

    sui->uctConsumable2->hoverEntered = boost::bind(&DashboardView::onConsumable2HoverOn, this);
    sui->uctConsumable2->hoverLeft = boost::bind(&DashboardView::onConsumable2HoverOff, this);

    sui->uctConsumable3->hoverEntered = boost::bind(&DashboardView::onConsumable3HoverOn, this);
    sui->uctConsumable3->hoverLeft = boost::bind(&DashboardView::onConsumable3HoverOff, this);

    sui->uctConsumable4->hoverEntered = boost::bind(&DashboardView::onConsumable4HoverOn, this);
    sui->uctConsumable4->hoverLeft = boost::bind(&DashboardView::onConsumable4HoverOff, this);

    sui->uctConsumable5->hoverEntered = boost::bind(&DashboardView::onConsumable5HoverOn, this);
    sui->uctConsumable5->hoverLeft = boost::bind(&DashboardView::onConsumable5HoverOff, this);

    sui->uctConsumable6->hoverEntered = boost::bind(&DashboardView::onConsumable6HoverOn, this);
    sui->uctConsumable6->hoverLeft = boost::bind(&DashboardView::onConsumable6HoverOff, this);

    sui->uctConsumable7->hoverEntered = boost::bind(&DashboardView::onConsumable7HoverOn, this);
    sui->uctConsumable7->hoverLeft = boost::bind(&DashboardView::onConsumable7HoverOff, this);

    sui->uctConsumable8->hoverEntered = boost::bind(&DashboardView::onConsumable8HoverOn, this);
    sui->uctConsumable8->hoverLeft = boost::bind(&DashboardView::onConsumable8HoverOff, this);

    sui->uctConsumable9->hoverEntered = boost::bind(&DashboardView::onConsumable9HoverOn, this);
    sui->uctConsumable9->hoverLeft = boost::bind(&DashboardView::onConsumable9HoverOff, this);
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOnStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_name->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_category->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_time->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_value->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
    p_unit->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_ON);
}
void IGSxGUI::DashboardView::setNormalKPIUCTHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_category, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_HOVER_OFF);
    p_name->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_PLAIN_TEXT);
    p_category->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
    p_time->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
    p_value->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_PLAIN_TEXT);
    p_unit->setStyleSheetClass(STYLE_UCT_NORMAL_KPI_CATEGORY_GRAY_TEXT);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI1, sui->lblNormalKPI1Name, sui->lblNormalKPI1Category, sui->lblNormalKPI1Time, sui->lblNormalKPI1Value, sui->lblNormalKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI1, sui->lblNormalKPI1Name, sui->lblNormalKPI1Category, sui->lblNormalKPI1Time, sui->lblNormalKPI1Value, sui->lblNormalKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI2, sui->lblNormalKPI2Name, sui->lblNormalKPI2Category, sui->lblNormalKPI2Time, sui->lblNormalKPI2Value, sui->lblNormalKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI2, sui->lblNormalKPI2Name, sui->lblNormalKPI2Category, sui->lblNormalKPI2Time, sui->lblNormalKPI2Value, sui->lblNormalKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI3, sui->lblNormalKPI3Name, sui->lblNormalKPI3Category, sui->lblNormalKPI3Time, sui->lblNormalKPI3Value, sui->lblNormalKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI3HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI3, sui->lblNormalKPI3Name, sui->lblNormalKPI3Category, sui->lblNormalKPI3Time, sui->lblNormalKPI3Value, sui->lblNormalKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI4, sui->lblNormalKPI4Name, sui->lblNormalKPI4Category, sui->lblNormalKPI4Time, sui->lblNormalKPI4Value, sui->lblNormalKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI4HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI4, sui->lblNormalKPI4Name, sui->lblNormalKPI4Category, sui->lblNormalKPI4Time, sui->lblNormalKPI4Value, sui->lblNormalKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI5, sui->lblNormalKPI5Name, sui->lblNormalKPI5Category, sui->lblNormalKPI5Time, sui->lblNormalKPI5Value, sui->lblNormalKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI5HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI5, sui->lblNormalKPI5Name, sui->lblNormalKPI5Category, sui->lblNormalKPI5Time, sui->lblNormalKPI5Value, sui->lblNormalKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI6, sui->lblNormalKPI6Name, sui->lblNormalKPI6Category, sui->lblNormalKPI6Time, sui->lblNormalKPI6Value, sui->lblNormalKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI6HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI6, sui->lblNormalKPI6Name, sui->lblNormalKPI6Category, sui->lblNormalKPI6Time, sui->lblNormalKPI6Value, sui->lblNormalKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI7, sui->lblNormalKPI7Name, sui->lblNormalKPI7Category, sui->lblNormalKPI7Time, sui->lblNormalKPI7Value, sui->lblNormalKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI7HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI7, sui->lblNormalKPI7Name, sui->lblNormalKPI7Category, sui->lblNormalKPI7Time, sui->lblNormalKPI7Value, sui->lblNormalKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI8, sui->lblNormalKPI8Name, sui->lblNormalKPI8Category, sui->lblNormalKPI8Time, sui->lblNormalKPI8Value, sui->lblNormalKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI8HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI8, sui->lblNormalKPI8Name, sui->lblNormalKPI8Category, sui->lblNormalKPI8Time, sui->lblNormalKPI8Value, sui->lblNormalKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI9, sui->lblNormalKPI9Name, sui->lblNormalKPI9Category, sui->lblNormalKPI9Time, sui->lblNormalKPI9Value, sui->lblNormalKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI9HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI9, sui->lblNormalKPI9Name, sui->lblNormalKPI9Category, sui->lblNormalKPI9Time, sui->lblNormalKPI9Value, sui->lblNormalKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxNormalKPI10, sui->lblNormalKPI10Name, sui->lblNormalKPI10Category, sui->lblNormalKPI10Time, sui->lblNormalKPI10Value, sui->lblNormalKPI10Unit);
}
void IGSxGUI::DashboardView::onUCTNormalKPI10HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxNormalKPI10, sui->lblNormalKPI10Name, sui->lblNormalKPI10Category, sui->lblNormalKPI10Time, sui->lblNormalKPI10Value, sui->lblNormalKPI10Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI1HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI1, sui->lblSystemKPI1Name, sui->lblSystemKPI1Category, sui->lblSystemKPI1Time, sui->lblSystemKPI1Value, sui->lblSystemKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI1HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI1, sui->lblSystemKPI1Name, sui->lblSystemKPI1Category, sui->lblSystemKPI1Time, sui->lblSystemKPI1Value, sui->lblSystemKPI1Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI2HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI2, sui->lblSystemKPI2Name, sui->lblSystemKPI2Category, sui->lblSystemKPI2Time, sui->lblSystemKPI2Value, sui->lblSystemKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI2HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI2, sui->lblSystemKPI2Name, sui->lblSystemKPI2Category, sui->lblSystemKPI2Time, sui->lblSystemKPI2Value, sui->lblSystemKPI2Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI3HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI3, sui->lblSystemKPI3Name, sui->lblSystemKPI3Category, sui->lblSystemKPI3Time, sui->lblSystemKPI3Value, sui->lblSystemKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI3HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI3, sui->lblSystemKPI3Name, sui->lblSystemKPI3Category, sui->lblSystemKPI3Time, sui->lblSystemKPI3Value, sui->lblSystemKPI3Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI4HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI4, sui->lblSystemKPI4Name, sui->lblSystemKPI4Category, sui->lblSystemKPI4Time, sui->lblSystemKPI4Value, sui->lblSystemKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI4HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI4, sui->lblSystemKPI4Name, sui->lblSystemKPI4Category, sui->lblSystemKPI4Time, sui->lblSystemKPI4Value, sui->lblSystemKPI4Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI5HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI5, sui->lblSystemKPI5Name, sui->lblSystemKPI5Category, sui->lblSystemKPI5Time, sui->lblSystemKPI5Value, sui->lblSystemKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI5HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI5, sui->lblSystemKPI5Name, sui->lblSystemKPI5Category, sui->lblSystemKPI5Time, sui->lblSystemKPI5Value, sui->lblSystemKPI5Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI6HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI6, sui->lblSystemKPI6Name, sui->lblSystemKPI6Category, sui->lblSystemKPI6Time, sui->lblSystemKPI6Value, sui->lblSystemKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI6HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI6, sui->lblSystemKPI6Name, sui->lblSystemKPI6Category, sui->lblSystemKPI6Time, sui->lblSystemKPI6Value, sui->lblSystemKPI6Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI7HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI7, sui->lblSystemKPI7Name, sui->lblSystemKPI7Category, sui->lblSystemKPI7Time, sui->lblSystemKPI7Value, sui->lblSystemKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI7HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI7, sui->lblSystemKPI7Name, sui->lblSystemKPI7Category, sui->lblSystemKPI7Time, sui->lblSystemKPI7Value, sui->lblSystemKPI7Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI8HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI8, sui->lblSystemKPI8Name, sui->lblSystemKPI8Category, sui->lblSystemKPI8Time, sui->lblSystemKPI8Value, sui->lblSystemKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI8HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI8, sui->lblSystemKPI8Name, sui->lblSystemKPI8Category, sui->lblSystemKPI8Time, sui->lblSystemKPI8Value, sui->lblSystemKPI8Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI9HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI9, sui->lblSystemKPI9Name, sui->lblSystemKPI9Category, sui->lblSystemKPI9Time, sui->lblSystemKPI9Value, sui->lblSystemKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI9HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI9, sui->lblSystemKPI9Name, sui->lblSystemKPI9Category, sui->lblSystemKPI9Time, sui->lblSystemKPI9Value, sui->lblSystemKPI9Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI10HoverOn()
{
    setNormalKPIUCTHoverOnStyle(sui->gbxSystemKPI10, sui->lblSystemKPI10Name, sui->lblSystemKPI10Category, sui->lblSystemKPI10Time, sui->lblSystemKPI10Value, sui->lblSystemKPI10Unit);
}
void IGSxGUI::DashboardView::onUCTSystemKPI10HoverOff()
{
    setNormalKPIUCTHoverOffStyle(sui->gbxSystemKPI10, sui->lblSystemKPI10Name, sui->lblSystemKPI10Category, sui->lblSystemKPI10Time, sui->lblSystemKPI10Value, sui->lblSystemKPI10Unit);
}
void IGSxGUI::DashboardView::setConsumableHoverOnStyle(SUI::GroupBox* p_GroupBox,  SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_name->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_time->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_value->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
    p_unit->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_ON);
}

void IGSxGUI::DashboardView::setConsumableHoverOffStyle(SUI::GroupBox* p_GroupBox, SUI::Label* p_name, SUI::Label* p_time, SUI::Label* p_value, SUI::Label* p_unit) const
{
    p_GroupBox->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_HOVER_OFF);
    p_name->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT);
    p_time->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT);
    p_value->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_PLAIN_TEXT);
    p_unit->setStyleSheetClass(STYLE_UCT_CONSUMABLE_KPI_GRAY_TEXT);
}
void IGSxGUI::DashboardView::onConsumable1HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable1HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable1, sui->lblConsumable1Name, sui->lblConsumable1Time, sui->lblConsumable1Value, sui->lblConsumable1Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable2HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable2, sui->lblConsumable2Name, sui->lblConsumable2Time, sui->lblConsumable2Value, sui->lblConsumable2Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable3HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable3, sui->lblConsumable3Name, sui->lblConsumable3Time, sui->lblConsumable3Value, sui->lblConsumable3Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable4HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable4, sui->lblConsumable4Name, sui->lblConsumable4Time, sui->lblConsumable4Value, sui->lblConsumable4Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable5HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable5, sui->lblConsumable5Name, sui->lblConsumable5Time, sui->lblConsumable5Value, sui->lblConsumable5Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable6HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable6, sui->lblConsumable6Name, sui->lblConsumable6Time, sui->lblConsumable6Value, sui->lblConsumable6Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable7HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable7, sui->lblConsumable7Name, sui->lblConsumable7Time, sui->lblConsumable7Value, sui->lblConsumable7Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable8HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable8, sui->lblConsumable8Name, sui->lblConsumable8Time, sui->lblConsumable8Value, sui->lblConsumable8Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::onConsumable9HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable9, sui->lblConsumable9Name, sui->lblConsumable9Time, sui->lblConsumable9Value, sui->lblConsumable9Unit);
}
void IGSxGUI::DashboardView::onConsumable10HoverOn()
{
    setConsumableHoverOnStyle(sui->gbxConsumable10, sui->lblConsumable10Name, sui->lblConsumable10Time, sui->lblConsumable10Value, sui->lblConsumable10Unit);
}
void IGSxGUI::DashboardView::onConsumable10HoverOff()
{
    setConsumableHoverOffStyle(sui->gbxConsumable10, sui->lblConsumable10Name, sui->lblConsumable10Time, sui->lblConsumable10Value, sui->lblConsumable10Unit);
}
void IGSxGUI::DashboardView::init()
{
    sui->scbTimeSlider->setMaxValue(360);
    sui->scbTimeSlider->setMinValue(0);
    sui->scbTimeSlider->setValue(m_slider_value_backup);
    sui->scbTimeSlider->valueChanged =  boost::bind(&DashboardView::onSliderValueChanged, this);
    buildTmerDisplays();
    buildHistogramGraphs();
    buildKPITable();
    buildConsumableTable();
}
