/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsView.cpp
| Author       : Venugopal S
| Description  : Implementation of Advanced Diagnostics view
|
| ! \file        IGSxGUIxAdvancedDiagnosticsView.cpp
| ! \brief       Implementation of Advanced Diagnostics view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxAdvancedDiagnosticsView.hpp"
#include "IGSxGUIxMoc_AdvancedDiagnosticsView.hpp"
#include "IGSxCOMMON.hpp"
#include <SUILabel.h>
#include <SUIButton.h>
#include <SUITableWidget.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AdvancedDiagnosticsView::LOAD_FILE_ADVANCED_DIAGNOSTICS = IGS::Resource::path("IGSxGUIxAdvancedDiagnosticsView.xml");
const std::string IGSxGUI::AdvancedDiagnosticsView::STR_STOPPED = "STOPPED : ";
const std::string IGSxGUI::AdvancedDiagnosticsView::STR_STARTED = "Started : ";
const std::string IGSxGUI::AdvancedDiagnosticsView::STR_ADT_LIST = "ADT List";
const std::string IGSxGUI::AdvancedDiagnosticsView::STR_INCORRECT_SELECTION = "Selection not correct";

IGSxGUI::AdvancedDiagnosticsView::AdvancedDiagnosticsView(ADTManager* pADTManager) :
    sui(new SUI::AdvancedDiagnosticsView)
{
    m_presenter = new AdvancedDiagnosticsPresenter(this,pADTManager);
}
IGSxGUI::AdvancedDiagnosticsView::~AdvancedDiagnosticsView()
{
    delete m_presenter;
    delete sui;
}

void IGSxGUI::AdvancedDiagnosticsView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(LOAD_FILE_ADVANCED_DIAGNOSTICS.c_str(),MainScreenContainer);

    sui->btnStartADT->clicked = boost::bind(&AdvancedDiagnosticsView::onBtnStartADTPressed, this);

    std::vector<ADT* > adts = m_presenter->getADTs();

    for (size_t i = 0; i < adts.size(); i++)
    {
        ADT* adt = adts[i];

        std::list<std::string> listRowData;

        listRowData.push_back(adt->getName());
        sui->tawADT->insertRows(i+1,1);
        sui->tawADT->addData(i+1,listRowData);
    }


}

void IGSxGUI::AdvancedDiagnosticsView::setActive(bool /*bActive*/)
{

}



void IGSxGUI::AdvancedDiagnosticsView::onBtnStartADTPressed()
{
    sui->lblADTStatus->clearText();
    std::list<std::string> items = sui->tawADT->getSelectedItems();

    if(items.size() < 1)
    {
        sui->lblADTStatus->setText(STR_INCORRECT_SELECTION);
        return;
    }
    std::string strSelectedRow = items.front();
    //Indirect way to get the selected row item
    //Interface not available now, to get the selected row item text based on selection
    strSelectedRow.erase(0,11);
    strSelectedRow.erase(strSelectedRow.size()-2,strSelectedRow.size());
    std::string selectedText = sui->tawADT->getItemText((boost::lexical_cast<int>(strSelectedRow)-1),0);

    if(selectedText == STR_ADT_LIST)
    {
        sui->lblADTStatus->setText(STR_INCORRECT_SELECTION);
    }
    else
    {
        if(m_presenter->startADT(selectedText))
        {
            sui->lblADTStatus->setText(STR_STARTED + selectedText);
        }
    }
}

