/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpi.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for KPI
|
| ! \file        IGSxGUIxKpi.hpp
| ! \brief       Header file for KPI
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_KPI_HPP
#define IGSXKPI_KPI_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2/signal.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxKpiValueSet.hpp"

using std::string;
using std::vector;

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class KPI
{
 public:
    explicit KPI(IGSxKPI::KPIDefinition kpiDefinition);
    virtual ~KPI();

    IGSxGUI::KPIValueSet *getValueSet(const std::string& name) const;
    std::vector<KPIValueSet *> getValueSets() const;

    string getName() const;
    string getDescription() const;

    string getDisplayName() const;
    string getFactor() const;
    string getType() const;
    string getMin() const;
    string getMax() const;

    void setDisplayName(std::string displayName);
    void setFactor(std::string factor);
    void setType(std::string type);
    void setMin(std::string min);
    void setMax(std::string max);

    void updateValue(IGSxKPI::KPIData kpiData);
    void updateValues(IGSxKPI::KPIDataList kpiDataList);

    typedef boost::signals2::signal<void (string, string, string, vector<double>)> ValueChanged;
    typedef ValueChanged::slot_type ValueChangedCallback;

    boost::signals2::connection registerForValueChanged(const ValueChangedCallback& cb);

 private:
    KPI(KPI const &);
    KPI& operator=(KPI const &);

    std::string m_name;  // KPI name
    std::string m_desc;  // KPI description

    std::string m_displayName;  // Display name
    std::string m_factor;       // Factor
    std::string m_type;         // Type
    std::string m_min;          //Min
    std::string m_max;          //Max

    vector<KPIValueSet*> m_KPIValueSets;
    ValueChanged m_valueChanged;
};
}  // namespace IGSxGUI
#endif  // IGSXKPI_KPI_HPP
