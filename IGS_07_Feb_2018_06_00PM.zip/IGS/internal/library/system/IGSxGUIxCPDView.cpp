/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/algorithm/string/split.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <algorithm>
#include <string>
#include <vector>
#include <list>
#include <numeric>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include <FWQxWidgets/SUIGraphicsView.h>
#include <FWQxGraphicsItems/SUIGraphicsScene.h>
#include <FWQxWidgets/SUILabel.h>
#include <FWQxWidgets/SUIGroupBox.h>
#include <FWQxWidgets/SUITableWidget.h>
#include <FWQxWidgets/SUIWebView.h>
#include <FWQxCore/SUIResourcePath.h>
#include <FWQxWidgets/SUIDialog.h>
#include <FWQxCore/SUIObjectList.h>
#include <FWQxWidgets/SUIButton.h>
#include <FWQxWidgets/SUIRadioButton.h>
#include <FWQxWidgets/SUIUserControl.h>
#include <FWQxUtils/SUITimer.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"
#include "IGSxGUIxDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = "IGSxGUIxCPD.xml";
const std::string IGSxGUI::CPDView::STRING_EMPTY = "";
const std::string IGSxGUI::CPDView::STRING_SINGLESPACE = " ";
const char IGSxGUI::CPDView::NEWLINE_CHAR = '\n';
const std::string IGSxGUI::CPDView::STRING_ALL = "All";
const std::string IGSxGUI::CPDView::STRING_ALL_CPDS = "ALL CPDs";
const std::string IGSxGUI::CPDView::STRING_CALIBRATION = "Calibration";
const std::string IGSxGUI::CPDView::STRING_PERFORMANCE = "Performance";
const std::string IGSxGUI::CPDView::STRING_DIAGNOSTICS = "Diagnostics";
const std::string IGSxGUI::CPDView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::CPDView::STRING_CPDVIEW_SHOWN = "CPDView is shown.";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BUTTON_COLOR = "#1b3e92";
const std::string IGSxGUI::CPDView::STRING_CPDSUBSYSTEM_STYLE = "adtsubsystem";
const std::string IGSxGUI::CPDView::STRING_SLASH = " / ";
const std::string IGSxGUI::CPDView::STYLE_ASML_COLORORANGE = "#FF7F45";
const std::string IGSxGUI::CPDView::STYLE_AWESOME_ICONCOLOR = "#4d4d4d";
const std::string IGSxGUI::CPDView::STYLE_AWESOMEACTIVE_ICONCOLOR = "#8c8c8c";
const std::string IGSxGUI::CPDView::STYLE_HOVERON = "hoverOn";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPDLABEL_BLACK = "BlackLabel16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPDLABEL_GREY = "GreyLabel14PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ASML_ORANGELABEL = "OrangeLabel";
const std::string IGSxGUI::CPDView::STYLE_ASML_ORANGEBUTTON = "ASMLOrangeButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_ASML_DARKBLUEBUTTON = "ASMLDarkBlueButton16PxRoboRegular";
const std::string IGSxGUI::CPDView::STYLE_INACTIVE_CPD = "InactiveStatusDisplayLabel";
const std::string IGSxGUI::CPDView::STYLE_ACTIVECPD_GROUPBOX = "BlueBorderGroupBox";
const std::string IGSxGUI::CPDView::STYLE_INACTIVE_GROUPBOX = "GreyBorderGroupBox";
const std::string IGSxGUI::CPDView::CUSTOM_STYLESHEET = "customCss.css";
const std::string IGSxGUI::CPDView::STRING_CPDLOG1 = "Start CPD pressed: ";
const std::string IGSxGUI::CPDView::STRING_CPDLOG2 = ",CPDType: ";
const std::string IGSxGUI::CPDView::STRING_NOACTIVE_CPD = " There is no active CPD";
const std::string IGSxGUI::CPDView::STRING_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S";
const std::string IGSxGUI::CPDView::STRING_MAINTENANCE = "Maintenance/Calibration";
const std::string IGSxGUI::CPDView::STRING_TESTREPORTS = " / Test reports";
const std::string IGSxGUI::CPDView::STRING_CLOSEREPORT = "Close report";
const std::string IGSxGUI::CPDView::STRING_CLOSEREPORTS = "Close all reports";
const std::string IGSxGUI::CPDView::STRING_VIEW_SELECTED_REPORT = "View selected report...";
const std::string IGSxGUI::CPDView::STRING_VIEW_SELECTED_REPORTS = "View selected reports...";
const std::string IGSxGUI::CPDView::IMAGE_LOGO = "IGSxGUIxSystem_asml.png";
const int IGSxGUI::CPDView::MAX_INITIAL_ROWCOUNT = 11;
const int IGSxGUI::CPDView::CPDSUBSYSTEM_CLOSEBUTTON_SIZE = 12;
const int IGSxGUI::CPDView::AWESOME_ICON_SIZE = 14;
const int IGSxGUI::CPDView::AWESOME_ANGLE_SIZE = 22;
const int IGSxGUI::CPDView::AWESOME_CLOSE_SIZE = 30;
const int IGSxGUI::CPDView::AWESOME_ACTIVEANGLE_SIZE = 16;
const int IGSxGUI::CPDView::CPDTABLE_ROW_SIZE = 62;
const int IGSxGUI::CPDView::NORMAL_SUBSYSTEM_ROW_SIZE = 40;
const int IGSxGUI::CPDView::EXTENDED_SUBSYSTEM_ROW_SIZE = 60;
const int IGSxGUI::CPDView::HOURS_PER_DAY = 24;
const int IGSxGUI::CPDView::NUMBER_OF_DAYS = 4;
const int IGSxGUI::CPDView::SECONDS_PER_HOUR = 3600;
const int IGSxGUI::CPDView::MAX_NUMBER_OF_SELECTED_ROWS = 2;
const int IGSxGUI::CPDView::REQUIRED_SPACE_FOUR = 4;
const int IGSxGUI::CPDView::REQUIRED_SPACE_FIVE = 5;
const int IGSxGUI::CPDView::TIME_DEFERRED_LOADING = 50;
const std::string::size_type IGSxGUI::CPDView::MAX_SUBSYSTEM_CHARS_PER_CELL = 21;
const std::string::size_type IGSxGUI::CPDView::MIN_SUBSYSTEM_CHARS_PER_LINE = 3;
const int IGSxGUI::CPDView::CPD_LIST_INITIAL_BATCH_SIZE = 11;

namespace IGSxGUI
{

bool CPDComparator(const CPD *leftCPD, const CPD *rightCPD)
{
    return (leftCPD->getName().compare(rightCPD->getName()) <= 0);
}

int subSystemCountAccumulator(int value, subSystemCount obj)
{
    return (value + obj.count);
}

}  // namespace  IGSxGUI

IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_selectedCPD(""),
    m_selectedSubSystem(""),
    m_countAllCPD(0),
    m_countCalibration(0),
    m_countPerformance(0),
    m_countDiagnostics(0),
    m_selectedCPDRowNum(-1),
    m_selectedSubsystemRowNum(-1),
    m_isReloading(false),
    m_isDescFolded(true),
    m_isCPDActivated(false),
    m_isTestReportFolded(true),
    m_isCloseButtonPressed(false),
    m_isInternalCallToSubsystemPressed(false),
    m_mainScreenContainer(NULL),
    m_cpdTimer(SUI::Timer::createTimer())
{
    m_presenter = new CPDPresenter(this, pCPDManager);
    m_cpdTimer->timeout = boost::bind(&CPDView::onTimeout, this);
}

IGSxGUI::CPDView::~CPDView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::CPDView::show(SUI::Container* mainScreenContainer, bool bIsFirstTimeDisplay)
{
    m_mainScreenContainer = mainScreenContainer;
    sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), mainScreenContainer);
    setHandlers();
    sui->lblNoReports->setVisible(false);

    if (bIsFirstTimeDisplay) {
        init();
    } else {
        reload();
    }
    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
    IGS_INFO(STRING_CPDVIEW_SHOWN);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->tawCPDSubsystem->rowClicked = boost::bind(&CPDView::onSubsystemPressed, this);
    sui->btnOpenCPD->clicked = boost::bind(&CPDView::onOpenCPDClicked, this);
    sui->btnTestReports->clicked = boost::bind(&CPDView::onBtnTestReportsClicked, this);
    sui->btnTestReports->hoverEntered = boost::bind(&CPDView::onBtnTestReportHoverEntered, this);
    sui->btnTestReports->hoverLeft = boost::bind(&CPDView::onBtnTestReportHoverLeft, this);
    sui->btnDescription->clicked = boost::bind(&CPDView::onBtnDescriptionClicked, this);
    sui->btnDescription->hoverEntered = boost::bind(&CPDView::onBtnDescriptionHoverEntered, this);
    sui->btnDescription->hoverLeft = boost::bind(&CPDView::onBtnDescriptionHoverLeft, this);
    sui->btnViewSelectedReports->clicked = boost::bind(&CPDView::onBtnViewSelectedReportsPressed, this);
    sui->rbtnAll->checkStateChanged = boost::bind(&CPDView::onRadioButtonAllPressed, this);
    sui->rbtnCalibration->checkStateChanged = boost::bind(&CPDView::onRadioButtonCalibrationPressed, this);
    sui->rbtnPerformance->checkStateChanged = boost::bind(&CPDView::onRadioButtonPerformancePressed, this);
    sui->rbtnDiagnostics->checkStateChanged = boost::bind(&CPDView::onRadioButtonDiagnosticsPressed, this);
    sui->uctCloseReports->clicked = boost::bind(&CPDView::onUCTCloseReportsClicked, this);
    sui->uctCloseReports->hoverEntered = boost::bind(&CPDView::onUCTCloseReportsHoverOn, this);
    sui->uctCloseReports->hoverLeft = boost::bind(&CPDView::onUCTCloseReportsHoverOff, this);
    //sui->uctCloseReports->pressed = boost::bind(&CPDView::onUCTCloseReportsPressed, this);    // TODO: PTOX - This requires GUI FW Sprint 50 or higher before it can be enabled
}

void IGSxGUI::CPDView::loadSubSystemTable()
{
    std::vector<IGSxGUI::subSystemCount> listSubsystemCount;
    container subsystem;

    m_listSubsystems.clear();

    std::vector<CPD*> listSubsystemCPDs = m_presenter->getCPDs();

    for (size_t i = 0 ; i < listSubsystemCPDs.size(); i++)
    {
        subsystem.name = listSubsystemCPDs[i]->getSubsystem();
        subsystem.cpd = listSubsystemCPDs[i];
        m_listStringSubsystem.push_back(listSubsystemCPDs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(m_listStringSubsystem.begin(), m_listStringSubsystem.end());
    m_listStringSubsystem.erase(unique(m_listStringSubsystem.begin(), m_listStringSubsystem.end()), m_listStringSubsystem.end());

    for (size_t i = 0 ; i < m_listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            if (m_listStringSubsystem[i] == m_listSubsystems[j].name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = m_listStringSubsystem[i];
        subsyscount.count = count;

        listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;

    // All CPDs
    sui->tawCPDSubsystem->setItemText(0, 1, STRING_ALL_CPDS);
    int totalCPDs = std::accumulate(listSubsystemCount.begin(), listSubsystemCount.end(), 0, subSystemCountAccumulator);
    std::string  totalCPDText = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(totalCPDs) + STRING_CLOSE_BRACKET;
    sui->tawCPDSubsystem->setItemText(0, 2, totalCPDText);
    for (size_t i = 0; i < listSubsystemCount.size(); i++) {
        sui->tawCPDSubsystem->appendRow();
        subSystemCount subsyscount = listSubsystemCount[i];
        std::string subsys = STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;
        listTestReportSubSystemItems.push_back(subsys);
        int translatedIndex = static_cast<int>(i) + 1;
        if (subsyscount.nameSubsystem.length() < MAX_SUBSYSTEM_CHARS_PER_CELL)
        {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, translatedIndex, NORMAL_SUBSYSTEM_ROW_SIZE);
        } else {
            IGSxGUI::Util::setRowHeight(sui->tawCPDSubsystem, translatedIndex, EXTENDED_SUBSYSTEM_ROW_SIZE);
        }
        setValuesToRowWidgets(subsys, translatedIndex, subsyscount);
    }
}


void IGSxGUI::CPDView::intersectCPDs(std::vector<IGSxGUI::CPD *> listTestTypeCPDs, std::vector<IGSxGUI::CPD *> listSubSystemCPDs)
{
    m_listCPD.clear();

    if (listSubSystemCPDs.size() > 1)
    {
        std::sort(listSubSystemCPDs.begin(), listSubSystemCPDs.end());
    }
    if (listTestTypeCPDs.size() > 1)
    {
        std::sort(listTestTypeCPDs.begin(), listTestTypeCPDs.end());
    }

    if ((listSubSystemCPDs.size() > 0) && (listTestTypeCPDs.size() > 0))
    {
        std::set_intersection(listSubSystemCPDs.begin(), listSubSystemCPDs.end(), listTestTypeCPDs.begin(), listTestTypeCPDs.end(), std::back_inserter(m_listCPD));
    } else if (listSubSystemCPDs.size() > 0) {
        m_listCPD = listSubSystemCPDs;
    } else {
        m_listCPD = listTestTypeCPDs;
    }
}

void IGSxGUI::CPDView::loadTestTypes()
{
    m_listTestTypes.clear();
    container testtype;
    for (size_t i = 0 ; i < m_listCPD.size(); i++)
    {
        testtype.name = m_listCPD[i]->getTestType();
        testtype.cpd = m_listCPD[i];
        m_listTestTypes.push_back(testtype);
    }
}


std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestCPDsByName(const std::string &testtypeName) const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++)
    {
        IGSxGUI::container testtype = m_listTestTypes[i];

        if (testtype.name == testtypeName)
        {
            listTestTypeCPDs.push_back(testtype.cpd);
        }
    }
    return listTestTypeCPDs;
}


std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getSelectedSubSystemCPDs() const
{
    std::vector<IGSxGUI::CPD*> listSubsystemCPDs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
        container subsys = m_listSubsystems[i];

        std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
        if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
        {
            listSubsystemCPDs.push_back(subsys.cpd);
        }
    }
    return listSubsystemCPDs;
}


void IGSxGUI::CPDView::countSubSystemsTesttype(bool selectedSystemsOnly)
{
    m_countAllCPD = 0;
    m_countCalibration = 0;
    m_countPerformance = 0;
    m_countDiagnostics = 0;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++) {
        container subsys = m_listSubsystems[i];
        if ((!selectedSystemsOnly)  || (subsys.name == m_selectedSubSystem)) {
            if (subsys.cpd->getTestType() == STRING_CALIBRATION) {
                ++m_countCalibration;
            } else if (subsys.cpd->getTestType() == STRING_PERFORMANCE) {
                ++m_countPerformance;
            } else if (subsys.cpd->getTestType() == STRING_DIAGNOSTICS) {
                ++m_countDiagnostics;
            }
            ++m_countAllCPD;
        }
    }
}


void IGSxGUI::CPDView::countAllSubSystemsTesttype()
{
    countSubSystemsTesttype(false);
}

void IGSxGUI::CPDView::countSelectedSubSystemsTesttype()
{
    countSubSystemsTesttype(true);
}


void IGSxGUI::CPDView::loadCPDTypeRadios()
{
    if (m_selectedSubSystem != STRING_ALL_CPDS)
    {
        countSelectedSubSystemsTesttype();
    } else {
        countAllSubSystemsTesttype();
    }

    sui->rbtnAll->setText(STRING_ALL + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countAllCPD) + STRING_CLOSE_BRACKET);
    sui->rbtnCalibration->setText(getRequiredSpace(REQUIRED_SPACE_FOUR) + STRING_CALIBRATION + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countCalibration) + STRING_CLOSE_BRACKET);
    sui->rbtnPerformance->setText(getRequiredSpace(REQUIRED_SPACE_FIVE) + STRING_PERFORMANCE + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countPerformance) + STRING_CLOSE_BRACKET);
    sui->rbtnDiagnostics->setText(getRequiredSpace(REQUIRED_SPACE_FOUR) + STRING_DIAGNOSTICS + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_countDiagnostics) + STRING_CLOSE_BRACKET);
}

void IGSxGUI::CPDView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::CPDView::updateStatus(const std::string& strCPD, const IGS::Result& /*result*/)
{
    m_isCPDActivated = false;

    sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
    sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);
    sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
    sui->lblActiveCPDDescription->setVisible(false);
    sui->lblActiveCPDTestType->setVisible(false);
    sui->lblActiveCPDTestTypeIcon->setVisible(false);
    sui->lblActiveArrow->setVisible(false);

    sui->btnOpenCPD->setEnabled(true);
    if ((m_selectedCPD == strCPD) && (!m_isTestReportFolded))
    {
        this->loadTestReportTable();
    }
}

std::string IGSxGUI::CPDView::formatSubsystemName(const std::string& subsystemname)
{
    std::string strMultiLine = subsystemname;
    if (subsystemname.length() > MAX_SUBSYSTEM_CHARS_PER_CELL)
    {
        for (int i = static_cast<int>(MAX_SUBSYSTEM_CHARS_PER_CELL) - 1; i > static_cast<int>(MIN_SUBSYSTEM_CHARS_PER_LINE); --i)
        {
            char ch = subsystemname.at(i);
            if (ch == ' ')
            {
                strMultiLine = subsystemname.substr(0, i) + NEWLINE_CHAR +
                        formatSubsystemName(subsystemname.substr(i + 1));
                break;
            }
            if (::isupper(ch))
            {
                strMultiLine = subsystemname.substr(0, i) + NEWLINE_CHAR +
                        formatSubsystemName(subsystemname.substr(i));
                break;
            }
        }
        if (strMultiLine == subsystemname)
        {
            // no spaces or capitals found in the last 15 characters: split at char 21
            strMultiLine = subsystemname.substr(0, MAX_SUBSYSTEM_CHARS_PER_CELL) + NEWLINE_CHAR +
                    formatSubsystemName(subsystemname.substr(MAX_SUBSYSTEM_CHARS_PER_CELL));
        }
    }
    return strMultiLine;
}

void IGSxGUI::CPDView::setValuesToRowWidgets(const std::string &subsys, size_t i, subSystemCount subsyscount)
{
    sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 1, formatSubsystemName(subsyscount.nameSubsystem));
    sui->tawCPDSubsystem->setItemText(static_cast<int>(i), 2, subsys);

    IGSxGUI::Util::setColor(sui->tawCPDSubsystem->getWidgetItem(static_cast<int>(i), 1), SUI::ColorEnum::White, sui->tawCPDSubsystem);
}

std::string IGSxGUI::CPDView::getRequiredSpace(size_t count)
{
    std::string emptySpace;
    for (size_t i = 0 ; i < count; i++)
    {
        emptySpace.append(STRING_SINGLESPACE);
    }
    return emptySpace;
}

void IGSxGUI::CPDView::onSubsystemPressed()
{
    if (m_isCloseButtonPressed)
    {
        return;
    }
    if (!m_isInternalCallToSubsystemPressed)
    {
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
    }

    std::vector<int> items = sui->tawCPDSubsystem->getSelectedRows();
    if (items.size() > 0) {
        m_selectedSubsystemRowNum = items[0];
        if (m_selectedSubsystemRowNum == 0) {
            m_selectedSubSystem = STRING_ALL_CPDS;
            m_listCPD = m_presenter->getCPDs();
            sui->lblAllCPDs->setText(STRING_ALL_CPDS);
        } else {
            m_selectedSubSystem = m_listStringSubsystem[m_selectedSubsystemRowNum - 1];
            sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);
        }
        loadCPDTypeRadios();
        setSelectedCPDTestType();
        loadCPDTableByType(m_cpdTypeSelected, false);
        showRightPane(false, "");
    }
}

void IGSxGUI::CPDView::onCPDUCTHoverEntered(int index)
{
    if (m_selectedCPDRowNum != index)
    {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOnStyle(widget);
    }
}

void IGSxGUI::CPDView::onCPDUCTHoverLeft(int index)
{
    if (m_selectedCPDRowNum != index)
    {
        SUI::Widget *widget = sui->tawCPD->getWidgetItem(index, 0);
        IGSxGUI::Util::setUCTHoverOffStyle(widget);
    }
}

void IGSxGUI::CPDView::onRadioButtonAllPressed()
{
    if (sui->rbtnAll->isChecked())
    {
        loadCPDTableByType(TYPE_NONE, m_isReloading);
        m_cpdTypeSelected = TYPE_NONE;
        showRightPane(false, "");
    }
}

void IGSxGUI::CPDView::onRadioButtonCalibrationPressed()
{
    if (sui->rbtnCalibration->isChecked())
    {
        loadCPDTableByType(TYPE_CALIBRATION, m_isReloading);
        m_cpdTypeSelected = TYPE_CALIBRATION;
        showRightPane(false, "");
    }
}

void IGSxGUI::CPDView::onRadioButtonPerformancePressed()
{
    if (sui->rbtnPerformance->isChecked())
    {
        loadCPDTableByType(TYPE_PERFORMANCE, m_isReloading);
        m_cpdTypeSelected = TYPE_PERFORMANCE;
        showRightPane(false, "");
    }
}

void IGSxGUI::CPDView::onRadioButtonDiagnosticsPressed()
{
    if (sui->rbtnDiagnostics->isChecked())
    {
        loadCPDTableByType(TYPE_DIAGNOSTICS, m_isReloading);
        m_cpdTypeSelected = TYPE_DIAGNOSTICS;
        showRightPane(false, "");
    }
}

void IGSxGUI::CPDView::loadCPDTableByType(CPD_TYPE cpdType, bool isReloading)
{
    switch (cpdType)
    {
        case TYPE_CALIBRATION:
            intersectCPDs(getTestCPDsByName(STRING_CALIBRATION), getSelectedSubSystemCPDs());
            break;
        case TYPE_PERFORMANCE:
            intersectCPDs(getTestCPDsByName(STRING_PERFORMANCE), getSelectedSubSystemCPDs());
            break;
        case TYPE_DIAGNOSTICS:
            intersectCPDs(getTestCPDsByName(STRING_DIAGNOSTICS), getSelectedSubSystemCPDs());
            break;
        case TYPE_NONE:
            intersectCPDs(m_presenter->getCPDs(), getSelectedSubSystemCPDs());
            break;
        default:
            break;
    }
    loadCPDTable(m_listCPD, isReloading);
}

void IGSxGUI::CPDView::initCommon()
{
    sui->tawCPDSubsystem->showGrid(false);
    sui->tawCPD->showGrid(false);
    sui->tawTestReports->showGrid(false);
    sui->gbxTestReportPage->setVisible(false);
    sui->gbxFrontPage->setVisible(true);

    IGSxGUI::Util::addCustomStylesheet(sui->wvwCPDHTMLDescription, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwSingleTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwLeftTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));
    IGSxGUI::Util::addCustomStylesheet(sui->wvwRightTestReport, SUI::ResourcePath::getResourceFile(CUSTOM_STYLESHEET));

    IGSxGUI::Util::setAwesome(sui->lblIconCalibration, IGSxGUI::AwesomeIcon::AI_fa_crosshairs, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblIconPerformance, IGSxGUI::AwesomeIcon::AI_fa_areachart, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblIconDiagnostics, IGSxGUI::AwesomeIcon::AI_fa_stethoscope, STYLE_AWESOME_ICONCOLOR, AWESOME_ICON_SIZE);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);

    sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
    sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
    sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);

    loadSubSystemTable();
}

void IGSxGUI::CPDView::loadCPDTable(std::vector<CPD*> listCPD, bool isReloading)
{
    sui->tawCPD->setVisible(false);
    if (listCPD.size() > 0)
    {
        std::sort(listCPD.begin(), listCPD.end(), IGSxGUI::CPDComparator);

        int currentRowCount = sui->tawCPD->rowCount();
        int intermediateRowCount = std::min(static_cast<int>(listCPD.size()), currentRowCount + MAX_INITIAL_ROWCOUNT);
        int targetRowCount = static_cast<int>(listCPD.size());

        // add first batch: fill up an additional 11 items, to show a full screen with a scrollbar
        for (int i = currentRowCount ; i < intermediateRowCount; i++)
        {
            sui->tawCPD->appendRow();
        }

        // fill the first batch
        for (int row = 0; row < intermediateRowCount; ++row)
        {
            SUI::Widget *widget = sui->tawCPD->getWidgetItem(row, 0);
            IGSxGUI::Util::setCPDUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableCPDRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&CPDView::onCPDUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&CPDView::onCPDUCTHoverLeft, this, row);

            IGSxGUI::Util::setTextToCPDUserControl(widget, 0, listCPD[row]->getName());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 1, listCPD[row]->getDescription());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 3, listCPD[row]->getTestType());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 4, STRING_EMPTY);
            IGSxGUI::Util::setRowHeight(sui->tawCPD, row, CPDTABLE_ROW_SIZE);
        }

        // in case there are more rows available than needed, set the height of these rows to zero
        for (int row = intermediateRowCount; row < sui->tawCPD->rowCount(); ++row)
        {
            IGSxGUI::Util::setRowHeight(sui->tawCPD, row, 0);
        }
        sui->tawCPD->setVisible(true);

        // there may be more data needed then currently available, we will save them in a list and come back later
        if (intermediateRowCount < targetRowCount)
        {
            for (int row = intermediateRowCount; row < targetRowCount; ++row)
            {
                m_listCPDDeferred.push_back(listCPD[row]);
            }
            m_cpdTimer->start(TIME_DEFERRED_LOADING);
        }

        IGSxGUI::Util::clearSelection(sui->tawCPD);

        if (!isReloading)
        {
            m_selectedCPD = "";
            m_selectedCPDRowNum = -1;
        }
    }
}

void IGSxGUI::CPDView::onTimeout()
{
    m_cpdTimer->stop();

    void* dPointer = sui->tawCPD;
    sui->loadObjects(m_mainScreenContainer->getObjectList());
    if(sui->tawCPD == dPointer) {
        // add the final batch to the existing list
        int initialRowCount = sui->tawCPD->rowCount();

        for (size_t row = 0 ; row < m_listCPDDeferred.size(); row++)
        {
            sui->tawCPD->appendRow();

            SUI::Widget *widget = sui->tawCPD->getWidgetItem(row + initialRowCount, 0);
            IGSxGUI::Util::setCPDUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableCPDRowPressed, this, row + initialRowCount);
            usercontrol->hoverEntered = boost::bind(&CPDView::onCPDUCTHoverEntered, this, row + initialRowCount);
            usercontrol->hoverLeft = boost::bind(&CPDView::onCPDUCTHoverLeft, this, row + initialRowCount);

            IGSxGUI::Util::setTextToCPDUserControl(widget, 0, m_listCPDDeferred[row]->getName());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 1, m_listCPDDeferred[row]->getDescription());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 3, m_listCPDDeferred[row]->getTestType());
            IGSxGUI::Util::setTextToCPDUserControl(widget, 4, STRING_EMPTY);
            IGSxGUI::Util::setRowHeight(sui->tawCPD, row + initialRowCount, CPDTABLE_ROW_SIZE);
        }
    }
    m_listCPDDeferred.clear();

    if (m_selectedCPDRowNum >= MAX_INITIAL_ROWCOUNT)
    {
        if (m_isReloading)
        {
            if (m_selectedCPD != "")
            {
                IGSxGUI::Util::setCPDUCTClickedStyle(sui->tawCPD->getWidgetItem(m_selectedCPDRowNum, 0));
                showRightPane(true, m_selectedCPD);
            } else {
                showRightPane(false, m_selectedCPD);
            }
            reloadActiveCPD();
            sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);

            m_isReloading = false;
        }
    }
}


void IGSxGUI::CPDView::onTableCPDRowPressed(int rowindex)
{
    SUI::Widget *widget = sui->tawCPD->getWidgetItem(rowindex, 0);

    if (m_selectedCPDRowNum == rowindex)
    {
        m_selectedCPD = "";
        m_selectedCPDRowNum = -1;
        IGSxGUI::Util::setCPDUCTNormalStyle(widget);
        showRightPane(false, m_selectedCPD);

    } else {
        m_selectedCPDRowNum = rowindex;
        m_selectedCPD = IGSxGUI::Util::getADTCPDNameFromUserControl(widget);
        boost::trim(m_selectedCPD);

        for (int i = 0; i < sui->tawCPD->rowCount(); ++i )
        {
            IGSxGUI::Util::setCPDUCTNormalStyle(sui->tawCPD->getWidgetItem(i, 0));
        }
        IGSxGUI::Util::setCPDUCTClickedStyle(sui->tawCPD->getWidgetItem(rowindex, 0));
        showRightPane(true, m_selectedCPD);
    }
}

void IGSxGUI::CPDView::onBtnDescriptionClicked()
{
    if (m_isDescFolded)
    {
        m_isDescFolded = false;
        showDescriptionHTML(true);
        IGSxGUI::Util::setUnderline(sui->btnDescription, false);
    } else {
        m_isDescFolded = true;
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        showDescriptionHTML(false);
    }
}

void IGSxGUI::CPDView::showDescriptionHTML(bool isVisible)
{
    sui->wvwCPDHTMLDescription->setVisible(isVisible);
    if (isVisible)
    {
        IGSxGUI::CPD* CPD = m_presenter->getCPD(sui->lblSelectedCPD->getText());

        if (CPD != NULL)
        {
            IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->btnDescription->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);

            std::string strCPDHTMLFilePath = CPD->getHtmlFile();
            sui->wvwCPDHTMLDescription->setUrl(SUI::ResourcePath::getResourceFile(strCPDHTMLFilePath));
        }
    } else {
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnDescription->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);
    }
}

void IGSxGUI::CPDView::moveDescriptionToDown()
{
    const int ANGLE_YPOS = 608;
    const int BUTTON_YPOS = 604;
    const int LINE_YPOS = 640;
    const int WEBVIEW_HEIGHT = 230;
    sui->lblDescriptionAngle->setGeometry(sui->lblDescriptionAngle->getGeometry().getX(), ANGLE_YPOS, sui->lblDescriptionAngle->getGeometry().getWidth(), sui->lblDescriptionAngle->getGeometry().getHeight());
    sui->btnDescription->setGeometry(sui->btnDescription->getGeometry().getX(), BUTTON_YPOS, sui->btnDescription->getGeometry().getWidth(), sui->btnDescription->getGeometry().getHeight());
    sui->lblDescriptionLine->setGeometry(sui->lblDescriptionLine->getGeometry().getX(), LINE_YPOS, sui->lblDescriptionLine->getGeometry().getWidth(), sui->lblDescriptionLine->getGeometry().getHeight());
    sui->wvwCPDHTMLDescription->setGeometry(sui->wvwCPDHTMLDescription->getGeometry().getX(), LINE_YPOS, sui->wvwCPDHTMLDescription->getGeometry().getWidth(), WEBVIEW_HEIGHT);
}

void IGSxGUI::CPDView::setSelectedCPDTestType()
{
    bool isCPDTypeIsAll = false;
    switch (m_cpdTypeSelected)
    {
        case TYPE_CALIBRATION:
            if (m_countCalibration > 0)
            {
                sui->rbtnCalibration->setChecked(true);
            } else {
                isCPDTypeIsAll = true;
            }
            break;
        case TYPE_PERFORMANCE:
            if (m_countPerformance > 0)
            {
                sui->rbtnPerformance->setChecked(true);
            } else {
                isCPDTypeIsAll = true;
            }
            break;
        case TYPE_DIAGNOSTICS:
            if (m_countDiagnostics > 0)
            {
                sui->rbtnDiagnostics->setChecked(true);
            } else {
                isCPDTypeIsAll = true;
            }
            break;
        case TYPE_NONE:
            sui->rbtnAll->setChecked(true);
            break;
        default:
            break;
    }

    if (isCPDTypeIsAll) {
        m_cpdTypeSelected = TYPE_NONE;
        sui->rbtnAll->setChecked(true);
    }
}

void IGSxGUI::CPDView::moveDescriptionToOriginalPosition()
{
    const int ANGLE_YPOS = 335;
    const int BUTTON_YPOS = 331;
    const int LINE_YPOS = 360;
    const int WEBVIEW_HEIGHT = 480;
    sui->lblDescriptionAngle->setGeometry(sui->lblDescriptionAngle->getGeometry().getX(), ANGLE_YPOS, sui->lblDescriptionAngle->getGeometry().getWidth(), sui->lblDescriptionAngle->getGeometry().getHeight());
    sui->btnDescription->setGeometry(sui->btnDescription->getGeometry().getX(), BUTTON_YPOS, sui->btnDescription->getGeometry().getWidth(), sui->btnDescription->getGeometry().getHeight());
    sui->lblDescriptionLine->setGeometry(sui->lblDescriptionLine->getGeometry().getX(), LINE_YPOS, sui->lblDescriptionLine->getGeometry().getWidth(), sui->lblDescriptionLine->getGeometry().getHeight());
    sui->wvwCPDHTMLDescription->setGeometry(sui->wvwCPDHTMLDescription->getGeometry().getX(), LINE_YPOS, sui->wvwCPDHTMLDescription->getGeometry().getWidth(), WEBVIEW_HEIGHT);
}

void IGSxGUI::CPDView::showTestReportTableColumns(bool isVisible)
{
    sui->lblColumnLine->setVisible(isVisible);
    sui->lblColumnReport->setVisible(isVisible);
    sui->lblColumnDateTime->setVisible(isVisible);
}

void IGSxGUI::CPDView::loadTestReportTable()
{
    IGSxCPD::TestResultList cpdTestReports;
    m_presenter->getCPDTestResults(m_selectedCPD, cpdTestReports);
    sui->tawTestReports->setVisible(true);
    sui->lblNoReports->setVisible(false);
    showTestReportTableColumns(true);
    sui->tawTestReports->removeRows(1, sui->tawTestReports->rowCount()-1);
    int totalNumberOfReports = static_cast<int>(cpdTestReports.size());
    int numberOfReportsToDisplay = 0;
    int reportCounOne = 1;
    const int REPORTCOUNTFIVE = 5;
    if (totalNumberOfReports == 0) {
        sui->tawTestReports->setVisible(false);
        sui->lblNoReports->setVisible(true);
        showTestReportTableColumns(false);
    } else if (totalNumberOfReports > REPORTCOUNTFIVE) {
        numberOfReportsToDisplay = REPORTCOUNTFIVE;
    } else if ((totalNumberOfReports >= reportCounOne) && (totalNumberOfReports <= REPORTCOUNTFIVE)) {
        numberOfReportsToDisplay = totalNumberOfReports;
    }
    for (int i = 0 ; i < (numberOfReportsToDisplay - 1); i++) {
        sui->tawTestReports->appendRow();
    }
    if (numberOfReportsToDisplay > 0) {
        for (int row = 0; row < sui->tawTestReports->rowCount(); ++row) {
            SUI::Widget *widget = sui->tawTestReports->getWidgetItem(row, 0);
            IGSxGUI::Util::setTestReportUCTNormalStyle(widget);
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableTestReportRowPressed, this, row);
            usercontrol->hoverEntered = boost::bind(&CPDView::onTableTestReportUCTHoverEntered, this, row);
            usercontrol->hoverLeft = boost::bind(&CPDView::onTableTestReportUCTHoverLeft, this, row);
            std::string reportpath =  cpdTestReports[row].htmlReport();
            std::size_t found = reportpath.find_last_of("/\\");
            IGSxGUI::Util::setUnCheckToTestReportUserControl(widget);
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 1, reportpath.substr(found+1));
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 2, boost::lexical_cast<std::string>(IGSxGUI::DateTime::formatTime(cpdTestReports[row].time(), STRING_DATETIME_FORMAT)));
            IGSxGUI::Util::setTextToTestReportUserControl(widget, 3, reportpath);
        }
    }
}

void IGSxGUI::CPDView::onTableTestReportRowPressed(int rowindex)
{
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(rowindex, 0);
    IGSxGUI::Util::setCheckToTestReportUserControl(widget);
    setTestReportRowStyle(sui->tawTestReports);
    int numRowsChecked = IGSxGUI::Util::getNumCheckedRows(sui->tawTestReports);
    std::string captionViewSelectedReport = STRING_EMPTY;
    switch (numRowsChecked) {
    case 0:
        sui->btnViewSelectedReports->setEnabled(false);
        captionViewSelectedReport = STRING_VIEW_SELECTED_REPORT;
        break;
    case 1:
        sui->btnViewSelectedReports->setEnabled(true);
        captionViewSelectedReport = STRING_VIEW_SELECTED_REPORT;
        break;
    case 2:
        sui->btnViewSelectedReports->setEnabled(true);
        captionViewSelectedReport = STRING_VIEW_SELECTED_REPORTS;
        break;
    default:
        break;
    }
    sui->btnViewSelectedReports->setText(captionViewSelectedReport);
}

void IGSxGUI::CPDView::onTableTestReportUCTHoverEntered(int index)
{
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(index, 0);
    IGSxGUI::Util::setTestReportUCTHoverOnStyle(widget);
}

void IGSxGUI::CPDView::onTableTestReportUCTHoverLeft(int index)
{
    SUI::Widget *widget = sui->tawTestReports->getWidgetItem(index, 0);
    IGSxGUI::Util::setTestReportUCTHoverOffStyle(widget);
}

void IGSxGUI::CPDView::onBtnTestReportHoverEntered()
{
    if (m_isTestReportFolded)
    {
        IGSxGUI::Util::setUnderline(sui->btnTestReports, true);
    }
}

void IGSxGUI::CPDView::onBtnTestReportHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnTestReports, false);
}

void IGSxGUI::CPDView::onBtnDescriptionHoverEntered()
{
    if (m_isDescFolded)
    {
        IGSxGUI::Util::setUnderline(sui->btnDescription, true);
    }
}

void IGSxGUI::CPDView::onBtnDescriptionHoverLeft()
{
    IGSxGUI::Util::setUnderline(sui->btnDescription, false);
}

void IGSxGUI::CPDView::onBtnTestReportsClicked()
{
    if (m_isTestReportFolded)
    {
        m_isTestReportFolded = false;

        IGSxGUI::Util::setUnderline(sui->btnTestReports, false);

        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
        sui->btnTestReports->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);

        showTestReportTable(true);
        moveDescriptionToDown();
    } else {
        m_isTestReportFolded = true;

        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        sui->btnTestReports->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);

        showTestReportTable(false);
        moveDescriptionToOriginalPosition();
    }
}

void IGSxGUI::CPDView::showTestReportTable(bool isVisible)
{
    sui->lblColumnReport->setVisible(isVisible);
    sui->lblColumnDateTime->setVisible(isVisible);
    sui->lblColumnLine->setVisible(isVisible);
    sui->tawTestReports->setVisible(isVisible);
    sui->lblNoReports->setVisible(isVisible);
    sui->btnViewSelectedReports->setVisible(isVisible);

    if (isVisible)
    {
        IGSxGUI::CPD* CPD = m_presenter->getCPD(sui->lblSelectedCPD->getText());

        if (CPD != NULL)
        {
            loadTestReportTable();

            const int MINIMUM_VIEWABLE_REPORT_COUNT = 1;
            int numRowsChecked = IGSxGUI::Util::getNumCheckedRows(sui->tawTestReports);

            if (numRowsChecked >= MINIMUM_VIEWABLE_REPORT_COUNT)
            {
                sui->btnViewSelectedReports->setEnabled(true);
            } else {
                sui->btnViewSelectedReports->setEnabled(false);
            }
        }
    }
}

void IGSxGUI::CPDView::setTestReportRowStyleEnabled(SUI::Widget *widget, int rowIndex)
{
    IGSxGUI::Util::setTestReportUCTNormalStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = boost::bind(&CPDView::onTableTestReportRowPressed, this, rowIndex);
    usercontrol->hoverEntered = boost::bind(&CPDView::onTableTestReportUCTHoverEntered, this, rowIndex);
    usercontrol->hoverLeft = boost::bind(&CPDView::onTableTestReportUCTHoverLeft, this, rowIndex);
}

void IGSxGUI::CPDView::setTestReportRowStyleDisabled(SUI::Widget *widget)
{
    IGSxGUI::Util::setTestReportUCTDisabledStyle(widget);
    SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
    usercontrol->clicked = NULL;
    usercontrol->hoverEntered = NULL;
    usercontrol->hoverLeft = NULL;
}

void IGSxGUI::CPDView::setTestReportRowStyle(SUI::TableWidget *tablewidget)
{
    int numberOfRowsChecked = IGSxGUI::Util::getNumCheckedRows(tablewidget);
    int numberOfRows = tablewidget->rowCount();
    for (int i =0; i < numberOfRows; ++i) {
        SUI::Widget *widget = tablewidget->getWidgetItem(i, 0);
        if (IGSxGUI::Util::isTestReportSelected(widget)) {
            SUI::UserControl *usercontrol = dynamic_cast<SUI::UserControl*>(widget);
            usercontrol->clicked = boost::bind(&CPDView::onTableTestReportRowPressed, this, i);
            IGSxGUI::Util::setTestReportUCTClickedStyle(widget);
        } else {
            if (MAX_NUMBER_OF_SELECTED_ROWS == numberOfRowsChecked) {
                setTestReportRowStyleDisabled(widget);
                IGSxGUI::Util::setTestReportUCTDisabledStyle(widget);
            } else {
                setTestReportRowStyleEnabled(widget, i);
                IGSxGUI::Util::setTestReportUCTNormalStyle(widget);
            }
        }
    }
}

void IGSxGUI::CPDView::onBtnViewSelectedReportsPressed()
{
    sui->gbxFrontPage->setVisible(false);
    sui->gbxTestReportPage->setVisible(true);
    sui->lblCPDHeader->setText(sui->lblCPDHeader->getText() + STRING_TESTREPORTS);

    std::vector<std::string> listURL = IGSxGUI::Util::getReportURLfromTestReportTable(sui->tawTestReports);

    if (listURL.size() == 1)
    {
        sui->wvwSingleTestReport->setVisible(true);
        sui->wvwLeftTestReport->setVisible(false);
        sui->wvwRightTestReport->setVisible(false);
        sui->wvwSingleTestReport->setUrl(listURL[0]);
        sui->lblCloseAllReports->setText(STRING_CLOSEREPORT);
    } else {
        sui->wvwSingleTestReport->setVisible(false);
        sui->wvwLeftTestReport->setVisible(true);
        sui->wvwRightTestReport->setVisible(true);
        sui->wvwLeftTestReport->setUrl(listURL[0]);
        sui->wvwRightTestReport->setUrl(listURL[1]);
        sui->lblCloseAllReports->setText(STRING_CLOSEREPORTS);
    }
}

void IGSxGUI::CPDView::onUCTCloseReportsClicked()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ASML_ORANGELABEL);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_ASML_COLORORANGE, AWESOME_CLOSE_SIZE);

    sui->gbxTestReportPage->setVisible(false);
    sui->gbxFrontPage->setVisible(true);

    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);

    sui->lblCPDHeader->setText(STRING_MAINTENANCE);
    sui->lblCloseAllReports->setBGColor(SUI::ColorEnum::White);
    sui->lblCloseImage->setBGColor(SUI::ColorEnum::White);
}

void IGSxGUI::CPDView::onUCTCloseReportsHoverOn()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_HOVERON);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STRING_CLOSE_BUTTON_COLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::CPDView::onUCTCloseReportsHoverOff()
{
    sui->lblCloseAllReports->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, STYLE_AWESOME_ICONCOLOR, AWESOME_CLOSE_SIZE);
}

void IGSxGUI::CPDView::onOpenCPDClicked()
{
    std::string cpdName = sui->lblSelectedCPD->getText();
    IGSxGUI::CPD* cpd = m_presenter->getCPD(cpdName);
    std::string testType = cpd->getTestType();
    IGS_INFO(STRING_CPDLOG1 + cpdName + STRING_CPDLOG2 + testType);

    if (m_presenter->startCPD(cpdName))
    {
        m_isCPDActivated = true;

        sui->btnOpenCPD->setEnabled(false);
        sui->lblActiveCPDName->setVisible(true);
        sui->lblActiveCPDName->setText(getRequiredSpace(2) + cpdName);
        sui->lblActiveCPDDescription->setVisible(true);
        sui->lblActiveCPDDescription->setText(getRequiredSpace(2) + cpd->getDescription());
        sui->lblActiveCPDTestType->setVisible(true);
        sui->lblActiveCPDTestType->setText(testType);
        sui->lblActiveArrow->setVisible(false);
        sui->lblActiveCPDTestTypeIcon->setVisible(true);

        setActiveCPDStyle(testType);
    }
}

void IGSxGUI::CPDView::setActiveCPDStyle(std::string cpdType)
{
    sui->gbxActiveCPD->setStyleSheetClass(STYLE_ACTIVECPD_GROUPBOX);
    sui->lblActiveCPDName->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_BLACK);
    sui->lblActiveCPDDescription->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);
    sui->lblActiveCPDTestType->setStyleSheetClass(STYLE_ACTIVE_CPDLABEL_GREY);

    if (cpdType == STRING_CALIBRATION)
    {
        IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_crosshairs, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
    } else if (cpdType == STRING_PERFORMANCE) {
        IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_areachart, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
    } else if (cpdType == STRING_DIAGNOSTICS) {
        IGSxGUI::Util::setAwesome(sui->lblActiveCPDTestTypeIcon, IGSxGUI::AwesomeIcon::AI_fa_stethoscope, STYLE_AWESOMEACTIVE_ICONCOLOR, AWESOME_ICON_SIZE);
    }
}

void IGSxGUI::CPDView::init()
{
    initCommon();
    m_selectedSubSystem = STRING_ALL_CPDS;
    sui->lblAllCPDs->setText(STRING_ALL_CPDS);
    IGSxGUI::Util::selectRow(sui->tawCPDSubsystem, 0);

    m_listCPD = m_presenter->getCPDs();

    loadTestTypes();
    loadCPDTable(m_listCPD, false);
    loadCPDTypeRadios();
}

void IGSxGUI::CPDView::reload()
{
    m_isReloading = true;
    initCommon();
    if (m_selectedSubSystem == STRING_ALL_CPDS) {
        IGSxGUI::Util::selectRow(sui->tawCPDSubsystem, 0);
        sui->lblAllCPDs->setText(STRING_ALL_CPDS);
    } else if (m_selectedSubSystem != "") {
        m_isInternalCallToSubsystemPressed = true;
        IGSxGUI::Util::selectRow(sui->tawCPDSubsystem, m_selectedSubsystemRowNum);
        sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);
        m_isInternalCallToSubsystemPressed = false;
    }

    loadCPDTypeRadios();
    switch (m_cpdTypeSelected)
    {
        case TYPE_CALIBRATION:
            sui->rbtnCalibration->setChecked(true);
            break;
        case TYPE_PERFORMANCE:
            sui->rbtnPerformance->setChecked(true);
            break;
        case TYPE_DIAGNOSTICS:
            sui->rbtnDiagnostics->setChecked(true);
            break;
        case TYPE_NONE:
            sui->rbtnAll->setChecked(true);
            break;
        default:
            break;
    }

    loadCPDTableByType(m_cpdTypeSelected, true);

    if (m_selectedCPDRowNum < MAX_INITIAL_ROWCOUNT)
    {
        if (m_isReloading)
        {
            if (m_selectedCPD != "")
            {
                IGSxGUI::Util::setCPDUCTClickedStyle(sui->tawCPD->getWidgetItem(m_selectedCPDRowNum, 0));
                showRightPane(true, m_selectedCPD);
            } else {
                showRightPane(false, m_selectedCPD);
            }
            reloadActiveCPD();
            sui->lblAllCPDs->setText(STRING_ALL_CPDS + STRING_SLASH + m_selectedSubSystem);

            m_isReloading = false;
        }
    }
}

void IGSxGUI::CPDView::showRightPane(bool isVisible, const std::string &CPDName)
{
    sui->lblSelectedCPD->setVisible(isVisible);
    sui->btnOpenCPD->setVisible(isVisible);

    sui->lblTestReportAngle->setVisible(isVisible);
    sui->btnTestReports->setVisible(isVisible);
    sui->lblTestReportLine->setVisible(isVisible);

    sui->lblColumnReport->setVisible(isVisible);
    sui->lblColumnDateTime->setVisible(isVisible);
    sui->lblColumnLine->setVisible(isVisible);
    sui->tawTestReports->setVisible(isVisible);
    sui->lblNoReports->setVisible(isVisible);
    sui->btnViewSelectedReports->setVisible(isVisible);

    sui->lblDescriptionAngle->setVisible(isVisible);
    sui->btnDescription->setVisible(isVisible);
    sui->lblDescriptionLine->setVisible(isVisible);

    sui->wvwCPDHTMLDescription->setVisible(isVisible);

    if (isVisible)
    {
        sui->lblSelectedCPD->setText(CPDName);
        IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
        IGSxGUI::Util::setAwesome(sui->lblDescriptionAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);

        if (m_isTestReportFolded)
        {
            IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_right, SUI::ColorEnum::Black, AWESOME_ANGLE_SIZE);
            sui->btnTestReports->setStyleSheetClass(STYLE_ASML_DARKBLUEBUTTON);

            showTestReportTable(false);
            moveDescriptionToOriginalPosition();
        } else {
            IGSxGUI::Util::setAwesome(sui->lblTestReportAngle, IGSxGUI::AwesomeIcon::AI_fa_angle_down, STYLE_ASML_COLORORANGE, AWESOME_ANGLE_SIZE);
            sui->btnTestReports->setStyleSheetClass(STYLE_ASML_ORANGEBUTTON);

            showTestReportTable(true);
            moveDescriptionToDown();
        }
        if (m_isDescFolded)
        {
            showDescriptionHTML(false);
        } else {
            showDescriptionHTML(true);
        }
    }
}


void IGSxGUI::CPDView::reloadActiveCPD()
{
    if (m_isCPDActivated)
    {
        CPD* cpd = m_presenter->retrieveRunningCPD();
        if (cpd != NULL)
        {
            std::string testType = cpd->getTestType();

            sui->lblActiveCPDName->setVisible(true);
            sui->lblActiveCPDName->setText(getRequiredSpace(2) + cpd->getName());
            sui->lblActiveCPDDescription->setVisible(true);
            sui->lblActiveCPDDescription->setText(getRequiredSpace(2) + cpd->getDescription());
            sui->lblActiveCPDTestType->setVisible(true);
            sui->lblActiveCPDTestType->setText(testType);
            sui->lblActiveArrow->setVisible(true);
            sui->lblActiveCPDTestTypeIcon->setVisible(true);
            sui->btnOpenCPD->setEnabled(false);

            setActiveCPDStyle(testType);
        }
    } else {
        sui->gbxActiveCPD->setStyleSheetClass(STYLE_INACTIVE_GROUPBOX);
        sui->lblActiveCPDName->setStyleSheetClass(STYLE_INACTIVE_CPD);
        sui->lblActiveCPDName->setText(STRING_NOACTIVE_CPD);
        sui->lblActiveCPDDescription->setVisible(false);
        sui->lblActiveCPDTestType->setVisible(false);
        sui->lblActiveCPDTestTypeIcon->setVisible(false);
        sui->lblActiveArrow->setVisible(false);
    }
}
void IGSxGUI::CPDView::onUCTCloseReportsPressed()
{
    std::string color = "#FF7F45";
    IGSxGUI::Util::setAwesome(sui->lblCloseImage, IGSxGUI::AwesomeIcon::AI_fa_times, color, AWESOME_CLOSE_SIZE);
    std::string styleClass = "OrangeLabel";
    sui->lblCloseAllReports->setStyleSheetClass(styleClass);
}
