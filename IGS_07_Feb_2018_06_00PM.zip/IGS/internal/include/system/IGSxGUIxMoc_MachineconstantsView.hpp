/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_MachineconstantsView.hpp
| Author       : Raja
| Description  : Header file for Moc Machineconstants view
|
| ! \file        IGSxGUIxMoc_MachineconstantsView.hpp
| ! \brief       Header file for Moc Machineconstants view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
#define IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class MachineconstantsView;
}  // namespace IGSxGUI

namespace SUI {
class Dialog;
class ObjectList;
class Container;
class Button;
class TableWidget;
class LineEdit;
class Label;
class ScrollBar;
class GraphicsView;
class UserControl;
class GroupBox;
class TableWidget;
class TextArea;
class MachineconstantsView
{
 private:
    MachineconstantsView();

    void setupSUI(const char *XMLFileName);
    void setupSUIContainer(const char *XMLFileName, Container *container);
    void loadObjects(ObjectList *objectList);

    Dialog *dialog;
    Button *btnParameterName;
    Label *lblParameterNameTooltip;
    Button *btnParameterValue;
    Label *lblParameterValueTooltip;
    Label *lblPendingParameters;
    Button *btnNoPendingParameters;
    Button *btnHistory;
    Button *btnPendingParameterName;
    Label *lblPendingParameterNameTooltip;
    Button *btnPendingParameterValue;
    Label *lblPendingParameterValueTooltip;
    Button *btnPendingParametersLine;
    TableWidget *tawParameters;
    LineEdit *lneSearchParameterText;
    Button *btnSearchParameter;
    Button *btnSearchClear;
    Label *lblEntriesFound;
    Button *btnCancel;
    UserControl *uctSaveButton;
    Label *lblSaveImage;
    Label *lblSaveText;
    GroupBox *gbxSaveButton;
    ScrollBar *scbParametersTable;    
    GraphicsView *imvLogo;
    TableWidget *tawMCPendingParam;
    Label *lblPendingParamSaveName;
    LineEdit *lnePendingParamSaveName;
    Label *lblPendingParamSaveChangeReason;
    TextArea *txaPendingParamSaveChangeReason;
    Button *btnPendingParamCancelSave;
    UserControl *uctPendingParamFinalSave;
    Label *lblPendingParamFinalSaveImage;
    Label *lblPendingParamFinalSaveText;
    GroupBox *gbxPendingParamFinalSaveButton;
    Label *lblPendingParamSaveChangeReasonTxtArea;
    Label *lblPendingParamSaveNameLnEdit;
    Button *btnPendingParamSaveNameLnEditCancel;
    TableWidget *tawParameterTree;
    Label *lblMachineConstantHeader;
    Label *lblAllCategories;

    friend class ::IGSxGUI::MachineconstantsView;
};
}  // namespace SUI
#endif // IGSXGUIXMOC_MACHINECONSTANTSVIEW_HPP
