/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxPAR_impl.cpp
| Author       : Jan-Pieter
| Description  : Stub impementation of IGSxPAR interface
|
| ! \file        IGSxPAR_impl.cpp
| ! \brief       Stub impementation of IGSxPAR interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <boost/date_time.hpp>
#include <boost/algorithm/string/find.hpp>
#include "IGSxPAR_impl.hpp"
#include "StubParameters.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace
{
typedef struct
{
    std::string name;
    int defaultValue;
    int currentValue;
}gParameterType;

#define CREATEPARAMETERS(NAME, VALUE)\
{NAME, VALUE, VALUE },

gParameterType gParameters[] = {
    PARAMETERS(CREATEPARAMETERS)
};

int getParameterCount()
{
    return sizeof(gParameters)/sizeof(gParameters[0]);
}

int findParameterIndex(std::string str)
{
    for (int i = 0; i < getParameterCount(); ++i)
    {
        if (gParameters[i].name == str)
        {
            return i;
        }
    }
    return -1;
}

int getParameterValue(std::string str)
{
    int index = findParameterIndex(str);
    return index == -1 ? 0 : gParameters[index].currentValue;
}


void setParameterValue(std::string str, int value)
{
    int index = findParameterIndex(str);
    if (index == -1)
    {
        return;
    }
    gParameters[index].currentValue = value;
}

bool containsIgnoreCase(const std::string& targetText, const std::string& searchText)
{
   boost::iterator_range<std::string::const_iterator> rng;

   rng = boost::ifind_first(targetText, searchText);

   return rng;
}
} // namespace

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
// instance
IGSxPAR::PAR* IGSxPAR::PAR_Stub::getInstance()
{
    static PAR_Stub _instance;
    return &_instance;
}
IGSxPAR::PAR* IGSxPAR::PAR::instance = IGSxPAR::PAR_Stub::getInstance();

IGSxPAR::PAR_Stub::PAR_Stub()
{
}

IGSxPAR::PAR_Stub::~PAR_Stub()
{
}

void IGSxPAR::PAR_Stub::subscribeValuesChanged( const ValuesChangedCallback& /*cb*/)
{
}

void IGSxPAR::PAR_Stub::unsubscribeValuesChanged()
{
}

void IGSxPAR::PAR_Stub::Read( const std::string& filter, ParameterTypePtrVector& parameters )
{
    if (filter.empty())
    {
        for (int i = 0; i < getParameterCount(); ++i)
        {
            IntConfig intConfig(gParameters[i].defaultValue, 1000000, -1000000, "**UNIT**");
            IntValue intValue(gParameters[i].name , gParameters[i].currentValue);
            boost::shared_ptr<IGSxPAR::IntType> intType(new IntType(DESIGN, (i % 7 != 0), intConfig, intValue));

            parameters.push_back(intType);
        }
    } else {
        for (int i = 0; i < getParameterCount(); ++i)
        {
            if (containsIgnoreCase(gParameters[i].name , filter))
            {
                IntConfig intConfig(gParameters[i].defaultValue, 1000000, -1000000, "**UNIT**");
                IntValue intValue(gParameters[i].name , gParameters[i].currentValue);
                boost::shared_ptr<IGSxPAR::IntType> intType(new IntType(DESIGN, (i % 7 != 0), intConfig, intValue));

                parameters.push_back(intType);
            }
        }
    }
}

void IGSxPAR::PAR_Stub::Write( const TransactionInfo& /*transactionInfo*/, const IValuePtrVector& /*values*/)
{
}

void IGSxPAR::PAR_Stub::GetChangeHistory(time_t /*start*/, time_t /*end*/,  ParameterChangeHistoryVector& /*history*/)
{
}





