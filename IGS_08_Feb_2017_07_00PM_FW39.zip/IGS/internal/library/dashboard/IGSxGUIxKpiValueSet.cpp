/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.cpp
| ! \brief       Implementation of KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const int IGSxGUI::KPIValueSet::TOTAL_LIMITING_MINUTES = 380;

IGSxGUI::KPIValueSet::KPIValueSet(const IGSxKPI::KPIValueSetDefinition &kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description()),
    m_unit(kpiDefinition.unit()),
    m_displayUnit(""),
    m_factor(""),
    m_min(""),
    m_max(""),
    m_isImplemented(false)
{
    m_cbKPITimeValue.set_capacity(TOTAL_LIMITING_MINUTES);

    for (int index = 0; index < TOTAL_LIMITING_MINUTES; ++index)
    {
        KPITimeValue kpiTimeValue;

        kpiTimeValue.kpiTime = 0;
        kpiTimeValue.kpiValue = 0.0;

        m_cbKPITimeValue.push_back(kpiTimeValue);
    }
}

IGSxGUI::KPIValueSet::~KPIValueSet()
{
}

string IGSxGUI::KPIValueSet::getName() const
{
    return m_name;
}

string IGSxGUI::KPIValueSet::getDescription() const
{
    return m_desc;
}

string IGSxGUI::KPIValueSet::getUnit() const
{
    return m_unit;
}

std::string IGSxGUI::KPIValueSet::getDisplayUnit() const
{
    return m_displayUnit;
}

std::string IGSxGUI::KPIValueSet::getFactor() const
{
    return m_factor;
}

std::string IGSxGUI::KPIValueSet::getMin() const
{
    return m_min;
}
std::string IGSxGUI::KPIValueSet::getMax() const
{
    return m_max;
}
bool IGSxGUI::KPIValueSet::isActive()
{
    return m_isImplemented;
}

void IGSxGUI::KPIValueSet::setFactor(const std::string &factor)
{
    m_factor = factor;
}

void IGSxGUI::KPIValueSet::setMin(const std::string &min)
{
    m_min = min;
}

void IGSxGUI::KPIValueSet::setMax(const std::string &max)
{
    m_max = max;
}

void IGSxGUI::KPIValueSet::setDisplayUnit(const std::string &unit)
{
    m_displayUnit = unit;
}

void IGSxGUI::KPIValueSet::setActive(bool isImplemented)
{
    m_isImplemented = isImplemented;
}

void IGSxGUI::KPIValueSet::addValue(const time_t &time, const double &value)
{
    KPITimeValue previousKpiTimeValue = m_cbKPITimeValue.back();

    if (time  > previousKpiTimeValue.kpiTime)
    {
        KPITimeValue kpiTimeValue;

        kpiTimeValue.kpiTime = time;
        kpiTimeValue.kpiValue = value;

        m_cbKPITimeValue.push_back(kpiTimeValue);
    }
}

boost::circular_buffer<IGSxGUI::KPITimeValue> IGSxGUI::KPIValueSet::getValue() const
{
    return m_cbKPITimeValue;
}

IGSxGUI::KPITimeValue IGSxGUI::KPIValueSet::getLastValue() const
{
    return m_cbKPITimeValue.back();
}
