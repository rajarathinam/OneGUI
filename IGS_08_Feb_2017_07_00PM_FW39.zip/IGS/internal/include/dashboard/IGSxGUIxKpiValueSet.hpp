/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpiValueSet.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for KPI ValueSet
|
| ! \file        IGSxGUIxKpiValueSet.hpp
| ! \brief       Header file for KPI ValueSet
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_KPIVALUESET_HPP
#define IGSXKPI_KPIVALUESET_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/circular_buffer.hpp>
#include <string>
#include <vector>
#include "IGSxKPI.hpp"

using std::string;
using std::vector;
using IGSxKPI::KPIValueSetDefinition;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
struct structKPITimeValue
{
    time_t kpiTime;
    double kpiValue;

    structKPITimeValue(): kpiTime(0), kpiValue(0.0)
    {
    }
};
typedef structKPITimeValue KPITimeValue;

class KPIValueSet
{
 public:
    explicit KPIValueSet(const KPIValueSetDefinition &kpiDefinition);
    virtual ~KPIValueSet();

    string getName() const;
    string getDescription() const;
    string getUnit() const;

    string getDisplayUnit() const;
    string getFactor() const;
    string getMin() const;
    string getMax() const;
    bool isActive();
    void setActive(bool isActive);

    void setDisplayUnit(const std::string& unit);
    void setFactor(const std::string& factor);
    void setMin(const std::string& min);
    void setMax(const std::string& max);

    void addValue(const time_t& time, const double &value);
    boost::circular_buffer<KPITimeValue> getValue() const;
    KPITimeValue getLastValue() const;

 private:
    KPIValueSet(KPIValueSet const &);
    KPIValueSet& operator=(KPIValueSet const &);

    string m_name;  // KPI Value name
    string m_desc;  // KPI Value description
    string m_unit;  // KPI Value unit

    std::string m_displayUnit;  // Display name
    std::string m_factor;       // Factor
    std::string m_min;          // Min
    std::string m_max;          // Max
    bool m_isImplemented;       // Is implemented

    boost::circular_buffer<KPITimeValue> m_cbKPITimeValue;
    static const int TOTAL_LIMITING_MINUTES;
};
}  // namespace IGSxGUI
#endif  // IGSXKPI_KPIVALUESET_HPP
