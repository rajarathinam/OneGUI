/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIDashboardView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Dashboard plugin View
|
| ! \file        IGSxGUIxIDashboardView.hpp
| ! \brief       Header file for Dashboard plugin View
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIDASHBOARDVIEW_HPP
#define IGSXGUIXIDASHBOARDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <SUIContainer.h>

using std::string;
using std::vector;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class IDashboardView
{
 public:
    IDashboardView() {}
    virtual ~IDashboardView() {}

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void updateKPI(string kpiName, string valueSetName, vector<double> values) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIDASHBOARDVIEW_HPP
