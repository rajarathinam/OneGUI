/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIManager.hpp
| Author       : Sabari Chandra Sekar
| Description  : Header file for IGSKPI Manager
|
| ! \file        IGSxKPIManager.hpp
| ! \brief       Header file for IGSxKPI Manager
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXKPI_MANAGER_HPP
#define IGSXKPI_MANAGER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include "IGSxGUIxConsumable.hpp"
#include "IGSxGUIxKpi.hpp"
#include "IGSxKPI.hpp"
#include <SUITimer.h>

using std::string;
using std::vector;

/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class KPIManager
{
 public:
    KPIManager();
    virtual ~KPIManager();

    void initialize();

    vector<KPI*> getKPIs();
    vector<Consumable*> getConsumables();

    void addKPI(IGSxKPI::KPIDefinition&);
    void addConsumable(IGSxKPI::KPIDefinition&);

    KPI* getKPI(const string& name) const;
    Consumable* getConsumable(const string& name) const;

    void receiveKPIDataEvent(const IGSxKPI::KPIData &kpiData);
    void receiveConsumableDataEvent(const IGSxKPI::KPIData &kpiData);

 private:
    KPIManager(KPIManager const &);
    KPIManager& operator=(KPIManager const &);

    void getKPIData();
    void onTimeout();

    vector<KPI*> m_KPIs;
    vector<Consumable*> m_Consumables;
    boost::shared_ptr<SUI::Timer> m_timer;
    time_t m_previousPollTime;

    static const int TIMER_INTERVAL;
    static const string KPI_WHITELIST_FILE;

    static const string STRING_KPI;
    static const string STRING_KPIS;
    static const string STRING_TYPE;
    static const string STRING_ATTRIBUTE;
    static const string STRING_CONSUMABLE;
    static const string STRING_ATTRIBUTE_NAME;
    static const string STRING_ATTRIBUTE_TYPE;
};

}  // namespace IGSxGUI
#endif  // IGSXKPI_MANAGER_HPP
