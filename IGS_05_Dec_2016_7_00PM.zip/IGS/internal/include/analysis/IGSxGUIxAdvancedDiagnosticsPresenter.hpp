/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAdvancedDiagnosticsPresenter.hpp
| Author       : Venugopal S
| Description  : Header file for Advanced Diagnostics Presenter
|
| ! \file        IGSxGUIxAdvancedDiagnosticsPresenter.hpp
| ! \brief       Header file for Advanced Diagnostics Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADVANCEDDIAGNOSTICSPRESENTER_HPP
#define IGSXGUIXADVANCEDDIAGNOSTICSPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/signals2.hpp>
#include <vector>
#include <string>
#include "IGSxGUIxIAdvancedDiagnosticsView.hpp"
#include "IGSxGUIxADT.hpp"
#include "IGSxGUIxADTManager.hpp"


/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class AdvancedDiagnosticsPresenter
{
 public:
    explicit AdvancedDiagnosticsPresenter(IAdvancedDiagnosticsView* view, ADTManager* pADTManager);
    virtual ~AdvancedDiagnosticsPresenter();

    std::vector<ADT*> getADTs();


    bool startADT(std::string adtName);


 private:
    AdvancedDiagnosticsPresenter(const AdvancedDiagnosticsPresenter&);
    AdvancedDiagnosticsPresenter& operator=(const AdvancedDiagnosticsPresenter&);



    ADTManager* m_pADTManager;
    IAdvancedDiagnosticsView *m_view;
    boost::signals2::connection m_connection;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADVANCEDDIAGNOSTICSPRESENTER_HPP
