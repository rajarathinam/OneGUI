/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKpi.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of KPI
|
| ! \file        IGSxGUIxKpi.cpp
| ! \brief       Implementation of KPI
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxKpi.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::KPI::KPI(IGSxKPI::KPIDefinition kpiDefinition):
    m_name(kpiDefinition.name()),
    m_desc(kpiDefinition.description())
{
    for(size_t i=0; i< kpiDefinition.values()->size(); i++ )
    {
        KPIValueSet* kpiValueSet = new KPIValueSet(kpiDefinition.values()->at(i));
        m_KPIValueSets.push_back(kpiValueSet);
    }
}

IGSxGUI::KPI::~KPI()
{
    for (vector<KPIValueSet*>::iterator it = m_KPIValueSets.begin() ; it != m_KPIValueSets.end(); ++it)
    {
        delete (*it);
    }
    m_KPIValueSets.clear();
}

string IGSxGUI::KPI::getName() const
{
    return m_name;
}

string IGSxGUI::KPI::getDescription() const
{
    return m_desc;
}

void IGSxGUI::KPI::updateValue(IGSxKPI::KPIData kpiData)
{
    vector<double> values;
    IGSxKPI::KPIData data = kpiData;

    IGSxGUI::KPIValueSet * kpivalueSet = getValueSet(data.name());

    if( kpivalueSet != NULL && kpivalueSet->getTime() != data.time())
    {
        kpivalueSet->addTime(data.time());
        kpivalueSet->addValue(data.values());

        for (size_t j = 0; j < data.values()->size(); j++)
        {
            values.push_back(data.values()->at(j));
        }
        if(!m_valueChanged.empty())
        {
            m_valueChanged(getName(), kpivalueSet->getName(),values);
        }
    }
}

void IGSxGUI::KPI::updateValues(IGSxKPI::KPIDataList kpiDataList)
{
    for (size_t i = 0; i < kpiDataList.size(); i++)
    {
        updateValue(kpiDataList[i]);
    }
}

boost::signals2::connection IGSxGUI::KPI::registerForValueChanged(const IGSxGUI::KPI::ValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}

IGSxGUI::KPIValueSet *IGSxGUI::KPI::getValueSet(const std::string &name) const
{
    for (size_t i = 0; i < m_KPIValueSets.size(); i++)
    {
        if (m_KPIValueSets[i]->getName() == name)
        {
            return m_KPIValueSets[i];
        }
    }
    return NULL;
}

std::vector<IGSxGUI::KPIValueSet*> IGSxGUI::KPI::getValueSets() const
{
    return m_KPIValueSets;
}
