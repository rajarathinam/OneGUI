/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxConsumable.cpp
| Author       : Sabari Chandra Sekar
| Description  : Implementation of Consumable
|
| ! \file        IGSxConsumable.cpp
| ! \brief       Implementation of Consumable
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxConsumable.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::Consumable::Consumable(IGSxKPI::KPIDefinition consumableDefinition):
    m_name(consumableDefinition.name()),
    m_desc(consumableDefinition.description())
{
    for(size_t i=0; i<consumableDefinition.values()->size(); i++ )
    {
        ConsumableValueSet* consumableValueSet = new ConsumableValueSet(consumableDefinition.values()->at(i));
        m_ConsumableValueSets.push_back(consumableValueSet);
    }
}

IGSxGUI::Consumable::~Consumable()
{
    for (vector<ConsumableValueSet*>::iterator it = m_ConsumableValueSets.begin() ; it != m_ConsumableValueSets.end(); ++it)
    {
        delete (*it);
    }
    m_ConsumableValueSets.clear();
}

string IGSxGUI::Consumable::getName() const
{
    return m_name;
}

string IGSxGUI::Consumable::getDescription() const
{
    return m_desc;
}

void IGSxGUI::Consumable::updateValue(IGSxKPI::KPIData kpiData)
{
    vector<double> values;
    IGSxKPI::KPIData data = kpiData;

    IGSxGUI::ConsumableValueSet * kpivalueSet = getValueSet(data.name());

    if( kpivalueSet->getTime() != data.time())
    {
        kpivalueSet->addTime(data.time());
        kpivalueSet->addValue(data.values());

        for (size_t j = 0; j < data.values()->size(); j++)
        {
            values.push_back(data.values()->at(j));
        }
        if(!m_valueChanged.empty())
        {
            m_valueChanged(getName(), data.name(),values);
        }
    }
}

void IGSxGUI::Consumable::updateValues(IGSxKPI::KPIDataList kpiDataList)
{
    for (size_t i = 0; i < kpiDataList.size(); i++)
    {
        updateValue(kpiDataList[i]);
    }
}

boost::signals2::connection IGSxGUI::Consumable::registerForValueChanged(const IGSxGUI::Consumable::ValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}

IGSxGUI::ConsumableValueSet *IGSxGUI::Consumable::getValueSet(const std::string &name) const
{
    for (size_t i = 0; i < m_ConsumableValueSets.size(); i++)
    {
        if (m_ConsumableValueSets[i]->getName() == name)
        {
            return m_ConsumableValueSets[i];
        }
    }
    return NULL;
}

std::vector<IGSxGUI::ConsumableValueSet*> IGSxGUI::Consumable::getValueSets() const
{
    return m_ConsumableValueSets;
}
