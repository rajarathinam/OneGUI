/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDashboardView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Dashboard plugin view
|
| ! \file        IGSxGUIxDashboardView.cpp
| ! \brief       Implementation of Dashboard plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include "IGSxGUIxDashboardView.hpp"
#include "IGSxGUIxMoc_DashboardView.hpp"
#include <SUITableWidget.h>
#include <SUIPlotWidget.h>
#include <SUILabel.h>
#include <SUIPlotWidget.h>
#include <SUIPlotAxisEnum.h>
#include <SUIUserControl.h>



/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::DashboardView::LOAD_FILE_DASHBOARD = IGS::Resource::path("IGSxGUIxDashboardView.xml");
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE1 = "Collector Reflection";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE2 = "Droplet Generator";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE3 = "Tin catch remanining";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE4 = "Tin vanes level";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE5 = "Vanes Temperature";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE6 = "Vessel Pressure";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE7 = "Vessel Delta Pressure";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE8 = "Disc Space";
const std::string IGSxGUI::DashboardView::STRING_CONSUMABLE9 = "Network Load";

IGSxGUI::DashboardView::DashboardView(KPIManager* pKpiManager) :
    sui(new SUI::DashboardView)
{
    m_presenter = new DashboardPresenter(this,pKpiManager);
}

IGSxGUI::DashboardView::~DashboardView()
{    
    delete m_presenter;
    delete sui;
}
void IGSxGUI::DashboardView::constructGraphs()
{
    SUI::PlotHistogramItem *histogram = new SUI::PlotHistogramItem("MyHistogram");
    histogram->attach(sui->plwgraph);
    mapPlotHistogram.insert(std::pair<std::string, SUI::PlotHistogramItem*>("MyHistogram", histogram));
    histogram->setBrushColor(SUI::ColorEnum::Blue);

     //Add samples
     SUI::PlotIntervalSample sample1(10,2,3);
     SUI::PlotIntervalSample sample2(20,4,5);
     SUI::PlotIntervalSample sample3(5,6,7);
     SUI::PlotIntervalSample sample4(11,8,9);
     SUI::PlotIntervalSample sample5(18,10,11);
     SUI::PlotIntervalSample sample6(100,12,13);
     histogram->setSample(sample1);
     histogram->setSample(sample2);
     histogram->setSample(sample3);
     histogram->setSample(sample4);
     histogram->setSample(sample5);
     histogram->setSample(sample6);

    sui->plwgraph->replot();


}
void IGSxGUI::DashboardView::constructKPItable1()
{


}
void IGSxGUI::DashboardView::constructKPItable2()
{

}
void IGSxGUI::DashboardView::constructConsumableTable()
{
    sui->lblConsumable1Name->setText(STRING_CONSUMABLE1);
    sui->lblConsumable2Name->setText(STRING_CONSUMABLE2);
    sui->lblConsumable3Name->setText(STRING_CONSUMABLE3);
    sui->lblConsumable4Name->setText(STRING_CONSUMABLE4);
    sui->lblConsumable5Name->setText(STRING_CONSUMABLE5);
    sui->lblConsumable6Name->setText(STRING_CONSUMABLE6);
    sui->lblConsumable7Name->setText(STRING_CONSUMABLE7);
    sui->lblConsumable8Name->setText(STRING_CONSUMABLE8);
    sui->lblConsumable9Name->setText(STRING_CONSUMABLE9);

    sui->lblConsumable1Value->setText("80");
    sui->lblConsumable2Value->setText("80");
    sui->lblConsumable3Value->setText("80");
    sui->lblConsumable4Value->setText("80");
    sui->lblConsumable5Value->setText("300");
    sui->lblConsumable6Value->setText("20");
    sui->lblConsumable7Value->setText("20");
    sui->lblConsumable8Value->setText("50");
    sui->lblConsumable9Value->setText("50");

    sui->lblConsumable1Percentage->setText("%");
    sui->lblConsumable2Percentage->setText("%");
    sui->lblConsumable3Percentage->setText("%");
    sui->lblConsumable4Percentage->setText("%");
    sui->lblConsumable5Percentage->setText("C");
    sui->lblConsumable6Percentage->setText("mBar");
    sui->lblConsumable7Percentage->setText("mBar");
    sui->lblConsumable8Percentage->setText("%");
    sui->lblConsumable9Percentage->setText("%");


}
void IGSxGUI::DashboardView::setHandlers()
{
    sui->uctConsumable1->hoverEntered = boost::bind(&DashboardView::onConsumable1HoverOn, this);
    sui->uctConsumable1->hoverLeft= boost::bind(&DashboardView::onConsumable1HoverOff, this);

    sui->uctConsumable2->hoverEntered = boost::bind(&DashboardView::onConsumable2HoverOn, this);
    sui->uctConsumable2->hoverLeft= boost::bind(&DashboardView::onConsumable2HoverOff, this);
   /*
    sui->uctConsumable3->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable3->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable4->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable4->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable5->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable5->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable6->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable6->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable7->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable7->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable8->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable8->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);

    sui->uctConsumable9->hoverEntered = boost::bind(&DashboardView::onConsumableHoverOn, this);
    sui->uctConsumable9->hoverLeft= boost::bind(&DashboardView::onConsumableHoverOff, this);
    */



}
void IGSxGUI::DashboardView::onConsumable1HoverOn()
{

     sui->gbxConsumable1->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Name->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Time->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Value->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable1Percentage->setStyleSheetClass("uctconsumablehoveron");

}

void IGSxGUI::DashboardView::onConsumable1HoverOff()
{
    sui->gbxConsumable1->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Name->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Time->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Value->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable1Percentage->setStyleSheetClass("uctconsumablehoveroff");


}
void IGSxGUI::DashboardView::onConsumable2HoverOn()
{

     sui->gbxConsumable2->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Name->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Time->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Value->setStyleSheetClass("uctconsumablehoveron");
     sui->lblConsumable2Percentage->setStyleSheetClass("uctconsumablehoveron");

}

void IGSxGUI::DashboardView::onConsumable2HoverOff()
{
    sui->gbxConsumable2->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Name->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Time->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Value->setStyleSheetClass("uctconsumablehoveroff");
    sui->lblConsumable2Percentage->setStyleSheetClass("uctconsumablehoveroff");


}


void IGSxGUI::DashboardView::init()
{


    //Construct Graphs
    constructGraphs();
    constructKPItable1();
    constructKPItable2();
    constructConsumableTable();
/*
    m_listKPIs = m_presenter->getKPIs();

    for (size_t i = 0; i < m_listKPIs.size(); i++)
    {
        KPI* kpi = m_listKPIs[i];

        for (size_t j = 0; j < kpi->getValueSets().size(); j++)
        {
            KPIValueSet* valueSet = kpi->getValueSets()[j];
            std::list<std::string> listRowData;

            listRowData.push_back(kpi->getName());
            listRowData.push_back(valueSet->getName());

            listRowData.push_back(boost::lexical_cast<string>(valueSet->getValue().back()));
            listRowData.push_back("");

            sui->tawKPI->insertRows(i+1,1);
            sui->tawKPI->addData(i+1,listRowData);
        }
    }
    */
}


void IGSxGUI::DashboardView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(LOAD_FILE_DASHBOARD.c_str(), MainScreenContainer);
    init();
    setHandlers();

}

void IGSxGUI::DashboardView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else
    {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::DashboardView::updateKPI(string kpiName, string valueSetName, vector<double> values)
{

    /*
     * for (int i = 1; i < sui->tawKPI->rowCount(); i++)
    {
        if (sui->tawKPI->getItemText(i,0) == kpiName && sui->tawKPI->getItemText(i,1) == valueSetName)
        {
            sui->tawKPI->setItemText(i,2,boost::lexical_cast<string>(values[0]));
            break;
        }
    }
    */
}
