/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxConsumableValueSetTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Consumable ValueSet test
|
| ! \file        IGSxGUIxConsumableValueSetTest.hpp
| ! \brief       Header file for Consumable ValueSet test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCONSUMABLEVALUESETTEST_HPP
#define IGSXGUIXCONSUMABLEVALUESETTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxKPI.hpp"

using std::vector;
using std::list;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSet;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class ConsumableValueSetTest : public ::testing::Test
{
 public:
    ConsumableValueSetTest(){}
    virtual ~ConsumableValueSetTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class ConsumableValueSetTestParam : public ::testing::TestWithParam<std::string>
{
 public:
    ConsumableValueSetTestParam(){}
    virtual ~ConsumableValueSetTestParam(){}
 protected:
    KPIDefinitionList KPIs;
    KPIDefinition KPI_1;
    KPIDefinition KPI_2;
    KPIValueSetDefinition valsetdef_1;
    KPIValueSetDefinition valsetdef_2;
    KPIValueSetDefinitionList kpivalsetdeflist_2;
 protected:
  virtual void SetUp()
  {
    KPIValueSetDefinitionList kpivalsetdeflist_1;

    valsetdef_1.setName("MEAN");
    valsetdef_1.setDescription("MEAN");
    valsetdef_1.setUnit("mJ");
    kpivalsetdeflist_1.push_back(valsetdef_1);

    valsetdef_2.setName("MAX");
    valsetdef_2.setDescription("MAX");
    valsetdef_2.setUnit("µm");
    kpivalsetdeflist_2.push_back(valsetdef_2);

    KPI_1.setName("EUV_Pulse_Energy_Internal");
    KPI_1.setDescription("EUV_Pulse_Energy_Internal");
    KPI_1.setValues(kpivalsetdeflist_1);

    KPI_2.setName("DG_Droplet_Jump_Y");
    KPI_2.setDescription("DG_Droplet_Jump_Y");
    KPI_2.setValues(kpivalsetdeflist_2);

    KPIs.push_back(KPI_1);
    KPIs.push_back(KPI_2);
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXCONSUMABLEVALUESETTEST_HPP
