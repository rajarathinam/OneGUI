/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysis.hpp
| Author       : Venugopal S
| Description  : Header file for Analysis plugin
|
| ! \file        IGSxGUIxAnalysis.hpp
| ! \brief       Header file for Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXANALYSIS_HPP
#define IGSXGUIXANALYSIS_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIAnalysis.hpp"
#include "IGSxGUIxIAnalysisView.hpp"
#include "IGSxGUIxADTManager.hpp"
#include "IGSxGUIxIADTView.hpp"
#include "IGSxGUIxIEventViewerView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class Analysis: public IGSxGUI::IAnalysis
{
 public:
    Analysis();
    virtual ~Analysis();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);
    virtual void showEventViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);

 private:
    Analysis(Analysis const &);
    Analysis& operator=(Analysis const &);

    IAnalysisView *m_analysisView;
    IGSxGUI::IADTView *m_adtView;

    ADTManager* m_adtManager;
    IEventViewerView *m_eventviewer;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXANALYSIS_HPP
