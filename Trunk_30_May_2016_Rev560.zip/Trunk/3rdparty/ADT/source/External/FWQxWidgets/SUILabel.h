//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Label.
// !\description Header file for class SUI::Label.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILABEL_H
#define SUILABEL_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIIAlignable.h"
#include "FWQxCore/SUIIText.h"
#include "FWQxCore/SUIIColorable.h"
#include "FWQxCore/SUIIClickable.h"
#include "FWQxCore/SUIIBGColorable.h"
#include "FWQxCore/SUIFontSizeEnum.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief Specific Interface for the Label Widget
 */
class SUI_SHARED_EXPORT Label : public Widget, public IText, public IAlignable, public IColorable, public IBGColorable, public IClickable
{
public:
    virtual ~Label();

    /*!
     * \brief setFontSize
     * Set the label's font size. Also see FontSizeEnum::FontSize
     * \param fontsize
     */
    virtual void setFontSize(const FontSizeEnum::FontSize &fontsize) = 0;

    /*!
     * \brief
     * Returns the font size (FontSizeEnum::FontSize)
     * \return
     */
    virtual FontSizeEnum::FontSize getFontSize() const = 0;

protected:
    Label();
};
}

#endif // SUILABEL_H
