//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Widget.
// !\description Header file for class SUI::Widget.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIWIDGET_H
#define SUIWIDGET_H

#include "FWQxCore/SUIObject.h"
#include "FWQxCore/SUIRect.h"

#include <list>

namespace SUI {

/*!
 * \ingroup FWQxWidgets
 *
 * \brief Global Interface class for the purpose of the status of the widgets
 */
class SUI_SHARED_EXPORT Widget : public Object
{
public:    
    virtual ~Widget();

    /*!
     * \brief setEnabled
     * Enables (enabled = true) or disables (enabled = false) the widget
     * \param enabled
     */
    virtual void setEnabled(bool enabled);

    /*!
     * \brief isEnabled
     * Returns whether the widget is enabled or not.
     * \return
     */
    virtual bool isEnabled() const;

    /*!
     * \brief setFocus
     * Sets focus to the current widget
     */
    virtual void setFocus();

    /*!
     * \brief clearFocus
     * Clears focus from the current widget
     */
    virtual void clearFocus();

    /*!
     * \brief hasFocus
     * Returns whether the widget has focus
     * \return bool - does the widget have focus
     */
    virtual bool hasFocus() const;

    /*!
     * \brief setToolTip
     * Set the widget's tooltip
     * \param value - the tooltip text. If value is empty, no tooltip will be displayed
     */
    virtual void setToolTip(const std::string &value);

    /*!
     * \brief setStyleSheetClass
     * Sets the stylesheet class name
     * \param styleSheetClass
     */
    void setStyleSheetClass(const std::string &styleSheetClass);

    /*!
     * \brief getStyleSheetClass
     * Returns the name of the stylesheet class
     * \return
     */
    std::string getStyleSheetClass() const;

    /*!
     * \brief setContextMenuItems
     * Sets the entries of the context menu of this widget
     * \param item - string list of context menu entries
     */
    virtual void setContextMenuItems(const std::list<std::string> &item);

    /*!
     * \brief getContextMenuItems
     * Returns a list of strings that define the widget's context menu
     * \return
     */
    virtual std::list<std::string> getContextMenuItems() const;

    /*!
     * \brief setGeometry
     * Sets the geometry of the widget to a rectangle constructed from x, y, w and h.
     * \param x - x position
     * \param y - y position
     * \param w - width
     * \param h - height
     * \note Messagebox widget sizes automatically to fixed size.
     */
    virtual void setGeometry(int x,int y, int w, int h);

    /*!
     * \brief setGeometry
     * Sets the geometry of the widget to a rectangle
     * \param rect - SUI::Rect
     * \note Messagebox widget sizes automatically to fixed size.
     */
    virtual void setGeometry(const SUI::Rect rect);

    /*!
     * \brief getGeometry
     * Extracts the geometry coordinates of the widget into SUI::Rect
     * return SUI::Rect
     */
    virtual SUI::Rect getGeometry() const;

    /*!
     * \brief contextMenuClicked
     * Callback function that is called when the user requests the context menu
     * \return Widget ID and selected menu item
     */
    boost::function<void(const std::string &,const std::string &)> contextMenuClicked;

    /*!
     * \brief Callback function that is called when the widget was hovered.
     * \fn hoverEntering
     * \fn hoverLeaving
     */
    boost::function<void()> hoverEntered;
    boost::function<void()> hoverLeft;

protected:
    explicit Widget(const SUI::ObjectType::Type &type);
};
}
#endif // SUIWIDGET_H
