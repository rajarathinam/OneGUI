//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ProgressBar.
// !\description Header file for class SUI::ProgressBar.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPROGRESSBAR_H
#define SUIPROGRESSBAR_H

#include "FWQxWidgets/SUIWidget.h"

#include "FWQxCore/SUIIText.h"
#include "FWQxCore/SUIIOrientable.h"
#include "FWQxCore/SUIIColorable.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The ProgressBar class
 */
class SUI_SHARED_EXPORT ProgressBar : public Widget, public IText, public IOrientable, public IColorable
{
public:
    virtual ~ProgressBar();

    /*!
     * \brief getValue
     * Returns the current value of the progress bar. Current value remains unchanged
     * if a value outside the minimum-maximum range is set
     * \return : the value
     */
    virtual int getValue() const = 0;

    /*!
     * \brief setValue
     * Set the percentage value. If percentage is outside the minimum-maximum range,
     * the percentage is not applied
     * \param percentage: value to be set
     */
    virtual void setValue(int percentage) = 0;

    /*!
     * \brief disablePercentage
     * The % character can removed (disabled == true) from or
     * added to (disabled == false) the progressbar.
     * \param disabled - true will remove the % from the text
     */
    virtual void disablePercentage(bool disabled) = 0;

    /*!
     * \brief isPercentageDisabled
     * Returns the disabled state for the percentage sign
     * \return : the disabled state of the percentage sign
     */
    virtual bool isPercentageDisabled() const = 0;

    /*!
     * \brief startTimedProgress
     * The Progressbar shows a progress over the expected amount of time
     * \param int expectedSecs - The amount of time that the progressbar is supposed to show progress.
     */
    virtual void startTimedProgress(int expectedSecs) = 0;

    /*!
     * \brief stopTimedProgress
     * The Progressbar stops showing progress and sets the value to 100%
     * \param int showReadyMSecs - The amount of milliseconds the progress should show 100% before being reset to 0. Value of 0 means it will not be reset.
     */
    virtual void stopTimedProgress(int showReadyMSecs) = 0;

    /*!
     * \brief progressChanged
     * Callback function that is called when the value has changed.
     * \fn valueChanged
     */
    boost::function<void()> progressChanged;
    
protected:
    ProgressBar();
};
}

#endif // SUIPROGRESSBAR_H
