//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::PlotCurveItem.
// !\description Header file for class SUI::PlotCurveItem.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|

#ifndef SUIPlOTCURVEITEM__H
#define SUIPlOTCURVEITEM__H

#include "FWQxWidgets/SUIPlotItem.h"
#include "FWQxCore/SUIColorEnum.h"
#include "FWQxCore/SUILineStyleEnum.h"
#include "FWQxCore/SUIMarkerSymbolEnum.h"
#include "FWQxCore/SUIPlotAxisEnum.h"
#include "FWQxWidgets/SUIPlotDataPoint.h"

namespace SUI {
/*!
 * \ingroup FWQxWidgets
 *
 * \brief The PlotCurveItem class
 */
class PlotWidget;
class SUI_SHARED_EXPORT PlotCurveItem : public PlotItem
{
public:
    PlotCurveItem(const std::string &setName , SUI::PlotAxisEnum::PlotAxis side);
    virtual ~PlotCurveItem();

    //Interface functions
    virtual void attach(PlotWidget *plot);
    virtual void detach();
    virtual void setTitle(const std::string &title);
    virtual std::string getTitle() const;
    virtual void show();
    virtual void hide();
    virtual void setVisible(bool visible);
    virtual bool isVisible () const;
    virtual void setAxes(PlotAxisEnum::PlotAxis xAxis, PlotAxisEnum::PlotAxis yAxis);
    virtual void setXAxis(PlotAxisEnum::PlotAxis xAxis);
    virtual PlotAxisEnum::PlotAxis getXAxis() const;
    virtual void setYAxis(PlotAxisEnum::PlotAxis axis);
    virtual PlotAxisEnum::PlotAxis getYAxis() const;
    virtual double getZ() const;
    virtual void setZ(double z);

    /*!
     * \brief setCustomPenColor
     * Sets the (custom) RGB color of the pen
     * \param color
     */
    virtual void setCustomPenColor( const SUI::PlotItemCustomColor color);

    /*!
     * \brief getCustomPenColor
     * Returns the pen's RGB color
     * \return
     */
    virtual SUI::PlotItemCustomColor getCustomPenColor() const;

    /*!
     * \brief setColor
     * Sets the color of the curve
     * \param color - The color to set(SUI::ColorEnum::Color)
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setColor(const SUI::ColorEnum::Color color);

    /*!
     * \brief getColor
     * Returns the color of the curve
     * \return SUI::ColorEnum::Color - color
     */
    SUI::ColorEnum::Color getColor() const;

    /*!
     * \brief setWidth
     * Sets the width of the curve
     * \param width
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setWidth(const int penWidth);

    /*!
     * \brief getWidth
     * Returns the width of the curve
     * \return int - width
     */
    int getWidth() const;

    /*!
     * \brief setStyle
     * Sets the line style of the curve
     * \param style - Line Style(SUI::LineStyleEnum::LineStyle)
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setStyle(const LineStyleEnum::LineStyle linestyle);

    /*!
     * \brief getStyle
     * Returns the line style of the curve
     * \return SUI::LineStyleEnum::LineStyle
     */
    SUI::LineStyleEnum::LineStyle getStyle() const;

    /*!
     * \brief setPlotMarker
     * Sets the marker (color, symbol and size) for the curve datapoints
     * \param markerSymbol - The symbol to set (SUI::MarkerSymbolEnum::MarkerSymbol)
     * \param color - The color to set(SUI::ColorEnum::Color)
     * \param width - The width to set
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setPlotMarker(MarkerSymbolEnum::MarkerSymbol markerSymbol, SUI::ColorEnum::Color color,int width);

    /*!
     * \brief clearSamples
     *  Clear data samples plotted
     * \note Call to replot on Plot widget is required to see the changes
     */
    void clearSamples();

    /*!
     * \brief setSamples
     * Set and add data with an array of PlotDataPoint samples.
     * This function sets and adds a collection of data points to the curve.
     * \param values - std::vector<SUI::PlotDataPoint>
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setSamples(const std::vector<SUI::PlotDataPoint> &values);

    /*!
     * \brief setSamples
     * This function sets and add a data point to the curve.
     * Set and add data with a datapoint sample.
     * \param value - SUI::PlotDataPoint
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setSample(const SUI::PlotDataPoint &value);

    /*!
     * \brief setRawSamples
     * This function sets a collection of data points to the curve.
     * No deep copy is created, so the plot data needs to be kept alive
     * \param xData   - The X point array.
     * \param yData   - The Y point array.
     * \param size    - size of xData and YData.
     * \note Call to replot on Plot widget is required to see the changes
     */
    void setRawSamples(const double *xData, const double *yData, int size);

private:
    friend class ObjectFactory;
    explicit PlotCurveItem(SUI::PlotItem *parent = NULL);
    PlotCurveItem(const PlotCurveItem &copy);
    PlotCurveItem &operator=(const PlotCurveItem &copy);

    void plotCurve();
    SUI::ColorEnum::Color mColor;
    SUI::LineStyleEnum::LineStyle mLineStyle;
    std::vector<SUI::PlotDataPoint> dataPoints;    
};

}
#endif // SUIPlOTCURVEITEM__H
