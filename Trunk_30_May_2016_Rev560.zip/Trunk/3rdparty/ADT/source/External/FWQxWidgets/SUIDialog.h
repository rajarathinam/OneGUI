//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::Dialog.
// !\description Header file for class SUI::Dialog.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDIALOG_H
#define SUIDIALOG_H

#include "FWQxWidgets/SUIWidget.h"
#include "FWQxCore/SUIICloseable.h"

#include <boost/function.hpp>

namespace SUI {
class ObjectList;

/*!
 * \ingroup FWQxWidgets
 *
 * \brief The Dialog class
 */
class SUI_SHARED_EXPORT Dialog : public Widget, public ICloseable
{
public:
    Dialog();
    virtual ~Dialog(){}

    /*!
     * \brief quit
     * Closes the application without sending the closed event.
     */
    virtual void quit() = 0;

    /*!
     * \brief getObjectList
     * Returns the list of objects, currently part of the dialog
     * \return
     */
    virtual ObjectList *getObjectList() = 0;

    /*!
     * \brief setWindowTitle
     * Sets the title of to window to windowName
     * \param windowName
     */
    virtual void setWindowTitle(const std::string &windowName) = 0;

    /*!
     * \brief getWindowTitle
     * Returns the window title
     * \return
     */
    virtual std::string getWindowTitle() const = 0;

    /*!
     * \brief getFileName
     * Gets the filename of the ui definition file (xml)
     * \return
     */
    virtual std::string getFileName() const = 0;

    /*!
     * \brief setModal
     * Set the dialog to be modal (modal == true) or modeless (modal == false).
     * Default mode is modeless.
     * Modal: the main window (parent) is disabled, but kept visible
     * with this child window in front of it. The user must interact with the
     * child window, before he/she can return to the parent window
     * \return
     */
    virtual void setModal(bool modal) = 0;

};
}
#endif // SUIDIALOG_H
