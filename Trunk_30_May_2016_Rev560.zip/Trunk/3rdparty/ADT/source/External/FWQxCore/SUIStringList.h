//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::StringList.
// !\description Header file for class SUI::StringList.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISTRINGLIST_H
#define SUISTRINGLIST_H

#include "FWQxCore/SUIList.h"

namespace SUI {

/*!
 * \ingroup FWQxCore
 *
 * \brief Global Interface class handling the string list properties of widgets
 */
class StringList : public List<std::string>
{
public:
    virtual ~StringList() {}
};
}

#endif // SUISTRINGLIST_H
