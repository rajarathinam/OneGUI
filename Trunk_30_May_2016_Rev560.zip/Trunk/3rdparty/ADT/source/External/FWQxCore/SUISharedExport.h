//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Shared Export Library.
// !\description Shared Export Library.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUISHAREDEXPORT_H
#define SUISHAREDEXPORT_H

#if defined(__linux__) || defined(__linux)
#  define SUI_OS_LINUX
#elif defined(__ARMCC__) || defined(__CC_ARM)
#  define SUI_CC_RVCT
#elif !defined(SAG_COM) && (defined(WIN64) || defined(_WIN64) || defined(__WIN64__))
#  define SUI_OS_WIN32
#  define SUI_OS_WIN64
#elif !defined(SAG_COM) && (defined(WIN32) || defined(_WIN32) || defined(__WIN32__) || defined(__NT__))
#  if defined(WINCE) || defined(_WIN32_WCE)
#    define SUI_OS_WINCE
#  else
#    define SUI_OS_WIN32
#  endif
#elif defined(__MWERKS__) && defined(__INTEL__)
#  define SUI_OS_WIN32
#elif defined(__MWERKS__) &&  defined(__EMU_SYMBIAN_OS__)
#  define SUI_CC_NOKIAX86
#endif

#if defined(SUI_OS_WIN32) || defined(SUI_OS_WIN64) || defined(SUI_OS_WINCE)
#  define SUI_OS_WIN
#endif


#if defined(SUI_OS_LINUX) && defined(SUI_CC_RVCT)
#  define SUI_DECL_EXPORT     __attribute__((visibility("default")))
#  define SUI_DECL_IMPORT     __attribute__((visibility("default")))
#  define SUI_DECL_HIDDEN     __attribute__((visibility("hidden")))
#endif

#ifndef SUI_DECL_EXPORT
#  if defined(SUI_OS_WIN) || defined(SUI_CC_NOKIAX86) || defined(SUI_CC_RVCT)
#    define SUI_DECL_EXPORT __declspec(dllexport)
#  else
#    define SUI_DECL_EXPORT __attribute__((visibility("default")))
#    define SUI_DECL_HIDDEN __attribute__((visibility("hidden")))
#  endif
#  ifndef SUI_DECL_EXPORT
#    define SUI_DECL_EXPORT
#  endif
#endif

#ifndef SUI_DECL_IMPORT
#  if defined(SUI_OS_WIN) || defined(SUI_CC_NOKIAX86) || defined(SUI_CC_RVCT)
#    define SUI_DECL_IMPORT __declspec(dllimport)
#  else
#    define SUI_DECL_IMPORT
#  endif
#endif

#if defined(SUICORE_LIBRARY) || (FWQ_LIBRARY) || (SUIOBJECT_LIBRARY) || (SUIGUI_LIBRARY) || (SUIOBJECTIMPL_LIBRARY) || (SUIOBJECTINTERNAL_LIBRARY)
#  define SUI_SHARED_EXPORT SUI_DECL_EXPORT
#else
#  define SUI_SHARED_EXPORT SUI_DECL_IMPORT
#endif

#endif // SUI_SHARED_EXPORT_H
