//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::ObjectFactoryImpl.
// !\description Header file for class SUI::ObjectFactoryImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIOBJECTFACTORYIMPL_H
#define SUIOBJECTFACTORYIMPL_H

#include "FWQxCore/SUIObjectFactory.h"

namespace SUI {
class ObjectFactoryImpl : public ObjectFactory
{
public:
    virtual ~ObjectFactoryImpl();

    virtual BaseWidget *createWidget(ObjectType::Type widgetType, QWidget *parent = NULL, ObjectList *widgetList = NULL);
    virtual Widget *toWidget(BaseObject *object);
    virtual Object *toObject(BaseObject *object);
    virtual BaseObject *toBaseObject(Object *object);
    virtual BaseObject *toBaseObject(const Object *object);
    virtual BaseWidget *toBaseWidget(Widget *object);
    virtual BaseWidget *toBaseWidget(const Widget *object);

    static Object *baseObjectToObject(BaseObject *object);
    static BaseObject *objectToBaseObject(Object *object);

    virtual Widget *createButton(QWidget *parent = NULL);
    virtual Widget *createLabel(QWidget *parent = NULL);
    virtual Widget *createLineEdit(QWidget *parent = NULL);
    virtual Widget *createRadioButton(QWidget *parent = NULL);
    virtual Widget *createTabWidget(QWidget *parent = NULL);
    virtual Widget *createTabPage(QWidget *parent = NULL);
    virtual Widget *createCheckBox(QWidget *parent = NULL);
    virtual Widget *createGroupBox(QWidget *parent = NULL);
    virtual Widget *createCheckGroupBox(QWidget *parent = NULL);
    virtual Widget *createButtonBar(QWidget *parent = NULL);
    virtual Widget *createTableWidget(QWidget *parent = NULL);
    virtual Widget *createTableWidgetItem(QWidget *parent = NULL);
    virtual Widget *createSpinBox(QWidget *parent = NULL);
    virtual Widget *createDoubleSpinBox(QWidget *parent = NULL);
    virtual Widget *createDropDown(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createCheckMark(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createLEDWidget(QWidget *parent = NULL);
    virtual Widget *createColorDrop(QWidget *parent = NULL);
    virtual Widget *createColorCrossDrop(QWidget *parent = NULL);
    virtual Widget *createTextArea(QWidget *parent = NULL);
    virtual Widget *createProgressBar(QWidget *parent = NULL);
    virtual Widget *createImageViewer(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createMessageBox(QWidget *parent = NULL);
    virtual Widget *createSplitter(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createFileDialog(QWidget *parent = NULL);
    virtual Widget *createUserControl(QWidget *parent = NULL);
    virtual Widget *createPlotWidget(QWidget *parent = NULL);
    virtual Widget *createListView(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createControlWidget(QWidget *parent = NULL);
    virtual Widget *createStateWidget(QWidget *parent = NULL);
    virtual Widget *createScienceSpinBox(QWidget *parent = NULL);
    virtual Widget *createQuestionMark(QWidget *parent = NULL);
    virtual Widget *createBusyIndicator(QWidget *parent = NULL);
    virtual Widget *createImageWidget(QWidget *parent = NULL);
    virtual Widget *createTreeView(QWidget *parent = NULL);
    virtual Widget *createTreeViewItem(QWidget *parent = NULL);
    virtual Widget *createLineWidget(QWidget *parent = NULL);
    virtual SUI_DEPRECATED Widget *createSvgWidget(QWidget *parent = NULL);
    virtual Widget *createWidgetPage(QWidget *parent = NULL);
    virtual Widget *createScrollBar(QWidget *parent = NULL);
    virtual Widget *createContainer(QWidget *parent = NULL);
    virtual Widget *createDateTimeEdit(QWidget *parent = NULL);
    virtual Widget *createWebView(QWidget *parent = NULL);

private:
    ObjectFactoryImpl();
    ObjectFactoryImpl(const ObjectFactoryImpl &copy);
    ObjectFactoryImpl operator=(const ObjectFactoryImpl &copy);

    friend class ObjectFactory;
};
}

#endif // SUIOBJECTFACTORY_H
