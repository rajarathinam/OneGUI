//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::RadioButtonImpl.
// !\description Header file for class SUI::RadioButtonImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIRADIOBUTTONIMPL_H
#define SUIRADIOBUTTONIMPL_H

#include <QRadioButton>

#include "SUIBaseWidget.h"
#include "FWQxWidgets/SUIRadioButton.h"

namespace SUI {
/*!
 * \ingroup SUIWidgetFactory
 * \ingroup SUIWidget
 * \ingroup SUIInternal
 *
 * \brief The RadioButton class
 */
class RadioButtonImpl: public BaseWidget, public RadioButton
{
    Q_OBJECT

public:
    explicit RadioButtonImpl(QWidget *parent = NULL);

    virtual void initialize(const ObjectContext &context);
    virtual QRadioButton *getWidget() const;
    virtual void setPropertyValue(SUI::ObjectPropertyTypeEnum::Type propertyID, QString propertyValue);

    virtual void setChecked(bool checked);
    virtual bool isChecked() const;
    virtual void setText(const std::string &value);
    virtual std::string getText() const;
    virtual void clearText();
    virtual void setBold(bool bold);
    virtual bool isBold() const;

private slots:
    void handleCheckedChanged(bool newState);

private:
    RadioButtonImpl(const RadioButtonImpl &rhs);
    RadioButtonImpl &operator=(const RadioButtonImpl &rhs);
};
}

#endif // SUIRADIOBUTTONIMPL_H


