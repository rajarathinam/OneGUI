//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::DateImpl.
// !\description Header file for class SUI::DateImpl.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUIDATEIMPL_H
#define SUIDATEIMPL_H

#include <QDate>

#include <FWQxUtils/SUIDate.h>

namespace SUI {

class DateImpl : public QDate, public Date
{
private:
    explicit DateImpl();

    friend class Date;

public:
    virtual void addDays(int ndays);
    virtual void addMonths(int nmonths);
    virtual void addYears(int nyears);
    virtual int getDay() const;
    virtual int getDayOfWeek() const;
    virtual int getDayOfYear() const;
    virtual int getDaysInMonth() const;
    virtual int getDaysInYear() const;
    virtual int getDaysTo(const Date *d) const;
    virtual void getDate(int * getYear, int * getMonth, int * getDay);
    virtual bool isNull() const;
    virtual bool isValid() const;
    virtual int getMonth() const;
    virtual bool setDate(int getYear, int getMonth, int getDay);
    virtual int toJulianDay() const;
    virtual std::string toString(const std::string &format) const;
    virtual std::string toString(DateTimeEnum::DateFormat format = DateTimeEnum::TextDate) const;
    virtual int getWeekNumber(int * yearNumber = 0) const;
    virtual int getYear() const;

    virtual bool operator!=(const boost::shared_ptr<Date> &d) const;
    virtual bool operator<(const boost::shared_ptr<Date> &d) const;
    virtual bool operator<=(const boost::shared_ptr<Date> &d) const;
    virtual bool operator==(const boost::shared_ptr<Date> &d) const;
    virtual bool operator>(const boost::shared_ptr<Date> &d) const;
    virtual bool operator>=(const boost::shared_ptr<Date> &d) const;


};

} // namespace SUI

#endif // SUI_SUIDATEIMPL_H
