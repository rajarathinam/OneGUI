//----------------------------------------------------------------------------|
//                                                                            |
//                             C++ Source/Header File                         |
//                                                                            |
//----------------------------------------------------------------------------|
//
// !\author
// !\brief       Header file for class SUI::LegacyXMLConverter.
// !\description Header file for class SUI::LegacyXMLConverter.
//
//----------------------------------------------------------------------------|
//                                                                            |
//               Copyright (c) 2016, ASML Netherlands B.V.                    |
//                          All rights reserved                               |
//                                                                            |
//----------------------------------------------------------------------------|


#ifndef SUILEGACYXMLCONVERTER_H
#define SUILEGACYXMLCONVERTER_H

#include <QString>
#include <QTextStream>

#include "FWQxCore/SUIVersionInfo.h"

namespace SUI {

struct replacementString {
    QString oldName;
    QString newName;
};

class LegacyXMLConverter
{
public:
    static void convertLegacyXmlFile(const QString &fileName, const QString &newFileName);
    
    static const std::vector<SUI::replacementString> getReplacementStrings();
    
    static VersionInfo getVersionInfo(const QString &xmlFileName);
    static void updateVersionInfo(const QString &xmlFileName);

    static bool isLegacy(const QString &xmlFileName);
    
private:
    static QString updateVersionInfoPrivate(QString &fileContent);
    static QString readFile(const QString &fileName);
    static void writeFile(const QString &fileName, const QString &fileContent);

    static QString doConversion(QString content);
    static replacementString createReplacementString(QString oldName, QString newName);


};

} // namespace SUI

#endif // SUI_SUILEGACYXMLCONVERTER_H
