/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTView.hpp
| Author       : Raja A
| Description  : Header file for ADT view
|
| ! \file        IGSxGUIxADTView.hpp
| ! \brief       Header file for ADT view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTVIEW_HPP
#define IGSXGUIXADTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxIADTView.hpp"
#include "IGSxGUIxADTPresenter.hpp"
#include <SUIButton.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class ADTView;
class Label;
class UserControl;
class GroupBox;
class GraphicsView;
}  // namespace SUI

namespace IGSxGUI{

struct structContainer
{
    std::string name;
    ADT* adt;
};
typedef structContainer container;

struct structSubsystemCount
{
    std::string nameSubsystem;
    int count;
};
typedef structSubsystemCount subSystemCount;

class ADTView : public IADTView
{
 public:
    explicit ADTView(ADTManager *pADTManager);
    virtual ~ADTView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const IGS::Result& result);
    virtual void setActive(bool bActive);

 private:
    ADTView(const ADTView &);
    ADTView& operator=(const ADTView &);

    void onActiveADTDetailButtonPressed();

    void onButtonADT1StartPressed();
    void onButtonADT2StartPressed();
    void onButtonADT3StartPressed();
    void onButtonADT4StartPressed();
    void onButtonADT5StartPressed();
    void onButtonADT6StartPressed();
    void onButtonADT7StartPressed();
    void onButtonADT8StartPressed();
    void onButtonADT9StartPressed();
    void onButtonADT10StartPressed();

    void onButtonADT1DetailPressed();
    void onButtonADT2DetailPressed();
    void onButtonADT3DetailPressed();
    void onButtonADT4DetailPressed();
    void onButtonADT5DetailPressed();
    void onButtonADT6DetailPressed();
    void onButtonADT7DetailPressed();
    void onButtonADT8DetailPressed();
    void onButtonADT9DetailPressed();
    void onButtonADT10DetailPressed();

    void onButtonPrevPressed();
    void onButtonNextPressed();
    void onButtonOnePressed();
    void onButtonTwoPressed();
    void onButtonThreePressed();
    void onButtonFourPressed();

    void onSubsystemPressed();
    void onButtonShowReportsPressed();

    void loadContainers();
    void loadTestTypes();
    void loadSubSystems();
    void setHandlers();
    void setTextArea(const std::string& adtDescription, const std::string& adtTestName, const std::string& adtTestType) const;
    void loadADTs();
    void startADT(const std::string& adtName) const;
    void init();
    void setInfoButtonStyles();
    void initNumberedButtons(const int& numTotalPages);
    void fetchADTs(const int &nCurrentPageNumber);
    void configNavigationButtons(int buttonNumber);
    void modifyPrevNextButtons();
    void showADTReportPage(int nCurrentItem, SUI::Button *btnADTInfo, const std::string& adtDescription, const std::string& adtTestName, const std::string& adtTestType);
    void setNumberedButtonStyles(const int &nCurrentPage, const std::string& style) const;
    std::vector<ADT*> getTestTypeADTs() const;
    std::vector<ADT*> getTestADTsByName(const std::string& testtypeName);
    std::vector<ADT*> getSelectedSubSystemADTs();
    void intersectADTs(std::vector<ADT*> listTestTypeADTs, std::vector<ADT*> listSubSystemADTs);

    SUI::ADTView *sui;
    ADTPresenter *m_presenter;

    std::vector<SUI::UserControl*> m_listADTUCT;
    std::vector<SUI::Label*> m_listADTNameLabels;
    std::vector<SUI::Label*> m_listADTTypeLabels;
    std::vector<SUI::GraphicsView*> m_listADTTypeImvs;
    std::vector<SUI::Label*> m_listADTDescriptionLabels;
    std::vector<SUI::Label*> m_listADTTimeLabels;
    std::vector<SUI::Button*> m_listDisplayButtons;
    std::vector<SUI::Button*> m_listInfoButtons;

    std::vector<SUI::GroupBox*> m_listADTReportGroupBox;
    std::vector<SUI::Label*> m_listADTReportNameLabels;
    std::vector<SUI::Label*> m_listADTReportTypeLabels;
    std::vector<SUI::Label*> m_listADTReportDescriptionLabels;

    std::vector<ADT*> m_listADT;
    std::vector<ADT*> m_listSubsystemADTs;
    std::vector<IGSxGUI::container> m_listTestTypes;
    std::vector<IGSxGUI::container> m_listSubsystems;
    std::vector<IGSxGUI::subSystemCount> m_listSubsystemCount;

    int m_numTotalPages;
    int m_numLastPageItems;
    int m_currentPageNo;
    int m_nPreviousDetailItem;

    bool m_bRunningADT;
    std::string m_selectedSubSystem;
    std::string m_selectedADT;

    static const std::string STRING_ALL_ADTS;
    static const std::string ADTVIEW_LOAD_FILE;
    static const std::string STRING_NO_ACTIVE_ADT;
    static const std::string STRING_TIME;
    static const std::string STRING_DATE;
    static const std::string STRING_CALIBRATION;
    static const std::string STRING_PERFORMANCE;
    static const std::string STRING_DIAGNOSTICS;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STYLE_NORMAL;
    static const std::string STYLE_CURRENTPAGE;
    static const std::string STYLE_ADTINFO;
    static const std::string STYLE_ACTIVE_ADT;
    static const std::string STYLE_NO_ACTIVE_ADT;
    static const std::string IMAGE_CLOCK;
    static const std::string STRING_ADT_HPAC;
    static const std::string STRING_ADT_ATTENTION;
    static const std::string STRING_EMPTY;
    static const std::string STRING_DATETIME_FORMAT1;
    static const std::string STRING_DATETIME_FORMAT2;
    static const std::string STRING_SPACE;
    static const std::string IMAGE_CALIBRATION;
    static const std::string IMAGE_PERFORMANCE;
    static const std::string IMAGE_DIAGNOSTICS;

    static const int ADT_REPORT_PAGE_NUMBER_ONE;
    static const int ADT_REPORT_PAGE_NUMBER_TWO;
    static const int ADT_REPORT_PAGE_NUMBER_THREE;
    static const int ADT_REPORT_PAGE_NUMBER_FOUR;
    static const int ADT_REPORT_PAGE_NUMBER_FIVE;
    static const int ADT_REPORT_PAGE_NUMBER_SIX;
    static const int ADT_REPORT_PAGE_NUMBER_SEVEN;
    static const int ADT_REPORT_PAGE_NUMBER_EIGHT;
    static const int ADT_REPORT_PAGE_NUMBER_NINE;
    static const int ADT_REPORT_PAGE_NUMBER_TEN;

    static const int TIMER_INTERVAL;
    static const int CONVERSION_BUFFER_SIZE;
    static const int ITEMS_TO_REMOVE;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXADTVIEW_HPP
