/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMain.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main function
|
| ! \file        IGSxGUIxMain.cpp
| ! \brief       Implementation of Main function
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <SUIApplication.h>
#include "IGSxGUIxIMainView.hpp"
#include "IGSxGUIxMainView.hpp"
#include "IGSxIStubView.hpp"
#include "IGSxStubView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string STRING_SIMULATION = "simulation";

int main(int argc, char *argv[])
{
    int result = 1;
    // instantiate the application
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc, argv);

    if (argc == 1)
    {
        IGSxGUI::PluginFactory::getInstance().initialize();
        IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();

        if (mainView != NULL)
        {
            mainView->show();
            result = app->exec();
            delete mainView;
            mainView = NULL;
        }
    } else {
        std::string strPluginName(argv[1]);

        if (strPluginName == STRING_SIMULATION)
        {
           IGSxGUI::IStubView *stubView;
           stubView = new IGSxGUI::StubView();

           if (stubView != NULL)
           {
              stubView->show();
           }

           IGSxGUI::PluginFactory::getInstance().initialize();
           IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();

           if (mainView != NULL)
           {
              mainView->show();
              result = app->exec();
              delete mainView;
              mainView = NULL;

              if (stubView != NULL)
              {
                 delete stubView;
                 stubView = NULL;
              }
           }
        }
    }
    // execute the application (main eventloop)
    return result;
}

