/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Source File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR_impl.cpp
| Author       : Surya Tiwari
| Description  : Implementation of IGSxERR interface
|
| ! \file        IGSxERR_impl.cpp
| ! \brief       Implementation of IGSxERR interface
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxERR_impl.hpp"
#include <boost/bind.hpp>
#include <boost/lexical_cast.hpp>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const int IGSxERR::Alert_Stub::ALERT_TIMER_INTERVAL= 100000;
const int IGSxERR::Alert_Stub::ALERT_TIMER_MIN_INTERVAL= 100000;
const int IGSxERR::Alert_Stub::ALERT_TIMER_MAX_INTERVAL= 300000;
const std::string IGSxERR::Alert_Stub::USER_CODE= "This is a very nice description of a very bad error.";
const std::string IGSxERR::Alert_Stub::DEVELOPER_CODE= "Developer text we do not want to see this!";
const std::string IGSxERR::Alert_Stub::LOGCODE_PREFIX = "ABC-0";

IGSxERR::EventLogger *IGSxERR::EventLogger_Stub::getInstance()
{
    static EventLogger_Stub _instance;
    return &_instance;
}

IGSxERR::Alert *IGSxERR::Alert_Stub::getInstance()
{
    static Alert_Stub _instance;
    return &_instance;
}

IGSxERR::EventLogger* IGSxERR::EventLogger::instance = IGSxERR::EventLogger_Stub::getInstance();
IGSxERR::Alert* IGSxERR::Alert::instance = IGSxERR::Alert_Stub::getInstance();

IGSxERR::EventLogger_Stub::EventLogger_Stub():m_currentfilename("/home/adt/EventLogs/XER_event_log"),m_previousfilename("/home/adt/EventLogs/XER_event_log_S97391_20161210_144317")
{
}

IGSxERR::Alert_Stub::Alert_Stub() :
    m_timerAlertCreate(SUI::Timer::createTimer()),
    m_timerAlertKill(SUI::Timer::createTimer()),
    m_uniqueAlertId(0),
    m_AlertRaisedCb(NULL),
    m_AlertDeactivatedCb(NULL)
{
    m_timerAlertCreate->setInterval(ALERT_TIMER_INTERVAL);
    m_timerAlertKill->setInterval(ALERT_TIMER_MAX_INTERVAL);

    m_timerAlertCreate->timeout = boost::bind(&Alert_Stub::onAlertCreateTimeout, this);
    m_timerAlertKill->timeout = boost::bind(&Alert_Stub::onAlertKillTimeout, this);
}

IGSxERR::Alert_Stub::~Alert_Stub()
{
    m_timerAlertCreate->stop();
    m_timerAlertKill->stop();
}

void IGSxERR::Alert_Stub::onAlertCreateTimeout()
{
    int logId = ++m_uniqueAlertId;
    std::string logCode = LOGCODE_PREFIX + boost::lexical_cast<std::string>(m_uniqueAlertId);
    std::string userCode = USER_CODE + logCode;
    std::string developerCode = DEVELOPER_CODE + logCode;

    ActivatedAlert newAlert(logId, logCode, time(NULL), getAlertSeverity(), userCode , developerCode);
    m_ActiveAlertList.push_back(newAlert);

    if (m_AlertRaisedCb)
    {
        m_AlertRaisedCb(newAlert);
    }

    m_timerAlertCreate->start(getRandomNumber(ALERT_TIMER_MIN_INTERVAL,ALERT_TIMER_MAX_INTERVAL));
}

void IGSxERR::Alert_Stub::raiseAlert(std::string logCode, std::string userText, IGSxERR::AlertSeverity::AlertSeverityEnum severity)
{
    int logId = ++m_uniqueAlertId;

    ActivatedAlert newAlert(logId, logCode, time(NULL), severity, userText , "");
    m_ActiveAlertList.push_back(newAlert);

    if (m_AlertRaisedCb)
    {
        m_AlertRaisedCb(newAlert);
    }
}

void IGSxERR::Alert_Stub::onAlertKillTimeout()
{
    if (m_ActiveAlertList.size() > 0)
    {
        unsigned int indexRandomAlert = getRandomNumber(0, m_ActiveAlertList.size());

        if(indexRandomAlert == m_ActiveAlertList.size())
        {
            indexRandomAlert = indexRandomAlert - 1;
        }
        ActivatedAlert alert = m_ActiveAlertList[indexRandomAlert];
        DeactivatedAlert deactAlert(alert.logId());

        m_ActiveAlertList.erase(m_ActiveAlertList.begin() + indexRandomAlert);

        if (m_AlertDeactivatedCb)
        {
            m_AlertDeactivatedCb(deactAlert);
        }
    }
    m_timerAlertKill->start(ALERT_TIMER_MAX_INTERVAL);
}

int IGSxERR::Alert_Stub::getRandomNumber(int low, int high) const
{
    srand(time(NULL));
    return rand() % (high - low + 1) + low;
}

IGSxERR::AlertSeverity::AlertSeverityEnum IGSxERR::Alert_Stub::getAlertSeverity() const
{
    int nAlertSeverity = m_uniqueAlertId % 4;

    if (nAlertSeverity == 0)
    {
        return  IGSxERR::AlertSeverity::EVENT;
    } else if (nAlertSeverity == 1) {
        return  IGSxERR::AlertSeverity::WARNING;
    } else if (nAlertSeverity == 2) {
        return  IGSxERR::AlertSeverity::ERROR;
    } else {
        return  IGSxERR::AlertSeverity::ALARM;
    }
}

void IGSxERR::Alert_Stub::getActiveAlerts(IGSxERR::ActiveAlertList &alerts)
{
    if (alerts.size() > 0)
    {
        alerts.clear();
    }
    alerts = m_ActiveAlertList;
}

void IGSxERR::Alert_Stub::subscribeToAlertRaised(const IGSxERR::AlertRaisedCallback &cb)
{
    m_AlertRaisedCb = cb;
}

void IGSxERR::Alert_Stub::unsubscribeToAlertRaised()
{
    if (m_AlertRaisedCb)
    {
        m_AlertRaisedCb = NULL;
    }
}

void IGSxERR::Alert_Stub::subscribeToAlertDeactivated(const IGSxERR::AlertDeactivatedCallback &cb)
{
    m_AlertDeactivatedCb = cb;
}

void IGSxERR::Alert_Stub::unsubscribeToAlertDeactivated()
{
    if (m_AlertDeactivatedCb)
    {
        m_AlertDeactivatedCb = NULL;
    }
}

void IGSxERR::Alert_Stub::enableGenerateAlerts(bool generateAlerts)
{
    if (generateAlerts)
    {
        m_timerAlertCreate->start();
        m_timerAlertKill->start();
    } else {
        m_timerAlertCreate->stop();
        m_timerAlertKill->stop();
    }
}

std::string IGSxERR::EventLogger_Stub::getEventLog()
{
    return m_currentfilename;
}

std::string IGSxERR::EventLogger_Stub::getPreviousEventLog()
{
    return m_previousfilename;
}
