/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTTest.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT test
|
| ! \file        IGSxGUIxADTTest.cpp
| ! \brief       Implementation of ADT test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTTest.hpp"
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(ADTTest, Test_1)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);

    std::string adtname = adt.getName();
    std::string adtmetaname = metaData.name();
    EXPECT_STRCASEEQ(adtname.c_str(), adtmetaname.c_str());

    std::string adtdescription = adt.getDescription();
    std::string adtmetadescription = metaData.description();
    EXPECT_STRCASEEQ(adtdescription.c_str(), adtmetadescription.c_str());

    std::string adtsubsystem = adt.getSubsystem();
    std::string adtmetasubsystem = metaData.subSystem();
    EXPECT_STRCASEEQ(adtsubsystem.c_str(), adtmetasubsystem.c_str());

    std::string adthtmlfile = adt.getHtmlFile();
    std::string adtmetahtmlfile = metaData.htmlFile();
    EXPECT_STRCASEEQ(adthtmlfile.c_str(), adtmetahtmlfile.c_str());
}

TEST_F(ADTTest, Test_2)
{
    IGSxADT::MetaDescription metaData("Amplification Chain", "Laser Light Generation and Positioning", "ADT for high Power Amplification Chain", "/usr/local/msc/config/ADT//LAT_ACC.html");

    IGSxGUI::ADT adt(metaData);
    ASSERT_TRUE(adt.start());
}
