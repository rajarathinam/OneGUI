/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMockISystemView.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for System plugin view interface test
|
| ! \file        IGSxGUIxMockISystemView.hpp
| ! \brief       Header file for System plugin view interface test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMOCKISYSTEMVIEW_HPP
#define IGSXGUIXMOCKISYSTEMVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gmock.h>
#include <list>
#include <string>
#include "IGSxGUIxISystemView.hpp"
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class MockISystemView : public IGSxGUI::ISystemView
{
 public:
    MockISystemView(){}
    virtual ~MockISystemView(){}
    MOCK_METHOD1(show, void(SUI::Container* MainScreenContainer));
    MOCK_METHOD0(show, void());
    MOCK_METHOD0(showErrors, void());
    MOCK_METHOD2(updateSysFunction, void(DriverState::DriverStateEnum state, std::string strSysFunction));
    MOCK_METHOD2(updateDriver, void(DriverState::DriverStateEnum state, std::string strDriver));
};

#endif  // IGSXGUIXMOCKIMAINVIEW_HPP
