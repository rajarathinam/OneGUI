/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxStubPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Stub Presenter
|
| ! \file        IGSxStubPresenter.hpp
| ! \brief       Header file for Stub Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXSTUBPRESENTER_HPP
#define IGSXSTUBPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <list>
#include <vector>
#include "IGSxIStubView.hpp"
#include "IGSxITS.hpp"
#include "IGSxKPI.hpp"
#include <SUITimer.h>

using std::string;
using std::list;
using std::vector;
using IGSxKPI::KPIData;
using IGSxKPI::KPIDataList;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class StubPresenter
{
 public:
    explicit StubPresenter(IStubView* view);
    virtual ~StubPresenter();

    void Initialize() const;
    void Terminate() const;
    void Resolve();
    void fetchKPIInfo() const;
    list<string> getSystemFunctions() const;
    list<string> getDrivers(const std::string& systemFuncion) const;

    list<string> getKPIs() const;
    list<string> getValueSet(const std::string& kpi) const;

    void setDriverStatus(const std::string& driver, const std::string& state);
    void setKPIValue(const std::string& kpiName, const std::string& kpiValueSetName, const vector<double>& values);
    void setThrowExceptions(bool enable);

 private:
    IStubView *m_view;

    KPIDefinitionList m_KPIDefinitionList;
    boost::shared_ptr<SUI::Timer> m_timer;

    void onInitializeComplete(const IGS::Result& result) const;
    void onTerminateComplete(const IGS::Result& result) const;
    void updateKPI(const string& kpiName, const string& upTime, const vector<double>& values) const;

    static const char* STUB_INITIALIZING;
    static const char* STUB_TERMINATING;
    static const char* STUB_INITIALIZED;
    static const char* STUB_TERMINATED;
    static const int TIMER_INTERVAL;

    void onTimeout();
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXStubPresenter_HPP
