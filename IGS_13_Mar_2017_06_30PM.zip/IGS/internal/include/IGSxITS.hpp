/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS.hpp
| Author       : Thijs Jacobs
| Description  : Proxy interface for FSDxITS, Init Terminate Server
|
| ! \file        IGSxITS.hpp
| ! \brief       Proxy interface for FSDxITS, Init Terminate Server
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXITS_HPP
#define IGSXITS_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <boost/function.hpp>

#include "IGSxCOMMON.hpp"


namespace IGSxITS {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// driver state
class DriverState
{
public:
    typedef enum
    {
    DS_TERMINATING,      // executing actions to get to state TERMINATED
    DS_TERMINATED,       // ready for machine shutdown
    DS_INITIALIZING,     // executing actions to get to state INITIALIZED
    DS_INITIALIZED,      // operational conform specification
    DS_RECOVERY_REQUIRED // not available conform specification
    } DriverStateEnum;

    static std::string toString(DriverStateEnum state)
    {
        static std::string s[] = {"DS_TERMINATING","DS_TERMINATED","DS_INITIALIZING","DS_INITIALIZED","DS_RECOVERY_REQUIRED"};
        return s[state];
    }
};


// driver status
class DriverStatus
{
public:
    explicit DriverStatus(DriverState::DriverStateEnum _driverState) {m_driverState = _driverState; m_longAction = false;}
    virtual ~DriverStatus() {}

    DriverState::DriverStateEnum driverState() const {return m_driverState;}
    bool isExecutingLongAction() const {return m_longAction;}
    void setDriverState(DriverState::DriverStateEnum _driverState) {m_driverState = _driverState;}
    void setExecutingLongAction(bool _longAction) {m_longAction = _longAction;}

private:
    DriverState::DriverStateEnum m_driverState;
    bool m_longAction;
};


// meta data of system functions and drivers
class MetaDescription
{
public:
    explicit MetaDescription(const std::string& _name, const std::string& _description) {m_name = _name; m_desc = _description;}
    virtual ~MetaDescription() {}

    std::string name() const {return m_name;}
    std::string description() const {return m_desc;}
    void setName(const std::string& _name) {m_name = _name;}
    void setDescription(const std::string& _description) {m_desc = _description;}

private:
    std::string m_name;
    std::string m_desc;
};
typedef std::vector<MetaDescription> MetaDescriptions;


// driver names
typedef std::vector<std::string> DriverNames;


// callback type init-terminate completed notification
typedef boost::function<void (IGS::Result)> InitializeCompletedCallback;
typedef boost::function<void (IGS::Result)> TerminateCompletedCallback;


// callback type driver status changed event
typedef boost::function<void (const std::string& /*driverName*/, const DriverStatus&)> DriverStatusChangedCallback;


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class InitTerminate
{
// functions throw IGS::exception
public:
    static InitTerminate* getInstance() {return instance;}

    // meta data
    virtual MetaDescriptions getSysfuns() = 0;
    virtual MetaDescriptions getDrivers(const std::string& sysfunName) = 0;
    
    // init-terminate
    virtual void initializeSystem(const InitializeCompletedCallback& cb) = 0;
    virtual void initializeDrivers(const DriverNames& driverNames, const InitializeCompletedCallback& cb) = 0;
    virtual void terminateSystem(const TerminateCompletedCallback& cb) = 0;
    virtual void terminateDrivers(const DriverNames& driverNames, const TerminateCompletedCallback& cb) = 0;

    // current driver status
    virtual DriverStatus getDriverStatus(const std::string& driverName) = 0;

    // driver status changed event
    virtual void subscribeToDriverStatusChanged(const DriverStatusChangedCallback& cb) = 0;
    virtual void unsubscribeToDriverStatusChanged() = 0;

protected:
    // instance
    virtual ~InitTerminate() {}
    static InitTerminate* instance;
};

} // namespace IGSxITS

#endif // IGSXITS_HPP

