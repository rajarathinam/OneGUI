/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisView.hpp
| Author       : Venugopal S
| Description  : Header file for Analysisview
|
| ! \file        IGSxGUIxAdvancedDiagnosticsView.hpp
| ! \brief       Header file for Analysis view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXANALYSISVIEW_HPP
#define IGSXGUIXANALYSISVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxIAnalysisView.hpp"
#include "IGSxGUIxAnalysisPresenter.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AnalysisView;
}

namespace IGSxGUI{
class AnalysisView : public IAnalysisView
{
 public:
    AnalysisView();
    virtual ~AnalysisView();

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay);
    virtual void setActive(bool bActive);

 private:
    AnalysisView(const AnalysisView&);
    AnalysisView& operator=(const AnalysisView&);

    SUI::AnalysisView *sui;
    AnalysisPresenter *m_presenter;

    static const std::string LOAD_FILE_ADVANCED_DIAGNOSTICS;
    bool m_bAnalysisViewActive;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXANALYSISVIEW_HPP
