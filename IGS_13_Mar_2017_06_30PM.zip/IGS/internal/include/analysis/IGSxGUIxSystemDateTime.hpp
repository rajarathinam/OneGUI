/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|

| Ident        : IGSxGUIxSystemDateTime.hpp
| Author       : Surya Tiwari
| Description  : Header file for System Date and Time
|
| ! \file        IGSxGUIxSystemDateTime.hpp
| ! \brief       Header file for System Date and Time
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSYSTEMDATETIME_HPP
#define IGSXGUIXSYSTEMDATETIME_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

const std::string STRING_DATETIME_FORMAT1 = "%l:%M%p";
const std::string STRING_DATETIME_FORMAT2 = "%Y-%m-%d";
class SystemDateTime
{
 public:
    typedef enum
    {
        STR_DATE,
        STR_TIME
    }eSystemDateTime;

    const std::string SystemCurrentDateTime(const SystemDateTime::eSystemDateTime& strname)
    {
        time_t     now = time(0);
        struct tm  tstruct;
        char       buf[80];
        tstruct = *localtime_r(&now, &tstruct);
        if (strname == STR_TIME)
        {
            strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT1.c_str(), &tstruct);
        } else {
            strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT2.c_str(), &tstruct);
        }
        return (std::string)buf;
    }
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXSYSTEMDATETIME_HPP
