/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxERR.hpp
| Author       : Thijs Jacobs
| Description  : Interface to retrieve the XER event log
|
| ! \file        IGSxERR.hpp
| ! \brief       Interface to retrieve the XER event log
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXERR_HPP
#define IGSXERR_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>

#include "IGSxCOMMON.hpp"


namespace IGSxERR {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class EventLogger
{
// functions throw IGS::exception
public:
    static EventLogger* getInstance() {return instance;}

    // get the event log as a fully qualified filename
    // returns empty string when not found
    virtual std::string getEventLog() = 0;
    virtual std::string getPreviousEventLog() = 0;

protected:
    // instance
    virtual ~EventLogger() {}
    static EventLogger* instance;
};

} // namespace IGSxERR

#endif // IGSXERR_HPP

