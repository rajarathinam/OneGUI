/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIDashboard.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface file for Dashboard Plugin
|
| ! \file        IGSxGUIxIDashboard.hpp
| ! \brief       Interface file for Dashboard Plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIDASHBOARD_HPP
#define IGSXGUIXIDASHBOARD_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class IDashboard
{
 public:
    IDashboard() {}
    virtual ~IDashboard() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI

#endif
