/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainPresenter.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Main application Presenter
|
| ! \file        IGSxGUIxMainPresenter.hpp
| ! \brief       Header file for Main application Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXMAINPRESENTER_HPP
#define IGSXGUIXMAINPRESENTER_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxIMainView.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI {
class MainPresenter
{
 public:
    explicit MainPresenter(IGSxGUI::IMainView* view);
    virtual ~MainPresenter();
    void OnErrorStateChange(const std::string& eMsg);
 private:
    std::string getTimeStamp() const;

    static const std::string STRING_DATETIME_FORMAT1;
    static const std::string STRING_DATETIME_FORMAT2;
    IGSxGUI::IMainView *m_view;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXMAINPRESENTER_HPP
