/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStubTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for IGSxITS Stub test
|
| ! \file        IGSxGUIxStubTest.hpp
| ! \brief       Header file for IGSxITS Stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXSTUBTEST_HPP
#define IGSXGUIXSTUBTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <string>
#include <vector>
#include "IGSxITS.hpp"

using IGSxITS::MetaDescription;
using IGSxITS::DriverStatus;
using IGSxITS::DriverState;
using IGSxITS::InitTerminate;
using std::vector;
using std::string;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
template<typename T>
    ::testing::AssertionResult VectorsMatch(const vector<T>& Expected, const vector<T>& Actual)
{
        for (int i=0; i < Expected.size(); i++)
        {
            if (Expected.at(i).name().compare(Actual.at(i).name()) != 0)
            {
                return ::testing::AssertionFailure();
            }
        }
        return ::testing::AssertionSuccess();
}

class IGSxITSTest : public ::testing::Test
{
 public:
  IGSxITSTest(){}
  virtual ~IGSxITSTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class IGSxITSTestParam : public ::testing::TestWithParam<string>
{
 public:
    IGSxITSTestParam(){}
    virtual ~IGSxITSTestParam(){}
 protected:
    vector<MetaDescription> ExpectedDrivers;
 protected:
  virtual void SetUp()
  {
     ExpectedDrivers.push_back(MetaDescription("Collector Cooling Driver", "[NOT IMPLEMENTED]Collector Cooling Driver"));
     ExpectedDrivers.push_back(MetaDescription("Vessel Heat Exchanger Driver", "[NOT IMPLEMENTED]Vessel Heat Exchanger Driver"));
     ExpectedDrivers.push_back(MetaDescription("SFC Environmental Control", "SFC Environmental Control"));
     ExpectedDrivers.push_back(MetaDescription("Gas and Vacuum Driver", "Gas and Vacuum Driver"));
     ExpectedDrivers.push_back(MetaDescription("HP-RGA Driver", "HP-RGA Driver"));
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXSTUBTEST_HPP
