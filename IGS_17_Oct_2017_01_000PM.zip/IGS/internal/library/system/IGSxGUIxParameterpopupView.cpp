/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxParameterpopupView.cpp
| Author       : Raja
| Description  : Implementation of Parameterpopup view
|
| ! \file        IGSxGUIxParameterpopupView.cpp
| ! \brief       Implementation of Parameterpopup view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include "IGSxGUIxParameterpopupView.hpp"
#include "IGSxGUIxMoc_ParameterpopupView.hpp"
#include <SUILabel.h>
#include <SUILineEdit.h>
#include <SUIButton.h>
#include <SUIDialog.h>
#include "IGSxLOG.hpp"
#include "IGSxGUIxUtil.hpp"

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

const std::string IGSxGUI::ParameterpopupView::PARAMETERPOPUPVIEW_LOAD_FILE = "IGSxGUIxParameterPopup.xml";
const std::string IGSxGUI::ParameterpopupView::STRING_PARAMETERPOPUPVIEW_SHOWN = "ParameterPopupView is Shown.";
IGSxGUI::ParameterpopupView::ParameterpopupView():
    sui(new SUI::ParameterpopupView)
{
    sui->setupSUI(PARAMETERPOPUPVIEW_LOAD_FILE.c_str());
}


IGSxGUI::ParameterpopupView::~ParameterpopupView()
{
}

void IGSxGUI::ParameterpopupView::show()
{
    init();
    IGSxGUI::Util::disableScrollbars(sui->dialog);
    IGSxGUI::Util::setWindowFrame(sui->dialog, false);
    IGSxGUI::Util::executeDialog(sui->dialog);
    IGS_INFO(STRING_PARAMETERPOPUPVIEW_SHOWN);
}

void IGSxGUI::ParameterpopupView::init()
{
    IGSxGUI::Util::setWordWrap(sui->lblParameterName);
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#000080", 18);
    sui->btnClose->clicked = boost::bind(&ParameterpopupView::onCloseButtonPressed, this);
    sui->btnPopCancel->clicked = boost::bind(&ParameterpopupView::onCloseButtonPressed, this);
    sui->btnClose->hoverEntered = boost::bind(&ParameterpopupView::onCloseButtonHoverEntered, this);
    sui->btnClose->hoverLeft = boost::bind(&ParameterpopupView::onCloseButtonHoverLeft, this);
    sui->btnPopReset->clicked = boost::bind(&ParameterpopupView::onResetButtonPressed, this);
    sui->btnPopUpdate->clicked = boost::bind(&ParameterpopupView::onUpdatebuttonPressed, this);
}

void IGSxGUI::ParameterpopupView::onCloseButtonHoverEntered()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#000080", 18);
}


void IGSxGUI::ParameterpopupView::onCloseButtonHoverLeft()
{
    IGSxGUI::Util::setAwesome(sui->btnClose, IGSxGUI::AwesomeIcon::AI_fa_close, "#666666", 18);
}

void IGSxGUI::ParameterpopupView::onCloseButtonPressed()
{
  sui->dialog->close();
}
void IGSxGUI::ParameterpopupView::onResetButtonPressed()
{
    std::string value = sui->lblDefaultValueNumber->getText();
    sui->lneValue->setText(value);
}

void IGSxGUI::ParameterpopupView::onUpdatebuttonPressed()
{
    std::string name = getParameterName();
    std::string value = getParameterValue();
    m_valueChanged(name, value);
}
boost::signals2::connection IGSxGUI::ParameterpopupView::registerForValueChanged(const IGSxGUI::ParameterpopupView::ValueChangedCallback &cb)
{
    return m_valueChanged.connect(cb);
}
void IGSxGUI::ParameterpopupView::setParameterName(const std::string& name)
{
    sui->lblParameterName->setText(name);
}
std::string IGSxGUI::ParameterpopupView::getParameterName() const
{
    return sui->lblParameterName->getText();
}
void IGSxGUI::ParameterpopupView::setParameterValue(const std::string& value)
{
    sui->lneValue->setText(value);
}
std::string IGSxGUI::ParameterpopupView::getParameterValue() const
{
    return sui->lneValue->getText();
}
void IGSxGUI::ParameterpopupView::setParameterDefaultValue(const std::string& defaultvalue)
{
    sui->lblDefaultValueNumber->setText(defaultvalue);
}
std::string IGSxGUI::ParameterpopupView::getParameterDefaultValue() const
{
    return sui->lblDefaultValueNumber->getText();
}

void IGSxGUI::ParameterpopupView::close()
{
  sui->dialog->close();
}
void IGSxGUI::ParameterpopupView::setParent(SUI::Widget *parent)
{
    IGSxGUI::Util::setParent(sui->dialog, parent);
}
