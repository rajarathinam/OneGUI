/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverManagerTest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for Driver Manager test
|
| ! \file        IGSxGUIxDriverManagerTest.hpp
| ! \brief       Header file for Driver Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXDRIVERMANAGERTEST_HPP
#define IGSXGUIXDRIVERMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <string>
#include "IGSxGUIxDriverManager.hpp"

using std::vector;
using IGSxITS::MetaDescriptions;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class DriverManagerTest : public ::testing::Test
{
 public:
    DriverManagerTest(){}
    virtual ~DriverManagerTest(){}

 protected:
  IGSxGUI::DriverManager* m_driverManager;
  MetaDescriptions m_additionalSystemFunctions;
  virtual void SetUp()
  {
      m_driverManager = new IGSxGUI::DriverManager();

      MetaDescriptions systemFunctionsDescriptions;
      MetaDescriptions additionalSystemFunctions;

      systemFunctionsDescriptions.push_back(MetaDescription("SF-04", "SF Environmental Mgt"));
      systemFunctionsDescriptions.push_back(MetaDescription("SF-15", "SF Laser Mgt"));
      systemFunctionsDescriptions.push_back(MetaDescription("SF-16", "SF Tin Mgt"));
      systemFunctionsDescriptions.push_back(MetaDescription("SF-17", "SF Plasma & Energy Mgt"));
      systemFunctionsDescriptions.push_back(MetaDescription("SF-18", "SF Spectrally Pure EUV Collection Mgt"));
      systemFunctionsDescriptions.push_back(MetaDescription("SF-19", "SF Tin Mitigation Mgt"));

      m_additionalSystemFunctions.push_back(MetaDescription("SF-20", "SF Test Mgt 20"));
      m_additionalSystemFunctions.push_back(MetaDescription("SF-21", "SF Test Mgt 21"));

      m_driverManager->addSystemFunctions(systemFunctionsDescriptions);

      vector<IGSxGUI::SystemFunction *> systemFunctions = m_driverManager->getSystemFunctions();

      for (vector<IGSxGUI::SystemFunction *>::iterator it = systemFunctions.begin() ; it != systemFunctions.end(); ++it)
      {
          (*it)->addDriver(MetaDescription("SFC Environmental Mgt", "SFC Environmental Mgt"), DriverState::DS_RECOVERY_REQUIRED);
          (*it)->addDriver(MetaDescription("SSD Gas and Vacuum", "SSD Gas and Vacuum"), DriverState::DS_RECOVERY_REQUIRED);
          (*it)->addDriver(MetaDescription("SSD HPRGA", "SSD HPRGA"), DriverState::DS_RECOVERY_REQUIRED);
          (*it)->addDriver(MetaDescription("SSD Vessel Cooling", "SSD Vessel Cooling"), DriverState::DS_RECOVERY_REQUIRED);
          (*it)->addDriver(MetaDescription("SSD Collector Cooling", "SSD Collector Cooling"), DriverState::DS_RECOVERY_REQUIRED);
      }
  }
  virtual void TearDown()
  {
      delete m_driverManager;
      m_driverManager = NULL;
  }
};

#endif  // IGSXGUIXDRIVERMANAGERTEST_HPP

