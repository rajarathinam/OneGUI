/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxDriverTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Driver test
|
| ! \file        IGSxGUIxDriverTest.cpp
| ! \brief       Implementation of Driver test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxDriver.hpp"
#include "IGSxGUIxDriverTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(DriverTest, Test1)
{
    MetaDescription obj("SF Environmental Mgt", "SF Environmental Mgt Desc");
    IGSxGUI::Driver drv(obj, DriverState::DS_INITIALIZED);

    EXPECT_STRCASEEQ(drv.getName().c_str(), "SF Environmental Mgt");
    EXPECT_STRCASEEQ(drv.getDisplayName().c_str(), "SF Environmental Mgt Desc");
    EXPECT_EQ(DriverState::DS_INITIALIZED, drv.getState());
}

TEST_F(DriverTest, Test2)
{
    MetaDescription obj1("SF Environmental Mgt1", "SF Environmental Mgt1");
    IGSxGUI::Driver drv1(obj1, DriverState::DS_RECOVERY_REQUIRED);

    EXPECT_EQ(DriverState::DS_RECOVERY_REQUIRED, drv1.getState());

    MetaDescription obj2("FFA Driver", "FFA Driver");
    IGSxGUI::Driver drv2(obj2, DriverState::DS_TERMINATED);

    EXPECT_EQ(DriverState::DS_TERMINATED, drv2.getState());

    MetaDescription obj3("Plasma Driver", "Plasma Driver");
    IGSxGUI::Driver drv3(obj3, DriverState::DS_TERMINATING);

    EXPECT_EQ(DriverState::DS_TERMINATING, drv3.getState());

    MetaDescription obj4("SSD Gas and Vacuum", "SSD Gas and Vacuum");
    IGSxGUI::Driver drv4(obj4, DriverState::DS_INITIALIZING);

    EXPECT_EQ(DriverState::DS_INITIALIZING, drv4.getState());

    MetaDescription obj5("SSD HPRGA", "SSD HPRGA");
    IGSxGUI::Driver drv5(obj5, DriverState::DS_INITIALIZED);

    EXPECT_EQ(DriverState::DS_INITIALIZED, drv5.getState());
}

TEST_F(DriverTest, Test3)
{
    MetaDescription obj1("SF Environmental Mgt", "SF Environmental Mgt");
    IGSxGUI::Driver drv1(obj1, DriverState::DS_TERMINATED);

    ASSERT_TRUE(drv1.isImplemented());

    MetaDescription obj2("Tin Mgmt", "[NOT IMPLEMENTED]Tin Mgmt");
    IGSxGUI::Driver drv2(obj2, DriverState::DS_TERMINATED);

    ASSERT_FALSE(drv2.isImplemented());
}

TEST_F(DriverTest, Test4)
{
    MetaDescription obj("SF Environmental Mgt", "SF Environmental Mgt Desc");
    IGSxGUI::Driver drv(obj, DriverState::DS_RECOVERY_REQUIRED);

    EXPECT_EQ(DriverState::DS_RECOVERY_REQUIRED, drv.getState());

    drv.updateDriverState(DriverState::DS_TERMINATED);
    EXPECT_EQ(DriverState::DS_TERMINATED, drv.getState());

    drv.updateDriverState(DriverState::DS_TERMINATING);
    EXPECT_EQ(DriverState::DS_TERMINATING, drv.getState());

    drv.updateDriverState(DriverState::DS_INITIALIZING);
    EXPECT_EQ(DriverState::DS_INITIALIZING, drv.getState());

    drv.updateDriverState(DriverState::DS_INITIALIZED);
    EXPECT_EQ(DriverState::DS_INITIALIZED, drv.getState());
}
