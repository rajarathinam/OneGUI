/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAnalysisPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of Analysis Presenter test
|
| ! \file        IGSxGUIxAnalysisPresenterTest.cpp
| ! \brief       Implementation of Analysis Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxAnalysisPresenterTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(AnalysisPresenterTest, Test1)
{
    AnalysisViewStub* stubView  = new AnalysisViewStub();
    ASSERT_TRUE(stubView != NULL);

    ASSERT_TRUE(m_adtManager != NULL);
    IGSxGUI::AnalysisPresenter* analysispresenter = new IGSxGUI::AnalysisPresenter(stubView, m_adtManager);
    ASSERT_TRUE(analysispresenter != NULL);

    std::vector<IGSxGUI::ADT*> listADTs = analysispresenter->getADTs();
    EXPECT_EQ(6, listADTs.size());

    IGSxGUI::ADT* adt = new IGSxGUI::ADT(IGSxADT::MetaDescription("NewADTName", "NewADTSubSystem", "NewADTDesc", "NewADTFile"));
    ASSERT_TRUE(adt != NULL);

    m_adtManager->add(adt);

    listADTs = analysispresenter->getADTs();
    EXPECT_EQ(7, listADTs.size());

    ASSERT_TRUE(analysispresenter != NULL);
    delete analysispresenter;
    analysispresenter = NULL;

    ASSERT_TRUE(stubView != NULL);
    delete stubView;
    stubView = NULL;
}

TEST_F(AnalysisPresenterTest, Test2)
{
    ASSERT_TRUE(m_adtManager != NULL);

    AnalysisViewStub* stubView  = new AnalysisViewStub();
    ASSERT_TRUE(stubView != NULL);

    IGSxGUI::AnalysisPresenter* analysispresenter = new IGSxGUI::AnalysisPresenter(stubView, m_adtManager);

    std::vector<IGSxGUI::ADT*> adts = analysispresenter->getADTs();
    EXPECT_EQ(adts.size(), 6);

    EXPECT_FALSE(analysispresenter->startADT(""));
    EXPECT_FALSE(analysispresenter->startADT("OneGUI"));

    ASSERT_TRUE(analysispresenter->startADT("GVA"));

    if (analysispresenter != NULL)
    {
        delete analysispresenter;
        analysispresenter = NULL;
    }
    if (stubView != NULL)
    {
        delete stubView;
        stubView = NULL;
    }
}

