/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTPresenter.cpp
| Author       : Raja A
| Description  : Implementation of ADT Presenter
|
| ! \file        IGSxGUIxADTPresenter.cpp
| ! \brief       Implementation of ADT Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxADTPresenter.hpp"
#include <string>
#include <vector>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::ADTPresenter::ADTPresenter(IGSxGUI::IADTView* view,ADTManager* pADTManager):
    m_pADTManager(pADTManager),
    m_view(view)
{
}
IGSxGUI::ADTPresenter::~ADTPresenter()
{
    // Do not delete m_view, we are not the owner.
}

std::vector<IGSxGUI::ADT *> IGSxGUI::ADTPresenter::getADTs()
{
    return m_pADTManager->retrieveAll();
}

bool IGSxGUI::ADTPresenter::startADT(std::string adtName)
{
    IGSxGUI::ADT* adt = m_pADTManager->getADT(adtName);
    return adt->start();
}

void IGSxGUI::ADTPresenter::subscribeForEvents()
{
    std::vector<IGSxGUI::ADT *> ADTs = m_pADTManager->retrieveAll();

    for (size_t i = 0; i < ADTs.size(); ++i)
    {
       // boost::signals2::connection connection = ADTs[i]->registerToADTStopped(boost::bind(&IGSxGUI::ADTPresenter::onADTStopped, this, _1, _2));
       // m_connections.push_back(connection);
    }
}

void IGSxGUI::ADTPresenter::unsubscribeForEvents()
{
    for (size_t i = 0; i < m_connections.size(); ++i)
    {
        m_connections.at(i).disconnect();
    }
    m_connections.clear();
}

void IGSxGUI::ADTPresenter::onADTStopped(std::string strADT, IGS::Result result)
{
    m_view->updateStatus(strADT,result);
}


