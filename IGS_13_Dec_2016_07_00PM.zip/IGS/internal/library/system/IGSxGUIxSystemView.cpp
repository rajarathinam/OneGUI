/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System plugin view
|
| ! \file        IGSxGUIxSystemView.cpp
| ! \brief       Implementation of System plugin view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemView.hpp"
#include <boost/lexical_cast.hpp>
#include <string>
#include <algorithm>
#include <map>
#include <utility>
#include <vector>
#include <functional>
#include "IGSxGUIxMoc_SystemView.hpp"
#include <SUILabel.h>
#include <SUIProgressBar.h>
#include <SUIDialog.h>
#include <SUIUserControl.h>
#include <SUITextArea.h>
#include <SUIBusyIndicator.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIGroupBox.h>
#include <SUITableWidget.h>
#include <SUITime.h>
#include <SUITimer.h>
#include <SUIWidget.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SystemView::SYSTEMVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxSystemView.xml");
const std::string IGSxGUI::SystemView::IMAGE_NOT_OK = IGS::Resource::path("IGSxSystem_not_ok.png");
const std::string IGSxGUI::SystemView::IMAGE_OK = IGS::Resource::path("IGSxSystem_ok.png");
const std::string IGSxGUI::SystemView::IMAGE_CLOCK = IGS::Resource::path("IGSxSystem_clock.png");
const std::string IGSxGUI::SystemView::IMAGE_LOGO = IGS::Resource::path("IGSxSystem_asml.png");

const std::string IGSxGUI::SystemView::STRING_DRIVERS = " DRIVERS";
const std::string IGSxGUI::SystemView::STRING_INFORMATION = " INFORMATION";
const std::string IGSxGUI::SystemView::STRING_SEPERATOR = ">>  ";

const std::string IGSxGUI::SystemView::STYLECLASS_DEFAULT = "default";
const std::string IGSxGUI::SystemView::STYLECLASS_DEFAULT_SMALL = "defaultSmall";
const std::string IGSxGUI::SystemView::STYLECLASS_SELECTED = "selected";
const std::string IGSxGUI::SystemView::STYLECLASS_SELECTED_SMALL = "selectedSmall";

const int IGSxGUI::SystemView::SYSTEM_TIMER_INTERVAL = 1000;

const std::string IGSxGUI::SystemView::m_sysFunStates[] = {"Terminating...", "Terminated", "Initializing...", "Initialized", "Recovery required", "Partially Initialized"};
const std::string IGSxGUI::SystemView::m_driverStates[] = {"Terminating...", "Terminated", "Initializing...", "Initialized", "Recovery required"};

IGSxGUI::SystemView::SystemView(DriverManager* pDriverManager) :
    sui(new SUI::SystemView),
    m_sysFunctionLastSelected(NULL),
    m_indexSysFunctionLastSelected(0),
    m_indexDriverLastSelected(0),
    m_timer(SUI::Timer::createTimer()),
    m_nameCurrentSelectedSysFunction(""),
    m_nameCurrentSelectedDriver(""),
    m_startTime(time(NULL)),
    m_totaldrivercount(0),
    m_bSystemViewActive(false)
{
    m_presenter = new SystemPresenter(this,pDriverManager);

    m_timer->setSingleShot(true);
    m_timer->setInterval(SYSTEM_TIMER_INTERVAL);

    m_timer->timeout = boost::bind(&SystemView::onTimerTimeout, this);
}

IGSxGUI::SystemView::~SystemView()
{
    m_timer->stop();

    // Do not delete the content, we are not the owner:
    m_listSysFunctions.clear();
    m_listDrivers.clear();
    m_listSystemFunctionUCT.clear();;
    m_listDriverUCT.clear();

    m_listSystemFunctionNameLabels.clear();
    m_listSystemFunctionSignalViews.clear();
    m_listSystemFunctionStatusLabels.clear();
    m_listSystemFunctionProgressBar.clear();

    m_listDriverNameLabels.clear();
    m_listDriverSignalViews.clear();
    m_listDriverStatusLabels.clear();
    m_listDriverProgressBar.clear();
    m_listDriverBusyIndicator.clear();

    delete m_presenter;
    delete sui;

    // Do not delete:
    // m_lastDriverPressed
    // m_lastSysFunctionPressed
}

void IGSxGUI::SystemView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    sui->setupSUIContainer(SYSTEMVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    loadContainers();
    setButtonClickHandlers();
    sui->tawDriver->showGrid(false);

    if (bIsFirstTimeDisplay)
    {
        init();
    } else {
        reInit();
    }
}
void IGSxGUI::SystemView:: setActive(bool bActive)
{
    m_bSystemViewActive = bActive;
}

void IGSxGUI::SystemView::onInitializeButtonPressed()
{
    startTimer();
    m_presenter->Initialize();
    sui->tawDriver->clearFocus();
}

void IGSxGUI::SystemView::onTerminateButtonPressed()
{
    startTimer();
    m_presenter->Terminate();
    sui->tawDriver->clearFocus();
}

void IGSxGUI::SystemView::onResolveButtonPressed()
{
    startTimer();
    m_presenter->Resolve();
    sui->tawDriver->clearFocus();
}

void IGSxGUI::SystemView::startTimer()
{
    m_startTime = time(NULL);
    m_timer->start();

    showElapsedTime();
}
void IGSxGUI::SystemView::showElapsedTime()
{
    int elapsedSeconds = static_cast<int>(difftime(time(NULL), m_startTime));
    int seconds, minutes;
    minutes = elapsedSeconds / 60;
    seconds = elapsedSeconds % 60;
    minutes = minutes % 60;

    std::stringstream time;
    time << minutes << ":";
    if (seconds < 10) time << "0";
    time << seconds;

    if (m_bSystemViewActive)
    {
        sui->lblTimer->setText(time.str());
    }
}

void IGSxGUI::SystemView::onBtnSysFun1Pressed()
{
    showDrivers(m_listSysFunctions[0], 0);
}
void IGSxGUI::SystemView::onBtnSysFun2Pressed()
{
    showDrivers(m_listSysFunctions[1], 1);
}
void IGSxGUI::SystemView::onBtnSysFun3Pressed()
{
    showDrivers(m_listSysFunctions[2], 2);
}
void IGSxGUI::SystemView::onBtnSysFun4Pressed()
{
    showDrivers(m_listSysFunctions[3], 3);
}
void IGSxGUI::SystemView::onBtnSysFun5Pressed()
{
    showDrivers(m_listSysFunctions[4], 4);
}
void IGSxGUI::SystemView::onBtnSysFun6Pressed()
{
    showDrivers(m_listSysFunctions[5], 5);
}
void IGSxGUI::SystemView::onBtnSysFun7Pressed()
{
    showDrivers(m_listSysFunctions[6], 6);
}
void IGSxGUI::SystemView::onBtnDriver1Pressed()
{
    if ( m_listDrivers.size() >= 1)
    {
        showErrorInfo(m_listDrivers[0], 0);
    }
}
void IGSxGUI::SystemView::onBtnDriver2Pressed()
{
    if ( m_listDrivers.size() >= 2)
    {
        showErrorInfo(m_listDrivers[1], 1);
    }
}
void IGSxGUI::SystemView::onBtnDriver3Pressed()
{
    if ( m_listDrivers.size() >= 3)
    {
        showErrorInfo(m_listDrivers[2], 2);
    }
}
void IGSxGUI::SystemView::onBtnDriver4Pressed()
{
    if ( m_listDrivers.size() >= 4)
    {
        showErrorInfo(m_listDrivers[3], 3);
    }
}
void IGSxGUI::SystemView::onBtnDriver5Pressed()
{
    if ( m_listDrivers.size() >= 5)
    {
        showErrorInfo(m_listDrivers[4], 4);
    }
}
void IGSxGUI::SystemView::onBtnDriver6Pressed()
{
    if ( m_listDrivers.size() >= 6)
    {
        showErrorInfo(m_listDrivers[5], 5);
    }
}
void IGSxGUI::SystemView::onBtnDriver7Pressed()
{
    if ( m_listDrivers.size() >= 7)
    {
        showErrorInfo(m_listDrivers[6], 6);
    }
}

void IGSxGUI::SystemView::manipulateSysFunSelection(int index, bool bShow)
{
    for (size_t i = 0; i < m_listSysFunctions.size(); i++)
    {
        if (m_listSystemFunctionUCT[i]->getStyleSheetClass() == STYLECLASS_SELECTED)
        {
            m_listSystemFunctionUCT[i]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listSystemFunctionNameLabels[i]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listSystemFunctionStatusLabels[i]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);
        }
    }
    if (bShow)
    {
        m_listSystemFunctionUCT[index]->setStyleSheetClass(STYLECLASS_SELECTED);
        m_listSystemFunctionNameLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED);
        m_listSystemFunctionStatusLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED_SMALL);
        manipulateDriverSelection(0, false);
    }
}

void IGSxGUI::SystemView::manipulateDriverSelection(int index, bool bShow)
{
    for (size_t i = 0; i < m_listDriverUCT.size(); i++)
    {
        if (m_listDriverUCT[i]->getStyleSheetClass() == STYLECLASS_SELECTED)
        {
            m_listDriverUCT[i]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listDriverNameLabels[i]->setStyleSheetClass(STYLECLASS_DEFAULT);
            m_listDriverStatusLabels[i]->setStyleSheetClass(STYLECLASS_DEFAULT_SMALL);
        }
    }
    if (bShow)
    {
        m_listDriverUCT[index]->setStyleSheetClass(STYLECLASS_SELECTED);
        m_listDriverNameLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED);
        m_listDriverStatusLabels[index]->setStyleSheetClass(STYLECLASS_SELECTED_SMALL);
    }
}

void IGSxGUI::SystemView::hideDrivers()
{
    if (m_nameCurrentSelectedSysFunction != "")
    {
        std::vector<Driver *> drivers = m_presenter->getDrivers(m_nameCurrentSelectedSysFunction);

        for (std::size_t i = 0; i < drivers.size(); i++)
        {
            std::map<std::string, DriverInfo>::iterator it = m_mapDrivers.find(drivers[i]->getName());

            if (it != m_mapDrivers.end())
            {
                if (m_bSystemViewActive)
                {
                    it->second.UiID.UCT = NULL;
                    it->second.UiID.imvSignal = NULL;
                    it->second.UiID.lblName = NULL;
                    it->second.UiID.lblStatus = NULL;
                    it->second.UiID.pgbProgress = NULL;
                }
            }
        }

        if (m_bSystemViewActive)
        {
            sui->lblFunction->setVisible(false);
            sui->tawDriver->setVisible(false);
            for (std::size_t i = 0; i < m_listDriverUCT.size(); i++)
            {
                m_listDriverUCT[i]->setVisible(false);
            }
            hideErrorInfo();
        }
    }
}

void IGSxGUI::SystemView::hideErrorInfo()
{
    if (m_bSystemViewActive)
    {
        sui->lblDriverInformation->setVisible(false);
        sui->txaErrorDescription->setVisible(false);
        sui->btnAdvancedDashboard->setVisible(false);
    }
}

void IGSxGUI::SystemView::showErrorInfo(Driver* driver, int uctIndex)
{
    if (m_nameCurrentSelectedDriver == driver->getName())
    {
        hideErrorInfo();
        m_nameCurrentSelectedDriver = "";
        manipulateDriverSelection(uctIndex, false);
    } else {
        m_indexDriverLastSelected = uctIndex;
        m_nameCurrentSelectedDriver = driver->getName();

        manipulateDriverSelection(uctIndex, true);

        std::string strDriverName = driver->getDisplayName();
        std::transform(strDriverName.begin(), strDriverName.end(), strDriverName.begin(), std::ptr_fun<int, int>(toupper));

        if (m_bSystemViewActive)
        {
            sui->lblDriverInformation->setVisible(true);
            sui->lblDriverInformation->setText(std::string(STRING_SEPERATOR + strDriverName + STRING_INFORMATION));
            sui->txaErrorDescription->setVisible(true);
            sui->txaErrorDescription->clearText();
            sui->txaErrorDescription->setText("");
        }
    }
}

void IGSxGUI::SystemView::reShowErrorInfo(std::string strDriverName)
{
    std::transform(strDriverName.begin(), strDriverName.end(), strDriverName.begin(), std::ptr_fun<int, int>(toupper));
    if (m_bSystemViewActive)
    {
        sui->lblDriverInformation->setVisible(true);
        sui->lblDriverInformation->setText(std::string(STRING_SEPERATOR + strDriverName + STRING_INFORMATION));
        sui->txaErrorDescription->setVisible(true);
        sui->txaErrorDescription->clearText();
        sui->txaErrorDescription->setText("");
    }
}

void IGSxGUI::SystemView::updateStatus(SUI::ColorEnum::Color color,
                                              SystemState::SystemStateEnum state,
                                              bool bBtnInitVisibility,
                                              bool bBtnTerminateVisibility,
                                              bool bBtnResolveVisibility,
                                              bool bClockVisibility,
                                              bool bLblTimerVisibility)
{
    m_mainStatus.color = color;
    m_mainStatus.strMessage = m_sysFunStates[state];
    m_mainStatus.bBtnInitVisibility = bBtnInitVisibility;
    m_mainStatus.bBtnTerminateVisibility = bBtnTerminateVisibility;
    m_mainStatus.bBtnResolveVisibility = bBtnResolveVisibility;
    m_mainStatus.bClockVisibility = bClockVisibility;
    m_mainStatus.bLblTimerVisibility = bLblTimerVisibility;

    if (m_bSystemViewActive)
    {
        sui->gbxSystem->setBGColor(m_mainStatus.color);
        if (state == SystemState::SS_PARTIALLY_INITIALIZED)
        {
            std::string strMsg;
            int initializedDriverCount = m_presenter->getInitializedDriverCount();
            strMsg.append(m_mainStatus.strMessage).append(" (").append(boost::lexical_cast<std::string>(initializedDriverCount)).append("/").append(boost::lexical_cast<std::string>(m_totaldrivercount).append(")"));
            sui->lblMainStatus->setText(strMsg);
        } else {
            sui->lblMainStatus->setText(m_mainStatus.strMessage);
        }

        sui->btnInit->setVisible(m_mainStatus.bBtnInitVisibility);
        sui->btnTerminate->setVisible(m_mainStatus.bBtnTerminateVisibility);
        sui->btnResolve->setVisible(m_mainStatus.bBtnResolveVisibility);
        sui->imvClock->setVisible(m_mainStatus.bClockVisibility);
        sui->lblTimer->setVisible(m_mainStatus.bLblTimerVisibility);

        if (m_mainStatus.bBtnTerminateVisibility)  // This is to make the "Terminate" button colour depends on the system state.
        {
            sui->btnTerminate->setStyleSheetClass(SUI::ColorEnum::toString(color));
        }
        if (m_mainStatus.bBtnResolveVisibility)
        {
            sui->btnResolve->setStyleSheetClass(SUI::ColorEnum::toString(color));
        }
        if (color == SUI::ColorEnum::Gray)
        {
            sui->btnInit->setStyleSheetClass(SUI::ColorEnum::toString(color));
        } else {
            sui->btnInit->setStyleSheetClass("");
        }
    }
}

void IGSxGUI::SystemView::setButtonClickHandlers()
{
    sui->btnInit->clicked = boost::bind(&SystemView::onInitializeButtonPressed, this);
    sui->btnTerminate->clicked = boost::bind(&SystemView::onTerminateButtonPressed, this);
    sui->btnResolve->clicked = boost::bind(&SystemView::onResolveButtonPressed, this);

    sui->uctSystemFunction1->clicked = boost::bind(&SystemView::onBtnSysFun1Pressed, this);
    sui->uctSystemFunction2->clicked = boost::bind(&SystemView::onBtnSysFun2Pressed, this);
    sui->uctSystemFunction3->clicked = boost::bind(&SystemView::onBtnSysFun3Pressed, this);
    sui->uctSystemFunction4->clicked = boost::bind(&SystemView::onBtnSysFun4Pressed, this);
    sui->uctSystemFunction5->clicked = boost::bind(&SystemView::onBtnSysFun5Pressed, this);
    sui->uctSystemFunction6->clicked = boost::bind(&SystemView::onBtnSysFun6Pressed, this);
    sui->uctSystemFunction7->clicked = boost::bind(&SystemView::onBtnSysFun7Pressed, this);

    sui->uctDriver1->clicked = boost::bind(&SystemView::onBtnDriver1Pressed, this);
    sui->uctDriver2->clicked = boost::bind(&SystemView::onBtnDriver2Pressed, this);
    sui->uctDriver3->clicked = boost::bind(&SystemView::onBtnDriver3Pressed, this);
    sui->uctDriver4->clicked = boost::bind(&SystemView::onBtnDriver4Pressed, this);
    sui->uctDriver5->clicked = boost::bind(&SystemView::onBtnDriver5Pressed, this);
    sui->uctDriver6->clicked = boost::bind(&SystemView::onBtnDriver6Pressed, this);
    sui->uctDriver7->clicked = boost::bind(&SystemView::onBtnDriver7Pressed, this);
}

void IGSxGUI::SystemView::loadContainers()
{
    m_listSystemFunctionUCT.clear();
    m_listDriverUCT.clear();
    m_listSystemFunctionNameLabels.clear();
    m_listSystemFunctionSignalViews.clear();
    m_listSystemFunctionStatusLabels.clear();
    m_listSystemFunctionProgressBar.clear();
    m_listDriverNameLabels.clear();
    m_listDriverSignalViews.clear();
    m_listDriverStatusLabels.clear();
    m_listDriverProgressBar.clear();
    m_listDriverBusyIndicator.clear();

    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction1);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction2);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction3);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction4);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction5);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction6);
    m_listSystemFunctionUCT.push_back(sui->uctSystemFunction7);

    m_listDriverUCT.push_back(sui->uctDriver1);
    m_listDriverUCT.push_back(sui->uctDriver2);
    m_listDriverUCT.push_back(sui->uctDriver3);
    m_listDriverUCT.push_back(sui->uctDriver4);
    m_listDriverUCT.push_back(sui->uctDriver5);
    m_listDriverUCT.push_back(sui->uctDriver6);
    m_listDriverUCT.push_back(sui->uctDriver7);

    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun1Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun2Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun3Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun4Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun5Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun6Name);
    m_listSystemFunctionNameLabels.push_back(sui->lblSysFun7Name);

    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun1Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun2Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun3Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun4Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun5Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun6Signal);
    m_listSystemFunctionSignalViews.push_back(sui->imvSysFun7Signal);

    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun1Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun2Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun3Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun4Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun5Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun6Status);
    m_listSystemFunctionStatusLabels.push_back(sui->lblSysFun7Status);

    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun1Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun2Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun3Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun4Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun5Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun6Progress);
    m_listSystemFunctionProgressBar.push_back(sui->pgbSysFun7Progress);

    m_listDriverNameLabels.push_back(sui->lblDriver1Name);
    m_listDriverNameLabels.push_back(sui->lblDriver2Name);
    m_listDriverNameLabels.push_back(sui->lblDriver3Name);
    m_listDriverNameLabels.push_back(sui->lblDriver4Name);
    m_listDriverNameLabels.push_back(sui->lblDriver5Name);
    m_listDriverNameLabels.push_back(sui->lblDriver6Name);
    m_listDriverNameLabels.push_back(sui->lblDriver7Name);

    m_listDriverSignalViews.push_back(sui->imvDriver1Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver2Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver3Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver4Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver5Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver6Signal);
    m_listDriverSignalViews.push_back(sui->imvDriver7Signal);

    m_listDriverStatusLabels.push_back(sui->lblDriver1Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver2Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver3Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver4Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver5Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver6Status);
    m_listDriverStatusLabels.push_back(sui->lblDriver7Status);

    m_listDriverProgressBar.push_back(sui->pgbDriver1Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver2Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver3Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver4Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver5Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver6Progress);
    m_listDriverProgressBar.push_back(sui->pgbDriver7Progress);

    m_listDriverBusyIndicator.push_back(sui->bicDriver1Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver2Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver3Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver4Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver5Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver6Progress);
    m_listDriverBusyIndicator.push_back(sui->bicDriver7Progress);

    sui->imvClock->getGraphicsScene()->setBackgroundImageFile(IMAGE_CLOCK);
    sui->imvLogo->getGraphicsScene()->setBackgroundImageFile(IMAGE_LOGO);
}

void IGSxGUI::SystemView::init()
{
    m_mapSystemFunctions.clear();
    m_mapDrivers.clear();

    m_listSysFunctions = m_presenter->getSystemFunctions();

    for (size_t i = 0; i < m_listSysFunctions.size(); i++)
    {
        m_listSystemFunctionUCT[i]->setVisible(true);
        m_listSystemFunctionNameLabels[i]->setText(m_listSysFunctions[i]->getDescription());

        std::string sysFunName = m_listSysFunctions[i]->getName();
        std::pair<std::string, SysFunInfo> sysfunPair;

        sysfunPair.first = sysFunName;
        sysfunPair.second.UiID.UCT = m_listSystemFunctionUCT[i];
        sysfunPair.second.UiID.imvSignal = m_listSystemFunctionSignalViews[i];
        sysfunPair.second.UiID.lblName = m_listSystemFunctionNameLabels[i];
        sysfunPair.second.UiID.lblStatus = m_listSystemFunctionStatusLabels[i];
        sysfunPair.second.UiID.pgbProgress = m_listSystemFunctionProgressBar[i];
        sysfunPair.second.UiValues.NameText = m_listSysFunctions[i]->getDescription();
        sysfunPair.second.UiValues.StatusText = "";
        sysfunPair.second.UiValues.imagePath = "";
        sysfunPair.second.UiValues.imageVisibility = false;
        sysfunPair.second.UiValues.progressbarVisibility = false;
        sysfunPair.second.UiValues.ProgressbarValue = 0;

        std::vector<Driver*> drivers = m_presenter->getDrivers(sysFunName);

        for (size_t j = 0; j < drivers.size(); j++)
        {
            std::pair<std::string, DriverInfo> driverPair;

            if (!drivers[j]->isImplemented())
            {
                driverPair.second.UiValues.isImplemented = false;
                driverPair.second.UiValues.statusBICVisibility = false;
                driverPair.second.UiValues.statusTextVisibility = false;
                driverPair.second.UiValues.imageVisibility = false;
            } else {
                driverPair.second.UiValues.isImplemented = true;
                driverPair.second.UiValues.statusTextVisibility = true;
                ++m_totaldrivercount;
            }
            driverPair.first = drivers[j]->getName();
            driverPair.second.UiValues.NameText = drivers[j]->getDisplayName();
            driverPair.second.UiValues.StatusText = m_driverStates[drivers[j]->getState()];
            driverPair.second.UiValues.SysFunctionName = sysFunName;
            driverPair.second.UiValues.imageVisibility = false;
            driverPair.second.UiValues.imagePath = "";
            driverPair.second.UiValues.statusBICVisibility = false;

            m_mapDrivers.insert(driverPair);
        }
        sysfunPair.second.UiValues.TotalDriverCount = static_cast<int>(m_listSysFunctions[i]->getDriverCount());
        sysfunPair.second.UiValues.InitializedDriverCount = 0;
        sysfunPair.second.UiValues.TerminatedDriverCount = 0;
        if (m_listSysFunctions[i]->getDriverCount() > 0)
        {
            sysfunPair.second.UiValues.ProgressValueToBeIncreased = static_cast<int>((100 / m_listSysFunctions[i]->getDriverCount()) + 1);
            sysfunPair.second.UiValues.StatusText = m_sysFunStates[m_listSysFunctions[i]->getState()];
        }

        sysfunPair.second.UiID.lblStatus->setText(sysfunPair.second.UiValues.StatusText);
        m_mapSystemFunctions.insert(sysfunPair);
    }
    updateMainStatus(m_presenter->getSystemState());
}

void IGSxGUI::SystemView::reInit()
{
    m_listSysFunctions = m_presenter->getSystemFunctions();

    for (size_t i = 0; i < m_listSysFunctions.size(); i++)
    {
        m_listSystemFunctionUCT[i]->setVisible(true);
        m_listSystemFunctionNameLabels[i]->setText(m_listSysFunctions[i]->getDescription());

        std::string sysFunName = m_listSysFunctions[i]->getName();

        std::map<std::string, SysFunInfo>::iterator itSysFun = m_mapSystemFunctions.find(sysFunName);

        if (itSysFun != m_mapSystemFunctions.end())
        {
            itSysFun->second.UiID.UCT = m_listSystemFunctionUCT[i];
            itSysFun->second.UiID.imvSignal = m_listSystemFunctionSignalViews[i];
            itSysFun->second.UiID.lblName = m_listSystemFunctionNameLabels[i];
            itSysFun->second.UiID.lblStatus = m_listSystemFunctionStatusLabels[i];
            itSysFun->second.UiID.pgbProgress = m_listSystemFunctionProgressBar[i];

            itSysFun->second.UiID.imvSignal->setVisible(itSysFun->second.UiValues.imageVisibility);
            itSysFun->second.UiID.imvSignal->getGraphicsScene()->setBackgroundImageFile(itSysFun->second.UiValues.imagePath);
            itSysFun->second.UiID.lblStatus->setText(itSysFun->second.UiValues.StatusText);
            itSysFun->second.UiID.pgbProgress->setVisible(itSysFun->second.UiValues.progressbarVisibility);
            itSysFun->second.UiID.pgbProgress->setValue(itSysFun->second.UiValues.ProgressbarValue);
        }

        std::vector<Driver*> drivers = m_presenter->getDrivers(sysFunName);

        for (size_t j = 0; j < drivers.size(); j++)
        {
            std::string driverName = drivers[j]->getName();

            std::map<std::string, DriverInfo>::iterator itDriver = m_mapDrivers.find(driverName);

            if (itDriver != m_mapDrivers.end())
            {
                itDriver->second.UiID.UCT = m_listDriverUCT[j];
                itDriver->second.UiID.imvSignal = m_listDriverSignalViews[j];
                itDriver->second.UiID.lblName = m_listDriverNameLabels[j];
                itDriver->second.UiID.lblStatus = m_listDriverStatusLabels[j];
                itDriver->second.UiID.pgbProgress = m_listDriverProgressBar[j];
                itDriver->second.UiID.bicProgress = m_listDriverBusyIndicator[j];
            }
        }
    }
    sui->gbxSystem->setBGColor(m_mainStatus.color);
    sui->lblMainStatus->setText(m_mainStatus.strMessage);
    sui->btnInit->setVisible(m_mainStatus.bBtnInitVisibility);
    sui->btnTerminate->setVisible(m_mainStatus.bBtnTerminateVisibility);
    sui->btnResolve->setVisible(m_mainStatus.bBtnResolveVisibility);

    if (!m_mainStatus.bClockVisibility)
    {
        sui->imvClock->setVisible(m_mainStatus.bClockVisibility);
        sui->lblTimer->setVisible(m_mainStatus.bLblTimerVisibility);
    }    

    if(m_nameCurrentSelectedSysFunction != "")
    {
        manipulateSysFunSelection(m_indexSysFunctionLastSelected,true);
        reShowDrivers(m_sysFunctionLastSelected);

        if(m_nameCurrentSelectedDriver != "")
        {
            manipulateDriverSelection(m_indexDriverLastSelected,true);
            reShowErrorInfo(m_nameCurrentSelectedDriver);
        }
    }
    updateMainStatus(m_presenter->getSystemState());
}

void IGSxGUI::SystemView::hideProgressbar()
{
    for (std::map<std::string, SysFunInfo>::iterator it = m_mapSystemFunctions.begin(); it!=m_mapSystemFunctions.end(); ++it)
    {
        if ( it->second.UiValues.progressbarVisibility )
        {
            it->second.UiValues.progressbarVisibility = false;
            it->second.UiID.pgbProgress->setVisible(it->second.UiValues.progressbarVisibility);
        }
    }
}

void IGSxGUI::SystemView::updateSysFunction(DriverState::DriverStateEnum state, std::string strSysFunction, int nInitializedDriverCount, int nTerminatedDriverCount)
{
    std::map<std::string, SysFunInfo>::iterator it = m_mapSystemFunctions.find(strSysFunction);

    if (it != m_mapSystemFunctions.end())
    {
        switch (state)
        {
            case DriverState::DS_INITIALIZED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.imageVisibility = true;
                it->second.UiValues.imagePath = IMAGE_OK;
                it->second.UiValues.progressbarVisibility = false;
                break;
            }
            case DriverState::DS_TERMINATED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.imageVisibility = false;
                it->second.UiValues.progressbarVisibility = false;
                break;
            }
            case DriverState::DS_INITIALIZING:
            {
                std::string temp;
                it->second.UiValues.InitializedDriverCount = nInitializedDriverCount;
                temp.append(boost::lexical_cast<std::string>(it->second.UiValues.InitializedDriverCount)).append(" / ").append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount));

                it->second.UiValues.ProgressbarValue = it->second.UiValues.ProgressValueToBeIncreased * nInitializedDriverCount;

                it->second.UiValues.StatusText = temp;
                it->second.UiValues.imageVisibility = false;
                it->second.UiValues.progressbarVisibility = true;
                break;
            }
            case DriverState::DS_TERMINATING:
            {
                std::string temp;
                it->second.UiValues.TerminatedDriverCount = nTerminatedDriverCount;
                temp.append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount - nTerminatedDriverCount)).append(" / ").append(boost::lexical_cast<std::string>(it->second.UiValues.TotalDriverCount));

                int progressValue = it->second.UiValues.ProgressValueToBeIncreased * (it->second.UiValues.TotalDriverCount - nTerminatedDriverCount);
                it->second.UiValues.ProgressbarValue = progressValue > 100 ? 100:progressValue;

                it->second.UiValues.StatusText = temp;
                it->second.UiValues.imageVisibility = false;
                it->second.UiValues.progressbarVisibility = true;

                break;
            }
            case DriverState::DS_RECOVERY_REQUIRED:
            {
                it->second.UiValues.StatusText = m_sysFunStates[state];
                it->second.UiValues.imageVisibility = true;
                it->second.UiValues.progressbarVisibility = false;
                it->second.UiValues.imagePath = IMAGE_NOT_OK;
                break;
            }
        }

        if (m_bSystemViewActive)
        {
            it->second.UiID.pgbProgress->setVisible(it->second.UiValues.progressbarVisibility);
            it->second.UiID.pgbProgress->setValue(it->second.UiValues.ProgressbarValue);
            it->second.UiID.lblStatus->setText(it->second.UiValues.StatusText);
            it->second.UiID.imvSignal->setVisible(it->second.UiValues.imageVisibility);
            it->second.UiID.imvSignal->getGraphicsScene()->setBackgroundImageFile(it->second.UiValues.imagePath);
            sui->tawDriver->clearFocus();
        }
    }
}

void IGSxGUI::SystemView::updateDriver(DriverState::DriverStateEnum state, std::string strDriver)
{
    std::map<std::string, DriverInfo>::iterator itDriver = m_mapDrivers.find(strDriver);

    if (itDriver != m_mapDrivers.end())
    {
        itDriver->second.UiValues.StatusText = m_driverStates[state];

        switch (state)
        {
            case DriverState::DS_INITIALIZED:
            {
                itDriver->second.UiValues.imageVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.imagePath = IMAGE_OK;

                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICVisibility = false;
                break;
            }
            case DriverState::DS_TERMINATED:
            {
                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICVisibility = false;
                itDriver->second.UiValues.imageVisibility = false;
                break;
            }
            case DriverState::DS_INITIALIZING:
            case DriverState::DS_TERMINATING:
            {
                itDriver->second.UiValues.imageVisibility = false;
                itDriver->second.UiValues.imagePath = "";

                itDriver->second.UiValues.statusTextVisibility = false;
                itDriver->second.UiValues.statusBICVisibility = (true && itDriver->second.UiValues.isImplemented);
                break;
            }
            case DriverState::DS_RECOVERY_REQUIRED:
            {
                itDriver->second.UiValues.imageVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.imagePath = IMAGE_NOT_OK;

                itDriver->second.UiValues.statusTextVisibility = (true && itDriver->second.UiValues.isImplemented);
                itDriver->second.UiValues.statusBICVisibility = false;
                break;
            }
        }

        // Fixed a bug - overlapping driver status values.
        // Set driver values, only if it is visible.
        // This bug found, after Switching page
        for (std::size_t i = 0; i < m_listDrivers.size(); i++)
        {
            if(strDriver == m_listDrivers[i]->getName())
            {
                if (m_bSystemViewActive && itDriver->second.UiID.UCT != NULL)
                {
                     itDriver->second.UiID.bicProgress->setVisible(itDriver->second.UiValues.statusBICVisibility);
                     itDriver->second.UiID.lblStatus->setVisible(itDriver->second.UiValues.statusTextVisibility);
                     itDriver->second.UiID.lblStatus->setText(itDriver->second.UiValues.StatusText);
                     itDriver->second.UiID.imvSignal->setVisible(itDriver->second.UiValues.imageVisibility);
                     itDriver->second.UiID.imvSignal->getGraphicsScene()->setBackgroundImageFile(itDriver->second.UiValues.imagePath);
                }
            }
        }
    }
}

void IGSxGUI::SystemView::showDrivers(SystemFunction* sysFunction, int uctIndex)
{
    hideDrivers();

    if (sysFunction->getName() == m_nameCurrentSelectedSysFunction)
    {
        m_nameCurrentSelectedSysFunction = "";
        manipulateSysFunSelection(uctIndex, false);
    } else {
        manipulateSysFunSelection(uctIndex, true);

        m_sysFunctionLastSelected = sysFunction;
        m_indexSysFunctionLastSelected = uctIndex;

        m_nameCurrentSelectedSysFunction = sysFunction->getName();
        m_nameCurrentSelectedDriver.clear();

        sui->tawDriver->setVisible(true);
        sui->tawDriver->clearFocus();        

        std::string strDriverText(STRING_SEPERATOR);
        std::string strDesc = sysFunction->getDescription();
        std::transform(strDesc.begin(), strDesc.end(), strDesc.begin(), std::ptr_fun<int, int>(toupper));
        strDriverText.append(strDesc.append(STRING_DRIVERS));

        if (m_bSystemViewActive)
        {
            sui->lblFunction->setVisible(true);
            sui->lblFunction->setText(strDriverText);
        }
        loadDrivers(sysFunction->getName());
    }
}

void IGSxGUI::SystemView::reShowDrivers(SystemFunction* sysFunction)
{
    std::string strDriverText(STRING_SEPERATOR);
    std::string strDesc = sysFunction->getDescription();
    std::transform(strDesc.begin(), strDesc.end(), strDesc.begin(), std::ptr_fun<int, int>(toupper));
    strDriverText.append(strDesc.append(STRING_DRIVERS));

    if (m_bSystemViewActive)
    {
        sui->tawDriver->setVisible(true);
        sui->lblFunction->setVisible(true);
        sui->lblFunction->setText(strDriverText);
    }
    loadDrivers(sysFunction->getName());
}

void IGSxGUI::SystemView::loadDrivers(std::string sysFunctionName)
{
    m_listDrivers.clear();
    m_listDrivers = m_presenter->getDrivers(sysFunctionName);

    for (std::size_t i = 0; i < m_listDrivers.size(); i++)
    {
        std::map<std::string, DriverInfo>::iterator it = m_mapDrivers.find(m_listDrivers[i]->getName());

        if (it != m_mapDrivers.end())
        {
            if (m_bSystemViewActive)
            {
                it->second.UiID.UCT = m_listDriverUCT[i];
                it->second.UiID.imvSignal = m_listDriverSignalViews[i];
                it->second.UiID.lblName = m_listDriverNameLabels[i];
                it->second.UiID.lblStatus = m_listDriverStatusLabels[i];
                it->second.UiID.pgbProgress = m_listDriverProgressBar[i];
                it->second.UiID.bicProgress = m_listDriverBusyIndicator[i];

                it->second.UiID.UCT->setVisible(true);
                it->second.UiID.lblName->setEnabled(it->second.UiValues.isImplemented);
                it->second.UiID.imvSignal->setVisible(it->second.UiValues.imageVisibility);
                it->second.UiID.bicProgress->setVisible(it->second.UiValues.statusBICVisibility);
                it->second.UiID.lblStatus->setVisible(it->second.UiValues.statusTextVisibility);
                it->second.UiID.lblName->setText(m_listDrivers[i]->getDisplayName());
                it->second.UiID.lblStatus->setText(it->second.UiValues.StatusText);
                it->second.UiID.imvSignal->getGraphicsScene()->setBackgroundImageFile(it->second.UiValues.imagePath);
                it->second.UiID.lblStatus->setText(it->second.UiValues.StatusText);
            }
        }
    }
}

void IGSxGUI::SystemView::showError()
{
    m_timer->stop();
}

void IGSxGUI::SystemView::showErrors()
{
    m_timer->stop();
}

void IGSxGUI::SystemView::onTimerTimeout()
{
    showElapsedTime();
    m_timer->start();
}

void IGSxGUI::SystemView::updateMainStatus(SystemState::SystemStateEnum state)
{
    switch (state)
    {
        case SystemState::SS_INITIALIZED:
        {
            updateStatus(SUI::ColorEnum::Green, state, false, true, true, false, false);
            break;
        }
        case SystemState::SS_TERMINATED:
        {
            updateStatus(SUI::ColorEnum::Standard, state, false, true, true, false, false);
            break;
        }
        case SystemState::SS_INITIALIZING:
        case SystemState::SS_TERMINATING:
        {
            updateStatus(SUI::ColorEnum::Blue, state, false, false, false, true, true);
            break;
        }
        case SystemState::SS_PARTIALLY_INITIALIZED:
        {
            hideProgressbar();
            updateStatus(SUI::ColorEnum::Yellow, state, false, true, true, false, false);
            break;
        }
        case SystemState::SS_RECOVERY_REQUIRED:
        {
            updateStatus(SUI::ColorEnum::Red, state, false, true, true, false, false);
            break;
        }
    }
}
