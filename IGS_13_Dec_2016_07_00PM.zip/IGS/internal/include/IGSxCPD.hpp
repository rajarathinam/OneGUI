/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPD.hpp
| Author       : Thijs Jacobs
| Description  : Proxy interface for Test Manager,
|                Calibration, Performance and Diagnostics (CPD) Manager
|                The Test Manager manages the execution of CPD tests
|
| ! \file        IGSxCPD.hpp
| ! \brief       Proxy interface for Test Manager,
|                Calibration, Performance and Diagnostics (CPD) Manager
|                The Test Manager manages the execution of CPD tests
|
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSxCPD_HPP
#define IGSxCPD_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include <vector>
#include <boost/function.hpp>

#include "IGSxCOMMON.hpp"


namespace IGSxCPD {

/*----------------------------------------------------------------------------|
|                                     Type Defs                               |
|----------------------------------------------------------------------------*/
// CPD meta data
class MetaDescription
{
public:
    explicit MetaDescription(const std::string& _name, const std::string& _testType, const std::string& _subSystem, const std::string& _description, const std::string& _htmlFile) 
        {m_name = _name; m_testType = _testType; m_subSystem = _subSystem; m_description = _description; m_htmlFile = _htmlFile;}
    virtual ~MetaDescription() {}

    std::string name() const {return m_name;}
    std::string testType() const {return m_testType;}
    std::string subSystem() const {return m_subSystem;}
    std::string description() const {return m_description;}
    std::string htmlFile() const {return m_htmlFile;}
    void setName(const std::string& _name) {m_name = _name;}
    void setTestType(const std::string& _testType) {m_testType = _testType;}
    void setSubSystem(const std::string& _subSystem) {m_subSystem = _subSystem;}
    void setDescription(const std::string& _description) {m_description = _description;}
    void setHtmlFile(const std::string& _htmlFile) {m_htmlFile = _htmlFile;}

private:
    std::string m_name;        // test name, e.g. LCD_FFAFRF_CO2
    std::string m_testType;    // test type: Calibration, Performance, Diagnostics or Adjustment
    std::string m_subSystem;   // sub system, e.g. FinalFocusAssembly
    std::string m_description; // short description, e.g. Frequency Response Function
    std::string m_htmlFile;    // html description file, e.g. LCD_FFAFRF_CO2_description.html
};
typedef std::vector<MetaDescription> MetaDescriptions;


// callback type test stopped notification
typedef boost::function<void (IGS::Result)> TestStoppedCallback;


/*----------------------------------------------------------------------------|
|                                     Interface Definition                    |
|----------------------------------------------------------------------------*/
class CPD
{
// functions throw IGS::exception
public:
    static CPD* getInstance() {return instance;}

    // get all tests
    virtual void getTests(MetaDescriptions& tests) = 0;

    // start a test
    virtual void startTest(const std::string& testName) = 0;
    
    // get the current active test
    // returns the name of the current active test 
    // returns an empty string when no test is active
    virtual std::string getCurrentTest() = 0;
    
    // test stopped event
    virtual void subscribeToTestStopped(const TestStoppedCallback& cb) = 0;
    virtual void unsubscribeToTestStopped() = 0;

protected:
    // instance
    virtual ~CPD() {}
    static CPD* instance;
};

} // namespace IGSxCPD

#endif // IGSxCPD_HPP

