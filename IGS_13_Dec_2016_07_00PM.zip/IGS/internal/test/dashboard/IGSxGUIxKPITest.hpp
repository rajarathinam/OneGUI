/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxKPITest.hpp
| Author       : Arjan Tekelenburg
| Description  : Header file for KPI test
|
| ! \file        IGSxGUIxKPITest.hpp
| ! \brief       Header file for KPI test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXKPITEST_HPP
#define IGSXGUIXKPITEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxKpi.hpp"

using std::vector;
using std::list;
using IGSxKPI::KPIDefinition;
using IGSxKPI::KPIDefinitionList;
using IGSxKPI::KPIValueSet;
using IGSxKPI::KPIValueSetDefinition;
using IGSxKPI::KPIValueSetDefinitionList;
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
template<typename T>
    ::testing::AssertionResult VectorsMatch(vector<T> Expected, vector<T> Actual)
{
        for (int i=0; i < Expected.size(); i++)
        {
            if (Expected.at(i)->getName().compare(Actual.at(i)->getName()) != 0)
            {
                return ::testing::AssertionFailure();
            }
        }
        return ::testing::AssertionSuccess();
}

template<typename T>
    ::testing::AssertionResult ListMatch(list<T> Expected, list<T> Actual)
{
        while ((!Expected.empty()) && (!Actual.empty()))
        {
            if (Expected.front().compare(Actual.front()) != 0)
            {
                return ::testing::AssertionFailure();
            }
            Expected.pop_front();
            Actual.pop_front();
        }
        return ::testing::AssertionSuccess();
}

class KPITest : public ::testing::Test
{
 public:
    KPITest(){}
    virtual ~KPITest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

class KPITestParam : public ::testing::TestWithParam<std::string>
{
 public:
    KPITestParam(){}
    virtual ~KPITestParam(){}
 protected:
    KPIDefinition m_kpiDefinition1;
    KPIDefinition m_kpiDefinition2;
 protected:
  virtual void SetUp()
  {
    KPIValueSetDefinitionList kpiValueSetDefinitionList_1;
    KPIValueSetDefinition kpiValueSetDefinition1_1("ValueSetName1_1", "ValueSetDescription1_1", "ValueSetUnit1_1");
    KPIValueSetDefinition kpiValueSetDefinition1_2("ValueSetName1_2", "ValueSetDescription1_2", "ValueSetUnit1_2");
    KPIValueSetDefinition kpiValueSetDefinition1_3("ValueSetName1_3", "ValueSetDescription1_3", "ValueSetUnit1_3");

    kpiValueSetDefinitionList_1.push_back(kpiValueSetDefinition1_1);
    kpiValueSetDefinitionList_1.push_back(kpiValueSetDefinition1_2);
    kpiValueSetDefinitionList_1.push_back(kpiValueSetDefinition1_3);

    KPIDefinition kpiDefinition1("DefName_1", "DefDescription_1", kpiValueSetDefinitionList_1);
    m_kpiDefinition1 = kpiDefinition1;

    KPIValueSetDefinitionList kpiValueSetDefinitionList_2;
    KPIValueSetDefinition kpiValueSetDefinition2_1("ValueSetName2_1", "ValueSetDescription2_1", "ValueSetUnit2_1");
    KPIValueSetDefinition kpiValueSetDefinition2_2("ValueSetName2_2", "ValueSetDescription2_2", "ValueSetUnit2_2");
    KPIValueSetDefinition kpiValueSetDefinition2_3("ValueSetName2_3", "ValueSetDescription2_3", "ValueSetUnit2_3");

    kpiValueSetDefinitionList_2.push_back(kpiValueSetDefinition2_1);
    kpiValueSetDefinitionList_2.push_back(kpiValueSetDefinition2_2);
    kpiValueSetDefinitionList_2.push_back(kpiValueSetDefinition2_3);

    KPIDefinition kpiDefinition2("DefName_2", "DefDescription_2", kpiValueSetDefinitionList_2);
    m_kpiDefinition2 = kpiDefinition2;
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};

#endif  // IGSXGUIXKPITEST_HPP
