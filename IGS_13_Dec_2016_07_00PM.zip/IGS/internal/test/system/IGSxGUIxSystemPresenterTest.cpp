/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemPresenterTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of System Presenter test
|
| ! \file        IGSxGUIxSystemPresenterTest.cpp
| ! \brief       Implementation of System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxSystemPresenterTest.hpp"
#include "IGSxGUIxDriverManager.hpp"
#include "IGSxGUIxISystemView.hpp"
#include "IGSxGUIxSystemView.hpp"
#include "IGSxGUIxDriver.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
INSTANTIATE_TEST_CASE_P(InstantiationName,
                        SystemPresenterTestParam,
                        ::testing::Values("SF-04"));

TEST_P(SystemPresenterTestParam, Test1)
{
    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();
    SystemViewStub* stubView = new SystemViewStub();
    drvMgr->addSystemFunctions(Sysfunctions);
    IGSxGUI::SystemPresenter* ptr = new IGSxGUI::SystemPresenter(stubView, drvMgr);

    vector<IGSxGUI::Driver*> drv= ptr->getDrivers("SF-04");
    EXPECT_EQ(drv.size(), 5);

    delete ptr;
    delete drvMgr;
    delete stubView;
}

TEST_P(SystemPresenterTestParam, Test2)
{
    IGSxGUI::DriverManager* drvMgr = new IGSxGUI::DriverManager();
    SystemViewStub* stubView = new SystemViewStub();
    drvMgr->addSystemFunctions(Sysfunctions);
    IGSxGUI::SystemPresenter* ptr = new IGSxGUI::SystemPresenter(stubView, drvMgr);

    vector<IGSxGUI::Driver*> drv= ptr->getDrivers("SF-15");
    EXPECT_EQ(drv.size(), 6);

    delete ptr;
    delete drvMgr;
    delete stubView;
}
