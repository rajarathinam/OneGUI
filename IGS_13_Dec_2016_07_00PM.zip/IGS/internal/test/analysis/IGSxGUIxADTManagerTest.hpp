/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADTManagerTest.hpp
| Author       : Venugopal S
| Description  : Header file for ADT Manager test
|
| ! \file        IGSxGUIxADTManagerTest.hpp
| ! \brief       Header file for ADT Manager test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXADTMANAGERTEST_HPP
#define IGSXGUIXADTMANAGERTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include <vector>
#include <list>
#include <string>
#include "IGSxGUIxADT.hpp"
#include "IGSxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class ADTManagerTest : public ::testing::Test
{
 public:
    ADTManagerTest(){}
    virtual ~ADTManagerTest(){}

 protected:
  virtual void SetUp()
  {
  }

  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXGUIXADTMANAGERTEST_HPP
