/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxStandAloneView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Standalone view
|
| ! \file        IGSxGUIxStandAloneView.cpp
| ! \brief       Implementation of Standalone view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxStandAloneView.hpp"
#include <boost/bind.hpp>
#include <string>
#include <SUIDialog.h>
#include <SUIButton.h>
#include "IGSxGUIxMoc_StandAloneView.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::StandAloneView::StandAloneView() :
    sui(new SUI::StandAloneView)
{
    sui->setupSUI("IGSxGUIxStandAlone.xml");
    m_presenter = new IGSxGUI::StandAlonePresenter(this);
}

IGSxGUI::StandAloneView::~StandAloneView()
{
    delete sui;
    delete m_presenter;
    // Do not delete the plugins, they are maintained by the Factory
}

void IGSxGUI::StandAloneView::show(std::string strPluginName)
{
    sui->dialog->show();

    if (!strPluginName.compare("System"))
    {
        ISystem* systemPlugin = PluginFactory::getInstance().getSystemPlugin();
        if (systemPlugin)
        {
            systemPlugin->setActive(true);
            systemPlugin->show(sui->containerStandAlone, true);
        }
    } else if (!strPluginName.compare("Analysis")) {
        IAnalysis* analysisPlugin = PluginFactory::getInstance().getAnalysisPlugin();
        if (analysisPlugin)
        {
            analysisPlugin->show(sui->containerStandAlone, true);
        }

    } else if (!strPluginName.compare("Dashboard")) {
        IDashboard* dashboardPlugin = PluginFactory::getInstance().getDashboardPlugin();
        if (dashboardPlugin)
        {
            dashboardPlugin->show(sui->containerStandAlone, true);
        }
    }
}


