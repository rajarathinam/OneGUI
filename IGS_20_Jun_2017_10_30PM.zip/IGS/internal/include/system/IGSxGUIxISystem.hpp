/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxISystem.hpp
| Author       : Arjan Tekelenburg
| Description  : Interface file for System plugin
|
| ! \file        IGSxGUIxISystem.hpp
| ! \brief       Interface file for System plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXISYSTEM_HPP
#define IGSXGUIXISYSTEM_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <SUIContainer.h>
#include "IGSxGUIxSystemState.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class ISystem
{
 public:
    ISystem(){}
    virtual ~ISystem() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void showCPD(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
    virtual void subscribeForSystemState(const SystemStateChangedCallback& cb)= 0;
    virtual void unsubscribeForSystemState(const SystemStateChangedCallback& cb)= 0;
    virtual IGSxGUI::SystemState::SystemStateEnum retrieveSystemState()= 0;
    virtual void notifyAlertPopup(bool bAlertPopupRaised) = 0;
};
}  // namespace IGSxGUI
#endif
