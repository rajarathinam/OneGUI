#ifndef IGSXGUIXAPPLICATION_H
#define IGSXGUIXAPPLICATION_H
#include <string>

class IGSxGUIxApplication
{
public:
    IGSxGUIxApplication(const std::string& resourcePath);
    void exec();
private:
    std::string m_resourcePath;
};

#endif // IGSXGUIXAPPLICATION_H
