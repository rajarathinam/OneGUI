/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxCPDStubTest.hpp
| Author       : Venugopal S
| Description  : Header file for IGSxCPD Stub test
|
| ! \file        IGSxCPDStubTest.hpp
| ! \brief       Header file for IGSxCPD Stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXCPDSTUBTEST_HPP
#define IGSXCPDSTUBTEST_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <gtest.h>
#include "IGSxCPD.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
class IGSxCPDStubTest : public ::testing::Test
{
 public:
  IGSxCPDStubTest(){}
  virtual ~IGSxCPDStubTest(){}
 protected:
  virtual void SetUp()
  {
  }
  virtual void TearDown()
  {
     // Code here will be called immediately after each test
     // (right before the destructor).
  }
};
#endif  // IGSXCPDSTUBTEST_HPP
