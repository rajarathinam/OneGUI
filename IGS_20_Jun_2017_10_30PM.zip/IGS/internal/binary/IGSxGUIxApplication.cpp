#include "IGSxGUIxApplication.h"

IGSxGUIxApplication::IGSxGUIxApplication(const std::string &resourcePath)
{
    m_resourcePath = resourcePath;
}

void IGSxGUIxApplication::exec()
{
    /*
    boost::shared_ptr<SUI::Application> app = SUI::Application::createApplication(argc, argv);
    SUI::ResourcePath::getInstance()->setResourcePath(m_resourcePath);

    IGSxGUI::ISplashView *splashView = new IGSxGUI::SplashView();
    splashView->show();

    IGSxGUI::PluginFactory::getInstance().initialize();
    delete splashView;
    splashView = NULL;

    IGSxGUI::IMainView *mainView = new IGSxGUI::MainView();
    mainView->show();
    int result = app->exec();
    delete mainView;
    mainView = NULL;
    return result;
    */
}

