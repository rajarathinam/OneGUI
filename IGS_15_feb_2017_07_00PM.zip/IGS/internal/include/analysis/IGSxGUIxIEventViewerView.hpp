/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIEventViewerView.hpp
| Author       : Surya Tiwari
| Description  : Interface file for Event Viewer
|
| ! \file        IGSxGUIxIEventViewerView.hpp
| ! \brief       Interface file for Event Viewer
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIEVENTVIEWERVIEW_HPP
#define IGSXGUIXIEVENTVIEWERVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{

class IEventViewerView
{
 public:
    IEventViewerView() {}
    virtual ~IEventViewerView() {}

    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIEVENTVIEWERVIEW_HPP
