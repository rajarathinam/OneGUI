/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.hpp
| Author       : Venugopal S
| Description  : Header file for CPD view
|
| ! \file        IGSxGUIxCPDView.hpp
| ! \brief       Header file for CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXCPDVIEW_HPP
#define IGSXGUIXCPDVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxGUIxICPDView.hpp"
#include "IGSxGUIxCPDPresenter.hpp"
#include <SUIButton.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class CPDView;
class Label;
class UserControl;
class GroupBox;
class Timer;
}  // namespace SUI

namespace IGSxGUI{

struct structContainer
{
    std::string name;
    CPD* cpd;
};
typedef structContainer container;

struct structSubsystemCount
{
    std::string nameSubsystem;
    int count;
};
typedef structSubsystemCount subSystemCount;

class CPDView : public ICPDView
{
 public:
    explicit CPDView(CPDManager* pCPDManager);
    virtual ~CPDView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const std::string&, const IGS::Result& result);
    virtual void setActive(bool bActive);

 private:
    CPDView(const CPDView &);
    CPDView& operator=(const CPDView &);

    void onActiveCPDShowButtonPressed();
    void onWarningCloseButtonPressed();
    void onActiveCPDDetailButtonPressed();
    void onRadioButtonAllPressed();
    void onRadioButtonCalibrationPressed();
    void onRadioButtonPerformancePressed();
    void onRadioButtonDiagnosticsPressed();
    void onWarningTimeout();
    void onButtonTestReportPressed();

    void onButtonCPD1StartPressed();
    void onButtonCPD2StartPressed();
    void onButtonCPD3StartPressed();
    void onButtonCPD4StartPressed();
    void onButtonCPD5StartPressed();
    void onButtonCPD6StartPressed();
    void onButtonCPD7StartPressed();
    void onButtonCPD8StartPressed();
    void onButtonCPD9StartPressed();
    void onButtonCPD10StartPressed();

    void onButtonCPD1DetailPressed();
    void onButtonCPD2DetailPressed();
    void onButtonCPD3DetailPressed();
    void onButtonCPD4DetailPressed();
    void onButtonCPD5DetailPressed();
    void onButtonCPD6DetailPressed();
    void onButtonCPD7DetailPressed();
    void onButtonCPD8DetailPressed();
    void onButtonCPD9DetailPressed();
    void onButtonCPD10DetailPressed();

    void updatePaginationButtonTextOnPressed();
    void onButtonPrevPressed();
    void onButtonNextPressed();
    void onButtonOnePressed();
    void onButtonTwoPressed();
    void onButtonThreePressed();
    void onButtonFourPressed();

    void onSubsystemPressed();
    void onButtonShowReportsPressed();

    void loadContainers();
    void loadTestTypes();
    void loadSubSystems();
    void setHandlers();
    void setTextArea(const std::string& cpdDescription, const std::string& cpdTestName, const std::string& cpdTestType) const;
    void loadCPDs();
    void startCPD(const std::string& cpdName, const std::string& cpdType);
    void init();
    void initNumberedButtons(const int &numTotalPages) const;
    void fetchCPDs(const int &nCurrentPageNumber) const;
    void modifyPrevNextButtons() const;
    void setNumberedButtonStyles(const int &nCurrentPage, const std::string& style) const;
    std::vector<CPD*> getTestTypeCPDs() const;
    std::vector<CPD*> getTestCPDsByName(const std::string& testtypeName) const;
    std::vector<CPD*> getSelectedSubSystemCPDs() const;
    void intersectCPDs(std::vector<CPD*> listTestTypeCPDs, std::vector<CPD*> listSubSystemCPDs);

    const std::string currentDateTime(const std::string& dateTime) const;

    SUI::CPDView *sui;
    CPDPresenter *m_presenter;

    boost::shared_ptr<SUI::Timer> m_timer;

    std::vector<SUI::UserControl*> m_listCPDUCT;
    std::vector<SUI::Label*> m_listCPDNameLabels;
    std::vector<SUI::Label*> m_listCPDTypeLabels;
    std::vector<SUI::Label*> m_listCPDDescriptionLabels;
    std::vector<SUI::Label*> m_listCPDTimeLabels;
    std::vector<SUI::Button*> m_listDisplayButtons;

    std::vector<SUI::GroupBox*> m_listCPDReportGroupBox;
    std::vector<SUI::Label*> m_listCPDReportNameLabels;
    std::vector<SUI::Label*> m_listCPDReportTypeLabels;
    std::vector<SUI::Label*> m_listCPDReportDescriptionLabels;

    std::vector<CPD*> m_listCPD;
    std::vector<CPD*> m_listSubsystemCPDs;
    std::vector<IGSxGUI::container> m_listTestTypes;
    std::vector<IGSxGUI::container> m_listSubsystems;
    std::vector<IGSxGUI::subSystemCount> m_listSubsystemCount;

    int m_numTotalPages;
    int m_numLastPageItems;
    int m_currentPageNo;

    bool m_bRunningCPD;
    std::string m_selectedSubSystem;

    static const std::string STRING_EMPTY;
    static const std::string STRING_ALL_CPDS;
    static const std::string CPDVIEW_LOAD_FILE;
    static const std::string STRING_NO_ACTIVE_CPD;
    static const std::string STRING_ACTIVE_CPD;
    static const std::string STRING_TIME;
    static const std::string STRING_DATE;
    static const std::string STRING_CALIBRATION;
    static const std::string STRING_PERFORMANCE;
    static const std::string STRING_DIAGNOSTICS;
    static const std::string STRING_OPEN_BRACKET;
    static const std::string STRING_CLOSE_BRACKET;
    static const std::string STYLE_NORMAL;
    static const std::string STYLE_CURRENTPAGE;
    static const std::string STYLE_ACTIVE_CPD;
    static const std::string STYLE_NO_ACTIVE_CPD;
    static const std::string IMAGE_CLOCK;
    static const std::string STRING_PREV_BUTTON;
    static const std::string STRING_NEXT_BUTTON;
    static const std::string STRING_DATETIME_FORMAT1;
    static const std::string STRING_DATETIME_FORMAT2;
    static const int TIMER_INTERVAL;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXCPDVIEW_HPP
