/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxKPIStubTest.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of IGSxKPI stub test
|
| ! \file        IGSxKPIStubTest.cpp
| ! \brief       Implementation of IGSxKPI stub test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxKPIStubTest.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
TEST_F(IGSxKPIStubTest, KPIInstanceTest)
{
    EXPECT_EQ(KPI::getInstance(), KPI::getInstance());    
}

TEST_F(IGSxKPIStubTest, ParserTest)
{
    KPIParser obj;
    obj.loadKPI();
    std::map<std::string,KPIINFO> mapKPI = obj.getKPIs();
    EXPECT_GT(mapKPI.size(), 0);
}

TEST_F(IGSxKPIStubTest, getKpis)
{
    IGSxKPI::KPIDefinitionList kpis;
    KPI::getInstance()->getKpis(kpis);
    EXPECT_GT(kpis.size(), 0);

    IGSxKPI::KPIDefinition kpidef = kpis[0];
    EXPECT_STRCASEEQ(kpidef.name().c_str(),"AMP_PA0in_MpPpPower_On");
    EXPECT_STRCASEEQ(kpidef.description().c_str(),"Seed table MP+PP power on droplet");

    EXPECT_GT(kpidef.values()->size(), 0);
    IGSxKPI::KPIValueSetDefinition valset = kpidef.values()->at(0);

    EXPECT_STRCASEEQ(valset.name().c_str(),"MEAN");
    EXPECT_STRCASEEQ(valset.description().c_str(),"MEAN");
    EXPECT_STRCASEEQ(valset.unit().c_str(),"W");
}

TEST_F(IGSxKPIStubTest, getKpi)
{
    IGSxKPI::KPIDefinition kpi;
    KPI::getInstance()->getKpi("AMP_PA0in_MpPpPower_On",kpi);

    EXPECT_STRCASEEQ(kpi.name().c_str(),"AMP_PA0in_MpPpPower_On");
    EXPECT_STRCASEEQ(kpi.description().c_str(),"Seed table MP+PP power on droplet");

    EXPECT_GT(kpi.values()->size(), 0);
    IGSxKPI::KPIValueSetDefinition valset = kpi.values()->at(0);

    EXPECT_STRCASEEQ(valset.name().c_str(),"MEAN");
    EXPECT_STRCASEEQ(valset.description().c_str(),"MEAN");
    EXPECT_STRCASEEQ(valset.unit().c_str(),"W");
}

TEST_F(IGSxKPIStubTest, getKpiData)
{
    time_t now = time(NULL);
    IGSxKPI::KPIDataList dataList;

    IGSxKPI::KPIDefinition kpi;
    KPI::getInstance()->getKpiData("AMP_PA0in_MpPpPower_On",now - 60000, now, dataList);

    IGSxKPI::KPIData data = dataList[0];

    EXPECT_STRCASEEQ(data.name().c_str(),"MEAN");
    EXPECT_GT(data.values()->at(0), 0);
}

