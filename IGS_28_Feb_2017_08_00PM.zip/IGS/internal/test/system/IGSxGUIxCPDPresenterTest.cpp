/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDPresenterTest.cpp
| Author       : Raja A
| Description  : Implementation of System Presenter test
|
| ! \file        IGSxGUIxCPDPresenterTest.cpp
| ! \brief       Implementation of System Presenter test
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <vector>
#include "IGSxGUIxCPDPresenterTest.hpp"
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxCPDManager.hpp"
#include "IGSxGUIxCPDManager.hpp"
using namespace IGSxGUI;
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/

TEST_F(CPDPresenterTest, Test1)
{
    CPDManager* pCPDManager = new CPDManager;
    pCPDManager->initialize();
    ICPDView* cpdview = new CPDView(pCPDManager);
    CPDPresenter* cpdpresenter = new CPDPresenter(cpdview,pCPDManager);

    CPD* cpd1 = cpdpresenter->getCPD("PMY_PCLYZM");
    EXPECT_EQ(cpd1->getName(),"PMY_PCLYZM");

    CPD* cpd2 = cpdpresenter->getCPD("LCF_FFAMDC");
    EXPECT_EQ(cpd2->getName(),"LCF_FFAMDC");

    if (cpdpresenter != NULL)
    {
        delete cpdpresenter;
        cpdpresenter = NULL;
    }
    if (cpdview != NULL)
    {
        delete cpdview;
        cpdview = NULL;
    }
    if (pCPDManager != NULL)
    {
        delete pCPDManager;
        pCPDManager = NULL;
    }
}

TEST_F(CPDPresenterTest, Test2)
{
    CPDManager* pCPDManager = new CPDManager;
    ICPDView* cpdview = new CPDView(pCPDManager);
    CPDPresenter* cpdpresenter = new CPDPresenter(cpdview,pCPDManager);

    std::vector<CPD*> listCPDs = cpdpresenter->getCPDs();
    EXPECT_EQ(0, listCPDs.size());


    listCPDs.clear();
    EXPECT_EQ(listCPDs.size(), 0);
    pCPDManager->initialize();
    listCPDs = cpdpresenter->getCPDs();
    EXPECT_EQ(51, listCPDs.size());

    if (cpdpresenter != NULL)
    {
        delete cpdpresenter;
        cpdpresenter = NULL;
    }
    if (cpdview != NULL)
    {
        delete cpdview;
        cpdview = NULL;
    }
    if (pCPDManager != NULL)
    {
        delete pCPDManager;
        pCPDManager = NULL;
    }
}

TEST_F(CPDPresenterTest, Test3)
{
    CPDManager* pCPDManager = new CPDManager;
    ICPDView* cpdview = new CPDView(pCPDManager);
    CPDPresenter* cpdpresenter = new CPDPresenter(cpdview,pCPDManager);
    std::vector<CPD*> listCPDs = cpdpresenter->getCPDs();

    listCPDs.clear();
    EXPECT_EQ(0, listCPDs.size());
    pCPDManager->initialize();


    listCPDs = cpdpresenter->getCPDs();
    EXPECT_EQ(51,listCPDs.size());
    EXPECT_EQ(cpdpresenter->startCPD("PMY_PCLYZM"),true);
    EXPECT_EQ(cpdpresenter->startCPD("ONEGUI"),false);
    EXPECT_EQ(cpdpresenter->startCPD("LCF_FFAMDC"),true);
    EXPECT_EQ(cpdpresenter->startCPD(""),false);

    if (cpdpresenter != NULL)
    {
        delete cpdpresenter;
        cpdpresenter = NULL;
    }
    if (cpdview != NULL)
    {
        delete cpdview;
        cpdview = NULL;
    }
    if (pCPDManager != NULL)
    {
        delete pCPDManager;
        pCPDManager = NULL;
    }
}


TEST_F(CPDPresenterTest, Test4)
{
    CPDManager* pCPDManager = new CPDManager;
    ICPDView* cpdview = new CPDView(pCPDManager);
    CPDPresenter* cpdpresenter = new CPDPresenter(cpdview,pCPDManager);

    IGSxCPD::TestResultList testresults;
    testresults.clear();
    time_t currenttime = time(NULL);
    EXPECT_EQ(0,testresults.size());
    cpdpresenter->getCPDTestResults("PMY_PCLYZM",currenttime,testresults);
    EXPECT_EQ("PMY_PCLYZM",testresults[0].name());

    if (cpdpresenter != NULL)
    {
        delete cpdpresenter;
        cpdpresenter = NULL;
    }
    if (cpdview != NULL)
    {
        delete cpdview;
        cpdview = NULL;
    }
    if (pCPDManager != NULL)
    {
        delete pCPDManager;
        pCPDManager = NULL;
    }
}
