/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxCPDView.cpp
| Author       : Venugopal S
| Description  : Implementation of CPD view
|
| ! \file        IGSxGUIxCPDView.cpp
| ! \brief       Implementation of CPD view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>
#include <time.h>
#include <string>
#include <list>
#include <vector>
#include <algorithm>
#include <fstream>
#include <functional>
#include <map>
#include "IGSxGUIxCPDView.hpp"
#include "IGSxGUIxMoc_CPDView.hpp"
#include "IGSxGUIxDateTime.hpp"
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIGroupBox.h>
#include <SUIRadioButton.h>
#include <SUITimer.h>
#include <SUITextArea.h>
#include <SUITableWidget.h>
#include <SUIDropDown.h>
#include <SUIWebView.h>
#include <SUIDateTimeEdit.h>
#include <SUIDateTime.h>
#include <SUITime.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::CPDView::CPDVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxCPD.xml");
const std::string IGSxGUI::CPDView::IMAGE_CLOCK = IGS::Resource::path("IGSxGUIxSystem_clock.png");

const std::string IGSxGUI::CPDView::STRING_EMPTY = "";
const std::string IGSxGUI::CPDView::STRING_ALL_CPDS = "All CPDs";
const std::string IGSxGUI::CPDView::STRING_CALIBRATION = "Calibration";
const std::string IGSxGUI::CPDView::STRING_PERFORMANCE = "Performance";
const std::string IGSxGUI::CPDView::STRING_DIAGNOSTICS = "Diagnostics";
const std::string IGSxGUI::CPDView::STRING_NO_ACTIVE_CPD = "There is no active CPD";
const std::string IGSxGUI::CPDView::STRING_ACTIVE_CPD = "This is an active CPD";
const std::string IGSxGUI::CPDView::STRING_PREV_BUTTON = ">";
const std::string IGSxGUI::CPDView::STRING_NEXT_BUTTON = "<";

const std::string IGSxGUI::CPDView::STRING_TIME = "Time";
const std::string IGSxGUI::CPDView::STRING_SPACE = "  ";
const std::string IGSxGUI::CPDView::STRING_DATE = "Date";
const std::string IGSxGUI::CPDView::STRING_OPEN_BRACKET = " (";
const std::string IGSxGUI::CPDView::STRING_CLOSE_BRACKET = ")";
const std::string IGSxGUI::CPDView::STRING_DATETIME_FORMAT3 = "%Y-%m-%d %H:%M:%S";

const std::string IGSxGUI::CPDView::STYLE_NORMAL = "Normal";
const std::string IGSxGUI::CPDView::STYLE_CPDINFO = "uctcpddetailedbutton";
const std::string IGSxGUI::CPDView::STYLE_CURRENTPAGE = "currentPage";
const std::string IGSxGUI::CPDView::STYLE_ACTIVE_CPD = "ActiveCPD";
const std::string IGSxGUI::CPDView::STYLE_NO_ACTIVE_CPD = "NoActiveCPD";

const std::string IGSxGUI::CPDView::IMAGE_CALIBRATION = "IGSxGUIxCalibration.png";
const std::string IGSxGUI::CPDView::IMAGE_PERFORMANCE = "IGSxGUIxPerformance.png";
const std::string IGSxGUI::CPDView::IMAGE_DIAGNOSTICS = "IGSxGUIxDiagnostics.png";

const int IGSxGUI::CPDView::TIMER_INTERVAL = 4000;

struct TimeDescOrderComparator
{
 public:
    bool operator()(const IGSxCPD::TestResult& testresult1, const IGSxCPD::TestResult& testresult2)
    {
        if (testresult1.time() > testresult2.time())
        {
            return true;
        }else {
            return false;
        }
    }
};
IGSxGUI::CPDView::CPDView(CPDManager *pCPDManager) :
    sui(new SUI::CPDView),
    m_timer(SUI::Timer::createTimer()),
    m_numTotalPages(0),
    m_numLastPageItems(0),
    m_currentPageNo(0),
    m_nPreviousDetailItem(0),
    m_bRunningCPD(false),
    m_selectedSubSystem(""),
    m_selectedCPD("")
{
    m_presenter = new CPDPresenter(this, pCPDManager);
}

IGSxGUI::CPDView::~CPDView()
{
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}


void IGSxGUI::CPDView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    sui->setupSUIContainer(CPDVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    setHandlers();
    loadContainers();
    init();
}

void IGSxGUI::CPDView::init()
{
    sui->lblActiveCPD->setColor(SUI::ColorEnum::Gray);
    sui->lblAllCPDs->setColor(SUI::ColorEnum::Gray);

    sui->gbxCPD->setBGColor(SUI::ColorEnum::White);

    sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_CPD);
    sui->lblDescription->setText(STRING_NO_ACTIVE_CPD);
    sui->lblType->setVisible(false);
    sui->lblName->setVisible(false);
    sui->lblStatus->setVisible(false);
    sui->btnShowCPD->setVisible(false);
    sui->btnCPDInfo->setVisible(false);

    sui->imvClock->getGraphicsScene()->setBackgroundImageFile(IMAGE_CLOCK);
    sui->lblDateTime->setText(IGSxGUI::DateTime::currentDateTime(STRING_DATE) + IGSxGUI::DateTime::currentDateTime(STRING_TIME));
    sui->tawCPDSubsystem->showGrid(false);
    sui->rbtnAll->setChecked(true);

    if (m_presenter != NULL)
    {
        m_listCPD = m_presenter->getCPDs();
        m_listSubsystemCPDs = m_presenter->getCPDs();
    }
    sui->btnNext->setText(STRING_PREV_BUTTON);
    sui->btnPrev->setText(STRING_NEXT_BUTTON);

    loadTestTypes();
    loadSubSystems();
    loadCPDs();
    sui->btnMoreReports->setVisible(false);
    sui->lblCPDDescTime1->setVisible(false);
    sui->lblCPDDescTime2->setVisible(false);
    sui->lblCPDDescTime3->setVisible(false);
    sui->lblCPDDescTime4->setVisible(false);
}

void IGSxGUI::CPDView::initNumberedButtons(const int& numTotalPages) const
{
    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if ( boost::lexical_cast<int>(m_listDisplayButtons[i]->getText()) <= numTotalPages)
        {
            m_listDisplayButtons[i]->setEnabled(true);
        } else {
            m_listDisplayButtons[i]->setEnabled(false);
        }
    }
}

void IGSxGUI::CPDView::fetchCPDs(const int& nCurrentPageNumber) const
{
    size_t j  = ((nCurrentPageNumber - 1)*10);

    for (size_t i = 0 ; i < m_listCPDUCT.size(); i++)
    {
        if ( j < m_listCPD.size())
        {
            m_listCPDUCT[i]->setVisible(true);
            m_listCPDNameLabels[i]->setText(m_listCPD[j]->getName());
            std::string testtype = m_listCPD[j]->getTestType();

            if (testtype == STRING_CALIBRATION)
            {
                m_listCPDTypeImvs[i]->getGraphicsScene()->setBackgroundImageFile(IMAGE_CALIBRATION);
            } else if (testtype == STRING_PERFORMANCE) {
                m_listCPDTypeImvs[i]->getGraphicsScene()->setBackgroundImageFile(IMAGE_PERFORMANCE);
            } else if (testtype == STRING_DIAGNOSTICS) {
                m_listCPDTypeImvs[i]->getGraphicsScene()->setBackgroundImageFile(IMAGE_DIAGNOSTICS);
            }
            m_listCPDTypeLabels[i]->setText(testtype);
            m_listCPDDescriptionLabels[i]->setText(m_listCPD[j]->getDescription());
            ++j;
        } else {
            m_listCPDUCT[i]->setVisible(false);
        }
    }
}

void IGSxGUI::CPDView::onButtonPrevPressed()
{
    --m_currentPageNo;

    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    } else if (m_currentPageNo < m_numTotalPages) {
        sui->btnNext->setEnabled(true);
    }
    updatePaginationButtonTextOnPressed();
}

void IGSxGUI::CPDView::onButtonNextPressed()
{
    ++m_currentPageNo;

    if (m_currentPageNo == m_numTotalPages)
    {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    } else if (m_currentPageNo > 1) {
        sui->btnPrev->setEnabled(true);
    }
    updatePaginationButtonTextOnPressed();
}

void IGSxGUI::CPDView::updatePaginationButtonTextOnPressed()
{
    size_t paginationCount = 0;

    if (m_currentPageNo >= 4)            // Total clickable Button on single page is 4
    {
        paginationCount = m_currentPageNo - 4;
    }

    for (size_t i = 0; i < m_listDisplayButtons.size(); i++)
    {
        if (m_currentPageNo >= (boost::lexical_cast<int>(m_listDisplayButtons.size())))
        {
            m_listDisplayButtons[i]->setText(boost::lexical_cast<std::string>(i + paginationCount + 1));
            m_listDisplayButtons[i]->setEnabled(true);
        }
    }

    if (m_currentPageNo <= 6 &&  m_currentPageNo >= 0)
    {
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    } else {
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::modifyPrevNextButtons() const
{
    if (m_currentPageNo == 1)
    {
        sui->btnNext->setEnabled(true);
        sui->btnPrev->setEnabled(false);
    } else if (m_currentPageNo < m_numTotalPages) {
        sui->btnNext->setEnabled(true);
    }

    if (m_currentPageNo == m_numTotalPages) {
        sui->btnNext->setEnabled(false);
        sui->btnPrev->setEnabled(true);
    } else if (m_currentPageNo > 1) {
        sui->btnPrev->setEnabled(true);
    }
}

void IGSxGUI::CPDView::setNumberedButtonStyles(const int& nCurrentPage, const std::string &style) const
{
    sui->btnOne->setStyleSheetClass(STYLE_NORMAL);
    sui->btnTwo->setStyleSheetClass(STYLE_NORMAL);
    sui->btnThree->setStyleSheetClass(STYLE_NORMAL);
    sui->btnFour->setStyleSheetClass(STYLE_NORMAL);

    if (nCurrentPage == 1)
    {
        sui->btnOne->setStyleSheetClass(style);
    } else if (nCurrentPage == 2) {
        sui->btnTwo->setStyleSheetClass(style);
    } else if (nCurrentPage == 3) {
        sui->btnThree->setStyleSheetClass(style);
    } else if ((nCurrentPage >= 4) && (nCurrentPage <=6)) {
        sui->btnFour->setStyleSheetClass(style);
    }
}

void IGSxGUI::CPDView::configNavigationButtons(int buttonNumber)
{
    if (m_numTotalPages >= buttonNumber)
    {
        m_currentPageNo = buttonNumber;
        setNumberedButtonStyles(m_currentPageNo, STYLE_CURRENTPAGE);
    }
    modifyPrevNextButtons();
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::onButtonOnePressed()
{
    configNavigationButtons(1);
}

void IGSxGUI::CPDView::onButtonTwoPressed()
{
    configNavigationButtons(2);
}

void IGSxGUI::CPDView::onButtonThreePressed()
{
    configNavigationButtons(3);
}

void IGSxGUI::CPDView::onButtonFourPressed()
{
    configNavigationButtons(4);
}

void IGSxGUI::CPDView::viewHTMLReport()
{
    sui->gbxPageThree->setVisible(true);

    std::string strCPDHTMLFilePath;
    size_t noofCPDs = m_listCPD.size();
    for (size_t index = 0; index < noofCPDs; ++index)
    {
        if (m_listCPD[index]->getName() == m_selectedCPD)
        {
            if (m_listReportCollection.size() > 0)
            {
                strCPDHTMLFilePath =  m_listReportCollection[0];
                break;
            }
        }
    }

    std::fstream cpdhtmlfile;
    cpdhtmlfile.open(strCPDHTMLFilePath.c_str(), std::fstream::in);
    if (cpdhtmlfile.is_open())
    {
        std::stringstream buffer;
        buffer <<  cpdhtmlfile.rdbuf();
        std::string fullText = buffer.str();
        sui->wvwCPDReport->setHtml(fullText, "");
        cpdhtmlfile.close();
    }
}


void IGSxGUI::CPDView::onButtonViewReport1Pressed()
{
    viewHTMLReport();
}

void IGSxGUI::CPDView::onButtonViewReport2Pressed()
{
    viewHTMLReport();
}

void IGSxGUI::CPDView::onButtonViewReport3Pressed()
{
    viewHTMLReport();
}

void IGSxGUI::CPDView::onButtonViewReport4Pressed()
{
    viewHTMLReport();
}

void IGSxGUI::CPDView::onButtonBackPressed()
{
    sui->gbxPageThree->setVisible(false);
}

void IGSxGUI::CPDView::onActiveCPDShowButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    } else {
        sui->gbxReport->setVisible(true);
        sui->lblCPDDescDescription->setText(sui->lblName->getText());
        sui->lblCPDDescName1->setText(sui->lblName->getText());
        sui->lblCPDDescType1->setText(sui->lblType->getText());
        sui->txaCPDHPACDetail->clearText();
        sui->txaCPDHPACDetail->setText(sui->lblName->getText());
        sui->txaCPDHPACAttention->clearText();
        sui->txaCPDHPACAttention->setText(sui->lblType->getText());
    }
}

void IGSxGUI::CPDView::onWarningCloseButtonPressed()
{
    sui->gbxWarning->setVisible(false);
}

void IGSxGUI::CPDView::onWarningTimeout()
{
    sui->gbxWarning->setVisible(false);
}

void IGSxGUI::CPDView::onButtonTestReportPressed()
{
    sui->gbxPageOne->setVisible(false);
    sui->gbxPageTwo->setVisible(true);
    sui->tawShowReports->setVisible(false);
}

void IGSxGUI::CPDView::onSubsystemPressed()
{
    sui->gbxPageOne->setVisible(true);
    sui->gbxPageTwo->setVisible(false);

    std::list<std::string> items = sui->tawCPDSubsystem->getSelectedItems();
    std::string strSelectedRow = items.front();

    strSelectedRow.erase(0, 20);
    strSelectedRow.erase(strSelectedRow.size()-2, strSelectedRow.size());
    std::string selectedText = sui->tawCPDSubsystem->getItemText((boost::lexical_cast<int>(strSelectedRow)-1), 0);

    int position = selectedText.find('(');
    selectedText.erase(position, selectedText.size());
    boost::trim(selectedText);
    m_selectedSubSystem = selectedText;

    std::vector<CPD*> listSubsystemCPDs;

    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
         if ((found != std::string::npos) || (subsys.name == selectedText))
         {
             listSubsystemCPDs.push_back(subsys.cpd);
         }
    }
    intersectCPDs(getTestTypeCPDs(), listSubsystemCPDs);
    loadCPDs();
}


void IGSxGUI::CPDView::onShowReportsTableRowPressed(int row)
{
    if (!m_listReportCollection.empty())
    {
        sui->gbxPageThree->setVisible(true);
        std::fstream cpdhtmlfile;
        cpdhtmlfile.open(m_listReportCollection[row].c_str(), std::fstream::in);
        if (cpdhtmlfile.is_open())
        {
            std::stringstream buffer;
            buffer <<  cpdhtmlfile.rdbuf();
            std::string fullText = buffer.str();
            sui->wvwCPDReport->setHtml(fullText, "");
            cpdhtmlfile.close();
        }
    }
}

void IGSxGUI::CPDView::onButtonShowReportsPressed()
{
    m_listReportCollection.clear();
    // Get slected CPD Name
    std::list<std::string> selectedItems = sui->ddbSubsystem->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::string cpdname = selectedItems.front();
        CPD* currentCPD = NULL;
        currentCPD = m_presenter->getCPD(cpdname);
        if (currentCPD == NULL)
        {
            return;
        }
        // Get date and time from UI
        boost::shared_ptr<SUI::Time>  ui_startTime = sui->dtestarttimeEdit->getTime();
        boost::shared_ptr<SUI::Time>  ui_stopTime =  sui->dtestoptimeEdit->getTime();
        int startday = 0;
        int startmonth = 0;
        int startyear = 0;
        sui->dtestarttimeEdit->getDate(&startyear, &startmonth, &startday);
        int endday = 0;
        int endmonth = 0;
        int endyear = 0;
        sui->dtestoptimeEdit->getDate(&endyear, &endmonth, &endday);

        // Convert to time_t
        time_t startTimeToSearch = IGSxGUI::DateTime::DateTimeToTime_t(startday, startmonth, startday, ui_startTime);
        time_t stopTimeToSearch = IGSxGUI::DateTime::DateTimeToTime_t(endyear, endmonth, endday, ui_stopTime);

        IGSxCPD::TestResultList cpdTestResults;
        m_presenter->getCPDTestResults(cpdname, stopTimeToSearch, cpdTestResults);
        if (!cpdTestResults.empty())
        {
            time_t end_time = stopTimeToSearch;
            time_t start_time = startTimeToSearch;
            std::vector<IGSxCPD::TestResult> reportstodisplay;
            reportstodisplay.clear();
            for (size_t i = 0 ; i < cpdTestResults.size(); ++i)
            {
                if ((cpdTestResults[i].time() >=  start_time) && (cpdTestResults[i].time() <=  end_time))
                {
                    reportstodisplay.push_back(cpdTestResults[i]);
                }
            }
            std::sort(reportstodisplay.begin(), reportstodisplay.end(), TimeDescOrderComparator());
            size_t noofcpdTestResults = reportstodisplay.size();
            int x = sui->tawShowReports->rowCount();
            sui->tawShowReports->removeRows(1, x-1);
            sui->tawShowReports->insertRows(1, 1);
            sui->tawShowReports->removeRow(0);
            sui->tawShowReports->selectItem(-1);
            if (noofcpdTestResults > 0)
            {
              sui->tawShowReports->insertRows(1, noofcpdTestResults-1);
              sui->tawShowReports->showGrid(false);
              for (size_t i = 0; i < noofcpdTestResults; ++i)
              {
                  int8_t col = 0;
                  sui->tawShowReports->setItemText(i, col, currentCPD->getName());
                  sui->tawShowReports->setItemText(i, col + 1, currentCPD->getDescription());
                  sui->tawShowReports->setItemText(i, col + 2, currentCPD->getTestType());
                  sui->tawShowReports->setItemText(i, col + 3, boost::lexical_cast<std::string>(IGSxGUI::DateTime::formatTime(reportstodisplay[i].time(), STRING_DATETIME_FORMAT3)));
                  m_listReportCollection.push_back(reportstodisplay[i].htmlReport());
                  sui->tawShowReports->setItemText(i, col + 4, "View Report...");
              }
            } else {
                sui->tawShowReports->setItemText(0, 0, "");
                sui->tawShowReports->setItemText(0, 1, "");
                sui->tawShowReports->setItemText(0, 2, "");
                sui->tawShowReports->setItemText(0, 3, "");
                sui->tawShowReports->setItemText(0, 4, "No Reports");
            }
        }
    }
    sui->tawShowReports->setVisible(true);
}
void IGSxGUI::CPDView::onButtonMoreReportsPressed()
{
    std::list<std::string> itemlist = sui->ddbSubsystem->getItems();
    std::list<std::string>::iterator findIter = std::find(itemlist.begin(), itemlist.end(), m_moreReportsCPD);
    if (findIter != itemlist.end())
    {
        sui->ddbSubsystem->setCurrentIndex(std::distance(itemlist.begin(), findIter));
    }
    sui->gbxPageOne->setVisible(false);
    sui->gbxPageTwo->setVisible(true);

    std::list<std::string> selectedItems = sui->ddbSubsystem->getSelectedItems();
    if (selectedItems.size() == 1)
    {
        std::string cpdname = selectedItems.front();
        IGSxCPD::TestResultList cpdTestResults;
        time_t currentTime = time(NULL);
        m_presenter->getCPDTestResults(cpdname, currentTime, cpdTestResults);
        if (!cpdTestResults.empty())
        {
            std::sort(cpdTestResults.begin(), cpdTestResults.end(), TimeDescOrderComparator());
            size_t noofcpdTestResults = cpdTestResults.size();
            CPD* currentCPD = NULL;
            currentCPD = m_presenter->getCPD(cpdname);
            if (currentCPD == NULL)
            {
                return;
            }
            int x = sui->tawShowReports->rowCount();
            sui->tawShowReports->removeRows(1, x);
            sui->tawShowReports->insertRows(1, 1);
            sui->tawShowReports->removeRow(0);

            sui->tawShowReports->insertRows(1, noofcpdTestResults-1);
            sui->tawShowReports->showGrid(false);
            for (size_t i = 0; i < noofcpdTestResults; ++i)
            {
                int8_t col = 0;
                sui->tawShowReports->setItemText(i, col, currentCPD->getName());
                sui->tawShowReports->setItemText(i, col + 1, currentCPD->getDescription());
                sui->tawShowReports->setItemText(i, col + 2, currentCPD->getTestType());
                sui->tawShowReports->setItemText(i, col + 3, boost::lexical_cast<std::string>(IGSxGUI::DateTime::formatTime(cpdTestResults[i].time(), STRING_DATETIME_FORMAT3)));
                sui->tawShowReports->setItemText(i, col + 4, "View Report...");
            }
        }
     }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestCPDsByName(const std::string &testtypeName) const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    for (size_t i = 0 ; i < m_listTestTypes.size(); i++)
    {
         IGSxGUI::container testtype = m_listTestTypes[i];

         if (testtype.name == testtypeName)
         {
             listTestTypeCPDs.push_back(testtype.cpd);
         }
    }
    return listTestTypeCPDs;
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getSelectedSubSystemCPDs() const
{
    std::vector<IGSxGUI::CPD*> listSubsystemCPDs;
    for (size_t i = 0 ; i < m_listSubsystems.size(); i++)
    {
         container subsys = m_listSubsystems[i];

         std::size_t found = m_selectedSubSystem.find(STRING_ALL_CPDS);
         if ((found != std::string::npos) || (subsys.name == m_selectedSubSystem))
         {
             listSubsystemCPDs.push_back(subsys.cpd);
         }
    }
    return listSubsystemCPDs;
}

void IGSxGUI::CPDView::intersectCPDs(std::vector<IGSxGUI::CPD *> listTestTypeCPDs, std::vector<IGSxGUI::CPD *> listSubSystemCPDs)
{
    m_listCPD.clear();

    std::sort(listSubSystemCPDs.begin(), listSubSystemCPDs.end());
    std::sort(listTestTypeCPDs.begin(), listTestTypeCPDs.end());

    std::set_intersection(listSubSystemCPDs.begin(), listSubSystemCPDs.end(), listTestTypeCPDs.begin(), listTestTypeCPDs.end(), std::back_inserter(m_listCPD));

    if ((m_listCPD.size() <= 0) && sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    }
}

std::vector<IGSxGUI::CPD *> IGSxGUI::CPDView::getTestTypeCPDs() const
{
    std::vector<IGSxGUI::CPD*> listTestTypeCPDs;
    if (sui->rbtnAll->isChecked())
    {
        listTestTypeCPDs = m_presenter->getCPDs();
    } else if (sui->rbtnCalibration->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_CALIBRATION);
    } else if (sui->rbtnPerformance->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_PERFORMANCE);
    } else if (sui->rbtnDiagnostics->isChecked()) {
        listTestTypeCPDs = getTestCPDsByName(STRING_DIAGNOSTICS);
    }
    return listTestTypeCPDs;
}

void IGSxGUI::CPDView::onRadioButtonAllPressed()
{
  if (sui->rbtnAll->isChecked())
  {
    intersectCPDs(m_presenter->getCPDs(), getSelectedSubSystemCPDs());
    loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonCalibrationPressed()
{
  if (sui->rbtnCalibration->isChecked())
  {
      intersectCPDs(getTestCPDsByName(STRING_CALIBRATION), getSelectedSubSystemCPDs());
      loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonPerformancePressed()
{
  if (sui->rbtnPerformance->isChecked())
  {
      intersectCPDs(getTestCPDsByName(STRING_PERFORMANCE), getSelectedSubSystemCPDs());
      loadCPDs();
  }
}

void IGSxGUI::CPDView::onRadioButtonDiagnosticsPressed()
{
    if (sui->rbtnDiagnostics->isChecked())
    {
        intersectCPDs(getTestCPDsByName(STRING_DIAGNOSTICS), getSelectedSubSystemCPDs());
        loadCPDs();
    }
}

void IGSxGUI::CPDView::loadCPDs()
{
    m_numTotalPages = m_listCPD.size() / m_listCPDUCT.size();
    m_numLastPageItems = m_listCPD.size() % m_listCPDUCT.size();

    m_currentPageNo = 1;

    if ( m_numLastPageItems > 0 )
    {
        ++m_numTotalPages;
    }

    if (m_numTotalPages == 0)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(0, STYLE_NORMAL);
    }

    if (m_numTotalPages == 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(false);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    if (m_numTotalPages > 1)
    {
        sui->btnPrev->setEnabled(false);
        sui->btnNext->setEnabled(true);
        setNumberedButtonStyles(1, STYLE_CURRENTPAGE);
    }

    initNumberedButtons(m_numTotalPages);
    fetchCPDs(m_currentPageNo);
}

void IGSxGUI::CPDView::setActive(bool bActive)
{
    if (bActive)
    {
        m_presenter->subscribeForEvents();
    } else {
        m_presenter->unsubscribeForEvents();
    }
}

void IGSxGUI::CPDView::updateStatus(const std::string& /*strCPD*/, const IGS::Result& result)
{
    if (result == IGS::OK)
    {
        m_bRunningCPD = false;

        sui->gbxCPD->setBGColor(SUI::ColorEnum::White);
        sui->lblDescription->setStyleSheetClass(STYLE_NO_ACTIVE_CPD);
        sui->lblDescription->setText(STRING_NO_ACTIVE_CPD);
        sui->lblType->setVisible(false);
        sui->lblName->setVisible(false);
        sui->lblStatus->setVisible(false);
        sui->btnShowCPD->setVisible(false);
        sui->btnCPDInfo->setVisible(false);
    }
}

void IGSxGUI::CPDView::startCPD(const std::string &cpdName, const std::string &cpdType)
{
    if (!m_bRunningCPD)
    {
        if (m_presenter->startCPD(cpdName))
        {
           m_bRunningCPD = true;

           sui->gbxCPD->setBGColor(SUI::ColorEnum::Blue);
           sui->lblDescription->setStyleSheetClass(STYLE_ACTIVE_CPD);
           sui->lblDescription->setText(STRING_ACTIVE_CPD);
           sui->lblName->setVisible(true);
           sui->lblName->setText(cpdName);
           sui->lblType->setVisible(true);
           sui->lblType->setText(cpdType);
           sui->lblStatus->setVisible(true);
           sui->btnShowCPD->setVisible(true);
           sui->btnCPDInfo->setVisible(true);
        }
    } else {
        sui->gbxWarning->setBGColor(SUI::ColorEnum::Blue);
        sui->gbxWarning->setVisible(true);
        m_timer->start(TIMER_INTERVAL);
    }
}

void IGSxGUI::CPDView::onButtonCPD1StartPressed()
{
    startCPD(sui->lblCPD1Name->getText(), sui->lblCPD1Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD2StartPressed()
{
    startCPD(sui->lblCPD2Name->getText(), sui->lblCPD2Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD3StartPressed()
{
    startCPD(sui->lblCPD3Name->getText(), sui->lblCPD3Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD4StartPressed()
{
    startCPD(sui->lblCPD4Name->getText(), sui->lblCPD4Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD5StartPressed()
{
    startCPD(sui->lblCPD5Name->getText(), sui->lblCPD5Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD6StartPressed()
{
    startCPD(sui->lblCPD6Name->getText(), sui->lblCPD6Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD7StartPressed()
{
    startCPD(sui->lblCPD7Name->getText(), sui->lblCPD7Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD8StartPressed()
{
    startCPD(sui->lblCPD8Name->getText(), sui->lblCPD8Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD9StartPressed()
{
    startCPD(sui->lblCPD9Name->getText(), sui->lblCPD9Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD10StartPressed()
{
    startCPD(sui->lblCPD10Name->getText(), sui->lblCPD10Type->getText());
}

void IGSxGUI::CPDView::setInfoButtonStyles()
{
    for (size_t i=0; i < m_listInfoButtons.size(); i++)
    {
        m_listInfoButtons[i]->setStyleSheetClass(STYLE_CPDINFO);
    }
}

void IGSxGUI::CPDView::showCPDReportPage(int nCurrentItem, SUI::Button *btnCPDInfo, const std::string &cpdDescription, const std::string &cpdTestName, const std::string &cpdTestType)
{
    if (m_nPreviousDetailItem == nCurrentItem)
    {
        if (sui->gbxReport->isVisible())
        {
            sui->gbxReport->setVisible(false);
            btnCPDInfo->setStyleSheetClass(STYLE_CPDINFO);
        } else {
            sui->gbxReport->setVisible(true);
            btnCPDInfo->setStyleSheetClass(STYLE_CURRENTPAGE);
        }
    } else {
        setInfoButtonStyles();
        btnCPDInfo->setStyleSheetClass(STYLE_CURRENTPAGE);
        displayCPDDetails(cpdDescription, cpdTestName, cpdTestType);
        m_selectedCPD = cpdTestName;
        m_nPreviousDetailItem = nCurrentItem;
    }
}

void IGSxGUI::CPDView::onButtonCPD1DetailPressed()
{
    showCPDReportPage(1, sui->btnCPD1Info, sui->lblCPD1Description->getText(), sui->lblCPD1Name->getText(), sui->lblCPD1Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD2DetailPressed()
{
    showCPDReportPage(2, sui->btnCPD2Info, sui->lblCPD2Description->getText(), sui->lblCPD2Name->getText(), sui->lblCPD2Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD3DetailPressed()
{
    showCPDReportPage(3, sui->btnCPD3Info, sui->lblCPD3Description->getText(), sui->lblCPD3Name->getText(), sui->lblCPD3Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD4DetailPressed()
{
    showCPDReportPage(4, sui->btnCPD4Info, sui->lblCPD4Description->getText(), sui->lblCPD4Name->getText(), sui->lblCPD4Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD5DetailPressed()
{
    showCPDReportPage(5, sui->btnCPD5Info, sui->lblCPD5Description->getText(), sui->lblCPD5Name->getText(), sui->lblCPD5Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD6DetailPressed()
{
    showCPDReportPage(6, sui->btnCPD6Info, sui->lblCPD6Description->getText(), sui->lblCPD6Name->getText(), sui->lblCPD6Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD7DetailPressed()
{
    showCPDReportPage(7, sui->btnCPD7Info, sui->lblCPD7Description->getText(), sui->lblCPD7Name->getText(), sui->lblCPD7Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD8DetailPressed()
{
    showCPDReportPage(8, sui->btnCPD8Info, sui->lblCPD8Description->getText(), sui->lblCPD8Name->getText(), sui->lblCPD8Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD9DetailPressed()
{
    showCPDReportPage(9, sui->btnCPD9Info, sui->lblCPD9Description->getText(), sui->lblCPD9Name->getText(), sui->lblCPD9Type->getText());
}

void IGSxGUI::CPDView::onButtonCPD10DetailPressed()
{
    showCPDReportPage(10, sui->btnCPD10Info, sui->lblCPD10Description->getText(), sui->lblCPD10Name->getText(), sui->lblCPD10Type->getText());
}

void IGSxGUI::CPDView::loadContainers()
{
    m_listCPDUCT.clear();
    m_listCPDNameLabels.clear();
    m_listCPDTypeLabels.clear();
    m_listCPDTypeImvs.clear();
    m_listCPDDescriptionLabels.clear();
    m_listCPDTimeLabels.clear();
    m_listDisplayButtons.clear();
    m_listInfoButtons.clear();
    m_listCPDReportGroupBox.clear();
    m_listCPDReportNameLabels.clear();
    m_listCPDReportTypeLabels.clear();
    m_listCPDReportDescriptionLabels.clear();
    m_listCPDReportTimeLabels.clear();
    m_listCPDDescTimeLabels.clear();
    m_listCPDViewReportButtons.clear();

    m_listCPDUCT.push_back(sui->uctCPD1);
    m_listCPDUCT.push_back(sui->uctCPD2);
    m_listCPDUCT.push_back(sui->uctCPD3);
    m_listCPDUCT.push_back(sui->uctCPD4);
    m_listCPDUCT.push_back(sui->uctCPD5);
    m_listCPDUCT.push_back(sui->uctCPD6);
    m_listCPDUCT.push_back(sui->uctCPD7);
    m_listCPDUCT.push_back(sui->uctCPD8);
    m_listCPDUCT.push_back(sui->uctCPD9);
    m_listCPDUCT.push_back(sui->uctCPD10);

    m_listCPDNameLabels.push_back(sui->lblCPD1Name);
    m_listCPDNameLabels.push_back(sui->lblCPD2Name);
    m_listCPDNameLabels.push_back(sui->lblCPD3Name);
    m_listCPDNameLabels.push_back(sui->lblCPD4Name);
    m_listCPDNameLabels.push_back(sui->lblCPD5Name);
    m_listCPDNameLabels.push_back(sui->lblCPD6Name);
    m_listCPDNameLabels.push_back(sui->lblCPD7Name);
    m_listCPDNameLabels.push_back(sui->lblCPD8Name);
    m_listCPDNameLabels.push_back(sui->lblCPD9Name);
    m_listCPDNameLabels.push_back(sui->lblCPD10Name);

    m_listCPDTypeLabels.push_back(sui->lblCPD1Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD2Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD3Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD4Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD5Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD6Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD7Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD8Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD9Type);
    m_listCPDTypeLabels.push_back(sui->lblCPD10Type);

    m_listCPDTypeImvs.push_back(sui->imvCPD1Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD2Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD3Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD4Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD5Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD6Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD7Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD8Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD9Type);
    m_listCPDTypeImvs.push_back(sui->imvCPD10Type);

    m_listCPDDescriptionLabels.push_back(sui->lblCPD1Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD2Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD3Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD4Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD5Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD6Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD7Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD8Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD9Description);
    m_listCPDDescriptionLabels.push_back(sui->lblCPD10Description);

    m_listCPDTimeLabels.push_back(sui->lblCPD1Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD2Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD3Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD4Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD5Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD6Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD7Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD8Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD9Time);
    m_listCPDTimeLabels.push_back(sui->lblCPD10Time);

    m_listDisplayButtons.push_back(sui->btnOne);
    m_listDisplayButtons.push_back(sui->btnTwo);
    m_listDisplayButtons.push_back(sui->btnThree);
    m_listDisplayButtons.push_back(sui->btnFour);

    m_listInfoButtons.push_back(sui->btnCPD1Info);
    m_listInfoButtons.push_back(sui->btnCPD2Info);
    m_listInfoButtons.push_back(sui->btnCPD3Info);
    m_listInfoButtons.push_back(sui->btnCPD4Info);
    m_listInfoButtons.push_back(sui->btnCPD5Info);
    m_listInfoButtons.push_back(sui->btnCPD6Info);
    m_listInfoButtons.push_back(sui->btnCPD7Info);
    m_listInfoButtons.push_back(sui->btnCPD8Info);
    m_listInfoButtons.push_back(sui->btnCPD9Info);
    m_listInfoButtons.push_back(sui->btnCPD10Info);

    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView1);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView2);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView3);
    m_listCPDReportGroupBox.push_back(sui->gbxCPDReportView4);

    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest1);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest2);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest3);
    m_listCPDReportNameLabels.push_back(sui->lblCPDReportTest4);

    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType1);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType2);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType3);
    m_listCPDReportTypeLabels.push_back(sui->lblCPDReportType4);

    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc1);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc2);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc3);
    m_listCPDReportDescriptionLabels.push_back(sui->lblCPDReportDesc4);

    m_listCPDReportTimeLabels.push_back(sui->lblCPDReportDate1);
    m_listCPDReportTimeLabels.push_back(sui->lblCPDReportDate2);
    m_listCPDReportTimeLabels.push_back(sui->lblCPDReportDate3);
    m_listCPDReportTimeLabels.push_back(sui->lblCPDReportDate4);

    m_listCPDDescTimeLabels.push_back(sui->lblCPDDescTime1);
    m_listCPDDescTimeLabels.push_back(sui->lblCPDDescTime2);
    m_listCPDDescTimeLabels.push_back(sui->lblCPDDescTime3);
    m_listCPDDescTimeLabels.push_back(sui->lblCPDDescTime4);

    m_listCPDViewReportButtons.push_back(sui->btnViewReport1);
    m_listCPDViewReportButtons.push_back(sui->btnViewReport2);
    m_listCPDViewReportButtons.push_back(sui->btnViewReport3);
    m_listCPDViewReportButtons.push_back(sui->btnViewReport4);
}

void IGSxGUI::CPDView::loadTestTypes()
{
    container testtype;
    for (size_t i = 0 ; i < m_listCPD.size(); i++)
    {
        testtype.name = m_listCPD[i]->getTestType();
        testtype.cpd = m_listCPD[i];
        m_listTestTypes.push_back(testtype);
    }
}

void IGSxGUI::CPDView::loadSubSystems()
{
    m_listSubsystemCount.clear();
    m_listSubsystems.clear();
    std::vector<std::string> listStringSubsystem;
    container subsystem;
    for (size_t i = 0; i < m_listSubsystemCPDs.size(); i++)
    {
        subsystem.name = m_listSubsystemCPDs[i]->getSubsystem();
        subsystem.cpd = m_listSubsystemCPDs[i];
        listStringSubsystem.push_back(m_listSubsystemCPDs[i]->getSubsystem());
        m_listSubsystems.push_back(subsystem);
    }

    sort(listStringSubsystem.begin(), listStringSubsystem.end());
    listStringSubsystem.erase(unique(listStringSubsystem.begin(), listStringSubsystem.end()), listStringSubsystem.end());

    for (size_t i = 0 ; i < listStringSubsystem.size(); i++)
    {
        int count = 0;
        subSystemCount subsyscount;
        for (size_t j = 0 ; j < m_listSubsystems.size(); j++)
        {
            container subsystem = m_listSubsystems[j];

            if (listStringSubsystem[i] == subsystem.name)
            {
                ++count;
            }
        }
        subsyscount.nameSubsystem = listStringSubsystem[i];
        subsyscount.count = count;

        m_listSubsystemCount.push_back(subsyscount);
    }

    std::list<std::string> listTestReportSubSystemItems;
    std::string strAllCPDs =  sui->tawCPDSubsystem->getItemText(0, 0) + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(m_listSubsystemCPDs.size()) + STRING_CLOSE_BRACKET;
    sui->tawCPDSubsystem->setItemText(0, 0, strAllCPDs);
    listTestReportSubSystemItems.push_back(strAllCPDs);

    for (size_t i = 0; i < m_listSubsystemCount.size(); i++)
    {
        subSystemCount subsyscount = m_listSubsystemCount[i];

        std::string subsys = subsyscount.nameSubsystem + STRING_OPEN_BRACKET + boost::lexical_cast<std::string>(subsyscount.count) + STRING_CLOSE_BRACKET;

        listTestReportSubSystemItems.push_back(subsys);

        sui->tawCPDSubsystem->insertRows(i+1, 1);
        sui->tawCPDSubsystem->setItemText(i+1, 0, STRING_SPACE + subsys);
    }

    std::list<std::string> cpdnamelist;
    for (size_t i = 0; i < m_listCPD.size(); ++i)
    {
      cpdnamelist.push_back(m_listCPD[i]->getName());
    }

    sui->ddbSubsystem->addItems(cpdnamelist);
    sui->ddbSubsystem->selectItem(1);
    sui->tawCPDSubsystem->selectItem(0);
}

void IGSxGUI::CPDView::setHandlers()
{
    sui->btnShowCPD->clicked     = boost::bind(&CPDView::onActiveCPDShowButtonPressed, this);
    sui->btnCPDInfo->clicked   = boost::bind(&CPDView::onActiveCPDDetailButtonPressed, this);
    sui->rbtnAll->checkStateChanged = boost::bind(&CPDView::onRadioButtonAllPressed, this);
    sui->rbtnCalibration->checkStateChanged = boost::bind(&CPDView::onRadioButtonCalibrationPressed, this);
    sui->rbtnPerformance->checkStateChanged = boost::bind(&CPDView::onRadioButtonPerformancePressed, this);
    sui->rbtnDiagnostics->checkStateChanged = boost::bind(&CPDView::onRadioButtonDiagnosticsPressed, this);

    sui->btnCPD1Start->clicked    = boost::bind(&CPDView::onButtonCPD1StartPressed, this);
    sui->btnCPD2Start->clicked    = boost::bind(&CPDView::onButtonCPD2StartPressed, this);
    sui->btnCPD3Start->clicked    = boost::bind(&CPDView::onButtonCPD3StartPressed, this);
    sui->btnCPD4Start->clicked    = boost::bind(&CPDView::onButtonCPD4StartPressed, this);
    sui->btnCPD5Start->clicked    = boost::bind(&CPDView::onButtonCPD5StartPressed, this);
    sui->btnCPD6Start->clicked    = boost::bind(&CPDView::onButtonCPD6StartPressed, this);
    sui->btnCPD7Start->clicked    = boost::bind(&CPDView::onButtonCPD7StartPressed, this);
    sui->btnCPD8Start->clicked    = boost::bind(&CPDView::onButtonCPD8StartPressed, this);
    sui->btnCPD9Start->clicked    = boost::bind(&CPDView::onButtonCPD9StartPressed, this);
    sui->btnCPD10Start->clicked    = boost::bind(&CPDView::onButtonCPD10StartPressed, this);

    sui->btnCPD1Info->clicked    = boost::bind(&CPDView::onButtonCPD1DetailPressed, this);
    sui->btnCPD2Info->clicked    = boost::bind(&CPDView::onButtonCPD2DetailPressed, this);
    sui->btnCPD3Info->clicked    = boost::bind(&CPDView::onButtonCPD3DetailPressed, this);
    sui->btnCPD4Info->clicked    = boost::bind(&CPDView::onButtonCPD4DetailPressed, this);
    sui->btnCPD5Info->clicked    = boost::bind(&CPDView::onButtonCPD5DetailPressed, this);
    sui->btnCPD6Info->clicked    = boost::bind(&CPDView::onButtonCPD6DetailPressed, this);
    sui->btnCPD7Info->clicked    = boost::bind(&CPDView::onButtonCPD7DetailPressed, this);
    sui->btnCPD8Info->clicked    = boost::bind(&CPDView::onButtonCPD8DetailPressed, this);
    sui->btnCPD9Info->clicked    = boost::bind(&CPDView::onButtonCPD9DetailPressed, this);
    sui->btnCPD10Info->clicked    = boost::bind(&CPDView::onButtonCPD10DetailPressed, this);

    sui->btnPrev->clicked    = boost::bind(&CPDView::onButtonPrevPressed, this);
    sui->btnNext->clicked    = boost::bind(&CPDView::onButtonNextPressed, this);
    sui->btnOne->clicked    = boost::bind(&CPDView::onButtonOnePressed, this);
    sui->btnTwo->clicked    = boost::bind(&CPDView::onButtonTwoPressed, this);
    sui->btnThree->clicked    = boost::bind(&CPDView::onButtonThreePressed, this);
    sui->btnFour->clicked    = boost::bind(&CPDView::onButtonFourPressed, this);
    sui->btnTestReport->clicked    = boost::bind(&CPDView::onButtonTestReportPressed, this);
    sui->btnMoreReports->clicked = boost::bind(&CPDView::onButtonMoreReportsPressed, this);
    sui->btnShowReports->clicked    = boost::bind(&CPDView::onButtonShowReportsPressed, this);

    sui->btnViewReport1->clicked    = boost::bind(&CPDView::onButtonViewReport1Pressed, this);
    sui->btnViewReport2->clicked    = boost::bind(&CPDView::onButtonViewReport2Pressed, this);
    sui->btnViewReport3->clicked    = boost::bind(&CPDView::onButtonViewReport3Pressed, this);
    sui->btnViewReport4->clicked    = boost::bind(&CPDView::onButtonViewReport4Pressed, this);
    sui->btnBack->clicked    = boost::bind(&CPDView::onButtonBackPressed, this);

    sui->tawCPDSubsystem->rowClicked = boost::bind(&CPDView::onSubsystemPressed, this);
    sui->tawShowReports->rowClicked = boost::bind(&CPDView::onShowReportsTableRowPressed, this, _1);

    m_timer->timeout = boost::bind(&CPDView::onWarningTimeout, this);
    sui->btnWarningClose->clicked = boost::bind(&CPDView::onWarningCloseButtonPressed, this);
}


void IGSxGUI::CPDView::displayCPDDetails(const std::string &/*cpdDescription*/, const std::string &cpdTestName, const std::string &cpdTestType)
{
    m_listReportCollection.clear();
    m_moreReportsCPD = cpdTestName;
    sui->gbxReport->setVisible(true);
    for (size_t i = 0; i < 4; ++i)
    {
        m_listCPDDescTimeLabels[i]->setVisible(false);
        m_listCPDViewReportButtons[i]->setVisible(false);
    }
    sui->btnMoreReports->setVisible(true);
    sui->txaCPDHPACDetail->clearText();
    sui->txaCPDHPACDetail->setText(cpdTestName);
    sui->txaCPDHPACAttention->clearText();
    sui->txaCPDHPACAttention->setText(cpdTestType);

         IGSxCPD::TestResultList  cpdTestResults;
         time_t currentTime = time(NULL);
         m_presenter->getCPDTestResults(cpdTestName, currentTime, cpdTestResults);
        if (!cpdTestResults.empty())
        {
            time_t end_time = time(NULL);
            time_t start_time = end_time - (2 * 24 * 3600);
            std::vector<IGSxCPD::TestResult> twodaysreportonly;
            twodaysreportonly.clear();
            for (size_t i = 0 ; i < cpdTestResults.size(); ++i)
            {
                if ((cpdTestResults[i].time() >=  start_time) && (cpdTestResults[i].time() <=  end_time))
                {
                    twodaysreportonly.push_back(cpdTestResults[i]);
                }
            }
            std::sort(twodaysreportonly.begin(), twodaysreportonly.end(), TimeDescOrderComparator());
            size_t noofcpdTestResults = twodaysreportonly.size();
            sui->lblCPDDescName1->setText(cpdTestName);
            sui->lblCPDDescType1->setText(cpdTestType);
            if ( noofcpdTestResults > 4 )
            {
                sui->btnMoreReports->setVisible(true);
            }
            for (size_t i = 0; i < 4; ++i)
            {
                m_listCPDDescTimeLabels[i]->setVisible(true);
                m_listCPDViewReportButtons[i]->setVisible(true);
                m_listReportCollection.push_back(twodaysreportonly[i].htmlReport());
                if (i == 0)
                {
                    m_listCPDDescTimeLabels[i]->setText(boost::lexical_cast<std::string>("Last run: " + IGSxGUI::DateTime::formatTime(twodaysreportonly[i].time(), STRING_DATETIME_FORMAT3)));
                } else {
                    m_listCPDDescTimeLabels[i]->setText(boost::lexical_cast<std::string>(IGSxGUI::DateTime::formatTime(twodaysreportonly[i].time(), STRING_DATETIME_FORMAT3)));
                }
            }
        }
}

void IGSxGUI::CPDView::onActiveCPDDetailButtonPressed()
{
    if (sui->gbxReport->isVisible())
    {
        sui->gbxReport->setVisible(false);
    } else {
        sui->gbxReport->setVisible(true);
        sui->lblCPDDescDescription->setText(sui->lblName->getText());
        sui->lblCPDDescName1->setText(sui->lblName->getText());
        sui->lblCPDDescType1->setText(sui->lblType->getText());
        sui->txaCPDHPACDetail->clearText();
        sui->txaCPDHPACDetail->setText(sui->lblName->getText());
        sui->txaCPDHPACAttention->clearText();
        sui->txaCPDHPACAttention->setText(sui->lblType->getText());
    }
}

