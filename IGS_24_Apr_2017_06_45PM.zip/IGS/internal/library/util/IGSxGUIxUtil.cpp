/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxUtil.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation file for Utility class
|
| ! \file        IGSxGUIxUtil.cpp
| ! \brief       Implementation file for Utility class
|
|-----------------------------------------------------------------------------|
|                                                                             |
|                Copyright (c) 2017, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxUtil.hpp"
#include <QDialog>
#include <QWidget>
#include <QScrollArea>
#include <QApplication>
#include <QFontMetrics>

#include <SUIWidget.h>
#include <SUIDialog.h>
#include <SUIBaseWidget.h>
#include <string>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
IGSxGUI::Util::Util()
{
}

void IGSxGUI::Util::setGeometry(SUI::Widget* widget, int x, int y, int width, int height)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    QWidget* qparent = qwidget->parentWidget();

    if (qwidget != NULL)
    {
        qwidget->setGeometry(x, qparent->y() + y, width, height);
    }
}

void IGSxGUI::Util::setWindowFrame(SUI::Dialog* dialog, bool enable)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);

    if (qdialog != NULL)
    {
        if (enable)
        {
            qdialog->setWindowFlags(Qt::Dialog);
        } else {
            qdialog->setWindowFlags(Qt::Sheet | Qt::FramelessWindowHint);
            qdialog->setFixedSize(qdialog->geometry().size());
        }
    }
}

void IGSxGUI::Util::disableScrollbars(SUI::Dialog* dialog)
{
    QDialog* qdialog = dynamic_cast<QDialog*>(dialog);
    if (qdialog != NULL)
    {
        QScrollArea* scrollArea = qdialog->findChild<QScrollArea*>("");

        if (scrollArea != NULL)
        {
            scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
            scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
        }
    }
}

void IGSxGUI::Util::setParent(SUI::Widget* widget, SUI::Widget *parent)
{
    QWidget* qwidget = dynamic_cast<QWidget*>(widget);
    SUI::BaseWidget* suiparent = dynamic_cast<SUI::BaseWidget*>(parent);

    QWidget* topWidget = suiparent->getWidget()->nativeParentWidget();
    qwidget->setParent(topWidget);
}

void IGSxGUI::Util::processEvents(){
    QApplication::processEvents();
}

const std::string IGSxGUI::Util::elideText(const std::string& str, int fontsize, int width)
{
    std::string elidedtext = str;
    if ((width > 0) && (!str.empty()))
    {
           QFont font("Roboto", fontsize);
           QFontMetrics fm(font);
           QString intext(str.c_str());
           QString outtext = fm.elidedText(intext, Qt::ElideRight, width);

           // To do , last char is not printable char('...')
           QChar ch = outtext.at(outtext.length() - 1);
           if (!ch.toAscii())
           {
           outtext.chop(4);
           elidedtext = outtext.toStdString() + "...";
           } else {
              elidedtext = outtext.toStdString();
           }
    }
    return elidedtext;
}
