/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxSystemDateTime.cpp
| Author       : Raja A
| Description  : System Date Time Implementation
|
| ! \file        IGSxGUIxSystemDateTime.cpp
| ! \brief       System Date Time Implementation
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxSystemDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::SystemDateTime::getSystemCurrentDateTime(const SystemDateTime::eSystemDateTime& strname)
{
    time_t     now = time(0);
    struct tm  tstruct;
    char       buf[CONVERSION_BUFFER_SIZE];
    tstruct = *localtime_r(&now, &tstruct);
    std::string currenttime = "";
    if (strname == SystemDateTime::STR_TIME)
    {
        strftime(buf, sizeof(buf), STRING_TIME_FORMAT.c_str(), &tstruct);
        currenttime = buf;
    } else if (strname == SystemDateTime::STR_DATE) {
        strftime(buf, sizeof(buf), STRING_DATE_FORMAT.c_str(), &tstruct);
        currenttime = buf;
    }else if (strname == SystemDateTime::STR_DATE_TIME) {
        strftime(buf, sizeof(buf), STRING_DATETIME_FORMAT.c_str(), &tstruct);
        currenttime = buf;
    }
    return currenttime;
}
