/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Interface File                               |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxIAnalysis.hpp
| Author       : Venugopal S
| Description  : Interface file for Analysis plugin
|
| ! \file        IGSxGUIxIAnalysis.hpp
| ! \brief       Interface file for Analysis plugin
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXIANALYSIS_HPP
#define IGSXGUIXIANALYSIS_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <SUIContainer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace IGSxGUI{
class IAnalysis
{
 public:
    IAnalysis() {}
    virtual ~IAnalysis() {}
    virtual void show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void showADT(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void setActive(bool bActive) = 0;
    virtual void showEventViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
    virtual void showAlertViewer(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay) = 0;
};
}  // namespace IGSxGUI
#endif  // IGSXGUIXIANALYSIS_HPP
