/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.hpp
| Author       : Raja A
| Description  : Header file for Alertview
|
| ! \file        IGSxGUIxAlertView.hpp
| ! \brief       Header file for Alertview
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/
#ifndef IGSXGUIXALERTVIEW_HPP
#define IGSXGUIXALERTVIEW_HPP
/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxIAlertView.hpp"
#include <SUIDialog.h>
#include <SUITimer.h>
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
namespace SUI {
class AlertView;
class Dialog;
class ObjectList;
class Timer;


}  // namespace SUI

namespace IGSxGUI{

class AlertView : public IAlertView
{
 public:
    explicit AlertView();
    virtual ~AlertView();
    virtual void show(SUI::Container* MainScreenContainer, bool);
    virtual void updateStatus(const IGS::Result& result);
    virtual void setActive(bool bActive);
    void onTimeout();

 private:
    AlertView(const AlertView &);
    AlertView& operator=(const AlertView &);
    SUI::AlertView *sui;
    boost::shared_ptr<SUI::Timer> m_timer;
    bool m_alarmcolorflag;
    static const std::string ALERTVIEW_LOAD_FILE;


};
}  // namespace IGSxGUI
#endif // IGSXGUIXALERTVIEW_HPP
