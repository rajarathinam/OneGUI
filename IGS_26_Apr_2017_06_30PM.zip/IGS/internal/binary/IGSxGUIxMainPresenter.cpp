/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainPresenter.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application Presenter
|
| ! \file        IGSxGUIxMainPresenter.cpp
| ! \brief       Implementation of Main application Presenter
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxMainPresenter.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MainPresenter::STRING_DATETIME_FORMAT1 = "%H:%M%p";
const std::string IGSxGUI::MainPresenter::STRING_DATETIME_FORMAT2 = "%d/%m/%Y";
const int IGSxGUI::MainPresenter::CONVERSION_BUFFER_SIZE = 80;

IGSxGUI::MainPresenter::~MainPresenter()
{
    // Do not delete m_view, we are not the owner.
}

void IGSxGUI::MainPresenter::OnErrorStateChange(const std::string& eMsg)
{
    m_view->showError(eMsg, getTimeStamp());
}

IGSxGUI::MainPresenter::MainPresenter(IGSxGUI::IMainView* view)
{
    if (view != NULL)
    {
        m_view = view;
    }
}

std::string IGSxGUI::MainPresenter::getTimeStamp() const
{
    return SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE_TIME);
}
