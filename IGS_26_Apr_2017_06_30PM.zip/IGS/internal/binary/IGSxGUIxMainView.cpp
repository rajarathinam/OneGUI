/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMainView.cpp
| Author       : Arjan Tekelenburg
| Description  : Implementation of Main application view
|
| ! \file        IGSxGUIxMainView.cpp
| ! \brief       Implementation of Main application view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                            |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMainView.hpp"
#include <boost/bind.hpp>
#include <string>
#include "IGSxGUIxMoc_MainView.hpp"
#include "IGSxGUIxPluginFactory.hpp"
#include "IGSxCOMMON.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include <SUIDialog.h>
#include <SUIButton.h>
#include <SUIGroupBox.h>
#include <SUILabel.h>
#include <SUIUserControl.h>
#include <SUIGraphicsView.h>
#include <SUIGraphicsScene.h>
#include <SUIBusyIndicator.h>
#include <SUITimer.h>
#include "IGSxGUIxUtil.hpp"
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::MainView::MAINVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxMainView.xml");
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_SYSTEM = "System";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_DASHBOARD = "Dashboard";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ANALYSIS = "Analysis";
const std::string IGSxGUI::MainView::NAVIGATION_BUTTON_ERRORALARM = "ALARM";

const std::string IGSxGUI::MainView::IMAGE_WHITE_SYSTEM = IGS::Resource::path("IGSxGUIxMain_WHITE_System.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_DASHBOARD = IGS::Resource::path("IGSxGUIxMain_WHITE_Dashboard.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_ANALYSIS = IGS::Resource::path("IGSxGUIxMain_WHITE_Analysis.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_WARNING = IGS::Resource::path("IGSxGUIxMain_WHITE_Warning.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_CLOCK = IGS::Resource::path("IGSxGUIxMain_WHITE_Clock.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_INFO = IGS::Resource::path("IGSxGUIxMain_WHITE_Info.png");
const std::string IGSxGUI::MainView::IMAGE_WHITE_CHECKCIRCLE = IGS::Resource::path("IGSxGUIxMain_WHITE_CheckCircle.png");

const std::string IGSxGUI::MainView::IMAGE_BLUE_SYSTEM = IGS::Resource::path("IGSxGUIxMain_BLUE_System.png");
const std::string IGSxGUI::MainView::IMAGE_BLUE_DASHBOARD = IGS::Resource::path("IGSxGUIxMain_BLUE_Dashboard.png");
const std::string IGSxGUI::MainView::IMAGE_BLUE_ANALYSIS = IGS::Resource::path("IGSxGUIxMain_BLUE_Analysis.png");

const std::string IGSxGUI::MainView::IMAGE_GREEN_CHECKCIRCLE = IGS::Resource::path("IGSxGUIxMain_GREEN_CheckCircle.png");
const std::string IGSxGUI::MainView::IMAGE_RED_WARNING_16PX = IGS::Resource::path("IGSxGUIxMain_RED_Warning_16px.png");

const std::string IGSxGUI::MainView::STRING_INITIALIZED = "INITIALIZED";
const std::string IGSxGUI::MainView::STRING_TERMINATED = "TERMINATED";
const std::string IGSxGUI::MainView::STRING_PARTIALLY_INITIALIZED = "PARTIALLY..";
const std::string IGSxGUI::MainView::STRING_RECOVERY_REQUIRED = "RECOVERY...";

const std::string IGSxGUI::MainView::STRING_DATE_TIME = "Date & time";

const std::string IGSxGUI::MainView::STYLE_HOVER_ON = "hoverOn";
const std::string IGSxGUI::MainView::STYLE_HOVER_OFF = "hoverOff";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_ON = "hoverOnAlarmButton";
const std::string IGSxGUI::MainView::STYLE_ERROR_ALARM_HOVER_OFF = "hoverOffAlarmButton";

const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU1_BUTTON = "System initialization";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU2_BUTTON = "System state manager";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU3_BUTTON = "Hardware reset";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU4_BUTTON = "Maintenance";
const std::string IGSxGUI::MainView::STRING_SYSTEM_SUBMENU5_BUTTON = "Service";

const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU1_BUTTON  = "Data View";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU2_BUTTON  = "Safety Diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU3_BUTTON  = "Advanced diagnostics";
const std::string IGSxGUI::MainView::STRING_ANALYSIS_SUBMENU4_BUTTON  = "Event Log";

const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_CLICKED  = "subSystemClciked";
const std::string IGSxGUI::MainView::STYLE_MENU_BUTTON_NORMAL  = "subSystemText";

const int IGSxGUI::MainView::TIMER_INTERVAL = 1000;
const int IGSxGUI::MainView::TIMER_RESTART_INTERVAL = 60000;
const int IGSxGUI::MainView::CONVERSION_BUFFER_SIZE = 80;

IGSxGUI::MainView::MainView() :
    NavigationButton(BTN_SYSTEM),
    sui(new SUI::MainView),
    m_iSystem(NULL),
    m_iDashboard(NULL),
    m_iAnalysis(NULL),
    m_timer(SUI::Timer::createTimer()),
    m_bInitializeEventLog(true)
{
    if (sui != NULL)
    {
        sui->setupSUI(MAINVIEW_LOAD_FILE.c_str());
    }

    sui->uctSystem->clicked = boost::bind(&MainView::onSystemButtonPressed, this);
    sui->uctDashboard->clicked = boost::bind(&MainView::onDashboardButtonPressed, this);
    sui->uctAnalysis->clicked = boost::bind(&MainView::onAnalysisButtonPressed, this);
    sui->uctErrorAlarm->clicked = boost::bind(&MainView::onErrorAlarmButtonPressed, this);
    sui->btn_ErrorInfo_Close->clicked = boost::bind(&MainView::onErrorCloseBtnPressed, this);

    sui->uctSystem->hoverEntered = boost::bind(&MainView::onSystemHoverOn, this);
    sui->uctSystem->hoverLeft = boost::bind(&MainView::onSystemHoverOff, this);
    sui->uctDashboard->hoverEntered = boost::bind(&MainView::onDashboardHoverOn, this);
    sui->uctDashboard->hoverLeft = boost::bind(&MainView::onDashboardHoverOff, this);
    sui->uctAnalysis->hoverEntered = boost::bind(&MainView::onAnalysisHoverOn, this);
    sui->uctAnalysis->hoverLeft = boost::bind(&MainView::onAnalysisHoverOff, this);
    sui->uctErrorAlarm->hoverEntered = boost::bind(&MainView::onErrorAlarmHoverOn, this);
    sui->uctErrorAlarm->hoverLeft = boost::bind(&MainView::onErrorAlarmHoverOff, this);

    sui->btnSysInit->clicked = boost::bind(&MainView::onSubMenuSystemInitializationPressed, this);
    sui->btnSysStateMgr->clicked = boost::bind(&MainView::onSubMenuSystemStateManagerPressed, this);
    sui->btnSysHWReset->clicked = boost::bind(&MainView::onSubMenuHardwareResetPressed, this);
    sui->btnSysMaintenance->clicked = boost::bind(&MainView::onSubMenuMaintenancePressed, this);
    sui->btnSysService->clicked = boost::bind(&MainView::onSubMenuServicePressed, this);

    sui->btnAnalysisDataView->clicked = boost::bind(&MainView::onSubMenuDataViewPressed, this);
    sui->btnAnalysisSafetyDiagnostics->clicked = boost::bind(&MainView::onSubMenuSafetyDiagnosticsPressed, this);
    sui->btnAnalysisADT->clicked = boost::bind(&MainView::onSubMenuAdvancedDiagnosticsPressed, this);
    sui->btnAnalysisEventLog->clicked = boost::bind(&MainView::onSubMenuEventLogPressed, this);

    m_systemChanged = boost::bind(&IGSxGUI::MainView::onSystemStateChanged, this, _1);
    m_timer->timeout = boost::bind(&MainView::onTimeout, this);

    m_presenter = new IGSxGUI::MainPresenter(this);
}
IGSxGUI::MainView::~MainView()
{
    m_timer->stop();
    if (m_presenter != NULL)
    {
        delete m_presenter;
        m_presenter = NULL;
    }
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }

    if (m_systemChanged != NULL)
    {
        m_iSystem->unsubscribeForSystemState(m_systemChanged);
        m_systemChanged = NULL;
    }
    // Do not delete the plugins, they are maintained by the Factory
}

void IGSxGUI::MainView::show()
{
    m_timer->start(TIMER_INTERVAL);
    sui->uctSystem->setVisible(true);
    sui->uctDashboard->setVisible(true);
    sui->uctAnalysis->setVisible(true);

    sui->lblSystem->setText(NAVIGATION_BUTTON_SYSTEM);
    sui->lblDashboard->setText(NAVIGATION_BUTTON_DASHBOARD);
    sui->lblAnalysis->setText(NAVIGATION_BUTTON_ANALYSIS);
    sui->lblErrorAlarm->setText(NAVIGATION_BUTTON_ERRORALARM);

    sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_SYSTEM);
    sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_DASHBOARD);
    sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_ANALYSIS);
    sui->imvErrorAlarm->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_WARNING);

    sui->imv_TitleInfo_DateTime->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_CLOCK);
    sui->imv_ErrInfo_TimerImg->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_CLOCK);
    sui->imv_TitleInfo_Info->getGraphicsScene()->setBackgroundImageFile(IMAGE_WHITE_INFO);

    sui->lbl_tit_info_Time->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_TIME));
    sui->lbl_tit_info_Date->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE));
    sui->gbxTitleInfo_DateTime->setToolTip(STRING_DATE_TIME);

    sui->dialog->show();

    onSystemButtonPressed();
}

void IGSxGUI::MainView::showError(const std::string& eMsg, const std::string& timeStamp)
{
    if (sui->uctErrorAlarm != NULL)
    {
        if (!sui->uctErrorAlarm->isVisible()){
            sui->uctErrorAlarm->setVisible(true);
        }
        sui->lbl_ErrInfo_Date->setText(timeStamp);
        sui->lbl_ErrorInfo_Msg->setText(eMsg);
    }
}

void IGSxGUI::MainView::hideError()
{
    if (sui->uctErrorAlarm != NULL)
    {
        sui->uctErrorAlarm->setVisible(false);
    }
}

void IGSxGUI::MainView::onTimeout()
{
    if (sui->lbl_tit_info_Time->getText() == SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_TIME))
    {
        return;
    }
    sui->lbl_tit_info_Time->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_TIME));
    sui->lbl_tit_info_Date->setText(SystemDateTime::getSystemCurrentDateTime(SystemDateTime::STR_DATE));
    m_timer->stop();
    m_timer->start(TIMER_RESTART_INTERVAL);  // Increased the timer after first update as we dont need to update the seconds in timer.
}

void IGSxGUI::MainView::onSystemButtonPressed()
{
    showAnalysisSubMenu(false);
    showSystemSubMenu(true);

    sui->btnSysInit->setText(STRING_SYSTEM_SUBMENU1_BUTTON);
    sui->btnSysStateMgr->setText(STRING_SYSTEM_SUBMENU2_BUTTON);
    sui->btnSysHWReset->setText(STRING_SYSTEM_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_SYSTEM_SUBMENU4_BUTTON);
    sui->btnSysService->setText(STRING_SYSTEM_SUBMENU5_BUTTON);

    NavigationButton = BTN_SYSTEM;

    onDashboardHoverOff();
    onAnalysisHoverOff();
    onSystemHoverOn();

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    onSubMenuSystemInitializationPressed();
    sui->cntChildScreens->setVisible(true);
}

void IGSxGUI::MainView::onDashboardButtonPressed()
{
    bool bIsFirstTimeDisplay = false;

    showAnalysisSubMenu(false);
    showSystemSubMenu(false);

    NavigationButton = BTN_DASHBOARD;
    onSystemHoverOff();
    onAnalysisHoverOff();
    onDashboardHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->setActive(false);
    }

    if (m_iDashboard == NULL)
    {
        m_iDashboard = PluginFactory::getInstance().getDashboardPlugin();
        bIsFirstTimeDisplay = true;
    }
    m_iDashboard->setActive(true);

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    m_iDashboard->show(sui->cntChildScreens, bIsFirstTimeDisplay);
    sui->cntChildScreens->setVisible(true);
}


void IGSxGUI::MainView::onAnalysisButtonPressed()
{
    showSystemSubMenu(false);
    showAnalysisSubMenu(true);

    sui->btnAnalysisDataView->setText(STRING_ANALYSIS_SUBMENU1_BUTTON);
    sui->btnAnalysisSafetyDiagnostics->setText(STRING_ANALYSIS_SUBMENU2_BUTTON);
    sui->btnAnalysisADT->setText(STRING_ANALYSIS_SUBMENU3_BUTTON);
    sui->btnSysMaintenance->setText(STRING_ANALYSIS_SUBMENU4_BUTTON);

    NavigationButton = BTN_ANALYSIS;

    onSystemHoverOff();
    onDashboardHoverOff();
    onAnalysisHoverOn();

    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    m_iAnalysis->setActive(true);

    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    onSubMenuEventLogPressed();
    sui->cntChildScreens->setVisible(true);
}

void IGSxGUI::MainView::onErrorAlarmButtonPressed()
{
    if (m_iSystem != NULL)
    {
        m_iSystem->setActive(false);
    }

    if (m_iDashboard != NULL)
    {
        m_iDashboard->setActive(false);
    }

    if (m_iAnalysis == NULL)
    {
        m_iAnalysis = PluginFactory::getInstance().getAnalysisPlugin();
    }
    m_iAnalysis->setActive(true);
    sui->cntChildScreens->setVisible(false);
    Util::processEvents();
    onAlertPressed();
    sui->cntChildScreens->setVisible(true);

/*
    if ((!sui->gbx_ErrorInfo->isVisible()) && (sui->uctErrorAlarm->isEnabled()))
    {
        sui->gbx_ErrorInfo->setVisible(true);

    }
    */
}

void IGSxGUI::MainView::onErrorCloseBtnPressed()
{
    sui->gbx_ErrorInfo->setVisible(false);
}

void IGSxGUI::MainView::onSystemStateChanged(const SystemState::SystemStateEnum &state)
{
    switch (state)
    {
        case SystemState::SS_INITIALIZED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(true);
            sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_GREEN_CHECKCIRCLE);
            sui->lblTopBarStatus->setText(STRING_INITIALIZED);
            break;
        }
        case SystemState::SS_TERMINATED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(false);
            sui->lblTopBarStatus->setText(STRING_TERMINATED);
            break;
        }
        case SystemState::SS_INITIALIZING:
        case SystemState::SS_TERMINATING:
        {
            sui->uctTopBarStatus->setVisible(false);
            sui->bicTopBarStatus->setVisible(true);
            break;
        }
        case SystemState::SS_PARTIALLY_INITIALIZED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(false);
            sui->lblTopBarStatus->setText(STRING_PARTIALLY_INITIALIZED);
            break;
        }
        case SystemState::SS_RECOVERY_REQUIRED:
        {
            sui->uctTopBarStatus->setVisible(true);
            sui->bicTopBarStatus->setVisible(false);

            sui->imvTopBarStatus->setVisible(true);
            sui->imvTopBarStatus->getGraphicsScene()->setBackgroundImageFile(IMAGE_RED_WARNING_16PX);
            sui->lblTopBarStatus->setText(STRING_RECOVERY_REQUIRED);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::onSystemHoverOn()
{
    setMainNavigationButtonStyles(BTN_SYSTEM, IMAGE_BLUE_SYSTEM, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onDashboardHoverOn()
{
    setMainNavigationButtonStyles(BTN_DASHBOARD, IMAGE_BLUE_DASHBOARD, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onAnalysisHoverOn()
{
    setMainNavigationButtonStyles(BTN_ANALYSIS, IMAGE_BLUE_ANALYSIS, STYLE_HOVER_ON);
}

void IGSxGUI::MainView::onErrorAlarmHoverOn()
{
    if (sui->uctErrorAlarm->isEnabled())
    {
        setMainNavigationButtonStyles(BTN_ERRORALARM, IMAGE_RED_WARNING_16PX, STYLE_ERROR_ALARM_HOVER_ON);
    }
}

void IGSxGUI::MainView::onSystemHoverOff()
{
    if (NavigationButton != BTN_SYSTEM)
    {
        setMainNavigationButtonStyles(BTN_SYSTEM, IMAGE_WHITE_SYSTEM, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onDashboardHoverOff()
{
    if (NavigationButton != BTN_DASHBOARD)
    {
        setMainNavigationButtonStyles(BTN_DASHBOARD, IMAGE_WHITE_DASHBOARD, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onAnalysisHoverOff()
{
    if (NavigationButton != BTN_ANALYSIS)
    {
        setMainNavigationButtonStyles(BTN_ANALYSIS, IMAGE_WHITE_ANALYSIS, STYLE_HOVER_OFF);
    }
}

void IGSxGUI::MainView::onErrorAlarmHoverOff()
{
    if (sui->uctErrorAlarm->isEnabled())
    {
        setMainNavigationButtonStyles(BTN_ERRORALARM, IMAGE_WHITE_WARNING, STYLE_ERROR_ALARM_HOVER_OFF);
    }
}

void IGSxGUI::MainView::setMainNavigationButtonStyles(const BUTTON &button, const std::string &strImage, const std::string &strStyle) const
{
    switch (button)
    {
        case BTN_SYSTEM:
        {
            sui->imvSystem->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblSystem->setStyleSheetClass(strStyle);
            sui->gbxSystem->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_DASHBOARD:
        {
            sui->imvDashboard->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblDashboard->setStyleSheetClass(strStyle);
            sui->gbxDashboard->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ANALYSIS:
        {
            sui->imvAnalysis->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblAnalysis->setStyleSheetClass(strStyle);
            sui->gbxAnalysis->setStyleSheetClass(strStyle);
            break;
        }
        case BTN_ERRORALARM:
        {
            sui->imvErrorAlarm->getGraphicsScene()->setBackgroundImageFile(strImage);
            sui->lblErrorAlarm->setStyleSheetClass(strStyle);
            sui->gbxErrorAlarm->setStyleSheetClass(strStyle);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setSystemSubMenuButtonStyle(const SYSTEM_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_SYSTEM_INITIALIZATION:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEM_STATEMANAGER:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_HARDWARE_RESET:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_MAINTENANCE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SYSTEM_SERVICE:
        {
            sui->btnSysInit->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysStateMgr->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysHWReset->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysMaintenance->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnSysService->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        default:
            // ToDo, log this case.
            break;
    }
}

void IGSxGUI::MainView::setAnalysisSubMenuButtonStyle(const IGSxGUI::MainView::ANALYSIS_SUBMENU_BUTTON &button) const
{
    switch (button)
    {
        case BTN_DATAVIEW:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_SAFETY_DIAGNOSTICS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_ADVANCED_DIAGNOSTICS:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            break;
        }
        case BTN_EVENTLOG:
        {
            sui->btnAnalysisDataView->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisSafetyDiagnostics->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisADT->setStyleSheetClass(STYLE_MENU_BUTTON_NORMAL);
            sui->btnAnalysisEventLog->setStyleSheetClass(STYLE_MENU_BUTTON_CLICKED);
            break;
        }
        default:
           // ToDo, log this case.
           break;
    }
}

void IGSxGUI::MainView::onSubMenuSystemInitializationPressed()
{
    bool bIsFirstTimeDisplay = false;

    setSystemSubMenuButtonStyle(BTN_SYSTEM_INITIALIZATION);

    if (m_iSystem == NULL)
    {
        m_iSystem = PluginFactory::getInstance().getSystemPlugin();

        if (m_systemChanged != NULL)
        {
            m_iSystem->subscribeForSystemState(m_systemChanged);
            onSystemStateChanged(m_iSystem->retrieveSystemState());
        }

        bIsFirstTimeDisplay = true;
    }

    m_iSystem->setActive(true);
    m_iSystem->show(sui->cntChildScreens, bIsFirstTimeDisplay);
}
void IGSxGUI::MainView::onSubMenuSystemStateManagerPressed()
{
    setSystemSubMenuButtonStyle(BTN_SYSTEM_STATEMANAGER);
}
void IGSxGUI::MainView::onSubMenuHardwareResetPressed()
{
    setSystemSubMenuButtonStyle(BTN_HARDWARE_RESET);
}
void IGSxGUI::MainView::onSubMenuMaintenancePressed()
{
    setSystemSubMenuButtonStyle(BTN_MAINTENANCE);
    m_iSystem->showCPD(sui->cntChildScreens, false);
}
void IGSxGUI::MainView::onSubMenuServicePressed()
{
    setSystemSubMenuButtonStyle(BTN_SYSTEM_SERVICE);
}
void IGSxGUI::MainView::onSubMenuDataViewPressed()
{
    setAnalysisSubMenuButtonStyle(BTN_DATAVIEW);
}
void IGSxGUI::MainView::onSubMenuSafetyDiagnosticsPressed()
{
    setAnalysisSubMenuButtonStyle(BTN_SAFETY_DIAGNOSTICS);
}
void IGSxGUI::MainView::onSubMenuAdvancedDiagnosticsPressed()
{
    setAnalysisSubMenuButtonStyle(BTN_ADVANCED_DIAGNOSTICS);

    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showADT(sui->cntChildScreens, false);
    }
}

void IGSxGUI::MainView::onAlertPressed()
{
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showAlertViewer(sui->cntChildScreens, m_bInitializeEventLog);
    }
    m_bInitializeEventLog = false;
}
void IGSxGUI::MainView::onSubMenuEventLogPressed()
{
    setAnalysisSubMenuButtonStyle(BTN_EVENTLOG);
    if (m_iAnalysis != NULL)
    {
        m_iAnalysis->showEventViewer(sui->cntChildScreens, m_bInitializeEventLog);
    }
    m_bInitializeEventLog = false;
}

void IGSxGUI::MainView::showSystemSubMenu(bool bShow) const
{
    sui->btnSysInit->setVisible(bShow);
    sui->btnSysStateMgr->setVisible(false);  // Screen not implemented yet
    sui->btnSysHWReset->setVisible(false);  // Screen not implemented yet
    sui->btnSysMaintenance->setVisible(bShow);  // Screen not implemented yet
    sui->btnSysService->setVisible(false);  // Screen not implemented yet
}

void IGSxGUI::MainView::showAnalysisSubMenu(bool bShow) const
{
    sui->btnAnalysisDataView->setVisible(false);  // Screen not implemented yet
    sui->btnAnalysisSafetyDiagnostics->setVisible(false);  // Screen not implemented yet
    sui->btnAnalysisADT->setVisible(bShow);  // Screen not implemented yet
    sui->btnAnalysisEventLog->setVisible(bShow);
}
