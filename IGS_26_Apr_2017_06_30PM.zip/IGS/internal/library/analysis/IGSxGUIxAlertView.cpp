/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxAlertView.cpp
| Author       : Raja A
| Description  : Implementation of ADT view
|
| ! \file        IGSxGUIxAlertView.cpp
| ! \brief       Implementation of Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include "IGSxGUIxAlertView.hpp"
#include "IGSxGUIxMoc_AlertView.hpp"
#include <SUITableWidget.h>
#include <SUITimer.h>
#include <SUIButton.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
const std::string IGSxGUI::AlertView::ALERTVIEW_LOAD_FILE = IGS::Resource::path("IGSxGUIxAlertView.xml");

IGSxGUI::AlertView::AlertView() :
    sui(new SUI::AlertView),m_timer(SUI::Timer::createTimer()), m_alarmcolorflag(false)
{
  m_timer->timeout = boost::bind(&AlertView::onTimeout, this);
}

IGSxGUI::AlertView::~AlertView()
{

    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::AlertView::show(SUI::Container* MainScreenContainer, bool /*bIsFirstTimeDisplay*/)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(ALERTVIEW_LOAD_FILE.c_str(), MainScreenContainer);
    }
    m_timer->start(500);
    sui->tawAlert->showGrid(false);
}
void IGSxGUI::AlertView::setActive(bool /*bActive*/)
{
    // Currently no state information is preserved in during Page switch. No events triggered.
}

void IGSxGUI::AlertView::updateStatus(const IGS::Result &result)
{

}
void IGSxGUI::AlertView::onTimeout()
{
    if (!m_alarmcolorflag)
    {
   sui->btnAlarmTableRow1->setStyleSheetClass("alarmbuttonimagered");
    m_alarmcolorflag = true;
    } else {
      sui->btnAlarmTableRow1->setStyleSheetClass("alarmbuttonimagewhite");
       m_alarmcolorflag = false;
    }

}
