/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxADT.cpp
| Author       : Venugopal S
| Description  : Implementation of ADT
|
| ! \file        IGSxGUIxADT.cpp
| ! \brief       Implementation of ADT
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <string>
#include "IGSxGUIxADT.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
IGSxGUI::ADT::ADT(const IGSxADT::MetaDescription& metaDescription):
    m_name(metaDescription.name()),
    m_subsystem(metaDescription.subSystem()),
    m_description(metaDescription.description()),
    m_htmlFile(metaDescription.htmlFile())
{
}

IGSxGUI::ADT::~ADT()
{
}

std::string IGSxGUI::ADT::getName() const
{
    return m_name;
}

std::string IGSxGUI::ADT::getDescription() const
{
    return m_description;
}

std::string IGSxGUI::ADT::getSubsystem() const
{
    return m_subsystem;
}
std::string IGSxGUI::ADT::getHtmlFile() const
{
    return m_htmlFile;
}

bool IGSxGUI::ADT::start() const
{
    try
    {
        IGSxADT::ADT::getInstance()->startAdt(getName());
    }catch (IGS::Exception& /*ex*/){
        // ToDo, determine what to do.
    }
    return true;
}
