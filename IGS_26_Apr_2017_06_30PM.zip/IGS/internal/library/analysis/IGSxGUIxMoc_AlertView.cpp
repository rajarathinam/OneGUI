/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxMoc_AlertView.cpp
| Author       : Raja A
| Description  : Implementation of Moc Alert view
|
| ! \file        IGSxGUIxMoc_AlertView.cpp
| ! \brief       Implementation of Moc Alert view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Netherlands B.V.                    |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include "IGSxGUIxMoc_AlertView.hpp"
#include <SUIUILoader.h>
#include <SUIObjectList.h>
#include <SUIDialog.h>
#include <SUIContainer.h>
#include <SUITableWidget.h>
#include <SUIButton.h>


/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
SUI::AlertView::AlertView():tawAlert(NULL)
{
}

void SUI::AlertView::setupSUI(const char* XMLFileName)
{
    dialog = UILoader::loadUI(XMLFileName);
    loadObjects(dialog->getObjectList());
}

void SUI::AlertView::setupSUIContainer(const char *XMLFileName, Container* container)
{
    container->setUiFilename(XMLFileName);
    loadObjects(container->getObjectList());
}

void SUI::AlertView::loadObjects(ObjectList* objectList)
{
    tawAlert = objectList->getObject<TableWidget>("tawAlert");
    btnAlarmTableRow1 = objectList->getObject<Button>("btn-tawAlert:1-1");

}


