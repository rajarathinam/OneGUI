/*----------------------------------------------------------------------------|
|                                                                             |
|                              C++ Source File                                |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxGUIxEventViewerView.cpp
| Author       : Surya Tiwari
| Description  : Implementation of Event Viewer view
|
| ! \file        IGSxGUIxEventViewerView.cpp
| ! \brief       Implementation of Event Viewer view
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/bind.hpp>
#include <string>
#include <fstream>
#include "IGSxGUIxEventViewerView.hpp"
#include "IGSxGUIxMoc_EventViewerView.hpp"
#include "IGSxGUIxSystemDateTime.hpp"
#include "IGSxERR.hpp"
#include "IGSxCOMMON.hpp"
#include <SUIButton.h>
#include <SUILabel.h>
#include <SUITextArea.h>
/*----------------------------------------------------------------------------|
|                                     Implementation                          |
|----------------------------------------------------------------------------*/
namespace IGSxGUI
{
    std::string lastupdateddate;
}

const std::string IGSxGUI::EventViewerView::LOAD_FILE_EVENT_VIEWER = IGS::Resource::path("IGSxGUIxEventViewer.xml");
const std::string IGSxGUI::EventViewerView::STRING_LAST_UPDATED = "Last Updated: ";
const std::string IGSxGUI::EventViewerView::STRING_NO_FILE = "No File";
const int IGSxGUI::EventViewerView::READ_NUM_LINES = 1000;

IGSxGUI::EventViewerView::EventViewerView() :
    sui(new SUI::EventViewerView)
{
    cirbuf.set_capacity(1000);
}
IGSxGUI::EventViewerView::~EventViewerView()
{
    if (sui != NULL)
    {
        delete sui;
        sui = NULL;
    }
}

void IGSxGUI::EventViewerView::show(SUI::Container* MainScreenContainer, bool bIsFirstTimeDisplay)
{
    if (sui != NULL)
    {
        sui->setupSUIContainer(LOAD_FILE_EVENT_VIEWER.c_str(), MainScreenContainer);
    }

    sui->buttonUpdateLog->clicked = boost::bind(&EventViewerView::onUpdateLogButtonPressed, this);

    if (true == bIsFirstTimeDisplay)
    {
        sui->lblLastUpdatedDate->setText(STRING_LAST_UPDATED);
    } else {
        std::string fulltext;
        sui->lblLastUpdatedDate->setText(lastupdateddate);

        boost::circular_buffer<std::string>::iterator it;
        for (it = cirbuf.begin(); it != cirbuf.end(); ++it)
        {
            fulltext += (*it);
        }
        sui->textAreaEventViewerLog->clearText();
        sui->textAreaEventViewerLog->setText(fulltext);
    }
}

void IGSxGUI::EventViewerView::setActive(bool /*bActive*/)
{
}

void IGSxGUI::EventViewerView::onUpdateLogButtonPressed()
{
    UpdateLastUpdatedDateTime();
    std::string currentfilename = IGSxERR::EventLogger::getInstance()->getEventLog();
    std::string prevfilename = IGSxERR::EventLogger::getInstance()->getPreviousEventLog();
    std::string gline;
    std::string fulltext;
    std::fstream curreventlog;
    std::fstream preveventlog;
    bool fileReadactive = false;
    int lineCounter = 0;

    sui->textAreaEventViewerLog->clearText();

    curreventlog.open(currentfilename.c_str(), std::fstream::in);
    if (curreventlog.is_open())
    {
        lineCounter = 1;        // Read 1000 Lines
        while (std::getline(curreventlog, gline))
        {
            lineCounter++;
            cirbuf.push_back(gline);
            if (READ_NUM_LINES == lineCounter)
            {
                break;
            }
        }
        fileReadactive = true;
    }
    curreventlog.close();

    if (lineCounter < READ_NUM_LINES)  // Less Lines in latest file, Read second latest file
    {
        preveventlog.open(prevfilename.c_str(), std::fstream::in);
        if (preveventlog.is_open())
        {
            while (std::getline(preveventlog, gline))
            {
                lineCounter++;
                cirbuf.push_back(gline);
                if (READ_NUM_LINES == lineCounter)
                {
                    break;
                }
            }
            fileReadactive = true;
        }
        preveventlog.close();
    }

    if (fileReadactive)
    {
        boost::circular_buffer<std::string>::iterator it;

        for (it = cirbuf.begin(); it != cirbuf.end(); ++it)
        {
            fulltext += (*it);
        }
        sui->textAreaEventViewerLog->setText(fulltext);
    } else {
        sui->textAreaEventViewerLog->setText(STRING_NO_FILE);
    }
}

void IGSxGUI::EventViewerView::UpdateLastUpdatedDateTime() const
{
    SystemDateTime currDate;
    lastupdateddate = STRING_LAST_UPDATED + currDate.SystemCurrentDateTime(SystemDateTime::STR_DATE);
    sui->lblLastUpdatedDate->setText(lastupdateddate);
}
