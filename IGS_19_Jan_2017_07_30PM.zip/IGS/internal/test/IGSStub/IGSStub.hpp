/*----------------------------------------------------------------------------|
|                                                                             |
|                            C++ Header File                                  |
|                                                                             |
|-----------------------------------------------------------------------------|
|
| Ident        : IGSxITS_Stub.hpp
| Author       : Thijs Jacobs
| Description  : Header file for IGSxITS stub
|
| ! \file        IGSxITS_stub.hpp
| ! \brief       Header file for IGSxITS stub
|
|-----------------------------------------------------------------------------|
|                                                                             |
|        Copyright (c) 2016, ASML Holding N.V. (including affiliates).        |
|                           All rights reserved                               |
|                                                                             |
|----------------------------------------------------------------------------*/

#ifndef IGSXITS_STUB_HPP
#define IGSXITS_STUB_HPP

/*----------------------------------------------------------------------------|
|                                     Includes                                |
|----------------------------------------------------------------------------*/
#include <boost/shared_ptr.hpp>
#include <string>
#include <vector>
#include "IGSxITS.hpp"
/*----------------------------------------------------------------------------|
|                                     Defines                                 |
|----------------------------------------------------------------------------*/
// forward declaration
namespace SUI {
class Timer;
}

namespace IGSxITS {

typedef int ErrorId;

class Driver : public MetaDescription
{
 public:
    explicit Driver(const std::string& name, const std::string& description, int initializeDuration, int terminateDuration) :
        MetaDescription(name, description),
        m_driverState(DriverState::DS_TERMINATED),
        m_error(0) ,
        m_initializeDuration(initializeDuration),
        m_terminateDuration(terminateDuration),
        m_driverStatus(DriverState::DS_TERMINATED){}
    virtual ~Driver() {}

    DriverState::DriverStateEnum driverState() {return m_driverState;}
    void setDriverState(DriverState::DriverStateEnum state) {m_driverState = state;}

    ErrorId error() {return m_error;}
    void setError(ErrorId error) {m_error = error;}

    int initializeDuration() {return m_initializeDuration;}
    void setInitializeDuration(int duration) {m_initializeDuration = duration;}

    int terminateDuration() {return m_terminateDuration;}
    void setTerminateDuration(int duration) {m_terminateDuration = duration;}

    DriverStatus driverStatus() {return m_driverStatus;}
    void setDriverStatus(DriverStatus status) {m_driverStatus = status;}

 private:
    DriverState::DriverStateEnum m_driverState;
    ErrorId m_error;
    int m_initializeDuration;
    int m_terminateDuration;
    DriverStatus m_driverStatus;
};

/*----------------------------------------------------------------------------|
|                                     Class Definition                        |
|----------------------------------------------------------------------------*/
class InitTerminate_Stub : public InitTerminate
{
 public:
    // instance
    static InitTerminate* getInstance();

    // meta data
    virtual MetaDescriptions getSysfuns();
    virtual MetaDescriptions getDrivers(const std::string& sysfunName);

    // init-terminate
    virtual void initializeSystem(const InitializeCompletedCallback& cb);
    virtual void initializeDrivers(const DriverNames& driverNames, const InitializeCompletedCallback& cb);
    virtual void terminateSystem(const TerminateCompletedCallback& cb);
    virtual void terminateDrivers(const DriverNames& driverNames, const TerminateCompletedCallback& cb);

    // current state
    virtual DriverStatus getDriverStatus(const std::string& driverName);

    // state changed event
    virtual void subscribeToDriverStatusChanged(const DriverStatusChangedCallback& cb);
    virtual void unsubscribeToDriverStatusChanged();

    // Stub manipulation
    void setDriverStatus(std::string driverName, IGSxITS::DriverState::DriverStateEnum state);
    void setThrowExceptions(bool enable);

 protected:
    InitTerminate_Stub();
    virtual ~InitTerminate_Stub();

 private:
    Driver& driver(const std::string& driverName);
    void notifyDriverStateChanged(Driver* driver);
    void on_initializeSystem();
    void on_terminateSystem();
    void on_initializeDriver();
    void on_terminateDriver();
    int getInitializeDuration(const std::string& driverName);
    int getTerminateDuration(const std::string& driverName);

 private:
    // callbacks
    InitializeCompletedCallback m_initializeSystemCompletedCb;
    InitializeCompletedCallback m_initializeDriverCompletedCb;
    TerminateCompletedCallback m_terminateSystemCompletedCb;
    TerminateCompletedCallback m_terminateDriverCompletedCb;
    DriverStatusChangedCallback m_driverStatusChangedCb;

    std::vector<Driver> m_drivers;  // driver administration
    Driver* m_driver;  // initializing/terminating driver
    boost::shared_ptr<SUI::Timer> m_timer;  // timer for updating driver states
    int m_elapsedTime;  // elapsed time in ms
    static const char* ERR_INIT_SYS;
    static const char* ERR_GET_DRIVER;
    bool m_throwException;
};
}  // namespace IGSxITS

#endif  // IGSXITS_STUB_HPP

